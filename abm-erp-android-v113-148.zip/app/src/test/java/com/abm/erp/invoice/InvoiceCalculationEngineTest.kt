package com.abm.erp.invoice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal

class InvoiceCalculationEngineTest {

    private fun bd(v: String) = BigDecimal(v)

    @Test
    fun `normal invoice - simple qty times price`() {
        val line = InvoiceCalculationEngine.LineInput(quantity = bd("10"), unitPrice = bd("50.00"))
        val result = InvoiceCalculationEngine.computeInvoice(InvoiceCalculationEngine.InvoiceInput(listOf(line)))
        assertEquals(bd("500.00"), result.currentInvoiceNetTotal.setScale(2))
    }

    @Test
    fun `line discount reduces the taxable base before tax`() {
        val line = InvoiceCalculationEngine.LineInput(quantity = bd("10"), unitPrice = bd("100.00"), lineDiscountPct = bd("10"))
        val r = InvoiceCalculationEngine.computeLine(line)!!
        assertEquals(bd("900.00").setScale(2), r.afterLineDiscount)
    }

    @Test
    fun `VAT is applied on the discounted taxable amount, not the gross`() {
        val line = InvoiceCalculationEngine.LineInput(quantity = bd("1"), unitPrice = bd("1000.00"), lineDiscountPct = bd("10"), vatPct = bd("15"))
        val r = InvoiceCalculationEngine.computeLine(line)!!
        // taxable = 900, vat = 135, net = 1035 — NOT 1000*1.15=1150 then discounted
        assertEquals(bd("135.00").setScale(2), r.vatAmount)
        assertEquals(bd("1035.00").setScale(2), r.netLineTotal)
    }

    @Test
    fun `free quantity does not add revenue`() {
        val line = InvoiceCalculationEngine.LineInput(quantity = bd("10"), freeQuantity = bd("2"), unitPrice = bd("50.00"))
        val r = InvoiceCalculationEngine.computeLine(line)!!
        assertEquals(bd("500.00").setScale(2), r.grossAmount) // free quantity is not billed
    }

    @Test
    fun `unit conversion - cartons to pieces`() {
        // 5 cartons, 24 pieces per carton, price is per-piece
        val line = InvoiceCalculationEngine.LineInput(quantity = bd("5"), unitConversionFactor = bd("24"), unitPrice = bd("10.00"))
        val r = InvoiceCalculationEngine.computeLine(line)!!
        assertEquals(bd("120").setScale(0), r.baseQuantity.setScale(0))
        assertEquals(bd("1200.00").setScale(2), r.grossAmount)
    }

    @Test
    fun `fractional quantity is handled precisely`() {
        val line = InvoiceCalculationEngine.LineInput(quantity = bd("2.5"), unitPrice = bd("33.33"))
        val r = InvoiceCalculationEngine.computeLine(line)!!
        assertEquals(bd("83.33").setScale(2, java.math.RoundingMode.HALF_UP), r.grossAmount)
    }

    @Test
    fun `previous due carries into remaining due but not into current invoice net total`() {
        val line = InvoiceCalculationEngine.LineInput(quantity = bd("1"), unitPrice = bd("100.00"))
        val result = InvoiceCalculationEngine.computeInvoice(InvoiceCalculationEngine.InvoiceInput(listOf(line), previousDue = bd("500.00")))
        assertEquals(bd("100.00").setScale(2), result.currentInvoiceNetTotal)
        assertEquals(bd("600.00").setScale(2), result.remainingDue)
    }

    @Test
    fun `partial payment reduces remaining due`() {
        val line = InvoiceCalculationEngine.LineInput(quantity = bd("1"), unitPrice = bd("1000.00"))
        val result = InvoiceCalculationEngine.computeInvoice(InvoiceCalculationEngine.InvoiceInput(listOf(line), paidAmount = bd("400.00")))
        assertEquals(bd("600.00").setScale(2), result.remainingDue)
    }

    @Test
    fun `rounding edge case - HALF_UP at exactly 0_5`() {
        val line = InvoiceCalculationEngine.LineInput(quantity = bd("1"), unitPrice = bd("10.005"))
        val r = InvoiceCalculationEngine.computeLine(line)!!
        assertEquals(bd("10.01").setScale(2), r.netLineTotal) // HALF_UP rounds 10.005 up to 10.01, not down to 10.00
    }

    @Test
    fun `return adjustment reduces the line`() {
        val line = InvoiceCalculationEngine.LineInput(quantity = bd("10"), unitPrice = bd("100.00"), returnAdjustment = bd("-200.00"))
        val r = InvoiceCalculationEngine.computeLine(line)!!
        assertEquals(bd("800.00").setScale(2), r.netLineTotal)
    }

    @Test
    fun `negative quantity is rejected`() {
        val line = InvoiceCalculationEngine.LineInput(quantity = bd("-5"), unitPrice = bd("10.00"))
        assertEquals(null, InvoiceCalculationEngine.computeLine(line))
    }

    @Test
    fun `negative price is rejected`() {
        val line = InvoiceCalculationEngine.LineInput(quantity = bd("5"), unitPrice = bd("-10.00"))
        assertEquals(null, InvoiceCalculationEngine.computeLine(line))
    }

    @Test
    fun `invoice with no lines is rejected, never silently zero`() {
        val result = InvoiceCalculationEngine.computeInvoice(InvoiceCalculationEngine.InvoiceInput(emptyList()))
        assertTrue(result.rejected)
    }

    @Test
    fun `invoice-level discount and delivery charge apply after line totals`() {
        val line = InvoiceCalculationEngine.LineInput(quantity = bd("1"), unitPrice = bd("1000.00"))
        val result = InvoiceCalculationEngine.computeInvoice(
            InvoiceCalculationEngine.InvoiceInput(listOf(line), invoiceLevelDiscountPct = bd("10"), deliveryCharge = bd("50.00")),
        )
        // 1000 -> 900 after 10% invoice discount -> +50 delivery = 950
        assertEquals(bd("950.00").setScale(2), result.currentInvoiceNetTotal)
    }
}
