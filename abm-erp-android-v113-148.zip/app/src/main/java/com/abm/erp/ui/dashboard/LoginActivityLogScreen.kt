package com.abm.erp.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.data.FirebaseSync
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LoginActivityLogScreen(onClose: () -> Unit) {
    val loginLog by FirebaseSync.loginLog.collectAsState()
    val formatter = remember { SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()) }

    Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Login Activity Log", style = MaterialTheme.typography.titleMedium)
            IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = "Close") }
        }
        Text(
            "Every login attempt — successful or failed — with device and time. ⚠ marks a login far from where this person is normally assigned.",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(12.dp))

        if (loginLog.isEmpty()) {
            Text("No login activity yet.", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        LazyColumn {
            items(loginLog, key = { it.id }) { entry ->
                Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (entry.anomalous) {
                                    Text("⚠ ", color = WarningAmber, fontWeight = FontWeight.Bold)
                                }
                                Text(entry.employeeName, fontWeight = FontWeight.SemiBold, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                            }
                            Text(
                                entry.result,
                                color = if (entry.result == "Success") SuccessGreen else DangerRed,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                        Text(
                            "${entry.deviceId} · ${formatter.format(Date(entry.atMillis))}" + if (entry.anomalous) " · far from assigned area" else "",
                            style = MaterialTheme.typography.labelSmall, color = if (entry.anomalous) WarningAmber else TextSecondary,
                        )
                    }
                }
            }
        }
    }
}
