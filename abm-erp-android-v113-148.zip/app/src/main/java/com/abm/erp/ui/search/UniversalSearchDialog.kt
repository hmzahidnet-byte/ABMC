package com.abm.erp.ui.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.abm.erp.core.GlassCard
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

/**
 * Global Rule — Universal Search. One search box across Dealers, Retailers,
 * Sales Invoices, Tasks, Leads, and Approvals (MockRepository.universalSearch
 * does the actual matching, purely in-memory over what's already loaded —
 * works offline like everything else in this app). Tapping a result
 * navigates to that module's existing screen; it doesn't try to deep-link
 * to the specific record (that would need per-module route params this
 * app's NavGraph doesn't carry today), so the destination screen opens
 * and the person finds the exact record themselves — a real, honest
 * "search takes you to the right place" rather than an unbuilt promise.
 */
@Composable
fun UniversalSearchDialog(onDismiss: () -> Unit, onNavigate: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var debouncedQuery by remember { mutableStateOf("") }
    LaunchedEffect(query) {
        kotlinx.coroutines.delay(250) // debounce — avoid re-searching on every single keystroke
        debouncedQuery = query
    }
    val results = remember(debouncedQuery) { MockRepository.universalSearch(debouncedQuery) }
    var typeFilter by remember { mutableStateOf<String?>(null) }
    val availableTypes = remember(results) { results.map { it.moduleReference }.distinct() }
    val filteredResults = remember(results, typeFilter) { if (typeFilter == null) results else results.filter { it.moduleReference == typeFilter } }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
                Text("Universal Search", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("Dealer, retailer, invoice, task, lead…") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                )
                Spacer(Modifier.height(10.dp))
                if (query.isBlank()) {
                    Text("টাইপ করা শুরু করুন — Dealer/Retailer/Invoice/Task/Lead/Approval সব জায়গায় একসাথে খুঁজবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                } else if (results.isEmpty()) {
                    Text("কোনো ফলাফল পাওয়া যায়নি।", color = TextSecondary)
                } else {
                    if (availableTypes.size > 1) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                            FilterChip(selected = typeFilter == null, onClick = { typeFilter = null }, label = { Text("All (${results.size})") })
                            availableTypes.forEach { t ->
                                FilterChip(selected = typeFilter == t, onClick = { typeFilter = t }, label = { Text(t) })
                            }
                        }
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(filteredResults, key = { it.moduleReference + it.entityId }) { r ->
                            GlassCard(
                                modifier = Modifier.fillMaxWidth().then(
                                    if (r.navRoute != null) Modifier.clickable {
                                        com.abm.erp.data.PendingSearchNavigation.request(r.moduleReference, r.entityId)
                                        onNavigate(r.navRoute)
                                    } else Modifier,
                                ),
                            ) {
                                Text("${r.moduleReference} · ${r.title}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                Text(r.subtitle, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                TextButton(onClick = onDismiss) { Text("Close") }
            }
        }
    }
}
