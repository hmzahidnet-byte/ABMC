package com.abm.erp.data

import android.content.Context

/**
 * Device-local (SharedPreferences) session state — everything here lives
 * only on THIS phone, never synced. Was previously private inside
 * LoginScreen.kt; moved here so ABMApplication.onCreate() can also read the
 * saved company code at cold start (needed to point FirebaseSync at the
 * right tenant before any screen has even opened).
 */
private const val SESSION_PREFS = "abm_session"
private const val KEY_LAST_EMPLOYEE_ID = "last_employee_id"
private const val KEY_LAST_USER_ACCOUNT_ID = "last_user_account_id"
private const val KEY_LAST_EMPLOYEE_PROFILE_ID = "last_employee_profile_id"
private const val KEY_BIOMETRIC_ENROLLED_AT = "biometric_enrolled_at_epoch_millis"
private const val KEY_DEVICE_ID = "device_id"
private const val KEY_COMPANY_CODE = "company_code"
private const val KEY_LAST_MOBILE = "last_mobile"
private const val KEY_LANGUAGE = "language"
private const val KEY_HIDDEN_WIDGETS = "dashboard_hidden_widgets"

fun saveLastLoggedInEmployee(context: Context, employeeId: String) {
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE)
        .edit().putString(KEY_LAST_EMPLOYEE_ID, employeeId).apply()
}

fun getLastLoggedInEmployee(context: Context): String? =
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).getString(KEY_LAST_EMPLOYEE_ID, null)

/**
 * Production biometric fix — a real UserAccount + EmployeeProfile is the
 * authoritative identity for biometric quick-unlock, not the demo
 * employeeId above (kept only for the DEBUG/legacy demo path).
 * pinSetAtEpochMillis is captured at enrollment time specifically so a
 * later PIN change (which updates the real UserAccount's pinSetAt) can be
 * detected and invalidate this device's biometric binding — comparing
 * timestamps client-side since SharedPreferences on THIS device can't be
 * reached by other devices/an admin action directly.
 */
fun saveLastLoggedInAccount(context: Context, userAccountId: String, employeeProfileId: String, pinSetAtEpochMillis: Long) {
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).edit()
        .putString(KEY_LAST_USER_ACCOUNT_ID, userAccountId)
        .putString(KEY_LAST_EMPLOYEE_PROFILE_ID, employeeProfileId)
        .putLong(KEY_BIOMETRIC_ENROLLED_AT, pinSetAtEpochMillis)
        .apply()
}

fun getLastLoggedInAccountId(context: Context): String? =
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).getString(KEY_LAST_USER_ACCOUNT_ID, null)

fun getLastLoggedInEmployeeProfileId(context: Context): String? =
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).getString(KEY_LAST_EMPLOYEE_PROFILE_ID, null)

fun getBiometricEnrolledAtEpochMillis(context: Context): Long =
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).getLong(KEY_BIOMETRIC_ENROLLED_AT, 0L)

/** Clears the real-account biometric binding — called on logout, device revoke, or when the account can no longer be resolved/validated. */
fun clearLastLoggedInAccount(context: Context) {
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).edit()
        .remove(KEY_LAST_USER_ACCOUNT_ID).remove(KEY_LAST_EMPLOYEE_PROFILE_ID).remove(KEY_BIOMETRIC_ENROLLED_AT)
        .remove(KEY_LAST_MOBILE)
        .apply()
}

/** Foundation Layer — Session Management: called on ordinary logout so the next app open requires a full PIN/biometric login again instead of auto-resuming this employee's session. */
fun clearLastLoggedInEmployee(context: Context) {
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).edit().remove(KEY_LAST_EMPLOYEE_ID).apply()
    clearLastLoggedInAccount(context)
}

/** This phone's own stable identity — created once, kept until app uninstall. Used by Trusted Devices/Login Activity Log. */
fun getOrCreateDeviceId(context: Context): String {
    val prefs = context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE)
    val existing = prefs.getString(KEY_DEVICE_ID, null)
    if (existing != null) return existing
    val fresh = "DEV-" + java.util.UUID.randomUUID().toString()
    prefs.edit().putString(KEY_DEVICE_ID, fresh).apply()
    return fresh
}

/** Multi-tenant: which company's data this device is scoped to — entered once at the Company Code screen, remembered after. */
fun getSavedCompanyCode(context: Context): String? =
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).getString(KEY_COMPANY_CODE, null)

fun saveCompanyCode(context: Context, code: String) {
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).edit().putString(KEY_COMPANY_CODE, code).apply()
}

/**
 * v113-139 — remembers the mobile number of the last SUCCESSFUL login on this
 * device, so a returning employee is asked only for their PIN instead of retyping
 * their number every time (person's explicit request). Stored per-device in the
 * same SharedPreferences as the other session values — it is a convenience hint,
 * NOT a credential: the PIN is still verified in full against the PBKDF2 hash on
 * every single login, and `clearLastLoggedInAccount` (logout) clears this too so
 * a shared phone doesn't leak the previous user's number.
 */
fun getRememberedMobile(context: Context): String? =
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).getString(KEY_LAST_MOBILE, null)

fun saveRememberedMobile(context: Context, mobile: String) {
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).edit().putString(KEY_LAST_MOBILE, mobile).apply()
}

fun getSavedLanguage(context: Context): String =
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).getString(KEY_LANGUAGE, "bn") ?: "bn"

fun saveLanguage(context: Context, lang: String) {
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).edit().putString(KEY_LANGUAGE, lang).apply()
}

/** Dashboard Personalization / Configurable Widgets — persisted per-device via SharedPreferences (no backend needed, this is a UI preference, not business data). */
fun getHiddenDashboardWidgets(context: Context): Set<String> =
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).getStringSet(KEY_HIDDEN_WIDGETS, emptySet()) ?: emptySet()

fun saveHiddenDashboardWidgets(context: Context, hidden: Set<String>) {
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).edit().putStringSet(KEY_HIDDEN_WIDGETS, hidden).apply()
}

/** v86, Module 13 — Notification Preferences: per-device muted categories. */
private const val KEY_MUTED_NOTIFICATION_CATEGORIES = "muted_notification_categories"
fun getMutedNotificationCategories(context: Context): Set<String> =
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).getStringSet(KEY_MUTED_NOTIFICATION_CATEGORIES, emptySet()) ?: emptySet()

fun saveMutedNotificationCategories(context: Context, muted: Set<String>) {
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).edit().putStringSet(KEY_MUTED_NOTIFICATION_CATEGORIES, muted).apply()
}
