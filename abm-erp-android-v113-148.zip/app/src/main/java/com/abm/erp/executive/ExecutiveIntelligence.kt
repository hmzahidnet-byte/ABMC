package com.abm.erp.executive

import java.time.LocalDateTime

/**
 * Foundation 6 — Executive Command Center. Deterministic KPI/trend math
 * only — "Do not use fake KPI values. Do not use random AI output."
 */
object ExecutiveIntelligence {

    data class TrendResult(val current: Double, val previous: Double, val absoluteChange: Double, val pctChange: Double?, val direction: String, val baselineMissing: Boolean)

    /** Section 3 — real time comparison, avoids divide-by-zero, flags missing baseline instead of a misleading 0%/∞%. */
    fun computeTrend(current: Double, previous: Double): TrendResult {
        val absChange = current - previous
        val baselineMissing = previous == 0.0
        val pct = if (baselineMissing) null else (absChange / previous) * 100
        val direction = when { absChange > 0 -> "UP"; absChange < 0 -> "DOWN"; else -> "FLAT" }
        return TrendResult(current, previous, absChange, pct, direction, baselineMissing)
    }

    enum class ExceptionSeverity { INFO, WARNING, CRITICAL }

    /** Section 6 — deterministic alert priority score (0-100), transparent factors only, never a black-box/random score. */
    data class PriorityFactors(val financialImpact: Double = 0.0, val ageDays: Long = 0, val isRepeated: Boolean = false, val severityBase: Int = 50)
    fun computePriorityScore(factors: PriorityFactors): Int {
        var score = factors.severityBase
        score += (factors.financialImpact / 10000).toInt().coerceIn(0, 30)
        score += (factors.ageDays * 2).toInt().coerceIn(0, 20)
        if (factors.isRepeated) score += 15
        return score.coerceIn(0, 100)
    }

    data class RiskItem(val type: String, val evidence: String, val estimatedImpact: Double, val recommendedAction: String, val responsibleOwner: String, val score: Int)
    data class OpportunityItem(val type: String, val evidence: String, val estimatedImpact: Double, val recommendedAction: String, val responsibleOwner: String, val score: Int)
}
