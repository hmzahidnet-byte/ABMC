package com.abm.erp.ui.core

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * Real, self-contained interactive line chart — pure Compose Canvas, no
 * external charting library (avoids any version/API-mismatch risk).
 * Smooth curve with gradient fill under the line, light grid, and
 * tap-to-highlight showing the exact value at that point.
 */
@Composable
fun TrendLineChart(
    values: List<Double>,
    modifier: Modifier = Modifier,
    lineColor: Color = MaterialTheme.colorScheme.primary,
    labelFormatter: (Double) -> String = { "৳${"%,.0f".format(it)}" },
) {
    if (values.size < 2) {
        Box(modifier.height(180.dp), contentAlignment = androidx.compose.ui.Alignment.Center) {
            Text("যথেষ্ট ডেটা নেই চার্ট দেখানোর জন্য", style = MaterialTheme.typography.bodySmall)
        }
        return
    }
    var selectedIndex by remember { mutableStateOf<Int?>(null) }
    val maxVal = values.max().coerceAtLeast(0.01)
    val minVal = values.min().coerceAtMost(0.0)
    val range = (maxVal - minVal).coerceAtLeast(0.01)

    Column(modifier) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .pointerInput(values) {
                    detectTapGestures { offset ->
                        val stepX = size.width / (values.size - 1).coerceAtLeast(1)
                        selectedIndex = (offset.x / stepX).roundToInt().coerceIn(0, values.size - 1)
                    }
                },
        ) {
            val w = size.width
            val h = size.height
            val stepX = w / (values.size - 1).coerceAtLeast(1)

            // Light horizontal grid — 4 lines.
            val gridColor = Color.Gray.copy(alpha = 0.15f)
            for (i in 0..4) {
                val y = h * i / 4
                drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
            }

            fun pointFor(i: Int): Offset {
                val x = stepX * i
                val normalized = (values[i] - minVal) / range
                val y = h - (normalized * h).toFloat()
                return Offset(x, y)
            }

            val linePath = Path()
            val fillPath = Path()
            values.indices.forEach { i ->
                val p = pointFor(i)
                if (i == 0) { linePath.moveTo(p.x, p.y); fillPath.moveTo(p.x, h); fillPath.lineTo(p.x, p.y) } else { linePath.lineTo(p.x, p.y); fillPath.lineTo(p.x, p.y) }
            }
            fillPath.lineTo(pointFor(values.size - 1).x, h)
            fillPath.close()

            drawPath(fillPath, brush = Brush.verticalGradient(listOf(lineColor.copy(alpha = 0.35f), lineColor.copy(alpha = 0.02f))))
            drawPath(linePath, color = lineColor, style = Stroke(width = 4f))

            // Data points, highlighting the tapped one.
            values.indices.forEach { i ->
                val p = pointFor(i)
                val isSelected = i == selectedIndex
                drawCircle(color = lineColor, radius = if (isSelected) 7f else 3.5f, center = p)
                if (isSelected) drawCircle(color = Color.White, radius = 3f, center = p)
            }
        }
        selectedIndex?.let { idx ->
            Spacer(Modifier.height(4.dp))
            Text(
                "দিন ${idx + 1}: ${labelFormatter(values[idx])}",
                style = MaterialTheme.typography.labelMedium,
                color = lineColor,
            )
        }
    }
}

/** Simple bar-chart variant, same self-contained Canvas approach — for comparisons (e.g. dealer-vs-dealer, product-vs-product). */
@Composable
fun ComparisonBarChart(
    labels: List<String>,
    values: List<Double>,
    modifier: Modifier = Modifier,
    barColor: Color = MaterialTheme.colorScheme.secondary,
) {
    if (values.isEmpty()) return
    val maxVal = values.max().coerceAtLeast(0.01)
    Canvas(modifier = modifier.fillMaxWidth().height(160.dp)) {
        val barWidth = size.width / values.size
        values.forEachIndexed { i, v ->
            val barHeight = (v / maxVal * size.height).toFloat()
            drawRect(
                color = barColor,
                topLeft = Offset(i * barWidth + barWidth * 0.15f, size.height - barHeight),
                size = androidx.compose.ui.geometry.Size(barWidth * 0.7f, barHeight),
            )
        }
    }
    Row(Modifier.fillMaxWidth()) {
        labels.forEach { label ->
            Text(label.take(6), style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f), fontSize = 9.sp, maxLines = 1)
        }
    }
}
