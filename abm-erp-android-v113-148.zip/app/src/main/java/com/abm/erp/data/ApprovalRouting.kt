package com.abm.erp.data

/**
 * Decision 2 (v113-72) — there is no central Approvals screen any more, so anything
 * that used to link to route "approvals" has to land on the module that actually owns
 * the request instead.
 *
 * v113-77 update: repointed from the legacy suite routes to the new drawer-based
 * mother modules (DMS/RMS/HR), which is where each of these approvals actually lives
 * now (v113-72/74/76). The mapping is not invented: every value below corresponds to
 * a real `raiseApprovalRequest(...)` call site, and every route + drawer key
 * corresponds to a real NavGraph destination and a real `when (key)` branch inside
 * the target module (`?key=` is read by DmsHomeScreen/RmsHomeScreen/HrHomeScreen's
 * own `startKey` argument).
 *
 *   "SalesInvoice"     → DMS · Invoice tab   (discount %, over-limit invoice)
 *   "Expense"          → FMS · (still legacy Expenses screen — FMS has no Expense
 *                         drawer item yet, see PROJECT_STATE v113-76's open items)
 *   "Voucher"          → HRM/Ledger (still legacy — no FMS/Chairman Voucher item yet)
 *   "Payroll"          → HR · Finance (Payroll) tab
 *   "AttendanceRecord" → HR · Attendance tab
 *   ApprovalType.LEAVE → HR · Leave Management tab
 *
 * Anything unrecognised falls back to the Dashboard rather than to a made-up screen —
 * an honest dead-end beats a wrong one.
 */
fun approvalOwnerRoute(entityType: String, type: ApprovalType): String = when (entityType) {
    "SalesInvoice" -> "dms?key=invoice"
    "Expense" -> "fms?key=expense" // v113-82 — FMS now hosts the Expense Workspace
    "Voucher" -> "ledger?tab=2" // no FMS/Chairman drawer item for this yet — legacy screen still correct
    "Payroll" -> "hr_module?key=payroll"
    "AttendanceRecord" -> "hr_module?key=attendance"
    else -> when (type) {
        ApprovalType.LEAVE -> "hr_module?key=leave"
        ApprovalType.EXPENSE -> "fms?key=expense"
        ApprovalType.DISCOUNT -> "dms?key=invoice"
        ApprovalType.OTHER -> "dashboard"
    }
}
