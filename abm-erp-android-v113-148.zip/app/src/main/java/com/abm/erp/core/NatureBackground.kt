package com.abm.erp.core

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.sin

/**
 * The animated nature-scene background — sun, drifting clouds, distant birds,
 * a side-on (landscape, not aerial) stretch of green land with one tree, and
 * animated ocean waves at the bottom. Sales Chain only, per Zahid's explicit
 * scoping — every other screen keeps its normal background. Ported from the
 * JSX/SVG prototype version, rebuilt from scratch with Compose Canvas since
 * Android has no direct CSS/SVG equivalent.
 */
@Composable
fun NatureLandscapeBackground(modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "natureScene")

    val cloudDrift1 by infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(11000, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "cloud1",
    )
    val cloudDrift2 by infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(14000, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "cloud2",
    )
    val birdDrift by infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(4500, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "bird",
    )
    val treeSway by infinite.animateFloat(
        initialValue = -1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(1900, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "tree",
    )
    val sunPulse by infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(2000, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "sun",
    )
    val wavePhase by infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(2500, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "wave1",
    )
    val wavePhase2 by infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(1800, easing = LinearEasing), repeatMode = RepeatMode.Reverse),
        label = "wave2",
    )

    Box(modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // আকাশ
            drawRect(Brush.verticalGradient(listOf(Color(0xFF4FC3F7), Color(0xFF81D4FA), Color(0xFFB3E5FC))))

            // সূর্য — আলোর রশ্মিসহ, আস্তে আস্তে জ্বলজ্বল করবে
            val sunCenter = Offset(w * 0.78f, h * 0.13f)
            val sunPulseScale = 1f + sunPulse * 0.08f
            drawCircle(Color(0xFFFFE066).copy(alpha = 0.25f), radius = 60f * sunPulseScale, center = sunCenter)
            drawCircle(Color(0xFFFFD23F).copy(alpha = 0.35f), radius = 42f * sunPulseScale, center = sunCenter)
            drawCircle(Color(0xFFFFEA70), radius = 28f * sunPulseScale, center = sunCenter)
            drawCircle(Color(0xFFFFF6D5), radius = 24f * sunPulseScale, center = sunCenter)

            // তুলতুলে মেঘ — দুই গুচ্ছ, আস্তে দুলবে
            fun cloud(cx: Float, cy: Float, scale: Float) {
                val parts = listOf(22f to 16f, 28f to 20f, 24f to 17f, 20f to 14f)
                val dx = listOf(-25f, 0f, 25f, -40f)
                parts.forEachIndexed { i, (rx, ry) ->
                    drawOval(Color.White, topLeft = Offset(cx + dx[i] * scale - rx * scale, cy - ry * scale), size = androidx.compose.ui.geometry.Size(rx * 2 * scale, ry * 2 * scale))
                }
            }
            cloud(w * 0.28f + (cloudDrift1 - 0.5f) * 30f, h * 0.11f, 1f)
            cloud(w * 0.62f + (cloudDrift2 - 0.5f) * 24f, h * 0.17f, 0.8f)

            // দূরের পাখি — সাধারণ "M" রেখা, উড়ে বেড়াবে
            fun bird(cx: Float, cy: Float) {
                val path = Path().apply {
                    moveTo(cx - 10f, cy)
                    quadraticBezierTo(cx - 5f, cy - 8f, cx, cy)
                    quadraticBezierTo(cx + 5f, cy - 8f, cx + 10f, cy)
                }
                drawPath(path, Color(0xFF2C3E50), style = Stroke(width = 2.5f))
            }
            bird(w * 0.15f + birdDrift * 60f, h * 0.22f)
            bird(w * 0.45f + birdDrift * 40f, h * 0.19f)

            // বাম পাশে সবুজ জমি — পাশ থেকে দেখা (landscape view), দিগন্ত বরাবর
            val landPath = Path().apply {
                moveTo(0f, h * 0.68f)
                quadraticBezierTo(w * 0.2f, h * 0.62f, w * 0.4f, h * 0.665f)
                quadraticBezierTo(w * 0.65f, h * 0.70f, w, h * 0.68f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(landPath, Color(0xFF4CAF50))

            // গাছ — মাটির উপর সোজা দাঁড়ানো, বাতাসে দুলবে
            val treeBaseX = w * 0.16f
            val treeBaseY = h * 0.655f
            val swayAngleRad = treeSway * 0.07f
            drawRect(Color(0xFF7A4B26), topLeft = Offset(treeBaseX - 6f, treeBaseY - 60f), size = androidx.compose.ui.geometry.Size(12f, 60f))
            val canopyCx: Float = treeBaseX + sin(swayAngleRad).toFloat() * 40f
            val canopyCy: Float = treeBaseY - 100f
            drawCircle(Color(0xFF1FA33D), radius = 46f, center = Offset(canopyCx, canopyCy))
            drawCircle(Color(0xFF3FCB5E).copy(alpha = 0.9f), radius = 26f, center = Offset(canopyCx - 22f, canopyCy + 12f))
            drawCircle(Color(0xFF57D873).copy(alpha = 0.85f), radius = 24f, center = Offset(canopyCx + 20f, canopyCy - 18f))

            // সমুদ্র — নিচে, উজ্জ্বল নীল, একাধিক স্তরের নড়াচড়া করা ঢেউ
            fun wavePath(baseY: Float, amplitude: Float, phase: Float): Path = Path().apply {
                moveTo(0f, baseY)
                val step = w / 8f
                for (i in 0..8) {
                    val x = i * step
                    val y = baseY + sin((i * 0.9f) + phase * 2 * Math.PI.toFloat()).toFloat() * amplitude
                    if (i == 0) moveTo(x, y) else lineTo(x, y)
                }
                lineTo(w, h); lineTo(0f, h); close()
            }
            drawPath(wavePath(h * 0.80f, 6f, 0f), Color(0xFF0088CC))
            drawPath(wavePath(h * 0.855f, 8f, wavePhase), Color(0xFF00A8E8))
            drawPath(wavePath(h * 0.905f, 7f, wavePhase2), Color(0xFF00C2E8).copy(alpha = 0.9f))
        }
    }
}
