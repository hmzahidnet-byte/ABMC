package com.abm.erp.ui.production

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.abm.erp.data.*
import com.abm.erp.core.BackToSubMenuLink
import com.abm.erp.core.SubModuleGrid
import com.abm.erp.core.SubModuleItem
import com.abm.erp.theme.*
import kotlinx.coroutines.launch

@Composable
fun ProductionWarehouseScreen(startTab: Int? = null, onBack: () -> Unit = {}, onNavigate: (String) -> Unit = {}) {
    var tab by remember { mutableStateOf<Int?>(startTab) }
    val subItems = listOf(
        SubModuleItem("plans", "Production Plans", "🏭", 0xFFE85D4A, 0xFFC03A2B, Icons.Filled.Factory),
        SubModuleItem("transfers", "Warehouse Transfers", "🚚", 0xFF475569, 0xFF1E293B, Icons.Filled.LocalShipping),
    )

    // ---- Mini-dashboard data (Enterprise Workspace redesign) ----
    val stockLevelsForMini by InventoryRepository.stockLevels.collectAsState()
    val transfersForMini by MockRepository.warehouseTransfers.collectAsState()
    val availableStock = stockLevelsForMini.filter { it.stockCategory == StockCategory.STORE }.sumOf { it.quantityOnHand }
    val reservedStock = stockLevelsForMini.sumOf { it.reservedQty }
    val transitStock = stockLevelsForMini.filter { it.stockCategory == StockCategory.IN_TRANSIT }.sumOf { it.quantityOnHand }
    val damagedStock = stockLevelsForMini.filter { it.stockCategory == StockCategory.DAMAGED_HOLD_RETURNED }.sumOf { it.quantityOnHand }
    val pendingReceive = transfersForMini.count { it.status == TransferStatus.DISPATCHED || it.status == TransferStatus.PARTIALLY_RECEIVED }

    Column(Modifier.fillMaxSize()) {
        if (startTab == null) {
        com.abm.erp.core.ModuleWorkspaceHeader("Warehouse Management System", "🚚", 0xFF475569, 0xFF1E293B, iconVector = Icons.Filled.Warehouse, miniDashboard = {
            com.abm.erp.core.ModuleStat("Available Stock", "%.0f".format(availableStock), SuccessGreen)
            com.abm.erp.core.ModuleStat("Reserved", "%.0f".format(reservedStock), WarningAmber)
            com.abm.erp.core.ModuleStat("Transit", "%.0f".format(transitStock), TextPrimary)
            com.abm.erp.core.ModuleStat("Damaged", "%.0f".format(damagedStock), if (damagedStock > 0) DangerRed else SuccessGreen)
            com.abm.erp.core.ModuleStat("Pending Receive", "$pendingReceive", if (pendingReceive > 0) WarningAmber else SuccessGreen) { tab = 1 }
        }, quickActions = {
            AssistChip(onClick = { tab = 1 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.MoveToInbox, null, Modifier.size(16.dp)) }, label = { Text("Receive") })
            AssistChip(onClick = { tab = 1 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.LocalShipping, null, Modifier.size(16.dp)) }, label = { Text("Transfer") })
            AssistChip(onClick = { onNavigate("inventory") }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.Calculate, null, Modifier.size(16.dp)) }, label = { Text("Count") })
            AssistChip(onClick = { onNavigate("inventory") }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.Warning, null, Modifier.size(16.dp)) }, label = { Text("Damage") })
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("WarehouseTransfer", "ProductionPlan", "StockAdjustment", "DamageReport"))
        })
        } else {
            com.abm.erp.core.TaskHeader(if (tab == 0) "Production Plans" else "Warehouse Transfers", 0xFF475569, 0xFF1E293B, onBack = onBack, iconVector = Icons.Filled.Warehouse)
        }
        Column(Modifier.fillMaxSize().padding(12.dp)) {
        if (tab == null) {
            SubModuleGrid(subItems) { key -> tab = when (key) { "plans" -> 0; else -> 1 } }
        } else {
            if (startTab == null) BackToSubMenuLink(onClick = { tab = null })
            if (tab == 0) ProductionPlansTab() else WarehouseTransfersTab()
        }
        }
    }
}

@Composable
private fun ProductionPlansTab() {
    val scope = rememberCoroutineScope()
    val plans by MockRepository.productionPlans.collectAsState()
    val inspections by MockRepository.qualityInspections.collectAsState()
    var showCreate by remember { mutableStateOf(false) }
    var selectedPlanId by remember { mutableStateOf<String?>(null) }
    var statusFilter by remember { mutableStateOf<ProductionPlanStatus?>(null) }
    val filteredPlans = plans.filter { statusFilter == null || it.status == statusFilter }.sortedByDescending { it.createdAt }

    Spacer(Modifier.height(8.dp))
    Button(onClick = { showCreate = true }) { Text("+ New Production Plan") }
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(selected = statusFilter == null, onClick = { statusFilter = null }, label = { Text("সব") })
        ProductionPlanStatus.values().forEach { s ->
            FilterChip(selected = statusFilter == s, onClick = { statusFilter = s }, label = { Text(s.name) })
        }
    }
    Spacer(Modifier.height(8.dp))
    if (filteredPlans.isEmpty()) {
        com.abm.erp.core.WorkspaceEmptyState("কোনো Production Plan পাওয়া যায়নি।", "🏭")
    }
    LazyColumn {
        items(filteredPlans) { p ->
            val latestQc = inspections.filter { it.productionPlanId == p.id }.maxByOrNull { it.createdAt }
            Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), tonalElevation = 2.dp) {
                Column(Modifier.padding(10.dp)) {
                    Text("${p.batchNumber} — ${p.productId}", style = MaterialTheme.typography.titleSmall)
                    Text("Planned: ${p.plannedQuantity} ${p.unit} · Status: ${p.status}", style = MaterialTheme.typography.bodySmall)
                    Text("Line: ${p.productionLine ?: "-"} · Shift: ${p.shiftType} · Date: ${p.productionDate}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    com.abm.erp.core.RecordQrButton(
                        code = p.batchNumber.ifBlank { p.id },
                                entityType = "ProductionBatch", entityId = p.id,
                        title = "Production Batch",
                        subtitle = "${p.productId} · ${p.plannedQuantity} ${p.unit}",
                    )
                    if (latestQc != null) {
                        Text("QC: ${latestQc.result} (by ${latestQc.inspector})", style = MaterialTheme.typography.labelSmall, color = if (latestQc.isSellable) SuccessGreen else DangerRed)
                    }
                    val ppContext = androidx.compose.ui.platform.LocalContext.current
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                        when (p.status) {
                            ProductionPlanStatus.DRAFT -> Button(onClick = { MockRepository.approveProductionPlan(p.id, onRejected = { r -> android.widget.Toast.makeText(ppContext, r, android.widget.Toast.LENGTH_LONG).show() }) }) { Text("Approve") }
                            ProductionPlanStatus.APPROVED, ProductionPlanStatus.IN_PRODUCTION -> {
                                TextButton(onClick = { selectedPlanId = p.id }) { Text("Manage") }
                            }
                            else -> {}
                        }
                    }
                }
            }
        }
    }

    if (showCreate) {
        var productId by remember { mutableStateOf("") }
        var plannedQuantity by remember { mutableStateOf("") }
        var unit by remember { mutableStateOf("kg") }
        var manufacturingUnitId by remember { mutableStateOf("") }
        var productionLine by remember { mutableStateOf("") }
        var shiftType by remember { mutableStateOf(ShiftType.GENERAL) }
        var isSubmitting by remember { mutableStateOf(false) }
        Dialog(onDismissRequest = { showCreate = false }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(modifier = Modifier.fillMaxSize(), color = com.abm.erp.theme.DashBg) {
                Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("New Production Plan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { showCreate = false }) { Text("✕ Close") }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = productId, onValueChange = { productId = it }, label = { Text("Product ID") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = plannedQuantity, onValueChange = { plannedQuantity = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Planned Qty") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text("Unit") }, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = manufacturingUnitId, onValueChange = { manufacturingUnitId = it }, label = { Text("Manufacturing Unit") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = productionLine, onValueChange = { productionLine = it }, label = { Text("Production Line") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        ShiftType.values().forEach { s -> FilterChip(selected = shiftType == s, onClick = { shiftType = s }, label = { Text(s.name, style = MaterialTheme.typography.labelSmall) }) }
                    }
                    var planError by remember { mutableStateOf<String?>(null) }
                    planError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            if (isSubmitting) return@Button
                            isSubmitting = true
                            scope.launch {
                                val created = MockRepository.createProductionPlan(productId, null, plannedQuantity.toDoubleOrNull() ?: 0.0, unit, manufacturingUnitId, productionLine.ifBlank { null }, shiftType, null, java.time.LocalDate.now(), onRejected = { r -> planError = r })
                                isSubmitting = false
                                if (created != null) showCreate = false
                            }
                        },
                        enabled = !isSubmitting,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Create Plan") }
                }
            }
        }
    }

    selectedPlanId?.let { planId ->
        val plan = plans.firstOrNull { it.id == planId }
        if (plan != null) {
            var materialProductId by remember { mutableStateOf("") }
            var materialWarehouseId by remember { mutableStateOf("") }
            var issueQty by remember { mutableStateOf("") }
            var qcInspector by remember { mutableStateOf("") }
            var qcResult by remember { mutableStateOf(QcResult.PENDING) }
            var bulkQty by remember { mutableStateOf("") }
            var packSize by remember { mutableStateOf("") }
            var numPacks by remember { mutableStateOf("") }
            var fgBatchCode by remember { mutableStateOf("") }
            var fgWarehouseId by remember { mutableStateOf("") }
            var opError by remember { mutableStateOf<String?>(null) }
            Dialog(onDismissRequest = { selectedPlanId = null }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp).heightIn(max = 600.dp).verticalScroll(rememberScrollState())) {
                        Text("Manage — ${plan.batchNumber}", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(10.dp))
                        Text("১. Raw Material Issue", style = MaterialTheme.typography.labelLarge)
                        OutlinedTextField(value = materialProductId, onValueChange = { materialProductId = it }, label = { Text("Material Product ID") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(value = materialWarehouseId, onValueChange = { materialWarehouseId = it }, label = { Text("Warehouse ID") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = issueQty, onValueChange = { issueQty = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Qty") }, modifier = Modifier.weight(1f))
                        }
                        Button(onClick = {
                            scope.launch {
                                val ok = MockRepository.issueRawMaterial(plan.id, materialProductId, materialWarehouseId, issueQty.toDoubleOrNull() ?: 0.0, onRejected = { r -> opError = r })
                                if (ok) opError = null
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Issue Material") }

                        Spacer(Modifier.height(14.dp))
                        Text("২. Quality Inspection", style = MaterialTheme.typography.labelLarge)
                        OutlinedTextField(value = qcInspector, onValueChange = { qcInspector = it }, label = { Text("Inspector") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            QcResult.values().forEach { r -> FilterChip(selected = qcResult == r, onClick = { qcResult = r }, label = { Text(r.name.take(8), style = MaterialTheme.typography.labelSmall) }) }
                        }
                        var qcError by remember { mutableStateOf<String?>(null) }
                        qcError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                        Button(onClick = { MockRepository.recordQualityInspection(plan.id, null, null, qcInspector, null, qcResult, 0.0, 0.0, null, onRejected = { r -> qcError = r }) }, modifier = Modifier.fillMaxWidth()) { Text("Record QC") }

                        Spacer(Modifier.height(14.dp))
                        Text("৩. Packing", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(value = bulkQty, onValueChange = { bulkQty = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Bulk Qty") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = packSize, onValueChange = { packSize = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Pack Size") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = numPacks, onValueChange = { numPacks = it.filter(Char::isDigit) }, label = { Text("# Packs") }, modifier = Modifier.weight(1f))
                        }
                        Button(onClick = {
                            MockRepository.recordPacking(plan.id, bulkQty.toDoubleOrNull() ?: 0.0, packSize.toDoubleOrNull() ?: 0.0, numPacks.toIntOrNull() ?: 0, 0, 0.0, 0, 0.0, onRejected = { r -> opError = r })
                        }, modifier = Modifier.fillMaxWidth()) { Text("Record Packing") }

                        var showCartonBarcodes by remember { mutableStateOf(false) }
                        TextButton(onClick = { showCartonBarcodes = !showCartonBarcodes }) { Text(if (showCartonBarcodes) "Hide Carton Barcodes" else "🏷️ Generate Carton Barcodes") }
                        if (showCartonBarcodes) {
                            val cartonCount = (numPacks.toIntOrNull() ?: 0).coerceAtMost(10)
                            Column {
                                (1..cartonCount).forEach { seq ->
                                    val code = com.abm.erp.util.QrCodeGenerator.cartonCode(plan.batchNumber, seq)
                                    val barcodeBitmap = remember(code) { com.abm.erp.util.QrCodeGenerator.generateBarcode(code) }
                                    Column(Modifier.padding(vertical = 4.dp)) {
                                        Image(bitmap = barcodeBitmap.asImageBitmap(), contentDescription = code, modifier = Modifier.fillMaxWidth().height(60.dp))
                                        Text(code, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                    }
                                }
                                if ((numPacks.toIntOrNull() ?: 0) > 10) Text("... এবং আরও ${(numPacks.toIntOrNull() ?: 0) - 10}টা (প্রথম ১০টা দেখানো হয়েছে)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }

                        Spacer(Modifier.height(14.dp))
                        Text("৪. Finished Goods Confirmation", style = MaterialTheme.typography.labelLarge)
                        OutlinedTextField(value = fgBatchCode, onValueChange = { fgBatchCode = it }, label = { Text("Batch Code") }, modifier = Modifier.fillMaxWidth())
                        Text("Destination Warehouse (শুধু factory-side, saleable warehouse না)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        val warehouses by com.abm.erp.data.InventoryRepository.warehouses.collectAsState()
                        val factoryWarehouses = warehouses.filter { it.stockCategory == com.abm.erp.data.StockCategory.PRODUCTION }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            factoryWarehouses.forEach { w ->
                                FilterChip(selected = fgWarehouseId == w.id, onClick = { fgWarehouseId = w.id }, label = { Text(w.name, style = MaterialTheme.typography.labelSmall) })
                            }
                        }
                        opError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                        Button(onClick = {
                            scope.launch {
                                val r = MockRepository.confirmFinishedGoods(plan.id, plan.productId, fgBatchCode, java.time.LocalDate.now(), null, plan.plannedQuantity, plan.unit, fgWarehouseId, 0.0, onRejected = { e -> opError = e })
                                if (r != null) selectedPlanId = null
                            }
                        }, modifier = Modifier.fillMaxWidth(), enabled = fgWarehouseId.isNotBlank()) { Text("Confirm Finished Goods") }
                    }
                }
            }
        }
    }
}

@Composable
private fun WarehouseTransfersTab() {
    val scope = rememberCoroutineScope()
    val transfers by MockRepository.warehouseTransfers.collectAsState()
    var showCreate by remember { mutableStateOf(false) }
    var receivingId by remember { mutableStateOf<String?>(null) }
    var statusFilter by remember { mutableStateOf<TransferStatus?>(null) }

    Spacer(Modifier.height(8.dp))
    Button(onClick = { showCreate = true }) { Text("+ New Transfer Request") }
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(selected = statusFilter == null, onClick = { statusFilter = null }, label = { Text("সব") })
        listOf(TransferStatus.DISPATCHED, TransferStatus.PARTIALLY_RECEIVED, TransferStatus.RECEIVED, TransferStatus.APPROVED).forEach { s ->
            FilterChip(selected = statusFilter == s, onClick = { statusFilter = s }, label = { Text(s.name) })
        }
    }
    Spacer(Modifier.height(8.dp))
    val filteredTransfers = transfers.filter { statusFilter == null || it.status == statusFilter }.sortedByDescending { it.createdAt }
    if (filteredTransfers.isEmpty()) {
        com.abm.erp.core.WorkspaceEmptyState("কোনো ওয়্যারহাউস ট্রান্সফার পাওয়া যায়নি।", "🚚")
    }
    LazyColumn {
        items(filteredTransfers) { t ->
            Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), tonalElevation = 2.dp) {
                Column(Modifier.padding(10.dp)) {
                    Text("${t.transferNumber}: ${t.sourceWarehouseId} → ${t.destinationWarehouseId}", style = MaterialTheme.typography.titleSmall)
                    Text("Status: ${t.status} · ${t.lines.size} line(s)${t.dispatchChallanNumber?.let { " · Challan: $it" } ?: ""}", style = MaterialTheme.typography.bodySmall)
                    if (t.hasDiscrepancy) Text("⚠ Discrepancy detected", style = MaterialTheme.typography.labelSmall, color = DangerRed)
                    com.abm.erp.core.RecordQrButton(
                        code = t.transferNumber.ifBlank { t.id },
                                entityType = "WarehouseTransfer", entityId = t.id,
                        title = "Warehouse Transfer",
                        subtitle = "${t.sourceWarehouseId} → ${t.destinationWarehouseId}",
                    )
                    val wtContext = androidx.compose.ui.platform.LocalContext.current
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                        when (t.status) {
                            TransferStatus.DRAFT, TransferStatus.SUBMITTED -> Button(onClick = { MockRepository.approveWarehouseTransfer(t.id, onRejected = { r -> android.widget.Toast.makeText(wtContext, r, android.widget.Toast.LENGTH_LONG).show() }) }) { Text("Approve") }
                            TransferStatus.APPROVED -> Button(onClick = { scope.launch { MockRepository.dispatchWarehouseTransfer(t.id, null, null, onRejected = { e -> android.widget.Toast.makeText(wtContext, e, android.widget.Toast.LENGTH_LONG).show() }) } }) { Text("Dispatch") }
                            TransferStatus.DISPATCHED, TransferStatus.PARTIALLY_RECEIVED -> TextButton(onClick = { receivingId = t.id }) { Text("Receive") }
                            else -> {}
                        }
                    }
                }
            }
        }
    }

    if (showCreate) {
        var source by remember { mutableStateOf("") }
        var dest by remember { mutableStateOf("") }
        var productId by remember { mutableStateOf("") }
        var qty by remember { mutableStateOf("") }
        Dialog(onDismissRequest = { showCreate = false }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(modifier = Modifier.fillMaxSize(), color = com.abm.erp.theme.DashBg) {
                Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("New Warehouse Transfer", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { showCreate = false }) { Text("✕ Close") }
                    }
                    OutlinedTextField(value = source, onValueChange = { source = it }, label = { Text("Source Warehouse") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = dest, onValueChange = { dest = it }, label = { Text("Destination Warehouse") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = productId, onValueChange = { productId = it }, label = { Text("Product ID") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = qty, onValueChange = { qty = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Quantity") }, modifier = Modifier.fillMaxWidth())
                    val wtCreateContext = androidx.compose.ui.platform.LocalContext.current
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            // transferId is not yet known here — createWarehouseTransferRequest generates the real
                            // transfer id and stamps it onto every line before the transfer is ever persisted.
                            val line = WarehouseTransferLine(id = "L-${java.util.UUID.randomUUID().toString().take(6)}", transferId = "", productId = productId, quantity = qty.toDoubleOrNull() ?: 0.0)
                            scope.launch {
                                val created = MockRepository.createWarehouseTransferRequest(source, dest, listOf(line), null, null, null, null, onRejected = { r -> android.widget.Toast.makeText(wtCreateContext, r, android.widget.Toast.LENGTH_LONG).show() })
                                if (created != null) showCreate = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Submit Request") }
                }
            }
        }
    }

    receivingId?.let { transferId ->
        val transfer = transfers.firstOrNull { it.id == transferId }
        if (transfer != null) {
            var receiver by remember { mutableStateOf("") }
            var acceptedByLine by remember { mutableStateOf(transfer.lines.associate { it.id to it.quantity.toString() }) }
            var damagedByLine by remember { mutableStateOf(transfer.lines.associate { it.id to "0" }) }
            Dialog(onDismissRequest = { receivingId = null }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp).heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
                        Text("Receive — ${transfer.transferNumber}", style = MaterialTheme.typography.titleMedium)
                        val receiveContext = androidx.compose.ui.platform.LocalContext.current
                        OutlinedTextField(value = receiver, onValueChange = { receiver = it }, label = { Text("Receiver name") }, modifier = Modifier.fillMaxWidth())
                        transfer.lines.forEach { line ->
                            Spacer(Modifier.height(6.dp))
                            Text("${line.productId} (dispatched: ${line.dispatchedQuantity})", style = MaterialTheme.typography.labelSmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedTextField(value = acceptedByLine[line.id] ?: "", onValueChange = { acceptedByLine = acceptedByLine + (line.id to it) }, label = { Text("Accepted") }, modifier = Modifier.weight(1f))
                                OutlinedTextField(value = damagedByLine[line.id] ?: "", onValueChange = { damagedByLine = damagedByLine + (line.id to it) }, label = { Text("Damaged") }, modifier = Modifier.weight(1f))
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = {
                                scope.launch {
                                    val receivedLines = transfer.lines.map { line ->
                                        val accepted = acceptedByLine[line.id]?.toDoubleOrNull() ?: 0.0
                                        val damaged = damagedByLine[line.id]?.toDoubleOrNull() ?: 0.0
                                        val missing = (line.dispatchedQuantity - accepted - damaged).coerceAtLeast(0.0)
                                        line.copy(receivedQuantity = accepted + damaged, acceptedQuantity = accepted, damagedQuantity = damaged, missingQuantity = missing)
                                    }
                                    MockRepository.receiveWarehouseTransfer(transfer.id, receivedLines, receiver, null, null, null, onRejected = { r -> android.widget.Toast.makeText(receiveContext, r, android.widget.Toast.LENGTH_LONG).show() })
                                    receivingId = null
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Confirm Receipt") }
                    }
                }
            }
        }
    }
}
