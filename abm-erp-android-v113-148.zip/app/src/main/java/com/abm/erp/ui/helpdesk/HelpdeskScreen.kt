package com.abm.erp.ui.helpdesk

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.FirebaseSync
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Every staff role has this in BASE access — a dealer's or retailer's
 * problem should be visible to whoever's covering that territory, not
 * gated to a senior tier. Distinct from Complaint Box, which is internal
 * (staff-to-Chairman).
 */
@Composable
fun HelpdeskScreen() {
    val tickets by FirebaseSync.helpdeskTickets.collectAsState()
    val formatter = remember { SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()) }
    val open = tickets.filter { it.status == "Open" }
    val resolved = tickets.filter { it.status != "Open" }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            com.abm.erp.core.ModuleWorkspaceHeader("Helpdesk", "🎧", 0xFF4E9CFF, 0xFF2E6FE0, iconVector = Icons.Filled.SupportAgent, miniDashboard = {
                com.abm.erp.core.ModuleStat("Open", "${open.size}", if (open.isNotEmpty()) WarningAmber else SuccessGreen)
                com.abm.erp.core.ModuleStat("Resolved", "${resolved.size}", SuccessGreen)
                com.abm.erp.core.ModuleStat("Total", "${tickets.size}", TextPrimary)
            }, recentActivity = {
                com.abm.erp.core.ModuleRecentActivity(setOf("HelpdeskTicket", "Ticket"))
            })
        }
        item {
            Text(
                "Support tickets raised by dealers and retailers.",
                style = MaterialTheme.typography.bodySmall, color = TextSecondary,
            )
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                val context = androidx.compose.ui.platform.LocalContext.current
                com.abm.erp.core.ModuleActionBar(
                    onExport = {
                        val header = "Subject,From,Type,Status\n"
                        val rows = tickets.joinToString("\n") { t -> com.abm.erp.core.toCsvRow(t.subject, t.fromName, t.fromType, t.status) }
                        val file = java.io.File(context.getExternalFilesDir(null), "helpdesk_tickets_${System.currentTimeMillis()}.csv")
                        file.writeText(header + rows)
                        android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                    },
                    onShare = {
                        val summary = "Helpdesk Tickets (${tickets.size})\n" + tickets.take(20).joinToString("\n") { "${it.subject} — ${it.fromName} (${it.status})" }
                        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                        try { context.startActivity(android.content.Intent.createChooser(intent, "Helpdesk Tickets")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                    },
                )
            }
        }

        item { Text("Open (${open.size})", style = MaterialTheme.typography.titleMedium, color = WarningAmber) }
        items(open, key = { it.id }) { ticket ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(ticket.subject, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(ticket.fromType, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    com.abm.erp.core.UniversalActionMenu(
                        moduleReference = "HelpdeskTicket", entityId = ticket.id, entityLabel = ticket.subject,
                        shareText = "Ticket: ${ticket.subject}\nFrom: ${ticket.fromName} (${ticket.fromType})\n${ticket.message}",
                        csvHeader = "Subject,From,Type,Status", csvRow = com.abm.erp.core.toCsvRow(ticket.subject, ticket.fromName, ticket.fromType, ticket.status),
                    )
                }
                Text(ticket.fromName, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Spacer(Modifier.height(4.dp))
                Text(ticket.message, style = MaterialTheme.typography.bodyMedium)
                Text(formatter.format(Date(ticket.createdAtMillis)), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { FirebaseSync.setHelpdeskTicketStatus(ticket.id, "Resolved") }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) {
                    Text("Mark resolved")
                }
            }
        }
        if (open.isEmpty()) {
            item { Text("No open tickets — all caught up.", color = TextSecondary) }
        }

        if (resolved.isNotEmpty()) {
            item { Spacer(Modifier.height(6.dp)); Text("Resolved", style = MaterialTheme.typography.titleMedium) }
            items(resolved, key = { it.id }) { ticket ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(ticket.subject, color = TextPrimary)
                        Text("Resolved", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                    }
                    Text(ticket.fromName, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }
    }
}
