package com.abm.erp.ui.ledger

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.Space
import com.abm.erp.data.MockRepository
import com.abm.erp.data.PartyLedgerEntry
import com.abm.erp.data.PartyType
import com.abm.erp.theme.*
import java.time.LocalDate

/**
 * Party Statement — a dealer/retailer ledger presented the way a bank statement is.
 *
 * The important property of a statement is that every line shows the balance *after* that
 * transaction, so a reader can follow how the account moved. `PartyLedgerEntry.balanceAfter`
 * already stores exactly that, posted at the time of the transaction — so this screen reads
 * the real running balance rather than recomputing one, which means the statement can never
 * disagree with what was posted.
 *
 * Opening balance is derived as "closing balance of the entry immediately before the range",
 * again from stored values, not recalculated from scratch.
 *
 * **Visibility follows the existing cascade.** The screen refuses to open a party the current
 * user is not entitled to see, using the same `visibleDealerIds` / `visibleRetailerIds` the
 * rest of the app uses — a direct link or a search result cannot be used to reach a dealer
 * outside your territory.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PartyStatementScreen(partyType: String, partyId: String, onBack: () -> Unit) {
    val type = runCatching { PartyType.valueOf(partyType) }.getOrNull() ?: PartyType.DEALER
    val context = LocalContext.current
    val company = remember { MockRepository.companySettings() }

    val dealers by MockRepository.dealers.collectAsState()
    val retailers by MockRepository.retailers.collectAsState()
    val profiles by MockRepository.employeeProfiles.collectAsState()

    // ---- cascade check, before anything is rendered ----
    val myProfileId = remember(profiles) {
        profiles.firstOrNull { it.userAccountId == MockRepository.currentUser.id }?.id
    }
    val allowed = remember(myProfileId, partyId, type) {
        when {
            myProfileId == null -> true // no profile mapping (e.g. Chairman demo account) — module permission still applies
            type == PartyType.DEALER -> MockRepository.visibleDealerIds(myProfileId).contains(partyId)
            else -> MockRepository.visibleRetailerIds(myProfileId).contains(partyId)
        }
    }

    val partyName = when (type) {
        PartyType.DEALER -> dealers.firstOrNull { it.id == partyId }?.name
        else -> retailers.firstOrNull { it.id == partyId }?.name
    } ?: partyId

    if (!allowed) {
        Column(Modifier.fillMaxSize().padding(Space.xl), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(70.dp))
            com.abm.erp.core.WorkspaceEmptyState(
                "এই পার্টির লেজার আপনার এলাকার আওতায় নেই।",
                iconVector = Icons.Filled.Lock,
            )
            Spacer(Modifier.height(Space.lg))
            com.abm.erp.core.SecondaryButton("← ফিরে যান", onClick = onBack)
        }
        return
    }

    val allEntries by remember(partyId, type) { MockRepository.partyLedgerFor(type, partyId) }
        .collectAsState(initial = emptyList())

    // ---- date range: quick chips, with a calendar for Custom ----
    var rangeMode by remember { mutableStateOf(0) } // 0=This Month 1=Last Month 2=3 Months 3=Custom
    var customFrom by remember { mutableStateOf<LocalDate?>(null) }
    var customTo by remember { mutableStateOf<LocalDate?>(null) }
    var pickerFor by remember { mutableStateOf<String?>(null) } // "from" | "to"

    val today = LocalDate.now()
    val (fromDate, toDate) = when (rangeMode) {
        0 -> today.withDayOfMonth(1) to today
        1 -> today.minusMonths(1).withDayOfMonth(1) to today.withDayOfMonth(1).minusDays(1)
        2 -> today.minusMonths(3).withDayOfMonth(1) to today
        else -> (customFrom ?: today.withDayOfMonth(1)) to (customTo ?: today)
    }

    val inRange = remember(allEntries, fromDate, toDate) {
        allEntries.filter { val d = it.createdAt.toLocalDate(); !d.isBefore(fromDate) && !d.isAfter(toDate) }
            .sortedBy { it.createdAt }
    }
    // Opening = the balance recorded by the last entry *before* this window.
    val opening = remember(allEntries, fromDate) {
        allEntries.filter { it.createdAt.toLocalDate().isBefore(fromDate) }
            .maxByOrNull { it.createdAt }?.balanceAfter ?: 0.0
    }
    val closing = inRange.lastOrNull()?.balanceAfter ?: opening
    val totalDebit = inRange.filter { it.type == "DEBIT" }.sumOf { it.amount }
    val totalCredit = inRange.filter { it.type == "CREDIT" }.sumOf { it.amount }

    Column(Modifier.fillMaxSize().background(DashBg)) {

        // ── header ──
        Column(
            Modifier.fillMaxWidth()
                .background(Brush.linearGradient(listOf(Color(0xFF12C2A9), Color(0xFF0E9F8B))))
                .padding(horizontal = Space.md, vertical = 12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text("Party Statement", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(partyName, color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                }
                com.abm.erp.core.UniversalActionMenu(
                    moduleReference = "PartyLedger",
                    entityId = partyId,
                    entityLabel = "$partyName statement",
                    shareText = buildStatementText(company.companyName, partyName, fromDate, toDate, opening, inRange, totalDebit, totalCredit, closing),
                    csvHeader = "Date,Particulars,Reference,Debit,Credit,Balance",
                    csvRow = inRange.joinToString("\n") { e ->
                        com.abm.erp.core.toCsvRow(
                            e.createdAt.toLocalDate(), e.reason, e.referenceId,
                            if (e.type == "DEBIT") e.amount else 0.0,
                            if (e.type == "CREDIT") e.amount else 0.0,
                            e.balanceAfter,
                        )
                    },
                )
            }
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(Space.md)) {

            // ── date range ──
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                listOf("This Month", "Last Month", "3 Months", "Custom").forEachIndexed { i, label ->
                    FilterChip(
                        selected = rangeMode == i,
                        onClick = { rangeMode = i; if (i == 3 && customFrom == null) pickerFor = "from" },
                        label = { Text(label, fontSize = 11.sp) },
                    )
                }
            }
            if (rangeMode == 3) {
                Spacer(Modifier.height(Space.sm))
                Row(horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
                    Box(Modifier.weight(1f)) {
                        com.abm.erp.core.SecondaryButton(
                            "From: ${customFrom ?: "—"}",
                            onClick = { pickerFor = "from" },
                            icon = Icons.Filled.CalendarMonth,
                        )
                    }
                    Box(Modifier.weight(1f)) {
                        com.abm.erp.core.SecondaryButton(
                            "To: ${customTo ?: "—"}",
                            onClick = { pickerFor = "to" },
                            icon = Icons.Filled.CalendarMonth,
                        )
                    }
                }
            }

            Spacer(Modifier.height(Space.md))

            // ── opening balance ──
            com.abm.erp.core.PremiumCard(padding = Space.md) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Opening Balance", fontSize = 10.sp, color = TextSecondary)
                        Text("$fromDate → $toDate", fontSize = 9.sp, color = TextSecondary)
                    }
                    Text(
                        "৳${"%,.0f".format(opening)}",
                        fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary,
                    )
                }
            }

            Spacer(Modifier.height(Space.md))

            // ── statement table ──
            Row(
                Modifier.fillMaxWidth()
                    .background(Color(0xFF1B2430), RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
                    .padding(horizontal = Space.sm, vertical = 8.dp),
            ) {
                StHead("Date", 0.20f); StHead("Particulars", 0.34f)
                StHead("Debit", 0.15f, TextAlign.End); StHead("Credit", 0.15f, TextAlign.End)
                StHead("Balance", 0.16f, TextAlign.End)
            }

            if (inRange.isEmpty()) {
                com.abm.erp.core.WorkspaceEmptyState(
                    "এই সময়ের মধ্যে কোনো লেনদেন নেই।",
                    iconVector = Icons.Filled.ReceiptLong,
                )
            }

            inRange.forEachIndexed { i, e ->
                Row(
                    Modifier.fillMaxWidth()
                        .background(if (i % 2 == 1) Color(0xFFF7F8FA) else Color.White)
                        .padding(horizontal = Space.sm, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    StCell(e.createdAt.toLocalDate().toString().takeLast(5), 0.20f)
                    Column(Modifier.weight(0.34f)) {
                        Text(e.reason, fontSize = 10.5.sp, color = TextPrimary, maxLines = 1)
                        if (e.referenceId.isNotBlank()) {
                            Text(e.referenceId.take(14), fontSize = 8.sp, color = TextSecondary, maxLines = 1)
                        }
                    }
                    StCell(if (e.type == "DEBIT") "%,.0f".format(e.amount) else "—", 0.15f, TextAlign.End, StatusRed)
                    StCell(if (e.type == "CREDIT") "%,.0f".format(e.amount) else "—", 0.15f, TextAlign.End, StatusGreen)
                    StCell("%,.0f".format(e.balanceAfter), 0.16f, TextAlign.End, TextPrimary, FontWeight.SemiBold)
                }
            }

            Spacer(Modifier.height(Space.md))

            // ── totals ──
            com.abm.erp.core.PremiumCard(padding = Space.md) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Debit", fontSize = 11.sp, color = TextSecondary)
                    Text("৳${"%,.0f".format(totalDebit)}", fontSize = 12.sp, color = StatusRed, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Credit", fontSize = 11.sp, color = TextSecondary)
                    Text("৳${"%,.0f".format(totalCredit)}", fontSize = 12.sp, color = StatusGreen, fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(Modifier.height(Space.sm))
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.horizontalGradient(listOf(DarazOrange, DarazOrangeDark)), RoundedCornerShape(12.dp))
                    .padding(horizontal = Space.md, vertical = 13.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Closing Balance", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("৳${"%,.0f".format(closing)}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(Space.xxl))
        }
    }

    // ── calendar ──
    if (pickerFor != null) {
        val state = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { pickerFor = null },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { ms ->
                        val picked = java.time.Instant.ofEpochMilli(ms).atZone(java.time.ZoneOffset.UTC).toLocalDate()
                        if (pickerFor == "from") customFrom = picked else customTo = picked
                        rangeMode = 3
                    }
                    pickerFor = null
                }) { Text("ঠিক আছে") }
            },
            dismissButton = { TextButton(onClick = { pickerFor = null }) { Text("বাতিল") } },
        ) { DatePicker(state = state) }
    }
}

@Composable private fun RowScope.StHead(t: String, w: Float, align: TextAlign = TextAlign.Start) =
    Text(t, Modifier.weight(w), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = align)

@Composable private fun RowScope.StCell(
    t: String, w: Float, align: TextAlign = TextAlign.Start,
    color: Color = TextPrimary, weight: FontWeight = FontWeight.Normal,
) = Text(t, Modifier.weight(w), color = color, fontSize = 10.5.sp, textAlign = align, fontWeight = weight)

/** Plain-text statement for Share — the same figures the screen shows. */
private fun buildStatementText(
    companyName: String, partyName: String, from: LocalDate, to: LocalDate,
    opening: Double, entries: List<PartyLedgerEntry>, debit: Double, credit: Double, closing: Double,
): String = buildString {
    appendLine(companyName.ifBlank { "ABM ERP" })
    appendLine("Party Statement — $partyName")
    appendLine("Period: $from to $to")
    appendLine("Opening Balance: ${"%,.0f".format(opening)}")
    appendLine("----------------------------------------")
    entries.forEach { e ->
        appendLine(
            "${e.createdAt.toLocalDate()}  ${e.reason.take(22)}  " +
                "${if (e.type == "DEBIT") "Dr" else "Cr"} ${"%,.0f".format(e.amount)}  " +
                "Bal ${"%,.0f".format(e.balanceAfter)}",
        )
    }
    appendLine("----------------------------------------")
    appendLine("Total Debit: ${"%,.0f".format(debit)}")
    appendLine("Total Credit: ${"%,.0f".format(credit)}")
    appendLine("Closing Balance: ${"%,.0f".format(closing)}")
}
