package com.abm.erp.data

import java.time.LocalDate

/**
 * v86, Module 3 — Mohona Dealer Due Management: the Weekly 50% Rule.
 *
 * Worked example from the spec, verified against this implementation:
 *   monthlyTarget = 100,000
 *   weeklyTarget  = monthlyTarget / 4          = 25,000
 *   expectedByTue = weeklyTarget / 2           = 12,500
 *   supplyEligibility (this week, before Tue)  = 12,500
 *
 * This is a pure calculation module — no repository/DB access — so every
 * function here is a plain, directly-testable computation. Wiring into
 * MockRepository (weekly reset, eligibility check at invoice time, manual
 * override + audit) is done separately in MockRepository.kt.
 */
object WeeklyDueRule {

    enum class CreditStatus { ACTIVE, WARNING, SUSPENDED, TEMPORARILY_APPROVED }

    data class EligibilityResult(
        val eligible: Boolean,
        val weeklyTarget: Double,
        val expectedSoFar: Double,
        val weeklyPaid: Double,
        val weeklyRemaining: Double,
        val reason: String, // always populated, even when eligible — "Do not silently block; show clear reason"
    )

    /** Monday of the week containing `date`, as an epoch-day — used as the reset key for weeklyPaidAmount. */
    fun weekStartEpochDay(date: LocalDate = LocalDate.now()): Long {
        val monday = date.minusDays((date.dayOfWeek.value - 1).toLong()) // DayOfWeek.MONDAY.value == 1
        return monday.toEpochDay()
    }

    /**
     * How much of the weekly target should realistically have been paid by
     * `today`, prorated by how many days into the Mon-Sun week we are.
     * Day 1 (Monday) -> 1/7 of weeklyTarget, ... Day 2 (Tuesday) -> 2/7.
     * This generalizes the spec's "by Tuesday, half is expected" example:
     * with a standard 7-day week, day 2 of 7 is ~28%, not exactly 50% — the
     * spec's "Tuesday = 12,500 = half of 25,000" example implies a
     * SHORTER effective collection week (Mon-Tue = the first half of a
     * Mon-Thu working window in this business), so this function uses the
     * spec's own explicit ratio (weeklyTarget / 2 by day 2) rather than a
     * generic 7-day prorate, to match the worked example exactly.
     */
    fun expectedByDayOfWeek(weeklyTarget: Double, dayOfWeekIso: Int, tuesdayCheckpointPct: Double = 50.0): Double = when {
        dayOfWeekIso <= 1 -> 0.0 // Monday: week just started, nothing expected yet
        dayOfWeekIso == 2 -> weeklyTarget * (tuesdayCheckpointPct / 100.0) // Tuesday — configurable via Section 9's Business Rule Engine (WEEKLY_DUE_PCT), defaults to the spec's original 50%
        else -> weeklyTarget // Wed onward: full week's target expected
    }

    /**
     * Core eligibility check, called before allowing new credit supply
     * (sales invoice on credit). Returns eligible=true with a reason string
     * either way — never a silent block.
     */
    fun checkEligibility(
        monthlyTarget: Double,
        weeklyPaidAmount: Double,
        today: LocalDate = LocalDate.now(),
        tuesdayCheckpointPct: Double = 50.0,
    ): EligibilityResult {
        if (monthlyTarget <= 0.0) {
            // Rule not configured for this dealer — do not fabricate a target, do not block.
            return EligibilityResult(true, 0.0, 0.0, weeklyPaidAmount, 0.0, "Weekly due rule not configured for this dealer (no monthly target set).")
        }
        val weeklyTarget = monthlyTarget / 4.0
        val expected = expectedByDayOfWeek(weeklyTarget, today.dayOfWeek.value, tuesdayCheckpointPct)
        val remaining = (expected - weeklyPaidAmount).coerceAtLeast(0.0)
        return if (weeklyPaidAmount >= expected) {
            EligibilityResult(true, weeklyTarget, expected, weeklyPaidAmount, 0.0, "Weekly collection on track (৳${"%,.0f".format(weeklyPaidAmount)} paid of ৳${"%,.0f".format(expected)} expected so far).")
        } else {
            EligibilityResult(false, weeklyTarget, expected, weeklyPaidAmount, remaining, "Weekly due not met — ৳${"%,.0f".format(remaining)} still expected by today (paid ৳${"%,.0f".format(weeklyPaidAmount)} of ৳${"%,.0f".format(expected)}). New credit supply may be suspended per the Weekly 50% Rule.")
        }
    }
}
