package com.abm.erp.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Single authoritative companyId source (Section 2 of the production
 * hardening pass). Before this, each of the 6 repositories
 * (MockRepository, InventoryRepository, PurchaseRepository,
 * AccountsRepository, CrmRepository, CommsRepository) plus FirebaseSync
 * kept its OWN independent `syncCompanyId` variable, each falling back to
 * the literal string "_unset" when unset — this is exactly what produced
 * mismatched Firestore paths like companies/_unset/..., companies/C-1/...
 * (an unrelated hardcoded internal placeholder), and companies/112255/...
 * all appearing for the same logical session.
 *
 * This object is now the ONE place a real companyId gets validated and
 * recorded. Every repository's startCrossDeviceSync(companyId) call
 * should route through [validateAndRecord] rather than trusting whatever
 * string it was handed. UI can observe [current]/[isResolved] to show a
 * real "company not resolved yet" state instead of silently writing to a
 * wrong path.
 */
object CompanyContext {
    private val _current = MutableStateFlow<String?>(null)
    val current: StateFlow<String?> = _current.asStateFlow()

    val isResolved: Boolean get() = !_current.value.isNullOrBlank() && _current.value != "_unset" && _current.value != "C-1"

    /**
     * Validates a candidate companyId before it's allowed to become the
     * app's active company context. Rejects null, blank, "_unset", and
     * the unrelated internal "C-1" placeholder (Company/branch list used
     * for internal multi-branch accounting — never a real tenant id).
     * Returns true only if the value was accepted.
     */
    fun validateAndRecord(companyId: String?): Boolean {
        if (companyId.isNullOrBlank() || companyId == "_unset" || companyId == "C-1") {
            android.util.Log.w("CompanyContext", "Rejected invalid companyId candidate: '$companyId' — company context left unresolved rather than accepting a placeholder/blank value")
            return false
        }
        if (_current.value != null && _current.value != companyId) {
            android.util.Log.w("CompanyContext", "companyId changed mid-session: '${_current.value}' -> '$companyId' — this should only happen on an intentional company switch")
        }
        _current.value = companyId
        return true
    }

    fun clear() {
        _current.value = null
    }
}
