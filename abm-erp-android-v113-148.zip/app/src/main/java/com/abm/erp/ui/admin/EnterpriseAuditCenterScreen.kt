package com.abm.erp.ui.admin

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abm.erp.data.MockRepository
import com.abm.erp.data.UserRole
import com.abm.erp.theme.*

@Composable
fun EnterpriseAuditCenterScreen() {
    val currentUser = MockRepository.currentUser
    if (currentUser.role != UserRole.CHAIRMAN) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("এই স্ক্রিন শুধু Chairman-এর জন্য।") }
        return
    }
    val allEntries by MockRepository.auditLogEntries.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var entityTypeFilter by remember { mutableStateOf<String?>(null) }

    val entityTypes = remember(allEntries) { allEntries.map { it.entityType }.distinct().sorted() }
    val filtered = remember(allEntries, searchQuery, entityTypeFilter) {
        allEntries.filter { e ->
            (entityTypeFilter == null || e.entityType == entityTypeFilter) &&
                (searchQuery.isBlank() || e.entityId.contains(searchQuery, true) || e.performedBy.contains(searchQuery, true) || e.action.contains(searchQuery, true))
        }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Enterprise Audit Center", style = MaterialTheme.typography.titleLarge)
        Text("এই তালিকা কখনো সম্পাদনা/মোছা যায় না — শুধু দেখা যায়।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = searchQuery, onValueChange = { searchQuery = it }, label = { Text("খুঁজুন (কে/কী/entity-id)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState())) {
            FilterChip(selected = entityTypeFilter == null, onClick = { entityTypeFilter = null }, label = { Text("সব", style = MaterialTheme.typography.labelSmall) })
            entityTypes.forEach { type -> FilterChip(selected = entityTypeFilter == type, onClick = { entityTypeFilter = type }, label = { Text(type, style = MaterialTheme.typography.labelSmall) }) }
        }
        Spacer(Modifier.height(8.dp))
        Text("${filtered.size} entries", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        LazyColumn {
            items(filtered.sortedByDescending { it.timestamp }) { e ->
                Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), tonalElevation = 2.dp) {
                    Column(Modifier.padding(10.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("${e.entityType} — ${e.action}", style = MaterialTheme.typography.titleSmall)
                            Text(
                                when (e.syncStatus) { "SYNCED" -> "🟢"; "FAILED" -> "🔴"; else -> "⏳" },
                                style = MaterialTheme.typography.labelSmall,
                            )
                        }
                        Text("Who: ${e.performedBy} (${e.performedByRole}) · When: ${e.timestamp}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("Entity ID: ${e.entityId}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        if (e.oldValueJson != null) Text("আগে: ${e.oldValueJson}", style = MaterialTheme.typography.labelSmall)
                        if (e.newValueJson != null) Text("পরে: ${e.newValueJson}", style = MaterialTheme.typography.labelSmall)
                        e.reason?.let { Text("কারণ: $it", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                        e.relatedApprovalId?.let { Text("Approval Ref: $it", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                        if (e.deviceId != null || (e.gpsLat != null && e.gpsLng != null)) {
                            Text(
                                "Device: ${e.deviceId ?: "?"}${if (e.gpsLat != null) " · GPS: ${"%.4f".format(e.gpsLat)},${"%.4f".format(e.gpsLng)}" else ""}",
                                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                            )
                        }
                    }
                }
            }
        }
    }
}
