package com.abm.erp.data.room

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String = "",
    val sku: String = "",
    val name: String = "",
    val unit: String = "",          // "ctn", "kg", "pcs"...
    val category: String = "",
    val reorderThreshold: Double = 0.0,
    val defaultUnitPrice: Double = 0.0,
    val costPrice: Double = 0.0,
    val photoUri: String? = null,
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val dedupKey: String = "",
    val deletedAtEpochMillis: Long? = null,
    val deletedBy: String? = null,
    val barcodeValue: String = "",
    val categoryId: String? = null,
    val brandId: String? = null,
)

@Entity(tableName = "warehouses")
data class WarehouseEntity(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val zone: String = "",
    val stockCategory: String = "STORE", // "PRODUCTION" or "STORE" — see StockCategory enum in Models.kt
)

@Entity(tableName = "stock_levels", primaryKeys = ["productId", "warehouseId"])
data class StockLevelEntity(
    val productId: String,
    val warehouseId: String,
    val quantityOnHand: Double,
    val reservedQty: Double = 0.0, // v86 - Stock Reservation
)

@Entity(tableName = "stock_counts")
data class StockCountEntity(
    @PrimaryKey val id: String = "",
    val countNo: String = "",
    val warehouseId: String = "",
    val warehouseName: String = "",
    val linesRaw: String = "",
    val status: String = "DRAFT",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val approvedBy: String? = null,
    val approvedAtEpochMillis: Long? = null,
)

@Entity(tableName = "stock_movements")
data class StockMovementEntity(
    @PrimaryKey val id: String = "",
    val productId: String = "",
    val warehouseId: String = "",
    val type: String = "IN",          // IN / OUT / ADJUST
    val quantity: Double = 0.0,
    val reason: String = "",
    val batchCode: String? = null, // Section 6 — real, queryable batch reference (was previously only embedded loosely in the free-text reason string)
    val unitCost: Double = 0.0, // 0.0 = not known/applicable for this movement — never fabricated
    val timestampEpochMillis: Long = 0,
)
