package com.abm.erp.core

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.abm.erp.data.Product
import com.abm.erp.data.SalesInvoiceLineItem
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.DashBg
import com.abm.erp.theme.StatusRed
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

/**
 * Shared full-screen pickers for the invoice-style creation pages.
 *
 * Extracted here rather than left as a private copy inside one screen, because a second
 * screen (Dealer Invoice) needs the exact same product picker — duplicating it a second
 * time would have been the same mistake this project has already made twice this session
 * (shipping a second copy of something that already exists).
 */

/** Product picker — searches the real product master, returns one priced line item. */
@Composable
fun ProductPickerDialog(
    products: List<Product>,
    onDismiss: () -> Unit,
    onPick: (SalesInvoiceLineItem) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(products, query) {
        if (query.isBlank()) products.take(40)
        else products.filter { it.name.contains(query, true) || it.sku.contains(query, true) }.take(40)
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = DashBg) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth()
                        .background(Brush.horizontalGradient(listOf(Color(0xFF2563EB), Color(0xFF1E3A8A))))
                        .padding(Space.lg),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("পণ্য বাছুন", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = onDismiss) { Text("✕ বন্ধ", color = Color.White) }
                }
                Column(Modifier.padding(Space.md)) {
                    EnterpriseSearchBar(query, { query = it }, "নাম বা SKU দিয়ে খুঁজুন…")
                }
                if (filtered.isEmpty()) {
                    WorkspaceEmptyState("কোনো পণ্য পাওয়া যায়নি।", iconVector = Icons.Filled.Inventory2)
                }
                LazyColumn(
                    Modifier.weight(1f).padding(horizontal = Space.md),
                    verticalArrangement = Arrangement.spacedBy(Space.sm),
                ) {
                    items(filtered) { p ->
                        PremiumCard(
                            padding = Space.md,
                            onClick = {
                                onPick(SalesInvoiceLineItem(productId = p.id, name = p.name, unit = p.unit, qty = 1, unitPrice = p.defaultUnitPrice))
                            },
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Real product photo when the company uploaded one; icon chip otherwise.
                                if (!p.photoUri.isNullOrBlank()) {
                                    coil.compose.AsyncImage(
                                        model = p.photoUri,
                                        contentDescription = p.name,
                                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                        modifier = Modifier.size(40.dp).clip(RoundedCornerShape(11.dp)),
                                    )
                                } else {
                                    IconChip(Icons.Filled.Inventory2, Color(0xFF2563EB), size = 36)
                                }
                                Spacer(Modifier.width(Space.md))
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                    Text("${p.sku} · ${p.category}", fontSize = 10.sp, color = TextSecondary)
                                }
                                Text("৳${"%,.0f".format(p.defaultUnitPrice)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DarazOrange)
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Dealer picker — the counterpart used at the top of the Dealer Invoice page.
 *
 * Shows each dealer's real due balance and credit-limit status right on the picker row, not
 * only after selection, so the tapping decision is informed rather than blind. Nothing here
 * computes a new figure — `dueBalance` and `creditLimit` are read exactly as the repository
 * already tracks them.
 */
@Composable
fun DealerPickerDialog(
    dealers: List<com.abm.erp.data.Dealer>,
    onDismiss: () -> Unit,
    onPick: (com.abm.erp.data.Dealer) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(dealers, query) {
        if (query.isBlank()) dealers else dealers.filter { it.name.contains(query, true) || it.zone.contains(query, true) }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = DashBg) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth()
                        .background(Brush.horizontalGradient(listOf(Color(0xFFB45CFF), Color(0xFF7A2EE0))))
                        .padding(Space.lg),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("ডিলার বাছুন", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = onDismiss) { Text("✕ বন্ধ", color = Color.White) }
                }
                Column(Modifier.padding(Space.md)) {
                    EnterpriseSearchBar(query, { query = it }, "নাম বা এলাকা দিয়ে খুঁজুন…")
                }
                if (filtered.isEmpty()) {
                    WorkspaceEmptyState("কোনো ডিলার পাওয়া যায়নি।", iconVector = Icons.Filled.Business)
                }
                LazyColumn(
                    Modifier.weight(1f).padding(horizontal = Space.md),
                    verticalArrangement = Arrangement.spacedBy(Space.sm),
                ) {
                    items(filtered) { d ->
                        val overLimit = d.creditLimit > 0 && d.dueBalance >= d.creditLimit
                        PremiumCard(padding = Space.md, onClick = { onPick(d) }) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconChip(
                                    Icons.Filled.Business,
                                    if (overLimit) StatusRed else Color(0xFFB45CFF),
                                    size = 38,
                                )
                                Spacer(Modifier.width(Space.md))
                                Column(Modifier.weight(1f)) {
                                    Text(d.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                    Text(d.zone, fontSize = 10.sp, color = TextSecondary)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        "Due ৳${"%,.0f".format(d.dueBalance)}",
                                        fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                        color = if (overLimit) StatusRed else TextPrimary,
                                    )
                                    if (overLimit) {
                                        Text("Over limit ⚠", fontSize = 9.sp, color = StatusRed)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
