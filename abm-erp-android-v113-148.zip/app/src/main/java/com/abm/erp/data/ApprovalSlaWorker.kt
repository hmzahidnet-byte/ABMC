package com.abm.erp.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Section 5 — Approval SLA & Escalation. Without this worker,
 * checkAndNotifySlaBreaches() only ever ran when a screen happened to
 * call it — meaning "every approval should have deadlines" wasn't
 * actually automatic, it depended on someone opening the right screen
 * at the right moment. This makes the 24h/48h/72h tiers real: it runs
 * on its own schedule regardless of what's open on screen.
 */
class ApprovalSlaWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            val companyId = getSavedCompanyCode(applicationContext) ?: return Result.success()
            if (MockRepository.currentUser.companyId.isBlank()) return Result.success() // not signed in yet — nothing to check
            MockRepository.checkAndNotifySlaBreaches()
            MockRepository.dispatchSmartBusinessAlerts()
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "abm_approval_sla_check"

        /** Called once from ABMApplication.onCreate() — WorkManager itself persists the schedule across app restarts and device reboots. */
        fun schedule(context: Context) {
            // Hourly is fine granularity for 24h/48h/72h-scale thresholds — no network constraint needed since notifications/audit are local-first and sync separately.
            val request = PeriodicWorkRequestBuilder<ApprovalSlaWorker>(1, TimeUnit.HOURS)
                .build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        }
    }
}
