package com.abm.erp.auth

import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Part A — real PIN/password hashing. PBKDF2WithHmacSHA256, per-account
 * random salt, no plaintext PIN is ever stored or compared directly
 * anywhere past this point. This is the one place that does the hashing;
 * every other file must call through here rather than rolling its own.
 */
object PinHashing {
    private const val ITERATIONS = 120_000 // OWASP-recommended floor for PBKDF2-HMAC-SHA256 as of this writing
    private const val KEY_LENGTH_BITS = 256
    private const val SALT_LENGTH_BYTES = 16

    data class HashResult(val hash: String, val salt: String, val iterations: Int)

    fun generateSalt(): ByteArray {
        val salt = ByteArray(SALT_LENGTH_BYTES)
        SecureRandom().nextBytes(salt)
        return salt
    }

    fun hash(plainPin: String, salt: ByteArray, iterations: Int = ITERATIONS): String {
        val spec = PBEKeySpec(plainPin.toCharArray(), salt, iterations, KEY_LENGTH_BITS)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val key = factory.generateSecret(spec).encoded
        return android.util.Base64.encodeToString(key, android.util.Base64.NO_WRAP)
    }

    /** Creates a brand-new hash+salt pair for a freshly-set PIN. */
    fun createHash(plainPin: String): HashResult {
        val salt = generateSalt()
        val saltB64 = android.util.Base64.encodeToString(salt, android.util.Base64.NO_WRAP)
        return HashResult(hash(plainPin, salt), saltB64, ITERATIONS)
    }

    /** Constant-time-ish verify (re-hash and compare full strings — avoids the classic "compare byte-by-byte, return early" timing leak via a length+content check on already-fixed-length base64). */
    fun verify(plainPin: String, storedHash: String, storedSaltB64: String, iterations: Int): Boolean {
        val salt = android.util.Base64.decode(storedSaltB64, android.util.Base64.NO_WRAP)
        val computed = hash(plainPin, salt, iterations)
        return constantTimeEquals(computed, storedHash)
    }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var result = 0
        for (i in a.indices) result = result or (a[i].code xor b[i].code)
        return result == 0
    }

    /** Part A — reject known-weak PINs (sequential, repeated-digit) at set-time, not just log a warning after the fact. */
    fun isWeakPin(pin: String): Boolean {
        if (pin.length < 4) return true
        if (pin.all { it == pin[0] }) return true // "11111", "00000"
        val ascending = pin.zipWithNext().all { (a, b) -> b - a == 1 }
        val descending = pin.zipWithNext().all { (a, b) -> a - b == 1 }
        if (ascending || descending) return true // "12345", "54321"
        val commonWeak = setOf("1234", "12345", "0000", "00000", "1111", "11111", "9999", "99999", "1212", "12121")
        return pin in commonWeak
    }
}
