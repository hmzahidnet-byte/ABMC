package com.abm.erp.core

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.data.Dealer
import com.abm.erp.data.EmployeeProfile
import com.abm.erp.data.MockRepository
import com.abm.erp.data.PartyType
import com.abm.erp.data.Product
import com.abm.erp.data.Retailer
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import java.time.LocalDate

/**
 * v113-85 — per-module descriptors for the shared browse flow (ModuleBrowseFlow.kt).
 * Each is small on purpose: the screens live in one place, these only say what a
 * module's records look like and which drill-downs it genuinely has.
 *
 * Honest asymmetry, deliberately preserved rather than papered over:
 *  - Dealer and Retailer are money-bearing parties → they get Ledger, Calendar,
 *    Product Graph and 90-Day, all off real PartyLedger / invoice / collection data.
 *  - Employee is not a money-bearing party in this codebase — there is no employee
 *    ledger — so HR's browse flow shows identity, role/geo and status only, with no
 *    ledger/graph buttons. Rendering empty ones would imply data exists that doesn't.
 */

private fun classLabel(c: String) = when (c) { "A" -> "A-Class"; "C" -> "C-Class"; else -> "B-Class" }

// ── DMS · Dealer ───────────────────────────────────────────────────────────────

@Composable
fun rememberDealerBrowseConfig(zones: List<String>): BrowseConfig<Dealer> {
    val invoices by MockRepository.salesInvoices.collectAsState()
    val collections by MockRepository.partyCollections.collectAsState()
    return remember(zones, invoices, collections) {
        BrowseConfig(
            moduleName = "DMS", entityLabel = "Dealer",
            colorStart = 0xFF2563EB, colorEnd = 0xFF1E3A8A,
            idOf = { it.id },
            titleOf = { it.name },
            codeOf = { it.dealerCode.ifBlank { it.id.take(8).uppercase() } },
            subtitleOf = { "${it.phone.ifBlank { "ফোন নেই" }} · ${it.zone}" },
            categoryOf = { "${classLabel(it.classification)} Dealer" },
            isActiveOf = { it.isActive },
            searchMatches = { d, q -> d.name.contains(q, true) || d.dealerCode.contains(q, true) || d.phone.contains(q, true) || d.zone.contains(q, true) },
            facets = listOf(
                BrowseFacet("Area", zones) { d, o -> d.zone == o },
                BrowseFacet("Category", listOf("A", "B", "C")) { d, o -> d.classification == o },
                BrowseFacet("Status", listOf("Active", "Inactive")) { d, o -> (o == "Active") == d.isActive },
            ),
            infoRows = { d ->
                listOf(
                    BrowseInfoRow("Dealer Code", d.dealerCode.ifBlank { d.id.take(8).uppercase() }),
                    BrowseInfoRow("Dealer Name", d.name),
                    BrowseInfoRow("Owner Name", d.proprietorName.ifBlank { "—" }),
                    BrowseInfoRow("Phone", d.phone.ifBlank { "—" }),
                    BrowseInfoRow("Area / Zone", d.zone),
                    BrowseInfoRow("Address", d.address.ifBlank { "—" }),
                    BrowseInfoRow("Category", "${classLabel(d.classification)} Dealer"),
                    BrowseInfoRow("Status", if (d.isActive) "Active" else "Inactive"),
                    BrowseInfoRow("Join Date", d.createdAt.toLocalDate().toString()),
                    BrowseInfoRow("Credit Limit", if (d.creditLimit > 0) "৳${"%,.0f".format(d.creditLimit)}" else "নির্ধারিত নেই"),
                )
            },
            kpis = { d ->
                val inv = invoices.filter { !it.isDeleted && it.dealerId == d.id }
                val col = collections.filter { it.partyType == PartyType.DEALER && it.partyId == d.id && it.status == "VERIFIED" }
                listOf(
                    BrowseKpi("Total Sales", "৳${"%,.0f".format(inv.sumOf { it.total })}"),
                    BrowseKpi("Total Collection", "৳${"%,.0f".format(col.sumOf { it.amount })}", SuccessGreen),
                    BrowseKpi("Total Due", "৳${"%,.0f".format(d.dueBalance)}", if (d.dueBalance > 0) WarningAmber else SuccessGreen),
                )
            },
            hasLedger = true,
            activities = { d -> rememberPartyActivities(PartyType.DEALER, d.id) },
            hasGraph = true,
            slices = { d ->
                invoices.filter { !it.isDeleted && it.dealerId == d.id }
                    .flatMap { it.lineItems }.groupBy { it.name }
                    .map { (n, l) -> BrowseSlice(n, l.sumOf { it.lineTotal }) }
            },
            has90Day = true,
            summary90 = { d ->
                val cutoff = LocalDate.now().minusDays(90)
                val inv = invoices.filter { !it.isDeleted && it.dealerId == d.id && it.createdAt.toLocalDate() >= cutoff }
                val col = collections.filter { it.partyType == PartyType.DEALER && it.partyId == d.id && it.status == "VERIFIED" && it.createdAt.toLocalDate() >= cutoff }
                listOf(
                    BrowseKpi("Sales", "৳${"%,.0f".format(inv.sumOf { it.total })}"),
                    BrowseKpi("Collection", "৳${"%,.0f".format(col.sumOf { it.amount })}", SuccessGreen),
                    BrowseKpi("Due", "৳${"%,.0f".format(d.dueBalance)}", WarningAmber),
                    BrowseKpi("Invoices", "${inv.size}"),
                    BrowseKpi("Collections", "${col.size}"),
                    BrowseKpi("Stock Units", "${d.stockUnits}"),
                )
            },
            qrEntityType = "Dealer", // canonical registry type — same string activateQrFor uses at approval
            addRoute = "dms?key=newdealer",
            // v113-146 — real CSV import for dealers. Column names match what
            // `exportListAsCsv` writes plus the fields createDealer needs, so an
            // exported sheet edited in Excel round-trips. Each row goes through the
            // SAME createDealer the manual form uses, so permission/duplicate/
            // validation rules are identical and each failure reports its real reason.
            importCsv = { text ->
                val lines = text.lines().filter { it.isNotBlank() }
                if (lines.size < 2) {
                    CsvImport.ImportOutcome(0, 0, 0, emptyList(), "ফাইলে header ছাড়া কোনো row নেই।")
                } else {
                    val header = CsvImport.splitCsvLine(lines.first())
                    val (idx, missing) = CsvImport.headerIndex(header, listOf("Name", "Phone"))
                    if (missing != null) {
                        CsvImport.ImportOutcome(0, 0, 0, emptyList(), missing)
                    } else {
                        val results = mutableListOf<CsvImport.RowResult>()
                        lines.drop(1).forEachIndexed { i, raw ->
                            val cols = CsvImport.splitCsvLine(raw)
                            fun col(name: String): String = idx[name.lowercase()]?.let { cols.getOrNull(it) }.orEmpty()
                            val name = col("Name")
                            var reason: String? = null
                            val created = MockRepository.createDealer(
                                name = name, zone = col("Zone"), phone = col("Phone"), address = col("Address"),
                                onRejected = { r -> reason = r },
                            )
                            results.add(CsvImport.RowResult(i + 2, name.ifBlank { "(নামহীন)" }, created != null, reason))
                        }
                        CsvImport.ImportOutcome(results.size, results.count { it.ok }, results.count { !it.ok }, results)
                    }
                }
            },
            extraTabs = listOf("Transactions"),
            extraTabContent = { d, _, onNavigate ->
                PartyTransactionsTab(PartyType.DEALER, d.id, invoices.filter { !it.isDeleted && it.dealerId == d.id }.map {
                    Triple(it.invoiceNo, it.total, it.createdAt.toLocalDate().toString())
                }, onNavigate)
            },
        )
    }
}

// ── RMS · Retailer ─────────────────────────────────────────────────────────────

@Composable
fun rememberRetailerBrowseConfig(markets: List<String>): BrowseConfig<Retailer> {
    val orders by MockRepository.orders.collectAsState()
    val collections by MockRepository.partyCollections.collectAsState()
    return remember(markets, orders, collections) {
        BrowseConfig(
            moduleName = "RMS", entityLabel = "Retailer",
            colorStart = 0xFF0EA5A4, colorEnd = 0xFF0F766E,
            idOf = { it.id },
            titleOf = { it.name },
            codeOf = { it.retailerCode.ifBlank { it.id.take(8).uppercase() } },
            subtitleOf = { "${it.phone.ifBlank { "ফোন নেই" }} · ${it.market.ifBlank { "market নেই" }}" },
            categoryOf = { "${classLabel(it.classification)} Retailer" },
            isActiveOf = { it.isActive },
            searchMatches = { r, q -> r.name.contains(q, true) || r.retailerCode.contains(q, true) || r.phone.contains(q, true) || r.market.contains(q, true) },
            facets = listOf(
                BrowseFacet("Market", markets) { r, o -> r.market == o },
                BrowseFacet("Category", listOf("A", "B", "C")) { r, o -> r.classification == o },
                BrowseFacet("Status", listOf("Active", "Inactive")) { r, o -> (o == "Active") == r.isActive },
            ),
            infoRows = { r ->
                listOf(
                    BrowseInfoRow("Retailer Code", r.retailerCode.ifBlank { r.id.take(8).uppercase() }),
                    BrowseInfoRow("Retailer Name", r.name),
                    BrowseInfoRow("Owner Name", r.ownerName.ifBlank { "—" }),
                    BrowseInfoRow("Phone", r.phone.ifBlank { "—" }),
                    BrowseInfoRow("Market / Route", r.market.ifBlank { "—" }),
                    BrowseInfoRow("Address", r.address.ifBlank { "—" }),
                    BrowseInfoRow("Category", "${classLabel(r.classification)} Retailer"),
                    BrowseInfoRow("Status", if (r.isActive) "Active" else "Inactive"),
                    BrowseInfoRow("Join Date", r.createdAt.toLocalDate().toString()),
                    BrowseInfoRow("Credit Limit", if (r.creditLimit > 0) "৳${"%,.0f".format(r.creditLimit)}" else "নির্ধারিত নেই"),
                )
            },
            kpis = { r ->
                val myOrders = orders.filter { it.retailerId == r.id || (it.retailerId == null && it.retailerName == r.name) }
                val col = collections.filter { it.partyType == PartyType.RETAILER && it.partyId == r.id && it.status == "VERIFIED" }
                listOf(
                    BrowseKpi("Memo Total", "৳${"%,.0f".format(myOrders.sumOf { it.amount })}"),
                    BrowseKpi("Collection", "৳${"%,.0f".format(col.sumOf { it.amount })}", SuccessGreen),
                    BrowseKpi("Total Due", "৳${"%,.0f".format(r.dueBalance)}", if (r.dueBalance > 0) WarningAmber else SuccessGreen),
                )
            },
            hasLedger = true,
            activities = { r -> rememberPartyActivities(PartyType.RETAILER, r.id) },
            hasGraph = true,
            slices = { r ->
                orders.filter { it.retailerId == r.id || (it.retailerId == null && it.retailerName == r.name) }
                    .flatMap { it.lineItems }.groupBy { it.name }
                    .map { (n, l) -> BrowseSlice(n, l.sumOf { it.lineTotal }) }
            },
            has90Day = true,
            summary90 = { r ->
                val cutoff = LocalDate.now().minusDays(90)
                val myOrders = orders.filter { (it.retailerId == r.id || (it.retailerId == null && it.retailerName == r.name)) && it.loggedAt.toLocalDate() >= cutoff }
                val col = collections.filter { it.partyType == PartyType.RETAILER && it.partyId == r.id && it.status == "VERIFIED" && it.createdAt.toLocalDate() >= cutoff }
                listOf(
                    BrowseKpi("Memo Amount", "৳${"%,.0f".format(myOrders.sumOf { it.amount })}"),
                    BrowseKpi("Collection", "৳${"%,.0f".format(col.sumOf { it.amount })}", SuccessGreen),
                    BrowseKpi("Due", "৳${"%,.0f".format(r.dueBalance)}", WarningAmber),
                    BrowseKpi("Memos", "${myOrders.size}"),
                    BrowseKpi("Collections", "${col.size}"),
                )
            },
            qrEntityType = "Retailer",
            addRoute = "rms?key=add",
            extraTabs = listOf("Transactions"),
            extraTabContent = { r, _, onNavigate ->
                PartyTransactionsTab(PartyType.RETAILER, r.id, orders
                    .filter { it.retailerId == r.id || (it.retailerId == null && it.retailerName == r.name) }
                    .map { Triple(it.orderNo, it.amount, it.loggedAt.toLocalDate().toString()) }, onNavigate)
            },
        )
    }
}

// ── HR · Employee ──────────────────────────────────────────────────────────────

@Composable
fun rememberEmployeeBrowseConfig(departments: List<String>): BrowseConfig<EmployeeProfile> =
    remember(departments) {
        BrowseConfig(
            moduleName = "HR", entityLabel = "Employee",
            colorStart = 0xFFDB2777, colorEnd = 0xFF9D174D,
            idOf = { it.id },
            titleOf = { it.fullName },
            codeOf = { it.employeeCode.ifBlank { it.id.take(8).uppercase() } },
            subtitleOf = { "${it.designation.ifBlank { it.role.name }} · ${it.department.ifBlank { "বিভাগ নেই" }}" },
            categoryOf = { it.role.name },
            isActiveOf = { it.hasActiveAccess },
            searchMatches = { e, q -> e.fullName.contains(q, true) || e.employeeCode.contains(q, true) || e.mobile.contains(q, true) || e.designation.contains(q, true) },
            facets = listOf(
                BrowseFacet("Department", departments) { e, o -> e.department == o },
                BrowseFacet("Status", listOf("Active", "Inactive")) { e, o -> (o == "Active") == e.hasActiveAccess },
            ),
            infoRows = { e ->
                listOf(
                    BrowseInfoRow("Employee ID", e.employeeCode.ifBlank { e.id.take(8).uppercase() }),
                    BrowseInfoRow("Full Name", e.fullName),
                    BrowseInfoRow("Designation", e.designation.ifBlank { "—" }),
                    BrowseInfoRow("Role (permission)", e.role.name),
                    BrowseInfoRow("Department", e.department.ifBlank { "—" }),
                    BrowseInfoRow("Mobile", e.mobile.ifBlank { "—" }),
                    BrowseInfoRow("Employment Status", e.status.name),
                    BrowseInfoRow("Access", if (e.hasActiveAccess) "Active" else "No active access"),
                    BrowseInfoRow("Joined", e.createdAt.toLocalDate().toString()),
                )
            },
            // No ledger/graph/90-day: employees are not money-bearing parties in this
            // codebase, so those drill-downs genuinely have no data behind them.
            // First registry type introduced from the card itself: employees were never
            // auto-issued at approval (unlike Dealer/Retailer), so the card's "Issue"
            // button is the entry point. resolve() is type-agnostic, so scans validate.
            qrEntityType = "Employee",
            addRoute = "hr_module?key=add",
        )
    }


// ── FMS · Product / Stock ──────────────────────────────────────────────────────

/**
 * v113-86 — FMS's "list" is a PRODUCT list, not a party list. The record shape is
 * honestly different: no phone/owner/due, but sku/unit/price and per-warehouse stock.
 * The engine's capability flags carry that honestly — no Ledger and no 90-Day (a
 * product has no party ledger or due), but the Graph drill-down IS enabled and shows
 * the real per-warehouse stock split for that product, which is the product-shaped
 * equivalent of the dealer's product split.
 */
@Composable
fun rememberProductBrowseConfig(categories: List<String>): BrowseConfig<Product> {
    val stockLevels by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
    return remember(categories, stockLevels) {
        BrowseConfig(
            moduleName = "FMS", entityLabel = "Product",
            colorStart = 0xFFE85D4A, colorEnd = 0xFFC03A2B,
            idOf = { it.id },
            titleOf = { it.name },
            codeOf = { it.sku.ifBlank { it.id.take(8).uppercase() } },
            subtitleOf = { p ->
                val onHand = stockLevels.filter { it.productId == p.id }.sumOf { it.quantityOnHand }
                "${p.category.ifBlank { "category নেই" }} · Stock: ${"%,.0f".format(onHand)} ${p.unit}"
            },
            categoryOf = { it.category.ifBlank { "Uncategorised" } },
            isActiveOf = { it.isActive && !it.isDeleted },
            searchMatches = { pr, q -> pr.name.contains(q, true) || pr.sku.contains(q, true) || pr.category.contains(q, true) },
            facets = listOf(
                BrowseFacet("Category", categories) { pr, o -> pr.category == o },
                BrowseFacet("Status", listOf("Active", "Inactive")) { pr, o -> (o == "Active") == (pr.isActive && !pr.isDeleted) },
            ),
            infoRows = { pr ->
                val levels = stockLevels.filter { it.productId == pr.id }
                val onHand = levels.sumOf { it.quantityOnHand }
                listOf(
                    BrowseInfoRow("SKU", pr.sku.ifBlank { "—" }),
                    BrowseInfoRow("Product Name", pr.name),
                    BrowseInfoRow("Category", pr.category.ifBlank { "—" }),
                    BrowseInfoRow("Unit", pr.unit),
                    BrowseInfoRow("Sale Price", "৳${"%,.2f".format(pr.defaultUnitPrice)}"),
                    BrowseInfoRow("Cost Price", if (pr.costPrice > 0) "৳${"%,.2f".format(pr.costPrice)}" else "সেট করা নেই"),
                    BrowseInfoRow("On Hand (all warehouses)", "${"%,.0f".format(onHand)} ${pr.unit}"),
                    BrowseInfoRow("Reorder Threshold", "${"%,.0f".format(pr.reorderThreshold)} ${pr.unit}"),
                    BrowseInfoRow("Status", if (pr.isActive && !pr.isDeleted) "Active" else "Inactive"),
                    BrowseInfoRow("Created", pr.createdAt.toLocalDate().toString()),
                )
            },
            kpis = { pr ->
                val levels = stockLevels.filter { it.productId == pr.id }
                val onHand = levels.sumOf { it.quantityOnHand }
                listOf(
                    BrowseKpi("On Hand", "${"%,.0f".format(onHand)} ${pr.unit}"),
                    BrowseKpi("Stock Value", "৳${"%,.0f".format(onHand * pr.defaultUnitPrice)}"),
                    BrowseKpi("Warehouses", "${levels.count { it.quantityOnHand > 0 }}"),
                )
            },
            // Graph = per-warehouse stock split (the product-shaped "where is it" view).
            hasGraph = true,
            slices = { pr ->
                stockLevels.filter { it.productId == pr.id && it.quantityOnHand > 0 }
                    .map { BrowseSlice(it.warehouseName, it.quantityOnHand * pr.defaultUnitPrice) }
            },
            // No hasLedger / has90Day: a product has no party ledger and no due — the
            // engine simply won't render those buttons.
            graphTitle = "Warehouse Wise Stock", // default title says "Sales" — this graph is a stock split, not sales
            qrEntityType = "Product",
        )
    }
}

// ── shared helpers used by the configs ─────────────────────────────────────────

/** Real party ledger → browse activities. One place, both DMS and RMS. */
@Composable
private fun rememberPartyActivities(partyType: PartyType, partyId: String): List<BrowseActivity> {
    val entries by remember(partyType, partyId) { MockRepository.partyLedgerFor(partyType, partyId) }
        .collectAsState(initial = emptyList())
    return remember(entries) {
        entries.map { e ->
            BrowseActivity(
                date = e.createdAt.toLocalDate(),
                title = e.reason,
                kind = if (e.type == "DEBIT") "Invoice/Memo" else "Collection/Return",
                amount = e.amount,
                isDebit = e.type == "DEBIT",
                balanceAfter = e.balanceAfter,
            )
        }
    }
}

@Composable
private fun PartyTransactionsTab(
    partyType: PartyType,
    partyId: String,
    docs: List<Triple<String, Double, String>>,
    onNavigate: (String) -> Unit,
) {
    val collections by MockRepository.partyCollections.collectAsState()
    val myCollections = remember(collections, partyId) {
        collections.filter { it.partyType == partyType && it.partyId == partyId }.sortedByDescending { it.createdAt }
    }
    Column(Modifier.fillMaxWidth()) {
        Text("Transactions", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(8.dp))
        if (docs.isEmpty() && myCollections.isEmpty()) Text("কোনো লেনদেন নেই।", color = TextSecondary)
        docs.take(15).forEach { (no, amount, date) ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(no, fontWeight = FontWeight.SemiBold, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                        Text(date, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Text("৳${"%,.0f".format(amount)}", fontWeight = FontWeight.Bold, color = TextPrimary)
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        myCollections.take(15).forEach { c ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(c.collectionNo.ifBlank { c.id.take(8) }, fontWeight = FontWeight.SemiBold, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                        Text("Collection · ${c.method} · ${c.createdAt.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Text("৳${"%,.0f".format(c.amount)}", fontWeight = FontWeight.Bold, color = SuccessGreen)
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
