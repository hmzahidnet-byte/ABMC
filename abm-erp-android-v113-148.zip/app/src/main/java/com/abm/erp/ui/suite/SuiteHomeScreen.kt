package com.abm.erp.ui.suite

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.EnterpriseListRow
import com.abm.erp.core.IconChip
import com.abm.erp.core.MetricCard
import com.abm.erp.core.SectionTitle
import com.abm.erp.core.Space
import com.abm.erp.data.AppSuite
import com.abm.erp.data.MockRepository
import com.abm.erp.data.suiteByKey
import com.abm.erp.data.visibleFunctionsFor
import com.abm.erp.theme.*

/**
 * Suite home — the landing page for one business segment.
 *
 * Renders the suite's identity, a few live KPIs read from data the app already
 * loads, and the suite's functions grouped by purpose. Tapping a function opens the
 * **existing** screen at the right tab; no screen is reimplemented here.
 *
 * Access: functions are filtered through `visibleFunctionsFor()`, which is itself
 * derived from `visibleModulesFor()`. A suite can therefore never surface something
 * the module permission rules did not already permit.
 */
@Composable
fun SuiteHomeScreen(suiteKey: String, onNavigate: (String) -> Unit) {
    val suite = suiteByKey(suiteKey)
    if (suite == null) {
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            Text("Unknown module.", style = MaterialTheme.typography.titleMedium)
        }
        return
    }

    val currentUser = MockRepository.currentUser
    val profiles by MockRepository.employeeProfiles.collectAsState()
    val profile = remember(currentUser.employeeId, profiles) { profiles.firstOrNull { it.id == currentUser.employeeId } }
    val company = remember(currentUser.companyId) { MockRepository.companySettings() }
    val context = LocalContext.current
    val isOnline = remember { com.abm.erp.util.NetworkStatus.isOnline(context) }
    val failedSync by MockRepository.failedSyncIds.collectAsState()

    val groups = remember(suite, currentUser.role) { visibleFunctionsFor(suite, currentUser.role) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {

        // ---- suite identity banner ----
        Box(
            Modifier.fillMaxWidth()
                .background(Brush.linearGradient(listOf(Color(suite.colorStart), Color(suite.colorEnd))))
                .padding(horizontal = Space.lg, vertical = 20.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(46.dp).background(Color.White.copy(alpha = 0.20f), androidx.compose.foundation.shape.RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center,
                ) { Icon(suite.icon, null, tint = if (suite.isChairman) ChairmanGold else Color.White, modifier = Modifier.size(24.dp)) }
                Spacer(Modifier.width(Space.md))
                Column {
                    Text(
                        suite.fullName,
                        color = if (suite.isChairman) ChairmanGold else Color.White,
                        fontSize = 17.sp, fontWeight = FontWeight.Bold,
                    )
                    Text(suite.tagline, color = Color.White.copy(alpha = 0.82f), fontSize = 11.sp)
                }
            }
        }

        // ---- who is working this suite right now ----
        Surface(tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = Space.lg, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                val initials = remember(currentUser.name) {
                    currentUser.name.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() }
                }
                Box(
                    Modifier.size(36.dp).background(Color(suite.colorStart).copy(alpha = 0.15f), androidx.compose.foundation.shape.RoundedCornerShape(18.dp)),
                    contentAlignment = Alignment.Center,
                ) { Text(initials.ifBlank { "?" }, color = Color(suite.colorStart), fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                Spacer(Modifier.width(Space.md))
                Column(Modifier.weight(1f)) {
                    Text(currentUser.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    val line = listOfNotNull(
                        profile?.employeeCode?.ifBlank { null } ?: currentUser.employeeId.ifBlank { null },
                        profile?.designation?.ifBlank { null },
                        company.companyName.ifBlank { null },
                        currentUser.zone.ifBlank { null },
                    ).joinToString(" · ")
                    if (line.isNotBlank()) Text(line, fontSize = 10.sp, color = TextSecondary, maxLines = 2)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(if (isOnline) "● Online" else "● Offline", fontSize = 10.sp, color = if (isOnline) StatusGreen else StatusRed, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (failedSync.isEmpty()) "✓ Synced" else "⚠ ${failedSync.size} pending",
                        fontSize = 9.sp,
                        color = if (failedSync.isEmpty()) StatusGreen else StatusAmber,
                    )
                }
            }
        }

        Column(Modifier.fillMaxSize().padding(horizontal = Space.lg)) {

            // ---- live KPIs, from data already loaded elsewhere in the app ----
            val kpis = suiteKpis(suite.key)
            if (kpis.isNotEmpty()) {
                Spacer(Modifier.height(Space.lg))
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(Space.md),
                ) {
                    kpis.forEach { (label, value, color) ->
                        Box(Modifier.width(132.dp)) { MetricCard(label = label, value = value, valueColor = color) }
                    }
                }
            }

            groups.forEach { group ->
                SectionTitle(group.title)
                Column(verticalArrangement = Arrangement.spacedBy(Space.sm)) {
                    group.functions.forEach { fn ->
                        EnterpriseListRow(
                            title = fn.label,
                            subtitle = fn.description,
                            icon = fn.icon,
                            accent = Color(suite.colorStart),
                            onClick = {
                                // Existing route, opened at the right tab. The screen itself is
                                // unchanged — startTab is a defaulted parameter added for this.
                                val dest = if (fn.startTab != null) "${fn.route}?tab=${fn.startTab}" else fn.route
                                onNavigate(dest)
                            },
                            trailing = {
                                Icon(Icons.Filled.ChevronRight, null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                            },
                        )
                    }
                }
            }

            if (groups.isEmpty()) {
                Spacer(Modifier.height(Space.xl))
                com.abm.erp.core.WorkspaceEmptyState("এই মডিউলে আপনার প্রবেশাধিকার নেই।", iconVector = Icons.Filled.Lock)
            }

            Spacer(Modifier.height(Space.xxl))
        }
    }
}

/**
 * Live KPI values per suite. Every figure is read from a StateFlow the repository
 * already exposes — nothing is computed differently here, and nothing is invented.
 */
@Composable
private fun suiteKpis(key: String): List<Triple<String, String, Color>> {
    val today = java.time.LocalDate.now()
    return when (key) {
        "dms" -> {
            val dealers by MockRepository.dealers.collectAsState()
            val retailers by MockRepository.retailers.collectAsState()
            val collections by MockRepository.partyCollections.collectAsState()
            val due = dealers.sumOf { it.dueBalance } + retailers.sumOf { it.dueBalance }
            val todayCollected = collections.filter { it.createdAt.toLocalDate() == today }.sumOf { it.amount }
            val overLimit = dealers.count { it.creditLimit > 0 && it.dueBalance > it.creditLimit }
            listOf(
                Triple("Dealers", "${dealers.size}", TextPrimary),
                Triple("Retailers", "${retailers.size}", TextPrimary),
                Triple("Total Due", "৳${"%,.0f".format(due)}", if (due > 0) StatusAmber else StatusGreen),
                Triple("Collected Today", "৳${"%,.0f".format(todayCollected)}", StatusGreen),
                Triple("Over Limit", "$overLimit", if (overLimit > 0) StatusRed else StatusGreen),
            )
        }
        "sfa" -> {
            val invoices by MockRepository.salesInvoices.collectAsState()
            val visits by MockRepository.visitLogs.collectAsState()
            val orders by MockRepository.orders.collectAsState()
            val todaySales = invoices.filter { !it.isDeleted && it.createdAt.toLocalDate() == today }.sumOf { it.total }
            val todayVisits = visits.count { it.checkInAt.toLocalDate() == today }
            val todayOrders = orders.count { it.loggedAt.toLocalDate() == today }
            listOf(
                Triple("Today's Sales", "৳${"%,.0f".format(todaySales)}", DarazOrange),
                Triple("Orders Today", "$todayOrders", TextPrimary),
                Triple("Visits Today", "$todayVisits", if (todayVisits > 0) StatusGreen else StatusAmber),
            )
        }
        "crm" -> {
            val retailers by MockRepository.retailers.collectAsState()
            val dealers by MockRepository.dealers.collectAsState()
            val visits by MockRepository.visitLogs.collectAsState()
            val covered = visits.filter { it.checkInAt.toLocalDate() == today }.map { it.partyId }.distinct().size
            listOf(
                Triple("Retailers", "${retailers.size}", TextPrimary),
                Triple("Dealers", "${dealers.size}", TextPrimary),
                Triple("Covered Today", "$covered", TextPrimary),
            )
        }
        "hrm" -> {
            val leaves by MockRepository.leaveRequests.collectAsState()
            val payroll by MockRepository.payroll.collectAsState()
            val onLeave = leaves.count {
                it.status == com.abm.erp.data.LeaveStatus.APPROVED && !today.isBefore(it.fromDate) && !today.isAfter(it.toDate)
            }
            listOf(
                Triple("Employees", "${payroll.size}", TextPrimary),
                Triple("On Leave", "$onLeave", if (onLeave > 0) StatusAmber else StatusGreen),
                Triple("Overtime", "৳${"%,.0f".format(payroll.sumOf { it.overtimePay })}", TextPrimary),
            )
        }
        "wms" -> {
            val levels by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
            val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
            val low = levels.count { it.isLowStock }
            listOf(
                Triple("Products", "${products.size}", TextPrimary),
                Triple("On Hand", "%.0f".format(levels.sumOf { it.quantityOnHand }), StatusGreen),
                Triple("Reserved", "%.0f".format(levels.sumOf { it.reservedQty }), StatusAmber),
                Triple("Low Stock", "$low", if (low > 0) StatusRed else StatusGreen),
            )
        }
        "mes" -> {
            val plans by MockRepository.productionPlans.collectAsState()
            val running = plans.count { it.status == com.abm.erp.data.ProductionPlanStatus.IN_PRODUCTION }
            val completed = plans.count { it.status == com.abm.erp.data.ProductionPlanStatus.COMPLETED }
            listOf(
                Triple("Plans", "${plans.size}", TextPrimary),
                Triple("Running", "$running", StatusBlue),
                Triple("Completed", "$completed", StatusGreen),
            )
        }
        "fms" -> {
            val collections by MockRepository.partyCollections.collectAsState()
            val expenses by MockRepository.expenses.collectAsState()
            val dealers by MockRepository.dealers.collectAsState()
            val todayCollected = collections.filter { it.createdAt.toLocalDate() == today }.sumOf { it.amount }
            val todayExpense = expenses.filter {
                it.status == com.abm.erp.data.ExpenseStatus.APPROVED && it.createdAt.toLocalDate() == today
            }.sumOf { it.amount }
            listOf(
                Triple("Collection Today", "৳${"%,.0f".format(todayCollected)}", StatusGreen),
                Triple("Expense Today", "৳${"%,.0f".format(todayExpense)}", StatusRed),
                Triple("Outstanding", "৳${"%,.0f".format(dealers.sumOf { it.dueBalance })}", StatusAmber),
            )
        }
        "scm" -> {
            val suppliers by com.abm.erp.data.PurchaseRepository.suppliers.collectAsState()
            val pos by com.abm.erp.data.PurchaseRepository.purchaseOrders.collectAsState()
            val prs by com.abm.erp.data.PurchaseRepository.purchaseRequests.collectAsState()
            val pending = prs.count { it.status == "PENDING" }
            listOf(
                Triple("Suppliers", "${suppliers.size}", TextPrimary),
                Triple("Pending Requests", "$pending", if (pending > 0) StatusAmber else StatusGreen),
                Triple("Open POs", "${pos.count { it.status == "SENT" || it.status == "PARTIALLY_RECEIVED" }}", StatusBlue),
            )
        }
        "wsp" -> {
            val approvals by MockRepository.approvals.collectAsState()
            val notifications by MockRepository.notifications.collectAsState()
            val pending = approvals.count { it.status == com.abm.erp.data.ApprovalStatus.PENDING }
            val unread = notifications.count { !it.isRead }
            listOf(
                Triple("Pending Approvals", "$pending", if (pending > 0) StatusAmber else StatusGreen),
                Triple("Unread", "$unread", if (unread > 0) StatusAmber else StatusGreen),
            )
        }
        else -> emptyList()
    }
}
