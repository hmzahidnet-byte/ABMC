package com.abm.erp.data

import android.content.Context
import androidx.room.withTransaction
import com.abm.erp.data.room.AppDatabase
import com.abm.erp.data.room.ProductEntity
import com.abm.erp.data.room.StockLevelEntity
import com.abm.erp.data.room.StockMovementEntity
import com.abm.erp.data.room.WarehouseEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset

/**
 * Inventory / Stock Management module. Kept as its own repository object
 * (rather than folded into MockRepository) so modules stay decoupled as the
 * app grows — Sales/Dealer/Production screens will read stock levels from
 * here directly once they're wired up (Phase 3+).
 *
 * Call InventoryRepository.init(context) once, from ABMApplication.onCreate.
 */
object InventoryRepository {

    private lateinit var db: AppDatabase
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ---- Cross-device sync for Products (same pattern as MockRepository's Sales/Dealer/HR sync) ----
    private val firestoreDb by lazy { com.google.firebase.firestore.FirebaseFirestore.getInstance() }
    private var syncCompanyId: String? = null
    private var productsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var warehousesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var stockMovementsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var stockLevelsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

    private fun syncCollection(name: String) =
        firestoreDb.collection("companies").document(CompanyContext.current.value ?: "_unset").collection(name)

    /** Manual "Retry" entry point — see MockRepository.forceResync for why this is needed. */
    fun forceResync(companyId: String) {
        syncCompanyId = null
        startCrossDeviceSync(companyId)
    }

    /** Call once the company code is known — same call site as MockRepository.startCrossDeviceSync. */
    fun startCrossDeviceSync(companyId: String) {
        if (!CompanyContext.validateAndRecord(companyId)) {
            android.util.Log.w("InventoryRepository", "startCrossDeviceSync refused invalid companyId '$companyId' — sync not started")
            return
        }
        if (companyId == syncCompanyId) return
        syncCompanyId = companyId
        listenProductsRemote()
        listenWarehousesRemote()
        listenStockMovementsRemote()
        listenStockCountsRemote()
        listenStockLevelsRemote()
        listenCategoriesRemote()
        listenBrandsRemote()
        listenDamageReportsRemote()
        listenStockTransfersRemote()
        listenInventoryLotsRemote()
    }

    private fun listenCategoriesRemote() {
        syncCollection("productCategories").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("InventoryRepository", "categories sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.ProductCategoryEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.productCategoryDao().upsertAll(list) }
        }
    }

    private fun listenBrandsRemote() {
        syncCollection("productBrands").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("InventoryRepository", "brands sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.ProductBrandEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.productBrandDao().upsertAll(list) }
        }
    }

    private fun listenDamageReportsRemote() {
        syncCollection("damageReports").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("InventoryRepository", "damageReports sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.DamageReportEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.damageReportDao().upsertAll(list) }
        }
    }

    private fun listenStockTransfersRemote() {
        syncCollection("stockTransfers").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("InventoryRepository", "stockTransfers sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.StockTransferEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.stockTransferDao().upsertAll(list) }
        }
    }

    private fun listenInventoryLotsRemote() {
        syncCollection("inventoryLots").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("InventoryRepository", "inventoryLots sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.InventoryLotEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.inventoryLotDao().upsertAll(list) }
        }
    }

    private fun listenProductsRemote() {
        productsListenerReg?.remove()
        productsListenerReg = syncCollection("products").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("InventoryRepository", "products sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(ProductEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.productDao().upsertAll(list) }
        }
    }

    private fun listenWarehousesRemote() {
        warehousesListenerReg?.remove()
        warehousesListenerReg = syncCollection("warehouses").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("InventoryRepository", "warehouses sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(WarehouseEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.warehouseDao().upsertAll(list) }
        }
    }

    private fun pushProduct(e: ProductEntity) {
        syncCollection("products").document(e.id).set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("InventoryRepository", "pushProduct failed", it) }
    }

    private fun pushWarehouse(e: WarehouseEntity) {
        syncCollection("warehouses").document(e.id).set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("InventoryRepository", "pushWarehouse failed", it) }
    }


    private var stockCountsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private fun listenStockCountsRemote() {
        stockCountsListenerReg?.remove()
        stockCountsListenerReg = syncCollection("stockCounts").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("InventoryRepository", "stockCounts sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.StockCountEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.stockCountDao().upsertAll(list) }
        }
    }

    private fun listenStockMovementsRemote() {
        stockMovementsListenerReg?.remove()
        stockMovementsListenerReg = syncCollection("stockMovements").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("InventoryRepository", "stockMovements sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(StockMovementEntity::class.java) }.orEmpty()
            // পরিমাণ এখান থেকে recompute করা হয় না — সেটা listenStockLevelsRemote()-এর atomic
            // increment থেকেই আসে (Dealer stock/due-এর মতো একই প্রমাণিত পদ্ধতি), তাই একই
            // movement দুইবার (নিজের ডিভাইস + remote echo) গোনার ঝুঁকি নেই। এখানে শুধু
            // ইতিহাস/audit-trail হিসেবে Room-এ মিশিয়ে রাখা হয়।
            if (list.isNotEmpty()) scope.launch { db.stockDao().upsertMovements(list) }
        }
    }

    private fun pushStockMovement(e: StockMovementEntity) {
        syncCollection("stockMovements").document(e.id).set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("InventoryRepository", "pushStockMovement failed", it) }
    }

    private fun pushStockLevelIncrement(productId: String, warehouseId: String, delta: Double) {
        val data: MutableMap<String, Any> = hashMapOf(
            "productId" to productId,
            "warehouseId" to warehouseId,
            "quantityOnHand" to com.google.firebase.firestore.FieldValue.increment(delta),
        )
        syncCollection("stockLevels").document("${productId}_$warehouseId")
            .set(data, com.google.firebase.firestore.SetOptions.merge())
            .addOnFailureListener { com.abm.erp.config.AppLog.w("InventoryRepository", "pushStockLevelIncrement failed", it) }
    }

    private fun listenStockLevelsRemote() {
        stockLevelsListenerReg?.remove()
        stockLevelsListenerReg = syncCollection("stockLevels").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("InventoryRepository", "stockLevels sync listener error", err); return@addSnapshotListener }
            snap?.documents?.forEach { doc ->
                val pid = doc.getString("productId") ?: return@forEach
                val wid = doc.getString("warehouseId") ?: return@forEach
                val qty = doc.getDouble("quantityOnHand") ?: return@forEach
                scope.launch { db.stockDao().upsertLevel(StockLevelEntity(pid, wid, qty)) }
            }
        }
    }

    fun init(context: Context) {
        if (::db.isInitialized) return
        db = AppDatabase.getInstance(context)
        seedIfEmpty()
        wireFlows()
    }

    lateinit var products: StateFlow<List<Product>>
        private set

    lateinit var warehouses: StateFlow<List<Warehouse>>
        private set

    lateinit var stockLevels: StateFlow<List<StockLevelView>>
        private set
    lateinit var stockCounts: StateFlow<List<StockCount>>
        private set

    lateinit var movements: StateFlow<List<StockMovement>>
        private set

    val lowStockCount: Int get() = stockLevels.value.count { it.isLowStock }

    /**
     * Foundation Layer enforcement: action permission (canCreate on "inv"),
     * basic validation, and duplicate-prevention on sku+name — the same
     * pattern as MockRepository.createDealer/createRetailer.
     */
    /**
     * Foundation 5, Sections 1-7 — real Stock Intelligence orchestration.
     * Consumption comes from actual dispatched SalesInvoiceLineItem
     * quantities (real ERP data), not a guess — "Never use fake AI
     * predictions or random values."
     */
    data class StockIntelligenceReport(
        val productId: String, val productName: String, val currentStock: Double,
        val consumption: com.abm.erp.inventory.StockIntelligence.ConsumptionRate,
        val stockOut: com.abm.erp.inventory.StockIntelligence.StockOutPrediction,
        val safetyStock: com.abm.erp.inventory.StockIntelligence.SafetyStockLevels,
        val reorderQty: Double, val movementClass: com.abm.erp.inventory.StockIntelligence.MovementClass,
    )

    /** Real dispatched-quantity history for one product, from actual SalesInvoice line items across all non-deleted invoices — the one real consumption data source, not duplicated elsewhere. */
    private fun dispatchedQuantitiesFor(productId: String): List<Pair<java.time.LocalDateTime, Double>> {
        return MockRepository.salesInvoices.value.filter { !it.isDeleted }.flatMap { inv ->
            inv.lineItems.filter { it.productId == productId }.map { inv.createdAt to it.qty.toDouble() }
        }
    }

    /** Real incoming purchase quantity for a product — sum of not-yet-fully-received PO lines. */
    private fun incomingPurchaseQtyFor(productId: String): Double =
        PurchaseRepository.purchaseOrders.value.filter { !it.isDeleted && it.status in setOf("SENT", "PARTIALLY_RECEIVED") }
            .flatMap { it.lineItems }.filter { it.productId == productId }.sumOf { it.qty }

    /** Real production-pipeline quantity — matched by finished-product name since ProductionOrder has no productId FK (an honest limitation of the existing schema, not fabricated). */
    private fun productionPipelineQtyFor(productName: String): Double =
        MockRepository.productionOrders.value.filter { it.status in setOf("PLANNED", "IN_PROGRESS") && it.finishedProductName == productName }.sumOf { it.targetQty }

    fun computeStockIntelligence(
        productId: String, warehouseId: String? = null, thresholds: com.abm.erp.inventory.StockIntelligence.Thresholds = stockIntelligenceThresholds,
        precomputedDispatch: Map<String, List<Pair<java.time.LocalDateTime, Double>>>? = null,
        precomputedIncoming: Map<String, Double>? = null, precomputedPipeline: Map<String, Double>? = null,
    ): StockIntelligenceReport? {
        val product = products.value.firstOrNull { it.id == productId } ?: return null
        val relevantLevels = stockLevels.value.filter { it.productId == productId && (warehouseId == null || it.warehouseId == warehouseId) }
        val currentStock = relevantLevels.sumOf { it.quantityOnHand }
        // RC-1 perf fix — this used to call dispatchedQuantitiesFor(productId)
        // TWICE (once for consumption, once for last-movement), each a full
        // invoice-list scan, even for a SINGLE product. Computed once here.
        // When a caller iterating many products passes precomputed maps
        // (built once, grouped by product), no per-product scan happens at all.
        val dispatched = precomputedDispatch?.get(productId) ?: dispatchedQuantitiesFor(productId)
        val consumption = com.abm.erp.inventory.StockIntelligence.computeConsumptionRate(dispatched)
        val stockOut = com.abm.erp.inventory.StockIntelligence.predictStockOut(currentStock, consumption)
        val safety = com.abm.erp.inventory.StockIntelligence.computeSafetyStock(consumption, thresholds)
        val lastMovement = dispatched.maxOfOrNull { it.first }
        val daysSinceMovement = lastMovement?.let { java.time.Duration.between(it, java.time.LocalDateTime.now()).toDays() }
        val movementClass = com.abm.erp.inventory.StockIntelligence.classifyMovement(consumption, currentStock, daysSinceMovement, thresholds)
        val reorderQty = com.abm.erp.inventory.StockIntelligence.computeReorderQuantity(
            forecastDemand = consumption.weeklyAvg, safetyStock = safety.recommended, leadTimeDays = thresholds.leadTimeDays,
            dailyConsumption = consumption.dailyAvg, availableStock = currentStock,
            incomingPurchaseQty = precomputedIncoming?.get(productId) ?: incomingPurchaseQtyFor(productId),
            productionPipelineQty = precomputedPipeline?.get(product.name) ?: productionPipelineQtyFor(product.name),
        )
        return StockIntelligenceReport(productId, product.name, currentStock, consumption, stockOut, safety, reorderQty, movementClass)
    }

    /** RC-1 perf fix — real grouped pre-computation, built once per bulk call instead of once per product. */
    private fun buildDispatchMap(): Map<String, List<Pair<java.time.LocalDateTime, Double>>> =
        MockRepository.salesInvoices.value.filter { !it.isDeleted }
            .flatMap { inv -> inv.lineItems.map { it.productId to (inv.createdAt to it.qty.toDouble()) } }
            .groupBy({ it.first }, { it.second })

    private fun buildIncomingMap(): Map<String, Double> =
        PurchaseRepository.purchaseOrders.value.filter { !it.isDeleted && it.status in setOf("SENT", "PARTIALLY_RECEIVED") }
            .flatMap { it.lineItems }.groupBy { it.productId }.mapValues { (_, lines) -> lines.sumOf { it.qty } }

    private fun buildPipelineMap(): Map<String, Double> =
        MockRepository.productionOrders.value.filter { it.status in setOf("PLANNED", "IN_PROGRESS") }
            .groupBy { it.finishedProductName }.mapValues { (_, orders) -> orders.sumOf { it.targetQty } }

    /** Section 11 — Purchase Recommendation: real products needing reorder, sorted by urgency (soonest stock-out first). */
    data class PurchaseRecommendation(val productId: String, val productName: String, val recommendedQty: Double, val priority: String, val reason: String, val daysRemaining: Double?)
    fun purchaseRecommendations(thresholds: com.abm.erp.inventory.StockIntelligence.Thresholds = stockIntelligenceThresholds): List<PurchaseRecommendation> {
        val dispatchMap = buildDispatchMap(); val incomingMap = buildIncomingMap(); val pipelineMap = buildPipelineMap()
        return products.value.filter { !it.isDeleted && it.isActive }.mapNotNull { p ->
            val report = computeStockIntelligence(p.id, thresholds = thresholds, precomputedDispatch = dispatchMap, precomputedIncoming = incomingMap, precomputedPipeline = pipelineMap) ?: return@mapNotNull null
            if (report.reorderQty <= 0.0) return@mapNotNull null
            val priority = when {
                report.stockOut.daysRemaining != null && report.stockOut.daysRemaining <= thresholds.criticalSafetyStockDays -> "CRITICAL"
                report.stockOut.daysRemaining != null && report.stockOut.daysRemaining <= thresholds.safetyStockDays -> "HIGH"
                else -> "NORMAL"
            }
            PurchaseRecommendation(p.id, p.name, report.reorderQty, priority, "Reorder needed: ${report.reorderQty.toInt()} ${p.unit}, stock-out in ${report.stockOut.daysRemaining?.toInt() ?: "unknown"} days", report.stockOut.daysRemaining)
        }.sortedBy { it.daysRemaining ?: Double.MAX_VALUE }
    }

    /** Section 10 — Production Recommendation: same reorder math, applied to finished goods that ARE produced in-house (has an active BOM). */
    data class ProductionRecommendation(val productId: String, val productName: String, val recommendedQty: Double, val priority: String, val reason: String)
    fun productionRecommendations(bomProductNames: Set<String>, thresholds: com.abm.erp.inventory.StockIntelligence.Thresholds = stockIntelligenceThresholds): List<ProductionRecommendation> {
        // Performance fix — was calling computeStockIntelligence() per
        // product with no precomputed maps, forcing a fresh full-catalog
        // scan inside EVERY call (same O(n×m) class of bug already fixed
        // in purchaseRecommendations/deadStockReport, missed here).
        val dispatchMap = buildDispatchMap(); val incomingMap = buildIncomingMap(); val pipelineMap = buildPipelineMap()
        return products.value.filter { !it.isDeleted && it.isActive && it.name in bomProductNames }.mapNotNull { p ->
            val report = computeStockIntelligence(p.id, thresholds = thresholds, precomputedDispatch = dispatchMap, precomputedIncoming = incomingMap, precomputedPipeline = pipelineMap) ?: return@mapNotNull null
            if (report.reorderQty <= 0.0) return@mapNotNull null
            val priority = if (report.stockOut.daysRemaining != null && report.stockOut.daysRemaining <= thresholds.criticalSafetyStockDays) "CRITICAL" else "NORMAL"
            ProductionRecommendation(p.id, p.name, report.reorderQty, priority, "Production needed: ${report.reorderQty.toInt()} ${p.unit}")
        }
    }

    /** Section 6 — real dead/slow-moving stock report across the whole catalog. */
    fun deadStockReport(thresholds: com.abm.erp.inventory.StockIntelligence.Thresholds = stockIntelligenceThresholds): List<StockIntelligenceReport> {
        val dispatchMap = buildDispatchMap(); val incomingMap = buildIncomingMap(); val pipelineMap = buildPipelineMap()
        return products.value.filter { !it.isDeleted && it.isActive }.mapNotNull { computeStockIntelligence(it.id, thresholds = thresholds, precomputedDispatch = dispatchMap, precomputedIncoming = incomingMap, precomputedPipeline = pipelineMap) }
            .filter { it.movementClass == com.abm.erp.inventory.StockIntelligence.MovementClass.DEAD || it.movementClass == com.abm.erp.inventory.StockIntelligence.MovementClass.VERY_SLOW }
    }

    /** Section 7 — real expiry intelligence from actual InventoryLot records, FEFO-ordered. */
    data class ExpiryReportLine(val lot: InventoryLot, val productName: String, val status: com.abm.erp.inventory.StockIntelligence.ExpiryStatus)
    fun expiryReport(thresholds: com.abm.erp.inventory.StockIntelligence.Thresholds = stockIntelligenceThresholds): List<ExpiryReportLine> {
        val productNameById = products.value.associate { it.id to it.name }
        val lines = inventoryLots.value.filter { it.qtyRemaining > 0 }.map { lot ->
            val productName = productNameById[lot.productId] ?: lot.productId
            ExpiryReportLine(lot, productName, com.abm.erp.inventory.StockIntelligence.classifyExpiry(lot.expiryDate, thresholds))
        }.filter { it.status != com.abm.erp.inventory.StockIntelligence.ExpiryStatus.FRESH }
        return com.abm.erp.inventory.StockIntelligence.fefoOrder(lines) { it.lot.expiryDate }
    }

    /** Section 8 — Warehouse Balancing: real transfer recommendation when one warehouse is critical/dead for a product while another has real surplus. */
    data class TransferRecommendation(val productId: String, val productName: String, val fromWarehouseId: String, val fromWarehouseName: String, val toWarehouseId: String, val toWarehouseName: String, val recommendedQty: Double, val reason: String, val priority: String)
    fun warehouseBalancingRecommendations(thresholds: com.abm.erp.inventory.StockIntelligence.Thresholds = stockIntelligenceThresholds): List<TransferRecommendation> {
        val recs = mutableListOf<TransferRecommendation>()
        // RC-1 perf fix — dispatchedQuantitiesFor() used to re-scan the
        // entire sales-invoice list once PER PRODUCT (O(products × invoices)).
        // Grouped once here instead.
        val dispatchedByProduct = buildDispatchMap()
        products.value.filter { !it.isDeleted && it.isActive }.forEach { p ->
            val levels = stockLevels.value.filter { it.productId == p.id }
            if (levels.size < 2) return@forEach
            val consumption = com.abm.erp.inventory.StockIntelligence.computeConsumptionRate(dispatchedByProduct[p.id].orEmpty())
            val avgConsumptionPerWarehouse = if (levels.isNotEmpty()) consumption.dailyAvg / levels.size else 0.0
            val safety = com.abm.erp.inventory.StockIntelligence.computeSafetyStock(com.abm.erp.inventory.StockIntelligence.ConsumptionRate(avgConsumptionPerWarehouse, avgConsumptionPerWarehouse * 7, avgConsumptionPerWarehouse * 30, consumption.sampleDays), thresholds)
            val deficit = levels.filter { it.quantityOnHand < safety.minimum }
            val surplus = levels.filter { it.quantityOnHand > safety.recommended * 2 }
            deficit.forEach { d ->
                val source = surplus.maxByOrNull { it.quantityOnHand } ?: return@forEach
                if (source.warehouseId == d.warehouseId) return@forEach
                val transferable = ((source.quantityOnHand - safety.recommended) / 2).coerceAtMost(safety.recommended - d.quantityOnHand).coerceAtLeast(0.0)
                if (transferable <= 0) return@forEach
                recs += TransferRecommendation(
                    p.id, p.name, source.warehouseId, source.warehouseName, d.warehouseId, d.warehouseName, transferable,
                    "${d.warehouseName} below safety stock (${d.quantityOnHand.toInt()}), ${source.warehouseName} has surplus (${source.quantityOnHand.toInt()})",
                    if (d.quantityOnHand <= 0) "CRITICAL" else "NORMAL",
                )
            }
        }
        return recs
    }

    // Section 15 — Alert Engine. Reuses MockRepository.raiseLocationAlert-style notification, no parallel alert system.
    fun raiseStockAlerts(thresholds: com.abm.erp.inventory.StockIntelligence.Thresholds = stockIntelligenceThresholds) {
        val criticalPurchase = purchaseRecommendations(thresholds).filter { it.priority == "CRITICAL" }
        val expiredLots = expiryReport(thresholds).filter { it.status == com.abm.erp.inventory.StockIntelligence.ExpiryStatus.EXPIRED }
        val negativeStock = stockLevels.value.filter { it.quantityOnHand < 0 }
        criticalPurchase.forEach { r ->
            MockRepository.createNotification(com.abm.erp.data.NotificationCategory.APPROVAL, "Critical Stock: ${r.productName}", r.reason)
        }
        expiredLots.forEach { e ->
            MockRepository.createNotification(com.abm.erp.data.NotificationCategory.APPROVAL, "Expired Stock: ${e.productName}", "Batch ${e.lot.batchCode}: ${e.lot.qtyRemaining} units expired")
        }
        negativeStock.forEach { lvl ->
            MockRepository.createNotification(com.abm.erp.data.NotificationCategory.APPROVAL, "Negative Stock", "${lvl.productName} at ${lvl.warehouseName}: ${lvl.quantityOnHand}")
        }
        // Section 19 — audit the recommendation-generation event itself, not just the individual notifications.
        MockRepository.logAudit(
            "StockIntelligence", "global", "GENERATE_ALERTS",
            newValue = "critical=${criticalPurchase.size}, expired=${expiredLots.size}, negative=${negativeStock.size}",
        )
    }

    /** Section 13 — Retailer Demand: real trend from actual retailer ledger (DEBIT = sales), reusing Foundation 1's Retailer/PartyLedger — no duplicate demand model, no fabricated proxy numbers. */
    data class RetailerDemandInsight(val retailerId: String, val retailerName: String, val last30DaySales: Double, val previous30DaySales: Double, val trendPct: Double, val isGrowing: Boolean, val isInactive: Boolean, val isLost: Boolean)
    suspend fun retailerDemandInsights(): List<RetailerDemandInsight> {
        val now = java.time.LocalDateTime.now()
        // Part O fix — this used to call runBlocking PER RETAILER inside
        // the loop below (N retailers = N sequential blocking DB round-
        // trips on whatever thread called this). One real suspend fetch
        // of the whole ledger, then grouped/filtered in memory.
        val allLedger = MockRepository.allPartyLedgerEntriesSuspend()
        val ledgerByRetailer = allLedger.filter { it.partyType == PartyType.RETAILER && it.type == "DEBIT" }.groupBy { it.partyId }
        return MockRepository.retailers.value.filter { !it.isDeleted }.map { r ->
            val myLedger = ledgerByRetailer[r.id].orEmpty()
            val sales30 = myLedger.filter { it.createdAt.isAfter(now.minusDays(30)) }.sumOf { it.amount }
            val prevSales30 = myLedger.filter { it.createdAt.isAfter(now.minusDays(60)) && it.createdAt.isBefore(now.minusDays(30)) }.sumOf { it.amount }
            val trend = if (prevSales30 <= 0) (if (sales30 > 0) 100.0 else 0.0) else ((sales30 - prevSales30) / prevSales30 * 100)
            val isInactive = r.lastOrderDate == null || java.time.Duration.between(r.lastOrderDate, now).toDays() > 60
            val isLost = r.lastOrderDate != null && java.time.Duration.between(r.lastOrderDate, now).toDays() > 120
            RetailerDemandInsight(r.id, r.name, sales30, prevSales30, trend, trend >= 0, isInactive, isLost)
        }
    }

    /** Section 14 — Dealer Stock Health: real classification from actual dealer due/stock data (Foundation 1's Dealer model), not fabricated. */
    data class DealerStockHealthInsight(val dealerId: String, val dealerName: String, val health: com.abm.erp.inventory.StockIntelligence.StockHealth)
    fun dealerStockHealthInsights(): List<DealerStockHealthInsight> =
        MockRepository.dealers.value.filter { !it.isDeleted }.map { d ->
            val movement = if (d.stockUnits <= 0) com.abm.erp.inventory.StockIntelligence.MovementClass.DEAD else com.abm.erp.inventory.StockIntelligence.MovementClass.NORMAL
            val health = com.abm.erp.inventory.StockIntelligence.classifyStockHealth(d.stockUnits.toDouble(), 100.0, 1000.0, movement)
            DealerStockHealthInsight(d.id, d.name, health)
        }

    // Section 18 — centralized, settable thresholds (was: every call site used the Thresholds() default with no way to change it company-wide).
    var stockIntelligenceThresholds: com.abm.erp.inventory.StockIntelligence.Thresholds = com.abm.erp.inventory.StockIntelligence.Thresholds()
        private set

    fun updateStockIntelligenceThresholds(newThresholds: com.abm.erp.inventory.StockIntelligence.Thresholds, onRejected: (String) -> Unit = {}): Boolean {
        if (!PermissionManager.canCurrentUser("inv", PermissionAction.APPROVE)) { onRejected("আপনার role-এ Threshold পরিবর্তনের অনুমতি নেই।"); return false }
        val old = stockIntelligenceThresholds
        stockIntelligenceThresholds = newThresholds
        MockRepository.logAudit("StockIntelligenceSettings", "global", "UPDATE", oldValue = old, newValue = newThresholds)
        return true
    }

    fun addProduct(
        sku: String, name: String, unit: String, category: String, reorderThreshold: Double, defaultUnitPrice: Double,
        costPrice: Double = 0.0, photoUri: String? = null, barcodeValue: String = "", categoryId: String? = null, brandId: String? = null,
        // v113-137 — addProduct was missed by the earlier vague-rejection sweep
        // (it returns Unit, not a Boolean/nullable, so the scanner's pattern
        // didn't match it) — its 4 real rejection points were silent. Positioned
        // BEFORE onCreated, which must stay last so existing trailing-lambda
        // call sites keep compiling.
        onRejected: (String) -> Unit = {},
        // Needed so a caller can upload a photo AFTER creation, once the real id exists —
        // addProduct generates its own id internally, so there was no way to know it in
        // advance for a create→upload→attach sequence without this.
        onCreated: (String) -> Unit = {},
    ) {
        if (!PermissionManager.canCurrentUser("inv", PermissionAction.CREATE)) {
            MockRepository.logAudit("Product", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            onRejected("আপনার role-এ নতুন Product যোগ করার অনুমতি নেই।")
            return
        }
        if (sku.isBlank() || name.isBlank()) {
            com.abm.erp.config.AppLog.w("InventoryRepository", "addProduct rejected: blank sku/name")
            onRejected("SKU আর নাম দিন।")
            return
        }
        if (reorderThreshold < 0 || defaultUnitPrice < 0) {
            com.abm.erp.config.AppLog.w("InventoryRepository", "addProduct rejected: negative threshold/price")
            onRejected("Threshold বা দাম ঋণাত্মক হতে পারবে না।")
            return
        }
        val dedupKey = (sku.trim().lowercase() + "|" + name.trim().lowercase())
        scope.launch {
            if (db.productDao().countByDedupKey(dedupKey) > 0) {
                com.abm.erp.config.AppLog.w("InventoryRepository", "addProduct rejected: duplicate sku+name")
                onRejected("এই SKU + নাম দিয়ে আগে থেকেই একটা Product আছে।")
                return@launch
            }
            val entity = ProductEntity(
                id = java.util.UUID.randomUUID().toString(),
                sku = sku, name = name, unit = unit, category = category,
                reorderThreshold = reorderThreshold, defaultUnitPrice = defaultUnitPrice, costPrice = costPrice, photoUri = photoUri,
                dedupKey = dedupKey, createdBy = MockRepository.currentUser.name,
                barcodeValue = barcodeValue, categoryId = categoryId, brandId = brandId,
            )
            db.productDao().upsert(entity)
            pushProduct(entity)
            MockRepository.logAudit("Product", entity.id, "CREATE", newValue = entity)
            onCreated(entity.id)
        }
    }

    /**
     * v113-137 — Product EDIT, required by directive §9 (Chairman Product Control:
     * "product photo, name, category, base rate, unit, status — add, EDIT,
     * deactivate"). ProductDao already had `upsert`, but no repository function
     * exposed editing, so a Chairman could create and soft-delete a product but
     * never correct its name/price/category. Reuses the same real dedup rule as
     * addProduct (excluding the product's own row, so re-saving without a name
     * change isn't blocked by its own key) and writes a real audit entry carrying
     * the before/after, so a price change is traceable.
     */
    fun updateProduct(
        productId: String, sku: String, name: String, unit: String, category: String,
        reorderThreshold: Double, defaultUnitPrice: Double, costPrice: Double,
        onRejected: (String) -> Unit = {},
    ) {
        if (!PermissionManager.canCurrentUser("inv", PermissionAction.EDIT)) {
            MockRepository.logAudit("Product", productId, "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "EDIT")
            onRejected("আপনার role-এ Product সম্পাদনা করার অনুমতি নেই।")
            return
        }
        if (sku.isBlank() || name.isBlank()) { onRejected("SKU আর নাম দিন।"); return }
        if (reorderThreshold < 0 || defaultUnitPrice < 0 || costPrice < 0) { onRejected("Threshold বা দাম ঋণাত্মক হতে পারবে না।"); return }
        val existing = products.value.firstOrNull { it.id == productId }
        if (existing == null) { onRejected("এই Product খুঁজে পাওয়া যায়নি।"); return }
        val newDedupKey = (sku.trim().lowercase() + "|" + name.trim().lowercase())
        if (products.value.any { it.id != productId && !it.isDeleted && it.dedupKey == newDedupKey }) {
            onRejected("এই SKU + নাম দিয়ে অন্য একটা Product আগে থেকেই আছে।")
            return
        }
        scope.launch {
            // Built directly rather than via a `Product.toEntity()` — verified no such
            // extension exists in this codebase (checked before writing, not assumed).
            // Mirrors addProduct/duplicateProduct's own real ProductEntity construction,
            // preserving the fields this edit form does not expose (photo, barcode,
            // category/brand ids, creator) instead of silently blanking them.
            val updated = ProductEntity(
                id = productId,
                sku = sku, name = name, unit = unit, category = category,
                reorderThreshold = reorderThreshold, defaultUnitPrice = defaultUnitPrice, costPrice = costPrice,
                photoUri = existing.photoUri,
                dedupKey = newDedupKey, createdBy = existing.createdBy,
                barcodeValue = existing.barcodeValue, categoryId = existing.categoryId, brandId = existing.brandId,
            )
            db.productDao().upsert(updated)
            pushProduct(updated)
            MockRepository.logAudit("Product", productId, "EDIT", oldValue = "${existing.name} · ৳${existing.defaultUnitPrice}", newValue = "$name · ৳$defaultUnitPrice")
        }
    }

    /**
     * Persists a photo URL onto an existing product, after `MockRepository.uploadProductPhoto`
     * has already uploaded the file to Storage. Separate from `addProduct` because the upload
     * itself only returns a URL — nothing wrote it onto the product row, which is the
     * concrete reason product photos have not been settable after creation until now.
     */
    fun setProductPhoto(productId: String, photoUri: String) {
        if (!PermissionManager.canCurrentUser("inv", PermissionAction.EDIT)) {
            MockRepository.logAudit("Product", productId, "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "PHOTO_UPDATE")
            return
        }
        scope.launch {
            // ProductDao has no single-row fetch — same getAll().firstOrNull{} pattern
            // already used elsewhere in this codebase for the same reason.
            val existing = db.productDao().getAll().first().firstOrNull { it.id == productId } ?: return@launch
            val updated = existing.copy(photoUri = photoUri)
            db.productDao().upsert(updated)
            pushProduct(updated)
            MockRepository.logAudit("Product", productId, "PHOTO_UPDATE")
        }
    }

    /** Universal Action Menu: Duplicate — new id + "-COPY" suffixed SKU so the dedup check doesn't collide with the original. */
    fun duplicateProduct(productId: String, onRejected: (String) -> Unit = {}): DuplicateResult? {
        if (!PermissionManager.canCurrentUser("inv", PermissionAction.CREATE)) { onRejected("আপনার role-এ Product duplicate করার অনুমতি নেই।"); return null }
        val p = products.value.firstOrNull { it.id == productId } ?: run { onRejected("এই Product খুঁজে পাওয়া যায়নি।"); return null }
        val newId = java.util.UUID.randomUUID().toString()
        val newSku = "${p.sku}-COPY${System.currentTimeMillis().toString().takeLast(6)}"
        val dedupKey = (newSku.trim().lowercase() + "|" + p.name.trim().lowercase())
        scope.launch {
            val entity = ProductEntity(
                id = newId, sku = newSku, name = p.name, unit = p.unit, category = p.category,
                reorderThreshold = p.reorderThreshold, defaultUnitPrice = p.defaultUnitPrice, photoUri = p.photoUri,
                dedupKey = dedupKey, createdBy = MockRepository.currentUser.name,
                barcodeValue = "", categoryId = p.categoryId, brandId = p.brandId,
            )
            db.productDao().upsert(entity)
            pushProduct(entity)
            MockRepository.logAudit("Product", newId, "CREATE", newValue = entity)
        }
        return DuplicateResult(newId, "${p.name} ($newSku)")
    }

    fun deleteProduct(productId: String, onRejected: (String) -> Unit = {}) {
        if (!PermissionManager.canCurrentUser("inv", PermissionAction.DELETE)) {
            MockRepository.logAudit("Product", productId, "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "DELETE")
            onRejected("আপনার role-এ Product delete করার অনুমতি নেই।")
            return
        }
        scope.launch {
            val now = System.currentTimeMillis()
            db.productDao().softDelete(productId, now, MockRepository.currentUser.name)
            MockRepository.logAudit("Product", productId, "DELETE")
        }
    }

    fun restoreProduct(productId: String) {
        if (!PermissionManager.canCurrentUser("inv", PermissionAction.DELETE)) {
            MockRepository.logAudit("Product", productId, "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "RESTORE")
            return
        }
        scope.launch {
            db.productDao().restore(productId)
            MockRepository.logAudit("Product", productId, "RESTORE")
        }
    }

    fun addWarehouse(name: String, zone: String, stockCategory: StockCategory = StockCategory.STORE) {
        scope.launch {
            val entity = WarehouseEntity(id = java.util.UUID.randomUUID().toString(), name = name, zone = zone, stockCategory = stockCategory.name)
            db.warehouseDao().upsert(entity)
            pushWarehouse(entity)
        }
    }

    /**
     * Section 6 — Production and Warehouse Stock buckets. Finds the one
     * system-managed warehouse for this category (Raw Material / Work In
     * Progress / In-Transit / Damaged-Hold-Returned), creating it on first
     * use with a fixed, predictable id so later calls always find the
     * same one rather than accumulating duplicates. Unlike addWarehouse,
     * this is suspend and returns the id synchronously, since callers
     * (issueRawMaterial, dispatchWarehouseTransfer, etc) need it
     * immediately within the same operation.
     */
    suspend fun getOrCreateSystemWarehouse(category: StockCategory, companyId: String): String {
        val systemId = "SYS-${category.name}-$companyId"
        val existing = db.warehouseDao().getAll().first().firstOrNull { it.id == systemId }
        if (existing != null) return systemId
        val label = when (category) {
            StockCategory.RAW_MATERIAL -> "Raw Material Store"
            StockCategory.WORK_IN_PROGRESS -> "Work In Progress"
            StockCategory.IN_TRANSIT -> "In-Transit (Goods on the Way)"
            StockCategory.DAMAGED_HOLD_RETURNED -> "Damaged / Hold / Returned"
            StockCategory.PRODUCTION -> "Factory Finished Goods"
            StockCategory.STORE -> "Main Warehouse"
        }
        val entity = WarehouseEntity(id = systemId, name = label, zone = "SYSTEM", stockCategory = category.name)
        db.warehouseDao().upsert(entity)
        pushWarehouse(entity)
        return systemId
    }

    /** Adds stock (e.g. purchase, production output). Always succeeds. */
    /** v86 - Stock Reservation: real reserved-qty tracking, not just a UI label. reserveStock checks availableQty (on-hand minus already-reserved) before committing, so it can't over-reserve. releaseStock is called when an order is cancelled or converted to an actual stockOut. */
    fun reserveStock(productId: String, warehouseId: String, quantity: Double): Boolean {
        val level = stockLevels.value.firstOrNull { it.productId == productId && it.warehouseId == warehouseId } ?: return false
        if (level.availableQty < quantity) return false
        scope.launch { db.stockDao().adjustReservedQty(productId, warehouseId, quantity) }
        return true
    }

    fun releaseStock(productId: String, warehouseId: String, quantity: Double) {
        scope.launch { db.stockDao().adjustReservedQty(productId, warehouseId, -quantity) }
    }

    /** Section 6 — real Variance Report, the distinct "Physical vs System" comparison step, not just implicit per-line data. */
    data class VarianceReportLine(
        val productId: String, val productName: String, val batchCode: String?, val systemQty: Double, val countedQty: Double,
        val varianceQty: Double, val variancePct: Double, val systemCartons: Int, val countedCartons: Int, val varianceCartons: Int, val severity: String,
    )
    data class VarianceReport(val countNo: String, val warehouseName: String, val lines: List<VarianceReportLine>, val totalVarianceValue: Double, val significantVarianceCount: Int)

    fun computeVarianceReport(stockCount: StockCount): VarianceReport {
        val reportLines = stockCount.lines.filter { it.hasVariance }.map { line ->
            val severity = when {
                kotlin.math.abs(line.variancePct) >= 10 -> "HIGH"
                kotlin.math.abs(line.variancePct) >= 3 -> "MEDIUM"
                else -> "LOW"
            }
            VarianceReportLine(
                productId = line.productId, productName = line.productName, batchCode = line.batchCode,
                systemQty = line.systemQty, countedQty = line.countedQty, varianceQty = line.varianceQty, variancePct = line.variancePct,
                systemCartons = line.systemCartons, countedCartons = line.countedCartons, varianceCartons = line.varianceCartons, severity = severity,
            )
        }
        val unitCosts = products.value.associateBy({ it.id }, { it.costPrice })
        val totalValue = reportLines.sumOf { (unitCosts[it.productId] ?: 0.0) * it.varianceQty }
        return VarianceReport(
            countNo = stockCount.countNo, warehouseName = stockCount.warehouseName, lines = reportLines,
            totalVarianceValue = totalValue, significantVarianceCount = reportLines.count { it.severity != "LOW" },
        )
    }

    /** v86, Module 6 — Stock-Count workflow: Draft -> Submitted -> Approved (applies real stock adjustment via existing adjustStockToCount, one call per counted line) -> Adjusted. */
    fun createStockCount(warehouseId: String, warehouseName: String, lines: List<StockCountLine>): StockCount {
        val count = StockCount(id = java.util.UUID.randomUUID().toString(), countNo = "SC-${1000 + stockCounts.value.size + 1}", warehouseId = warehouseId, warehouseName = warehouseName, lines = lines, createdBy = MockRepository.currentUser.name)
        scope.launch {
            val entity = count.toEntity()
            db.stockCountDao().upsert(entity)
            syncCollection("stockCounts").document(entity.id).set(entity).addOnFailureListener { com.abm.erp.config.AppLog.w("InventoryRepository", "push stockCount failed", it) }
            MockRepository.logAudit("StockCount", count.id, "CREATE", newValue = count)
        }
        return count
    }

    fun submitStockCount(id: String) {
        scope.launch {
            db.stockCountDao().setStatus(id, "SUBMITTED")
            syncCollection("stockCounts").document(id).update("status", "SUBMITTED")
            MockRepository.logAudit("StockCount", id, "SUBMIT")
        }
    }

    /** Approving actually applies the count — each line's countedQty becomes the new system quantity via the existing, real adjustStockToCount function (no separate/duplicate stock-write path). */
    fun approveStockCount(id: String, onRejected: (String) -> Unit = {}): Boolean {
        if (!PermissionManager.canCurrentUser("inv", PermissionAction.APPROVE)) {
            MockRepository.logAudit("StockCount", id, "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "APPROVE")
            onRejected("আপনার role-এ Stock Count approve করার অনুমতি নেই।")
            return false
        }
        val count = stockCounts.value.firstOrNull { it.id == id } ?: run { onRejected("এই Stock Count খুঁজে পাওয়া যায়নি।"); return false }
        if (count.status != "SUBMITTED") {
            MockRepository.logAudit("StockCount", id, "DENY", oldValue = count.status, newValue = "APPROVE — must be SUBMITTED, already ${count.status}")
            onRejected("এটা SUBMITTED না, বর্তমান status: ${count.status}।")
            return false
        }
        if (MockRepository.isDateLocked(java.time.LocalDate.now())) {
            MockRepository.logAudit("StockCount", id, "DENY_LOCKED_PERIOD", newValue = "APPROVE_ATTEMPT")
            onRejected("আজকের তারিখের হিসাব বন্ধ — approve করা যাবে না।")
            return false
        }
        scope.launch {
            // Critical fix — grouping by productId and summing countedQty
            // across all batch-lines BEFORE adjusting. Calling
            // adjustStockToCount once per raw line was wrong: ADJUST sets
            // an ABSOLUTE stock level, so a second batch-line for the same
            // product would silently overwrite/discard the first batch's
            // counted adjustment instead of both contributing to the total.
            count.lines.groupBy { it.productId }.forEach { (productId, linesForProduct) ->
                val totalCounted = linesForProduct.sumOf { it.countedQty }
                adjustStockToCount(productId, count.warehouseId, totalCounted, "Stock count ${count.countNo}")
            }
            val now = System.currentTimeMillis()
            db.stockCountDao().approve(id, "ADJUSTED", MockRepository.currentUser.name, now)
            syncCollection("stockCounts").document(id).update(mapOf("status" to "ADJUSTED", "approvedBy" to MockRepository.currentUser.name, "approvedAtEpochMillis" to now))
            MockRepository.logAudit("StockCount", id, "APPROVE_AND_ADJUST")
        }
        return true
    }

    fun stockIn(productId: String, warehouseId: String, quantity: Double, reason: String) {
        scope.launch { adjustStock(productId, warehouseId, quantity, MovementType.IN, reason) }
    }

    /**
     * Removes stock (e.g. dealer fulfillment, damage). Suspends the caller so the
     * UI can react to whether it actually happened — returns false instead of
     * going negative if there isn't enough on hand.
     */
    suspend fun stockOut(productId: String, warehouseId: String, quantity: Double, reason: String): Boolean {
        val current = db.stockDao().getLevel(productId, warehouseId)?.quantityOnHand ?: 0.0
        if (current < quantity) return false
        adjustStock(productId, warehouseId, quantity, MovementType.OUT, reason)
        return true
    }

    /**
     * Module 3 — Stock Adjustment: sets the shelf count to a physically
     * counted absolute quantity (not a delta like stockIn/stockOut), for
     * reconciling a stock-take against what Room/Firestore currently show.
     * Uses the same MovementType.ADJUST the private adjustStock() already
     * supported but nothing ever called.
     */
    suspend fun adjustStockToCount(productId: String, warehouseId: String, actualCount: Double, reason: String, onRejected: (String) -> Unit = {}): Boolean {
        if (!PermissionManager.canCurrentUser("inv", PermissionAction.EDIT)) {
            MockRepository.logAudit("StockAdjustment", productId, "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "EDIT")
            onRejected("আপনার role-এ Stock adjust করার অনুমতি নেই।")
            return false
        }
        if (actualCount < 0.0) {
            com.abm.erp.config.AppLog.w("InventoryRepository", "adjustStockToCount rejected: counted quantity cannot be negative")
            onRejected("Count ঋণাত্মক হতে পারবে না।")
            return false
        }
        var before = 0.0
        db.withTransaction {
            before = db.stockDao().getLevel(productId, warehouseId)?.quantityOnHand ?: 0.0
            adjustStock(productId, warehouseId, actualCount, MovementType.ADJUST, reason.ifBlank { "Stock count adjustment" })
            MockRepository.logAuditAwaited("StockAdjustment", productId, "UPDATE", oldValue = before, newValue = actualCount)
        }
        return true
    }

    suspend fun adjustStock(productId: String, warehouseId: String, quantity: Double, type: MovementType, reason: String, batchCode: String? = null, unitCost: Double = 0.0) {
        var finalLevel = 0.0
        db.withTransaction {
            val current = db.stockDao().getLevel(productId, warehouseId)?.quantityOnHand ?: 0.0
            val delta = when (type) {
                MovementType.IN -> quantity
                MovementType.OUT -> -quantity
                MovementType.ADJUST -> quantity - current
            }
            val updated = current + delta
            finalLevel = updated
            db.stockDao().upsertLevel(StockLevelEntity(productId, warehouseId, updated))
            pushStockLevelIncrement(productId, warehouseId, delta)
            val movement = StockMovementEntity(
                id = java.util.UUID.randomUUID().toString(),
                productId = productId, warehouseId = warehouseId, type = type.name,
                quantity = quantity, reason = reason, batchCode = batchCode, unitCost = unitCost, timestampEpochMillis = System.currentTimeMillis(),
            )
            db.stockDao().insertMovement(movement)
            pushStockMovement(movement)
        }
        // Notification Framework — Low Stock: only fires on OUT/ADJUST (the movements that can actually cross the threshold downward), not every IN.
        if (type != MovementType.IN) {
            val product = products.value.firstOrNull { it.id == productId }
            if (product != null && finalLevel <= product.reorderThreshold) {
                MockRepository.createNotification(NotificationCategory.LOW_STOCK, "Low Stock: ${product.name}", "${product.name} — ${"%.1f".format(finalLevel)} ${product.unit} left (reorder at ${"%.1f".format(product.reorderThreshold)})")
            }
        }
    }

    // ================= Module 3 extras: Category, Brand, Expiry, Damage, Transfer =================

    lateinit var categories: StateFlow<List<ProductCategory>>
        private set
    lateinit var brands: StateFlow<List<ProductBrand>>
        private set
    lateinit var damageReports: StateFlow<List<DamageReport>>
        private set
    lateinit var stockTransfers: StateFlow<List<StockTransfer>>
        private set
    lateinit var inventoryLots: StateFlow<List<InventoryLot>>
        private set

    fun createCategory(name: String) {
        scope.launch {
            val entity = com.abm.erp.data.room.ProductCategoryEntity(id = java.util.UUID.randomUUID().toString(), name = name)
            db.productCategoryDao().upsert(entity)
            syncCollection("productCategories").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("InventoryRepository", "push category failed", it) }
        }
    }

    fun createBrand(name: String) {
        scope.launch {
            val entity = com.abm.erp.data.room.ProductBrandEntity(id = java.util.UUID.randomUUID().toString(), name = name)
            db.productBrandDao().upsert(entity)
            syncCollection("productBrands").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("InventoryRepository", "push brand failed", it) }
        }
    }

    /**
     * Stock-in WITH expiry tracking — creates a lot record (FEFO: first
     * expiry, first out) alongside the normal stock-level increment.
     * Regular stockIn() (no expiry) still works for non-perishable stock —
     * this is additive, not a replacement.
     */
    fun stockInWithExpiry(productId: String, warehouseId: String, quantity: Double, reason: String, expiryDate: java.time.LocalDateTime?, batchCode: String): Boolean {
        // Section 20 — "Batch inconsistency" / "Warehouse mismatch" prevention: reject a non-positive quantity and a warehouseId that doesn't exist, rather than silently creating an inconsistent lot record.
        if (quantity <= 0.0) {
            com.abm.erp.config.AppLog.w("InventoryRepository", "stockInWithExpiry rejected: quantity must be positive")
            return false
        }
        if (warehouses.value.none { it.id == warehouseId }) {
            com.abm.erp.config.AppLog.w("InventoryRepository", "stockInWithExpiry rejected: warehouse '$warehouseId' does not exist")
            return false
        }
        scope.launch {
            adjustStock(productId, warehouseId, quantity, MovementType.IN, reason)
            val lot = com.abm.erp.data.room.InventoryLotEntity(
                id = java.util.UUID.randomUUID().toString(), productId = productId, warehouseId = warehouseId,
                batchCode = batchCode.ifBlank { "LOT-${System.currentTimeMillis().toString().takeLast(8)}${(10..99).random()}" }, qtyRemaining = quantity,
                expiryDateEpochMillis = expiryDate?.toInstant(java.time.ZoneOffset.UTC)?.toEpochMilli(),
                receivedAtEpochMillis = System.currentTimeMillis(),
            )
            db.inventoryLotDao().upsert(lot)
            syncCollection("inventoryLots").document(lot.id).set(lot)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("InventoryRepository", "push lot failed", it) }
        }
        return true
    }

    /** Damage Tracking — explicitly tagged stock-out, distinct from a normal fulfillment stockOut, with its own DamageReport record for reporting. Genuinely suspend/transactional: stock adjustment, the DamageReport row, and the audit log entry all happen inside one Room transaction, and the caller only gets `true` back after all of that has actually committed — never optimistically before the work finishes. */
    suspend fun reportDamage(productId: String, productName: String, warehouseId: String, qty: Double, reason: String, onRejected: (String) -> Unit = {}): Boolean {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.DELETE)) {
            MockRepository.logAudit("DamageReport", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            onRejected("আপনার role-এ Damage report করার অনুমতি নেই।")
            return false
        }
        if (qty <= 0.0) {
            com.abm.erp.config.AppLog.w("InventoryRepository", "reportDamage rejected: quantity must be positive")
            onRejected("Quantity শূন্যের বেশি হতে হবে।")
            return false
        }
        var report: com.abm.erp.data.room.DamageReportEntity? = null
        db.withTransaction {
            // Real, transactional stock check — not the cached StateFlow — so a concurrent stock-out
            // between two near-simultaneous damage reports can't both pass and over-deduct.
            val current = db.stockDao().getLevel(productId, warehouseId)?.quantityOnHand ?: 0.0
            if (current < qty) {
                com.abm.erp.config.AppLog.w("InventoryRepository", "reportDamage rejected: insufficient or concurrently changed stock")
                onRejected("স্টক যথেষ্ট নেই।")
                return@withTransaction
            }
            adjustStock(productId, warehouseId, qty, MovementType.OUT, "Damage: $reason")
            val r = com.abm.erp.data.room.DamageReportEntity(
                id = java.util.UUID.randomUUID().toString(), productId = productId, productName = productName,
                warehouseId = warehouseId, qty = qty, reason = reason, reportedBy = MockRepository.currentUser.name,
                createdAtEpochMillis = System.currentTimeMillis(),
            )
            db.damageReportDao().upsert(r)
            MockRepository.logAuditAwaited("DamageReport", r.id, "CREATE", newValue = "$productName × $qty — $reason")
            report = r
        }
        val saved = report ?: return false
        // Firestore push is best-effort and happens after the local transaction has already committed —
        // network calls never gate the true/false result, matching this app's offline-first design.
        syncCollection("damageReports").document(saved.id).set(saved)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("InventoryRepository", "push damageReport failed", it) }
        return true
    }

    /** Stock Transfer — moves stock between two of our own warehouses atomically (stock-out at source + stock-in at destination), with one audit-friendly StockTransfer record instead of two disconnected movements. */
    suspend fun transferStock(productId: String, productName: String, fromWarehouseId: String, toWarehouseId: String, qty: Double): Boolean {
        val current = db.stockDao().getLevel(productId, fromWarehouseId)?.quantityOnHand ?: 0.0
        if (current < qty) return false
        db.withTransaction {
            adjustStock(productId, fromWarehouseId, qty, MovementType.OUT, "Transfer to $toWarehouseId")
            adjustStock(productId, toWarehouseId, qty, MovementType.IN, "Transfer from $fromWarehouseId")
        }
        val transfer = com.abm.erp.data.room.StockTransferEntity(
            id = java.util.UUID.randomUUID().toString(), productId = productId, productName = productName,
            fromWarehouseId = fromWarehouseId, toWarehouseId = toWarehouseId, qty = qty,
            createdBy = MockRepository.currentUser.name, createdAtEpochMillis = System.currentTimeMillis(),
        )
        db.stockTransferDao().upsert(transfer)
        syncCollection("stockTransfers").document(transfer.id).set(transfer)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("InventoryRepository", "push stockTransfer failed", it) }
        MockRepository.logAudit("StockTransfer", transfer.id, "CREATE", newValue = "$productName × $qty: $fromWarehouseId -> $toWarehouseId")
        MockRepository.createNotification(NotificationCategory.STOCK_TRANSFER, "Stock Transfer", "$productName × ${"%.1f".format(qty)}: $fromWarehouseId → $toWarehouseId")
        return true
    }

    // ================= internal wiring =================

    private fun wireFlows() {
        products = db.productDao().getAll().map { it.toDomainProducts() }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        warehouses = db.warehouseDao().getAll().map { it.toDomainWarehouses() }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        stockCounts = db.stockCountDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        stockLevels = combine(
            db.productDao().getAll(), db.warehouseDao().getAll(), db.stockDao().getAllLevels(),
        ) { productEntities, warehouseEntities, levelEntities ->
            val productsById = productEntities.associateBy { it.id }
            val warehousesById = warehouseEntities.associateBy { it.id }
            levelEntities.mapNotNull { level ->
                val product = productsById[level.productId] ?: return@mapNotNull null
                val warehouse = warehousesById[level.warehouseId] ?: return@mapNotNull null
                StockLevelView(
                    productId = product.id, productName = product.name, unit = product.unit,
                    warehouseId = warehouse.id, warehouseName = warehouse.name,
                    quantityOnHand = level.quantityOnHand, reorderThreshold = product.reorderThreshold,
                    stockCategory = StockCategory.valueOf(warehouse.stockCategory), reservedQty = level.reservedQty,
                )
            }.sortedBy { it.productName }
        }.stateIn(scope, SharingStarted.Eagerly, emptyList())

        movements = combine(
            db.productDao().getAll(), db.warehouseDao().getAll(), db.stockDao().getAllMovements(),
        ) { productEntities, warehouseEntities, movementEntities ->
            val productsById = productEntities.associateBy { it.id }
            val warehousesById = warehouseEntities.associateBy { it.id }
            movementEntities.mapNotNull { m ->
                val product = productsById[m.productId] ?: return@mapNotNull null
                val warehouse = warehousesById[m.warehouseId] ?: return@mapNotNull null
                StockMovement(
                    id = m.id, productId = product.id, productName = product.name,
                    warehouseId = warehouse.id, warehouseName = warehouse.name,
                    type = MovementType.valueOf(m.type), quantity = m.quantity, reason = m.reason,
                    timestamp = LocalDateTime.ofInstant(Instant.ofEpochMilli(m.timestampEpochMillis), ZoneOffset.UTC),
                    batchCode = m.batchCode, unitCost = m.unitCost,
                )
            }
        }.stateIn(scope, SharingStarted.Eagerly, emptyList())

        categories = db.productCategoryDao().getAll().map { list -> list.map { ProductCategory(it.id, it.name, it.isActive) } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        brands = db.productBrandDao().getAll().map { list -> list.map { ProductBrand(it.id, it.name, it.isActive) } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        damageReports = db.damageReportDao().getAll().map { list -> list.map {
            DamageReport(it.id, it.productId, it.productName, it.warehouseId, it.qty, it.reason, it.reportedBy,
                LocalDateTime.ofInstant(Instant.ofEpochMilli(it.createdAtEpochMillis), ZoneOffset.UTC))
        } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        stockTransfers = db.stockTransferDao().getAll().map { list -> list.map {
            StockTransfer(it.id, it.productId, it.productName, it.fromWarehouseId, it.toWarehouseId, it.qty, it.status, it.createdBy,
                LocalDateTime.ofInstant(Instant.ofEpochMilli(it.createdAtEpochMillis), ZoneOffset.UTC))
        } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        inventoryLots = db.inventoryLotDao().getAll().map { list -> list.map {
            InventoryLot(it.id, it.productId, it.warehouseId, it.batchCode, it.qtyRemaining,
                it.expiryDateEpochMillis?.let { e -> LocalDateTime.ofInstant(Instant.ofEpochMilli(e), ZoneOffset.UTC) },
                LocalDateTime.ofInstant(Instant.ofEpochMilli(it.receivedAtEpochMillis), ZoneOffset.UTC))
        } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
    }

    /** Starter products/warehouses/stock so the screen isn't empty on first run. */
    private fun seedIfEmpty() = runBlocking(Dispatchers.IO) {
        if (db.warehouseDao().count() == 0) {
            db.warehouseDao().upsertAll(
                listOf(
                    WarehouseEntity("WH-1", "Barisal Main Warehouse", "Barisal", StockCategory.STORE.name),
                    WarehouseEntity("WH-2", "Khulna Depot", "Khulna", StockCategory.STORE.name),
                    WarehouseEntity("WH-3", "Rajshahi Depot", "Rajshahi", StockCategory.STORE.name),
                    WarehouseEntity("WH-4", "Factory Production Store", "Barisal", StockCategory.PRODUCTION.name),
                )
            )
        }
        if (db.productDao().count() == 0) {
            db.productDao().upsertAll(
                listOf(
                    ProductEntity("PRD-1", "MHN-MASALA-1KG", "ABM Masala Tea 1kg", "kg", "Tea", 50.0, 420.0),
                    ProductEntity("PRD-2", "MHN-CLASSIC-1KG", "ABM Tea Classic 1kg", "kg", "Tea", 40.0, 380.0),
                )
            )
        }
        // Seed opening stock only once, guarded by absence of a stock level row.
        if (db.stockDao().getLevel("PRD-1", "WH-1") == null) {
            adjustStock("PRD-1", "WH-1", 320.0, MovementType.IN, "Opening stock")
            adjustStock("PRD-2", "WH-1", 45.0, MovementType.IN, "Opening stock")
            adjustStock("PRD-1", "WH-2", 180.0, MovementType.IN, "Opening stock")
            adjustStock("PRD-1", "WH-4", 600.0, MovementType.IN, "Raw material received")
            adjustStock("PRD-2", "WH-4", 150.0, MovementType.IN, "Raw material received")
        }
    }
}

private fun ProductEntity.toDomainSingle() = Product(
    id = id, sku = sku, name = name, unit = unit, category = category, reorderThreshold = reorderThreshold,
    defaultUnitPrice = defaultUnitPrice, costPrice = costPrice, photoUri = photoUri,
    isActive = isActive, isDeleted = isDeleted, createdBy = createdBy,
    createdAt = java.time.LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), java.time.ZoneOffset.UTC),
    dedupKey = dedupKey,
    deletedAt = deletedAtEpochMillis?.let { java.time.LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(it), java.time.ZoneOffset.UTC) },
    deletedBy = deletedBy, barcodeValue = barcodeValue, categoryId = categoryId, brandId = brandId,
)
private fun List<ProductEntity>.toDomainProducts() = map { it.toDomainSingle() }

private fun WarehouseEntity.toDomainSingle() = Warehouse(id, name, zone, StockCategory.valueOf(stockCategory))
private fun List<WarehouseEntity>.toDomainWarehouses() = map { it.toDomainSingle() }

private fun packStockCountLines(lines: List<StockCountLine>): String =
    lines.joinToString(";") { "${it.productId},${it.productName},${it.batchCode ?: ""},${it.systemQty},${it.countedQty},${it.systemCartons},${it.countedCartons}" }

private fun unpackStockCountLines(raw: String): List<StockCountLine> {
    if (raw.isBlank()) return emptyList()
    return raw.split(";").filter { it.isNotBlank() }.map { record ->
        val p = record.split(",")
        // Backward-compatible with the older 4-field format (no batch/carton) so previously-saved counts still parse.
        if (p.size >= 7) {
            StockCountLine(productId = p[0], productName = p[1], batchCode = p[2].ifBlank { null }, systemQty = p[3].toDouble(), countedQty = p[4].toDouble(), systemCartons = p[5].toIntOrNull() ?: 0, countedCartons = p[6].toIntOrNull() ?: 0)
        } else {
            StockCountLine(productId = p[0], productName = p[1], systemQty = p[2].toDouble(), countedQty = p[3].toDouble())
        }
    }
}

private fun StockCount.toEntity() = com.abm.erp.data.room.StockCountEntity(
    id = id, countNo = countNo, warehouseId = warehouseId, warehouseName = warehouseName,
    linesRaw = packStockCountLines(lines), status = status, createdBy = createdBy,
    createdAtEpochMillis = createdAt.toInstant(java.time.ZoneOffset.UTC).toEpochMilli(),
    approvedBy = approvedBy, approvedAtEpochMillis = approvedAt?.toInstant(java.time.ZoneOffset.UTC)?.toEpochMilli(),
)

private fun com.abm.erp.data.room.StockCountEntity.toDomain() = StockCount(
    id = id, countNo = countNo, warehouseId = warehouseId, warehouseName = warehouseName,
    lines = unpackStockCountLines(linesRaw), status = status, createdBy = createdBy,
    createdAt = java.time.LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(createdAtEpochMillis), java.time.ZoneOffset.UTC),
    approvedBy = approvedBy, approvedAt = approvedAtEpochMillis?.let { java.time.LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(it), java.time.ZoneOffset.UTC) },
)
