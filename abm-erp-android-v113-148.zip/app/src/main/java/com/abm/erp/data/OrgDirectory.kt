package com.abm.erp.data

/**
 * Geo scope for a person or a data record: which division/district/market
 * they're limited to. Nulls mean "all" at that level (e.g. an RSM has
 * district = null, meaning every district in their division).
 * zoneDivisions is only used by DSM-tier "zone" scopes that span more than
 * one division (see ZONES below).
 */
data class GeoScope(
    val division: String? = null,
    val district: String? = null,
    val market: String? = null,
    val zoneDivisions: List<String>? = null,
)

data class Employee(
    val id: String,
    val name: String,
    val role: UserRole,
    val geo: GeoScope,
    val geoLabel: String,
    val target: Long,
    val achieved: Long,
    val pendingOrders: Int,
    val dueLakh: Double,
    val insight: String,
)

// Real chain of command, bottom to top. Mirrors the design-phase JSX exactly.
val ROLE_ORDER: List<UserRole> = listOf(
    UserRole.SR, UserRole.TSM, UserRole.ASM, UserRole.RSM, UserRole.DSM,
    UserRole.NSM, UserRole.AGM, UserRole.GM, UserRole.MD, UserRole.CHAIRMAN,
)

// All 8 divisions and all 64 real districts of Bangladesh.
val DIVISION_DISTRICTS: Map<String, List<String>> = mapOf(
    "Dhaka" to listOf("Dhaka", "Faridpur", "Gazipur", "Gopalganj", "Kishoreganj", "Madaripur", "Manikganj", "Munshiganj", "Narayanganj", "Narsingdi", "Rajbari", "Shariatpur", "Tangail"),
    "Chattogram" to listOf("Bandarban", "Brahmanbaria", "Chandpur", "Chattogram", "Cumilla", "Cox's Bazar", "Feni", "Khagrachhari", "Lakshmipur", "Noakhali", "Rangamati"),
    "Rajshahi" to listOf("Bogura", "Joypurhat", "Naogaon", "Natore", "Chapainawabganj", "Pabna", "Rajshahi", "Sirajganj"),
    "Khulna" to listOf("Bagerhat", "Chuadanga", "Jashore", "Jhenaidah", "Khulna", "Kushtia", "Magura", "Meherpur", "Narail", "Satkhira"),
    "Barishal" to listOf("Barguna", "Barishal", "Bhola", "Jhalokati", "Patuakhali", "Pirojpur"),
    "Sylhet" to listOf("Habiganj", "Moulvibazar", "Sunamganj", "Sylhet"),
    "Rangpur" to listOf("Dinajpur", "Gaibandha", "Kurigram", "Lalmonirhat", "Nilphamari", "Panchagarh", "Rangpur", "Thakurgaon"),
    "Mymensingh" to listOf("Jamalpur", "Mymensingh", "Netrokona", "Sherpur"),
)

private val NAMED_MARKETS: Map<String, List<String>> = mapOf(
    "Rangpur" to listOf("Rangpur City Bazar", "Modern More Bazar", "Station Road Bazar"),
    "Barishal" to listOf("Barishal Notun Bazar", "Chawk Bazar", "Nathullabad Bazar"),
    "Khulna" to listOf("Khulna New Market", "Sonadanga Bazar"),
)

// DSM-এর zone — একাধিক division একসাথে, RSM-এর চেয়ে senior/broader। public
// রাখা হলো যাতে buildEmployeeDirectory() আর LoginScreen (area-selection)
// দুটোই একই তালিকা ব্যবহার করে।
val ZONES: Map<String, List<String>> = mapOf(
    "Northern Zone" to listOf("Rangpur", "Rajshahi"),
    "Southern Zone" to listOf("Khulna", "Barishal"),
    "Eastern Zone" to listOf("Chattogram", "Sylhet"),
    "Central Zone" to listOf("Dhaka", "Mymensingh"),
)

/**
 * Generates the full national directory from geography data instead of
 * hand-listing 200+ people (same approach as the validated JSX version):
 * one SR + TSM + ASM per district (192), one RSM per division (8), one DSM
 * per zone (4), then the national tiers (5) = 209 total.
 * Names are role+district placeholders except the 4 demo login accounts,
 * which get real names to match what's already been tested.
 */
fun buildEmployeeDirectory(): List<Employee> {
    val list = mutableListOf<Employee>()

    DIVISION_DISTRICTS.forEach { (division, districts) ->
        districts.forEach { district ->
            val firstMarket = NAMED_MARKETS[district]?.firstOrNull() ?: "$district Sadar Bazar"
            list += Employee(
                id = "SR-$district", name = "SR — $district", role = UserRole.SR,
                geo = GeoScope(division, district, firstMarket), geoLabel = "$district district ▸ $firstMarket",
                target = 480_000, achieved = 410_000, pendingOrders = 3, dueLakh = 0.3,
                insight = "$district retail coverage is steady this week.",
            )
            list += Employee(
                id = "TSM-$district", name = "TSM — $district", role = UserRole.TSM,
                geo = GeoScope(division, district), geoLabel = "$district district (all markets)",
                target = 2_100_000, achieved = 1_750_000, pendingOrders = 5, dueLakh = 1.1,
                insight = "$district district is on track this month.",
            )
            list += Employee(
                id = "ASM-$district", name = "ASM — $district", role = UserRole.ASM,
                geo = GeoScope(division, district), geoLabel = "$district district",
                target = 2_500_000, achieved = 2_000_000, pendingOrders = 4, dueLakh = 1.2,
                insight = "$district district trending steady this week.",
            )
        }
    }

    DIVISION_DISTRICTS.keys.forEach { division ->
        list += Employee(
            id = "RSM-$division", name = "RSM — $division", role = UserRole.RSM,
            geo = GeoScope(division = division), geoLabel = "$division division (all districts)",
            target = 13_000_000, achieved = 10_400_000, pendingOrders = 15, dueLakh = 6.3,
            insight = "$division division is on track this month.",
        )
    }

    ZONES.forEach { (zoneName, divisions) ->
        list += Employee(
            id = "DSM-${zoneName.replace(" ", "")}", name = "DSM — $zoneName", role = UserRole.DSM,
            geo = GeoScope(zoneDivisions = divisions), geoLabel = "$zoneName (${divisions.joinToString(" + ")} divisions)",
            target = 45_000_000, achieved = 36_000_000, pendingOrders = 34, dueLakh = 14.8,
            insight = "$zoneName is on track this month — ${divisions[0]} leading, ${divisions[1]} steady.",
        )
    }

    list += Employee("NSM-1", "NSM — National", UserRole.NSM, GeoScope(), "All divisions (national)", 150_000_000, 128_000_000, 62, 48.5, "Nationally, Khulna leads at +18% vs forecast; Sylhet is the only division behind target.")
    list += Employee("AGM-1", "AGM — HQ", UserRole.AGM, GeoScope(), "All divisions · HQ", 300_000_000, 261_000_000, 88, 71.2, "Company-wide: Khulna division is beating forecast by 18%, 2 divisions trailing.")
    list += Employee("GM-1", "GM — HQ", UserRole.GM, GeoScope(), "All divisions · HQ", 300_000_000, 261_000_000, 88, 71.2, "Company-wide: Khulna division is beating forecast by 18%, 2 divisions trailing.")
    list += Employee("MD-1", "MD — HQ", UserRole.MD, GeoScope(), "All Bangladesh · HQ", 500_000_000, 412_000_000, 121, 96.7, "Nationwide: Khulna division is beating forecast by 18%. Full board summary in Reports.")
    list += Employee("CHAIR-1", "Chairman", UserRole.CHAIRMAN, GeoScope(), "All Bangladesh · Board", 500_000_000, 412_000_000, 121, 96.7, "Nationwide: Khulna division is beating forecast by 18%. This is the only view with full company-wide A–Z visibility.")

    // Patch the 4 demo login accounts with real names (already tested via LoginScreen).
    fun patch(id: String, name: String) {
        val idx = list.indexOfFirst { it.id == id }
        if (idx >= 0) list[idx] = list[idx].copy(name = name)
    }
    patch("ASM-Rangpur", "Mahmudul Islam")
    patch("SR-Barishal", "Rafiq Hasan")
    patch("RSM-Khulna", "Kabir Ahmed")
    patch("CHAIR-1", "Zahid Hossain")
    patch("NSM-1", "Anwar Kabir")
    patch("AGM-1", "Farida Yasmin")
    patch("GM-1", "Shafiqul Islam")
    patch("MD-1", "Nasrin Chowdhury")

    return list
}

val EMPLOYEE_DIRECTORY: List<Employee> by lazy { buildEmployeeDirectory() }

/** broader "contains" narrower if every non-null field of broader matches narrower (null = "all"). */
fun geoContains(broader: GeoScope, narrower: GeoScope): Boolean {
    if (broader.zoneDivisions != null) return broader.zoneDivisions.contains(narrower.division)
    if (broader.division != null && broader.division != narrower.division) return false
    if (broader.district != null && broader.district != narrower.district) return false
    return true
}

/**
 * Module 9 (SFA) — Distance Validation / Geo-Fencing. Haversine great-circle
 * distance in meters between a field employee's current GPS fix and an
 * outlet/dealer's registered coordinates — the same math LoginScreen's
 * existing 50km device-check already uses informally, formalized here as a
 * reusable function so any visit/check-in flow can enforce "you must
 * actually be at this outlet" instead of trusting a manually-typed address.
 */
fun distanceMeters(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
    val r = 6371000.0 // Earth radius in meters
    val dLat = Math.toRadians(lat2 - lat1)
    val dLng = Math.toRadians(lng2 - lng1)
    val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2)
    val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return r * c
}

/** True if a check-in GPS fix is within `radiusMeters` of the outlet's registered location — the actual Geo-Fencing check a visit/order flow should call before accepting it as "verified on-site". */
fun isWithinGeoFence(checkInLat: Double, checkInLng: Double, outletLat: Double, outletLng: Double, radiusMeters: Double = 200.0): Boolean =
    distanceMeters(checkInLat, checkInLng, outletLat, outletLng) <= radiusMeters

/**
 * Vacancy cascade: walks up ROLE_ORDER from the vacant employee's tier,
 * returning the first non-vacant person whose geo covers the vacant
 * employee's area. Consecutive vacancies cascade further up automatically.
 */
fun findCoveringEmployee(vacant: Employee, vacantIds: Set<String>): Employee? {
    val startIdx = ROLE_ORDER.indexOf(vacant.role)
    for (i in (startIdx + 1) until ROLE_ORDER.size) {
        val tier = ROLE_ORDER[i]
        val candidate = EMPLOYEE_DIRECTORY.firstOrNull {
            it.role == tier && it.id !in vacantIds && geoContains(it.geo, vacant.geo)
        }
        if (candidate != null) return candidate
    }
    return EMPLOYEE_DIRECTORY.firstOrNull { it.role == UserRole.CHAIRMAN }
}

/**
 * FUNDAMENTAL RULE — every module with employee-level data uses this same
 * area-matching cascade: your supervisor is the nearest higher tier whose
 * geo covers yours. This is the SAME geo-matching findCoveringEmployee uses
 * for vacancy cascade, reused here for "who do I report to" and for
 * "which employees can I see" (geoContains(me, them) — never the reverse).
 */
fun findDirectSupervisor(employee: Employee): Employee? {
    val startIdx = ROLE_ORDER.indexOf(employee.role)
    for (i in (startIdx + 1) until ROLE_ORDER.size) {
        val tier = ROLE_ORDER[i]
        val candidate = EMPLOYEE_DIRECTORY.firstOrNull { it.role == tier && geoContains(it.geo, employee.geo) }
        if (candidate != null) return candidate
    }
    return EMPLOYEE_DIRECTORY.firstOrNull { it.role == UserRole.CHAIRMAN }
}

/** My own cascade — everyone whose geo falls within mine (never the reverse). Chairman's geo is empty/unrestricted so this naturally returns everyone. */
fun findMyCascade(viewer: Employee): List<Employee> =
    EMPLOYEE_DIRECTORY.filter { it.id != viewer.id && geoContains(viewer.geo, it.geo) }
