package com.abm.erp.data

import android.content.Context
import com.abm.erp.data.room.AppDatabase
import com.abm.erp.data.room.CallLogEntity
import com.abm.erp.data.room.CustomerSegmentEntity
import com.abm.erp.data.room.FollowUpEntity
import com.abm.erp.data.room.LeadEntity
import com.abm.erp.data.room.MeetingLogEntity
import com.abm.erp.data.room.OpportunityEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset

/**
 * Module 6 — CRM (Lead Management, Opportunity Tracking, Communication
 * History). Same repository-object pattern as Purchase/AccountsRepository.
 * Customer/Dealer/Retailer management itself already lives in
 * MockRepository's Dealer/Retailer functions (Module 7/8) — this repository
 * covers what wasn't there yet: pre-sale Leads, Opportunities, and the
 * Call/Meeting/Follow-up communication trail.
 */
object CrmRepository {

    private lateinit var db: AppDatabase
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val firestoreDb by lazy { com.google.firebase.firestore.FirebaseFirestore.getInstance() }
    private var syncCompanyId: String? = null
    private var leadsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var opportunitiesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var segmentsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var callLogsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var meetingLogsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var followUpsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

    private fun syncCollection(name: String) =
        firestoreDb.collection("companies").document(CompanyContext.current.value ?: "_unset").collection(name)

    fun startCrossDeviceSync(companyId: String) {
        if (!CompanyContext.validateAndRecord(companyId)) {
            android.util.Log.w("CrmRepository", "startCrossDeviceSync refused invalid companyId '$companyId' — sync not started")
            return
        }
        if (companyId == syncCompanyId) return
        syncCompanyId = companyId
        listenLeadsRemote(); listenOpportunitiesRemote(); listenSegmentsRemote()
        listenCallLogsRemote(); listenMeetingLogsRemote(); listenFollowUpsRemote()
    }

    private fun listenLeadsRemote() {
        leadsListenerReg?.remove()
        leadsListenerReg = syncCollection("leads").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("CrmRepository", "leads sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(LeadEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.leadDao().upsertAll(list) }
        }
    }

    private fun listenOpportunitiesRemote() {
        opportunitiesListenerReg?.remove()
        opportunitiesListenerReg = syncCollection("opportunities").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("CrmRepository", "opportunities sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(OpportunityEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.opportunityDao().upsertAll(list) }
        }
    }

    private fun listenSegmentsRemote() {
        segmentsListenerReg?.remove()
        segmentsListenerReg = syncCollection("customerSegments").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("CrmRepository", "customerSegments sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(CustomerSegmentEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.customerSegmentDao().upsertAll(list) }
        }
    }

    private fun listenCallLogsRemote() {
        callLogsListenerReg?.remove()
        callLogsListenerReg = syncCollection("callLogs").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("CrmRepository", "callLogs sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(CallLogEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.callLogDao().upsertAll(list) }
        }
    }

    private fun listenMeetingLogsRemote() {
        meetingLogsListenerReg?.remove()
        meetingLogsListenerReg = syncCollection("meetingLogs").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("CrmRepository", "meetingLogs sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(MeetingLogEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.meetingLogDao().upsertAll(list) }
        }
    }

    private fun listenFollowUpsRemote() {
        followUpsListenerReg?.remove()
        followUpsListenerReg = syncCollection("followUps").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("CrmRepository", "followUps sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(FollowUpEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.followUpDao().upsertAll(list) }
        }
    }

    private fun push(collection: String, id: String, entity: Any) {
        syncCollection(collection).document(id).set(entity)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("CrmRepository", "push $collection failed", it) }
    }

    fun init(context: Context) {
        db = AppDatabase.getInstance(context)
        leads = db.leadDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        opportunities = db.opportunityDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        customerSegments = db.customerSegmentDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        callLogs = db.callLogDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        meetingLogs = db.meetingLogDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        followUps = db.followUpDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
    }

    lateinit var leads: StateFlow<List<Lead>>
        private set
    lateinit var opportunities: StateFlow<List<Opportunity>>
        private set
    lateinit var customerSegments: StateFlow<List<CustomerSegment>>
        private set
    lateinit var callLogs: StateFlow<List<CallLog>>
        private set
    lateinit var meetingLogs: StateFlow<List<MeetingLog>>
        private set
    lateinit var followUps: StateFlow<List<FollowUp>>
        private set

    // ---- Lead Management ----
    fun createLead(name: String, phone: String, source: String, assignedTo: String, onRejected: (String) -> Unit = {}): Lead? {
        if (!PermissionManager.canCurrentUser("crm", PermissionAction.CREATE)) {
            MockRepository.logAudit("Lead", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            onRejected("আপনার role-এ Lead তৈরি করার অনুমতি নেই।")
            return null
        }
        if (name.isBlank()) { onRejected("নাম দিন।"); return null }
        val lead = Lead(id = "LEAD-${java.util.UUID.randomUUID().toString().take(8)}", name = name, phone = phone, source = source, assignedTo = assignedTo, createdBy = MockRepository.currentUser.name)
        scope.launch {
            val entity = lead.toEntity()
            db.leadDao().upsert(entity)
            push("leads", entity.id, entity)
            MockRepository.logAudit("Lead", lead.id, "CREATE", newValue = lead)
        }
        return lead
    }

    /** Universal Action Menu: Duplicate. */
    fun duplicateLead(leadId: String, onRejected: (String) -> Unit = {}): DuplicateResult? {
        val l = leads.value.firstOrNull { it.id == leadId } ?: run { onRejected("এই Lead খুঁজে পাওয়া যায়নি।"); return null }
        val created = createLead("${l.name} (copy)", l.phone, l.source, l.assignedTo, onRejected = onRejected) ?: return null
        return DuplicateResult(created.id, created.name)
    }

    fun updateLeadStatus(id: String, status: LeadStatus) {
        scope.launch {
            db.leadDao().setStatus(id, status.name)
            syncCollection("leads").document(id).update("status", status.name)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("CrmRepository", "push lead-status failed", it) }
            MockRepository.logAudit("Lead", id, "UPDATE", newValue = status)
        }
    }

    fun deleteLead(id: String) {
        scope.launch {
            db.leadDao().softDelete(id)
            syncCollection("leads").document(id).update("isDeleted", true)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("CrmRepository", "push lead-delete failed", it) }
            MockRepository.logAudit("Lead", id, "DELETE")
        }
    }

    // ---- Opportunity Tracking ----
    fun createOpportunity(leadId: String?, title: String, estimatedValue: Double, assignedTo: String, onRejected: (String) -> Unit = {}): Opportunity? {
        if (!PermissionManager.canCurrentUser("crm", PermissionAction.CREATE)) { onRejected("আপনার role-এ Opportunity তৈরি করার অনুমতি নেই।"); return null }
        val opp = Opportunity(id = java.util.UUID.randomUUID().toString(), leadId = leadId, title = title, estimatedValue = estimatedValue, assignedTo = assignedTo, createdBy = MockRepository.currentUser.name)
        scope.launch {
            val entity = opp.toEntity()
            db.opportunityDao().upsert(entity)
            push("opportunities", entity.id, entity)
            MockRepository.logAudit("Opportunity", opp.id, "CREATE", newValue = opp)
        }
        return opp
    }

    fun updateOpportunityStage(id: String, stage: String) {
        scope.launch {
            db.opportunityDao().setStage(id, stage)
            syncCollection("opportunities").document(id).update("stage", stage)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("CrmRepository", "push opportunity-stage failed", it) }
            MockRepository.logAudit("Opportunity", id, "UPDATE", newValue = stage)
        }
    }

    // ---- Customer Segmentation ----
    fun createSegment(name: String, criteria: String): CustomerSegment {
        val seg = CustomerSegment(id = java.util.UUID.randomUUID().toString(), name = name, criteria = criteria)
        scope.launch {
            val entity = seg.toEntity()
            db.customerSegmentDao().upsert(entity)
            push("customerSegments", entity.id, entity)
        }
        return seg
    }

    // ---- Communication History: Calls / Meetings / Follow-ups ----
    fun logCall(leadId: String?, partyType: PartyType?, partyId: String?, contactName: String, phone: String, durationMinutes: Int, notes: String): CallLog {
        val call = CallLog(id = java.util.UUID.randomUUID().toString(), leadId = leadId, partyType = partyType, partyId = partyId, contactName = contactName, phone = phone, durationMinutes = durationMinutes, notes = notes, loggedBy = MockRepository.currentUser.name)
        scope.launch {
            val entity = call.toEntity()
            db.callLogDao().upsert(entity)
            push("callLogs", entity.id, entity)
            MockRepository.logAudit("CallLog", call.id, "CREATE", newValue = call)
        }
        return call
    }

    fun logMeeting(title: String, attendees: String, notes: String): MeetingLog {
        val meeting = MeetingLog(id = java.util.UUID.randomUUID().toString(), title = title, attendees = attendees, notes = notes, loggedBy = MockRepository.currentUser.name)
        scope.launch {
            val entity = meeting.toEntity()
            db.meetingLogDao().upsert(entity)
            push("meetingLogs", entity.id, entity)
            MockRepository.logAudit("MeetingLog", meeting.id, "CREATE", newValue = meeting)
        }
        return meeting
    }

    fun createFollowUp(leadId: String?, note: String, dueDate: LocalDateTime): FollowUp {
        val followUp = FollowUp(id = java.util.UUID.randomUUID().toString(), leadId = leadId, note = note, dueDate = dueDate, createdBy = MockRepository.currentUser.name)
        scope.launch {
            val entity = followUp.toEntity()
            db.followUpDao().upsert(entity)
            push("followUps", entity.id, entity)
        }
        return followUp
    }

    fun setFollowUpDone(id: String, done: Boolean) {
        scope.launch {
            db.followUpDao().setDone(id, done)
            syncCollection("followUps").document(id).update("done", done)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("CrmRepository", "push followup-done failed", it) }
        }
    }
}

private fun Lead.toEntity() = LeadEntity(
    id = id, name = name, phone = phone, source = source, status = status.name, assignedTo = assignedTo, notes = notes,
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

private fun LeadEntity.toDomain() = Lead(
    id = id, name = name, phone = phone, source = source, status = LeadStatus.valueOf(status), assignedTo = assignedTo, notes = notes,
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC), isDeleted = isDeleted,
)

private fun Opportunity.toEntity() = OpportunityEntity(
    id = id, leadId = leadId, title = title, estimatedValue = estimatedValue, stage = stage, assignedTo = assignedTo,
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun OpportunityEntity.toDomain() = Opportunity(
    id = id, leadId = leadId, title = title, estimatedValue = estimatedValue, stage = stage, assignedTo = assignedTo,
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

private fun CustomerSegment.toEntity() = CustomerSegmentEntity(id = id, name = name, criteria = criteria)
private fun CustomerSegmentEntity.toDomain() = CustomerSegment(id = id, name = name, criteria = criteria)

private fun CallLog.toEntity() = CallLogEntity(
    id = id, leadId = leadId, partyType = partyType?.name, partyId = partyId, contactName = contactName, phone = phone,
    durationMinutes = durationMinutes, notes = notes, loggedBy = loggedBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun CallLogEntity.toDomain() = CallLog(
    id = id, leadId = leadId, partyType = partyType?.let { PartyType.valueOf(it) }, partyId = partyId, contactName = contactName, phone = phone,
    durationMinutes = durationMinutes, notes = notes, loggedBy = loggedBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

private fun MeetingLog.toEntity() = MeetingLogEntity(
    id = id, title = title, attendees = attendees, notes = notes, meetingDateEpochMillis = meetingDate.toInstant(ZoneOffset.UTC).toEpochMilli(), loggedBy = loggedBy,
)

private fun MeetingLogEntity.toDomain() = MeetingLog(
    id = id, title = title, attendees = attendees, notes = notes,
    meetingDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(meetingDateEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC), loggedBy = loggedBy,
)

private fun FollowUp.toEntity() = FollowUpEntity(
    id = id, leadId = leadId, note = note, dueDateEpochMillis = dueDate.toInstant(ZoneOffset.UTC).toEpochMilli(), done = done,
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun FollowUpEntity.toDomain() = FollowUp(
    id = id, leadId = leadId, note = note, dueDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(dueDateEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC), done = done,
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)
