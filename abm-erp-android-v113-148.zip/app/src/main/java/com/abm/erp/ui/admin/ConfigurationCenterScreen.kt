package com.abm.erp.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.EnterpriseListRow
import com.abm.erp.core.PremiumCard
import com.abm.erp.core.SectionTitle
import com.abm.erp.core.Space
import com.abm.erp.data.MockRepository
import com.abm.erp.data.UserRole
import com.abm.erp.theme.*

/**
 * Configuration Center — what the Chairman can change, and its current value.
 *
 * Almost everything here already existed, but spread across five screens, so nobody could
 * see the company's configuration as a whole. This page does not introduce new settings; it
 * shows the live value of each one and links to the screen that owns it. Every value below
 * is read from the same source the business logic reads, so what is shown is what the app
 * actually applies.
 *
 * It also states plainly what is **not** configurable and why — an operator who assumes a
 * setting exists and silently doesn't is worse off than one who knows the boundary.
 */
@Composable
fun ConfigurationCenterScreen(onNavigate: (String) -> Unit = {}) {
    val currentUser = MockRepository.currentUser
    if (currentUser.role != UserRole.CHAIRMAN) {
        Column(Modifier.fillMaxSize().padding(Space.xl), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(60.dp))
            com.abm.erp.core.WorkspaceEmptyState("এই পাতা শুধু Chairman দেখতে পারেন।", iconVector = Icons.Filled.Lock)
        }
        return
    }

    val company = remember { MockRepository.companySettings() }
    val profiles by MockRepository.employeeProfiles.collectAsState()

    // Read through the same accessor the business logic uses, so these cannot drift
    // from the values actually applied at runtime.
    fun rule(key: String, default: Double) = MockRepository.businessRuleDouble(key, default)

    Column(Modifier.fillMaxSize().background(DashBg)) {

        Column(
            Modifier.fillMaxWidth()
                .background(Brush.linearGradient(listOf(ChairmanNavy, Color(0xFF16294D))))
                .padding(Space.lg),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(42.dp).background(ChairmanGold.copy(alpha = 0.18f), RoundedCornerShape(13.dp)),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Tune, null, tint = ChairmanGold, modifier = Modifier.size(22.dp)) }
                Spacer(Modifier.width(Space.md))
                Column {
                    Text("Configuration Center", color = ChairmanGold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("কোম্পানির সব সেটিং — বর্তমান মান সহ", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp)
                }
            }
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(Space.md)) {

            // ── company identity ──
            SectionTitle("কোম্পানি পরিচয়")
            PremiumCard(padding = Space.md) {
                ConfigRow("নাম", company.companyName.ifBlank { "— সেট করা হয়নি —" })
                ConfigRow("ঠিকানা", company.companyAddress.ifBlank { "—" })
                ConfigRow("ফোন", company.companyPhone.ifBlank { "—" })
                ConfigRow("VAT / TIN", company.taxVatNumber.ifBlank { "—" })
                ConfigRow("মুদ্রা", "${company.currencySymbol} (${company.currencyCode})")
                ConfigRow("অর্থবছর শুরু", monthName(company.fiscalYearStartMonth))
                Spacer(Modifier.height(Space.sm))
                Text(
                    "এই নাম ও ঠিকানাই invoice-এর উপরে ছাপা হয়।",
                    fontSize = 10.sp, color = TextSecondary,
                )
            }
            Spacer(Modifier.height(Space.sm))
            EnterpriseListRow(
                title = "Company Settings",
                subtitle = "নাম, ঠিকানা, VAT, মুদ্রা, অর্থবছর, ছুটির দিন",
                icon = Icons.Filled.Business,
                accent = ChairmanNavy,
                onClick = { onNavigate("company_settings_center") },
            )

            // ── business rules ──
            SectionTitle("ব্যবসার নিয়ম (চালু মান)")
            PremiumCard(padding = Space.md) {
                ConfigRow("সর্বোচ্চ ছাড়", "${"%.0f".format(rule("MAX_DISCOUNT_PCT", 15.0))}%")
                ConfigRow("Invoice সীমা", "৳${"%,.0f".format(rule("INVOICE_LIMIT", 500000.0))}")
                ConfigRow("সাপ্তাহিক Due", "${"%.0f".format(rule("WEEKLY_DUE_PCT", 50.0))}%")
                ConfigRow("Dealer ডিফল্ট Credit Limit", "৳${"%,.0f".format(rule("DEALER_CREDIT_LIMIT_DEFAULT", 0.0))}")
                ConfigRow("সর্বনিম্ন Credit Limit", "৳${"%,.0f".format(rule("MIN_CREDIT_LIMIT", 0.0))}")
                ConfigRow("উপস্থিতি/ভিজিট ব্যাসার্ধ", "${"%.0f".format(rule("ATTENDANCE_RADIUS_M", 100.0))} মিটার")
                ConfigRow("দেরির ছাড়", "${"%.0f".format(rule("LATE_ENTRY_GRACE_MIN", 30.0))} মিনিট")
                ConfigRow("স্ট্যান্ডার্ড শিফট", "${"%.1f".format(rule("STANDARD_SHIFT_HOURS", 8.0))} ঘণ্টা")
                ConfigRow("ওভারটাইম রেট", "${"%.2f".format(rule("OVERTIME_RATE_MULTIPLIER", 1.5))} ×")
            }
            Spacer(Modifier.height(Space.sm))
            EnterpriseListRow(
                title = "Business Rules",
                subtitle = "৯টি নিয়ম — বদলালে সাথে সাথেই কার্যকর হয়",
                meta = "প্রতিটি পরিবর্তন audit log-এ থাকে",
                icon = Icons.Filled.Rule,
                accent = ChairmanNavy,
                onClick = { onNavigate("business_rule_engine") },
            )

            // ── people & access ──
            SectionTitle("কর্মী ও অনুমতি")
            PremiumCard(padding = Space.md) {
                ConfigRow("মোট কর্মী", "${profiles.size} জন")
                ConfigRow("সক্রিয়", "${profiles.count { it.hasActiveAccess }} জন")
                Spacer(Modifier.height(Space.sm))
                Text(
                    "অনুমোদনের আর্থিক সীমা প্রতিটি কর্মীর নিজের প্রোফাইলে সেট হয় — " +
                        "HR → কর্মী → Approval Limits থেকে।",
                    fontSize = 10.sp, color = TextSecondary,
                )
            }
            Spacer(Modifier.height(Space.sm))
            EnterpriseListRow(
                title = "Employee Setup",
                subtitle = "কর্মী যোগ · PIN রিসেট · লগইন চালু/বন্ধ",
                icon = Icons.Filled.ManageAccounts,
                accent = ChairmanNavy,
                onClick = { onNavigate("employee_setup") },
            )
            Spacer(Modifier.height(Space.sm))
            EnterpriseListRow(
                title = "Permission Center",
                subtitle = "প্রতি module-এ View / Create / Edit / Approve",
                icon = Icons.Filled.VpnKey,
                accent = ChairmanNavy,
                onClick = { onNavigate("permission_center") },
            )
            Spacer(Modifier.height(Space.sm))
            EnterpriseListRow(
                title = "Approval Limits",
                subtitle = "কে কত টাকা পর্যন্ত অনুমোদন দিতে পারবেন",
                meta = "HR module → কর্মী তালিকা → Approval Limits",
                icon = Icons.Filled.FactCheck,
                accent = ChairmanNavy,
                onClick = { onNavigate("hrm?tab=4") },
            )

            // ── period control ──
            SectionTitle("হিসাব নিয়ন্ত্রণ")
            EnterpriseListRow(
                title = "Period Lock",
                subtitle = "বন্ধ করা মাসে আর কোনো এন্ট্রি হবে না",
                icon = Icons.Filled.Lock,
                accent = ChairmanNavy,
                onClick = { onNavigate("period_lock_center") },
            )

            // ── the honest boundary ──
            SectionTitle("যা বদলানো যায় না")
            PremiumCard(padding = Space.md) {
                Text(
                    "নিচের জিনিসগুলো ইচ্ছাকৃতভাবে অ্যাপ থেকে বদলানো যায় না:",
                    fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(Space.sm))
                BoundaryRow(
                    "কাজের ধাপের ক্রম",
                    "Invoice অনুমোদন → স্টক কমা → Due বাড়া → Ledger পোস্টিং — এই ক্রম কোডে নির্দিষ্ট। " +
                        "এখানে ভুল হলে হিসাব মিলবে না, অথচ সাথে সাথে ধরা পড়বে না।",
                )
                BoundaryRow(
                    "স্ট্যাটাস রং",
                    "সবুজ = অনুমোদিত, লাল = বাতিল, হলুদ = অপেক্ষমাণ — পুরো অ্যাপে এক অর্থ। " +
                        "বদলালে এক পর্দার রং আরেক পর্দায় ভুল অর্থ দেবে।",
                )
                BoundaryRow(
                    "Audit log",
                    "কোনো এন্ট্রি মোছা বা বদলানো যায় না — এটাই এর মূল উদ্দেশ্য।",
                )
            }

            Spacer(Modifier.height(Space.xxl))
        }
    }
}

@Composable
private fun ConfigRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, fontSize = 11.sp, color = TextSecondary)
        Text(value, fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun BoundaryRow(title: String, why: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Lock, null, tint = TextSecondary, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(6.dp))
            Text(title, fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
        }
        Text(why, fontSize = 10.sp, color = TextSecondary, modifier = Modifier.padding(start = 19.dp, top = 2.dp))
    }
}

private fun monthName(m: Int): String = listOf(
    "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
    "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর",
).getOrNull(m - 1) ?: "—"
