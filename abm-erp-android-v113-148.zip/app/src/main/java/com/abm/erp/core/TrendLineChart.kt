package com.abm.erp.core

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Simple, dependency-free trend line chart for the Dashboard (Task: "real
 * sales trend chart", "collection trend chart"). Draws one polyline per
 * series over Canvas — no external charting library, consistent with the
 * rest of this app's "no external deps unless already included" pattern.
 * Values must be real (already-aggregated) data from the caller; this
 * composable does no data fetching itself.
 */
@Composable
fun TrendLineChart(
    labels: List<String>,
    values: List<Double>,
    lineColor: Color,
    modifier: Modifier = Modifier,
    height: androidx.compose.ui.unit.Dp = 120.dp,
) {
    if (values.isEmpty() || values.all { it == 0.0 }) {
        Text("এই সময়ে কোনো ডেটা নেই।", style = MaterialTheme.typography.labelSmall, color = androidx.compose.ui.graphics.Color.Gray)
        return
    }
    val maxValue = values.max().coerceAtLeast(1.0)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween) {
        Text("Latest: ৳${"%,.0f".format(values.last())}", style = MaterialTheme.typography.labelSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, color = lineColor)
        Text("Max: ৳${"%,.0f".format(maxValue)}", style = MaterialTheme.typography.labelSmall, color = androidx.compose.ui.graphics.Color.Gray)
    }
    Spacer(Modifier.height(4.dp))
    Canvas(modifier = modifier.fillMaxWidth().height(height)) {
        val stepX = size.width / (values.size - 1).coerceAtLeast(1)
        val points = values.mapIndexed { i, v -> androidx.compose.ui.geometry.Offset(i * stepX, size.height - (v / maxValue * size.height).toFloat()) }
        for (i in 0 until points.size - 1) {
            drawLine(color = lineColor, start = points[i], end = points[i + 1], strokeWidth = 4f)
        }
        points.forEach { p -> drawCircle(color = lineColor, radius = 5f, center = p) }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween) {
        // Only first/middle/last labels shown to avoid crowding on a phone-width chart.
        val toShow = if (labels.size <= 3) labels else listOf(labels.first(), labels[labels.size / 2], labels.last())
        toShow.forEach { l -> Text(l, style = MaterialTheme.typography.labelSmall, color = androidx.compose.ui.graphics.Color.Gray) }
    }
}
