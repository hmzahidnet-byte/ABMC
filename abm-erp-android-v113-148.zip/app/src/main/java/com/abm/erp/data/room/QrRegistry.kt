package com.abm.erp.data.room

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

/**
 * Secure QR Registry (Part 1).
 *
 * The QR payload carries an **opaque random reference**, never the business
 * identifier. Scanning `ABMQR1:9f3c…` tells an attacker nothing; it has to be
 * resolved against this registry, and the resolution is what applies company,
 * status, version, role, permission and geo checks.
 *
 * What is deliberately NOT stored here: names, amounts, phone numbers,
 * addresses, salaries, ledger values. Only the linkage (which opaque id maps to
 * which entity) plus lifecycle metadata. `entityId` is the app's own internal
 * id and is only ever surfaced to a caller that has already passed validation.
 *
 * `tokenHash` is a SHA-256 of the secret half of the payload. The raw token is
 * never persisted, so a dump of this table cannot be used to mint working QRs.
 */
@Entity(
    tableName = "qr_registry",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["entityType", "entityId"]),
        Index(value = ["status"]),
    ],
)
data class QrRegistryEntity(
    @PrimaryKey val qrId: String,
    val tokenHash: String,
    val companyId: String,
    val entityType: String,
    val entityId: String,
    /** DRAFT · ACTIVE · REVOKED · REISSUED · EXPIRED · HISTORICAL */
    val status: String,
    val version: Int = 1,
    val issuedAtEpochMillis: Long,
    val issuedBy: String,
    val revokedAtEpochMillis: Long? = null,
    val revokedBy: String? = null,
    val revokeReason: String? = null,
    val expiresAtEpochMillis: Long? = null,
    val previousQrId: String? = null,
    val metadataVersion: Int = 1,
    val lastScannedAtEpochMillis: Long? = null,
    val scanCount: Int = 0,
    val syncStatus: String = "PENDING",
)

/**
 * Append-only scan log. Every resolution attempt is recorded — successful or
 * denied — because a denied scan (wrong company, revoked code, missing
 * permission) is exactly the event a security review needs to see.
 *
 * No sensitive values: the log records which QR, which actor, what happened and
 * why, never the amounts or names behind the record.
 */
@Entity(
    tableName = "qr_scan_logs",
    indices = [Index(value = ["qrId"]), Index(value = ["companyId"])],
)
data class QrScanLogEntity(
    @PrimaryKey val id: String,
    val qrId: String,
    val companyId: String,
    val userId: String,
    val employeeId: String,
    val deviceId: String,
    val entityType: String,
    /** Only populated when the scan was authorised. */
    val entityId: String?,
    val action: String,
    /** ALLOWED · DENIED_UNKNOWN · DENIED_REVOKED · DENIED_EXPIRED · DENIED_COMPANY · DENIED_PERMISSION · DENIED_GEO · DENIED_VERSION */
    val result: String,
    val reason: String?,
    val gpsLat: Double? = null,
    val gpsLng: Double? = null,
    val wasOffline: Boolean,
    val timestampEpochMillis: Long,
    val syncStatus: String = "PENDING",
)

@Dao
interface QrRegistryDao {
    @Upsert
    suspend fun upsert(entry: QrRegistryEntity)

    @Upsert
    suspend fun upsertAll(entries: List<QrRegistryEntity>)

    @Query("SELECT * FROM qr_registry WHERE qrId = :qrId LIMIT 1")
    suspend fun findByQrId(qrId: String): QrRegistryEntity?

    @Query("SELECT * FROM qr_registry WHERE entityType = :entityType AND entityId = :entityId AND status = 'ACTIVE' LIMIT 1")
    suspend fun findActiveFor(entityType: String, entityId: String): QrRegistryEntity?

    @Query("SELECT * FROM qr_registry WHERE entityType = :entityType AND entityId = :entityId ORDER BY issuedAtEpochMillis DESC")
    fun historyFor(entityType: String, entityId: String): Flow<List<QrRegistryEntity>>

    @Query("SELECT * FROM qr_registry WHERE companyId = :companyId")
    fun allForCompany(companyId: String): Flow<List<QrRegistryEntity>>

    /**
     * Atomic claim used by revoke/reissue: only flips a row that is still in the
     * expected state, so two concurrent callers cannot both "succeed".
     * Returns the number of rows changed — 0 means someone else got there first.
     */
    @Query(
        """
        UPDATE qr_registry
        SET status = :newStatus, revokedAtEpochMillis = :atMillis, revokedBy = :by,
            revokeReason = :reason, syncStatus = 'PENDING'
        WHERE qrId = :qrId AND status = :expectedStatus
        """,
    )
    suspend fun transitionStatus(qrId: String, expectedStatus: String, newStatus: String, atMillis: Long, by: String, reason: String?): Int

    @Query("UPDATE qr_registry SET lastScannedAtEpochMillis = :atMillis, scanCount = scanCount + 1 WHERE qrId = :qrId")
    suspend fun recordScan(qrId: String, atMillis: Long)

    @Query("SELECT * FROM qr_registry WHERE syncStatus = 'PENDING'")
    suspend fun pendingSync(): List<QrRegistryEntity>
}

@Dao
interface QrScanLogDao {
    /** Insert-only by design — scan logs are append-only, never updated or deleted. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(log: QrScanLogEntity)

    @Query("SELECT * FROM qr_scan_logs WHERE qrId = :qrId ORDER BY timestampEpochMillis DESC")
    fun logsFor(qrId: String): Flow<List<QrScanLogEntity>>

    @Query("SELECT * FROM qr_scan_logs WHERE companyId = :companyId ORDER BY timestampEpochMillis DESC LIMIT :limit")
    fun recentForCompany(companyId: String, limit: Int = 200): Flow<List<QrScanLogEntity>>

    @Query("SELECT * FROM qr_scan_logs WHERE syncStatus = 'PENDING'")
    suspend fun pendingSync(): List<QrScanLogEntity>
}
