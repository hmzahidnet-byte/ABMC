package com.abm.erp.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.data.BackupManager
import com.abm.erp.data.BackupMetadata
import com.abm.erp.data.BackupStatus
import com.abm.erp.data.MockRepository
import com.abm.erp.data.getSavedCompanyCode
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import kotlinx.coroutines.launch
import java.time.format.DateTimeFormatter

private val DATE_FMT = DateTimeFormatter.ofPattern("d MMM yyyy, h:mm a")

/**
 * ViewModel intentionally takes a plain android.content.Context (application
 * context, held by the factory below) rather than reaching into a global
 * singleton — BackupManager's export/import are one-shot suspend calls, not
 * a StateFlow-backed repository stream like the rest of the app, so there's
 * nothing to delegate to except calling it directly here.
 */
class BackupRecoveryViewModel(private val appContext: android.content.Context) : ViewModel() {
    val history = BackupManager.history(appContext)

    var isWorking by mutableStateOf(false)
        private set
    var lastError by mutableStateOf<String?>(null)
        private set
    var lastSuccessMessage by mutableStateOf<String?>(null)
        private set

    fun createBackup() {
        val companyId = getSavedCompanyCode(appContext) ?: run { lastError = "কোম্পানি কোড পাওয়া যায়নি — আগে লগইন করুন।"; return }
        isWorking = true
        lastError = null
        viewModelScope.launch {
            try {
                val meta = BackupManager.exportBackup(appContext, companyId, MockRepository.currentUser.name)
                lastSuccessMessage = "✓ Backup সম্পন্ন — ${meta.collectionsIncluded}টা collection, ${formatSize(meta.fileSizeBytes)}"
            } catch (e: Exception) {
                lastError = "Backup ব্যর্থ হয়েছে: ${e.message ?: "unknown error"}"
            } finally {
                isWorking = false
            }
        }
    }

    fun restoreBackup(metadata: BackupMetadata) {
        isWorking = true
        lastError = null
        viewModelScope.launch {
            try {
                BackupManager.restoreBackup(appContext, metadata, MockRepository.currentUser.name)
                lastSuccessMessage = "✓ Restore সম্পন্ন — ${metadata.id}"
            } catch (e: Exception) {
                lastError = "Restore ব্যর্থ হয়েছে: ${e.message ?: "unknown error"}"
            } finally {
                isWorking = false
            }
        }
    }

    companion object {
        fun factory(appContext: android.content.Context) = object : androidx.lifecycle.ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T =
                BackupRecoveryViewModel(appContext.applicationContext) as T
        }
    }
}

private fun formatSize(bytes: Long): String = when {
    bytes >= 1_000_000 -> "%.1f MB".format(bytes / 1_000_000.0)
    bytes >= 1_000 -> "%.0f KB".format(bytes / 1_000.0)
    else -> "$bytes B"
}

@Composable
fun BackupRecoveryScreen(
    onClose: () -> Unit,
    vm: BackupRecoveryViewModel = viewModel(factory = BackupRecoveryViewModel.factory(LocalContext.current)),
) {
    val history by vm.history.collectAsState(initial = emptyList())
    var confirmRestore by remember { mutableStateOf<BackupMetadata?>(null) }

    Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Backup & Recovery", style = MaterialTheme.typography.titleMedium)
            IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = "Close") }
        }
        Text(
            "কোম্পানির সব ডেটার একটা snapshot নেয় Firestore থেকে, Firebase Storage-এ সংরক্ষিত হয়। Restore করলে বর্তমান ডেটা ওভাররাইট হবে।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(10.dp))

        Button(
            onClick = { vm.createBackup() },
            enabled = !vm.isWorking,
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (vm.isWorking) "কাজ চলছে…" else "📦 এখনই Backup নিন") }

        vm.lastSuccessMessage?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
        }
        vm.lastError?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall)
        }

        Spacer(Modifier.height(14.dp))
        Text("Backup history (${history.size})", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(6.dp))

        if (history.isEmpty()) {
            Text("এখনো কোনো backup নেওয়া হয়নি।", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(history, key = { it.id }) { meta ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(meta.createdAt.format(DATE_FMT), fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${meta.collectionsIncluded} collections · ${formatSize(meta.fileSizeBytes)} · by ${meta.triggeredBy}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            if (meta.status == BackupStatus.RESTORED && meta.restoredAt != null) {
                                Text("↺ Restored ${meta.restoredAt.format(DATE_FMT)} by ${meta.restoredBy ?: "—"}", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                            }
                        }
                        TextButton(onClick = { confirmRestore = meta }, enabled = !vm.isWorking) { Text("Restore") }
                    }
                }
            }
        }
    }

    confirmRestore?.let { meta ->
        Dialog(onDismissRequest = { confirmRestore = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Restore নিশ্চিত করুন", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = DangerRed)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "${meta.createdAt.format(DATE_FMT)}-এর backup থেকে restore করলে বর্তমান সব লাইভ ডেটা ওভাররাইট হয়ে যাবে। এটা পূর্বাবস্থায় ফেরানো যাবে না। নিশ্চিত?",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { vm.restoreBackup(meta); confirmRestore = null },
                            colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                        ) { Text("হ্যাঁ, Restore করুন") }
                        OutlinedButton(onClick = { confirmRestore = null }) { Text("বাতিল") }
                    }
                }
            }
        }
    }
}
