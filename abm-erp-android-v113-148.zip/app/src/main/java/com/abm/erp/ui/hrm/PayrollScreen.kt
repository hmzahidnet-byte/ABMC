package com.abm.erp.ui.hrm

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.abm.erp.core.BackToSubMenuLink
import com.abm.erp.core.GlassCard
import com.abm.erp.core.SubModuleGrid
import com.abm.erp.core.SubModuleItem
import com.abm.erp.data.EMPLOYEE_DIRECTORY
import com.abm.erp.data.MockRepository
import com.abm.erp.data.PayrollLine
import com.abm.erp.data.findMyCascade
import com.abm.erp.theme.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

private val IndigoStart = Color(0xFF5B67F1)
private val IndigoEnd = Color(0xFF6C7CF5)

class PayrollViewModel : ViewModel() {
    val currentUser get() = MockRepository.currentUser
    val routes = MockRepository.routes
    val payroll = MockRepository.payroll
    fun refreshPayrollAbsences() = MockRepository.refreshPayrollAbsences()

    // ---- Module 12: HR extras ----
    val leaveRequests = MockRepository.leaveRequests
    val lifecycleEvents = MockRepository.employeeLifecycleEvents
    fun applyLeave(employeeId: String, employeeName: String, type: com.abm.erp.data.LeaveType, from: java.time.LocalDate, to: java.time.LocalDate, reason: String) =
        MockRepository.applyLeave(employeeId, employeeName, type, from, to, reason)
    fun setLeaveStatus(id: String, status: com.abm.erp.data.LeaveStatus, onRejected: (String) -> Unit = {}) = MockRepository.setLeaveStatus(id, status, onRejected)
    fun recordLifecycleEvent(employeeId: String, employeeName: String, type: String, oldValue: String, newValue: String, effectiveDate: java.time.LocalDate, notes: String) =
        MockRepository.recordLifecycleEvent(employeeId, employeeName, type, oldValue, newValue, effectiveDate, notes)
    fun canApproveHr() = com.abm.erp.data.PermissionManager.canCurrentUser("hr", com.abm.erp.data.PermissionAction.APPROVE)
}

@Composable
fun PayrollScreen(startTab: Int? = null, onBack: () -> Unit = {}, vm: PayrollViewModel = viewModel()) {
    var tab by remember { mutableStateOf<Int?>(startTab) }
    val subItems = listOf(
        SubModuleItem("attend", "Attendance", "🕒", 0xFF5B67F1, 0xFF6C7CF5, Icons.Filled.Schedule),
        SubModuleItem("payroll", "Payroll", "💳", 0xFF3DDC97, 0xFF1FA972, Icons.Filled.CreditCard),
        SubModuleItem("leave", "Leave Management", "🏖️", 0xFF4E9CFF, 0xFF2E6FE0, Icons.Filled.BeachAccess),
        SubModuleItem("lifecycle", "Increment/Promotion/Transfer/Exit", "📋", 0xFF8A6DFF, 0xFF5B3FE0, Icons.Filled.Assignment),
        SubModuleItem("directory", "Employee Directory", "👥", 0xFF6EC6FF, 0xFF2E8FE0, Icons.Filled.Groups),
        SubModuleItem("empmgmt", "Employee Management", "🏢", 0xFFE85D4A, 0xFFC03A2B, Icons.Filled.Business),
    )

    // ---- Mini-dashboard data (Enterprise Workspace redesign) — same cascade scoping AttendanceTab uses ----
    val myCascadeForMini = remember {
        val me = EMPLOYEE_DIRECTORY.first { it.id == vm.currentUser.employeeId }
        findMyCascade(me).filter { it.role.name in setOf("SR", "TSM", "ASM") }
    }
    val presentCount by MockRepository.presentTodayCountFlow(myCascadeForMini.map { it.id }).collectAsState(initial = 0)
    val lateCount by MockRepository.lateTodayCountFlow(myCascadeForMini.map { it.id }).collectAsState(initial = 0)
    val absentCount = (myCascadeForMini.size - presentCount).coerceAtLeast(0)
    val leaveRequestsForMini by vm.leaveRequests.collectAsState()
    val today = java.time.LocalDate.now()
    val onLeaveToday = leaveRequestsForMini.count { it.status == com.abm.erp.data.LeaveStatus.APPROVED && !today.isBefore(it.fromDate) && !today.isAfter(it.toDate) }
    val payrollForMini by vm.payroll.collectAsState()
    val totalOvertimePay = payrollForMini.sumOf { it.overtimePay }

    Column(Modifier.fillMaxSize()) {
        if (startTab == null) {
        com.abm.erp.core.ModuleWorkspaceHeader("HR Management System", "🧑‍💼", 0xFFDB2777, 0xFF9D174D, iconVector = Icons.Filled.Groups, miniDashboard = {
            com.abm.erp.core.ModuleStat("Present", "$presentCount", SuccessGreen) { tab = 0 }
            com.abm.erp.core.ModuleStat("Absent", "$absentCount", if (absentCount > 0) DangerRed else SuccessGreen)
            com.abm.erp.core.ModuleStat("Late", "$lateCount", if (lateCount > 0) WarningAmber else SuccessGreen)
            com.abm.erp.core.ModuleStat("Leave", "$onLeaveToday", TextPrimary) { tab = 2 }
            com.abm.erp.core.ModuleStat("Overtime", "৳${"%,.0f".format(totalOvertimePay)}", TextPrimary)
        }, quickActions = {
            AssistChip(onClick = { tab = 3 }, label = { Text("+ Add Request") })
            AssistChip(onClick = { tab = 0 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.Schedule, null, Modifier.size(16.dp)) }, label = { Text("Attendance") })
            AssistChip(onClick = { tab = 2 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.BeachAccess, null, Modifier.size(16.dp)) }, label = { Text("Leave") })
            AssistChip(onClick = { tab = 0 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.Timer, null, Modifier.size(16.dp)) }, label = { Text("Overtime") })
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("EmployeeProfile", "LeaveRequest", "AttendanceRecord", "PayrollLine", "CorrectionRequest"))
        })
        } else {
            val taskTitle = subItems.firstOrNull { it.key == when (tab) { 0 -> "attend"; 1 -> "payroll"; 2 -> "leave"; 3 -> "lifecycle"; 4 -> "directory"; else -> "empmgmt" } }?.label ?: "HR"
            com.abm.erp.core.TaskHeader(taskTitle, 0xFFDB2777, 0xFF9D174D, onBack = onBack, iconVector = Icons.Filled.Groups)
        }
        Column(Modifier.fillMaxSize().padding(16.dp)) {
        if (tab == null) {
            SubModuleGrid(subItems) { key -> tab = when (key) { "attend" -> 0; "payroll" -> 1; "leave" -> 2; "lifecycle" -> 3; "directory" -> 4; else -> 5 } }
        } else {
            if (startTab == null) BackToSubMenuLink(onClick = { tab = null })
            when (tab) {
                0 -> AttendanceTab(vm)
                1 -> PayrollTab(vm)
                2 -> LeaveManagementTab(vm)
                3 -> LifecycleEventsTab(vm)
                4 -> EmployeeDirectoryTab()
                else -> EmployeeManagementTab()
            }
        }
        }
    }
}

/**
 * FUNDAMENTAL RULE — every employee-level list uses the same area-matching
 * cascade (findMyCascade): a viewer only ever sees their own subordinate
 * chain, never sideways or upward. Chairman's unrestricted geo naturally
 * returns everyone; nobody else gets that by accident.
 */
@Composable
private fun AttendanceTab(vm: PayrollViewModel) {
    var selectedEmployeeId by remember { mutableStateOf<String?>(null) }
    val myCascade = remember {
        val me = EMPLOYEE_DIRECTORY.first { it.id == vm.currentUser.employeeId }
        findMyCascade(me).filter { it.role.name in setOf("SR", "TSM", "ASM") }
    }

    if (selectedEmployeeId == null) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(IndigoStart, IndigoEnd)), RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)).padding(18.dp)) {
                Column {
                    Text("Employee Attend List", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(6.dp))
                    val activeCount by MockRepository.presentTodayCountFlow(myCascade.map { it.id }).collectAsState(initial = 0)
                    Text("এখন কর্মরত: $activeCount / ${myCascade.size} জন", color = Color(0xFFE4E9FF), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(4.dp))
            LazyColumn(Modifier.fillMaxSize().offset(y = (-16).dp), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    // Decision 2 (v113-72) — attendance-correction requests are approved
                    // here, on the attendance roster they actually change.
                    com.abm.erp.core.ModuleApprovalSection(
                        title = "Attendance correction অনুমোদন",
                        entityTypes = setOf("AttendanceRecord"),
                    )
                }
                if (myCascade.isEmpty()) {
                    item { com.abm.erp.core.WorkspaceEmptyState("কোনো কর্মী এই তালিকায় নেই।", "🕒") }
                }
                items(myCascade) { emp ->
                    val isPresent by MockRepository.isPresentTodayFlow(emp.id).collectAsState(initial = false)
                    GlassCard(modifier = Modifier.fillMaxWidth().clickable { selectedEmployeeId = emp.id }) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(36.dp).clip(CircleShape).background(Brush.linearGradient(listOf(IndigoStart, IndigoEnd))), contentAlignment = Alignment.Center) {
                                    Text(emp.name.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    // Blueprint §31 — HR's signature moment: a presence dot beside every
                                    // name, so a glance down the roster answers "who is in today".
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        com.abm.erp.core.PresenceDot(present = isPresent)
                                        Spacer(Modifier.width(6.dp))
                                        Text(emp.name, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    }
                                    Text(emp.role.name, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                }
                            }
                            Box(
                                Modifier.size(26.dp).clip(RoundedCornerShape(8.dp))
                                    .background(if (isPresent) SuccessGreen.copy(alpha = 0.12f) else DangerRed.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center,
                            ) { Text(if (isPresent) "P" else "A", color = if (isPresent) SuccessGreen else DangerRed, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column { Text("In Time", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("09:00 AM", style = MaterialTheme.typography.labelSmall) }
                            Column { Text("Out Time", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text(if (isPresent) "—" else "05:00 PM", style = MaterialTheme.typography.labelSmall) }
                        }
                    }
                }
                if (myCascade.isEmpty()) item { Text("আপনার অধীনে কেউ নেই।", color = TextSecondary) }
            }
        }
    } else {
        val emp = EMPLOYEE_DIRECTORY.first { it.id == selectedEmployeeId }
        AttendanceDetail(emp.id, emp.name, emp.role.name, vm) { selectedEmployeeId = null }
    }
}

@Composable
private fun AttendanceDetail(employeeId: String, name: String, role: String, vm: PayrollViewModel, onBack: () -> Unit) {
    val routes by vm.routes.collectAsState()
    val myRoute = routes.firstOrNull { it.employeeId == employeeId }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(IndigoStart, IndigoEnd)), RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)).padding(18.dp)) {
            Column {
                Text("←", color = Color.White, fontSize = 16.sp, modifier = Modifier.clickable(onClick = onBack))
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                        Text(name.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("$name Details", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(role, color = Color(0xFFE4E9FF), fontSize = 11.sp)
                    }
                }
            }
        }
        LazyColumn(Modifier.fillMaxSize().offset(y = (-16).dp), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    // v86 fix: this used to show a hardcoded "6h 30m" and a
                    // fake weekly-hours bar chart (listOf(7f,7.5f,...)) with
                    // no real check-in/out TIME data behind it — a direct
                    // "do not fabricate attendance values" violation. This
                    // codebase only tracks a per-day checkedIn boolean, not
                    // clock times, so real hour totals can't be computed
                    // honestly. Showing real present/absent instead.
                    Text("Attendance (Last 7 Days)", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    val records by MockRepository.attendanceRecordsFor(employeeId).collectAsState(initial = emptyList())
                    val last7Days = (6 downTo 0).map { java.time.LocalDate.now().minusDays(it.toLong()) }
                    Row(Modifier.fillMaxWidth().height(60.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                        last7Days.forEach { day ->
                            val present = records.any { it.dateEpochDay == day.toEpochDay() && it.checkedIn }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.width(18.dp).height(if (present) 40.dp else 8.dp).background(if (present) SuccessGreen else Color(0xFFDCE6F5), RoundedCornerShape(4.dp)))
                                Spacer(Modifier.height(3.dp))
                                Text(day.dayOfMonth.toString(), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                    }
                }
            }
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Shift Planning", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    var shiftContext = androidx.compose.ui.platform.LocalContext.current
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        com.abm.erp.data.ShiftType.values().forEach { s ->
                            TextButton(onClick = {
                                val today = java.time.LocalDate.now()
                                android.app.DatePickerDialog(shiftContext, { _, y, m, d ->
                                    MockRepository.planShift(employeeId, java.time.LocalDate.of(y, m + 1, d).toEpochDay(), s)
                                }, today.year, today.monthValue - 1, today.dayOfMonth).show()
                            }) { Text(s.name, style = MaterialTheme.typography.labelSmall) }
                        }
                    }
                }
            }
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("📍 Location Trail — Live Presence Heartbeat", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    val pings = myRoute?.breadcrumbs?.take(6) ?: emptyList()
                    if (pings.isEmpty()) {
                        Text("আজ এখনো কোনো checkpoint রেকর্ড হয়নি।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    } else {
                        pings.forEach { ping ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                                Text(ping.timestamp.toLocalTime().toString(), style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(70.dp))
                                Text("${"%.4f".format(ping.lat)}°N, ${"%.4f".format(ping.lng)}°E", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                    }
                }
            }
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    // v113-130 — this card showed literal hardcoded numbers
                    // (Present 13, Absent 0, Holiday 4, Half Day 6, Week Off 4,
                    // Leave 3) for every employee, always, regardless of their
                    // actual attendance — the same fabrication class the v86 fix
                    // right above this card already caught and corrected, just
                    // missed here. Computing real counts from the same `records`
                    // flow already in scope (last 30 days, clearly labeled).
                    // Holiday/Half Day/Week Off dropped rather than approximated:
                    // AttendanceRecordEntity has no real field backing any of the
                    // three (only checkedIn/isLate/isOnLeave/overtimeMinutes
                    // genuinely exist), matching the same "don't fabricate,
                    // show what's real" call the v86 fix already made.
                    Text("Attendance (Last 30 Days)", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    val attendanceStatsRecords by MockRepository.attendanceRecordsFor(employeeId).collectAsState(initial = emptyList())
                    val cutoffDay = java.time.LocalDate.now().minusDays(30).toEpochDay()
                    val last30 = attendanceStatsRecords.filter { it.dateEpochDay >= cutoffDay }
                    val presentN = last30.count { it.checkedIn }
                    val leaveN = last30.count { it.isOnLeave }
                    val absentN = last30.count { !it.checkedIn && !it.isOnLeave }
                    val lateN = last30.count { it.isLate }
                    val stats = listOf("Present" to (presentN to SuccessGreen), "Absent" to (absentN to DangerRed), "Late" to (lateN to WarningAmber), "Leave" to (leaveN to Color(0xFF00B4B4)))
                    stats.chunked(3).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { (label, pair) ->
                                val (value, color) = pair
                                Column(
                                    modifier = Modifier.weight(1f).background(Color(0xFFF7F8FA), RoundedCornerShape(10.dp)).padding(8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                ) {
                                    Text("$value", fontWeight = FontWeight.Bold, color = color, fontSize = 15.sp)
                                    Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun PayrollTab(vm: PayrollViewModel) {
    val payroll by vm.payroll.collectAsState()
    var expandedId by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    val filteredPayroll = remember(payroll, query) { if (query.isBlank()) payroll else payroll.filter { it.employeeName.contains(query, ignoreCase = true) } }
    LaunchedEffect(Unit) { vm.refreshPayrollAbsences() }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Dynamic 3-layer payroll: base pay × achievement curve + commission − absence penalty", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            val totalPayroll = payroll.sumOf { it.basePay + it.commission }
            var finalizeError by remember { mutableStateOf<String?>(null) }
            finalizeError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
            Button(onClick = { MockRepository.finalizePayrollPreparation(java.time.LocalDate.now().toString().take(7), MockRepository.currentUser.name, totalPayroll, onRejected = { r -> finalizeError = r }) }, modifier = Modifier.fillMaxWidth()) {
                Text("Finalize This Payroll Run (৳${"%,.0f".format(totalPayroll)})")
            }
            Text("Finalization needs approval from someone other than whoever prepared it (segregation of duties).", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Spacer(Modifier.height(8.dp))
            // Decision 2 (v113-72) — payroll-finalization approvals are actioned here,
            // in the Payroll tab that raised them, not in a separate inbox.
            com.abm.erp.core.ModuleApprovalSection(
                title = "Payroll finalization অনুমোদন",
                entityTypes = setOf("Payroll"),
            )
            OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("কর্মীর নাম দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        if (filteredPayroll.isEmpty()) {
            item { com.abm.erp.core.WorkspaceEmptyState("কোনো payroll লাইন পাওয়া যায়নি।", "💳") }
        }
        items(filteredPayroll) { line ->
            PayrollCard(line, expanded = expandedId == line.employeeId, onToggle = {
                expandedId = if (expandedId == line.employeeId) null else line.employeeId
            })
        }
    }
}

@Composable
private fun PayrollCard(line: PayrollLine, expanded: Boolean, onToggle: () -> Unit) {
    val band = when {
        line.achievementPct >= 100 -> SuccessGreen
        line.achievementPct >= 80 -> WarningAmber
        else -> DangerRed
    }
    GlassCard(modifier = Modifier.fillMaxWidth().clickable(onClick = onToggle)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(line.employeeName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text("Achievement: ${"%.1f".format(line.achievementPct)}%", color = band, style = MaterialTheme.typography.labelSmall)
            }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text("৳${"%,.0f".format(line.netPayable)}", style = MaterialTheme.typography.titleMedium, color = ElectricCyan)
                val context = androidx.compose.ui.platform.LocalContext.current
                IconButton(onClick = {
                    try {
                        val file = com.abm.erp.core.exportPayslipPdf(context, line)
                        com.abm.erp.core.shareStructuredPdf(context, file, "Payslip — ${line.employeeName}")
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(context, "Payslip PDF তৈরি ব্যর্থ হয়েছে: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                    }
                }) { Text("📄") }
            }
        }
        if (expanded) {
            Spacer(Modifier.height(10.dp))
            Divider(color = GlassBorder)
            Spacer(Modifier.height(10.dp))
            StatRow("Base pay", line.basePay)
            StatRow("Scaling factor", null, "${"%.2f".format(line.scalingFactor)}×")
            StatRow("Base × scaling", line.basePay * line.scalingFactor)
            StatRow("Sales commission (${"%.1f".format(line.commissionRate * 100)}%)", line.commission)
            StatRow("Unapproved absences", null, "${line.unapprovedAbsenceDays} day(s) — GPS-verified")
            StatRow("Absence penalty", -line.absencePenalty)
            Spacer(Modifier.height(6.dp))
            Divider(color = GlassBorder)
            Spacer(Modifier.height(6.dp))
            StatRow("Net payable", line.netPayable, bold = true)
            Spacer(Modifier.height(8.dp))
            Text(
                "Dispute-proof statement generated · penalty derived from missing/spoofed GPS nodes during duty hours, not manual entry.",
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}

@Composable
private fun StatRow(label: String, amount: Double?, override: String? = null, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(
            override ?: "৳${"%,.0f".format(amount ?: 0.0)}",
            color = if (bold) ElectricCyan else TextPrimary,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

@Composable
private fun LeaveManagementTab(vm: PayrollViewModel) {
    val leaves by vm.leaveRequests.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    var statusFilter by remember { mutableStateOf<com.abm.erp.data.LeaveStatus?>(null) }
    val filteredLeaves = leaves.filter { statusFilter == null || it.status == statusFilter }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "Employee,Type,From,To,Status\n"
                    val rows = leaves.joinToString("\n") { l -> com.abm.erp.core.toCsvRow(l.employeeName, l.type, l.fromDate, l.toDate, l.status) }
                    val file = java.io.File(context.getExternalFilesDir(null), "leave_requests_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Leave Requests (${leaves.size})\n" + leaves.take(20).joinToString("\n") { "${it.employeeName} — ${it.type} (${it.status})" }
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                    try { context.startActivity(android.content.Intent.createChooser(intent, "Leave Requests")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                },
            )
        }
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Apply Leave") }
        Spacer(Modifier.height(8.dp))
        // Decision 2 (v113-72) — leave approvals live here, inside HRM, not in a
        // central inbox. Renders nothing when there is nothing pending.
        com.abm.erp.core.ModuleApprovalSection(
            title = "Leave অনুমোদনের অপেক্ষায়",
            approvalTypes = setOf(com.abm.erp.data.ApprovalType.LEAVE),
        )
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = statusFilter == null, onClick = { statusFilter = null }, label = { Text("সব") })
            com.abm.erp.data.LeaveStatus.values().forEach { s ->
                FilterChip(selected = statusFilter == s, onClick = { statusFilter = s }, label = { Text(s.name) })
            }
        }
        Spacer(Modifier.height(10.dp))
        if (filteredLeaves.isEmpty()) {
            com.abm.erp.core.WorkspaceEmptyState("কোনো Leave Request পাওয়া যায়নি।", "🏖️")
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filteredLeaves) { l ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(l.employeeName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${l.type} · ${l.fromDate} → ${l.toDate} (${l.days} days)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            if (l.reason.isNotBlank()) Text(l.reason, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        com.abm.erp.core.StatusPill(l.status.name)
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "LeaveRequest", entityId = l.id, entityLabel = l.employeeName,
                            shareText = "Leave: ${l.employeeName}\n${l.type}: ${l.fromDate} → ${l.toDate}\nStatus: ${l.status}",
                            csvHeader = "Employee,Type,From,To,Days,Status",
                            csvRow = com.abm.erp.core.toCsvRow(l.employeeName, l.type, l.fromDate, l.toDate, l.days, l.status),
                        )
                    }
                    if (l.status == com.abm.erp.data.LeaveStatus.PENDING && vm.canApproveHr()) {
                        var leaveError by remember(l.id) { mutableStateOf<String?>(null) }
                        leaveError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.setLeaveStatus(l.id, com.abm.erp.data.LeaveStatus.APPROVED, onRejected = { r -> leaveError = r }) }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) { Text("Approve") }
                            OutlinedButton(onClick = { vm.setLeaveStatus(l.id, com.abm.erp.data.LeaveStatus.REJECTED, onRejected = { r -> leaveError = r }) }) { Text("Reject", color = DangerRed) }
                        }
                    }
                }
            }
            if (leaves.isEmpty()) item { Text("এখনো কোনো Leave application নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(modifier = Modifier.fillMaxSize(), color = com.abm.erp.theme.DashBg) {
                var selectedEmployee by remember { mutableStateOf<com.abm.erp.data.Employee?>(null) }
                var expanded by remember { mutableStateOf(false) }
                var type by remember { mutableStateOf(com.abm.erp.data.LeaveType.CASUAL) }
                var fromDaysOffset by remember { mutableStateOf("0") }
                var toDaysOffset by remember { mutableStateOf("1") }
                var reason by remember { mutableStateOf("") }
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    com.abm.erp.core.ModuleGradientHeader("Apply Leave", "🏖️", 0xFF4E9CFF, 0xFF2E6FE0, iconVector = Icons.Filled.BeachAccess)
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showNew = false }) { Text("✕ Close") }
                    }
                    Column(Modifier.padding(16.dp)) {
                    Spacer(Modifier.height(10.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedEmployee?.name ?: "Select employee") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            EMPLOYEE_DIRECTORY.forEach { e -> DropdownMenuItem(text = { Text(e.name) }, onClick = { selectedEmployee = e; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        com.abm.erp.data.LeaveType.values().forEach { t -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t.name) }) }
                    }
                    if (selectedEmployee != null && type != com.abm.erp.data.LeaveType.UNPAID) {
                        Spacer(Modifier.height(6.dp))
                        val balance = remember(selectedEmployee, type, leaves) { MockRepository.leaveBalance(selectedEmployee!!.id, type) }
                        Text("Balance: $balance day(s) remaining this year", style = MaterialTheme.typography.labelSmall, color = if (balance <= 0) DangerRed else TextSecondary)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = fromDaysOffset, onValueChange = { fromDaysOffset = it }, label = { Text("From (আজ থেকে দিন)") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = toDaysOffset, onValueChange = { toDaysOffset = it }, label = { Text("To (আজ থেকে দিন)") }, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val e = selectedEmployee ?: return@Button
                            val from = java.time.LocalDate.now().plusDays(fromDaysOffset.toLongOrNull() ?: 0)
                            val to = java.time.LocalDate.now().plusDays(toDaysOffset.toLongOrNull() ?: 1)
                            if (vm.applyLeave(e.id, e.name, type, from, to, reason) != null) showNew = false
                        },
                        enabled = selectedEmployee != null,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Submit") }
                    }
                }
            }
        }
    }
}

@Composable
private fun LifecycleEventsTab(vm: PayrollViewModel) {
    val events by vm.lifecycleEvents.collectAsState()
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        if (vm.canApproveHr()) {
            Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Record Event") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (events.isEmpty()) {
                item { com.abm.erp.core.WorkspaceEmptyState("কোনো Lifecycle Event নেই।", "📋") }
            }
            items(events) { e ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(e.employeeName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${e.oldValue} → ${e.newValue} · effective ${e.effectiveDate}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            if (e.notes.isNotBlank()) Text(e.notes, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text(e.type, color = ElectricCyan, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "EmployeeLifecycleEvent", entityId = e.id, entityLabel = e.employeeName,
                            shareText = "${e.type}: ${e.employeeName}\n${e.oldValue} → ${e.newValue}\nEffective: ${e.effectiveDate}",
                            csvHeader = "Employee,Type,OldValue,NewValue,EffectiveDate",
                            csvRow = com.abm.erp.core.toCsvRow(e.employeeName, e.type, e.oldValue, e.newValue, e.effectiveDate),
                        )
                    }
                }
            }
            if (events.isEmpty()) item { Text("এখনো কোনো lifecycle event নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(modifier = Modifier.fillMaxSize(), color = com.abm.erp.theme.DashBg) {
                var selectedEmployee by remember { mutableStateOf<com.abm.erp.data.Employee?>(null) }
                var expanded by remember { mutableStateOf(false) }
                var type by remember { mutableStateOf("INCREMENT") }
                var oldValue by remember { mutableStateOf("") }
                var newValue by remember { mutableStateOf("") }
                var notes by remember { mutableStateOf("") }
                Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Record Employee Event", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { showNew = false }) { Text("✕ Close") }
                    }
                    Spacer(Modifier.height(10.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedEmployee?.name ?: "Select employee") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            EMPLOYEE_DIRECTORY.forEach { emp -> DropdownMenuItem(text = { Text(emp.name) }, onClick = { selectedEmployee = emp; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("INCREMENT", "PROMOTION", "TRANSFER", "EXIT", "TRAINING").forEach { t -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t, style = MaterialTheme.typography.labelSmall) }) }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = oldValue, onValueChange = { oldValue = it }, label = { Text("আগে (e.g. পুরনো বেতন/পদবি/শাখা)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newValue, onValueChange = { newValue = it }, label = { Text("এখন") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("নোট") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val e = selectedEmployee ?: return@Button
                            if (vm.recordLifecycleEvent(e.id, e.name, type, oldValue, newValue, java.time.LocalDate.now(), notes)) showNew = false
                        },
                        enabled = selectedEmployee != null,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Save") }
                }
            }
        }
    }
}

/** v86 - Employee Directory / Department Hierarchy. Real EMPLOYEE_DIRECTORY grouped by role tier (this org's real hierarchy model — role-based, not department-based). */
@Composable
private fun EmployeeDirectoryTab() {
    val hierarchy = remember { MockRepository.roleHierarchy() }
    var query by remember { mutableStateOf("") }
    val filteredHierarchy = remember(hierarchy, query) {
        if (query.isBlank()) hierarchy
        else hierarchy.map { (role, emps) -> role to emps.filter { it.name.contains(query, ignoreCase = true) || it.geoLabel.contains(query, ignoreCase = true) } }
            .filter { (_, emps) -> emps.isNotEmpty() }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text("নাম বা এলাকা দিয়ে খুঁজুন…") },
            singleLine = true, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        )
        if (filteredHierarchy.all { (_, emps) -> emps.isEmpty() }) {
            com.abm.erp.core.WorkspaceEmptyState("কোনো কর্মী পাওয়া যায়নি।", "👥")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                filteredHierarchy.forEach { (role, employees) ->
                    if (employees.isNotEmpty()) {
                        item {
                            Text("${role.name} (${employees.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextSecondary)
                        }
                        items(employees) { e ->
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Text(e.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                Text(e.geoLabel, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Foundation 2, Sections 2/3/14/15 — real Employee Management: list with
 * search/filter, onboarding-draft creation, and hierarchy tree view. This
 * is the REAL, persisted employee system (EmployeeProfile) — distinct
 * from the synthetic EmployeeDirectoryTab above (EMPLOYEE_DIRECTORY).
 */
@Composable
private fun EmployeeManagementTab() {
    var subTab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = subTab) {
            Tab(selected = subTab == 0, onClick = { subTab = 0 }, text = { Text("List") })
            Tab(selected = subTab == 1, onClick = { subTab = 1 }, text = { Text("Hierarchy") })
        }
        Spacer(Modifier.height(10.dp))
        when (subTab) {
            0 -> EmployeeListSection()
            else -> EmployeeHierarchySection()
        }
    }
}

@Composable
private fun EmployeeListSection() {
    val allEmployees by MockRepository.employeeProfiles.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf<String?>(null) }
    val accountScope = rememberCoroutineScope()
    var showNew by remember { mutableStateOf(false) }

    val filtered = remember(allEmployees, searchQuery, statusFilter) {
        val q = searchQuery.trim().lowercase()
        allEmployees.filter { e ->
            !e.isDeleted &&
                (q.isBlank() || e.fullName.lowercase().contains(q) || e.employeeCode.lowercase().contains(q) || e.mobile.contains(q) || e.department.lowercase().contains(q) || e.designation.lowercase().contains(q)) &&
                (statusFilter == null || e.status.name == statusFilter)
        }
    }

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Employee (Draft)") }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = searchQuery, onValueChange = { searchQuery = it }, placeholder = { Text("নাম/কোড/মোবাইল/department দিয়ে খুঁজুন") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            FilterChip(selected = statusFilter == null, onClick = { statusFilter = null }, label = { Text("All") })
            com.abm.erp.data.EmployeeStatus.values().forEach { s -> FilterChip(selected = statusFilter == s.name, onClick = { statusFilter = s.name }, label = { Text(s.name) }) }
        }
        Spacer(Modifier.height(10.dp))
        if (filtered.isEmpty()) {
            Text("এখনো কোনো real employee record নেই — এটা EMPLOYEE_DIRECTORY (demo data) থেকে সম্পূর্ণ আলাদা, real onboarding দিয়ে শুরু হয়।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered, key = { it.id }) { e ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${e.fullName} (${e.employeeCode})", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${e.designation.ifBlank { e.role.name }} · ${e.department.ifBlank { "—" }}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        com.abm.erp.core.StatusPill(e.status.name)
                    }
                    if (e.onboardingStatus != com.abm.erp.data.EmployeeOnboardingStatus.ACTIVE) {
                        Text("Onboarding: ${e.onboardingStatus}" + (e.rejectReason?.let { " — $it" } ?: ""), style = MaterialTheme.typography.labelSmall, color = if (e.onboardingStatus == com.abm.erp.data.EmployeeOnboardingStatus.REJECTED) DangerRed else WarningAmber)
                        var onboardError by remember(e.id) { mutableStateOf<String?>(null) }
                        onboardError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (e.onboardingStatus == com.abm.erp.data.EmployeeOnboardingStatus.DRAFT || e.onboardingStatus == com.abm.erp.data.EmployeeOnboardingStatus.REJECTED) {
                                TextButton(onClick = { MockRepository.submitEmployeeForReview(e.id, onRejected = { r -> onboardError = r }) }) { Text("Submit") }
                            } else {
                                TextButton(onClick = { MockRepository.advanceEmployeeOnboarding(e.id, onRejected = { r -> onboardError = r }) }) { Text("Advance Stage") }
                                var showReject by remember { mutableStateOf(false) }
                                TextButton(onClick = { showReject = true }) { Text("Reject", color = DangerRed) }
                                if (showReject) {
                                    var reason by remember { mutableStateOf("") }
                                    Dialog(onDismissRequest = { showReject = false }) {
                                        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                            Column(Modifier.padding(16.dp)) {
                                                Text("Reject ${e.fullName}", style = MaterialTheme.typography.titleMedium)
                                                Spacer(Modifier.height(8.dp))
                                                OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
                                                Spacer(Modifier.height(10.dp))
                                                var rejectOnboardError by remember { mutableStateOf<String?>(null) }
                                        rejectOnboardError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                        Button(onClick = { val ok = MockRepository.rejectEmployeeOnboarding(e.id, reason, onRejected = { r -> rejectOnboardError = r }); if (ok) showReject = false }, enabled = reason.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Confirm Reject") }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                    Spacer(Modifier.height(6.dp))
                    var showManage by remember { mutableStateOf(false) }
                    TextButton(onClick = { showManage = !showManage }) { Text(if (showManage) "Hide Manage" else "⚙ Manage") }
                    if (showManage) {
                        val perf by produceState(initialValue = MockRepository.EmployeePerformance(0, 0.0, 0.0, 0.0, 0.0, 0, 0), e.id) {
                            value = MockRepository.computeEmployeePerformance(e.id)
                        }
                        Text("Retailer coverage: ${perf.retailerCoverage} · 90d sales ৳${"%,.0f".format(perf.salesValue90Days)} · Collection eff. ${"%.0f".format(perf.collectionEfficiencyPct)}%", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("Visit compliance: ${"%.0f".format(perf.visitCompliancePct)}% · Inactive retailers: ${perf.inactiveRetailerCount}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Spacer(Modifier.height(6.dp))
                        var showManagerPicker by remember { mutableStateOf(false) }
                        var showLimits by remember { mutableStateOf(false) }
                        var showTransfer by remember { mutableStateOf(false) }
                        var showDelegate by remember { mutableStateOf(false) }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            TextButton(onClick = { showManagerPicker = true }) { Text("Set Manager") }
                            TextButton(onClick = { showLimits = true }) { Text("Approval Limits") }
                            TextButton(onClick = { showTransfer = true }) { Text("Transfer") }
                            TextButton(onClick = { showDelegate = true }) { Text("Delegate") }
                        }
                        var showOverride by remember { mutableStateOf(false) }
                        TextButton(onClick = { showOverride = true }) { Text("Emergency Geo-Override", color = WarningAmber) }
                        run {
                            val photoContext = androidx.compose.ui.platform.LocalContext.current
                            var uploadingPhoto by remember { mutableStateOf(false) }
                            val photoPicker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
                                if (uri != null) {
                                    uploadingPhoto = true
                                    MockRepository.uploadEmployeeProfilePhoto(photoContext, e.id, uri.toString()) { uploadingPhoto = false }
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (!e.profilePhotoUri.isNullOrBlank()) {
                                    coil.compose.AsyncImage(model = e.profilePhotoUri, contentDescription = "Profile photo", modifier = Modifier.size(48.dp).clip(androidx.compose.foundation.shape.CircleShape))
                                }
                                TextButton(onClick = { photoPicker.launch("image/*") }) { Text(if (uploadingPhoto) "Uploading..." else if (e.profilePhotoUri.isNullOrBlank()) "Add Photo" else "Change Photo") }
                            }
                        }
                        var showEmployeeQr by remember { mutableStateOf(false) }
                        TextButton(onClick = {
                            showEmployeeQr = !showEmployeeQr
                            if (showEmployeeQr) MockRepository.logAudit("EmployeeProfile", e.id, "QR_VIEWED", reason = "by ${MockRepository.currentUser.name}")
                        }) { Text(if (showEmployeeQr) "Hide Employee QR" else "🔳 Employee ID QR Code") }
                        if (showEmployeeQr) {
                            val empQrBitmap = remember(e.employeeCode) { com.abm.erp.util.QrCodeGenerator.generate(e.employeeCode.ifBlank { e.id }, 300) }
                            Image(bitmap = empQrBitmap.asImageBitmap(), contentDescription = "QR code for ${e.fullName}", modifier = Modifier.size(140.dp))
                            Text(e.employeeCode.ifBlank { e.id }, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        var showAreaAssign by remember { mutableStateOf(false) }
                        val myAreas by MockRepository.employeeAreaAssignments.collectAsState()
                        val activeAreas = myAreas.filter { it.employeeId == e.id && it.isActive }
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(
                                if (activeAreas.isEmpty()) "⚠ No area assigned" else "Areas: ${activeAreas.joinToString(", ") { "${it.districtName ?: it.districtId ?: "?"} (${it.assignmentType.name})" }}",
                                style = MaterialTheme.typography.labelSmall, color = if (activeAreas.isEmpty()) WarningAmber else TextSecondary,
                            )
                            TextButton(onClick = { showAreaAssign = true }) { Text("Manage Area") }
                        }
                        if (showAreaAssign) {
                            var areaSelection by remember { mutableStateOf(com.abm.erp.ui.core.AdminSelection()) }
                            var assignType by remember { mutableStateOf(com.abm.erp.data.AreaAssignmentType.PRIMARY) }
                            var areaError by remember { mutableStateOf<String?>(null) }
                            Dialog(onDismissRequest = { showAreaAssign = false }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp).heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
                                        Text("Area Assignment — ${e.fullName}", style = MaterialTheme.typography.titleMedium)
                                        Spacer(Modifier.height(8.dp))
                                        activeAreas.forEach { a ->
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("${a.assignmentType.name}: ${a.districtName ?: "-"} / ${a.upazilaName ?: "-"} (since ${a.startDate})", style = MaterialTheme.typography.labelSmall)
                                                TextButton(onClick = {
                                                    if (a.assignmentType == com.abm.erp.data.AreaAssignmentType.PRIMARY) {
                                                        MockRepository.transferEmployeeArea(e.id, areaSelection.divisionId, areaSelection.districtId, areaSelection.upazilaId, areaSelection.unionId, null, null, onRejected = { r -> areaError = r })
                                                    }
                                                }) { Text("Transfer here", style = MaterialTheme.typography.labelSmall) }
                                            }
                                        }
                                        Spacer(Modifier.height(10.dp))
                                        Text("New assignment", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                        com.abm.erp.ui.core.AdminLocationCascadeSelector(selection = areaSelection, onSelectionChange = { areaSelection = it })
                                        Spacer(Modifier.height(6.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            com.abm.erp.data.AreaAssignmentType.values().forEach { t ->
                                                FilterChip(selected = assignType == t, onClick = { assignType = t }, label = { Text(t.name, style = MaterialTheme.typography.labelSmall) })
                                            }
                                        }
                                        areaError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                        Spacer(Modifier.height(10.dp))
                                        Button(
                                            onClick = {
                                                val ok = MockRepository.assignEmployeeArea(e.id, areaSelection.divisionId, areaSelection.districtId, areaSelection.upazilaId, areaSelection.unionId, null, null, assignType, onRejected = { r -> areaError = r })
                                                if (ok) showAreaAssign = false
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                        ) { Text("Assign") }
                                    }
                                }
                            }
                        }
                        var showAppraisal by remember { mutableStateOf(false) }
                        val myAppraisals by MockRepository.employeeAppraisals.collectAsState()
                        val empAppraisals = myAppraisals.filter { it.employeeId == e.id }
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(
                                if (empAppraisals.isEmpty()) "কোনো appraisal নেই" else "সর্বশেষ: ${empAppraisals.maxByOrNull { it.periodEnd }?.rating ?: "score pending"}",
                                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                            )
                            TextButton(onClick = { showAppraisal = true }) { Text("Appraisal") }
                        }
                        if (showAppraisal) {
                            var periodStart by remember { mutableStateOf(java.time.LocalDate.now().minusMonths(1)) }
                            var periodEnd by remember { mutableStateOf(java.time.LocalDate.now()) }
                            var salesTarget by remember { mutableStateOf("") }
                            var collectionTarget by remember { mutableStateOf("") }
                            var supervisorScore by remember { mutableStateOf("") }
                            var hrScore by remember { mutableStateOf("") }
                            var managerComment by remember { mutableStateOf("") }
                            var selectedAppraisalId by remember { mutableStateOf<String?>(null) }
                            var appraisalGenError by remember { mutableStateOf<String?>(null) }
                            var manualScoreError by remember { mutableStateOf<String?>(null) }
                            Dialog(onDismissRequest = { showAppraisal = false }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp).heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                                        Text("Performance Appraisal — ${e.fullName}", style = MaterialTheme.typography.titleMedium)
                                        Spacer(Modifier.height(8.dp))
                                        empAppraisals.forEach { a ->
                                            Surface(color = if (selectedAppraisalId == a.id) Sky.copy(alpha = 0.15f) else Color.Transparent, modifier = Modifier.fillMaxWidth().clickable { selectedAppraisalId = a.id }) {
                                                Column(Modifier.padding(6.dp)) {
                                                    Text("${a.periodStart} → ${a.periodEnd}: ${a.rating ?: "স্কোর pending (computed data only)"}", style = MaterialTheme.typography.labelSmall)
                                                    Text("Sales: ৳${"%,.0f".format(a.salesAchievement)}/${"%,.0f".format(a.salesTarget)} · Collection: ৳${"%,.0f".format(a.collectionAchievement)} · Attendance: ${a.attendancePresentDays}/${a.attendanceTotalDays}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                                    Text("Visits: ${a.dealerVisits} dealer + ${a.retailerVisits} retailer · New: ${a.newDealerAcquisition}D/${a.newRetailerAcquisition}R · Returns: ${"%.1f".format(a.returnRatePct)}% · Complaints: ${a.complaintCount}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                                    if (a.supervisorScore != null || a.hrScore != null) {
                                                        Text("Manual: Supervisor=${a.supervisorScore ?: "-"} HR=${a.hrScore ?: "-"} (manually entered)", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                                                    }
                                                }
                                            }
                                        }
                                        Spacer(Modifier.height(10.dp))
                                        Text("Generate new (from real ERP data)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            OutlinedTextField(value = salesTarget, onValueChange = { salesTarget = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Sales target") }, modifier = Modifier.weight(1f))
                                            OutlinedTextField(value = collectionTarget, onValueChange = { collectionTarget = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Collection target") }, modifier = Modifier.weight(1f))
                                        }
                                        Spacer(Modifier.height(6.dp))
                                        Button(
                                            onClick = { accountScope.launch { MockRepository.generateAppraisal(e.id, periodStart, periodEnd, salesTarget.toDoubleOrNull() ?: 0.0, collectionTarget.toDoubleOrNull() ?: 0.0, onRejected = { r -> appraisalGenError = r }) } },
                                            modifier = Modifier.fillMaxWidth(),
                                        ) { Text("Generate (last month -> today)") }
                                        appraisalGenError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                        Spacer(Modifier.height(10.dp))
                                        if (selectedAppraisalId != null) {
                                            Text("Manual scores (supervisor/HR only — clearly separate from computed data above)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                OutlinedTextField(value = supervisorScore, onValueChange = { supervisorScore = it.filter { c -> c.isDigit() } }, label = { Text("Supervisor (0-100)") }, modifier = Modifier.weight(1f))
                                                OutlinedTextField(value = hrScore, onValueChange = { hrScore = it.filter { c -> c.isDigit() } }, label = { Text("HR (0-100)") }, modifier = Modifier.weight(1f))
                                            }
                                            OutlinedTextField(value = managerComment, onValueChange = { managerComment = it }, label = { Text("Manager comment") }, modifier = Modifier.fillMaxWidth())
                                            Spacer(Modifier.height(6.dp))
                                            manualScoreError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                            Button(
                                                onClick = {
                                                    val ok = MockRepository.enterManualAppraisalScores(selectedAppraisalId!!, supervisorScore.toDoubleOrNull(), hrScore.toDoubleOrNull(), managerComment.ifBlank { null }, onRejected = { r -> manualScoreError = r })
                                                    if (ok) showAppraisal = false
                                                },
                                                modifier = Modifier.fillMaxWidth(),
                                            ) { Text("Save Scores") }
                                        }
                                    }
                                }
                            }
                        }
                        var showCreateAccount by remember { mutableStateOf(false) }
                        val hasAccount = MockRepository.userAccounts.value.any { it.employeeProfileId == e.id }
                        val myAccount = MockRepository.userAccounts.value.firstOrNull { it.employeeProfileId == e.id }
                        if (!hasAccount) {
                            TextButton(onClick = { showCreateAccount = true }) { Text("🔑 Create Login Account") }
                        } else if (myAccount != null) {
                            Text(
                                "✓ Login account: ${if (myAccount.active) "active" else "suspended"}${if (myAccount.locked) " · LOCKED" else ""}",
                                style = MaterialTheme.typography.labelSmall, color = if (myAccount.active && !myAccount.locked) SuccessGreen else WarningAmber,
                            )
                            var acctActionError by remember { mutableStateOf<String?>(null) }
                            acctActionError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                TextButton(onClick = { MockRepository.setUserAccountActive(myAccount.id, !myAccount.active, onRejected = { r -> acctActionError = r }) }) { Text(if (myAccount.active) "Suspend" else "Activate") }
                                if (myAccount.locked) TextButton(onClick = { MockRepository.unlockUserAccount(myAccount.id, onRejected = { r -> acctActionError = r }) }) { Text("Unlock") }
                                var resetPinShown by remember { mutableStateOf<String?>(null) }
                                TextButton(onClick = { resetPinShown = MockRepository.resetUserAccountPin(myAccount.id, onRejected = { r -> acctActionError = r }) }) { Text("Reset PIN") }
                                resetPinShown?.let { newTempPin ->
                                    Dialog(onDismissRequest = { resetPinShown = null }) {
                                        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                            Column(Modifier.padding(16.dp)) {
                                                Text("Temporary PIN: $newTempPin", fontWeight = FontWeight.Bold)
                                                Text("এই PIN নিরাপদে ${e.fullName}-কে জানান — পরের লগইনে বাধ্যতামূলক change হবে।", style = MaterialTheme.typography.labelSmall)
                                                Spacer(Modifier.height(10.dp))
                                                Button(onClick = { resetPinShown = null }, modifier = Modifier.fillMaxWidth()) { Text("OK") }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (showCreateAccount) {
                            var tempPin by remember { mutableStateOf("") }
                            var accountError by remember { mutableStateOf<String?>(null) }
                            Dialog(onDismissRequest = { showCreateAccount = false }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text("Create Login Account — ${e.fullName}", style = MaterialTheme.typography.titleMedium)
                                        Text("Part A/B — a real UserAccount separate from this Employee Profile. Temporary PIN must be changed on first login.", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(value = tempPin, onValueChange = { tempPin = it.filter(Char::isDigit).take(5) }, label = { Text("Temporary PIN (5 digits, not sequential/repeated)") }, modifier = Modifier.fillMaxWidth())
                                        accountError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                        Spacer(Modifier.height(10.dp))
                                        Button(
                                            onClick = {
                                                accountScope.launch {
                                                    val result = MockRepository.createUserAccount(e.id, e.companyId, tempPin)
                                                    if (!result.success) accountError = result.message else showCreateAccount = false
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                        ) { Text("Create Account") }
                                    }
                                }
                            }
                        }
                        if (showOverride) {
                            var overrideReason by remember { mutableStateOf("") }
                            var overrideAction by remember { mutableStateOf("VISIT") }
                            Dialog(onDismissRequest = { showOverride = false }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text("Emergency Override — ${e.fullName}", style = MaterialTheme.typography.titleMedium)
                                        Spacer(Modifier.height(8.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            listOf("LOGIN", "ATTENDANCE", "VISIT", "ORDER", "COLLECTION").forEach { a -> FilterChip(selected = overrideAction == a, onClick = { overrideAction = a }, label = { Text(a, style = MaterialTheme.typography.labelSmall) }) }
                                        }
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(value = overrideReason, onValueChange = { overrideReason = it }, label = { Text("Reason (required)") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(10.dp))
                                        var overrideError by remember { mutableStateOf<String?>(null) }
                                        overrideError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                        Button(
                                            onClick = { accountScope.launch { val ok = MockRepository.createGeoOverride(e.id, e.fullName, overrideAction, overrideReason, onRejected = { r -> overrideError = r }); if (ok) showOverride = false } },
                                            enabled = overrideReason.isNotBlank(),
                                            modifier = Modifier.fillMaxWidth(),
                                        ) { Text("Grant 60-min Override") }
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        var showLinkAccount by remember { mutableStateOf(false) }
                        Text(
                            e.userAccountId?.let { "Linked to login: $it" } ?: "লগইন account-এর সাথে link করা নেই",
                            style = MaterialTheme.typography.labelSmall, color = if (e.userAccountId != null) SuccessGreen else DangerRed,
                        )
                        TextButton(onClick = { showLinkAccount = true }) { Text("Link Login Account") }
                        if (showLinkAccount) {
                            var accountId by remember { mutableStateOf(e.userAccountId ?: "") }
                            Dialog(onDismissRequest = { showLinkAccount = false }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text("Link Login Account — ${e.fullName}", style = MaterialTheme.typography.titleMedium)
                                        Spacer(Modifier.height(8.dp))
                                        Text("Real employee/manager permission checks (approval limits, visibility scope) only work once this is linked.", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(value = accountId, onValueChange = { accountId = it }, label = { Text("Login User ID") }, modifier = Modifier.fillMaxWidth())
                                        var linkAccountError by remember { mutableStateOf<String?>(null) }
                                        linkAccountError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                        Spacer(Modifier.height(10.dp))
                                        Button(onClick = { val ok = MockRepository.linkEmployeeToUserAccount(e.id, accountId, onRejected = { r -> linkAccountError = r }); if (ok) showLinkAccount = false }, enabled = accountId.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Link") }
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        var showStatusChange by remember { mutableStateOf(false) }
                        TextButton(onClick = { showStatusChange = true }) { Text("Change Status", color = if (e.hasActiveAccess) TextPrimary else DangerRed) }
                        if (!e.hasActiveAccess) Text("⚠ No active ERP access (${e.status}/${e.onboardingStatus})", style = MaterialTheme.typography.labelSmall, color = DangerRed)
                        val activeDeleg = remember(e.id) { MockRepository.activeDelegationFor(e.id) }
                        if (activeDeleg != null) {
                            Text("🔑 Currently acting with ${activeDeleg.delegatorName}'s authority (${activeDeleg.scope}, until ${activeDeleg.endDate})", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                            TextButton(onClick = { MockRepository.revokeDelegation(activeDeleg.id) }) { Text("Revoke Delegation", color = DangerRed) }
                        }
                        var showRoleChange by remember { mutableStateOf(false) }
                        TextButton(onClick = { showRoleChange = true }) { Text("Change Role") }
                        if (showRoleChange) {
                            var newRole by remember { mutableStateOf(e.role) }
                            var newDesignation by remember { mutableStateOf(e.designation) }
                            var roleReason by remember { mutableStateOf("") }
                            Dialog(onDismissRequest = { showRoleChange = false }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp).heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
                                        Text("Change Role — ${e.fullName}", style = MaterialTheme.typography.titleMedium)
                                        Spacer(Modifier.height(8.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                            val currentUserRole2 = MockRepository.currentUser.role
                                            val selectableRoles2 = com.abm.erp.data.UserRole.values().filter {
                                                it != com.abm.erp.data.UserRole.CHAIRMAN && it != com.abm.erp.data.UserRole.MD ||
                                                    currentUserRole2 == com.abm.erp.data.UserRole.CHAIRMAN || currentUserRole2 == com.abm.erp.data.UserRole.MD
                                            }
                                            selectableRoles2.forEach { r -> FilterChip(selected = newRole == r, onClick = { newRole = r }, label = { Text(r.name, style = MaterialTheme.typography.labelSmall) }) }
                                        }
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(value = newDesignation, onValueChange = { newDesignation = it }, label = { Text("New designation") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(6.dp))
                                        OutlinedTextField(value = roleReason, onValueChange = { roleReason = it }, label = { Text("Reason (required)") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(10.dp))
                                        var roleChangeError by remember { mutableStateOf<String?>(null) }
                                        roleChangeError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                        Button(
                                            onClick = { val ok = MockRepository.changeEmployeeRole(e.id, newRole, newDesignation, roleReason, onRejected = { r -> roleChangeError = r }); if (ok) showRoleChange = false },
                                            enabled = roleReason.isNotBlank(),
                                            modifier = Modifier.fillMaxWidth(),
                                        ) { Text("Confirm Role Change") }
                                    }
                                }
                            }
                        }
                        if (showStatusChange) {
                            var newStatus by remember { mutableStateOf(e.status) }
                            var statusReason by remember { mutableStateOf("") }
                            Dialog(onDismissRequest = { showStatusChange = false }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp).heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
                                        Text("Change Status — ${e.fullName}", style = MaterialTheme.typography.titleMedium)
                                        Spacer(Modifier.height(8.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                            com.abm.erp.data.EmployeeStatus.values().forEach { s -> FilterChip(selected = newStatus == s, onClick = { newStatus = s }, label = { Text(s.name, style = MaterialTheme.typography.labelSmall) }) }
                                        }
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(value = statusReason, onValueChange = { statusReason = it }, label = { Text("Reason (required)") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(10.dp))
                                        var statusChangeError by remember { mutableStateOf<String?>(null) }
                                        statusChangeError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                        Button(
                                            onClick = { val ok = MockRepository.setEmployeeStatus(e.id, newStatus, statusReason, onRejected = { r -> statusChangeError = r }); if (ok) showStatusChange = false },
                                            enabled = statusReason.isNotBlank(),
                                            colors = ButtonDefaults.buttonColors(containerColor = if (newStatus in setOf(com.abm.erp.data.EmployeeStatus.SUSPENDED, com.abm.erp.data.EmployeeStatus.TERMINATED, com.abm.erp.data.EmployeeStatus.RESIGNED)) DangerRed else MaterialTheme.colorScheme.primary),
                                            modifier = Modifier.fillMaxWidth(),
                                        ) { Text("Confirm Status Change") }
                                    }
                                }
                            }
                        }
                        if (showManagerPicker) {
                            Dialog(onDismissRequest = { showManagerPicker = false }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp).heightIn(max = 400.dp).verticalScroll(rememberScrollState())) {
                                        Text("Assign Manager for ${e.fullName}", style = MaterialTheme.typography.titleMedium)
                                        var assignMgrError by remember { mutableStateOf<String?>(null) }
                                        assignMgrError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                        Spacer(Modifier.height(8.dp))
                                        allEmployees.filter { it.id != e.id }.forEach { mgr ->
                                            val (valid, reason) = MockRepository.validateManagerAssignment(e.id, mgr.id)
                                            Row(
                                                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable(enabled = valid) { if (MockRepository.assignDirectManager(e.id, mgr.id, onRejected = { r -> assignMgrError = r })) showManagerPicker = false },
                                                verticalAlignment = Alignment.CenterVertically,
                                            ) {
                                                Text(mgr.fullName + if (!valid) " (${reason})" else "", style = MaterialTheme.typography.bodySmall, color = if (valid) TextPrimary else TextSecondary)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (showLimits) {
                            var financial by remember { mutableStateOf(e.financialApprovalLimit.toString()) }
                            var credit by remember { mutableStateOf(e.creditOverrideLimit.toString()) }
                            var discount by remember { mutableStateOf(e.discountApprovalLimitPct.toString()) }
                            var purchase by remember { mutableStateOf(e.purchaseApprovalLimit.toString()) }
                            var leaveAuth by remember { mutableStateOf(e.leaveApprovalAuthority) }
                            Dialog(onDismissRequest = { showLimits = false }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp).heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
                                        Text("Approval Limits — ${e.fullName}", style = MaterialTheme.typography.titleMedium)
                                        Spacer(Modifier.height(8.dp))
                                        val testAmount = (e.financialApprovalLimit * 2).coerceAtLeast(1000.0)
                                        val escalatesTo = remember(e.id, e.financialApprovalLimit) { MockRepository.findAuthorizedApprover(e.id, MockRepository.ApprovalLimitType.FINANCIAL, testAmount) }
                                        Text(
                                            "একটা ৳${"%,.0f".format(testAmount)} লেনদেন এই limit ছাড়িয়ে গেলে escalate হবে: " + (escalatesTo?.fullName ?: "কোনো authorized approver পাওয়া যায়নি"),
                                            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(value = financial, onValueChange = { financial = it }, label = { Text("Financial approval limit") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(6.dp))
                                        OutlinedTextField(value = credit, onValueChange = { credit = it }, label = { Text("Credit override limit") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(6.dp))
                                        OutlinedTextField(value = discount, onValueChange = { discount = it }, label = { Text("Discount approval limit %") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(6.dp))
                                        OutlinedTextField(value = purchase, onValueChange = { purchase = it }, label = { Text("Purchase approval limit") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(6.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Checkbox(checked = leaveAuth, onCheckedChange = { leaveAuth = it })
                                            Text("Leave approval authority", style = MaterialTheme.typography.bodySmall)
                                        }
                                        Spacer(Modifier.height(10.dp))
                                        var limitsError by remember { mutableStateOf<String?>(null) }
                                        limitsError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                        Button(
                                            onClick = {
                                                val ok = MockRepository.setApprovalLimits(e.id, financial.toDoubleOrNull() ?: 0.0, credit.toDoubleOrNull() ?: 0.0, discount.toDoubleOrNull() ?: 0.0, e.stockAdjustmentApprovalLimit, purchase.toDoubleOrNull() ?: 0.0, leaveAuth, e.attendanceCorrectionAuthority, e.approvalAuthorityLevel, onRejected = { r -> limitsError = r })
                                                if (ok) showLimits = false
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                        ) { Text("Save Limits") }
                                    }
                                }
                            }
                        }
                        if (showTransfer) {
                            var transferType by remember { mutableStateOf("BRANCH") }
                            var toValue by remember { mutableStateOf("") }
                            var reason by remember { mutableStateOf("") }
                            Dialog(onDismissRequest = { showTransfer = false }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp).heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                                        Text("Transfer — ${e.fullName}", style = MaterialTheme.typography.titleMedium)
                                        Spacer(Modifier.height(8.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            listOf("BRANCH", "TERRITORY", "ROUTE").forEach { t -> FilterChip(selected = transferType == t, onClick = { transferType = t }, label = { Text(t, style = MaterialTheme.typography.labelSmall) }) }
                                        }
                                        Spacer(Modifier.height(6.dp))
                                        OutlinedTextField(value = toValue, onValueChange = { toValue = it }, label = { Text("New value") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(6.dp))
                                        OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(10.dp))
                                        var transferError by remember { mutableStateOf<String?>(null) }
                                        transferError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                        Button(
                                            onClick = {
                                                val created = MockRepository.createTransferRequest(e.id, transferType, when (transferType) { "TERRITORY" -> e.territoryId ?: ""; "ROUTE" -> e.routeId ?: ""; else -> e.branch }, toValue, java.time.LocalDate.now(), reason, onRejected = { r -> transferError = r })
                                                if (created != null) showTransfer = false
                                            },
                                            enabled = toValue.isNotBlank() && reason.isNotBlank(),
                                            modifier = Modifier.fillMaxWidth(),
                                        ) { Text("Create Transfer Request") }
                                    }
                                }
                            }
                        }
                        if (showDelegate) {
                            var delegateToId by remember { mutableStateOf<String?>(null) }
                            var reason by remember { mutableStateOf("") }
                            var delegateError by remember { mutableStateOf<String?>(null) }
                            Dialog(onDismissRequest = { showDelegate = false }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp).heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                                        Text("Delegate Authority from ${e.fullName}", style = MaterialTheme.typography.titleMedium)
                                        delegateError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                        Spacer(Modifier.height(8.dp))
                                        allEmployees.filter { it.id != e.id }.forEach { d ->
                                            Text(d.fullName, style = MaterialTheme.typography.bodySmall, fontWeight = if (delegateToId == d.id) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.fillMaxWidth().heightIn(min = 40.dp).clickable { delegateToId = d.id })
                                        }
                                        Spacer(Modifier.height(6.dp))
                                        OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(10.dp))
                                        Button(
                                            onClick = {
                                                val target = delegateToId
                                                if (target != null && reason.isNotBlank()) {
                                                    MockRepository.createDelegation(e.id, target, "APPROVAL", e.financialApprovalLimit, java.time.LocalDate.now(), java.time.LocalDate.now().plusDays(14), reason, onRejected = { r -> delegateError = r })?.let { showDelegate = false }
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                        ) { Text("Create Delegation (14 days)") }
                                    }
                                }
                            }
                        }
                    }
            }
        }
    }

    if (showNew) {
        var fullName by remember { mutableStateOf("") }
        var mobile by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var department by remember { mutableStateOf("") }
        var designation by remember { mutableStateOf("") }
        var role by remember { mutableStateOf(com.abm.erp.data.UserRole.SR) }
        var nationalId by remember { mutableStateOf("") }
        var workLocation by remember { mutableStateOf("") }
        var emergencyContactName by remember { mutableStateOf("") }
        var emergencyContactPhone by remember { mutableStateOf("") }
        var basePayMonthly by remember { mutableStateOf("") }
        var directManagerId by remember { mutableStateOf<String?>(null) }
        var newEmployeeError by remember { mutableStateOf<String?>(null) }
        val allEmployeesForManager by MockRepository.employeeProfiles.collectAsState()
        Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                    Text("New Employee (Draft)", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = fullName, onValueChange = { fullName = it }, label = { Text("Full name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = mobile, onValueChange = { mobile = it }, label = { Text("Mobile") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = nationalId, onValueChange = { nationalId = it }, label = { Text("National ID") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = department, onValueChange = { department = it }, label = { Text("Department") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = designation, onValueChange = { designation = it }, label = { Text("Designation") }, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = workLocation, onValueChange = { workLocation = it }, label = { Text("Work location") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = emergencyContactName, onValueChange = { emergencyContactName = it }, label = { Text("Emergency contact name") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = emergencyContactPhone, onValueChange = { emergencyContactPhone = it }, label = { Text("Emergency contact phone") }, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = basePayMonthly, onValueChange = { basePayMonthly = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Base monthly salary (৳)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Text("Reporting manager", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        allEmployeesForManager.filter { it.hasActiveAccess && it.role != com.abm.erp.data.UserRole.SR }.take(30).forEach { m ->
                            FilterChip(selected = directManagerId == m.id, onClick = { directManagerId = m.id }, label = { Text(m.fullName, style = MaterialTheme.typography.labelSmall) })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Role tier (permission level)", style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        val currentUserRole = MockRepository.currentUser.role
                        val selectableRoles = com.abm.erp.data.UserRole.values().filter {
                            it != com.abm.erp.data.UserRole.CHAIRMAN && it != com.abm.erp.data.UserRole.MD ||
                                currentUserRole == com.abm.erp.data.UserRole.CHAIRMAN || currentUserRole == com.abm.erp.data.UserRole.MD
                        }
                        selectableRoles.forEach { r -> FilterChip(selected = role == r, onClick = { role = r }, label = { Text(r.name, style = MaterialTheme.typography.labelSmall) }) }
                    }
                    newEmployeeError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 6.dp)) }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            accountScope.launch {
                                newEmployeeError = null
                                val created = MockRepository.createEmployeeDraft(
                                    fullName = fullName, mobile = mobile, email = email, department = department, designation = designation,
                                    role = role, companyId = MockRepository.currentUser.companyId,
                                    nationalId = nationalId.ifBlank { null }, workLocation = workLocation.ifBlank { null },
                                    directManagerId = directManagerId,
                                    emergencyContactName = emergencyContactName.ifBlank { null }, emergencyContactPhone = emergencyContactPhone.ifBlank { null },
                                    basePayMonthly = basePayMonthly.toDoubleOrNull() ?: 0.0,
                                    onRejected = { reason -> newEmployeeError = reason },
                                )
                                if (created != null) showNew = false
                                else if (newEmployeeError == null) newEmployeeError = "তৈরি করা যায়নি — আবার চেষ্টা করুন।"
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Save Draft") }
                }
            }
        }
    }
}

@Composable
private fun EmployeeHierarchySection() {
    val employees by MockRepository.employeeProfiles.collectAsState()
    val tree = remember(employees) { MockRepository.buildReportingTree() }

    @Composable
    fun NodeView(node: MockRepository.HierarchyNode, depth: Int) {
        Row(Modifier.fillMaxWidth().padding(start = (depth * 16).dp, top = 4.dp, bottom = 4.dp)) {
            Text("${"—".repeat(depth)} ${node.employee.fullName} (${node.employee.designation.ifBlank { node.employee.role.name }})", style = MaterialTheme.typography.bodySmall)
        }
        node.children.forEach { NodeView(it, depth + 1) }
    }

    Column(Modifier.fillMaxSize()) {
        val invalidIssues by produceState<List<Pair<com.abm.erp.data.EmployeeProfile, String>>>(initialValue = emptyList(), employees) {
            value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { MockRepository.invalidHierarchyReport() }
        }
        if (invalidIssues.isNotEmpty()) {
            Text("⚠ Invalid hierarchy detected:", color = DangerRed, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
            invalidIssues.forEach { (e, issue) -> Text("${e.fullName}: $issue", style = MaterialTheme.typography.labelSmall, color = DangerRed) }
            Spacer(Modifier.height(10.dp))
        }
        if (tree.isEmpty()) {
            Text("এখনো কোনো hierarchy নেই — real employee onboard করলে এখানে reporting-tree দেখাবে।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        LazyColumn { items(tree) { NodeView(it, 0) } }
    }
}
