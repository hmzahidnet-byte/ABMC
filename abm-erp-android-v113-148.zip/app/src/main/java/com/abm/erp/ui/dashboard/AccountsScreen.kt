package com.abm.erp.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.data.EMPLOYEE_DIRECTORY
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

class AccountsViewModel : ViewModel() {
    val demoAccountsFlow = MockRepository.demoAccountsFlow
    val deviceLocked = MockRepository.deviceLocked
    fun unlockDevice() = MockRepository.unlockDevice()
    fun resetPin(pin: String) = MockRepository.resetPin(pin)
    fun forceLogout(employeeId: String) = com.abm.erp.data.FirebaseSync.forceLogoutEmployee(employeeId)
}

/**
 * "Admin should have full control over everyone's password and access" —
 * Chairman-only. Lists every staff login account and can reset any of
 * their PINs (old one stops working immediately, a fresh random one is
 * shown once), plus shows/clears this device's lockout status.
 */
@Composable
fun AccountsScreen(onClose: () -> Unit, vm: AccountsViewModel = viewModel()) {
    val demoAccounts by vm.demoAccountsFlow.collectAsState()
    val deviceLocked by vm.deviceLocked.collectAsState()
    var justReset by remember { mutableStateOf<Pair<String, String>?>(null) } // (employeeName, newPin)

    Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Account & Access Control", style = MaterialTheme.typography.titleMedium)
            IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = "Close") }
        }
        Text(
            "Only the Chairman can see this. Resetting a PIN here immediately invalidates the old one.",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(10.dp))

        Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (deviceLocked) WarningAmber.copy(alpha = 0.15f) else SuccessGreen.copy(alpha = 0.12f),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(12.dp)) {
                Text(
                    if (deviceLocked) "🔒 This device is currently locked (3 failed PIN attempts)" else "✓ No device lockouts right now",
                    color = if (deviceLocked) Color(0xFF8A5A00) else SuccessGreen,
                    style = MaterialTheme.typography.labelMedium,
                )
                if (deviceLocked) {
                    Spacer(Modifier.height(6.dp))
                    Button(onClick = { vm.unlockDevice() }) { Text("Unlock now") }
                }
            }
        }

        justReset?.let { (name, newPin) ->
            Spacer(Modifier.height(10.dp))
            Surface(shape = RoundedCornerShape(12.dp), color = Color(0x142E8BC9), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("New PIN for $name:", style = MaterialTheme.typography.labelMedium)
                    Text(newPin, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Share this securely — it won't be shown again here.", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Text("Staff login accounts (${demoAccounts.size})", style = MaterialTheme.typography.labelLarge)

        LazyColumn {
            items(demoAccounts.entries.toList(), key = { it.key }) { (pin, user) ->
                val emp = EMPLOYEE_DIRECTORY.firstOrNull { it.id == user.employeeId }
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(user.name, style = MaterialTheme.typography.bodyMedium)
                        Text("${user.role} · ${emp?.geoLabel ?: user.zone}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { vm.forceLogout(user.employeeId) }) { Text("Force Logout") }
                        OutlinedButton(onClick = {
                            val newPin = vm.resetPin(pin)
                            justReset = user.name to newPin
                        }) { Text("Reset PIN") }
                    }
                }
            }
        }
        Text(
            "Only these ${demoAccounts.size} demo login accounts have individual PINs right now — the rest of the ${EMPLOYEE_DIRECTORY.size}-person directory gets real accounts once HR onboarding is wired in.",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
            modifier = Modifier.padding(top = 8.dp),
        )
    }
}
