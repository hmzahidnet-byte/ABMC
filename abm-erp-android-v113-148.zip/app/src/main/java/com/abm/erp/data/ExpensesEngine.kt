package com.abm.erp.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.first

// ============================================================================
// v113-87 Phase 5 — the Expense group, moved out of MockRepository.kt:
// submitExpense, approveExpense (the ONLY point that posts to the ledger),
// rejectExpense. Same extension-function mechanics as Phases 2-4; bodies
// untouched; call sites (ExpenseWorkspace, ApprovalRouting-driven flows)
// textually identical.
// ============================================================================

fun MockRepository.submitExpense(
    category: String, amount: Double, description: String, paymentMethod: ExpensePaymentMethod,
    attachmentUri: String? = null, onRejected: (String) -> Unit = {},
): Expense? {
    if (!PermissionManager.canCurrentUser("bill", PermissionAction.CREATE)) {
        logAudit("Expense", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "SUBMIT")
        onRejected("আপনার role-এ Expense জমা দেওয়ার অনুমতি নেই।")
        return null
    }
    if (category.isBlank()) { onRejected("Category দিন।"); return null }
    if (amount <= 0.0) { onRejected("টাকার পরিমাণ শূন্য বা তার কম হতে পারবে না।"); return null }
    val expense = Expense(
        id = "EXP-${java.util.UUID.randomUUID().toString().take(8)}", expenseNo = "", companyId = currentUser.companyId,
        category = category, amount = amount, description = description, paymentMethod = paymentMethod,
        submittedBy = currentUser.name, submittedByEmployeeId = currentUser.employeeId, attachmentUri = attachmentUri,
    )
    launchInRepoScope {
        val expenseNo = generateNumber("EXPENSE")
        val withNo = expense.copy(expenseNo = expenseNo)
        database.expenseDao().upsert(withNo.toEntity())
        qrSyncCollection("expenses").document(withNo.id).set(withNo.toEntity())
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push expense failed", it) }
        logAudit("Expense", withNo.id, "SUBMIT", newValue = withNo)
        raiseApprovalRequest(ApprovalType.EXPENSE, "$expenseNo — $category: ৳${"%,.0f".format(amount)}", "Expense", withNo.id)
    }
    return expense
}

fun MockRepository.approveExpense(expenseId: String, onRejected: (String) -> Unit = {}): Boolean {
    if (!PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)) {
        logAudit("Expense", expenseId, "DENY", oldValue = currentUser.role.name, newValue = "APPROVE")
        onRejected("আপনার role-এ Expense approve করার অনুমতি নেই।")
        return false
    }
    launchInRepoScope {
        val existing = database.withTransaction {
            val current = database.expenseDao().getAll().first().firstOrNull { it.id == expenseId } ?: run { onRejected("এই Expense খুঁজে পাওয়া যায়নি।"); return@withTransaction null }
            if (current.status != "PENDING") {
                logAudit("Expense", expenseId, "DENY", oldValue = current.status, newValue = "APPROVE — already ${current.status}")
                onRejected("এই Expense ইতিমধ্যে ${current.status} — আবার approve করা যাবে না।")
                return@withTransaction null
            }
            database.expenseDao().setStatus(expenseId, "APPROVED", currentUser.name, null, System.currentTimeMillis())
            current
        } ?: return@launchInRepoScope
        qrSyncCollection("expenses").document(expenseId).update(mapOf("status" to "APPROVED", "approvedBy" to currentUser.name, "approvedAtEpochMillis" to System.currentTimeMillis()))
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push expense-approve failed", it) }
        // Real account/ledger posting — only now, on approval, never at submission.
        addLedgerEntry(LedgerEntryType.OUT, existing.category, existing.description.ifBlank { "Expense ${existing.expenseNo}" }, existing.amount, currentUser.name)
        logAudit("Expense", expenseId, "APPROVE_AND_POST", oldValue = "PENDING", newValue = "APPROVED — ledger posted")
        createNotification(NotificationCategory.APPROVAL, "Expense Approved", "${existing.expenseNo} — ৳${"%,.0f".format(existing.amount)}")
    }
    return true
}

fun MockRepository.rejectExpense(expenseId: String, reason: String, onRejected: (String) -> Unit = {}): Boolean {
    if (!PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)) {
        logAudit("Expense", expenseId, "DENY", oldValue = currentUser.role.name, newValue = "REJECT")
        onRejected("আপনার role-এ Expense reject করার অনুমতি নেই।")
        return false
    }
    if (reason.isBlank()) { onRejected("Reject করার কারণ দিন।"); return false }
    launchInRepoScope {
        val existing = database.withTransaction {
            val current = database.expenseDao().getAll().first().firstOrNull { it.id == expenseId } ?: run { onRejected("এই Expense খুঁজে পাওয়া যায়নি।"); return@withTransaction null }
            if (current.status != "PENDING") {
                logAudit("Expense", expenseId, "DENY", oldValue = current.status, newValue = "REJECT — already ${current.status}")
                onRejected("এই Expense ইতিমধ্যে ${current.status} — আবার reject করা যাবে না।")
                return@withTransaction null
            }
            database.expenseDao().setStatus(expenseId, "REJECTED", null, reason, null)
            current
        } ?: return@launchInRepoScope
        qrSyncCollection("expenses").document(expenseId).update(mapOf("status" to "REJECTED", "rejectReason" to reason))
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push expense-reject failed", it) }
        logAudit("Expense", expenseId, "REJECT", oldValue = "PENDING", newValue = "REJECTED", reason = reason)
        createNotification(NotificationCategory.APPROVAL, "Expense Rejected", "${existing.expenseNo}: $reason")
    }
    return true
}
