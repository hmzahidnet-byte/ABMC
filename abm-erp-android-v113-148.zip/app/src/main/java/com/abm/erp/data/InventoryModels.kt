package com.abm.erp.data

import java.time.LocalDateTime

// ---------- Inventory / Stock Management ----------

data class Product(
    val id: String,
    val sku: String,
    val name: String,
    val unit: String,
    val category: String,
    val reorderThreshold: Double,
    val defaultUnitPrice: Double,
    val costPrice: Double = 0.0, // v86 - real cost basis for Margin/Profit Analysis; 0 = not set, margin calc shows "unavailable" rather than fabricating
    val photoUri: String? = null, // company-uploaded real product photo, shown in the Sales Chain/Invoice pickers instead of a placeholder
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val dedupKey: String = "", // normalized sku+name key — Foundation Layer's Data Integrity step checks this before insert
    val deletedAt: LocalDateTime? = null,
    val deletedBy: String? = null,
    val barcodeValue: String = "", // Barcode/QR Support — scanned or manually entered
    val categoryId: String? = null,
    val brandId: String? = null,
)

data class Warehouse(val id: String, val name: String, val zone: String, val stockCategory: StockCategory = StockCategory.STORE)

enum class MovementType { IN, OUT, ADJUST }

/** A denormalized, UI-ready view: one row per product+warehouse with names already resolved. */
data class StockLevelView(
    val productId: String,
    val productName: String,
    val unit: String,
    val warehouseId: String,
    val warehouseName: String,
    val quantityOnHand: Double,
    val reorderThreshold: Double,
    val stockCategory: StockCategory = StockCategory.STORE,
    val reservedQty: Double = 0.0,
) {
    val isLowStock: Boolean get() = quantityOnHand <= reorderThreshold
    val availableQty: Double get() = (quantityOnHand - reservedQty).coerceAtLeast(0.0)
}

data class StockMovement(
    val id: String,
    val productId: String,
    val productName: String,
    val warehouseId: String,
    val warehouseName: String,
    val type: MovementType,
    val quantity: Double,
    val reason: String,
    val timestamp: LocalDateTime,
    val batchCode: String? = null,
    val unitCost: Double = 0.0,
)
