package com.abm.erp.data

/** One tile in the dashboard's module grid — icon + gradient colors match the JSX design exactly. */
data class AppModule(
    val key: String,
    val label: String,
    val category: String,
    val icon: String,
    val colorStart: Long,
    val colorEnd: Long,
)

val CATEGORY_ORDER: List<String> = listOf(
    "Sales & Field", "Inventory & Production", "Intelligence", "Finance", "People & Admin",
)

val MODULES: List<AppModule> = listOf(
    AppModule("sales", "Sales Chain", "Sales & Field", "🛒", 0xFFFF8A3D, 0xFFFF5E62),
    AppModule("crm", "CRM", "Sales & Field", "👥", 0xFFF857A6, 0xFFFF5858),
    AppModule("dealer", "Dealers", "Sales & Field", "🏪", 0xFF9B5CFF, 0xFF6C2EE0),
    AppModule("gps", "GPS Track", "Sales & Field", "📍", 0xFF00C2E0, 0xFF0093B8),
    AppModule("bill", "Billing", "Sales & Field", "🧾", 0xFFF5A623, 0xFFE08600),
    AppModule("courier", "Courier & Logistics", "Sales & Field", "🚚", 0xFF3FA9F5, 0xFF1D78C7),
    AppModule("inv", "Inventory", "Inventory & Production", "📦", 0xFF12C2A9, 0xFF0E9F8B),
    AppModule("stock", "Stock Mgmt", "Inventory & Production", "🏭", 0xFF4E9CFF, 0xFF2E6FE0),
    AppModule("purchase", "Purchase", "Inventory & Production", "🛍️", 0xFF8A6DFF, 0xFF5B3FE0),
    AppModule("prod", "Production", "Inventory & Production", "⚙️", 0xFFE85D4A, 0xFFC03A2B),
    AppModule("market", "Market Analysis", "Intelligence", "📈", 0xFF38C96A, 0xFF1E9E4C),
    AppModule("ai", "AI Boardroom", "Intelligence", "✨", 0xFFB45CFF, 0xFF7A2EE0),
    AppModule("report", "Reports", "Intelligence", "📊", 0xFF64748B, 0xFF475569),
    AppModule("ledger", "Accounts/Ledger", "Finance", "💰", 0xFF2FA88A, 0xFF1C6E5C),
    AppModule("hr", "HR & Payroll", "People & Admin", "💳", 0xFF5C6CFF, 0xFF3B47D6),
    AppModule("approval", "Approvals", "People & Admin", "✅", 0xFF4CB963, 0xFF2F8F49),
    AppModule("tasks", "Task Manager", "People & Admin", "📋", 0xFF3AA9E0, 0xFF1E7FB8),
    AppModule("notify", "Notifications", "People & Admin", "🔔", 0xFFFFB648, 0xFFF08A24),
    AppModule("comms", "Communication Hub", "People & Admin", "💬", 0xFF3FA9F5, 0xFF1D78C7),
    AppModule("helpdesk", "Helpdesk", "People & Admin", "🎧", 0xFFD46CE0, 0xFF9B3FC4),
    AppModule("complaint", "Complaint Box", "People & Admin", "📮", 0xFFFF6B6B, 0xFFC23B3B),
)

/** Which module keys the currently-built real screens can actually open. Everything
 *  else in MODULES shows a "coming in the next update" message when tapped —
 *  honest placeholder rather than a silent no-op or a crash. */
val IMPLEMENTED_MODULE_ROUTES: Map<String, String> = mapOf(
    "sales" to "sales",
    "crm" to "crm",
    "gps" to "crm", // GPS Track tile opens the same screen — live tracking already lives inside GeoCrmScreen
    "inv" to "inventory",
    "stock" to "inventory", // Stock Mgmt tile opens the same screen — the Production/Store toggle already lives inside InventoryScreen
    "purchase" to "purchase",
    "comms" to "comms",
    "hr" to "hrm",
    "bill" to "billing",
    "prod" to "production",
    "ai" to "boardroom",
    "complaint" to "complaint",
    "dealer" to "dealers",
    "courier" to "courier",
    "tasks" to "tasks",
    // Decision 2 (v113-72) — "approval" intentionally has no route: there is no central
    // Approvals screen. The "approval" module key itself stays, because PermissionManager
    // still uses it as the APPROVE permission key inside each owning module.
    "notify" to "notifications",
    "market" to "market",
    "ledger" to "ledger",
    "helpdesk" to "helpdesk",
    "report" to "reports",
)

private val BASE = setOf("sales", "crm", "gps", "notify", "helpdesk", "complaint", "comms")

/** Per-designation module access, mirroring the JSX ROLES.allowed lists exactly. */
val ROLE_MODULES: Map<UserRole, Set<String>> = mapOf(
    UserRole.SR to BASE,
    UserRole.TSM to BASE + setOf("bill", "inv", "tasks"),
    UserRole.ASM to BASE + setOf("bill", "inv", "stock", "purchase", "dealer", "courier", "tasks", "approval"),
    UserRole.RSM to BASE + setOf("bill", "inv", "stock", "purchase", "dealer", "courier", "report", "tasks", "approval"),
    UserRole.DSM to BASE + setOf("bill", "inv", "stock", "purchase", "dealer", "courier", "report", "tasks", "approval"),
    UserRole.NSM to BASE + setOf("bill", "inv", "stock", "purchase", "dealer", "courier", "report", "ledger", "tasks", "approval"),
    UserRole.AGM to MODULES.map { it.key }.toSet() - setOf("ai", "market"),
    UserRole.GM to MODULES.map { it.key }.toSet() - setOf("ai", "market"),
    UserRole.MD to MODULES.map { it.key }.toSet(),
    UserRole.CHAIRMAN to MODULES.map { it.key }.toSet(),
)

fun visibleModulesFor(role: UserRole): List<AppModule> {
    val allowed = ROLE_MODULES[role].orEmpty()
    // RC-1 fix — ModuleRegistry existed but was never actually consulted
    // anywhere; DISABLED modules never hid, LIMITED never got flagged.
    return MODULES.filter { it.key in allowed && com.abm.erp.config.ModuleRegistry.statusOf(it.key) != com.abm.erp.config.ModuleReadiness.DISABLED }
}
