package com.abm.erp.auth

import com.abm.erp.config.AppEnvironment

/**
 * Part D — Forgot PIN / OTP. Real interface boundary for a future SMS
 * backend. No SMS provider is configured in this project, so
 * [ProductionOtpService] honestly reports itself as unavailable rather
 * than pretending to send anything. [DebugMockOtpService] exists only
 * behind [AppEnvironment.demoOtpAllowed] (local debug builds only, never
 * enabled by default in staging/production).
 */
interface OtpService {
    data class OtpResult(val success: Boolean, val message: String)

    /** Starts an OTP challenge for a registered mobile number. Never reveals whether the number is actually registered (Part D — "prevent account enumeration"). */
    suspend fun requestOtp(mobile: String): OtpResult

    /** Verifies a submitted code against the active challenge. One-time use — a verified or expired code can never be reused. */
    suspend fun verifyOtp(mobile: String, code: String): OtpResult

    suspend fun resendOtp(mobile: String): OtpResult

    fun invalidateOtp(mobile: String)
}

/**
 * Real production adapter boundary. No SMS backend is wired up in this
 * project — this deliberately fails informatively rather than silently
 * pretending success, and the UI (LoginScreen) must route to "contact
 * authorized administrator" instead of trying to complete this flow.
 */
class ProductionOtpService : OtpService {
    override suspend fun requestOtp(mobile: String): OtpService.OtpResult =
        OtpService.OtpResult(false, "OTP delivery is not configured for this deployment. Contact your authorized administrator to reset your PIN.")

    override suspend fun verifyOtp(mobile: String, code: String): OtpService.OtpResult =
        OtpService.OtpResult(false, "OTP verification is not available. Contact your authorized administrator.")

    override suspend fun resendOtp(mobile: String): OtpService.OtpResult = requestOtp(mobile)

    override fun invalidateOtp(mobile: String) {}
}

/**
 * Debug-only mock, gated by AppEnvironment.demoOtpAllowed (local DEBUG
 * builds only — never staging, never production, never "on by default").
 * A real, generated (not fixed "0000") 4-digit code with real expiry/
 * attempt-limit/one-time-use, so the debug experience still exercises the
 * real state machine rather than a permanent bypass.
 */
class DebugMockOtpService : OtpService {
    private data class Challenge(val code: String, val expiresAtMillis: Long, val attemptsUsed: Int = 0, val used: Boolean = false)
    private val challenges = mutableMapOf<String, Challenge>()
    private val maxAttempts = 3
    private val validityMillis = 5 * 60_000L

    override suspend fun requestOtp(mobile: String): OtpService.OtpResult {
        if (!AppEnvironment.demoOtpAllowed) return OtpService.OtpResult(false, "Debug OTP is disabled in this build.")
        val code = (1000..9999).random().toString() // real random per request, never a fixed value — Part D
        challenges[mobile] = Challenge(code, System.currentTimeMillis() + validityMillis)
        android.util.Log.d("DebugMockOtpService", "[DEBUG-ONLY, never in production] OTP for $mobile: $code")
        return OtpService.OtpResult(true, "Debug OTP generated (see Logcat — debug builds only).")
    }

    override suspend fun verifyOtp(mobile: String, code: String): OtpService.OtpResult {
        if (!AppEnvironment.demoOtpAllowed) return OtpService.OtpResult(false, "Debug OTP is disabled in this build.")
        val challenge = challenges[mobile] ?: return OtpService.OtpResult(false, "Incorrect OTP.") // generic message — Part D anti-enumeration
        if (challenge.used || System.currentTimeMillis() > challenge.expiresAtMillis || challenge.attemptsUsed >= maxAttempts) {
            return OtpService.OtpResult(false, "Incorrect OTP.")
        }
        if (challenge.code != code) {
            challenges[mobile] = challenge.copy(attemptsUsed = challenge.attemptsUsed + 1)
            return OtpService.OtpResult(false, "Incorrect OTP.")
        }
        challenges[mobile] = challenge.copy(used = true) // one-time use
        return OtpService.OtpResult(true, "OTP verified.")
    }

    override suspend fun resendOtp(mobile: String): OtpService.OtpResult = requestOtp(mobile)

    override fun invalidateOtp(mobile: String) { challenges.remove(mobile) }
}

object OtpServiceProvider {
    val instance: OtpService by lazy { if (AppEnvironment.demoOtpAllowed) DebugMockOtpService() else ProductionOtpService() }
}
