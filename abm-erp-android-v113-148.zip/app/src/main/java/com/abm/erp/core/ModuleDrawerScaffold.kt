package com.abm.erp.core

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.theme.DashBg
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * v113-74 — the shell every "mother module" uses (DMS, RMS, HR, FMS, Chairman, AI).
 *
 * The person's rule, restated from the drafts:
 *  - the Home Dashboard shows exactly six mother modules and nothing else;
 *  - entering one opens a left drawer listing only *that* module's options;
 *  - picking an option closes the drawer, so the option gets the whole screen —
 *    that is the entire point ("phone er display ta onek boro pabo");
 *  - one module's drawer never lists another module's items. To switch modules you
 *    go back to Home. This keeps the UI clean and is why there is no cross-module
 *    shortcut anywhere in here.
 *
 * Only the *shell* is shared. Each module passes its own item list, its own colours
 * and its own content — the options are deliberately different per module.
 *
 * Performance: this renders on every module entry, so the drawer body is a plain
 * Column in a scroll container (item counts are ~8–10, a LazyColumn would cost more
 * than it saves) and no work happens in composition beyond drawing. Target is a
 * steady 90Hz minimum, 120Hz where the panel allows.
 */
data class ModuleDrawerItem(
    val key: String,
    val label: String,
    val icon: ImageVector,
    /** Optional short line under the label, e.g. "Direct Invoice + Auto Data". */
    val hint: String = "",
)

@Composable
fun ModuleDrawerScaffold(
    moduleName: String,
    moduleSubtitle: String,
    colorStart: Long,
    colorEnd: Long,
    moduleIcon: ImageVector,
    items: List<ModuleDrawerItem>,
    selectedKey: String,
    onSelect: (String) -> Unit,
    onBackToHome: () -> Unit,
    content: @Composable (String) -> Unit,
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val start = Color(colorStart)
    val end = Color(colorEnd)

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = DashBg) {
                Column(
                    Modifier.fillMaxWidth()
                        .background(Brush.linearGradient(listOf(start, end)))
                        .padding(18.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(moduleIcon, contentDescription = null, tint = Color.White)
                        Spacer(Modifier.width(10.dp))
                        Text(moduleName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(moduleSubtitle, color = Color(0xFFE8ECFF), fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    items.forEach { item ->
                        val selected = item.key == selectedKey
                        Row(
                            Modifier.fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 3.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (selected) start.copy(alpha = 0.12f) else Color.Transparent)
                                .clickable {
                                    onSelect(item.key)
                                    // Close on pick — this is what frees the whole screen for the task.
                                    scope.launch { drawerState.close() }
                                }
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                item.icon, contentDescription = null,
                                tint = if (selected) start else TextSecondary,
                                modifier = Modifier.size(20.dp),
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    item.label,
                                    color = if (selected) start else TextPrimary,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                )
                                if (item.hint.isNotBlank()) {
                                    Text(item.hint, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                }
                            }
                        }
                    }
                }
                Divider()
                Row(
                    Modifier.fillMaxWidth().clickable { onBackToHome() }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("← Home", color = TextSecondary, style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.weight(1f))
                    Text(
                        "অন্য মডিউলে যেতে Home-এ ফিরুন",
                        style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                    )
                }
            }
        },
    ) {
        Column(Modifier.fillMaxSize()) {
            // Compact top bar — deliberately not the old full ModuleWorkspaceHeader.
            // Its whole job is: which module am I in, which option is open, and how do
            // I get the option list back.
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.horizontalGradient(listOf(start, end)))
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { scope.launch { drawerState.open() } }) {
                    Icon(Icons.Filled.Menu, contentDescription = "Options", tint = Color.White)
                }
                Column(Modifier.weight(1f)) {
                    Text(moduleName, color = Color.White, fontWeight = FontWeight.Bold)
                    val current = items.firstOrNull { it.key == selectedKey }?.label
                    if (current != null) {
                        Text(current, color = Color(0xFFE8ECFF), style = MaterialTheme.typography.labelSmall)
                    }
                }
                TextButton(onClick = onBackToHome) { Text("Home", color = Color.White) }
            }
            content(selectedKey)
        }
    }
}

/**
 * Used where a mother module lists its own records for the person to drill into
 * (e.g. DMS → Ledger → pick a dealer). Kept here so both DMS and RMS draw the same
 * row rather than each inventing one.
 */
@Composable
fun ModuleDrillRow(title: String, subtitle: String, onClick: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                if (subtitle.isNotBlank()) {
                    Text(subtitle, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextSecondary)
        }
    }
}

/**
 * Honest placeholder. Used only where the draft asks for something this codebase does
 * not have yet (e.g. Retailer Stock, Gift entry). It states plainly what is missing
 * instead of showing a fake screen that looks finished.
 */
@Composable
fun NotBuiltYet(what: String, detail: String = "") {
    Column(Modifier.fillMaxWidth().padding(24.dp)) {
        Text("$what — এখনো বানানো হয়নি", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        Text(
            detail.ifBlank { "এই অংশটা draft-এ আছে কিন্তু কোডে এখনো নেই। পরের ব্যাচে বানানো হবে।" },
            style = MaterialTheme.typography.bodySmall, color = TextSecondary,
        )
    }
}
