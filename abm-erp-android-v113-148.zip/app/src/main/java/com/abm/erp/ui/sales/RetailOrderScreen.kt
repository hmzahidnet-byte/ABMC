package com.abm.erp.ui.sales

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.ProductPickerDialog
import com.abm.erp.core.Space
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.*

/**
 * Retailer Order — its own full-screen page.
 *
 * Previously this was tab 0 inside `SalesChainScreen`, so taking an order felt like being
 * inside a module rather than opening a tool. The order-taking body itself is **not
 * reimplemented**: it reuses the existing `RetailerTab` composable unchanged, which is why
 * every validation, GPS check, duplicate guard and permission rule inside it still applies
 * exactly as before.
 *
 * This route gets its own `SalesChainViewModel` instance, so the draft here is independent
 * of any half-finished draft in the Sales module — which is the behaviour you want for a
 * dedicated "take an order" screen.
 */
@Composable
fun RetailOrderScreen(onBack: () -> Unit, vm: SalesChainViewModel = viewModel()) {
    val draft by vm.draft.collectAsState()
    val lastAgentAction by vm.lastAgentAction.collectAsState()
    val orders by MockRepository.orders.collectAsState()

    val today = java.time.LocalDate.now()
    val myOrdersToday = orders.filter { it.loggedAt.toLocalDate() == today }
    val todayValue = myOrdersToday.sumOf { it.amount }

    Column(Modifier.fillMaxSize().background(DashBg)) {

        // ── header ──
        Column(
            Modifier.fillMaxWidth()
                .background(Brush.linearGradient(listOf(Color(0xFF2563EB), Color(0xFF1E3A8A))))
                .padding(horizontal = Space.md, vertical = 12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text("Retailer Order", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(
                        MockRepository.currentUser.zone.ifBlank { "—" },
                        color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp,
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Today", color = Color.White.copy(alpha = 0.75f), fontSize = 9.sp)
                    Text(
                        "${myOrdersToday.size} · ৳${"%,.0f".format(todayValue)}",
                        color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    )
                }
            }
        }

        val cart by vm.cart.collectAsState()
        val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
        var pickerOpen by remember { mutableStateOf(false) }

        Column(Modifier.weight(1f)) {
        // Cart lives in its own bounded-height scroll region. RetailerTab below already
        // contains its own internal LazyColumn (it renders the full order-taking list) — a
        // LazyColumn measured inside an unbounded verticalScroll parent throws immediately
        // at runtime ("measured with infinity maximum height constraints"), which is exactly
        // what was crashing this screen on open. Giving the cart a capped height here, and
        // leaving RetailerTab as the one weighted, self-scrolling region below it, fixes that.
        Column(
            Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()).padding(horizontal = Space.md, vertical = Space.sm),
        ) {
            // ═══ THE MEMO ═══
            // Design note (agreed with the person before building): the retailer-name entry
            // field, its area-suggestions dropdown, and the "verified shop" total are all
            // tightly coupled inside RetailerTab's own logic below — pulling just the name
            // field out risks the duplicate-order and suggestion-matching code that depends
            // on it. So this header shows the name **live** (reading the same draft state
            // RetailerTab writes to) rather than re-implementing entry a second time; the
            // actual typing still happens once, in RetailerTab's own field below.
            Column(Modifier.fillMaxWidth().background(Color.White, androidx.compose.foundation.shape.RoundedCornerShape(16.dp))) {
                Row(
                    Modifier.fillMaxWidth()
                        .background(Brush.horizontalGradient(listOf(Color(0xFF2563EB), Color(0xFF1E3A8A))), androidx.compose.foundation.shape.RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                        .padding(Space.lg),
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("ABM CORPORATION", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("Retailer Order Memo", color = Color.White.copy(alpha = 0.85f), fontSize = 9.sp)
                    }
                    Text(java.time.LocalDate.now().toString(), color = Color.White.copy(alpha = 0.85f), fontSize = 9.sp)
                }
                Column(Modifier.padding(Space.lg)) {
                    Text("TO", fontSize = 8.sp, color = TextSecondary, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                    Spacer(Modifier.height(2.dp))
                    Text(
                        draft.retailerName.value.ifBlank { "নিচে দোকানের নাম লিখুন" },
                        fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        color = if (draft.retailerName.value.isBlank()) TextSecondary else TextPrimary,
                    )

                    Spacer(Modifier.height(Space.md))

                    // ── item table ──
                    Row(
                        Modifier.fillMaxWidth().background(Color(0xFF1B2430), androidx.compose.foundation.shape.RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                            .padding(horizontal = Space.sm, vertical = 8.dp),
                    ) {
                        Text("Item", Modifier.weight(0.42f), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("Qty", Modifier.weight(0.22f), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        Text("Rate", Modifier.weight(0.17f), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.End)
                        Text("Amount", Modifier.weight(0.19f), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.End)
                    }
                    cart.forEachIndexed { idx, line ->
                        Row(
                            Modifier.fillMaxWidth()
                                .background(if (idx % 2 == 1) Color(0xFFF7F8FA) else Color.White)
                                .padding(horizontal = Space.sm, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(line.name, Modifier.weight(0.42f), fontSize = 11.sp, color = TextPrimary, maxLines = 1)
                            Row(Modifier.weight(0.22f), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { vm.updateCartQty(line.productId, line.qty - 1) }, modifier = Modifier.size(22.dp)) {
                                    Icon(Icons.Filled.Remove, "Decrease", tint = DarazOrange, modifier = Modifier.size(14.dp))
                                }
                                Text("${line.qty}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                IconButton(onClick = { vm.updateCartQty(line.productId, line.qty + 1) }, modifier = Modifier.size(22.dp)) {
                                    Icon(Icons.Filled.Add, "Increase", tint = DarazOrange, modifier = Modifier.size(14.dp))
                                }
                            }
                            Text("৳${"%,.0f".format(line.unitPrice)}", Modifier.weight(0.17f), fontSize = 10.sp, color = TextSecondary, textAlign = androidx.compose.ui.text.style.TextAlign.End)
                            Text("৳${"%,.0f".format(line.lineTotal)}", Modifier.weight(0.19f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, textAlign = androidx.compose.ui.text.style.TextAlign.End)
                        }
                    }
                    // "add item" — the table's own next row, not a separate control above it.
                    Row(
                        Modifier.fillMaxWidth().clickable { pickerOpen = true }.padding(horizontal = Space.sm, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.AddCircleOutline, null, tint = DarazOrange, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(Space.sm))
                        Text("+ Add Item", color = DarazOrange, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    if (cart.isEmpty()) {
                        Text(
                            "উপরের \"+ Add Item\" চেপে পণ্য যোগ করুন।",
                            fontSize = 10.sp, color = TextSecondary,
                            modifier = Modifier.padding(horizontal = Space.sm, vertical = 4.dp),
                        )
                    }

                    if (cart.isNotEmpty()) {
                        Spacer(Modifier.height(Space.md))
                        Row(
                            Modifier.fillMaxWidth()
                                .background(Brush.horizontalGradient(listOf(Color(0xFF2563EB), Color(0xFF1E3A8A))), androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                                .padding(horizontal = Space.md, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column {
                                Text("Total Items", color = Color.White.copy(alpha = 0.85f), fontSize = 10.sp)
                                Text("${cart.sumOf { it.qty }}", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Total Amount", color = Color.White.copy(alpha = 0.85f), fontSize = 10.sp)
                                Text("৳${"%,.0f".format(cart.sumOf { it.lineTotal })}", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

            // ── the existing order form: retailer, photo, GPS, duplicate guard, submit ──
            // Reused unchanged, so every validation it performs still applies. Given the
            // remaining screen height (not infinite) via weight(1f) on this Box, so its
            // internal LazyColumn can measure and scroll itself correctly.
            Box(Modifier.weight(1f).padding(horizontal = Space.md)) {
                com.abm.erp.core.SectionTitle("Order Details")
                RetailerTab(vm = vm, draft = draft, lastAgentAction = lastAgentAction, orders = orders)
            }
        }

        if (pickerOpen) {
            ProductPickerDialog(
                products = products,
                onDismiss = { pickerOpen = false },
                onPick = { line -> vm.addToCart(line); pickerOpen = false },
            )
        }
    }
}
