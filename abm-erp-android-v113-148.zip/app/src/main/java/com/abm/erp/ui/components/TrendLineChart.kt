package com.abm.erp.ui.components

import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * A real, dependency-free trend-line chart. Built by hand with Canvas
 * rather than a third-party charting library — after an earlier attempt
 * to wire in an external library (Vico) risked an API mismatch this
 * environment couldn't verify, a hand-drawn chart removes that risk
 * entirely while still looking like a genuine, polished analytics chart:
 * gradient fill under the curve, grid lines, animated draw-in, and a
 * highlighted final point with its value labeled.
 */
@Composable
fun TrendLineChart(
    values: List<Double>,
    lineColor: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier,
    valueFormatter: (Double) -> String = { "%,.0f".format(it) },
) {
    if (values.isEmpty()) return
    var animationProgress by remember(values) { mutableStateOf(0f) }
    val animatedProgress by animateFloatAsState(
        targetValue = animationProgress,
        animationSpec = tween(durationMillis = 900, easing = LinearOutSlowInEasing),
        label = "trendChartDrawIn",
    )
    androidx.compose.runtime.LaunchedEffect(values) {
        animationProgress = 0f
        delay(16) // let the reset commit before animating back to 1f
        animationProgress = 1f
    }

    val maxVal = values.max().let { if (it <= 0.0) 1.0 else it }
    val minVal = values.min().coerceAtMost(0.0)
    val range = (maxVal - minVal).let { if (it == 0.0) 1.0 else it }

    Column(modifier) {
        Canvas(Modifier.fillMaxWidth().height(160.dp)) {
            val w = size.width
            val h = size.height
            val gridColor = Color.Gray.copy(alpha = 0.15f)
            // Horizontal grid lines — 4 bands, quiet and unobtrusive.
            for (i in 0..3) {
                val y = h * i / 3f
                drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
            }

            val stepX = if (values.size > 1) w / (values.size - 1) else w
            val points = values.mapIndexed { index, v ->
                val x = index * stepX
                val normalized = ((v - minVal) / range).toFloat().coerceIn(0f, 1f)
                val y = h - (normalized * h)
                Offset(x, y)
            }
            val visiblePointCount = (points.size * animatedProgress).toInt().coerceIn(1, points.size)
            val visiblePoints = points.take(visiblePointCount)
            if (visiblePoints.size < 2) return@Canvas

            // Smooth-ish line path.
            val linePath = Path().apply {
                moveTo(visiblePoints[0].x, visiblePoints[0].y)
                for (i in 1 until visiblePoints.size) lineTo(visiblePoints[i].x, visiblePoints[i].y)
            }
            // Gradient fill under the curve — the one deliberate visual signature of this chart.
            val fillPath = Path().apply {
                addPath(linePath)
                lineTo(visiblePoints.last().x, h)
                lineTo(visiblePoints.first().x, h)
                close()
            }
            drawPath(fillPath, brush = Brush.verticalGradient(listOf(lineColor.copy(alpha = 0.28f), Color.Transparent)))
            drawPath(linePath, color = lineColor, style = Stroke(width = 5f))

            // Highlighted final point — where the trend currently stands.
            val last = visiblePoints.last()
            drawCircle(color = lineColor, radius = 7f, center = last)
            drawCircle(color = Color.White, radius = 3f, center = last)
        }
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(valueFormatter(values.first()), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(valueFormatter(values.last()), fontSize = 11.sp, color = lineColor, textAlign = TextAlign.End)
        }
    }
}
