package com.abm.erp.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.Constraints
import java.util.concurrent.TimeUnit

/**
 * Backend Architecture — WorkManager piece.
 *
 * Firestore's own offline cache replays queued writes automatically, but
 * only while this app process is alive; if a snapshot listener silently
 * dies after a network blip (a real Android/Firestore edge case), nothing
 * currently notices. This worker doesn't replace Firestore's queue — it
 * just guarantees a periodic "are we still actually listening?" resync by
 * restarting the same company-scoped listeners on a schedule, so a stuck
 * connection heals itself within the hour instead of staying silently
 * broken until the person manually reopens the app.
 */
class SyncRetryWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            val companyId = getSavedCompanyCode(applicationContext) ?: return Result.success()
            MockRepository.startCrossDeviceSync(companyId)
            InventoryRepository.startCrossDeviceSync(companyId)
            PurchaseRepository.startCrossDeviceSync(companyId)
            AccountsRepository.startCrossDeviceSync(companyId)
            CrmRepository.startCrossDeviceSync(companyId)
            CommsRepository.startCrossDeviceSync(companyId)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "abm_sync_retry"

        /** Called once from ABMApplication.onCreate() — WorkManager itself persists the schedule across app restarts and device reboots. */
        fun schedule(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val request = PeriodicWorkRequestBuilder<SyncRetryWorker>(1, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        }
    }
}
