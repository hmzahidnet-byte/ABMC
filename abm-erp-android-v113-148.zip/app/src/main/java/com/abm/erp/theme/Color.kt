package com.abm.erp.theme

import androidx.compose.ui.graphics.Color

// Midnight Obsidian palette — kept for any chart/accent that still wants it,
// but no longer the app's base theme (see note below).
val ObsidianBg = Color(0xFF05070B)
val ObsidianBgAlt = Color(0xFF0A0E17)
val ElectricCyan = Color(0xFF0EA5E9)
val DeepIndigo = Color(0xFF4338CA)

// GlassCard/TextPrimary/TextSecondary are referenced by EVERY module screen
// (Sales, Billing, Inventory, HRM, etc.) — these were originally tuned for a
// dark background (light text, translucent-white "glass" cards). The JSX
// design is a LIGHT theme (white cards, dark text, sky-blue/gold accents),
// so these values are updated here rather than touching every screen file —
// same names, new values, everything downstream just renders correctly now.
val GlassSurface = Color(0xFFFFFFFF)      // solid white card (was translucent white for a dark bg)
val GlassBorder = Color(0xFFE4E7EC)       // Blueprint §5 hairline — same value as HairlineBorder (kept literal: top-level vals initialise in declaration order, so referencing a later val would read as transparent at runtime)
val TextPrimary = Color(0xFF1B2430)       // dark text (was light text meant for a dark bg)
val TextSecondary = Color(0xFF7C8698)     // muted gray, readable on light backgrounds
val SuccessGreen = Color(0xFF22A06B)
val WarningAmber = Color(0xFFF5A623)
val DangerRed = Color(0xFFE24A3B)
val RiskGreen = Color(0xFF22A06B)
val RiskYellow = Color(0xFFF5A623)
val RiskRed = Color(0xFFE24A3B)

// ABM Corporation brand palette — the actual app theme (dashboard, login, headers).
val SkyTop = Color(0xFF1E6FA8)
val Sky = Color(0xFF2E8BC9)
val SkyHorizon = Color(0xFF8FD0E8)
val Gold = Color(0xFFD4AF6A)
val GoldBright = Color(0xFFF3D998)
val GoldDeep = Color(0xFF8A6A30)
val DashBg = Color(0xFFF4F6FA)             // light body background behind the white cards
val CardWhite = Color(0xFFFFFFFF)

// ---- Daraz-inspired redesign palette (Batch 1) ----
// New named tokens only — nothing above this line is renamed or removed, so every existing
// screen that references Sky/Gold/DashBg/etc. keeps compiling and rendering exactly as before.
// These are additive brand tokens for the incremental redesign to adopt module by module.
val DarazOrange = Color(0xFFF85606)        // primary brand accent — vivid orange
val DarazOrangeDark = Color(0xFFC23F00)    // pressed/gradient-end state
val DarazOrangeSoft = Color(0xFFFFE7DA)    // tint background for chips/badges on white
val ChairmanNavy = Color(0xFF0F1E3D)
val ChairmanGold = Color(0xFFD4AF37)

// ---- Status colours (Blueprint §3.3) — semantic, fixed meaning app-wide ----
// A status word never appears in two different colours in two different modules.
val StatusGreen = Color(0xFF12A867)        // approved · paid · delivered · present · synced
val StatusBlue = Color(0xFF2563EB)         // in progress · in transit · submitted · informational
val StatusAmber = Color(0xFFF5A623)        // pending · awaiting approval · low stock · late
val StatusRed = Color(0xFFDC3626)          // rejected · overdue · damaged · failed · over limit
val StatusSlate = Color(0xFF667085)        // draft · cancelled · archived · inactive

val HairlineBorder = Color(0xFFE4E7EC)     // 1dp card border (Blueprint §5)
