package com.abm.erp.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abm.erp.data.*
import com.abm.erp.theme.*

private data class RuleDef(val key: String, val label: String, val type: BusinessRuleType, val default: Double)

private val KNOWN_RULES = listOf(
    RuleDef("WEEKLY_DUE_PCT", "Weekly 50% Due Rule (Tuesday checkpoint %)", BusinessRuleType.PERCENTAGE, 50.0),
    RuleDef("MAX_DISCOUNT_PCT", "Maximum Discount %", BusinessRuleType.PERCENTAGE, 15.0),
    RuleDef("ATTENDANCE_RADIUS_M", "Attendance/Visit Radius (meters)", BusinessRuleType.DISTANCE_METERS, 100.0),
    RuleDef("LATE_ENTRY_GRACE_MIN", "Late Entry Grace Period (minutes after 9:00 AM)", BusinessRuleType.MINUTES, 30.0),
    RuleDef("INVOICE_LIMIT", "Invoice Limit (needs extra approval above this)", BusinessRuleType.AMOUNT, 500000.0),
    RuleDef("DEALER_CREDIT_LIMIT_DEFAULT", "Dealer Credit Limit — default for new dealers", BusinessRuleType.AMOUNT, 0.0),
    RuleDef("MIN_CREDIT_LIMIT", "Minimum Credit Limit (floor for any dealer)", BusinessRuleType.AMOUNT, 0.0),
    // These two were already read by the payroll/attendance logic but had no editor, so a
    // Chairman could not change shift length or the OT rate without a code change. Defaults
    // below are the exact values the code falls back to (MockRepository ~7795 / ~7833) — if
    // they ever diverge, the screen would display a number the app does not actually use.
    RuleDef("STANDARD_SHIFT_HOURS", "Standard Shift Length (hours) — overtime counts beyond this", BusinessRuleType.COUNT, 8.0),
    RuleDef("OVERTIME_RATE_MULTIPLIER", "Overtime Rate Multiplier (× normal hourly rate)", BusinessRuleType.COUNT, 1.5),
)

@Composable
fun BusinessRuleEngineScreen() {
    val currentUser = MockRepository.currentUser
    if (currentUser.role != UserRole.CHAIRMAN) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("এই স্ক্রিন শুধু Chairman-এর জন্য।") }
        return
    }
    val rules by MockRepository.businessRules.collectAsState()
    var editingKey by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Business Rule Engine", style = MaterialTheme.typography.titleLarge)
        Text("এখানে পরিবর্তন করলে সাথে সাথে পুরো ERP-এ প্রতিফলিত হবে — কোনো restart লাগবে না।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(10.dp))
        Text("Stock Approval — per-employee (HR → Employee Detail → Approval Limits)-এ configure করুন, এখানে না।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(10.dp))
        LazyColumn {
            items(KNOWN_RULES) { def ->
                val current = rules.firstOrNull { it.key == def.key }
                val currentValue = current?.value ?: def.default
                Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), tonalElevation = 2.dp) {
                    Column(Modifier.padding(10.dp)) {
                        Text(def.label, style = MaterialTheme.typography.titleSmall)
                        Text("বর্তমান মান: $currentValue${if (def.type == BusinessRuleType.PERCENTAGE) "%" else ""}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        current?.let { Text("সর্বশেষ পরিবর্তন: ${it.updatedByName} (${it.updatedAt.toLocalDate()})", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                        TextButton(onClick = { editingKey = def.key }) { Text("সম্পাদনা করুন") }
                    }
                }
            }
        }
    }

    editingKey?.let { key ->
        val def = KNOWN_RULES.first { it.key == key }
        val current = rules.firstOrNull { it.key == key }?.value ?: def.default
        var newValue by remember { mutableStateOf(current.toString()) }
        androidx.compose.ui.window.Dialog(onDismissRequest = { editingKey = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(def.label, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newValue, onValueChange = { newValue = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("নতুন মান") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val v = newValue.toDoubleOrNull()
                            if (v != null) {
                                MockRepository.setBusinessRule(def.key, def.label, def.type, v)
                                editingKey = null
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("সংরক্ষণ করুন") }
                }
            }
        }
    }
}
