package com.abm.erp.config

/**
 * Part P — Module Readiness Registry. Every dashboard tile's real status,
 * so nothing production-visible silently shows "coming in the next
 * update" and nothing incomplete is advertised as done. Statuses reflect
 * this actual pass's honest findings, not aspirational completeness.
 */
enum class ModuleReadiness { ENABLED, LIMITED, DISABLED }

object ModuleRegistry {
    // Foundations 1-6 + Bangladesh Location Master — core business modules.
    private val readiness: Map<String, ModuleReadiness> = mapOf(
        "sales" to ModuleReadiness.ENABLED,
        "crm" to ModuleReadiness.ENABLED,
        "dealer" to ModuleReadiness.ENABLED,
        "inv" to ModuleReadiness.ENABLED,
        "prod" to ModuleReadiness.LIMITED, // Part L hardened completion, but Part M/N ledger-reconciliation checks are not yet fully wired across every posting path
        "hrm" to ModuleReadiness.LIMITED, // Part A/B UserAccount system exists but LoginScreen's primary path is still the legacy demoAccounts map pending full cutover
        "bill" to ModuleReadiness.LIMITED, // Part M mutex added for invoice numbering; full reversal-not-destructive-edit workflow not yet audited end-to-end
        "boardroom" to ModuleReadiness.LIMITED, // Foundation 6 KPI/exception engine real; Part Q voice/AI confirmation-gating exists for decision query only, not yet for the assistant/analysis modes
        "bd_location" to ModuleReadiness.ENABLED, // hardened this pass (Part R)
    )

    fun statusOf(moduleKey: String): ModuleReadiness = readiness[moduleKey] ?: ModuleReadiness.ENABLED // unlisted = assume working (this registry only tracks EXCEPTIONS, not a full allowlist) — defaulting to DISABLED would have hidden every real module this session built that was never explicitly added here

    /** Production config (Part S) forces anything not explicitly ENABLED to render as disabled/limited rather than silently pretending completeness. */
    fun isFullyEnabled(moduleKey: String): Boolean = statusOf(moduleKey) == ModuleReadiness.ENABLED
}
