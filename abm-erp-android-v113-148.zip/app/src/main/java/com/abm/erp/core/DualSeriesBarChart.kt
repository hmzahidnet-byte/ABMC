package com.abm.erp.core

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.theme.ElectricCyan
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextSecondary

/**
 * v113-139 — the dual-series weekly bar chart, moved out of ChairmanHubScreen so
 * EVERY mother-module dashboard can show the same real chart (person asked for
 * KPI graphics on each module dashboard, "aro attractive lge dakte"). One shared
 * implementation rather than five near-identical copies — and it renders only
 * real caller-supplied values, never sample data.
 *
 * `weekly` is (label, seriesA, seriesB). Labels for the two series are the
 * caller's, so DMS can say Sales/Collection while another module says something
 * else, without the component inventing meaning.
 */
@Composable
fun DualSeriesBarChart(
    weekly: List<Triple<String, Double, Double>>,
    labelA: String,
    labelB: String,
) {
    val maxVal = (weekly.maxOfOrNull { maxOf(it.second, it.third) } ?: 0.0).coerceAtLeast(1.0)
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().height(140.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
            weekly.forEach { (_, a, b) ->
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Box(Modifier.width(14.dp).height((110 * (a / maxVal)).dp.coerceAtLeast(2.dp)).background(SuccessGreen, RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp)))
                    Box(Modifier.width(14.dp).height((110 * (b / maxVal)).dp.coerceAtLeast(2.dp)).background(ElectricCyan, RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp)))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            weekly.forEach { (label, _, _) -> Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 10.sp) }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(10.dp).background(SuccessGreen, RoundedCornerShape(2.dp))); Spacer(Modifier.width(4.dp)); Text(labelA, style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
            Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(10.dp).background(ElectricCyan, RoundedCornerShape(2.dp))); Spacer(Modifier.width(4.dp)); Text(labelB, style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
        }
    }
}
