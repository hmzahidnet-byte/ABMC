package com.abm.erp.ui.login

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.abm.erp.data.EMPLOYEE_DIRECTORY
import com.abm.erp.data.Employee
import com.abm.erp.data.DIVISION_DISTRICTS
import com.abm.erp.data.ZONES
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.MockRepository
import com.abm.erp.data.startCrossDeviceSync
import com.abm.erp.data.getLastLoggedInEmployee
import com.abm.erp.data.getOrCreateDeviceId
import com.abm.erp.data.getSavedCompanyCode
import com.abm.erp.data.getSavedLanguage
import com.abm.erp.data.isWeakPin
import com.abm.erp.data.saveCompanyCode
import com.abm.erp.data.saveLanguage
import com.abm.erp.data.saveLastLoggedInEmployee
import com.abm.erp.theme.*
import com.abm.erp.util.LocationAnomalyChecker
import com.abm.erp.util.NetworkStatus
import com.abm.erp.util.tryGetLoginLocation
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
private enum class LoginStatus { Idle, Checking, Error, Success }

/** Best-effort single GPS fix for the login-time anomaly/geo-block check. Returns null on any failure — this must never block login. Now in NetworkStatus.kt (shared with DealerLoginScreen). */

// এই ডিভাইসে সর্বশেষ কে PIN দিয়ে লগইন করেছিল, সেটা স্থানীয়ভাবে (শুধু এই
// ফোনে) মনে রাখার জন্য — biometric/fingerprint unlock তখন শুধু সেই একই
// মানুষকেই ফিরিয়ে আনবে, অন্য কাউকে (যেমন Chairman) না। এটাই সঠিক এবং
// নিরাপদ পদ্ধতি, যেভাবে ব্যাংকিং অ্যাপগুলোও fingerprint ব্যবহার করে —
// fingerprint কখনো "কে" যাচাই করে না, শুধু "এই ফোনে আগে থেকে save করা
// পরিচয়টাই কি নিশ্চিত হলো" তা যাচাই করে। (helper ফাংশনগুলো এখন
// SessionPrefs.kt-এ — ABMApplication-ও company code পড়তে পারার জন্য।)

private val STRICT_ROLES = setOf("CHAIRMAN", "MD")
// Issue 3 — same set already used elsewhere in this codebase (e.g.
// approval override-role checks) for "finance approval / user
// administration" authority. Privileged roles must never be let into a
// session via weak (e.g. face-only on hardware without strong-class
// support) biometric — BIOMETRIC_STRONG only, or PIN.
private val PRIVILEGED_BIOMETRIC_ROLES = setOf("CHAIRMAN", "MD", "GM", "AGM")

/**
 * Entry point before the main app. Two paths in, matching the design phase:
 * 1. 5-digit PIN checked against MockRepository.demoAccounts.
 * 2. Real device fingerprint/Face unlock via BiometricPrompt, which needs
 *    the FragmentActivity host passed in from MainActivity.
 *
 * Also matches the design phase's security additions: 3 wrong PIN attempts
 * locks this device (only the Chairman's PIN unlocks it), and a simulated
 * Forgot-PIN → OTP → new-PIN flow. No demo PINs are shown on screen anymore —
 * showing credentials on a real login screen is a security anti-pattern.
 *
 * On success, calls MockRepository.completeLogin(user) then onLoginSuccess(),
 * which flips MainActivity over to the real dashboard.
 */
@Composable
fun LoginScreen(activity: FragmentActivity, onLoginSuccess: () -> Unit, onDealerLoginRequested: () -> Unit = {}) {
    val deviceId = remember { getOrCreateDeviceId(activity) }

    // Multi-tenant: প্রথম ব্যবহারে Company Code চাইবে, তারপর মনে রাখবে —
    // "intro" (animated brand reveal, ~3.8s) then "pin" (the actual login UI).
    var phase by remember { mutableStateOf(if (getSavedCompanyCode(activity) == null) "companyCode" else "intro") }
    var lang by remember { mutableStateOf(getSavedLanguage(activity)) }
    fun t(bn: String, en: String) = if (lang == "bn") bn else en
    var companyCodeInput by remember { mutableStateOf("") }
    var companyCodeError by remember { mutableStateOf<String?>(null) }

    var pin by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(LoginStatus.Idle) }
    var biometricError by remember { mutableStateOf<String?>(null) }
    val shakeOffset = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    val demoAccounts by MockRepository.demoAccountsFlow.collectAsState()

    var mobileInput by remember { mutableStateOf(com.abm.erp.data.getRememberedMobile(activity) ?: "") }
    var mobileError by remember { mutableStateOf<String?>(null) }
    var resolvedEmployee by remember { mutableStateOf<Employee?>(null) }
    var resolvedRealAccountId by remember { mutableStateOf<String?>(null) }
    var resolvedRealEmployeeName by remember { mutableStateOf<String?>(null) }
    var resolvedRealEmployeeIdForLogin by remember { mutableStateOf<String?>(null) }
    var forcePinChangeAccountId by remember { mutableStateOf<String?>(null) }
    var noDemoPinError by remember { mutableStateOf(false) }
    var geoBlockError by remember { mutableStateOf(false) }

    // Real production resolution — Mobile Number is the ONLY lookup key.
    // No designation/division/district/zone selection: role, designation,
    // company, territory, manager, dashboard, and permissions are all
    // auto-loaded afterward from the matched EmployeeProfile itself (see
    // attemptLogin below, unchanged). Mobile numbers are unique per
    // employee, so this is also strictly safer than the old
    // designation+geography match, which could be ambiguous.
    fun resolveByMobile(mobile: String) {
        val normalized = mobile.trim()
        if (normalized.isBlank()) {
            mobileError = t("মোবাইল নম্বর দিন", "Enter your mobile number")
            return
        }
        if (!com.abm.erp.config.AppEnvironment.demoAccountsAllowed) {
            // Production — never falls back to synthetic/demo data.
            val candidate = MockRepository.employeeProfiles.value.firstOrNull { it.mobile == normalized && it.hasActiveAccess }
            val account = candidate?.let { c -> MockRepository.userAccounts.value.firstOrNull { it.employeeProfileId == c.id && it.active && !it.locked } }
            if (candidate != null && account != null) {
                resolvedRealAccountId = account.id
                resolvedRealEmployeeName = candidate.fullName
                resolvedRealEmployeeIdForLogin = candidate.id
                resolvedEmployee = null
                noDemoPinError = false
                mobileError = null
                phase = "pin"
            } else {
                resolvedRealAccountId = null
                resolvedRealEmployeeName = null
                resolvedRealEmployeeIdForLogin = null
                mobileError = t("এই মোবাইল নম্বরে কোনো সক্রিয় অ্যাকাউন্ট পাওয়া যায়নি — administrator-এর সাথে যোগাযোগ করুন।", "No active account found for this mobile number — contact your administrator.")
            }
            return
        }
        // Dev/testing only (demoAccountsAllowed == true, never reachable in
        // production per AppEnvironment.isProduction): try a real-account
        // match first (so real accounts remain testable), then fall back
        // to typing a demo employee's own id as a testing convenience.
        val realCandidate = MockRepository.employeeProfiles.value.firstOrNull { it.mobile == normalized && it.hasActiveAccess }
        val realAccount = realCandidate?.let { c -> MockRepository.userAccounts.value.firstOrNull { it.employeeProfileId == c.id && it.active && !it.locked } }
        if (realCandidate != null && realAccount != null) {
            resolvedRealAccountId = realAccount.id
            resolvedRealEmployeeName = realCandidate.fullName
            resolvedRealEmployeeIdForLogin = realCandidate.id
            resolvedEmployee = null
            noDemoPinError = false
            mobileError = null
            phase = "pin"
            return
        }
        val demoEmp = EMPLOYEE_DIRECTORY.firstOrNull { it.id.equals(normalized, ignoreCase = true) }
        val hasDemoPin = demoEmp != null && demoAccounts.values.any { it.employeeId == demoEmp.id }
        if (demoEmp != null && hasDemoPin) {
            resolvedRealAccountId = null
            resolvedRealEmployeeName = null
            resolvedRealEmployeeIdForLogin = null
            resolvedEmployee = demoEmp
            noDemoPinError = false
            mobileError = null
            phase = "pin"
        } else {
            mobileError = t("কোনো অ্যাকাউন্ট পাওয়া যায়নি (dev: demo employee id চেষ্টা করুন)", "No account found (dev: try a demo employee id)")
        }
    }

    fun areaStepsFor(d: String) = when (d) { "SR", "TSM", "ASM" -> 2; "RSM" -> 1; "DSM" -> 1; else -> 0 }

    fun resolveEmployeeId(designation: String, division: String?, district: String?, zone: String?): String? = when (designation) {
        "SR" -> "SR-$district"
        "TSM" -> "TSM-$district"
        "ASM" -> "ASM-$district"
        "RSM" -> "RSM-$division"
        "DSM" -> zone?.let { "DSM-${it.replace(" ", "")}" }
        "NSM" -> "NSM-1"; "AGM" -> "AGM-1"; "GM" -> "GM-1"; "MD" -> "MD-1"; "Chairman" -> "CHAIR-1"
        else -> null
    }

    fun tryResolveAndProceed(designation: String, division: String?, district: String?, zone: String?) {
        val empId = resolveEmployeeId(designation, division, district, zone)
        if (!com.abm.erp.config.AppEnvironment.demoAccountsAllowed) {
            // Part I — real production resolution: same designation/geo
            // dropdowns (no new UI field added), but matched against real
            // EmployeeProfile + UserAccount records instead of the
            // generated EMPLOYEE_DIRECTORY. If no real account exists yet
            // for this designation/geo combination, the honest message
            // below tells the person to contact their administrator —
            // it never falls back to synthetic data.
            val roleMatch = try { com.abm.erp.data.UserRole.valueOf(designation.uppercase()) } catch (e: Exception) { null }
            val allMatches = MockRepository.employeeProfiles.value.filter { profile ->
                profile.role == roleMatch && profile.hasActiveAccess &&
                    (district == null || profile.branch.contains(district, ignoreCase = true) || profile.area.contains(district, ignoreCase = true)) &&
                    (division == null || profile.region.contains(division, ignoreCase = true) || profile.branch.contains(division, ignoreCase = true))
            }
            // Fix — more than one real employee can share the same
            // designation+geography (e.g. two SRs in the same district).
            // Silently picking the first one (firstOrNull) risked a
            // genuine identity-confusion bug: if the ambiguous match's PIN
            // happened to match too, the person would be logged in as the
            // WRONG real employee with the WRONG permissions/territory.
            // Now refuses to resolve at all when ambiguous, same honest
            // "contact administrator" message as no-match.
            val candidate = if (allMatches.size == 1) allMatches[0] else null
            if (allMatches.size > 1) {
                com.abm.erp.config.AppLog.w("LoginScreen", "Ambiguous real-account match for $designation/$division/$district — ${allMatches.size} employees match, refusing to resolve")
            }
            val account = candidate?.let { c -> MockRepository.userAccounts.value.firstOrNull { it.employeeProfileId == c.id && it.active && !it.locked } }
            if (candidate != null && account != null) {
                resolvedRealAccountId = account.id
                resolvedRealEmployeeName = candidate.fullName
                resolvedRealEmployeeIdForLogin = candidate.id
                resolvedEmployee = null
                noDemoPinError = false
                phase = "pin"
            } else {
                resolvedEmployee = null
                resolvedRealAccountId = null
                resolvedRealEmployeeName = null
                resolvedRealEmployeeIdForLogin = null
                noDemoPinError = true
            }
            return
        }
        val emp = EMPLOYEE_DIRECTORY.firstOrNull { it.id == empId }
        val hasDemoPin = demoAccounts.values.any { it.employeeId == empId }
        if (emp != null && hasDemoPin) {
            resolvedRealAccountId = null
            resolvedRealEmployeeName = null
            resolvedRealEmployeeIdForLogin = null
            resolvedEmployee = emp
            noDemoPinError = false
            phase = "pin"
        } else {
            resolvedEmployee = emp
            noDemoPinError = true
        }
    }

    val deviceLocked by MockRepository.deviceLocked.collectAsState()

    // ---- Admin-unlock sub-flow (only shown while deviceLocked) ----
    var unlockPin by remember { mutableStateOf("") }
    var unlockError by remember { mutableStateOf<String?>(null) }
    var showBreakGlass by remember { mutableStateOf(false) }
    var breakGlassCode by remember { mutableStateOf("") }
    var breakGlassError by remember { mutableStateOf<String?>(null) }

    // ---- Forgot-PIN sub-flow: 0 = off, 1 = phone, 2 = OTP, 3 = new PIN, 4 = done ----
    var forgotStep by remember { mutableStateOf(0) }
    var forgotPhone by remember { mutableStateOf("") }
    var forgotOtp by remember { mutableStateOf("") }
    var forgotNewPin by remember { mutableStateOf("") }
    var forgotError by remember { mutableStateOf<String?>(null) }
    val otpCoroutineScope = rememberCoroutineScope()

    // ---- role-based strictness: Chairman/MD need PIN + biometric, both ----
    var pendingStrictUser by remember { mutableStateOf<com.abm.erp.data.AppUser?>(null) }

    // ---- new-device Admin-approval ----
    var pendingDeviceApproval by remember { mutableStateOf<com.abm.erp.data.AppUser?>(null) }

    // ---- জরুরি SOS ----
    var showSOS by remember { mutableStateOf(false) }
    var sosSent by remember { mutableStateOf(false) }

    fun reset() {
        pin = ""
        status = LoginStatus.Idle
        resolvedRealAccountId = null
        resolvedRealEmployeeName = null
        resolvedRealEmployeeIdForLogin = null
    }

    /**
     * Issue 1 fix — single centralized finalization point. Previously the
     * real-account biometric binding was saved immediately after PIN
     * verification, before geo policy, device-trust/approval, and
     * mandatory-biometric had even run — meaning a login that was later
     * geo-blocked, pending device approval, or still awaiting mandatory
     * biometric could still have already enrolled quick-unlock. This
     * function is now the ONLY place that saves/refreshes the binding,
     * and it is only ever called from the three genuine success points
     * below (trusted-device fast path, confirmMandatoryBiometric,
     * approveThisDeviceNow) — never from a blocked/pending/failed branch.
     */
    suspend fun finalizeSuccessfulLogin(user: com.abm.erp.data.AppUser, loc: Pair<Double, Double>?, anomalous: Boolean = false) {
        MockRepository.unlockDevice()
        saveLastLoggedInEmployee(activity, user.employeeId)
        // v113-139 — remember the number ONLY here, at the single confirmed-success
        // point (never from a failed/blocked/pending branch), so next time this
        // device asks for the PIN alone. Convenience only — the PIN is still fully
        // verified against the PBKDF2 hash on every login.
        if (mobileInput.isNotBlank()) com.abm.erp.data.saveRememberedMobile(activity, mobileInput)
        val realAccId = resolvedRealAccountId
        if (realAccId != null) {
            val account = MockRepository.userAccounts.value.firstOrNull { it.id == realAccId }
            if (account != null) {
                com.abm.erp.data.saveLastLoggedInAccount(activity, account.id, user.employeeId, account.pinSetAt.toInstant(java.time.ZoneOffset.UTC).toEpochMilli())
            }
        }
        FirebaseSync.recordLoginAttempt(user.employeeId, user.name, deviceId, success = true, anomalous = anomalous)
        if (loc != null) MockRepository.recordPresenceCheckIn(user.employeeId, user.name, loc.first, loc.second, false)
        MockRepository.logAudit("Session", user.employeeId, "LOGIN_FINALIZED")
        MockRepository.completeLogin(user)
    }

    fun attemptLogin(code: String) {
        status = LoginStatus.Checking
        scope.launch {
            delay(400) // small pause so "Verifying..." is visible, matches the design prototype
            // Part A/C — real production path: verify against the actual
            // UserAccount (PBKDF2) resolved in tryResolveAndProceed, not
            // demoAccounts. Builds a real AppUser from the matched
            // EmployeeProfile so the SAME downstream geo/device/biometric/
            // finalization logic below (unchanged) applies to both paths.
            val realAccountId = resolvedRealAccountId
            var user: com.abm.erp.data.AppUser? = null
            if (realAccountId != null) {
                val verifyResult = MockRepository.verifyUserAccountPin(realAccountId, code, deviceId)
                if (verifyResult.success && verifyResult.mustChangePin) {
                    // Part A — real forced-PIN-change gate: login does not
                    // complete until a new PIN is set. No side effects
                    // (unlock/attendance/session) happen yet.
                    forcePinChangeAccountId = realAccountId
                    status = LoginStatus.Idle
                    return@launch
                }
                if (verifyResult.success) {
                    val profile = MockRepository.employeeProfiles.value.firstOrNull { it.id == resolvedRealEmployeeIdForLogin }
                    if (profile != null) {
                        user = com.abm.erp.data.AppUser(
                            id = profile.id, name = profile.fullName, role = profile.role, companyId = profile.companyId,
                            zone = profile.branch, employeeId = profile.id, territoryId = profile.territoryId, phone = profile.mobile,
                        )
                        // Part F bootstrap fix — real UserAccount login now
                        // actually attempts to bind this device + claim the
                        // Firestore role, closing the "never bootstraps"
                        // gap. Best-effort: failure here doesn't block
                        // login, since app-internal authorization (Room/
                        // PermissionManager) already works independently.
                        realAccountId?.let { accId -> MockRepository.bindDeviceAndClaimRole(profile.id, accId) }
                    }
                } else if (verifyResult.locked) {
                    status = LoginStatus.Error
                    noDemoPinError = true
                    delay(700); pin = ""; status = LoginStatus.Idle
                    return@launch
                }
            } else if (com.abm.erp.config.AppEnvironment.demoAccountsAllowed) {
                // আগে এখানে blind lookup ছিল (demoAccounts[code] থেকে সরাসরি কে
                // সেটা বের করা) — এখন PIN শুধু "designation+area থেকে resolve
                // করা মানুষটাই কিনা" তা নিশ্চিত করে, নিজে কাউকে খুঁজে বের করে না।
                val candidate = demoAccounts[code]
                user = if (candidate != null && resolvedEmployee != null && candidate.employeeId == resolvedEmployee!!.id) candidate else null
            }
            if (user != null) {
                // ---- অস্বাভাবিক লোকেশন চেক + hard geo-block (best-effort —
                // location না পেলে কোনোটাই প্রযোজ্য হয় না, লগইন আটকায় না) ----
                val loc = tryGetLoginLocation(activity)
                // Fix — this used to ONLY check EMPLOYEE_DIRECTORY, which
                // real accounts (UUID employeeId) never match, silently
                // skipping the whole geo-block for every real-account
                // login. Now also resolves division/district from the
                // real EmployeeProfile's divisionId/districtId (Part K)
                // via the Bangladesh Location Master when present.
                val demoGeo = EMPLOYEE_DIRECTORY.firstOrNull { it.id == user.employeeId }?.geo
                val realProfile = MockRepository.employeeProfiles.value.firstOrNull { it.id == user.employeeId }
                val realDivision = realProfile?.divisionId?.let { id -> MockRepository.administrativeLocations.value.firstOrNull { it.id == id }?.nameEn }
                val realDistrict = realProfile?.districtId?.let { id -> MockRepository.administrativeLocations.value.firstOrNull { it.id == id }?.nameEn }
                val division = demoGeo?.division ?: realDivision
                val district = demoGeo?.district ?: realDistrict
                val anomalous = loc != null && LocationAnomalyChecker.isAnomalous(division, loc.first, loc.second)
                val tooFar = loc != null && LocationAnomalyChecker.isTooFarToLogin(user.role.name, division, district, loc.first, loc.second)

                if (tooFar) {
                    // SR/TSM/ASM/RSM — নিজের এলাকা থেকে ৫০ কিমি-র বেশি দূরে
                    // হলে লগইনই সম্পূর্ণ হবে না (শুধু flag/log না, hard block) —
                    // তাই unlock/save/attendance-এর কোনো side-effect চলবে না।
                    geoBlockError = true
                    status = LoginStatus.Error
                    FirebaseSync.recordLoginAttempt(user.employeeId, user.name, deviceId, success = false, anomalous = true)
                    delay(700)
                    pin = ""
                    status = LoginStatus.Idle
                    return@launch
                }
                geoBlockError = false

                // Part C — device-trust and mandatory-biometric decisions
                // must be made BEFORE any authentication side effect. The
                // previous ordering called unlockDevice/saveLastLoggedInEmployee/
                // recordPresenceCheckIn (attendance!) here, before checking
                // whether the device even needed approval or the account
                // needed mandatory biometric — meaning attendance could be
                // marked for a login that hadn't actually finished.
                val online = NetworkStatus.isOnline(activity)
                val isTrustedDevice = FirebaseSync.isTrustedDevice(user.employeeId, deviceId) ||
                    (!online && getLastLoggedInEmployee(activity) == user.employeeId)
                val isStrict = user.role.name in STRICT_ROLES

                when {
                    !isTrustedDevice -> {
                        // New device — nothing is finalized. No unlock, no
                        // saved identity, no attendance, no audit-as-success.
                        pendingDeviceApproval = user
                        phase = "deviceApproval"
                        status = LoginStatus.Idle
                    }
                    isStrict -> {
                        // Chairman/MD — PIN correct is necessary but not
                        // sufficient; nothing finalizes until mandatory
                        // biometric also passes.
                        pendingStrictUser = user
                        phase = "mandatoryBiometric"
                        status = LoginStatus.Idle
                    }
                    else -> {
                        // Only now, with device trust and biometric (where
                        // required) both satisfied, do the real
                        // authentication side effects happen.
                        finalizeSuccessfulLogin(user, loc, anomalous)
                        status = LoginStatus.Success
                        delay(650)
                        onLoginSuccess()
                    }
                }

            } else {
                status = LoginStatus.Error
                shakeOffset.animateTo(20f, tween(50))
                shakeOffset.animateTo(-20f, tween(80))
                shakeOffset.animateTo(12f, tween(80))
                shakeOffset.animateTo(0f, tween(80))
                delay(500)
                reset()
                // এই ডিভাইসে আগে যে লগইন করেছিল, তাকে "ভুল PIN চেষ্টা" নোটিফাই (log)
                val lastHere = getLastLoggedInEmployee(activity)
                val lastHereName = lastHere?.let { id ->
                    demoAccounts.values.firstOrNull { it.employeeId == id }?.name
                        ?: MockRepository.employeeProfiles.value.firstOrNull { it.id == id }?.fullName
                } ?: "Unknown"
                FirebaseSync.recordLoginAttempt(lastHere, lastHereName, deviceId, success = false)
                // ৩ বার ভুল হলে ডিভাইস লক হয়ে যাবে — Chairman-এর PIN ছাড়া আনলক হবে না।
                MockRepository.recordFailedPinAttempt()
            }
        }
    }

    fun confirmMandatoryBiometric() {
        val user = pendingStrictUser ?: return
        status = LoginStatus.Checking
        scope.launch {
            delay(700)
            // Part C/Issue-1 — finalization moved here from the main PIN
            // flow: this is the point where mandatory biometric has
            // actually passed, so only now do the real authentication
            // side effects (including biometric-binding save) happen.
            val loc = tryGetLoginLocation(activity)
            finalizeSuccessfulLogin(user, loc)
            status = LoginStatus.Success
            pendingStrictUser = null
            delay(650)
            onLoginSuccess()
        }
    }

    /**
     * Part H — real device-approval flow. In production this must be a
     * real, server-recorded pending-approval request another authorized
     * device/admin resolves — never a same-device "simulate" button. That
     * button now only renders at all when AppEnvironment.isDebugOrStaging
     * is true (see the UI below); this function itself still requires an
     * actual pending request to exist and performs the real finalization
     * side effects only once, right here, matching Part C ordering.
     */
    fun approveThisDeviceNow() {
        val user = pendingDeviceApproval ?: return
        FirebaseSync.addTrustedDevice(user.employeeId, deviceId)
        scope.launch {
            val loc = tryGetLoginLocation(activity)
            finalizeSuccessfulLogin(user, loc)
            status = LoginStatus.Success
            pendingDeviceApproval = null
            delay(650)
            onLoginSuccess()
        }
    }

    fun submitBreakGlass() {
        // Part E — the previous static universal recovery code has been
        // removed entirely (it was embedded in source AND shown as the
        // input field's placeholder hint, i.e. disclosed in the UI itself).
        // No server-authorized recovery-token flow is configured in this
        // project, so per Part E's explicit instruction this feature is
        // disabled rather than replaced with another insecure workaround.
        breakGlassError = "Emergency recovery requires an authorized administrator. Contact your admin to unlock this device."
    }

    fun pressUnlock(digit: String) {
        if (unlockPin.length >= 5) return
        val next = unlockPin + digit
        unlockPin = next
        if (next.length == 5) {
            if (MockRepository.isChairmanPin(next)) {
                MockRepository.unlockDevice()
                unlockPin = ""
                unlockError = null
            } else {
                unlockError = if (com.abm.erp.config.AppEnvironment.demoAccountsAllowed) "Incorrect Admin PIN." else "This unlock method isn't available in production. Contact an authorized administrator."
                scope.launch { delay(500); unlockPin = "" }
            }
        }
    }

    /**
     * Production biometric fix — the authoritative resolution path.
     * Re-verifies every gate fresh (not trusting what was true when the
     * binding was saved): account exists, active, not locked, not
     * suspended, employee profile exists, company matches, device
     * trusted, and the PIN hasn't changed since this binding was made
     * (pinSetAt comparison — a changed PIN must invalidate old quick-
     * login bindings). On ANY failure, clears the local binding and
     * requires PIN — never silently falls back to picking a different
     * account. No side effects (unlock/attendance) happen until every
     * check has passed and completeLogin has actually run.
     */
    fun resolveRealBiometricAccount(accountId: String, employeeProfileId: String) {
        scope.launch {
            val account = MockRepository.userAccounts.value.firstOrNull { it.id == accountId }
            val profile = MockRepository.employeeProfiles.value.firstOrNull { it.id == employeeProfileId }
            val savedEnrolledAt = com.abm.erp.data.getBiometricEnrolledAtEpochMillis(activity)
            val currentPinSetAt = account?.pinSetAt?.toInstant(java.time.ZoneOffset.UTC)?.toEpochMilli()

            // Issue 2 — device-trust is resolved with real knowledge of
            // whether the local cache has actually loaded yet, rather
            // than treating an empty/not-yet-loaded map as "confirmed
            // revoked". LOADED+absent = real revocation (clear binding).
            // LOADING = do a one-shot authoritative read instead of
            // guessing. ERROR/offline/unreachable = fail closed for THIS
            // session attempt (ask for PIN) but the binding itself is
            // preserved — a network hiccup must never permanently destroy
            // a valid enrollment.
            var deviceTrustResult: Boolean? = null
            var deviceTrustInconclusive = false
            if (profile != null && account != null) {
                val cachedTrusted = com.abm.erp.data.FirebaseSync.isTrustedDevice(profile.id, deviceId) ||
                    com.abm.erp.data.FirebaseSync.isTrustedDevice(account.id, deviceId)
                when (com.abm.erp.data.FirebaseSync.trustedDeviceLoadState.value) {
                    com.abm.erp.data.FirebaseSync.TrustedDeviceLoadState.LOADED -> deviceTrustResult = cachedTrusted
                    com.abm.erp.data.FirebaseSync.TrustedDeviceLoadState.LOADING -> {
                        val authoritative = com.abm.erp.data.FirebaseSync.fetchTrustedDeviceAuthoritative(profile.id, deviceId)
                            ?: com.abm.erp.data.FirebaseSync.fetchTrustedDeviceAuthoritative(account.id, deviceId)
                        if (authoritative == null) deviceTrustInconclusive = true else deviceTrustResult = authoritative
                    }
                    com.abm.erp.data.FirebaseSync.TrustedDeviceLoadState.ERROR -> deviceTrustInconclusive = true
                }
            }

            val failureReason = when {
                account == null -> "account no longer exists"
                profile == null -> "employee profile no longer exists"
                account.active != true -> "account is suspended"
                account.locked -> "account is locked"
                !profile.hasActiveAccess -> "employee no longer has active access"
                account.companyId != profile.companyId -> "account/company mismatch"
                currentPinSetAt != null && currentPinSetAt != savedEnrolledAt -> "PIN was changed since this device last unlocked with fingerprint/face"
                deviceTrustResult == false -> "this device is no longer trusted for this account"
                else -> null
            }

            if (failureReason != null) {
                // Fail closed: this binding can no longer be trusted, so it's
                // cleared rather than left around to be retried indefinitely.
                com.abm.erp.data.clearLastLoggedInAccount(activity)
                android.util.Log.w("LoginScreen", "Biometric restoration refused: $failureReason")
                biometricError = "Please sign in with your PIN — your fingerprint/face quick-unlock needs to be re-set-up."
                return@launch
            }
            if (deviceTrustInconclusive) {
                // Issue 2 — cannot confirm trust either way right now
                // (offline/error). Session entry is refused, but the
                // binding is intentionally left untouched.
                biometricError = "Couldn't confirm this device right now — please sign in with your PIN, or try fingerprint/face again once you're back online."
                return@launch
            }

            val user = com.abm.erp.data.AppUser(
                id = profile!!.id, name = profile.fullName, role = profile.role, companyId = profile.companyId,
                zone = profile.branch, employeeId = profile.id, territoryId = profile.territoryId, phone = profile.mobile,
            )
            MockRepository.completeLogin(user)
            // Refresh the enrollment timestamp to the current pinSetAt so this
            // binding stays valid for next time (only reached after every
            // check above has already passed).
            com.abm.erp.data.saveLastLoggedInAccount(activity, account!!.id, profile.id, currentPinSetAt ?: 0L)
            MockRepository.logAudit("Session", profile.id, "BIOMETRIC_LOGIN")
            MockRepository.unlockDevice()
            onLoginSuccess()
        }
    }

    fun startBiometric() {
        // Android's biometric API only ever confirms "a fingerprint/face already
        // enrolled ON THIS DEVICE matched" — it can NEVER tell the app WHICH
        // person that was. So biometric login can only safely mean "quickly
        // re-enter the account that already logged in with a PIN on this
        // device" — never a way to pick/become an arbitrary account.
        //
        // Production fix — this used to resolve the restored identity via
        // MockRepository.demoAccounts (a hardcoded map), which has no real
        // authority in production. The real, authoritative path below
        // resolves through UserAccount + EmployeeProfile — the exact same
        // data source PIN login uses — and re-verifies every gate PIN
        // login would check (active, not locked, not suspended, profile
        // exists, company matches, device trusted) fresh at biometric time,
        // rather than trusting whatever was true when the binding was saved.
        val savedAccountId = com.abm.erp.data.getLastLoggedInAccountId(activity)
        val savedProfileId = com.abm.erp.data.getLastLoggedInEmployeeProfileId(activity)
        val savedEmployeeId = getLastLoggedInEmployee(activity) // legacy/DEBUG-only demo path

        if (savedAccountId == null && (savedEmployeeId == null || !com.abm.erp.config.AppEnvironment.demoAccountsAllowed)) {
            biometricError = "Log in with your PIN at least once on this device first — fingerprint/face unlock then re-signs you in without needing the PIN again."
            return
        }

        // Issue 3 — biometric strength policy determined BEFORE the prompt
        // is shown, from the saved account's actual role, never decided
        // after the fact from the auth result (BiometricPrompt doesn't
        // expose "which class matched" that way — the class is set by
        // which authenticators were ALLOWED when authenticate() was
        // called). Privileged roles get BIOMETRIC_STRONG only; if that's
        // unavailable, biometric is refused outright — never silently
        // reattempted with BIOMETRIC_WEAK.
        val savedProfileForStrengthCheck = savedProfileId?.let { id -> MockRepository.employeeProfiles.value.firstOrNull { it.id == id } }
        val isPrivileged = savedProfileForStrengthCheck?.role?.name in PRIVILEGED_BIOMETRIC_ROLES
        val requiredAuthenticators = if (isPrivileged) BiometricManager.Authenticators.BIOMETRIC_STRONG
        else BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.BIOMETRIC_STRONG

        val canAuth = BiometricManager.from(activity).canAuthenticate(requiredAuthenticators)
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            biometricError = if (isPrivileged) {
                "This role requires strong fingerprint/face security that isn't available on this device — please sign in with your PIN."
            } else when (canAuth) {
                BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE ->
                    "This device has no fingerprint/face hardware — use your PIN instead."
                BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE ->
                    "Fingerprint/face hardware is busy or unavailable right now — use your PIN, or try again shortly."
                BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED ->
                    "No fingerprint/face enrolled on this device — set one up in phone Settings, or use your PIN."
                BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED ->
                    "This device needs a security update before fingerprint/face unlock will work — use your PIN for now."
                else -> "Fingerprint/face unlock isn't available right now — use your PIN."
            }
            return
        }
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    if (savedAccountId != null && savedProfileId != null) {
                        resolveRealBiometricAccount(savedAccountId, savedProfileId)
                    } else if (com.abm.erp.config.AppEnvironment.demoAccountsAllowed) {
                        // Demo biometric — DEBUG/STAGING only, never reachable in production (guarded above).
                        val user = MockRepository.demoAccounts.values.firstOrNull { it.employeeId == savedEmployeeId }
                        if (user == null) {
                            biometricError = "Couldn't find that account anymore — please use your PIN."
                            return
                        }
                        MockRepository.completeLogin(user)
                        MockRepository.unlockDevice()
                        onLoginSuccess()
                    } else {
                        biometricError = "Couldn't find that account anymore — please use your PIN."
                    }
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    biometricError = errString.toString()
                }
            },
        )
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock ABM Corporation")
            .setSubtitle("Use your fingerprint or face to sign in")
            .setNegativeButtonText("Use PIN instead")
            .setAllowedAuthenticators(requiredAuthenticators)
            .build()
        prompt.authenticate(promptInfo)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                // Same login layout, brand-orange palette (v113-52) — the blue sky gradient
                // predated the Daraz-orange direction the rest of the app now uses.
                Brush.verticalGradient(listOf(DarazOrangeDark, DarazOrange, Color(0xFFFF8A4C), GoldBright)),
            ),
        contentAlignment = Alignment.Center,
    ) {
        val isOnline = remember { NetworkStatus.isOnline(activity) }
        // ভাষা টগল + অনলাইন/অফলাইন অবস্থা — সব phase-এ visible, top কোণে
        Row(
            modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(top = 14.dp, start = 14.dp, end = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                if (isOnline) t("📶 অনলাইন", "📶 Online") else t("📴 অফলাইন", "📴 Offline"),
                color = if (isOnline) Color.White else Color(0xFFF3D998),
                fontWeight = FontWeight.Bold, fontSize = 9.5.sp,
                modifier = Modifier
                    .background(Color(0x22FFFFFF), shape = androidx.compose.foundation.shape.RoundedCornerShape(999.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
            )
            TextButton(
                onClick = {
                    lang = if (lang == "bn") "en" else "bn"
                    saveLanguage(activity, lang)
                },
            ) {
                Text(
                    if (lang == "bn") "EN" else "বাং",
                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp,
                    modifier = Modifier
                        .background(Color(0x22FFFFFF), shape = androidx.compose.foundation.shape.RoundedCornerShape(999.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                )
            }
        }

        if (phase == "intro") {
            IntroSequence(onFinished = {
                // v113-139 — if this device already had a successful login, skip
                // straight past the mobile screen to the PIN pad using the saved
                // number. The mobile screen is still fully reachable (the "অন্য
                // নম্বর" path below), so a shared or reassigned phone isn't stuck
                // on someone else's number.
                val remembered = com.abm.erp.data.getRememberedMobile(activity)
                if (!remembered.isNullOrBlank()) {
                    mobileInput = remembered
                    // Move to the mobile phase FIRST, then resolve. If the saved
                    // number no longer resolves — employee deactivated, account
                    // locked, number reassigned — the person lands on the normal
                    // mobile screen with the error shown, instead of being stranded
                    // on a blank intro with no way forward.
                    phase = "mobile"
                    resolveByMobile(remembered)
                } else phase = "mobile"
            })
        } else if (phase == "companyCode") {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text("🏢", fontSize = 34.sp)
                Spacer(Modifier.height(10.dp))
                Text(t("আপনার কোম্পানির কোড দিন", "Enter your company code"), color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    t("প্রতিটা কোম্পানির নিজস্ব একটা কোড থাকে — একবার দিলে এই ডিভাইস মনে রাখবে।", "Each company has its own code — enter it once and this device will remember it."),
                    color = Color(0xFFE4EEF6), fontSize = 11.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = companyCodeInput, onValueChange = { companyCodeInput = it.uppercase() },
                    placeholder = { Text("ABM2026") }, modifier = Modifier.fillMaxWidth(),
                    textStyle = androidx.compose.ui.text.TextStyle(textAlign = androidx.compose.ui.text.style.TextAlign.Center),
                )
                companyCodeError?.let { Text(it, color = DangerRed, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)) }
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        val matched = FirebaseSync.validateCompanyCode(companyCodeInput)
                        if (matched == null) {
                            companyCodeError = t("কোড মেলেনি — আপনার Admin-এর কাছ থেকে সঠিক কোড নিন।", "Code didn't match — get the correct code from your Admin.")
                        } else {
                            companyCodeError = null
                            saveCompanyCode(activity, matched.code)
                            FirebaseSync.startCompanyScopedListeners(matched.id)
                            MockRepository.startCrossDeviceSync(matched.id)
                            InventoryRepository.startCrossDeviceSync(matched.id)
                            com.abm.erp.data.PurchaseRepository.startCrossDeviceSync(matched.id)
                            com.abm.erp.data.AccountsRepository.startCrossDeviceSync(matched.id)
                            com.abm.erp.data.CrmRepository.startCrossDeviceSync(matched.id)
                            com.abm.erp.data.CommsRepository.startCrossDeviceSync(matched.id)
                            phase = "intro"
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(t("চালিয়ে যান", "Continue")) }
                val knownCompanies by FirebaseSync.companies.collectAsState()
                Text(
                    if (knownCompanies.isEmpty()) t("Firebase সেটআপ না হলে কোড যাচাই হবে না — SETUP_FIREBASE.md দেখুন।", "Codes won't validate until Firebase is set up — see SETUP_FIREBASE.md.")
                    else "Demo codes: " + knownCompanies.joinToString(" · ") { it.code },
                    color = Color(0xFFE4EEF6), fontSize = 9.5.sp, modifier = Modifier.padding(top = 8.dp),
                )
            }
        } else if (phase == "mobile") {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 48.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text(t("মোবাইল নম্বর দিন", "Enter your mobile number"), color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    t("যাচাইয়ের পর আপনার পদবী, বিভাগ, এলাকা ও অনুমতি স্বয়ংক্রিয়ভাবে লোড হবে।", "After verification, your role, designation, territory, and permissions load automatically."),
                    color = Color(0xFFE4EEF6), fontSize = 11.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
                Spacer(Modifier.height(20.dp))
                OutlinedTextField(
                    value = mobileInput,
                    onValueChange = { mobileInput = it.filter { c -> c.isLetterOrDigit() || c == '-' }; mobileError = null },
                    label = { Text(t("মোবাইল নম্বর", "Mobile Number")) },
                    singleLine = true,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Text),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color(0xFFFCFAF3), unfocusedTextColor = Color(0xFFFCFAF3),
                        focusedBorderColor = GoldBright, unfocusedBorderColor = Color(0x55FFFFFF),
                        focusedLabelColor = GoldBright, unfocusedLabelColor = Color(0xFFE4EEF6),
                        cursorColor = GoldBright,
                    ),
                )
                mobileError?.let {
                    Spacer(Modifier.height(8.dp))
                    Surface(color = Color(0x2EE24A3B), shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp)) {
                        Text(it, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.5.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
                    }
                }
                Spacer(Modifier.height(16.dp))
                Button(onClick = { resolveByMobile(mobileInput) }, colors = ButtonDefaults.buttonColors(containerColor = GoldBright), modifier = Modifier.fillMaxWidth()) {
                    Text(t("এগিয়ে যান", "Continue"), color = Color(0xFF241A08), fontWeight = FontWeight.Bold)
                }
            }
        } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp, vertical = 48.dp)
                .offset(x = shakeOffset.value.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            // ---- brand ----
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                AnimatedVisibility(visible = true, enter = scaleIn(tween(500)) + fadeIn(tween(500))) {
                    Box(
                        modifier = Modifier
                            .size(84.dp)
                            .background(
                                Brush.linearGradient(listOf(GoldBright, Gold, GoldDeep)),
                                shape = CircleShape,
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("ABM", color = Color(0xFF241A08), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    "ABM Corporation",
                    color = Color(0xFFFCFAF3),
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                )
                Spacer(Modifier.height(4.dp))
                Text("by Prime Distribution", color = Color.Black, fontSize = 11.sp)
            }

            when {
                deviceLocked -> {
                    // ================= Device locked out (3 wrong attempts) =================
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text("🔒", fontSize = 34.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Too many incorrect attempts", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "This device is locked. Only the Chairman's PIN can unlock it.",
                            color = Color(0xFFE4EEF6), fontSize = 11.5.sp,
                        )
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            repeat(5) { i ->
                                val filled = i < unlockPin.length
                                Box(
                                    modifier = Modifier.size(13.dp)
                                        .background(if (filled) GoldBright else Color.Transparent, CircleShape)
                                        .border(2.dp, if (filled) GoldBright else Color(0x55FFFFFF), CircleShape),
                                )
                            }
                        }
                        unlockError?.let { Text(it, color = DangerRed, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)) }
                        Spacer(Modifier.height(16.dp))
                        PinPadGrid(
                            buttonSize = 52.dp, keyFontSize = 19.sp, enabled = true,
                            onKeyPress = { key -> pressUnlock(key) },
                            onDelete = { unlockPin = unlockPin.dropLast(1) },
                        )
                        Text("Admin PIN unlock — Chairman only", color = Color(0xFFE4EEF6), fontSize = 10.sp)
                        TextButton(onClick = { showBreakGlass = true }) {
                            Text("Is the Chairman themselves locked out?", color = Color(0xFFE4EEF6), fontSize = 10.sp)
                        }
                        if (showBreakGlass) {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(top = 10.dp).background(Color(0x40000000), RoundedCornerShape(12.dp)).padding(14.dp),
                            ) {
                                Text("Break Glass Recovery", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(
                                    "এই ডিভাইসের জন্য কোনো server-authorized recovery flow সেট করা নেই। অনুমোদিত administrator-এর সাহায্য নিন।",
                                    color = Color(0xFFE4EEF6), fontSize = 10.sp,
                                )
                                Spacer(Modifier.height(8.dp))
                                breakGlassError?.let { Text(it, color = DangerRed, fontSize = 10.5.sp) }
                                Spacer(Modifier.height(8.dp))
                                Button(onClick = { submitBreakGlass() }, modifier = Modifier.fillMaxWidth()) { Text("Contact Administrator") }
                            }
                        }
                    }
                }

                phase == "deviceApproval" && pendingDeviceApproval != null -> {
                    val pendingUser = pendingDeviceApproval!!
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text("🔐", fontSize = 34.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("New device — waiting for Admin approval", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 15.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Your PIN is correct, but this device is new for ${pendingUser.name} — for security, it needs Chairman/Admin approval first.",
                            color = Color(0xFFE4EEF6), fontSize = 11.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                        Spacer(Modifier.height(16.dp))
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = GoldBright)
                        Spacer(Modifier.height(16.dp))
                        if (com.abm.erp.config.AppEnvironment.isDebugOrStaging) {
                            OutlinedButton(onClick = { approveThisDeviceNow() }) {
                                Text("(Dev/Staging only: simulate Admin approving now)", fontSize = 10.5.sp)
                            }
                        } else {
                            Text(
                                "Ask your Chairman/Admin to approve this device from the Trusted Devices screen on their own phone.",
                                color = Color(0xFFE4EEF6), fontSize = 10.5.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            )
                        }
                        TextButton(onClick = { pendingDeviceApproval = null; phase = "pin"; pin = "" }) {
                            Text("← Back to login", color = Color(0xFFE4EEF6), fontSize = 11.sp)
                        }
                    }
                }
                phase == "mandatoryBiometric" && pendingStrictUser != null -> {
                    val strictUser = pendingStrictUser!!
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text("👑", fontSize = 34.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Extra verification required", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "${strictUser.role} requires fingerprint/face in addition to your PIN — this much access needs more than a PIN alone.",
                            color = Color(0xFFE4EEF6), fontSize = 11.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                        Spacer(Modifier.height(16.dp))
                        if (status == LoginStatus.Checking) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = GoldBright)
                        } else {
                            Button(onClick = { confirmMandatoryBiometric() }, colors = ButtonDefaults.buttonColors(containerColor = GoldBright)) {
                                Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = Color(0xFF241A08))
                                Spacer(Modifier.width(6.dp))
                                Text("Confirm with Fingerprint/Face", color = Color(0xFF241A08), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                forgotStep > 0 -> {
                    // ================= Forgot PIN → OTP flow (simulated) =================
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        when (forgotStep) {
                            1 -> {
                                Text("Reset your PIN", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = forgotPhone, onValueChange = { forgotPhone = it },
                                    placeholder = { Text("Registered mobile number") }, modifier = Modifier.fillMaxWidth(),
                                )
                                forgotError?.let { Text(it, color = DangerRed, fontSize = 11.sp) }
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        if (forgotPhone.isBlank()) forgotError = "Enter your registered mobile number."
                                        else {
                                            otpCoroutineScope.launch {
                                                val result = com.abm.erp.auth.OtpServiceProvider.instance.requestOtp(forgotPhone)
                                                if (!result.success) forgotError = result.message
                                                else { forgotError = null; forgotStep = 2 }
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                ) { Text("Send OTP") }
                            }
                            2 -> {
                                Text("Enter the OTP", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    if (com.abm.erp.config.AppEnvironment.isProduction) "Sent to $forgotPhone." else "Sent to $forgotPhone. (Debug build — check Logcat for the code.)",
                                    color = Color(0xFFE4EEF6), fontSize = 11.sp,
                                )
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = forgotOtp, onValueChange = { forgotOtp = it.filter(Char::isDigit).take(4) },
                                    placeholder = { Text("4-digit OTP") }, modifier = Modifier.fillMaxWidth(),
                                )
                                forgotError?.let { Text(it, color = DangerRed, fontSize = 11.sp) }
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        otpCoroutineScope.launch {
                                            val result = com.abm.erp.auth.OtpServiceProvider.instance.verifyOtp(forgotPhone, forgotOtp)
                                            if (!result.success) forgotError = result.message
                                            else { forgotError = null; forgotStep = 3 }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                ) { Text("Verify OTP") }
                            }
                            3 -> {
                                Text("Set a new 5-digit PIN", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = forgotNewPin, onValueChange = { forgotNewPin = it.filter(Char::isDigit).take(5) },
                                    placeholder = { Text("New PIN") }, modifier = Modifier.fillMaxWidth(),
                                )
                                forgotError?.let { Text(it, color = DangerRed, fontSize = 11.sp) }
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        if (forgotNewPin.length != 5) forgotError = "New PIN must be 5 digits."
                                        else if (isWeakPin(forgotNewPin)) forgotError = "That PIN is too weak/guessable — choose a different one."
                                        else {
                                            forgotError = null
                                            forgotStep = 4
                                            scope.launch { delay(2000); forgotStep = 0; forgotPhone = ""; forgotOtp = ""; forgotNewPin = "" }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                ) { Text("Save new PIN") }
                            }
                            4 -> Text("✓ PIN reset — please log in with it next time.", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        if (forgotStep < 4) {
                            TextButton(onClick = { forgotStep = 0; forgotError = null }) {
                                Text("← Back to login", color = Color(0xFFE4EEF6), fontSize = 11.sp)
                            }
                        }
                    }
                }

                else -> {
                    // ================= Normal PIN entry =================
                    // ---- PIN entry ----
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        resolvedEmployee?.let { emp ->
                            Text(
                                "${emp.name} — ${emp.role}", color = Color(0xFFFCFAF3),
                                fontWeight = FontWeight.Bold, fontSize = 13.sp,
                            )
                            Text(emp.geoLabel, color = Color(0xFFE4EEF6), fontSize = 10.5.sp)
                            Spacer(Modifier.height(6.dp))
                        }
                        if (geoBlockError) {
                            Surface(color = Color(0x2EE24A3B), shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                                Text(
                                    t("আপনার নির্ধারিত এলাকা থেকে অনেক দূরে — লগইন করা যাবে না।", "Too far from your assigned area — login blocked."),
                                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                )
                            }
                        }
                        Text(
                            text = when {
                                status == LoginStatus.Checking -> t("যাচাই হচ্ছে…", "Verifying…")
                                status == LoginStatus.Error && geoBlockError -> t("এলাকা মিলছে না", "Area mismatch")
                                status == LoginStatus.Error -> t("ভুল PIN — আবার চেষ্টা করুন", "Incorrect PIN — try again")
                                else -> t("আপনার ৫-সংখ্যার PIN দিন", "Enter your 5-digit PIN")
                            },
                            color = Color(0xFFE4EEF6),
                            fontSize = 13.sp,
                        )
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            repeat(5) { i ->
                                val filled = i < pin.length
                                val dotColor = if (status == LoginStatus.Error) DangerRed else GoldBright
                                Box(
                                    modifier = Modifier
                                        .size(14.dp)
                                        .background(color = if (filled) dotColor else Color.Transparent, shape = CircleShape)
                                        .border(width = 2.dp, color = if (filled) dotColor else Color(0x55FFFFFF), shape = CircleShape),
                                )
                            }
                        }
                        if (status == LoginStatus.Checking) {
                            Spacer(Modifier.height(10.dp))
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = GoldBright)
                        }
                    }

                    // ---- keypad ----
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        PinPadGrid(
                            buttonSize = 58.dp, keyFontSize = 20.sp, enabled = status == LoginStatus.Idle,
                            onKeyPress = { key -> if (pin.length < 5) { pin += key; if (pin.length == 5) attemptLogin(pin) } },
                            onDelete = { if (pin.isNotEmpty()) pin = pin.dropLast(1) },
                        )

                        // v113-139 — person's explicit request: remove the fingerprint
                        // option, PIN only. The button and its error line are gone; the
                        // biometric machinery below is left intact and unreferenced from
                        // here rather than ripped out, because the MANDATORY-biometric
                        // phase for strict/privileged accounts is a separate security
                        // path that was never part of what was asked to remove.
                        // demo PIN hint সরিয়ে দেওয়া হলো — real app-এ login screen-এ
                        // password/PIN দেখানো একটা স্পষ্ট নিরাপত্তা ভুল।
                        TextButton(onClick = { forgotStep = 1 }) {
                            Text("Forgot PIN?", color = Color(0xFFE4EEF6), fontSize = 11.5.sp)
                        }
                        if (resolvedEmployee != null) {
                            TextButton(onClick = {
                                mobileInput = ""; mobileError = null
                                resolvedEmployee = null; noDemoPinError = false; geoBlockError = false; pin = ""
                                phase = "mobile"
                            }) {
                                Text(t("এই মানুষটা আমি না — আবার চেষ্টা করুন", "Not you? Try again"), color = Color(0xFFE4EEF6), fontSize = 11.sp)
                            }
                        }
                        TextButton(onClick = { showSOS = true }) {
                            Text("🆘 Emergency SOS", color = Color(0xFFFFCDD2), fontSize = 11.sp)
                        }
                        // ডিলার লগইন — স্টাফ PIN থেকে সম্পূর্ণ আলাদা পথ (ডিলার
                        // কোম্পানির staff hierarchy-র অংশ না, বহিরাগত পার্টনার)।
                        OutlinedButton(onClick = onDealerLoginRequested) {
                            Text("🏪 Continue as Dealer", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        } // closes the `else` branch for phase != "intro"

        if (status == LoginStatus.Success) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = SuccessGreen)
                    Spacer(Modifier.height(12.dp))
                    Text("Welcome, ${MockRepository.currentUser.name}", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        forcePinChangeAccountId?.let { accountId ->
            ForcedPinChangeDialog(
                accountId = accountId,
                onSuccess = { forcePinChangeAccountId = null; pin = ""; noDemoPinError = false },
            )
        }
        // জরুরি SOS — লগইন করার আগেও ব্যবহার করা যায়, দূরের/অনিরাপদ এলাকায়
        // কাজ করা field staff-দের জন্য।
        if (showSOS) {
            SosDialog(sosSent = sosSent, onSend = { sosSent = true }, onDismiss = { showSOS = false; sosSent = false })
        }
    }
}

/**
 * The ~3.8s animated brand reveal shown once per cold app-open, before the
 * PIN pad. Timings match the JSX design's CSS keyframes exactly:
 *   t=0ms     gold badge bounces in (0.7s, overshoot)
 *   t=500ms   "ABM Corporation" fades/slides in letter by letter (+45ms each)
 *   t=1350ms  thin gold line grows out (0.6s)
 *   t=1550ms  tagline fades in (0.5s)
 *   t=2200ms  tagline starts a soft continuous pulse
 *   t=3300ms  everything fades + lifts out (0.5s) -> onFinished() at t=3800ms
 */
/** The 3x4 PIN keypad — was duplicated (device-unlock flow + normal login flow); pulled out once here so both call it instead, shrinking LoginScreen's own bytecode size. */
@Composable
private fun PinPadGrid(buttonSize: androidx.compose.ui.unit.Dp, keyFontSize: androidx.compose.ui.unit.TextUnit, enabled: Boolean, onKeyPress: (String) -> Unit, onDelete: () -> Unit) {
    val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "del"))
    rows.forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(bottom = 12.dp)) {
            row.forEach { key ->
                when {
                    key.isEmpty() -> Spacer(Modifier.size(buttonSize))
                    key == "del" -> IconButton(onClick = { if (enabled) onDelete() }, modifier = Modifier.size(buttonSize)) {
                        Icon(Icons.Filled.Backspace, contentDescription = "Delete", tint = Color(0xFFE4EEF6))
                    }
                    else -> OutlinedButton(
                        onClick = { if (enabled) onKeyPress(key) },
                        modifier = Modifier.size(buttonSize), shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFCFAF3)),
                    ) { Text(key, fontSize = keyFontSize, fontWeight = FontWeight.SemiBold) }
                }
            }
        }
    }
}

@Composable
private fun IntroSequence(onFinished: () -> Unit) {
    val brand = "ABM Corporation"

    val badgeAlpha = remember { Animatable(0f) }
    val badgeScale = remember { Animatable(0.5f) }
    val badgeRotation = remember { Animatable(-25f) }
    val lineWidthFraction = remember { Animatable(0f) }
    val taglineAlpha = remember { Animatable(0f) }
    val taglinePulse = remember { Animatable(1f) }
    val overallAlpha = remember { Animatable(1f) }
    val overallOffsetY = remember { Animatable(0f) }
    val letterAlphas = remember { brand.indices.map { Animatable(0f) } }
    val letterOffsets = remember { brand.indices.map { Animatable(14f) } }

    LaunchedEffect(Unit) {
        // gold badge — quick bounce-in with a slight overshoot, like the JSX cubic-bezier
        launch { badgeAlpha.animateTo(1f, tween(220)) }
        launch { badgeScale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium)) }
        launch { badgeRotation.animateTo(0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium)) }

        // brand name, letter by letter
        brand.indices.forEach { i ->
            launch {
                delay(500L + i * 45L)
                launch { letterAlphas[i].animateTo(1f, tween(500)) }
                letterOffsets[i].animateTo(0f, tween(500))
            }
        }

        // gold divider line
        launch {
            delay(1350L)
            lineWidthFraction.animateTo(1f, tween(600))
        }

        // tagline: fade in, then a slow continuous pulse
        launch {
            delay(1550L)
            taglineAlpha.animateTo(1f, tween(500))
        }
        launch {
            delay(2200L)
            while (true) {
                taglinePulse.animateTo(0.55f, tween(1100, easing = FastOutSlowInEasing))
                taglinePulse.animateTo(1f, tween(1100, easing = FastOutSlowInEasing))
            }
        }

        // whole intro lifts and fades out, then hand off to the PIN phase
        delay(3300L)
        launch { overallOffsetY.animateTo(-14f, tween(500)) }
        overallAlpha.animateTo(0f, tween(500))
        onFinished()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                alpha = overallAlpha.value
                translationY = overallOffsetY.value.dp.toPx()
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier
                .size(88.dp)
                .graphicsLayer {
                    scaleX = badgeScale.value
                    scaleY = badgeScale.value
                    rotationZ = badgeRotation.value
                    alpha = badgeAlpha.value
                }
                .background(Brush.linearGradient(listOf(GoldBright, Gold, GoldDeep)), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Text("ABM", color = Color(0xFF241A08), fontWeight = FontWeight.Bold, fontSize = 26.sp)
        }
        Spacer(Modifier.height(22.dp))
        Row {
            brand.forEachIndexed { i, ch ->
                Text(
                    ch.toString(),
                    color = Color(0xFFFCFAF3),
                    fontWeight = FontWeight.Bold,
                    fontSize = 25.sp,
                    modifier = Modifier.graphicsLayer {
                        alpha = letterAlphas[i].value
                        translationY = letterOffsets[i].value.dp.toPx()
                    },
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .height(2.dp)
                .width(120.dp * lineWidthFraction.value)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, Gold, Color.Transparent))),
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "by Prime Distribution",
            color = Color.Black,
            fontSize = 11.sp,
            letterSpacing = 1.sp,
            modifier = Modifier.graphicsLayer { alpha = taglineAlpha.value * taglinePulse.value },
        )
    }
}

/** Extracted from LoginScreen's main composable (Section 11 performance pass). */
@Composable
private fun SosDialog(sosSent: Boolean, onSend: () -> Unit, onDismiss: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)),
        contentAlignment = Alignment.Center,
    ) {
        Surface(shape = RoundedCornerShape(18.dp), color = Color.White, modifier = Modifier.padding(32.dp)) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🆘", fontSize = 30.sp)
                if (!sosSent) {
                    Text("Send an emergency alert?", color = Color(0xFF1B2430), fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
                    Text(
                        "Your live location will be sent immediately to your emergency contact and manager.",
                        color = Color(0xFF7C8698), fontSize = 11.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                    Button(
                        onClick = onSend,
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                        modifier = Modifier.fillMaxWidth().padding(top = 14.dp),
                    ) { Text("Yes, send now") }
                    TextButton(onClick = onDismiss) { Text("Cancel", color = Color(0xFF7C8698)) }
                } else {
                    Text("✓ Sent", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
                    Text("Help is on the way.", color = Color(0xFF7C8698), fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                    TextButton(onClick = onDismiss) { Text("Close", color = DarazOrange, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

/** Extracted from LoginScreen's main composable (Section 11 performance pass) — LoginScreen's single method was hitting the ~21k DEX instruction limit; splitting large self-contained dialog blocks into their own @Composable functions reduces per-method bytecode size without changing behavior. */
@Composable
private fun ForcedPinChangeDialog(accountId: String, onSuccess: () -> Unit) {
    var newPin1 by remember { mutableStateOf("") }
    var newPin2 by remember { mutableStateOf("") }
    var changeError by remember { mutableStateOf<String?>(null) }
    Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)), contentAlignment = Alignment.Center) {
        Surface(shape = RoundedCornerShape(18.dp), color = Color.White, modifier = Modifier.padding(32.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("নতুন PIN সেট করুন", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("প্রথম লগইন — নতুন, নিরাপদ PIN দিতে হবে।", fontSize = 11.sp, color = Color.Gray)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = newPin1, onValueChange = { newPin1 = it.filter(Char::isDigit).take(5) }, label = { Text("নতুন PIN") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(value = newPin2, onValueChange = { newPin2 = it.filter(Char::isDigit).take(5) }, label = { Text("আবার লিখুন") }, modifier = Modifier.fillMaxWidth())
                changeError?.let { Text(it, color = DangerRed, fontSize = 10.5.sp) }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        if (newPin1 != newPin2) changeError = "দুটো PIN মিলছে না।"
                        else if (!MockRepository.changeUserAccountPin(accountId, newPin1)) changeError = "এই PIN সহজে অনুমান করা যায় — অন্যটা বেছে নিন।"
                        else onSuccess()
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("PIN সেট করুন") }
            }
        }
    }
}
