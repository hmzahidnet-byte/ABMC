package com.abm.erp.core

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * v113-87 — composable wrapper around the app's ONE QR bitmap generator
 * (`com.abm.erp.util.QrCodeGenerator`, the same ZXing path the retailer shop-tag
 * feature already uses). First draft of this file re-implemented the bitmap loop;
 * caught against the standing "grep before creating" rule and rewritten to
 * delegate — one generator, one place to fix.
 *
 * Feed it ONLY genuine payloads (registry `ABMQR:…` strings from
 * `QrRegistry.issue`, or other officially-defined formats). The "never draw fake
 * QR" rule stands: this renders real payloads, it does not invent them.
 */
@Composable
fun QrImage(payload: String, size: Dp, modifier: Modifier = Modifier) {
    var bitmap by remember(payload) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(payload) {
        bitmap = if (payload.isBlank()) null else withContext(Dispatchers.Default) {
            runCatching { com.abm.erp.util.QrCodeGenerator.generate(payload, 512) }.getOrNull()
        }
    }
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        val bmp = bitmap
        if (bmp != null) {
            Image(bitmap = bmp.asImageBitmap(), contentDescription = "QR Code", modifier = Modifier.size(size))
        } else if (payload.isNotBlank()) {
            CircularProgressIndicator(Modifier.size(24.dp))
        }
    }
}
