package com.abm.erp.location

/**
 * Foundation 4 — Territory Geo-lock & Access Security. Real polygon
 * geometry (ray-casting point-in-polygon), not district-name matching.
 * "Do not depend only on district names" — a territory's polygon (when
 * defined) is the actual enforcement boundary; district/upazila remain
 * administrative labels for search/reporting.
 */
object GeoLock {

    /**
     * Ray-casting point-in-polygon test. polygon is an ordered list of
     * (lat, lng) vertices; standard, well-known algorithm — no third-party
     * geometry library needed for a simple simple (non-self-intersecting)
     * polygon, which is what a territory boundary is.
     */
    fun isPointInPolygon(lat: Double, lng: Double, polygon: List<Pair<Double, Double>>): Boolean {
        if (polygon.size < 3) return false
        var inside = false
        var j = polygon.size - 1
        for (i in polygon.indices) {
            val (latI, lngI) = polygon[i]
            val (latJ, lngJ) = polygon[j]
            if ((lngI > lng) != (lngJ > lng) && lat < (latJ - latI) * (lng - lngI) / (lngJ - lngI) + latI) {
                inside = !inside
            }
            j = i
        }
        return inside
    }

    /**
     * Boundary tolerance (Section 2): a point just outside the polygon by
     * less than toleranceMeters is still treated as inside, since GPS
     * drift near an edge is normal and shouldn't hard-fail a legitimate
     * visit. Checks the nearest polygon edge distance approximately via
     * the nearest-vertex distance (a reasonable, cheap approximation —
     * exact point-to-segment distance would need real geometry libraries
     * this project doesn't currently depend on).
     */
    fun isPointInPolygonWithTolerance(lat: Double, lng: Double, polygon: List<Pair<Double, Double>>, toleranceMeters: Double): Boolean {
        if (isPointInPolygon(lat, lng, polygon)) return true
        if (polygon.isEmpty() || toleranceMeters <= 0) return false
        val nearestVertexDistance = polygon.minOf { (vLat, vLng) -> LocationVerification.distanceMeters(lat, lng, vLat, vLng) }
        return nearestVertexDistance <= toleranceMeters
    }

    /** Section 2 — "Nearest polygon": which of several territory polygons is this point closest to (or inside). */
    fun nearestTerritory(lat: Double, lng: Double, territories: List<Pair<String, List<Pair<Double, Double>>>>): String? {
        var best: String? = null
        var bestDistance = Double.MAX_VALUE
        territories.forEach { (territoryId, polygon) ->
            if (polygon.isEmpty()) return@forEach
            if (isPointInPolygon(lat, lng, polygon)) { best = territoryId; bestDistance = 0.0; return@forEach }
            val d = polygon.minOf { (vLat, vLng) -> LocationVerification.distanceMeters(lat, lng, vLat, vLng) }
            if (d < bestDistance) { bestDistance = d; best = territoryId }
        }
        return best
    }

    enum class AccessDecision { ALLOWED, ALLOWED_WITH_WARNING, TEMPORARY_OVERRIDE, BLOCKED }
    data class EvaluationResult(val decision: AccessDecision, val reasons: List<String>)

    /**
     * The central business question this whole foundation exists to
     * answer: "Can this employee legally perform this action HERE and
     * NOW?" Real, deterministic, transparent rules — not a black box.
     * hasActiveOverride is looked up by the caller (MockRepository, which
     * has DB access) and passed in here so this stays a pure function.
     */
    fun evaluateAccess(
        lat: Double?, lng: Double?, accuracyMeters: Float?, mockSuspected: Boolean,
        territoryPolygon: List<Pair<Double, Double>>?, boundaryToleranceMeters: Double,
        isAssignedTerritory: Boolean, hasActiveOverride: Boolean,
    ): EvaluationResult {
        val reasons = mutableListOf<String>()
        if (hasActiveOverride) return EvaluationResult(AccessDecision.TEMPORARY_OVERRIDE, listOf("Active manager override in effect"))
        if (lat == null || lng == null) { reasons += "No location available"; return EvaluationResult(AccessDecision.BLOCKED, reasons) }
        if (mockSuspected) { reasons += "Mock location suspected"; return EvaluationResult(AccessDecision.BLOCKED, reasons) }
        if (!isAssignedTerritory) { reasons += "Employee not assigned to this territory"; return EvaluationResult(AccessDecision.BLOCKED, reasons) }
        if (territoryPolygon != null && territoryPolygon.size >= 3) {
            val inside = isPointInPolygonWithTolerance(lat, lng, territoryPolygon, boundaryToleranceMeters)
            if (!inside) { reasons += "Outside territory boundary"; return EvaluationResult(AccessDecision.BLOCKED, reasons) }
        }
        val quality = LocationVerification.classifyQuality(accuracyMeters)
        if (quality == LocationVerification.LocationQuality.UNRELIABLE || quality == LocationVerification.LocationQuality.UNKNOWN) {
            reasons += "GPS accuracy weak/unreliable"
            return EvaluationResult(AccessDecision.ALLOWED_WITH_WARNING, reasons)
        }
        return EvaluationResult(AccessDecision.ALLOWED, reasons)
    }
}
