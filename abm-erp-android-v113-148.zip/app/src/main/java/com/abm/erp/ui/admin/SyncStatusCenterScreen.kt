package com.abm.erp.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.abm.erp.data.MockRepository
import com.abm.erp.data.forceResync
import com.abm.erp.theme.*
import com.abm.erp.util.NetworkStatus
import kotlinx.coroutines.launch

/**
 * Section 9 — Accuracy and Audit. Real sync-status visibility: the app
 * is genuinely Room-local-first (every write already lands in Room
 * before any network attempt), so "Saved Locally" is always true the
 * instant a write completes; "Synced"/"Failed" reflect the REAL
 * `failedSyncIds` tracker (was previously only shown as a single global
 * badge with no way to see WHICH records failed, and no manual retry).
 *
 * Two things this screen must NOT claim, and doesn't:
 * 1. "Sync Pending" below is a live offline/online status label, not a count
 *    from a persistent Room sync-queue table — no such queue table exists in
 *    this codebase. If one is ever added, this label can become a real count.
 * 2. The "Reconnect" action re-attaches this session's Firestore listeners
 *    (`forceResync` — fixes a listener that silently died). It does NOT
 *    resend the writes listed in `failedIds` below; there is currently no
 *    function that replays a specific failed push. That gap is called out
 *    in the failed-records section instead of being implied away.
 */
@Composable
fun SyncStatusCenterScreen() {
    val context = LocalContext.current
    val failedIds by MockRepository.failedSyncIds.collectAsState()
    val isOnline = remember { NetworkStatus.isOnline(context) }
    var isRetrying by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Sync Status Center", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(10.dp))

        Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Server Connection", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Text(if (isOnline) "🟢 Online" else "🔴 Offline", color = if (isOnline) SuccessGreen else DangerRed)
                }
                Spacer(Modifier.height(6.dp))
                Text("✅ Saved Locally — সব লেখা সবসময় প্রথমে ডিভাইসে (Room) সংরক্ষিত হয়, নেটওয়ার্ক না থাকলেও।", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                if (!isOnline) Text("🕓 Sync Pending (offline status, না যে queue-এ গোনা কোনো সংখ্যা) — ডিভাইস অফলাইনে, তাই নতুন লেখা এখনো সার্ভারে পাঠানো হয়নি।", style = MaterialTheme.typography.bodySmall, color = WarningAmber)
                Text(if (failedIds.isEmpty()) "✅ Synced — এই সেশনে কোনো sync ব্যর্থতা নেই।" else "⚠️ ${failedIds.size}টি রেকর্ড sync ব্যর্থ হয়েছে (এই সেশনে)।", style = MaterialTheme.typography.bodySmall, color = if (failedIds.isEmpty()) SuccessGreen else DangerRed)
            }
        }
        Spacer(Modifier.height(10.dp))

        Button(
            onClick = {
                scope.launch {
                    isRetrying = true
                    val companyId = com.abm.erp.data.getSavedCompanyCode(context)
                    if (companyId != null) {
                        MockRepository.forceResync(companyId)
                        com.abm.erp.data.InventoryRepository.forceResync(companyId)
                    }
                    kotlinx.coroutines.delay(1500)
                    isRetrying = false
                }
            },
            enabled = !isRetrying && isOnline,
            modifier = Modifier.fillMaxWidth(),
        ) {
            if (isRetrying) { CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp); Spacer(Modifier.width(8.dp)) }
            Text(if (isRetrying) "রিকানেক্ট হচ্ছে…" else "🔄 Reconnect (listener refresh)")
        }
        if (!isOnline) Text("Reconnect-এর জন্য ইন্টারনেট সংযোগ দরকার।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Text("এই বাটন শুধু সার্ভার listener আবার চালু করে — নিচের ব্যর্থ রেকর্ডগুলো এখনো আবার পাঠায় না।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)

        Spacer(Modifier.height(14.dp))
        Text("ব্যর্থ রেকর্ড (এই সেশনে)", style = MaterialTheme.typography.titleMedium)
        if (failedIds.isEmpty()) {
            Text("কোনো ব্যর্থ রেকর্ড নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        } else {
            Text("এই রেকর্ডগুলো এখনো সার্ভারে পৌঁছায়নি — বর্তমানে কোনো automatic resend নেই, নিশ্চিত করতে সংশ্লিষ্ট ফর্ম থেকে আবার সাবমিট করুন।", style = MaterialTheme.typography.labelSmall, color = DangerRed)
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(failedIds.toList()) { id ->
                    Surface(tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text(id, style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.padding(8.dp))
                    }
                }
            }
        }
    }
}
