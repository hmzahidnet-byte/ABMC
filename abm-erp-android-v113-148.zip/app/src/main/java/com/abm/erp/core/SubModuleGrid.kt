package com.abm.erp.core

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

data class SubModuleItem(
    val key: String,
    val label: String,
    val icon: String,
    val colorStart: Long,
    val colorEnd: Long,
    /** Blueprint §6/§23 — when supplied, renders a vector icon instead of the emoji.
     *  Optional so modules migrate one at a time without breaking any existing call. */
    val iconVector: androidx.compose.ui.graphics.vector.ImageVector? = null,
)

/**
 * The colorful animated header every module screen can open with — same
 * visual language established on HR (Attendance) and CRM (profile detail),
 * now available as one shared component so every module gets its own
 * distinct, non-overlapping color identity without copy-pasting the same
 * ~15 lines everywhere.
 */
/**
 * Task Header — the header a module shows when reached through a Suite's specific function
 * (i.e., `startTab != null`), instead of the module's own full `ModuleWorkspaceHeader`.
 *
 * Root cause this exists to fix: every multi-tab module screen rendered its full
 * identity+KPI+quick-actions+recent-activity dashboard **unconditionally**, even when the
 * user arrived from a Suite list already asking for one specific task (e.g. "Dealer
 * Invoice"). That meant landing on a second, full mini-dashboard before ever reaching the
 * thing that was tapped — the exact "everything gathered together" clutter the redesign was
 * asked to remove. This header carries only the task's own identity and a real back arrow,
 * so a Suite-launched task now looks and feels like the dedicated page it should be — no
 * different from `RetailerOrderScreen` or `DealerInvoiceScreen`, which were hand-built this
 * way from the start.
 *
 * The module's own full dashboard is untouched and still renders exactly as before whenever
 * the module is entered without a specific task (`startTab == null`).
 */
@Composable
fun TaskHeader(
    title: String,
    colorStart: Long,
    colorEnd: Long,
    onBack: () -> Unit,
    iconVector: androidx.compose.ui.graphics.vector.ImageVector? = null,
) {
    Row(
        Modifier.fillMaxWidth()
            .background(Brush.linearGradient(listOf(Color(colorStart), Color(colorEnd))), RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp))
            .padding(horizontal = 8.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        androidx.compose.material3.IconButton(onClick = onBack) {
            androidx.compose.material3.Icon(
                androidx.compose.material.icons.Icons.Filled.ArrowBack,
                contentDescription = "Back",
                tint = Color.White,
            )
        }
        Spacer(Modifier.width(4.dp))
        if (iconVector != null) {
            Box(
                Modifier.size(36.dp).background(Color.White.copy(alpha = 0.18f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center,
            ) {
                androidx.compose.material3.Icon(iconVector, contentDescription = null, tint = Color.White, modifier = Modifier.size(19.dp))
            }
            Spacer(Modifier.width(10.dp))
        }
        Text(title, color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun ModuleGradientHeader(
    title: String,
    icon: String,
    colorStart: Long,
    colorEnd: Long,
    iconVector: androidx.compose.ui.graphics.vector.ImageVector? = null,
) {
    Box(
        Modifier.fillMaxWidth()
            .background(Brush.linearGradient(listOf(Color(colorStart), Color(colorEnd))), RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
            .padding(18.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Blueprint §6 — vector icon in a translucent chip is the target look; the emoji
            // path stays only so modules not yet migrated keep rendering while the rollout
            // proceeds module by module.
            if (iconVector != null) {
                Box(
                    Modifier.size(40.dp)
                        .background(Color.White.copy(alpha = 0.18f), RoundedCornerShape(13.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    androidx.compose.material3.Icon(
                        imageVector = iconVector,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(21.dp),
                    )
                }
            } else {
                Text(icon, fontSize = 22.sp)
            }
            Spacer(Modifier.width(12.dp))
            Text(title, color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 17.sp)
        }
    }
}

/**
 * The reusable "sub-menu of colorful tiles" every module's own screen opens
 * into — same visual language as the Dashboard's main module grid, just one
 * level deeper. Approved on Sales Chain first; same component reused for
 * every other module so the pattern stays identical everywhere.
 */
@Composable
fun SubModuleGrid(items: List<SubModuleItem>, onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        val rows = items.chunked(4)
        rows.forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 18.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { item -> SubModuleTile(item, onClick = { onSelect(item.key) }) }
                repeat(4 - row.size) { Spacer(Modifier.width(54.dp)) }
            }
        }
    }
}

@Composable
private fun SubModuleTile(item: SubModuleItem, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.9f else 1f, label = "tileScale")
    Column(
        modifier = Modifier
            .width(64.dp)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(54.dp)
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .background(Brush.linearGradient(listOf(Color(item.colorStart), Color(item.colorEnd))), RoundedCornerShape(17.dp)),
            contentAlignment = Alignment.Center,
        ) {
            if (item.iconVector != null) {
                androidx.compose.material3.Icon(
                    imageVector = item.iconVector,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(24.dp),
                )
            } else {
                Text(item.icon, fontSize = 22.sp)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(item.label, style = MaterialTheme.typography.labelSmall, color = TextPrimary, textAlign = TextAlign.Center, maxLines = 2)
    }
}

/**
 * Enterprise Workspace redesign — every module's professional header: the existing branded
 * gradient banner, plus an identity strip (who's working this module right now) and an optional
 * mini-dashboard KPI row specific to that module. Identity is read entirely from the already-
 * authenticated session (MockRepository.currentUser -> employeeProfiles -> companySettings) —
 * never prompts the user to reselect who they are. No photo file exists in the data model (no
 * schema change made for this), so a colored initials avatar is used, same visual idiom as the
 * Dashboard's own "ABM" badge.
 */
@Composable
fun ModuleWorkspaceHeader(
    title: String,
    icon: String,
    colorStart: Long,
    colorEnd: Long,
    miniDashboard: (@Composable () -> Unit)? = null,
    quickActions: (@Composable () -> Unit)? = null,
    recentActivity: (@Composable () -> Unit)? = null,
    iconVector: androidx.compose.ui.graphics.vector.ImageVector? = null,
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val currentUser = com.abm.erp.data.MockRepository.currentUser
    val profiles by com.abm.erp.data.MockRepository.employeeProfiles.collectAsState()
    val profile = remember(currentUser.employeeId, profiles) { profiles.firstOrNull { it.id == currentUser.employeeId } }
    val company = remember(currentUser.companyId) { com.abm.erp.data.MockRepository.companySettings() }
    val isOnline = remember { com.abm.erp.util.NetworkStatus.isOnline(context) }
    val failedSyncCount by com.abm.erp.data.MockRepository.failedSyncIds.collectAsState()
    val initials = remember(currentUser.name) { currentUser.name.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() } }

    Column(Modifier.fillMaxWidth()) {
        ModuleGradientHeader(title, icon, colorStart, colorEnd, iconVector)
        Surface(tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(38.dp).background(Brush.linearGradient(listOf(Color(colorStart), Color(colorEnd))), RoundedCornerShape(19.dp)),
                    contentAlignment = Alignment.Center,
                ) { Text(initials.ifBlank { "?" }, color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 13.sp) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(currentUser.name, style = MaterialTheme.typography.titleSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, color = TextPrimary)
                    val idLine = listOfNotNull(
                        profile?.employeeCode?.ifBlank { null } ?: currentUser.employeeId.ifBlank { null },
                        profile?.designation?.ifBlank { null },
                        company.companyName.ifBlank { null },
                    ).joinToString(" · ")
                    if (idLine.isNotBlank()) Text(idLine, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    val territory = currentUser.zone.ifBlank { null }
                    if (territory != null) Text(territory, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        if (isOnline) "🟢 Online" else "🔴 Offline",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isOnline) Color(0xFF1FA972) else Color(0xFFC0392B),
                    )
                    Text(
                        if (failedSyncCount.isEmpty()) "✅ Synced" else "⚠ ${failedSyncCount.size} pending",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (failedSyncCount.isEmpty()) Color(0xFF1FA972) else Color(0xFFE0A800),
                    )
                }
            }
        }
        if (miniDashboard != null) {
            Surface(tonalElevation = 0.5.dp, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    miniDashboard()
                }
            }
        }
        if (quickActions != null) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                quickActions()
            }
        }
        if (recentActivity != null) {
            Surface(tonalElevation = 0.5.dp, modifier = Modifier.fillMaxWidth()) {
                Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    recentActivity()
                }
            }
        }
    }
}

/** Standard workspace "Recent activity" panel — filters the existing global audit log
 * (MockRepository.auditLogEntries) down to the entity types relevant to one module, most-recent
 * first. No new data source; purely a scoped view over data that's already tracked and shown
 * elsewhere (Enterprise Audit Center). */
@Composable
fun ModuleRecentActivity(entityTypes: Set<String>, limit: Int = 5) {
    val allEntries by com.abm.erp.data.MockRepository.auditLogEntries.collectAsState()
    val recent = remember(allEntries) {
        allEntries.filter { it.entityType in entityTypes }.sortedByDescending { it.timestamp }.take(limit)
    }
    Column(Modifier.fillMaxWidth()) {
        Text("সাম্প্রতিক কার্যক্রম", style = MaterialTheme.typography.titleSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        if (recent.isEmpty()) {
            Text("এখনো কোনো কার্যক্রম নেই।", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        } else {
            recent.forEach { e ->
                Text(
                    "${e.entityType} — ${e.action} · ${e.performedBy}",
                    style = MaterialTheme.typography.bodySmall, color = TextSecondary,
                    maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/** One stat in a module's mini-dashboard row — label + value, optional color. */
@Composable
fun ModuleStat(label: String, value: String, color: Color = TextPrimary, onClick: (() -> Unit)? = null) {
    // Blueprint §19 — tapping a KPI navigates to the filtered list that explains it.
    // Optional so every existing call site stays valid; the chevron only appears when
    // the stat is actually actionable, so users aren't invited to tap dead numbers.
    Column(
        modifier = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier,
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, color = color)
            if (onClick != null) {
                Spacer(Modifier.width(2.dp))
                androidx.compose.material3.Icon(
                    imageVector = Icons.Filled.ChevronRight,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(14.dp),
                )
            }
        }
    }
}

/** Standard workspace list states — Empty/Loading/Error+Retry, reused across module screens instead of each screen writing its own ad-hoc "no data" text. Purely presentational. */
@Composable
fun WorkspaceEmptyState(
    message: String,
    icon: String = "",
    iconVector: androidx.compose.ui.graphics.vector.ImageVector = Icons.Filled.Inbox,
) {
    // Blueprint §14 — an empty state is an icon chip, a sentence naming the thing that is
    // missing, and nothing else. `icon` is kept in the signature so the ~35 existing call
    // sites that pass an emoji still compile; it is no longer rendered.
    Column(Modifier.fillMaxWidth().padding(vertical = 32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        IconChip(icon = iconVector, accent = TextSecondary, size = 48)
        Spacer(Modifier.height(10.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, color = TextSecondary, textAlign = TextAlign.Center)
    }
}

@Composable
fun WorkspaceLoadingState(message: String = "লোড হচ্ছে…") {
    Column(Modifier.fillMaxWidth().padding(vertical = 32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        androidx.compose.material3.CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 2.dp)
        Spacer(Modifier.height(8.dp))
        Text(message, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
    }
}

@Composable
fun WorkspaceErrorState(message: String, onRetry: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        IconChip(icon = Icons.Filled.ErrorOutline, accent = com.abm.erp.theme.StatusRed, size = 48)
        Spacer(Modifier.height(10.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, color = com.abm.erp.theme.DangerRed, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        androidx.compose.material3.OutlinedButton(onClick = onRetry) { Text("Retry") }
    }
}

/** Standard "← Back" link used at the top of every sub-view, to return to that module's tile grid. */
@Composable
fun BackToSubMenuLink(onClick: () -> Unit) {
    Text(
        "← Back", color = TextPrimary, fontSize = 13.sp,
        modifier = Modifier.clickable(onClick = onClick).padding(bottom = 12.dp),
    )
}
