package com.abm.erp.config

import com.abm.erp.BuildConfig

/**
 * Part S — Release Configuration. Centralizes the DEBUG/STAGING/PRODUCTION
 * distinction instead of scattering `BuildConfig.DEBUG` checks across the
 * codebase. Every "is this feature allowed" question in Parts D/E/H/I
 * routes through this object.
 */
enum class Environment { DEBUG, STAGING, PRODUCTION }

object AppEnvironment {
    val current: Environment = when (BuildConfig.APP_ENVIRONMENT) {
        "PRODUCTION" -> Environment.PRODUCTION
        "STAGING" -> Environment.STAGING
        else -> Environment.DEBUG
    }

    val isProduction: Boolean get() = current == Environment.PRODUCTION
    val isDebugOrStaging: Boolean get() = !isProduction

    // Part S — production must disable all of these, centrally, not per-file.
    val demoAccountsAllowed: Boolean get() = !isProduction
    val demoOtpAllowed: Boolean get() = current == Environment.DEBUG // stricter than staging — mock OTP never in staging either, only local debug
    val simulatedDeviceApprovalAllowed: Boolean get() = current == Environment.DEBUG
    val staticRecoveryCodeAllowed: Boolean get() = false // never allowed in any build — Part E removes it outright regardless of environment
    val seedDemoDataAllowed: Boolean get() = !isProduction
    val debugLoggingEnabled: Boolean get() = !isProduction
}
