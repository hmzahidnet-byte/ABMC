package com.abm.erp.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Action-level permission engine — Foundation Layer.
 *
 * ROLE_MODULES (ModuleAccess.kt) only answers "can this designation even see
 * this module tile". PermissionManager answers the finer question every
 * screen/ViewModel/repository action actually needs: "can THIS role do THIS
 * specific action (view/create/edit/delete/approve/export) on THIS module,
 * right now". It's a single in-memory source of truth that both UI (to
 * hide/disable buttons) and the Repository layer (to actually block the
 * write even if a bad client bypasses the UI) call into.
 *
 * Source of truth precedence: a Firestore-synced RoleDefinition for a role
 * (pushed into Room, loaded via updateFromSynced) always overrides the
 * compiled-in DEFAULT_ROLE_DEFINITIONS below for that role. Roles with no
 * synced definition yet (fresh install, or a brand-new custom role nobody
 * has configured) fall back to the compiled default so the app is never
 * left with zero permissions before an admin has configured anything.
 */
enum class PermissionAction { VIEW, CREATE, EDIT, DELETE, APPROVE, EXPORT }

object PermissionManager {

    /**
     * Compiled-in fallback matrix — mirrors the business rules the person
     * described: SR can view+create Invoice but not approve/delete it; ASM
     * can approve; GM/MD/CHAIRMAN/AGM get full access everywhere. This is
     * the safety net, not the final word — an admin can override any of
     * this per-role via the synced RoleDefinition once that UI exists.
     */
    private val DEFAULT_ROLE_DEFINITIONS: Map<String, RoleDefinition> = buildMap {
        val fullAccessModules = MODULES.map { it.key }
        val fullAccessRoles = listOf(UserRole.GM, UserRole.MD, UserRole.CHAIRMAN, UserRole.AGM)
        fullAccessRoles.forEach { role ->
            put(role.name, RoleDefinition(
                roleKey = role.name,
                label = role.name,
                modulePermissions = fullAccessModules.map { key ->
                    ModulePermission(key, canView = true, canCreate = true, canEdit = true, canApprove = true, canDelete = true, canExport = true)
                },
            ))
        }

        // Sales/field tiers: everyone in ROLE_MODULES' base set can view+create
        // on the modules they're allowed to open; only ASM and above can
        // approve; only TSM and above can edit; delete is reserved for RSM+.
        UserRole.values().filter { it !in fullAccessRoles }.forEach { role ->
            val allowedModules = ROLE_MODULES[role].orEmpty()
            val canEdit = role.ordinal >= UserRole.TSM.ordinal
            val canApprove = role.ordinal >= UserRole.ASM.ordinal
            val canDelete = role.ordinal >= UserRole.RSM.ordinal
            val canExport = role.ordinal >= UserRole.NSM.ordinal
            put(role.name, RoleDefinition(
                roleKey = role.name,
                label = role.name,
                modulePermissions = allowedModules.map { key ->
                    ModulePermission(key, canView = true, canCreate = true, canEdit = canEdit, canApprove = canApprove, canDelete = canDelete, canExport = canExport)
                },
            ))
        }
    }

    private val _synced = MutableStateFlow<Map<String, RoleDefinition>>(emptyMap())
    val synced: StateFlow<Map<String, RoleDefinition>> = _synced.asStateFlow()

    /** Called by MockRepository whenever the Room-cached (Firestore-synced) role_definitions table changes. */
    fun updateFromSynced(definitions: List<RoleDefinition>) {
        _synced.value = definitions.associateBy { it.roleKey }
    }

    private fun definitionFor(roleKey: String): RoleDefinition? =
        _synced.value[roleKey] ?: DEFAULT_ROLE_DEFINITIONS[roleKey]

    /** The actual enforcement check — every gated action in the app calls this, directly or through canCurrentUser(). */
    fun can(roleKey: String, moduleKey: String, action: PermissionAction): Boolean {
        val perm = definitionFor(roleKey)?.modulePermissions?.firstOrNull { it.moduleKey == moduleKey } ?: return false
        return when (action) {
            PermissionAction.VIEW -> perm.canView
            PermissionAction.CREATE -> perm.canCreate
            PermissionAction.EDIT -> perm.canEdit
            PermissionAction.DELETE -> perm.canDelete
            PermissionAction.APPROVE -> perm.canApprove
            PermissionAction.EXPORT -> perm.canExport
        }
    }

    fun can(role: UserRole, moduleKey: String, action: PermissionAction): Boolean = can(role.name, moduleKey, action)

    /** Convenience for UI/ViewModel call sites — checks the currently signed-in user, resolving employee-specific overrides first, then their assigned Template, then their raw role default. */
    fun canCurrentUser(moduleKey: String, action: PermissionAction): Boolean {
        val employeeId = MockRepository.currentUser.employeeId
        val override = _employeeOverrides.value.firstOrNull { it.employeeId == employeeId && it.moduleKey == moduleKey }
        if (override != null) return override.accessLevel.toModulePermission(moduleKey).satisfies(action)
        val profile = MockRepository.employeeProfiles.value.firstOrNull { it.id == employeeId }
        val templateKey = profile?.assignedTemplateKey
        if (templateKey != null && (_synced.value.containsKey(templateKey))) return can(templateKey, moduleKey, action)
        return can(MockRepository.currentUser.role, moduleKey, action)
    }

    private fun ModulePermission.satisfies(action: PermissionAction): Boolean = when (action) {
        PermissionAction.VIEW -> canView
        PermissionAction.CREATE -> canCreate
        PermissionAction.EDIT -> canEdit
        PermissionAction.DELETE -> canDelete
        PermissionAction.APPROVE -> canApprove
        PermissionAction.EXPORT -> canExport
    }

    private val _employeeOverrides = MutableStateFlow<List<EmployeePermissionOverride>>(emptyList())
    /** Called by MockRepository whenever the Room-cached employee_permission_overrides table changes. */
    fun updateFromSyncedOverrides(overrides: List<EmployeePermissionOverride>) { _employeeOverrides.value = overrides }

    /** Chairman-only — Permission Control Center. Every action here requires the CALLER to be Chairman; "no one is above the Chairman" also means only the Chairman can grant this level of control, not delegate it via a permission flag (which could be self-granted). */
    private fun requireChairman(): Boolean = MockRepository.currentUser.role == UserRole.CHAIRMAN

    fun createTemplate(templateKey: String, label: String, baseModulePermissions: List<ModulePermission>): Boolean {
        if (!requireChairman()) return false
        if (_synced.value.containsKey(templateKey) || UserRole.values().any { it.name == templateKey }) return false // never shadow a real role or an existing template
        val def = RoleDefinition(roleKey = templateKey, label = label, modulePermissions = baseModulePermissions)
        MockRepository.savePermissionTemplate(def)
        return true
    }

    fun duplicateTemplate(sourceKey: String, newTemplateKey: String, newLabel: String): Boolean {
        if (!requireChairman()) return false
        val source = definitionFor(sourceKey) ?: return false
        if (_synced.value.containsKey(newTemplateKey) || UserRole.values().any { it.name == newTemplateKey }) return false
        MockRepository.savePermissionTemplate(source.copy(roleKey = newTemplateKey, label = newLabel))
        return true
    }

    fun updateTemplate(templateKey: String, modulePermissions: List<ModulePermission>): Boolean {
        if (!requireChairman()) return false
        val existing = _synced.value[templateKey] ?: return false
        MockRepository.savePermissionTemplate(existing.copy(modulePermissions = modulePermissions))
        return true
    }

    /** Built-in role definitions (the 10 real UserRole keys) are never deletable — only Chairman-created custom templates are. */
    fun deleteTemplate(templateKey: String): Boolean {
        if (!requireChairman()) return false
        if (UserRole.values().any { it.name == templateKey }) return false
        if (MockRepository.employeeProfiles.value.any { it.assignedTemplateKey == templateKey }) return false // must unassign from every employee first
        MockRepository.deletePermissionTemplate(templateKey)
        return true
    }

    fun assignTemplateToEmployees(templateKey: String, employeeIds: List<String>): Boolean {
        if (!requireChairman()) return false
        if (templateKey.isNotBlank() && !_synced.value.containsKey(templateKey) && UserRole.values().none { it.name == templateKey }) return false
        employeeIds.forEach { MockRepository.assignPermissionTemplate(it, templateKey.ifBlank { null }) }
        return true
    }

    fun setEmployeeOverride(employeeId: String, moduleKey: String, accessLevel: AccessLevel): Boolean {
        if (!requireChairman()) return false
        MockRepository.setEmployeePermissionOverride(employeeId, moduleKey, accessLevel)
        return true
    }

    fun clearEmployeeOverride(employeeId: String, moduleKey: String): Boolean {
        if (!requireChairman()) return false
        MockRepository.clearEmployeePermissionOverride(employeeId, moduleKey)
        return true
    }

    /** All templates — built-in role defaults plus Chairman-created custom ones — for the Permission Control Center's template list. */
    fun allTemplates(): List<RoleDefinition> = (DEFAULT_ROLE_DEFINITIONS.values + _synced.value.values).distinctBy { it.roleKey }

    /** Every role this matrix currently knows about — built-in + any custom roles an admin has added via Firestore. */
    fun allRoleKeys(): Set<String> = DEFAULT_ROLE_DEFINITIONS.keys + _synced.value.keys

    /** Used once by MockRepository's first-run seeding to write the compiled defaults into Room/Firestore so they become editable, inspectable data instead of only living in this file. */
    fun defaultDefinitionsForSeeding(): List<RoleDefinition> = DEFAULT_ROLE_DEFINITIONS.values.toList()
}
