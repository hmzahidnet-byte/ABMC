package com.abm.erp.config

/**
 * Section 2 fix — centralized debug logging. This project's ~318
 * `android.util.Log.w(...)` diagnostic calls (rejection reasons, sync
 * failures) have now been routed through this wrapper.
 */
object AppLog {
    fun d(tag: String, message: String) {
        if (AppEnvironment.debugLoggingEnabled) android.util.Log.d(tag, message)
    }

    /** Warnings (rejections, sync failures) always log — they matter in production support/audit, not just debug. */
    fun w(tag: String, message: String, throwable: Throwable? = null) {
        if (throwable != null) android.util.Log.w(tag, message, throwable) else android.util.Log.w(tag, message)
    }
}
