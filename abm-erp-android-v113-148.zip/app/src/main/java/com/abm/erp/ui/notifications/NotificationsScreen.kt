package com.abm.erp.ui.notifications

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.data.ApprovalStatus
import com.abm.erp.data.EMPLOYEE_DIRECTORY
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.LeaveStatus
import com.abm.erp.data.MockRepository
import com.abm.erp.data.UserRole
import com.abm.erp.data.findCoveringEmployee
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import java.time.LocalDateTime

class NotificationsViewModel : ViewModel() {
    val currentUserFlow = MockRepository.currentUserFlow
    val vacantEmployeeIds = MockRepository.vacantEmployeeIds
    val stockLevels = InventoryRepository.stockLevels
    val complaints = FirebaseSync.complaints
    val approvals = MockRepository.approvals
    val leaveRequests = MockRepository.leaveRequests
    val partyCollections = MockRepository.partyCollections
    val dealers = MockRepository.dealers
    val retailers = MockRepository.retailers
    val notifications = MockRepository.notifications
    fun markRead(id: String) = MockRepository.markNotificationRead(id)
}

/**
 * A single inbox pulling from every source that generates an alert, rather
 * than one screen per source — matches the JSX design's Notifications
 * concept. Low-stock reaches everyone (even SR, who doesn't manage dealers
 * directly, still benefits from knowing); vacancy-coverage duties and open
 * complaints are scoped to what's actually relevant to the viewer.
 */
@Composable
fun NotificationsScreen(onNavigate: (String) -> Unit = {}, vm: NotificationsViewModel = viewModel()) {
    val appUser by vm.currentUserFlow.collectAsState()
    val vacantIds by vm.vacantEmployeeIds.collectAsState()
    val stockLevels by vm.stockLevels.collectAsState()
    val complaints by vm.complaints.collectAsState()

    val employee = remember(appUser.employeeId) {
        EMPLOYEE_DIRECTORY.firstOrNull { it.id == appUser.employeeId } ?: EMPLOYEE_DIRECTORY.first { it.role == UserRole.CHAIRMAN }
    }
    val coveredEmployees = remember(employee.id, vacantIds) {
        EMPLOYEE_DIRECTORY.filter { vacantIds.contains(it.id) && findCoveringEmployee(it, vacantIds)?.id == employee.id }
    }
    val lowStock = stockLevels.filter { it.isLowStock }
    val openComplaints = if (appUser.role == UserRole.CHAIRMAN) complaints.filter { !it.resolved } else emptyList()
    val approvals by vm.approvals.collectAsState()
    val myPendingApprovals = approvals.filter { it.status == ApprovalStatus.PENDING }
    val leaveRequests by vm.leaveRequests.collectAsState()
    val pendingLeaves = leaveRequests.filter { it.status == LeaveStatus.PENDING }
    val partyCollections by vm.partyCollections.collectAsState()
    val dueCollections = partyCollections.filter { it.status == "PENDING" }
    val dealers by vm.dealers.collectAsState()
    val retailers by vm.retailers.collectAsState()
    val dayAgo = LocalDateTime.now().minusHours(24)
    val newDealers = dealers.filter { it.createdAt.isAfter(dayAgo) }
    val newRetailers = retailers.filter { it.createdAt.isAfter(dayAgo) }
    val persistedNotifications by vm.notifications.collectAsState()
    val prefContext = androidx.compose.ui.platform.LocalContext.current
    var mutedCategories by remember { mutableStateOf(com.abm.erp.data.getMutedNotificationCategories(prefContext)) }
    var showPreferences by remember { mutableStateOf(false) }
    val visibleNotifications = persistedNotifications.filter { it.category.name !in mutedCategories }

    val unreadCountTop = persistedNotifications.count { !it.isRead }
    val criticalCount = persistedNotifications.count { !it.isRead && it.category.name.contains("ALERT", ignoreCase = true) }
    Column(Modifier.fillMaxSize()) {
        com.abm.erp.core.ModuleWorkspaceHeader("Notifications", "🔔", 0xFFFFB020, 0xFFE08A00, iconVector = Icons.Filled.Notifications, miniDashboard = {
            com.abm.erp.core.ModuleStat("Unread", "$unreadCountTop", if (unreadCountTop > 0) WarningAmber else SuccessGreen)
            com.abm.erp.core.ModuleStat("Total", "${persistedNotifications.size}", TextPrimary)
            com.abm.erp.core.ModuleStat("Visible", "${visibleNotifications.size}", TextPrimary)
            com.abm.erp.core.ModuleStat("Muted", "${mutedCategories.size}", TextSecondary)
        }, quickActions = {
            AssistChip(onClick = { showPreferences = true }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.Settings, null, Modifier.size(16.dp)) }, label = { Text("Preferences") })
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("NotificationEntry", "Notification"))
        })
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            val unreadCount = persistedNotifications.count { !it.isRead }
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "Title,Body,Category,Read\n"
                    val rows = persistedNotifications.joinToString("\n") { n -> com.abm.erp.core.toCsvRow(n.title, n.body, n.category, n.isRead) }
                    val file = java.io.File(context.getExternalFilesDir(null), "notifications_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Notifications (${persistedNotifications.size})\n" + persistedNotifications.take(20).joinToString("\n") { "${it.title}: ${it.body}" }
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                    try { context.startActivity(android.content.Intent.createChooser(intent, "Notifications")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                },
            )
        }
        if (persistedNotifications.any { !it.isRead }) {
            Spacer(Modifier.height(6.dp))
            TextButton(onClick = { MockRepository.markAllNotificationsRead() }, modifier = Modifier.fillMaxWidth()) { Text("Mark All Read") }
        }
        TextButton(onClick = { showPreferences = true }, modifier = Modifier.fillMaxWidth()) { Text("⚙ Notification Preferences") }
        if (showPreferences) {
            androidx.compose.ui.window.Dialog(onDismissRequest = { showPreferences = false }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp).heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
                        Text("Mute Categories", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        com.abm.erp.data.NotificationCategory.values().forEach { cat ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Text(cat.name, style = MaterialTheme.typography.bodySmall)
                                Switch(
                                    checked = cat.name !in mutedCategories,
                                    onCheckedChange = { enabled ->
                                        mutedCategories = if (enabled) mutedCategories - cat.name else mutedCategories + cat.name
                                        com.abm.erp.data.saveMutedNotificationCategories(prefContext, mutedCategories)
                                    },
                                )
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        TextButton(onClick = { showPreferences = false }) { Text("Close") }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        if (persistedNotifications.isNotEmpty()) {
            Text("Recent Activity", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            visibleNotifications.take(10).forEach { n ->
                val targetRoute = when (n.category) {
                    // Decision 2 (v113-72) — the central "approvals" route is gone. APPROVAL
                    // is a catch-all category here (hiring, security, stock, HR events…) and
                    // NotificationEntry carries no entityType/entityId, so there is no honest
                    // way to pick an owning module from a notification alone. Dashboard is the
                    // deliberate fallback. Precise routing needs an entity link on the
                    // notification record — a schema change, so not done unasked.
                    com.abm.erp.data.NotificationCategory.APPROVAL -> "dashboard"
                    com.abm.erp.data.NotificationCategory.COLLECTION, com.abm.erp.data.NotificationCategory.PAYMENT -> "ledger"
                    com.abm.erp.data.NotificationCategory.SALES_ORDER, com.abm.erp.data.NotificationCategory.INVOICE -> "sales"
                    com.abm.erp.data.NotificationCategory.DELIVERY -> "courier"
                    com.abm.erp.data.NotificationCategory.PRODUCTION, com.abm.erp.data.NotificationCategory.QUALITY_CHECK -> "production"
                    com.abm.erp.data.NotificationCategory.LOW_STOCK, com.abm.erp.data.NotificationCategory.STOCK_TRANSFER -> "inventory"
                    com.abm.erp.data.NotificationCategory.ATTENDANCE, com.abm.erp.data.NotificationCategory.LEAVE -> "hrm"
                    com.abm.erp.data.NotificationCategory.COMPLAINT -> "complaint"
                    com.abm.erp.data.NotificationCategory.DEALER_REGISTRATION, com.abm.erp.data.NotificationCategory.RETAILER_REGISTRATION -> "dealers"
                    com.abm.erp.data.NotificationCategory.PURCHASE_ORDER, com.abm.erp.data.NotificationCategory.GOODS_RECEIPT -> "purchase"
                    com.abm.erp.data.NotificationCategory.HELPDESK -> "helpdesk"
                    com.abm.erp.data.NotificationCategory.TASK -> "tasks"
                    com.abm.erp.data.NotificationCategory.ALERT -> "dashboard"
                }
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).clickable { vm.markRead(n.id); onNavigate(targetRoute) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(n.title, fontWeight = FontWeight.SemiBold, color = if (n.isRead) TextSecondary else TextPrimary)
                            Text(n.body, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        if (!n.isRead) {
                            TextButton(onClick = { vm.markRead(n.id) }) { Text("Mark read") }
                        }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Notification", entityId = n.id, entityLabel = n.title,
                            shareText = "${n.title}\n${n.body}\n${n.category}",
                            csvHeader = "Title,Body,Category,Read", csvRow = com.abm.erp.core.toCsvRow(n.title, n.body, n.category, n.isRead),
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        if (coveredEmployees.isEmpty() && lowStock.isEmpty() && openComplaints.isEmpty() && myPendingApprovals.isEmpty() &&
            pendingLeaves.isEmpty() && dueCollections.isEmpty() && newDealers.isEmpty() && newRetailers.isEmpty()
        ) {
            Text("You're all caught up — nothing needs attention right now.", color = TextSecondary)
        }

        if (myPendingApprovals.isNotEmpty()) {
            Text("Approval alerts (${myPendingApprovals.size})", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            myPendingApprovals.forEach { a ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text("${a.type} — ${a.fromEmployee}", color = WarningAmber, fontWeight = FontWeight.SemiBold)
                    Text(a.detail, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }

        if (pendingLeaves.isNotEmpty()) {
            Text("Leave alerts (${pendingLeaves.size})", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            pendingLeaves.forEach { l ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text("${l.employeeName} — ${l.type}", color = WarningAmber, fontWeight = FontWeight.SemiBold)
                    Text("${l.fromDate} → ${l.toDate}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }

        if (dueCollections.isNotEmpty()) {
            Text("Collection due (${dueCollections.size})", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            dueCollections.forEach { c ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text("${c.partyName} — ৳${"%,.0f".format(c.amount)}", color = WarningAmber, fontWeight = FontWeight.SemiBold)
                    Text("Awaiting verification · ${c.method}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }

        if (newDealers.isNotEmpty() || newRetailers.isNotEmpty()) {
            Text("New registrations (24h)", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            newDealers.forEach { d ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text("New Dealer: ${d.name}", color = SuccessGreen, fontWeight = FontWeight.SemiBold)
                    Text(d.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
            newRetailers.forEach { r ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text("New Outlet: ${r.name}", color = SuccessGreen, fontWeight = FontWeight.SemiBold)
                    Text(r.outletCategory, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }

        coveredEmployees.forEach { vacant ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                Text("⚠ Covering: ${vacant.name} (${vacant.role}, ${vacant.geoLabel})", color = WarningAmber, fontWeight = FontWeight.SemiBold)
                Text("This position is currently vacant — their duties route to you.", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
        }

        if (lowStock.isNotEmpty()) {
            Text("Stock alerts", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            lowStock.forEach { level ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text("${level.productName} low at ${level.warehouseName}", color = DangerRed, fontWeight = FontWeight.SemiBold)
                    Text("${"%.1f".format(level.quantityOnHand)} ${level.unit} left (reorder level: ${"%.0f".format(level.reorderThreshold)})", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }

        if (openComplaints.isNotEmpty()) {
            Text("Open complaints", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            openComplaints.forEach { c ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text(c.subject, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                    Text(if (c.anonymous) "Anonymous · ${c.fromRole}" else "${c.fromName} · ${c.fromRole}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }
    }
    }
}
