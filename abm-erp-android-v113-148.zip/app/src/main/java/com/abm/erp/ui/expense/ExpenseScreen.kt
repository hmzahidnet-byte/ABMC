package com.abm.erp.ui.expense

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.abm.erp.core.UniversalActionMenu
import com.abm.erp.data.*
import com.abm.erp.theme.*

@Composable
fun ExpenseScreen() {
    val expenses by MockRepository.expenses.collectAsState()
    val currentUser = MockRepository.currentUser
    val context = androidx.compose.ui.platform.LocalContext.current
    var showNew by remember { mutableStateOf(false) }
    val canApprove = PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)

    Column(Modifier.fillMaxSize()) {
        val today = java.time.LocalDate.now()
        val todayExpense = expenses.filter { it.createdAt.toLocalDate() == today }.sumOf { it.amount }
        val pendingCount = expenses.count { it.status == ExpenseStatus.PENDING }
        val approvedTotal = expenses.filter { it.status == ExpenseStatus.APPROVED }.sumOf { it.amount }
        val rejectedCount = expenses.count { it.status == ExpenseStatus.REJECTED }
        com.abm.erp.core.ModuleWorkspaceHeader("Expenses", "💸", 0xFFE85D4A, 0xFFC03A2B, iconVector = Icons.Filled.Payments, miniDashboard = {
            com.abm.erp.core.ModuleStat("Today", "৳${"%,.0f".format(todayExpense)}", TextPrimary)
            com.abm.erp.core.ModuleStat("Pending", "$pendingCount", if (pendingCount > 0) WarningAmber else SuccessGreen)
            com.abm.erp.core.ModuleStat("Approved", "৳${"%,.0f".format(approvedTotal)}", SuccessGreen)
            com.abm.erp.core.ModuleStat("Rejected", "$rejectedCount", if (rejectedCount > 0) DangerRed else SuccessGreen)
        }, quickActions = {
            AssistChip(onClick = { showNew = true }, label = { Text("+ New Expense") })
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("Expense"))
        })
        Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Button(onClick = { showNew = true }) { Text("+ New Expense") }
        }
        Spacer(Modifier.height(10.dp))
        // Decision 2 (v113-72) — expense approvals live inside FMS/Expenses, not in a
        // central inbox. The per-row Approve/Reject in UniversalActionMenu below acts on
        // the Expense record itself; this section actions the ApprovalRequest raised for it.
        com.abm.erp.core.ModuleApprovalSection(
            title = "Expense অনুমোদনের অপেক্ষায়",
            entityTypes = setOf("Expense"),
        )
        if (expenses.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("কোনো expense নেই।", color = TextSecondary) }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(expenses) { exp ->
                    Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Column {
                                    Text("${exp.expenseNo} — ${exp.category}", style = MaterialTheme.typography.titleSmall)
                                    Text("৳${"%,.0f".format(exp.amount)} · ${exp.paymentMethod} · ${exp.submittedBy}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                    if (exp.description.isNotBlank()) Text(exp.description, style = MaterialTheme.typography.bodySmall)
                                    Text(
                                        exp.status.name,
                                        color = when (exp.status) { ExpenseStatus.APPROVED -> SuccessGreen; ExpenseStatus.REJECTED -> DangerRed; ExpenseStatus.PENDING -> WarningAmber },
                                        style = MaterialTheme.typography.labelSmall,
                                    )
                                    exp.rejectReason?.let { Text("কারণ: $it", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                                }
                                UniversalActionMenu(
                                    moduleReference = "Expense",
                                    entityId = exp.id,
                                    entityLabel = "${exp.expenseNo} — ${exp.category}",
                                    shareText = "${exp.expenseNo}\n${exp.category}: ৳${"%,.0f".format(exp.amount)}\n${exp.description}\nStatus: ${exp.status}",
                                    csvHeader = "ExpenseNo,Category,Amount,Method,SubmittedBy,Status",
                                    csvRow = com.abm.erp.core.toCsvRow(exp.expenseNo, exp.category, exp.amount, exp.paymentMethod, exp.submittedBy, exp.status),
                                    canApprove = canApprove,
                                    onApprove = if (exp.status != ExpenseStatus.PENDING) null else { {
                                        if (!MockRepository.approveExpense(exp.id)) {
                                            android.widget.Toast.makeText(context, "Approve ব্যর্থ হয়েছে — অনুমতি নেই অথবা ইতিমধ্যে প্রসেস হয়ে গেছে।", android.widget.Toast.LENGTH_LONG).show()
                                        }
                                    } },
                                    onReject = if (exp.status != ExpenseStatus.PENDING) null else { reason ->
                                        if (!MockRepository.rejectExpense(exp.id, reason)) {
                                            android.widget.Toast.makeText(context, "Reject ব্যর্থ হয়েছে — অনুমতি নেই অথবা ইতিমধ্যে প্রসেস হয়ে গেছে।", android.widget.Toast.LENGTH_LONG).show()
                                        }
                                    },
                                )
                            }
                        }
                    }
                }
            }
        }
        }
    }

    if (showNew) {
        var category by remember { mutableStateOf("") }
        var amount by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var paymentMethod by remember { mutableStateOf(ExpensePaymentMethod.CASH) }
        Dialog(onDismissRequest = { showNew = false }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(modifier = Modifier.fillMaxSize(), color = com.abm.erp.theme.DashBg) {
                Column(Modifier.fillMaxSize()) {
                    com.abm.erp.core.ModuleGradientHeader("New Expense", "💸", 0xFFE85D4A, 0xFFC03A2B, iconVector = Icons.Filled.Payments)
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showNew = false }) { Text("✕ Close") }
                    }
                    Column(Modifier.fillMaxSize().padding(16.dp)) {
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = amount, onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Amount") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = paymentMethod == ExpensePaymentMethod.CASH, onClick = { paymentMethod = ExpensePaymentMethod.CASH }, label = { Text("Cash") })
                        FilterChip(selected = paymentMethod == ExpensePaymentMethod.BANK, onClick = { paymentMethod = ExpensePaymentMethod.BANK }, label = { Text("Bank") })
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val amt = amount.toDoubleOrNull()
                            if (amt != null && amt > 0 && category.isNotBlank()) {
                                MockRepository.submitExpense(category, amt, description, paymentMethod)
                                showNew = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Submit") }
                    }
                }
            }
        }
    }
}
