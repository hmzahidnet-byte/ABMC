package com.abm.erp.ui.dealer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.Space
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.*

/**
 * v113-75 — Retailer Stock, the RMS mirror of DealerStockScreen.
 *
 * One real difference from the dealer version, stated plainly rather than papered
 * over: `Dealer.stockUnits` is a trusted aggregate that predates product-wise
 * tracking, so DealerStockScreen can show "Total Units" and "Product Breakdown" as
 * two different views of the same underlying truth, with any gap between them
 * explained. **`Retailer` has no such field** — retailer stock did not exist at all
 * before this batch — so there is nothing to reconcile against. This screen shows
 * only the product breakdown, and says so, rather than inventing a total that would
 * look more complete than it is.
 */
@Composable
fun RetailerStockScreen(retailerId: String, onBack: () -> Unit) {
    val retailers by MockRepository.retailers.collectAsState()
    val retailer = retailers.firstOrNull { it.id == retailerId }
    val lines by remember(retailerId) { MockRepository.retailerStockLinesFor(retailerId) }
        .collectAsState(initial = emptyList())

    if (retailer == null) {
        Column(Modifier.fillMaxSize().padding(Space.xl), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(70.dp))
            com.abm.erp.core.WorkspaceEmptyState("এই retailer পাওয়া যায়নি।", iconVector = Icons.Filled.Store)
            Spacer(Modifier.height(Space.lg))
            com.abm.erp.core.SecondaryButton("← ফিরে যান", onClick = onBack)
        }
        return
    }

    Column(Modifier.fillMaxSize().background(DashBg)) {
        Column(
            Modifier.fillMaxWidth()
                .background(Brush.linearGradient(listOf(Color(0xFF0EA5A4), Color(0xFF0F766E))))
                .padding(horizontal = Space.md, vertical = 12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text("Retailer Stock", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(retailer.name, color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                }
            }
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(Space.md)) {
            // ── the honest "no total" disclosure, in place of a trusted aggregate ──
            com.abm.erp.core.PremiumCard(padding = Space.md) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Info, null, tint = StatusAmber, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(Space.sm))
                    Column {
                        Text(
                            "শুধু product breakdown — কোনো trusted total নেই",
                            fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            "Dealer stock-এর মতো আগে থেকে হিসাব করা সংখ্যা retailer-এর জন্য কখনো ছিল না। " +
                                "এই তালিকা memo fulfilled হওয়া আর damage/return থেকে আজ থেকে শুরু — dealer stock " +
                                "থেকে সম্পূর্ণ আলাদা, কোনো সম্পর্ক নেই।",
                            fontSize = 9.sp, color = TextSecondary,
                        )
                    }
                }
            }
            Spacer(Modifier.height(Space.md))

            com.abm.erp.core.SectionTitle("Product Breakdown (${lines.size})")
            if (lines.isEmpty()) {
                com.abm.erp.core.WorkspaceEmptyState(
                    "এখনো কোনো পণ্য-ভিত্তিক রেকর্ড নেই — নতুন memo fulfillment বা return থেকে যোগ হবে।",
                    iconVector = Icons.Filled.Inventory,
                )
            } else {
                val maxQty = lines.maxOf { it.qty }.coerceAtLeast(1)
                Column(verticalArrangement = Arrangement.spacedBy(Space.sm)) {
                    lines.sortedByDescending { it.qty }.forEach { line ->
                        com.abm.erp.core.PremiumCard(padding = Space.md) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(line.productName, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, maxLines = 1, modifier = Modifier.weight(1f))
                                Text(
                                    "${line.qty}",
                                    fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                    color = if (line.qty < 0) StatusRed else TextPrimary,
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Box(Modifier.fillMaxWidth().height(5.dp).background(HairlineBorder, RoundedCornerShape(999.dp))) {
                                Box(
                                    Modifier
                                        .fillMaxWidth((line.qty.toFloat() / maxQty).coerceIn(0f, 1f))
                                        .fillMaxHeight()
                                        .background(if (line.qty < 0) StatusRed else Color(0xFF0EA5A4), RoundedCornerShape(999.dp)),
                                )
                            }
                            if (line.qty < 0) {
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "নেতিবাচক সংখ্যা — সম্ভবত রিটার্ন এর তুলনায় কম আগমন রেকর্ড হয়েছে, যাচাই করুন।",
                                    fontSize = 9.sp, color = StatusRed,
                                )
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(Space.xxl))
        }
    }
}
