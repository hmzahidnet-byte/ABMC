package com.abm.erp.core

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import com.abm.erp.data.Dealer
import com.abm.erp.data.EmployeeProfile
import com.abm.erp.data.MockRepository
import com.abm.erp.data.Retailer

/**
 * Decision 4 (v113-73) — the single entry point every screen uses to read
 * dealers / retailers / employees.
 *
 * The bug this exists to close: `DealerInvoiceScreen` and `SalesChainScreen`'s
 * `DealerInvoiceTab` both read `MockRepository.dealers.collectAsState()` raw and
 * fed that straight into `DealerPickerDialog`, so an SR could pick — and invoice —
 * a dealer outside his own territory. The scoping rule existed and was correct;
 * it was simply not applied on those two screens.
 *
 * The fix is deliberately an *accessor*, not another inline filter: a screen that
 * calls `rememberVisibleDealers()` cannot forget the cascade, whereas a screen
 * that copy-pastes a filter can. New screens should never call
 * `MockRepository.dealers.collectAsState()` directly.
 *
 * `remember(...)` here is not cosmetic — these lists are read inside tabs that
 * recompose on every scroll, and re-running the hierarchy walk each frame would
 * blow the 8.3 ms (120fps) budget.
 */
@Composable
fun rememberVisibleDealers(): List<Dealer> {
    val all by MockRepository.dealers.collectAsState()
    val profiles by MockRepository.employeeProfiles.collectAsState()
    return remember(all, profiles) { MockRepository.visibleDealersFor(all, profiles) }
}

@Composable
fun rememberVisibleRetailers(): List<Retailer> {
    val all by MockRepository.retailers.collectAsState()
    val profiles by MockRepository.employeeProfiles.collectAsState()
    return remember(all, profiles) { MockRepository.visibleRetailersFor(all, profiles) }
}

@Composable
fun rememberVisibleEmployeeProfiles(): List<EmployeeProfile> {
    val profiles by MockRepository.employeeProfiles.collectAsState()
    return remember(profiles) { MockRepository.visibleEmployeeProfilesFor(profiles) }
}
