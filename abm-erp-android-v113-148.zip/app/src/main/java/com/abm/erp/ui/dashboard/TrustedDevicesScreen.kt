package com.abm.erp.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.data.EMPLOYEE_DIRECTORY
import com.abm.erp.data.FirebaseSync
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

/**
 * "Admin should be able to see who's logged in on which device and remotely
 * log them out" — Chairman-only. Backed by Firestore since the Chairman
 * needs to see devices trusted on OTHER people's phones from their own.
 */
@Composable
fun TrustedDevicesScreen(onClose: () -> Unit) {
    val trustedDeviceIds by FirebaseSync.trustedDeviceIds.collectAsState()

    Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Trusted Devices", style = MaterialTheme.typography.titleMedium)
            IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = "Close") }
        }
        Text(
            "Only the Chairman can see this. Removing a device forces that person to log in with their PIN again next time.",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(12.dp))

        val entries = trustedDeviceIds.entries.filter { it.value.isNotEmpty() }
        if (entries.isEmpty()) {
            Text("No devices trusted yet — this fills in as people log in with their PIN.", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        LazyColumn {
            items(entries.toList(), key = { it.key }) { (employeeId, devices) ->
                val emp = EMPLOYEE_DIRECTORY.firstOrNull { it.id == employeeId }
                Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(emp?.name ?: employeeId, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("${emp?.role?.name ?: ""} · ${emp?.geoLabel ?: ""}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Spacer(Modifier.height(6.dp))
                        devices.forEach { deviceId ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(deviceId, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                TextButton(onClick = { FirebaseSync.removeTrustedDevice(employeeId, deviceId) }) {
                                    Text("Remote logout", color = DangerRed, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
