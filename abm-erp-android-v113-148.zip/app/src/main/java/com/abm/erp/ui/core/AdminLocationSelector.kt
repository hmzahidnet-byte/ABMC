package com.abm.erp.ui.core

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.abm.erp.data.AdministrativeLocation
import com.abm.erp.data.MockRepository

/**
 * Bangladesh Offline Administrative Location Master — reusable cascading
 * selector: Division -> District -> Upazila -> Union. Fully offline (reads
 * MockRepository.administrativeLocations, seeded from bundled assets, no
 * network). Clears children when a parent changes; selection state lives
 * in the caller so it survives recomposition/rotation.
 */
data class AdminSelection(
    val divisionId: String? = null, val districtId: String? = null, val upazilaId: String? = null, val unionId: String? = null,
)

@Composable
fun AdminLocationCascadeSelector(selection: AdminSelection, onSelectionChange: (AdminSelection) -> Unit, modifier: Modifier = Modifier) {
    val allLocations by MockRepository.administrativeLocations.collectAsState()
    if (allLocations.isEmpty()) {
        Text("Location data লোড হচ্ছে... (প্রথমবার app চালু হলে seed হয়)", style = MaterialTheme.typography.labelSmall)
        return
    }
    val byId = remember(allLocations) { allLocations.associateBy { it.id } }
    val divisions = remember(allLocations) { allLocations.filter { it.type == "DIVISION" && it.active }.sortedBy { it.nameEn } }
    val districts = remember(allLocations, selection.divisionId) { if (selection.divisionId == null) emptyList() else allLocations.filter { it.type == "DISTRICT" && it.parentId == selection.divisionId && it.active }.sortedBy { it.nameEn } }
    val upazilas = remember(allLocations, selection.districtId) { if (selection.districtId == null) emptyList() else allLocations.filter { it.type == "UPAZILA" && it.parentId == selection.districtId && it.active }.sortedBy { it.nameEn } }
    val unions = remember(allLocations, selection.upazilaId) { if (selection.upazilaId == null) emptyList() else allLocations.filter { it.type == "UNION" && it.parentId == selection.upazilaId && it.active }.sortedBy { it.nameEn } }

    Column(modifier) {
        AdminPickerField("Division", byId[selection.divisionId]?.let { "${it.nameEn} / ${it.nameBn}" }, divisions) { picked ->
            onSelectionChange(AdminSelection(divisionId = picked.id)) // changing parent clears all children — Section 6 requirement
        }
        Spacer(Modifier.height(8.dp))
        AdminPickerField("District", byId[selection.districtId]?.let { "${it.nameEn} / ${it.nameBn}" }, districts, enabled = selection.divisionId != null) { picked ->
            onSelectionChange(selection.copy(districtId = picked.id, upazilaId = null, unionId = null))
        }
        Spacer(Modifier.height(8.dp))
        AdminPickerField("Upazila/Thana", byId[selection.upazilaId]?.let { "${it.nameEn} / ${it.nameBn}" }, upazilas, enabled = selection.districtId != null) { picked ->
            onSelectionChange(selection.copy(upazilaId = picked.id, unionId = null))
        }
        Spacer(Modifier.height(8.dp))
        AdminPickerField("Union", byId[selection.unionId]?.let { "${it.nameEn} / ${it.nameBn}" }, unions, enabled = selection.upazilaId != null) { picked ->
            onSelectionChange(selection.copy(unionId = picked.id))
        }
    }
}

@Composable
private fun AdminPickerField(label: String, currentLabel: String?, options: List<AdministrativeLocation>, enabled: Boolean = true, onPick: (AdministrativeLocation) -> Unit) {
    var showPicker by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    OutlinedButton(onClick = { if (enabled) showPicker = true }, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
        Text(currentLabel ?: ("$label নির্বাচন করুন" + if (!enabled) " (আগে উপরেরটা বাছুন)" else ""))
    }
    if (showPicker) {
        Dialog(onDismissRequest = { showPicker = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 480.dp)) {
                    Text("Select $label", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = searchQuery, onValueChange = { searchQuery = it }, placeholder = { Text("নাম দিয়ে খুঁজুন") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    val filtered = if (searchQuery.isBlank()) options else options.filter { it.nameEn.contains(searchQuery, ignoreCase = true) || it.nameBn.contains(searchQuery) }
                    if (filtered.isEmpty()) {
                        Text("কোনো ফলাফল নেই।", style = MaterialTheme.typography.bodySmall)
                    }
                    LazyColumn {
                        items(filtered) { loc ->
                            Text(
                                "${loc.nameEn} / ${loc.nameBn}", style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onPick(loc); showPicker = false; searchQuery = "" }.padding(vertical = 12.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}
