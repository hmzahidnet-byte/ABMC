package com.abm.erp.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.EnterpriseFormField
import com.abm.erp.core.EnterpriseListRow
import com.abm.erp.core.PremiumCard
import com.abm.erp.core.PrimaryButton
import com.abm.erp.core.SectionTitle
import com.abm.erp.core.Space
import com.abm.erp.data.MockRepository
import com.abm.erp.data.UserRole
import com.abm.erp.theme.*
import kotlinx.coroutines.launch

/**
 * Employee Setup — the Chairman's single page for putting a person into the system.
 *
 * Everything here already existed, but scattered: the employee draft lived in HR, the login
 * account behind a dialog inside HR, permissions in the Permission Center, territory somewhere
 * else again. Adding one person meant four screens. This is the same operations in one place.
 *
 * Two things it deliberately does **not** do:
 *  - It does not bypass any check. Account creation still goes through
 *    `createUserAccount()` with its weak-PIN rejection and force-change-on-first-login;
 *    PIN reset and enable/disable are Chairman-gated inside the repository, not here.
 *  - It does not set permissions directly. Role carries the permission tier, and per-module
 *    overrides remain in the Permission Center — duplicating that editor here would create
 *    two sources of truth for access, which is exactly the kind of thing that produces a
 *    security hole nobody notices.
 */
@Composable
fun EmployeeSetupScreen(onNavigate: (String) -> Unit = {}) {
    val currentUser = MockRepository.currentUser
    val isChairman = currentUser.role == UserRole.CHAIRMAN
    val profiles by MockRepository.employeeProfiles.collectAsState()
    val scope = rememberCoroutineScope()

    var query by remember { mutableStateOf("") }
    var showNew by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var revealedPin by remember { mutableStateOf<Pair<String, String>?>(null) } // name to pin

    if (!isChairman) {
        Column(Modifier.fillMaxSize().padding(Space.xl), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(60.dp))
            com.abm.erp.core.WorkspaceEmptyState(
                "কর্মী সেটআপ শুধু Chairman করতে পারেন।",
                iconVector = Icons.Filled.Lock,
            )
        }
        return
    }

    val visible = remember(profiles, query) {
        if (query.isBlank()) profiles
        else profiles.filter {
            it.fullName.contains(query, true) || it.designation.contains(query, true) ||
                it.employeeCode.contains(query, true)
        }
    }

    Column(Modifier.fillMaxSize().background(DashBg)) {

        Column(
            Modifier.fillMaxWidth()
                .background(Brush.linearGradient(listOf(ChairmanNavy, Color(0xFF16294D))))
                .padding(Space.lg),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(42.dp).background(ChairmanGold.copy(alpha = 0.18f), RoundedCornerShape(13.dp)),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.ManageAccounts, null, tint = ChairmanGold, modifier = Modifier.size(22.dp)) }
                Spacer(Modifier.width(Space.md))
                Column {
                    Text("Employee Setup", color = ChairmanGold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("কর্মী · পদবি · এলাকা · PIN — এক জায়গায়", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp)
                }
            }
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(Space.md)) {

            com.abm.erp.core.EnterpriseSearchBar(
                value = query, onValueChange = { query = it },
                placeholder = "নাম, পদবি বা কোড দিয়ে খুঁজুন…",
            )

            Spacer(Modifier.height(Space.md))
            PrimaryButton("+ নতুন কর্মী যোগ করুন", onClick = { showNew = true }, icon = Icons.Filled.PersonAdd)

            message?.let {
                Spacer(Modifier.height(Space.md))
                PremiumCard(padding = Space.md) {
                    Text(it, fontSize = 12.sp, color = if (it.startsWith("✓")) StatusGreen else StatusRed)
                }
            }

            // A reset PIN is shown once, here, and never persisted in readable form.
            revealedPin?.let { (name, pin) ->
                Spacer(Modifier.height(Space.md))
                PremiumCard(padding = Space.lg) {
                    Text("অস্থায়ী PIN — $name", fontSize = 11.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(pin, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = DarazOrange, letterSpacing = 6.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "এখনই কর্মীকে জানিয়ে দিন। এটি আর দেখানো যাবে না, এবং প্রথম লগইনেই তাকে বদলাতে হবে।",
                        fontSize = 10.sp, color = TextSecondary,
                    )
                    Spacer(Modifier.height(Space.sm))
                    com.abm.erp.core.SecondaryButton("বুঝেছি, বন্ধ করুন", onClick = { revealedPin = null })
                }
            }

            SectionTitle("কর্মী তালিকা (${visible.size})")

            if (visible.isEmpty()) {
                com.abm.erp.core.WorkspaceEmptyState("কোনো কর্মী পাওয়া যায়নি।", iconVector = Icons.Filled.Groups)
            }

            Column(verticalArrangement = Arrangement.spacedBy(Space.sm)) {
                visible.forEach { emp ->
                    var busy by remember(emp.id) { mutableStateOf(false) }
                    PremiumCard(padding = Space.md) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            com.abm.erp.core.IconChip(Icons.Filled.Person, DarazOrange, size = 38)
                            Spacer(Modifier.width(Space.md))
                            Column(Modifier.weight(1f)) {
                                Text(emp.fullName, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                Text(
                                    listOfNotNull(
                                        emp.employeeCode.ifBlank { null },
                                        emp.designation.ifBlank { null },
                                        emp.role.name,
                                    ).joinToString(" · "),
                                    fontSize = 10.sp, color = TextSecondary,
                                )
                            }
                            com.abm.erp.core.StatusPill(emp.status.name)
                        }
                        Spacer(Modifier.height(Space.sm))
                        Row(horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
                            TextButton(
                                enabled = !busy,
                                onClick = {
                                    busy = true; message = null
                                    scope.launch {
                                        val r = MockRepository.chairmanResetEmployeePin(emp.id)
                                        busy = false
                                        if (r.success) {
                                            // `message` on success carries the new PIN by design of
                                            // AccountCreationResult; surface it in the reveal card, not a toast.
                                            revealedPin = emp.fullName to r.message
                                        } else {
                                            message = "✗ ${r.message}"
                                        }
                                    }
                                },
                            ) {
                                Icon(Icons.Filled.LockReset, null, Modifier.size(15.dp), tint = DarazOrange)
                                Spacer(Modifier.width(4.dp))
                                Text("PIN Reset", fontSize = 11.sp, color = DarazOrange)
                            }
                            TextButton(
                                enabled = !busy,
                                onClick = {
                                    busy = true; message = null
                                    scope.launch {
                                        val ok = MockRepository.setAccountActive(emp.id, false)
                                        busy = false
                                        message = if (ok) "✓ ${emp.fullName} — লগইন বন্ধ করা হয়েছে।"
                                        else "✗ পরিবর্তন করা যায়নি — এই কর্মীর কোনো account নেই।"
                                    }
                                },
                            ) {
                                Icon(Icons.Filled.Block, null, Modifier.size(15.dp), tint = StatusRed)
                                Spacer(Modifier.width(4.dp))
                                Text("Disable", fontSize = 11.sp, color = StatusRed)
                            }
                            TextButton(
                                enabled = !busy,
                                onClick = {
                                    busy = true; message = null
                                    scope.launch {
                                        val ok = MockRepository.setAccountActive(emp.id, true)
                                        busy = false
                                        message = if (ok) "✓ ${emp.fullName} — লগইন চালু করা হয়েছে।"
                                        else "✗ পরিবর্তন করা যায়নি — এই কর্মীর কোনো account নেই।"
                                    }
                                },
                            ) {
                                Icon(Icons.Filled.CheckCircle, null, Modifier.size(15.dp), tint = StatusGreen)
                                Spacer(Modifier.width(4.dp))
                                Text("Enable", fontSize = 11.sp, color = StatusGreen)
                            }
                        }
                        // Office / Factory. This decides which module's HR screens the person
                        // appears in — HRM for office staff, MES's factory workforce for factory
                        // staff — so it is set explicitly rather than guessed from `department`.
                        Spacer(Modifier.height(Space.sm))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("কর্মস্থল:", fontSize = 11.sp, color = TextSecondary)
                            Spacer(Modifier.width(Space.sm))
                            com.abm.erp.data.EmployeeType.values().forEach { t ->
                                FilterChip(
                                    selected = emp.employeeType == t,
                                    onClick = {
                                        scope.launch {
                                            val ok = MockRepository.setEmployeeType(emp.id, t)
                                            message = if (ok) "✓ ${emp.fullName} — ${t.name}"
                                            else "✗ শুধু Chairman এটি বদলাতে পারেন।"
                                        }
                                    },
                                    label = { Text(if (t == com.abm.erp.data.EmployeeType.OFFICE) "Office" else "Factory", fontSize = 10.sp) },
                                    modifier = Modifier.padding(end = 6.dp),
                                )
                            }
                        }
                    }
                }
            }

            SectionTitle("Access")
            EnterpriseListRow(
                title = "Approval Authority Limits",
                subtitle = "ছাড়ের সীমা · আর্থিক অনুমোদন · ক্রেডিট override",
                meta = "কে কত % ছাড় দিতে পারবে — এর বেশি হলে অনুমোদন লাগবে",
                icon = Icons.Filled.Gavel,
                accent = ChairmanNavy,
                onClick = { onNavigate("hrm?tab=5") },
            )
            Spacer(Modifier.height(Space.sm))
            EnterpriseListRow(
                title = "Permission Center",
                subtitle = "প্রতি module-এ View / Create / Edit / Approve টগল",
                meta = "পদবি অনুযায়ী ডিফল্ট থাকে — ব্যতিক্রম হলে এখানে বদলান",
                icon = Icons.Filled.VpnKey,
                accent = ChairmanNavy,
                onClick = { onNavigate("permission_center") },
            )

            Spacer(Modifier.height(Space.xxl))
        }
    }

    if (showNew) {
        NewEmployeeDialog(
            onDismiss = { showNew = false },
            onResult = { msg -> message = msg; showNew = false },
        )
    }
}

/**
 * New-employee dialog. Creates the employee draft through the existing
 * `createEmployeeDraft()` path, so the approval workflow that normally governs a new
 * hire still applies — this screen is a faster way in, not a way around it.
 */
@Composable
private fun NewEmployeeDialog(onDismiss: () -> Unit, onResult: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var designation by remember { mutableStateOf("") }
    var role by remember { mutableStateOf(UserRole.SR) }
    var roleOpen by remember { mutableStateOf(false) }
    var territory by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = DashBg) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth()
                        .background(Brush.linearGradient(listOf(ChairmanNavy, Color(0xFF16294D))))
                        .padding(Space.lg),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("নতুন কর্মী", color = ChairmanGold, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = onDismiss) { Text("✕ বন্ধ", color = Color.White) }
                }

                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(Space.lg)) {
                    SectionTitle("১ · পরিচয়")
                    EnterpriseFormField("পুরো নাম", name, { name = it }, placeholder = "যেমন: রাকিব হাসান")
                    Spacer(Modifier.height(Space.md))
                    EnterpriseFormField("মোবাইল নম্বর", mobile, { mobile = it.filter(Char::isDigit).take(11) }, placeholder = "01XXXXXXXXX", keyboardType = KeyboardType.Phone)

                    SectionTitle("২ · পদবি")
                    EnterpriseFormField("পদবি (লেখা)", designation, { designation = it }, placeholder = "যেমন: Sales Officer")
                    Spacer(Modifier.height(Space.md))
                    Text("Role — এটাই অনুমতির স্তর ঠিক করে", fontSize = 11.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Box {
                        com.abm.erp.core.SecondaryButton(role.name, onClick = { roleOpen = true })
                        DropdownMenu(expanded = roleOpen, onDismissRequest = { roleOpen = false }) {
                            UserRole.values().forEach { r ->
                                DropdownMenuItem(text = { Text(r.name) }, onClick = { role = r; roleOpen = false })
                            }
                        }
                    }

                    SectionTitle("৩ · এলাকা")
                    EnterpriseFormField("Territory / এলাকা", territory, { territory = it }, placeholder = "যেমন: Barishal · Nathullabad", optional = true)

                    error?.let {
                        Spacer(Modifier.height(Space.md))
                        Text(it, color = StatusRed, fontSize = 11.sp)
                    }

                    Spacer(Modifier.height(Space.lg))
                    Text(
                        "সংরক্ষণের পর কর্মী তালিকায় আসবে। এরপর সেখান থেকে লগইন account ও PIN দিতে পারবেন — " +
                            "PIN কখনো সরাসরি সংরক্ষণ হয় না, hash আকারে থাকে, আর প্রথম লগইনেই কর্মীকে বদলাতে হয়।",
                        fontSize = 10.sp, color = TextSecondary,
                    )
                    Spacer(Modifier.height(Space.xxl))
                }

                Box(Modifier.background(Color.White).padding(Space.md)) {
                    PrimaryButton(
                        text = if (busy) "সংরক্ষণ হচ্ছে…" else "সংরক্ষণ করুন",
                        loading = busy,
                        enabled = name.isNotBlank() && mobile.length >= 11,
                        onClick = {
                            busy = true; error = null
                            scope.launch {
                                // v113-99 — runCatching was the bug here: createEmployeeDraft
                                // REJECTS by returning null, it never throws — so runCatching's
                                // onSuccess fired even when creation failed, showing "✓ added"
                                // for an employee that was never actually saved. Checking the
                                // real return value now, and reporting the real reason.
                                var rejectReason: String? = null
                                val created = MockRepository.createEmployeeDraft(
                                    fullName = name.trim(),
                                    mobile = mobile.trim(),
                                    email = "",
                                    department = designation.trim(),
                                    designation = designation.trim(),
                                    role = role,
                                    companyId = MockRepository.currentUser.companyId,
                                    territoryId = territory.trim().ifBlank { null },
                                    onRejected = { reason -> rejectReason = reason },
                                )
                                busy = false
                                if (created != null) onResult("✓ ${name.trim()} যোগ করা হয়েছে।")
                                else error = rejectReason ?: "সংরক্ষণ করা যায়নি — আবার চেষ্টা করুন।"
                            }
                        },
                    )
                }
            }
        }
    }
}
