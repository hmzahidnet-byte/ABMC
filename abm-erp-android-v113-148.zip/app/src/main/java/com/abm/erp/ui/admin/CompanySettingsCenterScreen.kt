package com.abm.erp.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abm.erp.data.*
import com.abm.erp.theme.*

@Composable
fun CompanySettingsCenterScreen() {
    val currentUser = MockRepository.currentUser
    if (currentUser.role != UserRole.CHAIRMAN) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("এই স্ক্রিন শুধু Chairman-এর জন্য।") }
        return
    }
    val settingsList by MockRepository.companySettingsList.collectAsState()
    val settings = remember(settingsList) { MockRepository.companySettings() }

    var companyName by remember(settings) { mutableStateOf(settings.companyName) }
    var fiscalYearStartMonth by remember(settings) { mutableStateOf(settings.fiscalYearStartMonth) }
    var companyAddress by remember(settings) { mutableStateOf(settings.companyAddress) }
    var companyPhone by remember(settings) { mutableStateOf(settings.companyPhone) }
    var companyEmail by remember(settings) { mutableStateOf(settings.companyEmail) }
    var taxVatNumber by remember(settings) { mutableStateOf(settings.taxVatNumber) }
    var vatPct by remember(settings) { mutableStateOf(settings.vatPct.toString()) }
    var currencyCode by remember(settings) { mutableStateOf(settings.currencyCode) }
    var currencySymbol by remember(settings) { mutableStateOf(settings.currencySymbol) }
    var numberFormatPattern by remember(settings) { mutableStateOf(settings.numberFormatPattern) }
    var workingDays by remember(settings) { mutableStateOf(settings.workingDays.toSet()) }
    var attendancePolicyNote by remember(settings) { mutableStateOf(settings.attendancePolicyNote) }
    var payrollPolicyNote by remember(settings) { mutableStateOf(settings.payrollPolicyNote) }
    var invoicePolicyNote by remember(settings) { mutableStateOf(settings.invoicePolicyNote) }
    var dealerPolicyNote by remember(settings) { mutableStateOf(settings.dealerPolicyNote) }
    var targetPolicyNote by remember(settings) { mutableStateOf(settings.targetPolicyNote) }
    var saved by remember { mutableStateOf(false) }

    val allDays = listOf("SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY")

    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Text("Company Settings Center", style = MaterialTheme.typography.titleLarge)
        Text("Financial Year — Start Month", style = MaterialTheme.typography.titleMedium)
        val monthNames = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            monthNames.forEachIndexed { index, name ->
                FilterChip(selected = fiscalYearStartMonth == index + 1, onClick = { fiscalYearStartMonth = index + 1 }, label = { Text(name, style = MaterialTheme.typography.labelSmall) })
            }
        }
        Text("বর্তমান: ${monthNames[fiscalYearStartMonth - 1]}-এ শুরু (নতুন number-series-এই প্রতিফলিত হবে)।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(10.dp))

        Text("Company Information", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(value = companyName, onValueChange = { companyName = it }, label = { Text("Company Name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = companyAddress, onValueChange = { companyAddress = it }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(value = companyPhone, onValueChange = { companyPhone = it }, label = { Text("Phone") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = companyEmail, onValueChange = { companyEmail = it }, label = { Text("Email") }, modifier = Modifier.weight(1f))
        }

        Spacer(Modifier.height(14.dp))
        Text("Tax / VAT", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(value = taxVatNumber, onValueChange = { taxVatNumber = it }, label = { Text("Tax/VAT Number") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = vatPct, onValueChange = { vatPct = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("VAT %") }, modifier = Modifier.weight(1f))
        }

        Spacer(Modifier.height(14.dp))
        Text("Currency & Number Format", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(value = currencyCode, onValueChange = { currencyCode = it }, label = { Text("Currency Code") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = currencySymbol, onValueChange = { currencySymbol = it }, label = { Text("Symbol") }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = numberFormatPattern, onValueChange = { numberFormatPattern = it }, label = { Text("Number Format Pattern") }, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(14.dp))
        Text("Working Days", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            allDays.forEach { day ->
                FilterChip(selected = day in workingDays, onClick = { workingDays = if (day in workingDays) workingDays - day else workingDays + day }, label = { Text(day.take(3), style = MaterialTheme.typography.labelSmall) })
            }
        }

        Spacer(Modifier.height(14.dp))
        Text("Holidays", style = MaterialTheme.typography.titleMedium)
        var holidayName by remember { mutableStateOf("") }
        var holidayDate by remember { mutableStateOf(java.time.LocalDate.now()) }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(value = holidayName, onValueChange = { holidayName = it }, label = { Text("Holiday name") }, modifier = Modifier.weight(1f))
            Button(onClick = { if (holidayName.isNotBlank()) { MockRepository.addCompanyHoliday(holidayDate, holidayName); holidayName = "" } }) { Text("+ Add ($holidayDate)") }
        }
        settings.holidays.forEach { h -> Text("${h.date} — ${h.name}", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }

        Spacer(Modifier.height(14.dp))
        Text("Policies", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(value = attendancePolicyNote, onValueChange = { attendancePolicyNote = it }, label = { Text("Attendance Policy") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = payrollPolicyNote, onValueChange = { payrollPolicyNote = it }, label = { Text("Payroll Policy") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = invoicePolicyNote, onValueChange = { invoicePolicyNote = it }, label = { Text("Invoice Policy") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = dealerPolicyNote, onValueChange = { dealerPolicyNote = it }, label = { Text("Dealer Policy") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = targetPolicyNote, onValueChange = { targetPolicyNote = it }, label = { Text("Target Policy") }, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(16.dp))
        if (saved) Text("✓ সংরক্ষিত হয়েছে", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
        Button(
            onClick = {
                val updated = settings.copy(
                    companyName = companyName, companyAddress = companyAddress, companyPhone = companyPhone, companyEmail = companyEmail,
                    fiscalYearStartMonth = fiscalYearStartMonth,
                    taxVatNumber = taxVatNumber, vatPct = vatPct.toDoubleOrNull() ?: 0.0, currencyCode = currencyCode, currencySymbol = currencySymbol,
                    numberFormatPattern = numberFormatPattern, workingDays = workingDays.toList(),
                    attendancePolicyNote = attendancePolicyNote, payrollPolicyNote = payrollPolicyNote, invoicePolicyNote = invoicePolicyNote,
                    dealerPolicyNote = dealerPolicyNote, targetPolicyNote = targetPolicyNote,
                )
                saved = MockRepository.updateCompanySettings(updated)
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Save Settings") }
    }
}
