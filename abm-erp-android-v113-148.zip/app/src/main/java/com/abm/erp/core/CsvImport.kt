package com.abm.erp.core

import android.content.Context
import android.net.Uri

/**
 * v113-146 — real CSV/Excel import, the honest counterpart to the CSV EXPORT this
 * app already does (`exportListAsCsv`). A file exported from here, edited in
 * Excel/Sheets and saved back as CSV, imports cleanly — same column names, same
 * escaping rules.
 *
 * Scope stated plainly: this reads **CSV**, not binary `.xlsx`. Parsing real
 * `.xlsx` needs a heavy library (Apache POI) that isn't in this project, and
 * pretending a renamed file works would fail confusingly at run time. Every
 * spreadsheet tool offers "Save as CSV", and the app's own export is CSV, so this
 * is the format that genuinely round-trips.
 *
 * Nothing here writes to the database directly — each parsed row is handed to the
 * SAME real create function the manual form uses (createDealer/createRetailer/
 * addProduct), so every permission check, duplicate check and validation rule
 * applies identically to an imported row and a typed one. That is why the result
 * carries a real per-row reason instead of a single "import failed".
 */
object CsvImport {

    data class RowResult(val line: Int, val label: String, val ok: Boolean, val reason: String? = null)

    data class ImportOutcome(
        val total: Int,
        val succeeded: Int,
        val failed: Int,
        val rows: List<RowResult>,
        val fatal: String? = null,
    )

    /**
     * Splits one CSV line, honouring quoted fields and doubled quotes ("") the same
     * way `escapeCsvField` writes them — so a field containing a comma survives the
     * export→edit→import round trip instead of silently splitting into two columns.
     */
    fun splitCsvLine(line: String): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && inQuotes && i + 1 < line.length && line[i + 1] == '"' -> { sb.append('"'); i++ }
                c == '"' -> inQuotes = !inQuotes
                c == ',' && !inQuotes -> { out.add(sb.toString().trim()); sb.clear() }
                else -> sb.append(c)
            }
            i++
        }
        out.add(sb.toString().trim())
        return out
    }

    /** Reads the picked file as text. Returns null (not an empty string) when it genuinely can't be read, so the caller can tell "empty file" from "unreadable file". */
    fun readText(context: Context, uri: Uri): String? = try {
        context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
    } catch (e: Exception) {
        null
    }

    /**
     * Maps the header row to column indexes by NAME, case-insensitively, so column
     * order doesn't have to match and extra columns are ignored rather than
     * shifting everything. Returns null if a required column is absent — reported
     * as a fatal error naming the missing column, instead of importing garbage.
     */
    fun headerIndex(header: List<String>, required: List<String>): Pair<Map<String, Int>, String?> {
        val idx = header.mapIndexed { i, h -> h.trim().lowercase() to i }.toMap()
        val missing = required.filter { it.lowercase() !in idx }
        return idx to if (missing.isEmpty()) null else "এই column গুলো পাওয়া যায়নি: ${missing.joinToString(", ")}"
    }
}
