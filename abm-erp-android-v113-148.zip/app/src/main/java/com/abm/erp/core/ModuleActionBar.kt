package com.abm.erp.core

import android.widget.Toast
import androidx.compose.foundation.layout.Row
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext

/**
 * Task 3 — one reusable module-level action row instead of duplicating the
 * same icon-button trio in 20 different screen files. A screen wires in
 * only the callbacks it actually supports (Refresh/Export/Share); any null
 * callback simply doesn't render that icon — no dead buttons.
 *
 * Task 2 — every onExport/onShare invocation is wrapped in a try-catch
 * HERE, once, so all 17 call sites get the same crash-safety without each
 * screen duplicating its own try-catch block. A screen's callback can still
 * throw (missing directory, write failure, no share app, FileProvider
 * error, malformed data) — this composable catches it and shows a clear
 * Bengali error Toast instead of crashing, exactly like the equivalent
 * per-record protection already built into UniversalActionMenu.
 */
@Composable
fun ModuleActionBar(
    onRefresh: (() -> Unit)? = null,
    onExport: (() -> Unit)? = null,
    onShare: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    Row(modifier) {
        if (onRefresh != null) {
            IconButton(onClick = {
                try { onRefresh() } catch (e: Exception) { Toast.makeText(context, "Refresh ব্যর্থ হয়েছে: ${e.message}", Toast.LENGTH_LONG).show() }
            }) { Icon(Icons.Filled.Refresh, contentDescription = "Refresh") }
        }
        if (onExport != null) {
            IconButton(onClick = {
                try { onExport() } catch (e: Exception) { Toast.makeText(context, "Export ব্যর্থ হয়েছে: ${e.message}", Toast.LENGTH_LONG).show() }
            }) { Icon(Icons.Filled.FileDownload, contentDescription = "Export") }
        }
        if (onShare != null) {
            IconButton(onClick = {
                try { onShare() } catch (e: Exception) { Toast.makeText(context, "Share ব্যর্থ হয়েছে: ${e.message}", Toast.LENGTH_LONG).show() }
            }) { Icon(Icons.Filled.Share, contentDescription = "Share") }
        }
    }
}
