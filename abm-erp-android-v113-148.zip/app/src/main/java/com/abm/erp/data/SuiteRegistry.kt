package com.abm.erp.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Suite Registry — navigation metadata only.
 *
 * The app previously showed 21 flat module tiles. That made it feel like a menu of
 * screens rather than a set of tools. Here the same screens are grouped into
 * **suites**, each of which is the complete application for one business segment:
 * DMS is everything about a dealer (network, ledger, due, invoice, collection),
 * HRM is everything about an employee (directory, attendance, payroll, exit), and
 * so on.
 *
 * Nothing here is a new screen. Every `SuiteFunction` points at a route that already
 * exists in NavGraph plus, where relevant, the tab index inside that screen — so a
 * function opens directly on the right page instead of dropping the user on a hub.
 *
 * `roles` reuses the same role names the permission engine already uses; the suite
 * list is additionally filtered against `visibleModulesFor()` at render time, so a
 * suite can never widen access beyond what the module rules already granted.
 */

data class SuiteFunction(
    val label: String,
    val icon: ImageVector,
    val description: String,
    /** Existing NavGraph route. */
    val route: String,
    /** Tab index inside that screen, or null to open its own hub. */
    val startTab: Int? = null,
    /** Module key used for the existing access check. */
    val moduleKey: String,
)

data class SuiteGroup(val title: String, val functions: List<SuiteFunction>)

data class AppSuite(
    val key: String,
    val name: String,
    val fullName: String,
    val tagline: String,
    val icon: ImageVector,
    val colorStart: Long,
    val colorEnd: Long,
    val groups: List<SuiteGroup>,
    val isChairman: Boolean = false,
) {
    val functionCount: Int get() = groups.sumOf { it.functions.size }
}

// ── Tab indices below mirror the `when (key)` blocks already inside each screen.
//    They are not new behaviour; they are the same destinations the sub-module grid
//    already navigates to.

val APP_SUITES: List<AppSuite> = listOf(

    AppSuite(
        key = "dms", name = "DMS", fullName = "Dealer Management System",
        tagline = "Dealer network, stock, statement, due & collection",
        icon = Icons.Filled.Storefront, colorStart = 0xFFB45CFF, colorEnd = 0xFF7A2EE0,
        groups = listOf(
            SuiteGroup("Dealer Network", listOf(
                SuiteFunction("Dealer Add", Icons.Filled.AddBusiness, "নতুন ডিলার যোগ ও অনুমোদন", "dealers", 0, "dealer"),
                SuiteFunction("Dealer Directory", Icons.Filled.Business, "All dealers, territory-scoped", "dealers", 0, "dealer"),
                SuiteFunction("Dealer Stock", Icons.Filled.Inventory, "ডিলারের হাতে থাকা স্টক", "dealers", 0, "dealer"),
                SuiteFunction("Retailer Network", Icons.Filled.Store, "Outlets under each dealer", "dealers", 2, "dealer"),
                SuiteFunction("Location Alerts", Icons.Filled.LocationOn, "Geo-fence & location issues", "dealers", 3, "dealer"),
                SuiteFunction("Security Events", Icons.Filled.Security, "Device & access events", "dealers", 4, "dealer"),
            )),
            // Dealer-facing money only. The company's own books (Chart of Accounts, Trial
            // Balance, P&L) live in FMS — a dealer manager should not be looking at them here.
            SuiteGroup("Money", listOf(
                SuiteFunction("Collection", Icons.Filled.Payments, "Record & verify payment", "dealers", 1, "dealer"),
                SuiteFunction("Dealer Invoice", Icons.Filled.ReceiptLong, "Create invoice — bill-styled form", "dealer_invoice_new", null, "bill"),
                SuiteFunction("Credit Risk", Icons.Filled.Warning, "Limit, exposure & block rules", "billing", 0, "bill"),
                SuiteFunction("Payments", Icons.Filled.CreditCard, "Payment history & dues", "billing", 2, "bill"),
            )),
            SuiteGroup("Movement", listOf(
                SuiteFunction("Delivery Challan", Icons.Filled.LocalShipping, "Dispatch & handover", "billing", 5, "bill"),
                SuiteFunction("Sales Return", Icons.Filled.AssignmentReturn, "Return & credit note", "billing", 6, "bill"),
            )),
        ),
    ),

    AppSuite(
        key = "sfa", name = "SFA", fullName = "Sales Force Automation",
        tagline = "Field execution — order, visit, route & target",
        icon = Icons.Filled.TrendingUp, colorStart = 0xFF2563EB, colorEnd = 0xFF1E3A8A,
        groups = listOf(
            SuiteGroup("Selling", listOf(
                SuiteFunction("Retailer Order", Icons.Filled.ShoppingCart, "Take order from retailer", "retail_order", null, "sales"),
                SuiteFunction("Wholesale Order", Icons.Filled.Inventory2, "Bulk / wholesale order", "sales", 1, "sales"),
                SuiteFunction("Sales Order", Icons.Filled.Description, "Dealer sales order", "sales", 4, "sales"),
                SuiteFunction("Order Verification", Icons.Filled.FactCheck, "Verify & route to dealer", "sales", 3, "sales"),
            )),
            SuiteGroup("Field Work", listOf(
                SuiteFunction("Route Audit", Icons.Filled.Route, "Planned vs actual route", "crm", 2, "crm"),
                SuiteFunction("Live Tracking", Icons.Filled.Satellite, "Team location, manager view", "crm", 9, "crm"),
                SuiteFunction("Performance", Icons.Filled.BarChart, "Field performance by rep", "crm", 7, "crm"),
            )),
        ),
    ),

    AppSuite(
        key = "crm", name = "CRM", fullName = "Customer Relationship Management",
        tagline = "Leads, opportunities, engagement & complaints",
        icon = Icons.Filled.Diversity3, colorStart = 0xFF00C2E0, colorEnd = 0xFF0093B8,
        groups = listOf(
            SuiteGroup("Pipeline", listOf(
                SuiteFunction("Leads", Icons.Filled.GpsFixed, "Prospect pipeline", "crm", 4, "crm"),
                SuiteFunction("Opportunities", Icons.Filled.BusinessCenter, "Deals in progress", "crm", 5, "crm"),
            )),
            SuiteGroup("Relationship", listOf(
                SuiteFunction("Engagement Hub", Icons.Filled.Campaign, "Campaigns & engagement", "crm", 3, "crm"),
                SuiteFunction("Communication Log", Icons.Filled.Call, "Call & contact history", "crm", 6, "crm"),
                SuiteFunction("Customer Complaints", Icons.Filled.ReportProblem, "Complaints from the field", "crm", 8, "crm"),
            )),
            SuiteGroup("Directory", listOf(
                SuiteFunction("Retailer List", Icons.Filled.Store, "Outlets in your territory", "crm", 0, "crm"),
                SuiteFunction("Dealer List", Icons.Filled.Business, "Dealers in your territory", "crm", 1, "crm"),
            )),
        ),
    ),

    AppSuite(
        key = "hrm", name = "HRM", fullName = "Human Resource Management",
        tagline = "Office staff — lifecycle, attendance & payroll",
        icon = Icons.Filled.Groups, colorStart = 0xFFDB2777, colorEnd = 0xFF9D174D,
        groups = listOf(
            SuiteGroup("People", listOf(
                SuiteFunction("Employee Directory", Icons.Filled.Groups, "All staff by designation", "hrm", 4, "hr"),
                SuiteFunction("Employee Management", Icons.Filled.ManageAccounts, "Create & maintain staff", "hrm", 5, "hr"),
            )),
            SuiteGroup("Time", listOf(
                SuiteFunction("Attendance", Icons.Filled.Schedule, "Daily in/out, geo-verified", "hrm", 0, "hr"),
                SuiteFunction("Leave", Icons.Filled.BeachAccess, "Apply, approve, balance", "hrm", 2, "hr"),
            )),
            SuiteGroup("Money & Growth", listOf(
                SuiteFunction("Payroll", Icons.Filled.CreditCard, "Salary run & payslip", "hrm", 1, "hr"),
                SuiteFunction("Increment / Promotion / Exit", Icons.Filled.Assignment, "Employee lifecycle events", "hrm", 3, "hr"),
            )),
        ),
    ),

    AppSuite(
        key = "wms", name = "WMS", fullName = "Warehouse Management System",
        tagline = "Stock, transfer, receive & reconciliation",
        icon = Icons.Filled.Warehouse, colorStart = 0xFF475569, colorEnd = 0xFF1E293B,
        groups = listOf(
            SuiteGroup("Stock", listOf(
                SuiteFunction("Stock Levels", Icons.Filled.Inventory2, "On-hand by product & warehouse", "inventory", 0, "inv"),
                SuiteFunction("Product Master", Icons.Filled.AddBox, "SKU, category, brand, price", "inventory", 2, "inv"),
                SuiteFunction("Category & Brand", Icons.Filled.LocalOffer, "Product classification", "inventory", 3, "inv"),
                SuiteFunction("Stock Count", Icons.Filled.Calculate, "Physical count & variance", "inventory", 8, "inv"),
            )),
            SuiteGroup("Movement", listOf(
                SuiteFunction("Stock Movement", Icons.Filled.SwapHoriz, "In / out history", "inventory", 1, "inv"),
                SuiteFunction("Stock Adjustment", Icons.Filled.Balance, "Correct counted quantity", "inventory", 4, "inv"),
                SuiteFunction("Stock Transfer", Icons.Filled.LocalShipping, "Between own warehouses", "inventory", 5, "inv"),
                SuiteFunction("Warehouse Transfer", Icons.Filled.MoveToInbox, "Dispatch & receive", "production_warehouse", 1, "stock"),
            )),
            SuiteGroup("Exception", listOf(
                SuiteFunction("Damage", Icons.Filled.BrokenImage, "Damaged stock write-off", "inventory", 6, "inv"),
                SuiteFunction("Expiry", Icons.Filled.HourglassBottom, "Near-expiry & expired", "inventory", 7, "inv"),
                SuiteFunction("Stock Intelligence", Icons.Filled.Psychology, "Dead stock & reorder insight", "inventory", 9, "inv"),
            )),
        ),
    ),

    AppSuite(
        key = "mes", name = "MES", fullName = "Manufacturing Execution System",
        tagline = "Factory — plan, batch, QC, workers & output",
        icon = Icons.Filled.Factory, colorStart = 0xFFE85D4A, colorEnd = 0xFFC03A2B,
        groups = listOf(
            SuiteGroup("Planning", listOf(
                SuiteFunction("Production Plan", Icons.Filled.EventNote, "Batch schedule by line & shift", "production_warehouse", 0, "prod"),
                SuiteFunction("Bill of Materials", Icons.Filled.Architecture, "Recipe & unit cost", "production", 3, "prod"),
                SuiteFunction("Production Order", Icons.Filled.Factory, "Order to make finished goods", "production", 4, "prod"),
                SuiteFunction("Raw Materials", Icons.Filled.Layers, "Material stock & issue", "production", 0, "prod"),
            )),
            SuiteGroup("Execution", listOf(
                SuiteFunction("Batches", Icons.Filled.Settings, "Start, monitor, complete", "production", 1, "prod"),
                SuiteFunction("Machine Utilisation", Icons.Filled.Build, "Machine hours & uptime", "production", 7, "prod"),
            )),
            SuiteGroup("Quality & Output", listOf(
                SuiteFunction("Quality Control", Icons.Filled.VerifiedUser, "QC pass / fail per batch", "production", 5, "prod"),
                SuiteFunction("Production Loss", Icons.Filled.TrendingDown, "Yield & wastage", "production", 6, "prod"),
            )),
            // The factory runs its own workforce, separate from office HRM. Membership comes
            // from EmployeeProfile.employeeType, set by the Chairman in Employee Setup.
            SuiteGroup("Factory Workforce", listOf(
                SuiteFunction("Factory Workforce", Icons.Filled.Engineering, "কারখানার কর্মী ও আজকের উপস্থিতি", "production", 2, "prod"),
            )),
        ),
    ),

    AppSuite(
        key = "fms", name = "FMS", fullName = "Finance & Accounting",
        tagline = "Company books — cash, bank, ledger, expense, closing",
        icon = Icons.Filled.AccountBalance, colorStart = 0xFF12C2A9, colorEnd = 0xFF0E9F8B,
        groups = listOf(
            SuiteGroup("Daily", listOf(
                SuiteFunction("Quick Ledger", Icons.Filled.MenuBook, "Fast cash in / out entry", "ledger", 0, "ledger"),
                SuiteFunction("Cash & Bank Book", Icons.Filled.AccountBalance, "Running cash & bank balance", "ledger", 3, "ledger"),
                SuiteFunction("Expense", Icons.Filled.Payments, "Submit & approve expense", "expenses", null, "ledger"),
                SuiteFunction("Vouchers", Icons.Filled.ReceiptLong, "Journal / payment voucher", "ledger", 2, "ledger"),
            )),
            SuiteGroup("Books", listOf(
                SuiteFunction("Chart of Accounts", Icons.Filled.AccountTree, "Account tree", "ledger", 1, "ledger"),
                SuiteFunction("Trial Balance", Icons.Filled.Balance, "Debit / credit balance", "ledger", 4, "ledger"),
            )),
            SuiteGroup("Reporting", listOf(
                SuiteFunction("Profit & Loss", Icons.Filled.TrendingUp, "Income statement", "ledger", 5, "ledger"),
                SuiteFunction("Balance Sheet", Icons.Filled.PieChart, "Assets, liabilities, equity", "ledger", 6, "ledger"),
                SuiteFunction("Period Lock", Icons.Filled.Lock, "Close an accounting period", "period_lock_center", null, "ledger"),
            )),
        ),
    ),

    AppSuite(
        key = "scm", name = "SCM", fullName = "Procurement & Logistics",
        tagline = "Supplier, PO, GRN & delivery",
        icon = Icons.Filled.ShoppingCart, colorStart = 0xFF8A6DFF, colorEnd = 0xFF5B3FE0,
        groups = listOf(
            SuiteGroup("Procure", listOf(
                SuiteFunction("Suppliers", Icons.Filled.Business, "Vendor master", "purchase", 0, "purchase"),
                SuiteFunction("Purchase Request", Icons.Filled.Assignment, "Requisition & approval", "purchase", 1, "purchase"),
                SuiteFunction("Purchase Order", Icons.Filled.EditNote, "Issue PO to supplier", "purchase", 2, "purchase"),
                SuiteFunction("GRN / Receive", Icons.Filled.MoveToInbox, "Goods receipt note", "purchase", 3, "purchase"),
                SuiteFunction("Supplier Payment", Icons.Filled.CreditCard, "Pay & track dues", "purchase", 5, "purchase"),
            )),
            SuiteGroup("Logistics", listOf(
                SuiteFunction("Book Shipment", Icons.Filled.LocalShipping, "Courier booking", "courier", 0, "courier"),
                SuiteFunction("Track Shipment", Icons.Filled.LocationOn, "Live shipment status", "courier", 1, "courier"),
                SuiteFunction("Vehicle Tracking", Icons.Filled.AirportShuttle, "Own fleet location", "courier", 2, "courier"),
            )),
        ),
    ),

    AppSuite(
        key = "bi", name = "BI", fullName = "Reports & Analytics",
        tagline = "Company-wide reporting & market view",
        icon = Icons.Filled.InsertChart, colorStart = 0xFF9C6EFF, colorEnd = 0xFF6E3EDB,
        groups = listOf(
            SuiteGroup("Reports", listOf(
                SuiteFunction("Company Reports", Icons.Filled.InsertChart, "Cross-module summary", "reports", null, "report"),
                SuiteFunction("Market Analysis", Icons.Filled.QueryStats, "Zone performance & coverage", "market", null, "market"),
            )),
        ),
    ),

    AppSuite(
        key = "wsp", name = "Workspace", fullName = "My Workspace",
        tagline = "Tasks, messages & support",
        icon = Icons.Filled.TaskAlt, colorStart = 0xFF3DDC97, colorEnd = 0xFF1FA972,
        groups = listOf(
            // Decision 2 (v113-72) — "Approvals" is deliberately absent. Each approval type
            // now lives inside the module it is about (HRM / Expenses / Ledger / DMS), so a
            // Workspace entry here would be exactly the cross-cutting inbox that was removed.
            SuiteGroup("Action", listOf(
                SuiteFunction("Task Manager", Icons.Filled.TaskAlt, "Assigned tasks & sub-tasks", "tasks", null, "tasks"),
            )),
            SuiteGroup("Communication", listOf(
                SuiteFunction("Notifications", Icons.Filled.Notifications, "System & business alerts", "notifications", null, "notify"),
                SuiteFunction("Communication Hub", Icons.Filled.Forum, "Chat & announcements", "comms", null, "comms"),
                SuiteFunction("Helpdesk", Icons.Filled.SupportAgent, "Support tickets", "helpdesk", null, "helpdesk"),
                SuiteFunction("Complaint Box", Icons.Filled.MarkunreadMailbox, "Direct to Chairman", "complaint", null, "complaint"),
            )),
        ),
    ),

    AppSuite(
        key = "cmd", name = "Command", fullName = "Chairman Command Center",
        tagline = "Executive control · Chairman only",
        icon = Icons.Filled.WorkspacePremium, colorStart = 0xFF0F1E3D, colorEnd = 0xFF0A1428,
        isChairman = true,
        groups = listOf(
            SuiteGroup("Intelligence", listOf(
                SuiteFunction("Chairman Hub", Icons.Filled.WorkspacePremium, "Executive dashboard & risks", "chairman_hub", null, "report"),
                SuiteFunction("AI Boardroom", Icons.Filled.Insights, "Advisory & scenario view", "boardroom", null, "report"),
            )),
            SuiteGroup("Governance", listOf(
                SuiteFunction("Audit Log", Icons.Filled.Assignment, "Every data action", "enterprise_audit_center", null, "settings"),
                SuiteFunction("Business Rules", Icons.Filled.Rule, "Rule engine", "business_rule_engine", null, "settings"),
                SuiteFunction("Permission Center", Icons.Filled.VpnKey, "Roles & permissions", "permission_center", null, "settings"),
                SuiteFunction("Employee Setup", Icons.Filled.ManageAccounts, "কর্মী · পদবি · এলাকা · PIN — এক জায়গায়", "employee_setup", null, "settings"),
            )),
            SuiteGroup("System", listOf(
                SuiteFunction("System Health", Icons.Filled.MonitorHeart, "Sync, errors, uptime", "system_health_dashboard", null, "settings"),
                SuiteFunction("Sync Status", Icons.Filled.Sync, "Offline queue & retry", "sync_status_center", null, "settings"),
                SuiteFunction("Configuration Center", Icons.Filled.Tune, "সব সেটিং এক জায়গায় — বর্তমান মান সহ", "configuration_center", null, "settings"),
                SuiteFunction("Global Settings", Icons.Filled.Settings, "Company configuration", "company_settings_center", null, "settings"),
            )),
        ),
    ),
)

fun suiteByKey(key: String): AppSuite? = APP_SUITES.firstOrNull { it.key == key }

/**
 * Suites the current role may see.
 *
 * A suite appears only if the role can already see at least one of the modules its
 * functions belong to, so this can never grant access the module rules did not
 * already allow. Chairman-only suites additionally require the Chairman role.
 */
fun visibleSuitesFor(role: UserRole): List<AppSuite> {
    val allowedModules = visibleModulesFor(role).map { it.key }.toSet()
    return APP_SUITES.filter { suite ->
        if (suite.isChairman && role != UserRole.CHAIRMAN) return@filter false
        suite.groups.any { g -> g.functions.any { it.moduleKey in allowedModules } }
    }
}

/** Functions inside a suite that this role may actually open. */
fun visibleFunctionsFor(suite: AppSuite, role: UserRole): List<SuiteGroup> {
    val allowedModules = visibleModulesFor(role).map { it.key }.toSet()
    return suite.groups
        .map { g -> g.copy(functions = g.functions.filter { it.moduleKey in allowedModules }) }
        .filter { it.functions.isNotEmpty() }
}
