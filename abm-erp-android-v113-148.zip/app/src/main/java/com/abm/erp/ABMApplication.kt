package com.abm.erp

import android.app.Application
import com.abm.erp.data.ApprovalSlaWorker
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.MockRepository
import com.abm.erp.data.SyncRetryWorker
import kotlinx.coroutines.launch

/**
 * App-level entry point. MockRepository.init() and InventoryRepository.init()
 * open/create the on-device Room database (abm_erp.db) and seed it with
 * starter data on first run. FirebaseSync.init() signs in anonymously and
 * starts listening to Firestore for the data that needs to sync across
 * different people's phones (Complaint Box, Vacant Positions today; more
 * modules move here in later phases). It fails safely if google-services.json
 * hasn't been added yet — see SETUP_FIREBASE.md. SyncRetryWorker.schedule()
 * registers the WorkManager background job that re-heals sync if a listener
 * silently dies (see SyncRetryWorker's own doc comment).
 */
class ABMApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        // Section 12 — Firebase App Check. Debug provider only ever
        // activates for DEBUG/STAGING (its tokens are useless outside a
        // registered debug device anyway); Play Integrity is real
        // hardware/app-integrity attestation for production. This call
        // only INSTALLS a provider client-side — it does NOT turn on
        // enforcement in the Firebase Console (see SETUP_FIREBASE.md for
        // that manual step, which should happen only after confirming
        // real traffic isn't blocked).
        try {
            val appCheck = com.google.firebase.appcheck.FirebaseAppCheck.getInstance()
            if (com.abm.erp.config.AppEnvironment.isProduction) {
                appCheck.installAppCheckProviderFactory(
                    com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory.getInstance(),
                )
            } else {
                appCheck.installAppCheckProviderFactory(
                    com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory.getInstance(),
                )
            }
        } catch (e: Exception) {
            com.abm.erp.config.AppLog.w("ABMApplication", "App Check provider install failed — app still works, just without attestation", e)
        }
        MockRepository.init(this)
        InventoryRepository.init(this)
        com.abm.erp.data.PurchaseRepository.init(this)
        com.abm.erp.data.AccountsRepository.init(this)
        com.abm.erp.data.CrmRepository.init(this)
        com.abm.erp.data.CommsRepository.init(this)
        FirebaseSync.init(this)
        SyncRetryWorker.schedule(this)
        ApprovalSlaWorker.schedule(this)
        // Bangladesh Offline Administrative Location Master — background seed, never blocks UI (Section 5).
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                MockRepository.importBangladeshLocations(this@ABMApplication)
            } catch (e: Exception) {
                com.abm.erp.config.AppLog.w("ABMApplication", "Bangladesh location import failed", e)
            }
        }
    }

    companion object {
        // Section 7 — Business Continuity Mode. Backend business-logic
        // functions in MockRepository have no direct Context to check real
        // connectivity with; this minimal static holder (the standard,
        // safe pattern for an Application subclass, since Application
        // itself already lives for the whole process lifetime) lets
        // isOnlineNow() work from anywhere without threading Context
        // through dozens of function signatures.
        private var instance: ABMApplication? = null
        fun isOnlineNow(): Boolean = instance?.let { com.abm.erp.util.NetworkStatus.isOnline(it) } ?: true // fail open — never block a legitimate action just because this holder wasn't set yet
        /** Section 11 — Enterprise Audit Center's Device field, without threading Context through every logAudit() call site. */
        fun currentDeviceId(): String? = instance?.let { com.abm.erp.data.getOrCreateDeviceId(it) }
    }
}
