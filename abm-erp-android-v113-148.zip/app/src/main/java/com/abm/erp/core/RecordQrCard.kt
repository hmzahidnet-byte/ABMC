package com.abm.erp.core

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.util.QrCodeGenerator
import kotlinx.coroutines.launch

/**
 * QR Generation — the other half of the Universal QR engine.
 *
 * Every business record that the scanner can RESOLVE should also be able to
 * SHOW its own QR, otherwise there is nothing physical to scan in the field.
 * This renders the record's own code (the exact same string
 * `CodeRegistry.resolve()` matches on — dealerCode / employeeCode /
 * retailerCode / invoiceNo / collectionNo / sku / batchNumber /
 * transferNumber / challanNo), so a generated tag always scans back to its
 * own record. Never encodes anything sensitive — only the public identifier.
 *
 * `code` must be the record's real code field. Passing a raw UUID also works
 * (resolve() falls back to id matching) but produces a tag that is useless to
 * read by eye, so prefer the human-readable code where one exists.
 */
@Composable
fun RecordQrButton(
    code: String,
    title: String,
    subtitle: String? = null,
    label: String = "Show QR",
    /** When both are supplied the button uses the SECURE registry: it renders the record's
     *  active opaque token, and offers Reissue/Revoke. Without them it falls back to
     *  rendering the plain `code`, which is what pre-registry tags used. */
    entityType: String? = null,
    entityId: String? = null,
) {
    var showQr by remember { mutableStateOf(false) }
    if (code.isBlank() && entityId.isNullOrBlank()) return
    TextButton(onClick = { showQr = true }) {
        androidx.compose.material3.Icon(
            Icons.Filled.QrCode2,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
        )
        Spacer(Modifier.width(4.dp))
        Text(label)
    }
    if (showQr) {
        if (entityType != null && entityId != null) {
            SecureRecordQrDialog(entityType, entityId, title, subtitle) { showQr = false }
        } else {
            RecordQrDialog(code = code, title = title, subtitle = subtitle, onDismiss = { showQr = false })
        }
    }
}

/**
 * Secure QR sheet — shows the record's ACTIVE registry token, with Reissue and Revoke.
 *
 * Important property: the token is only available at the moment it is issued, because only
 * its hash is stored. So an already-issued QR cannot be re-rendered here — the honest
 * options are "reissue" (mint a new one, invalidating the old print) or nothing. That is
 * shown plainly rather than pretending the old code can be recovered.
 */
@Composable
fun SecureRecordQrDialog(
    entityType: String,
    entityId: String,
    title: String,
    subtitle: String?,
    onDismiss: () -> Unit,
) {
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var active by remember { mutableStateOf<com.abm.erp.data.room.QrRegistryEntity?>(null) }
    var history by remember { mutableStateOf<List<com.abm.erp.data.room.QrRegistryEntity>>(emptyList()) }
    var freshPayload by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var loaded by remember { mutableStateOf(false) }

    LaunchedEffect(entityType, entityId) {
        active = com.abm.erp.data.QrRegistry.activeFor(entityType, entityId)
        history = com.abm.erp.data.QrRegistry.historyFor(entityType, entityId)
        loaded = true
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
            Column(
                Modifier.padding(20.dp).widthIn(max = 340.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                if (!subtitle.isNullOrBlank()) Text(subtitle, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Spacer(Modifier.height(14.dp))

                when {
                    !loaded -> com.abm.erp.core.WorkspaceLoadingState("QR তথ্য লোড হচ্ছে…")

                    freshPayload != null -> {
                        val bmp = remember(freshPayload) { runCatching { QrCodeGenerator.generate(freshPayload!!, 640) }.getOrNull() }
                        if (bmp != null) {
                            Image(bitmap = bmp.asImageBitmap(), contentDescription = "Secure QR", modifier = Modifier.size(220.dp))
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "এখনই প্রিন্ট বা সেভ করুন — নিরাপত্তার জন্য এই কোড আর দেখানো যাবে না।",
                            style = MaterialTheme.typography.labelSmall,
                            color = com.abm.erp.theme.StatusAmber,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                    }

                    active != null -> {
                        Text("✅ সক্রিয় QR আছে", color = com.abm.erp.theme.StatusGreen, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text("Version ${active!!.version} · স্ক্যান হয়েছে ${active!!.scanCount} বার", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "নিরাপত্তার কারণে শুধু কোডের হ্যাশ সংরক্ষিত হয়, তাই আগের QR আবার দেখানো যায় না। নতুন প্রিন্ট দরকার হলে Reissue করুন — তাতে পুরনো QR বাতিল হয়ে যাবে।",
                            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                    }

                    else -> Text("এই রেকর্ডের কোনো সক্রিয় QR নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                }

                message?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, style = MaterialTheme.typography.labelSmall, color = com.abm.erp.theme.StatusRed)
                }

                if (history.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text("QR History", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = TextSecondary)
                    history.take(5).forEach { h ->
                        Text("v${h.version} · ${h.status}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }

                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        enabled = !busy,
                        onClick = {
                            busy = true; message = null
                            scope.launch {
                                val payload = if (active == null) {
                                    com.abm.erp.data.QrRegistry.issue(entityType, entityId)
                                } else {
                                    com.abm.erp.data.QrRegistry.reissue(entityType, entityId, "Reissued from workspace")
                                }
                                busy = false
                                if (payload == null) {
                                    message = "QR তৈরি করা যায়নি — অনুমতি নেই অথবা কোনো সমস্যা হয়েছে।"
                                } else {
                                    freshPayload = payload
                                    active = com.abm.erp.data.QrRegistry.activeFor(entityType, entityId)
                                    history = com.abm.erp.data.QrRegistry.historyFor(entityType, entityId)
                                }
                            }
                        },
                    ) { Text(if (active == null) "QR তৈরি করুন" else "Reissue") }

                    if (active != null) {
                        OutlinedButton(
                            enabled = !busy,
                            onClick = {
                                busy = true; message = null
                                scope.launch {
                                    val ok = com.abm.erp.data.QrRegistry.revoke(active!!.qrId, "Revoked from workspace")
                                    busy = false
                                    if (!ok) message = "বাতিল করা যায়নি — অনুমতি নেই।"
                                    active = com.abm.erp.data.QrRegistry.activeFor(entityType, entityId)
                                    history = com.abm.erp.data.QrRegistry.historyFor(entityType, entityId)
                                }
                            },
                        ) { Text("Revoke", color = com.abm.erp.theme.StatusRed) }
                    }
                    TextButton(onClick = onDismiss) { Text("বন্ধ") }
                }
            }
        }
    }
}

@Composable
fun RecordQrDialog(code: String, title: String, subtitle: String? = null, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val bitmap = remember(code) { runCatching { QrCodeGenerator.generate(code, 640) }.getOrNull() }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
            Column(
                Modifier.padding(20.dp).widthIn(max = 340.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                if (!subtitle.isNullOrBlank()) {
                    Text(subtitle, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                Spacer(Modifier.height(14.dp))
                if (bitmap != null) {
                    Image(bitmap = bitmap.asImageBitmap(), contentDescription = "QR code for $code", modifier = Modifier.size(220.dp))
                } else {
                    Text("QR তৈরি করা যায়নি।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(10.dp))
                Text(code, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(4.dp))
                Text("এই QR স্ক্যান করলে সরাসরি এই রেকর্ড খুলবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        // Saves the QR as a PNG in the app's own external files dir, then offers it
                        // through the standard share sheet — the same save-then-share pattern the
                        // existing CSV/PDF exports already use, so printing goes through whatever
                        // print/share app the device already has.
                        runCatching {
                            val bmp = bitmap ?: return@runCatching
                            val file = java.io.File(context.getExternalFilesDir(null), "qr_${code.replace(Regex("[^A-Za-z0-9-]"), "_")}.png")
                            java.io.FileOutputStream(file).use { out -> bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out) }
                            val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                type = "image/png"
                                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                putExtra(android.content.Intent.EXTRA_TEXT, "$title — $code")
                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(android.content.Intent.createChooser(intent, "QR শেয়ার/প্রিন্ট করুন"))
                        }.onFailure {
                            android.widget.Toast.makeText(context, "শেয়ার করার মতো কোনো app পাওয়া যায়নি।", android.widget.Toast.LENGTH_LONG).show()
                        }
                    }) { Text("প্রিন্ট / শেয়ার") }
                    TextButton(onClick = onDismiss) { Text("বন্ধ") }
                }
            }
        }
    }
}
