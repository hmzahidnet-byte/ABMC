package com.abm.erp.location

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Foundation 3 — Location Verification core. Before this file, distance
 * calculation existed FOUR separate times (MockRepository.haversineMeters
 * private helper, MockRepository.distanceMeters public function,
 * OrgDirectory.distanceMeters top-level function, and
 * NetworkStatus.haversineKm) — a direct violation of "Do not duplicate
 * distance logic in multiple screens" that predates this foundation. This
 * is now the one authoritative implementation; the other three should
 * delegate here rather than recompute independently (existing call sites
 * are left alone where changing them risks breaking Foundation 1/2 — see
 * the honest-limitations note in the final report — but any NEW location
 * code in this foundation uses only this).
 */
object LocationVerification {

    /** Real Haversine distance in meters — the one formula this whole app uses. */
    fun distanceMeters(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val r = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lng2 - lng1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLng / 2) * sin(dLng / 2)
        return r * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    /** Human-friendly distance string — meters for short range, km for longer (Section 7). */
    fun formatDistance(meters: Double): String = if (meters < 1000) "${meters.toInt()} m" else "%.1f km".format(meters / 1000)

    fun isValidCoordinate(lat: Double, lng: Double): Boolean = lat in -90.0..90.0 && lng in -180.0..180.0

    enum class LocationQuality { EXCELLENT, GOOD, ACCEPTABLE, WEAK, UNRELIABLE, UNKNOWN }
    enum class LocationFreshness { LIVE, RECENT, STALE, EXPIRED }
    enum class VerificationStatus { NOT_CAPTURED, PENDING_VERIFICATION, VERIFIED, REJECTED, SUSPICIOUS, NEEDS_RECAPTURE }
    enum class VisitVerificationResult {
        VERIFIED, VERIFIED_WITH_WARNING, OUTSIDE_RADIUS, WEAK_GPS, STALE_LOCATION,
        MOCK_LOCATION_SUSPECTED, UNASSIGNED_RETAILER, UNSCHEDULED_VISIT,
        SUSPICIOUS_MOVEMENT, MANAGER_OVERRIDE, REJECTED,
    }

    /**
     * Centralized, configurable thresholds (Section 3/4/25) — "Do not
     * hardcode thresholds throughout the app." Every classification
     * function below takes these as a parameter (with this as the
     * default), so a company can tune them in one place (LocationSettings,
     * once persisted) without touching classification logic anywhere.
     */
    data class Thresholds(
        val excellentMaxMeters: Float = 10f,
        val goodMaxMeters: Float = 20f,
        val acceptableMaxMeters: Float = 40f,
        val weakMaxMeters: Float = 100f,
        val liveMaxSeconds: Long = 30,
        val recentMaxSeconds: Long = 120,
        val staleMaxSeconds: Long = 600,
        val impossibleSpeedKmh: Double = 150.0, // faster than this between two consecutive points is flagged, not automatically rejected
        val defaultVisitRadiusMeters: Double = 100.0,
    )

    fun classifyQuality(accuracyMeters: Float?, thresholds: Thresholds = Thresholds()): LocationQuality {
        if (accuracyMeters == null || accuracyMeters < 0f) return LocationQuality.UNKNOWN
        return when {
            accuracyMeters <= thresholds.excellentMaxMeters -> LocationQuality.EXCELLENT
            accuracyMeters <= thresholds.goodMaxMeters -> LocationQuality.GOOD
            accuracyMeters <= thresholds.acceptableMaxMeters -> LocationQuality.ACCEPTABLE
            accuracyMeters <= thresholds.weakMaxMeters -> LocationQuality.WEAK
            else -> LocationQuality.UNRELIABLE
        }
    }

    fun classifyFreshness(ageSeconds: Long, thresholds: Thresholds = Thresholds()): LocationFreshness = when {
        ageSeconds <= thresholds.liveMaxSeconds -> LocationFreshness.LIVE
        ageSeconds <= thresholds.recentMaxSeconds -> LocationFreshness.RECENT
        ageSeconds <= thresholds.staleMaxSeconds -> LocationFreshness.STALE
        else -> LocationFreshness.EXPIRED
    }

    /** Real speed-based impossible-movement check (Section 10) — deterministic, not fake AI. */
    data class MovementCheck(val distanceMeters: Double, val timeDiffSeconds: Long, val speedKmh: Double, val suspicious: Boolean)
    fun checkMovement(lat1: Double, lng1: Double, t1EpochMillis: Long, lat2: Double, lng2: Double, t2EpochMillis: Long, thresholds: Thresholds = Thresholds()): MovementCheck {
        val distance = distanceMeters(lat1, lng1, lat2, lng2)
        val timeDiffSeconds = ((t2EpochMillis - t1EpochMillis) / 1000).coerceAtLeast(1)
        val speedKmh = (distance / 1000.0) / (timeDiffSeconds / 3600.0)
        return MovementCheck(distance, timeDiffSeconds, speedKmh, speedKmh > thresholds.impossibleSpeedKmh)
    }

    /**
     * Deterministic visit-verification scoring (Section 8) — transparent,
     * rule-based, never a black-box score. Each factor either passes or
     * contributes a specific, explainable penalty.
     */
    data class VerificationScoreInput(
        val accuracyMeters: Float?, val distanceFromRetailerMeters: Double?, val visitRadiusMeters: Double,
        val ageSeconds: Long, val mockSuspected: Boolean, val isAssignedRetailer: Boolean, val isScheduledVisit: Boolean,
    )
    data class VerificationScoreResult(val score: Int, val result: VisitVerificationResult, val reasons: List<String>)

    fun computeVisitVerification(input: VerificationScoreInput, thresholds: Thresholds = Thresholds()): VerificationScoreResult {
        var score = 100
        val reasons = mutableListOf<String>()

        if (input.mockSuspected) {
            return VerificationScoreResult(0, VisitVerificationResult.MOCK_LOCATION_SUSPECTED, listOf("Mock location provider detected"))
        }
        val quality = classifyQuality(input.accuracyMeters, thresholds)
        if (quality == LocationQuality.UNRELIABLE || quality == LocationQuality.UNKNOWN) {
            score -= 40; reasons += "GPS accuracy unreliable (${input.accuracyMeters ?: "unknown"}m)"
        } else if (quality == LocationQuality.WEAK) {
            score -= 20; reasons += "GPS accuracy weak (${input.accuracyMeters}m)"
        }

        val freshness = classifyFreshness(input.ageSeconds, thresholds)
        if (freshness == LocationFreshness.EXPIRED) {
            return VerificationScoreResult(0, VisitVerificationResult.STALE_LOCATION, listOf("Location expired (${input.ageSeconds}s old)"))
        } else if (freshness == LocationFreshness.STALE) {
            score -= 25; reasons += "Location stale (${input.ageSeconds}s old)"
        }

        if (input.distanceFromRetailerMeters != null && input.distanceFromRetailerMeters > input.visitRadiusMeters) {
            score -= 35; reasons += "Outside retailer radius (${input.distanceFromRetailerMeters.toInt()}m > ${input.visitRadiusMeters.toInt()}m)"
        }
        if (!input.isAssignedRetailer) { score -= 15; reasons += "Retailer not assigned to this employee" }
        if (!input.isScheduledVisit) { score -= 5; reasons += "Visit not on scheduled route" }

        score = score.coerceIn(0, 100)
        val result = when {
            input.distanceFromRetailerMeters != null && input.distanceFromRetailerMeters > input.visitRadiusMeters -> VisitVerificationResult.OUTSIDE_RADIUS
            quality == LocationQuality.UNRELIABLE || quality == LocationQuality.UNKNOWN -> VisitVerificationResult.WEAK_GPS
            !input.isAssignedRetailer -> VisitVerificationResult.UNASSIGNED_RETAILER
            !input.isScheduledVisit -> VisitVerificationResult.UNSCHEDULED_VISIT
            score >= 90 -> VisitVerificationResult.VERIFIED
            else -> VisitVerificationResult.VERIFIED_WITH_WARNING
        }
        return VerificationScoreResult(score, result, reasons)
    }
}
