package com.abm.erp.ui.dealer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.data.DealerOrderRecord
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

private val DEALER_PRODUCTS = listOf("ABM Masala Tea 1kg", "ABM Tea Classic 1kg")

class DealerHomeViewModel : ViewModel() {
    val dealers = MockRepository.dealers
    val dealerOrders = FirebaseSync.dealerOrders
    fun submitDealerOrder(dealerId: String, dealerName: String, product: String, qty: Int) =
        FirebaseSync.submitDealerOrder(dealerId, dealerName, product, qty)
    fun submitHelpdeskTicket(fromId: String, fromName: String, fromType: String, subject: String, message: String) =
        FirebaseSync.submitHelpdeskTicket(fromId, fromName, fromType, subject, message)
}

@Composable
fun DealerHomeScreen(dealerId: String, onLogout: () -> Unit, vm: DealerHomeViewModel = viewModel()) {
    val dealer = vm.dealers.collectAsState().value.firstOrNull { it.id == dealerId }
    val allOrders by vm.dealerOrders.collectAsState()
    val myOrders = allOrders.filter { it.dealerId == dealerId }.sortedByDescending { it.createdAtMillis }

    var product by remember { mutableStateOf(DEALER_PRODUCTS.first()) }
    var qtyText by remember { mutableStateOf("") }
    var productMenuOpen by remember { mutableStateOf(false) }
    var justSubmitted by remember { mutableStateOf(false) }

    var showHelp by remember { mutableStateOf(false) }
    var helpSubject by remember { mutableStateOf("") }
    var helpMessage by remember { mutableStateOf("") }
    var helpJustSent by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().background(Color(0xFF1E6FA8)).padding(16.dp)) {
            Text("Dealer Portal", color = Color(0xFFE4EEF6), style = MaterialTheme.typography.labelSmall)
            Text(dealer?.name ?: "Dealer", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Text(dealer?.zone ?: "", color = Color(0xFFE4EEF6), style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onLogout) { Text("Logout", color = Color.White) }
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        ) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Place a new order", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Box {
                    OutlinedButton(onClick = { productMenuOpen = true }, modifier = Modifier.fillMaxWidth()) { Text(product) }
                    DropdownMenu(expanded = productMenuOpen, onDismissRequest = { productMenuOpen = false }) {
                        DEALER_PRODUCTS.forEach { p ->
                            DropdownMenuItem(text = { Text(p) }, onClick = { product = p; productMenuOpen = false })
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Quantity") }, modifier = Modifier.fillMaxWidth())
                if (justSubmitted) {
                    Spacer(Modifier.height(6.dp))
                    Text("✓ Order sent to your Area Manager for approval.", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val qty = qtyText.toIntOrNull() ?: return@Button
                        if (qty <= 0 || dealer == null) return@Button
                        vm.submitDealerOrder(dealer.id, dealer.name, product, qty)
                        qtyText = ""
                        justSubmitted = true
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Submit order") }
            }

            Spacer(Modifier.height(16.dp))
            Text("My orders", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            if (myOrders.isEmpty()) {
                Text("No orders placed yet.", color = TextSecondary)
            }
            myOrders.forEach { o -> DealerOrderRow(o); Spacer(Modifier.height(8.dp)) }

            Spacer(Modifier.height(16.dp))
            Text("Need help?", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                if (!showHelp) {
                    OutlinedButton(onClick = { showHelp = true; helpJustSent = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("🎧 Raise a support ticket")
                    }
                } else {
                    OutlinedTextField(value = helpSubject, onValueChange = { helpSubject = it }, label = { Text("Subject") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = helpMessage, onValueChange = { helpMessage = it }, label = { Text("What's the problem?") }, modifier = Modifier.fillMaxWidth())
                    if (helpJustSent) {
                        Spacer(Modifier.height(6.dp))
                        Text("✓ Sent — staff will get back to you soon.", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (helpSubject.isBlank() || dealer == null) return@Button
                                vm.submitHelpdeskTicket(dealer.id, dealer.name, "Dealer", helpSubject, helpMessage)
                                helpSubject = ""; helpMessage = ""; helpJustSent = true
                            },
                        ) { Text("Send") }
                        OutlinedButton(onClick = { showHelp = false }) { Text("Close") }
                    }
                }
            }
        }
    }
}

@Composable
private fun DealerOrderRow(o: DealerOrderRecord) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(o.product, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            val color = when (o.status) { "Approved" -> SuccessGreen; "Rejected" -> DangerRed; else -> WarningAmber }
            Text(o.status, color = color, style = MaterialTheme.typography.labelSmall)
        }
        Text("Qty: ${o.qty}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    }
}
