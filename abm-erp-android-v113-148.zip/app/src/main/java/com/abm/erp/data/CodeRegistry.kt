package com.abm.erp.data

/**
 * Universal QR/Barcode Registry — the ONE place a scanned/typed code gets
 * resolved to a real entity. Type-agnostic: it looks at the code's own
 * prefix to decide what it IS, then validates it actually resolves to
 * exactly one real record.
 *
 * Extended (this pass) to cover all 6 required scan types:
 * Employee, Retailer, Dealer, Product/Carton, Production Batch,
 * Warehouse/Delivery — CARTON and PRODUCTION_BATCH previously matched
 * nothing real (CARTON wasn't resolved at all; PRODUCTION_BATCH and
 * WAREHOUSE_TRANSFER didn't exist as types), so scanning them silently
 * did nothing useful.
 */
object CodeRegistry {
    enum class CodeType { DEALER, EMPLOYEE, RETAILER, CARTON, PRODUCTION_BATCH, WAREHOUSE_TRANSFER, INVOICE, COLLECTION, PRODUCT, DELIVERY, UNKNOWN }

    sealed class ResolveResult {
        data class Found(val type: CodeType, val id: String, val label: String, val extra: String? = null) : ResolveResult()
        data class Ambiguous(val matches: List<Pair<CodeType, String>>) : ResolveResult() // same code string resolves to more than one real record — a real data-integrity problem, surfaced rather than silently picking one
        object NotFound : ResolveResult()
        object Invalid : ResolveResult() // blank/malformed input — never silently treated as "not found"
    }

    /** Detects the likely type from the code's own prefix convention. Doesn't guarantee the code is real — resolve() does that. */
    fun detectType(code: String): CodeType {
        val trimmed = code.trim().uppercase()
        return when {
            trimmed.isBlank() -> CodeType.UNKNOWN
            trimmed.startsWith("ABM-DLR-") || trimmed.startsWith("ABM-DEALER") -> CodeType.DEALER
            trimmed.startsWith("RTL-") || trimmed.startsWith("ABM-RETAILER") -> CodeType.RETAILER
            trimmed.startsWith("CTN-") -> CodeType.CARTON
            trimmed.contains("PRODUCTION_BATCH") -> CodeType.PRODUCTION_BATCH
            trimmed.contains("WAREHOUSE_TRANSFER") -> CodeType.WAREHOUSE_TRANSFER
            trimmed.contains("INVOICE") -> CodeType.INVOICE
            trimmed.contains("COLLECTION") -> CodeType.COLLECTION
            trimmed.contains("DELIVERY") -> CodeType.DELIVERY
            trimmed.startsWith("ABM-") -> CodeType.EMPLOYEE // ABM-{DEPT}-{ROLE}-#### — any other ABM- prefix is an employee code
            else -> CodeType.UNKNOWN
        }
    }

    /**
     * Resolves a scanned/typed code against the REAL, currently-loaded
     * data (never a placeholder or fabricated match). Detects cross-type
     * collisions (the same literal code string matching more than one
     * entity type or more than one record) rather than silently
     * returning the first hit.
     */
    fun resolve(code: String): ResolveResult {
        val trimmed = code.trim()
        if (trimmed.isBlank()) return ResolveResult.Invalid
        val myCompanyId = MockRepository.currentUser.companyId

        val dealerMatches = MockRepository.dealers.value.filter { !it.isDeleted && (it.dealerCode == trimmed || it.id == trimmed) }
        val employeeMatches = MockRepository.employeeProfiles.value.filter { !it.isDeleted && it.companyId == myCompanyId && (it.employeeCode == trimmed || it.id == trimmed) }
        val retailerMatches = MockRepository.retailers.value.filter { !it.isDeleted && (it.retailerCode == trimmed || it.id == trimmed) }
        // Carton codes are "CTN-{batchNumber}-{sequence}" (see QrCodeGenerator.cartonCode) — the carton itself
        // isn't a standalone entity, it resolves to the production batch that made it, plus the carton sequence.
        val cartonBatchNumber = if (trimmed.startsWith("CTN-")) {
            val withoutPrefix = trimmed.removePrefix("CTN-")
            val lastDash = withoutPrefix.lastIndexOf('-')
            if (lastDash > 0) withoutPrefix.substring(0, lastDash) else null
        } else null
        val cartonMatches = cartonBatchNumber?.let { batchNo -> MockRepository.productionPlans.value.filter { it.companyId == myCompanyId && it.batchNumber == batchNo } } ?: emptyList()
        val productionBatchMatches = MockRepository.productionPlans.value.filter { it.companyId == myCompanyId && (it.batchNumber == trimmed || it.id == trimmed) }
        val warehouseTransferMatches = MockRepository.warehouseTransfers.value.filter { it.companyId == myCompanyId && (it.transferNumber == trimmed || it.id == trimmed) }
        val invoiceMatches = MockRepository.salesInvoices.value.filter { !it.isDeleted && (it.invoiceNo == trimmed || it.id == trimmed) }
        val collectionMatches = MockRepository.partyCollections.value.filter { it.collectionNo == trimmed || it.id == trimmed }
        val productMatches = com.abm.erp.data.InventoryRepository.products.value.filter { it.sku == trimmed || it.id == trimmed }
        val deliveryMatches = MockRepository.deliveryChallans.value.filter { it.challanNo == trimmed || it.id == trimmed }

        val allMatches = dealerMatches.map { CodeType.DEALER to it.id } +
            employeeMatches.map { CodeType.EMPLOYEE to it.id } +
            retailerMatches.map { CodeType.RETAILER to it.id } +
            cartonMatches.map { CodeType.CARTON to it.id } +
            productionBatchMatches.map { CodeType.PRODUCTION_BATCH to it.id } +
            warehouseTransferMatches.map { CodeType.WAREHOUSE_TRANSFER to it.id } +
            invoiceMatches.map { CodeType.INVOICE to it.id } +
            collectionMatches.map { CodeType.COLLECTION to it.id } +
            productMatches.map { CodeType.PRODUCT to it.id } +
            deliveryMatches.map { CodeType.DELIVERY to it.id }

        return when {
            allMatches.isEmpty() -> ResolveResult.NotFound
            allMatches.size > 1 -> ResolveResult.Ambiguous(allMatches) // same code matched more than one real record across types — real conflict, not resolved silently
            else -> {
                val (type, id) = allMatches.first()
                when (type) {
                    CodeType.DEALER -> ResolveResult.Found(type, id, dealerMatches.first().name)
                    CodeType.EMPLOYEE -> ResolveResult.Found(type, id, employeeMatches.first().fullName)
                    CodeType.RETAILER -> ResolveResult.Found(type, id, retailerMatches.first().name)
                    CodeType.CARTON -> {
                        val plan = cartonMatches.first()
                        ResolveResult.Found(type, plan.id, "${plan.batchNumber} — carton", extra = trimmed)
                    }
                    CodeType.PRODUCTION_BATCH -> ResolveResult.Found(type, id, productionBatchMatches.first().batchNumber)
                    CodeType.WAREHOUSE_TRANSFER -> ResolveResult.Found(type, id, warehouseTransferMatches.first().transferNumber)
                    CodeType.INVOICE -> ResolveResult.Found(type, id, invoiceMatches.first().invoiceNo)
                    CodeType.COLLECTION -> ResolveResult.Found(type, id, collectionMatches.first().collectionNo)
                    CodeType.PRODUCT -> ResolveResult.Found(type, id, productMatches.first().name)
                    CodeType.DELIVERY -> ResolveResult.Found(type, id, deliveryMatches.first().challanNo)
                    CodeType.UNKNOWN -> ResolveResult.Found(type, id, "?")
                }
            }
        }
    }
}

/**
 * Bridge from the secure QR registry to the scanner's existing display layer.
 *
 * `QrRegistry.resolve()` has already done the security work — company isolation,
 * token match, status, expiry, permission. All that remains is to find the human
 * label for a record whose type and id are already known and already authorised.
 * This performs **no matching and no guessing**: it is a direct lookup by id.
 */
fun CodeRegistry.resolveRegistered(entityType: String, entityId: String): CodeRegistry.ResolveResult {
    fun found(type: CodeRegistry.CodeType, label: String, extra: String? = null) =
        CodeRegistry.ResolveResult.Found(type, entityId, label, extra)

    return when (entityType) {
        "Dealer" -> MockRepository.dealers.value.firstOrNull { it.id == entityId }
            ?.let { found(CodeRegistry.CodeType.DEALER, it.name) } ?: CodeRegistry.ResolveResult.NotFound
        "Retailer" -> MockRepository.retailers.value.firstOrNull { it.id == entityId }
            ?.let { found(CodeRegistry.CodeType.RETAILER, it.name) } ?: CodeRegistry.ResolveResult.NotFound
        "Employee", "EmployeeProfile" -> MockRepository.employeeProfiles.value.firstOrNull { it.id == entityId }
            ?.let { found(CodeRegistry.CodeType.EMPLOYEE, it.fullName) } ?: CodeRegistry.ResolveResult.NotFound
        "SalesInvoice", "Invoice" -> MockRepository.salesInvoices.value.firstOrNull { it.id == entityId }
            ?.let { found(CodeRegistry.CodeType.INVOICE, it.invoiceNo) } ?: CodeRegistry.ResolveResult.NotFound
        "Collection", "PartyCollection" -> MockRepository.partyCollections.value.firstOrNull { it.id == entityId }
            ?.let { found(CodeRegistry.CodeType.COLLECTION, it.collectionNo) } ?: CodeRegistry.ResolveResult.NotFound
        "Product" -> InventoryRepository.products.value.firstOrNull { it.id == entityId }
            ?.let { found(CodeRegistry.CodeType.PRODUCT, it.name) } ?: CodeRegistry.ResolveResult.NotFound
        "ProductionBatch", "ProductionPlan" -> MockRepository.productionPlans.value.firstOrNull { it.id == entityId }
            ?.let { found(CodeRegistry.CodeType.PRODUCTION_BATCH, it.batchNumber) } ?: CodeRegistry.ResolveResult.NotFound
        "WarehouseTransfer" -> MockRepository.warehouseTransfers.value.firstOrNull { it.id == entityId }
            ?.let { found(CodeRegistry.CodeType.WAREHOUSE_TRANSFER, it.transferNumber) } ?: CodeRegistry.ResolveResult.NotFound
        "Delivery", "DeliveryChallan" -> MockRepository.deliveryChallans.value.firstOrNull { it.id == entityId }
            ?.let { found(CodeRegistry.CodeType.DELIVERY, it.challanNo) } ?: CodeRegistry.ResolveResult.NotFound
        "Carton" -> found(CodeRegistry.CodeType.CARTON, entityId)
        else -> CodeRegistry.ResolveResult.NotFound
    }
}
