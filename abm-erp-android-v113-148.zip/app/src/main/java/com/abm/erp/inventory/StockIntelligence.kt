package com.abm.erp.inventory

import java.time.LocalDateTime

/**
 * Foundation 5 — Smart Stock Intelligence & Demand Prediction. Every
 * calculation here is deterministic, explainable business math from real
 * ERP data (sales history, stock levels, lots) — never a fake AI/random
 * prediction, per the spec's explicit instruction.
 */
object StockIntelligence {

    data class Thresholds(
        val safetyStockDays: Int = 7,
        val minSafetyStockDays: Int = 3,
        val criticalSafetyStockDays: Int = 1,
        val leadTimeDays: Int = 5,
        val deadStockDays: Int = 90,
        val slowMovingDays: Int = 45,
        val veryFastMovingDailyRatio: Double = 0.1,
        val expiryWarningDays: Int = 30,
    )

    enum class MovementClass { VERY_FAST, FAST, NORMAL, SLOW, VERY_SLOW, DEAD }
    enum class ExpiryStatus { FRESH, NEAR_EXPIRY, EXPIRED }
    enum class StockHealth { HEALTHY, WARNING, CRITICAL, OVERSTOCK, DEAD }

    data class ConsumptionRate(val dailyAvg: Double, val weeklyAvg: Double, val monthlyAvg: Double, val sampleDays: Int)

    fun computeConsumptionRate(dispatchedQuantities: List<Pair<LocalDateTime, Double>>, windowDays: Int = 90): ConsumptionRate {
        val now = LocalDateTime.now()
        val inWindow = dispatchedQuantities.filter { it.first.isAfter(now.minusDays(windowDays.toLong())) }
        val totalQty = inWindow.sumOf { it.second }
        val actualSampleDays = if (inWindow.isEmpty()) 0 else {
            val oldest = inWindow.minOf { it.first }
            java.time.Duration.between(oldest, now).toDays().toInt().coerceAtLeast(1)
        }
        val dailyAvg = if (actualSampleDays == 0) 0.0 else totalQty / actualSampleDays
        return ConsumptionRate(dailyAvg, dailyAvg * 7, dailyAvg * 30, actualSampleDays)
    }

    data class StockOutPrediction(val daysRemaining: Double?, val expectedStockOutDate: LocalDateTime?)

    fun predictStockOut(availableStock: Double, consumption: ConsumptionRate): StockOutPrediction {
        if (consumption.dailyAvg <= 0.0) return StockOutPrediction(null, null)
        val days = availableStock / consumption.dailyAvg
        return StockOutPrediction(days, LocalDateTime.now().plusDays(days.toLong()))
    }

    data class SafetyStockLevels(val minimum: Double, val recommended: Double, val critical: Double, val emergency: Double)

    fun computeSafetyStock(consumption: ConsumptionRate, thresholds: Thresholds = Thresholds()): SafetyStockLevels = SafetyStockLevels(
        minimum = consumption.dailyAvg * thresholds.minSafetyStockDays,
        recommended = consumption.dailyAvg * thresholds.safetyStockDays,
        critical = consumption.dailyAvg * thresholds.criticalSafetyStockDays,
        emergency = consumption.dailyAvg * 0.5,
    )

    fun computeReorderQuantity(
        forecastDemand: Double, safetyStock: Double, leadTimeDays: Int, dailyConsumption: Double,
        availableStock: Double, incomingPurchaseQty: Double, productionPipelineQty: Double,
    ): Double {
        val leadTimeRequirement = dailyConsumption * leadTimeDays
        val raw = forecastDemand + safetyStock + leadTimeRequirement - availableStock - incomingPurchaseQty - productionPipelineQty
        return raw.coerceAtLeast(0.0)
    }

    fun classifyMovement(consumption: ConsumptionRate, currentStock: Double, daysSinceLastMovement: Long?, thresholds: Thresholds = Thresholds()): MovementClass {
        if (daysSinceLastMovement != null && daysSinceLastMovement >= thresholds.deadStockDays) return MovementClass.DEAD
        if (consumption.dailyAvg <= 0.0) return if (daysSinceLastMovement != null && daysSinceLastMovement >= thresholds.slowMovingDays) MovementClass.VERY_SLOW else MovementClass.SLOW
        val ratio = if (currentStock > 0) consumption.dailyAvg / currentStock else 0.0
        return when {
            ratio >= thresholds.veryFastMovingDailyRatio -> MovementClass.VERY_FAST
            ratio >= thresholds.veryFastMovingDailyRatio / 2 -> MovementClass.FAST
            daysSinceLastMovement != null && daysSinceLastMovement >= thresholds.slowMovingDays -> MovementClass.VERY_SLOW
            ratio < thresholds.veryFastMovingDailyRatio / 10 -> MovementClass.SLOW
            else -> MovementClass.NORMAL
        }
    }

    fun classifyExpiry(expiryDate: LocalDateTime?, thresholds: Thresholds = Thresholds()): ExpiryStatus {
        if (expiryDate == null) return ExpiryStatus.FRESH
        val now = LocalDateTime.now()
        return when {
            expiryDate.isBefore(now) -> ExpiryStatus.EXPIRED
            expiryDate.isBefore(now.plusDays(thresholds.expiryWarningDays.toLong())) -> ExpiryStatus.NEAR_EXPIRY
            else -> ExpiryStatus.FRESH
        }
    }

    fun <T> fefoOrder(lots: List<T>, expiryOf: (T) -> LocalDateTime?): List<T> = lots.sortedWith(compareBy(nullsLast()) { expiryOf(it) })

    fun classifyStockHealth(currentStock: Double, reorderLevel: Double, maxLevel: Double, movementClass: MovementClass): StockHealth = when {
        movementClass == MovementClass.DEAD -> StockHealth.DEAD
        currentStock <= 0 -> StockHealth.CRITICAL
        currentStock < reorderLevel * 0.5 -> StockHealth.CRITICAL
        currentStock < reorderLevel -> StockHealth.WARNING
        maxLevel > 0 && currentStock > maxLevel -> StockHealth.OVERSTOCK
        else -> StockHealth.HEALTHY
    }
}
