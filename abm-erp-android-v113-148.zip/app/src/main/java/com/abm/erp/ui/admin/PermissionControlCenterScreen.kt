package com.abm.erp.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abm.erp.data.*

/** Chairman-only. "No one is above the Chairman" — every mutating action here re-checks PermissionManager's own requireChairman() gate server/repo-side too, so this screen isn't the only line of defense. */
@Composable
fun PermissionControlCenterScreen() {
    val currentUser = MockRepository.currentUser
    if (currentUser.role != UserRole.CHAIRMAN) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("এই স্ক্রিন শুধু Chairman-এর জন্য।")
        }
        return
    }
    var selectedTemplateKey by remember { mutableStateOf<String?>(null) }
    var selectedEmployeeId by remember { mutableStateOf<String?>(null) }
    val employees by MockRepository.employeeProfiles.collectAsState()
    val overrides by MockRepository.employeePermissionOverrides.collectAsState()
    val templates = PermissionManager.allTemplates()

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Permission Control Center", style = MaterialTheme.typography.titleLarge)
        Text("Templates তৈরি/সম্পাদনা/assign করুন, বা individual employee-এর জন্য override দিন।", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(10.dp))

        Text("Templates", style = MaterialTheme.typography.titleMedium)
        LazyColumn(Modifier.heightIn(max = 220.dp)) {
            items(templates) { t ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("${t.label} (${t.roleKey})", modifier = Modifier.weight(1f))
                    Row {
                        TextButton(onClick = { selectedTemplateKey = t.roleKey }) { Text("Edit") }
                        TextButton(onClick = {
                            PermissionManager.duplicateTemplate(t.roleKey, "${t.roleKey}_COPY_${System.currentTimeMillis() % 10000}", "${t.label} (copy)")
                        }) { Text("Duplicate") }
                        if (UserRole.values().none { it.name == t.roleKey }) {
                            TextButton(onClick = { PermissionManager.deleteTemplate(t.roleKey) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
        Button(onClick = {
            val key = "CUSTOM_${System.currentTimeMillis() % 100000}"
            PermissionManager.createTemplate(key, "New Custom Template", MODULES.map { it.key.toModulePermissionHide() })
        }) { Text("+ New Custom Template") }

        Spacer(Modifier.height(14.dp))
        selectedTemplateKey?.let { key ->
            val def = templates.firstOrNull { it.roleKey == key }
            if (def != null) {
                Text("Editing: ${def.label}", style = MaterialTheme.typography.titleMedium)
                Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                    MODULES.forEach { m ->
                        val perm = def.modulePermissions.firstOrNull { it.moduleKey == m.key }
                        val level = perm.toAccessLevel()
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(m.key, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            AccessLevel.values().forEach { lvl ->
                                FilterChip(
                                    selected = level == lvl, label = { Text(lvl.name.take(4), style = MaterialTheme.typography.labelSmall) },
                                    onClick = {
                                        val updated = def.modulePermissions.filter { it.moduleKey != m.key } + lvl.toModulePermission(m.key)
                                        PermissionManager.updateTemplate(key, updated)
                                    },
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        Text("Assign Template to Employees", style = MaterialTheme.typography.titleMedium)
        var bulkTargetTemplate by remember { mutableStateOf<String?>(null) }
        var selectedEmployeeIds by remember { mutableStateOf<Set<String>>(emptySet()) }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            templates.forEach { t -> FilterChip(selected = bulkTargetTemplate == t.roleKey, onClick = { bulkTargetTemplate = t.roleKey }, label = { Text(t.roleKey, style = MaterialTheme.typography.labelSmall) }) }
        }
        LazyColumn(Modifier.heightIn(max = 200.dp)) {
            items(employees.filter { !it.isDeleted }) { e ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = e.id in selectedEmployeeIds, onCheckedChange = { c -> selectedEmployeeIds = if (c) selectedEmployeeIds + e.id else selectedEmployeeIds - e.id })
                    Text("${e.fullName} — template: ${e.assignedTemplateKey ?: "(role default)"}", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { selectedEmployeeId = e.id }) { Text("Overrides") }
                }
            }
        }
        Button(onClick = { bulkTargetTemplate?.let { PermissionManager.assignTemplateToEmployees(it, selectedEmployeeIds.toList()) } }, enabled = bulkTargetTemplate != null && selectedEmployeeIds.isNotEmpty()) {
            Text("Assign Selected")
        }

        Spacer(Modifier.height(14.dp))
        selectedEmployeeId?.let { empId ->
            val emp = employees.firstOrNull { it.id == empId }
            if (emp != null) {
                Text("Overrides — ${emp.fullName}", style = MaterialTheme.typography.titleMedium)
                Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                    MODULES.forEach { m ->
                        val ov = overrides.firstOrNull { it.employeeId == empId && it.moduleKey == m.key }
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(m.key, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            AccessLevel.values().forEach { lvl ->
                                FilterChip(selected = ov?.accessLevel == lvl, label = { Text(lvl.name.take(4), style = MaterialTheme.typography.labelSmall) }, onClick = { PermissionManager.setEmployeeOverride(empId, m.key, lvl) })
                            }
                            if (ov != null) TextButton(onClick = { PermissionManager.clearEmployeeOverride(empId, m.key) }) { Text("Clear") }
                        }
                    }
                }
            }
        }
    }
}

private fun ModulePermission?.toAccessLevel(): AccessLevel = when {
    this == null || !canView -> AccessLevel.HIDE
    canCreate || canEdit || canDelete || canApprove || canExport -> AccessLevel.FULL_ACCESS
    else -> AccessLevel.VIEW_ONLY
}

private fun String.toModulePermissionHide(): ModulePermission = ModulePermission(this, canView = false)
