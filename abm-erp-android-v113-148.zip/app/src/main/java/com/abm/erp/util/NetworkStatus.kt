package com.abm.erp.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.core.content.ContextCompat
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Best-effort single GPS fix for login-time anomaly/geo-block checks (staff AND dealer login). Returns null on any failure — this must never block login by itself. */
suspend fun tryGetLoginLocation(context: Context): Pair<Double, Double>? {
    val granted = ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) ==
        android.content.pm.PackageManager.PERMISSION_GRANTED
    if (!granted) return null
    return try {
        suspendCancellableCoroutine { cont ->
            @Suppress("MissingPermission")
            com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(context).lastLocation
                .addOnSuccessListener { loc -> cont.resume(loc?.let { it.latitude to it.longitude }) }
                .addOnFailureListener { if (cont.isActive) cont.resume(null) }
        }
    } catch (e: Exception) {
        null
    }
}

object NetworkStatus {
    fun isOnline(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}

/**
 * Approximate division-level anomaly check. There's no real district/upazila
 * boundary data available (that would need actual GIS polygons), so this
 * uses each division's administrative-city coordinates and a distance
 * threshold — coarse, but catches genuinely wild anomalies (someone assigned
 * to Rangpur logging in from Chattogram), which is the actual goal here:
 * flagging for a human to look at, not an automatic block.
 */
object LocationAnomalyChecker {
    // (lat, lng) of each divisional headquarters city — stable, public, well-documented coordinates.
    private val DIVISION_CENTROIDS: Map<String, Pair<Double, Double>> = mapOf(
        "Dhaka" to (23.8103 to 90.4125),
        "Chattogram" to (22.3569 to 91.7832),
        "Khulna" to (22.8456 to 89.5403),
        "Rajshahi" to (24.3745 to 88.6042),
        "Barishal" to (22.7010 to 90.3535),
        "Sylhet" to (24.8949 to 91.8687),
        "Rangpur" to (25.7439 to 89.2752),
        "Mymensingh" to (24.7471 to 90.4203),
    )

    // জেলা সদরের approximate স্থানাঙ্ক — division centroid-এর চেয়ে অনেক বেশি
    // নির্ভুল দরকার SR/TSM/ASM-এর জন্য (এদের এলাকা জেলা-স্তরের, বিভাগ-স্তরের
    // না)। এটাও approximate (district সদর শহরের কেন্দ্র, পুরো জেলার সঠিক
    // সীমানা-polygon না) — user নিজেই স্বীকার করেছেন "100% accurate লাগবে না,
    // motamuti controlled thakle hobe"।
    private val DISTRICT_CENTROIDS: Map<String, Pair<Double, Double>> = mapOf(
        // Dhaka division
        "Dhaka" to (23.8103 to 90.4125), "Gazipur" to (23.9999 to 90.4203), "Narayanganj" to (23.6238 to 90.5000),
        "Tangail" to (24.2513 to 89.9167), "Kishoreganj" to (24.4449 to 90.7861), "Manikganj" to (23.8644 to 90.0047),
        "Munshiganj" to (23.5422 to 90.5305), "Narsingdi" to (23.9223 to 90.7150), "Rajbari" to (23.7574 to 89.6444),
        "Faridpur" to (23.6070 to 89.8429), "Gopalganj" to (23.0050 to 89.8266), "Madaripur" to (23.1641 to 90.1897),
        "Shariatpur" to (23.2423 to 90.4348),
        // Chattogram division
        "Chattogram" to (22.3569 to 91.7832), "Cox's Bazar" to (21.4272 to 92.0058), "Comilla" to (23.4607 to 91.1809),
        "Feni" to (23.0159 to 91.3976), "Brahmanbaria" to (23.9571 to 91.1119), "Rangamati" to (22.6533 to 92.1732),
        "Noakhali" to (22.8696 to 91.0995), "Chandpur" to (23.2333 to 90.6667), "Lakshmipur" to (22.9447 to 90.8282),
        "Khagrachhari" to (23.1193 to 91.9847), "Bandarban" to (22.1953 to 92.2184),
        // Khulna division
        "Khulna" to (22.8456 to 89.5403), "Jashore" to (23.1667 to 89.2167), "Satkhira" to (22.7185 to 89.0705),
        "Bagerhat" to (22.6516 to 89.7857), "Narail" to (23.1725 to 89.5127), "Chuadanga" to (23.6402 to 88.8410),
        "Kushtia" to (23.9013 to 89.1206), "Meherpur" to (23.7622 to 88.6318), "Magura" to (23.4855 to 89.4198),
        "Jhenaidah" to (23.5450 to 89.1539),
        // Rajshahi division
        "Rajshahi" to (24.3745 to 88.6042), "Bogura" to (24.8465 to 89.3773), "Pabna" to (24.0064 to 89.2372),
        "Sirajganj" to (24.4533 to 89.7000), "Natore" to (24.4206 to 89.0003), "Naogaon" to (24.7936 to 88.9318),
        "Chapainawabganj" to (24.5965 to 88.2775), "Joypurhat" to (25.0968 to 89.0227),
        // Barishal division
        "Barishal" to (22.7010 to 90.3535), "Bhola" to (22.6859 to 90.6482), "Patuakhali" to (22.3596 to 90.3296),
        "Pirojpur" to (22.5841 to 89.9720), "Barguna" to (22.0953 to 90.1121), "Jhalokati" to (22.6406 to 90.1987),
        // Sylhet division
        "Sylhet" to (24.8949 to 91.8687), "Moulvibazar" to (24.4829 to 91.7774), "Habiganj" to (24.3745 to 91.4155),
        "Sunamganj" to (25.0658 to 91.3950),
        // Rangpur division
        "Rangpur" to (25.7439 to 89.2752), "Dinajpur" to (25.6279 to 88.6332), "Kurigram" to (25.8054 to 89.6362),
        "Gaibandha" to (25.3288 to 89.5289), "Lalmonirhat" to (25.9923 to 89.2847), "Nilphamari" to (25.9316 to 88.8560),
        "Panchagarh" to (26.3411 to 88.5541), "Thakurgaon" to (26.0336 to 88.4616),
        // Mymensingh division
        "Mymensingh" to (24.7471 to 90.4203), "Jamalpur" to (24.9375 to 89.9372), "Netrokona" to (24.8802 to 90.7280),
        "Sherpur" to (25.0207 to 90.0154),
    )

    private const val ANOMALY_THRESHOLD_KM = 150.0

    // SR/TSM/ASM/RSM/Dealer-এর জন্য hard-block — soft flag না, একদম আটকে দেওয়া।
    private const val HARD_BLOCK_THRESHOLD_KM = 50.0

    private fun haversineKm(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lng2 - lng1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLng / 2) * sin(dLng / 2)
        return r * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    /** True if (lat, lng) is unexpectedly far from the given division's home city. Null division = can't check, assume fine. */
    fun isAnomalous(division: String?, lat: Double, lng: Double): Boolean {
        val centroid = DIVISION_CENTROIDS[division] ?: return false
        return haversineKm(centroid.first, centroid.second, lat, lng) > ANOMALY_THRESHOLD_KM
    }

    /**
     * Hard login block for SR/TSM/ASM (district-scoped) and RSM
     * (division-scoped) — more than 50km from their own assigned area and
     * login is refused outright, not just flagged. If we can't resolve a
     * centroid for their area (missing/unrecognized name), this fails open
     * (returns false / not blocked) rather than locking someone out due to
     * a data gap.
     */
    fun isTooFarToLogin(role: String, division: String?, district: String?, lat: Double, lng: Double): Boolean {
        val centroid = when (role) {
            "SR", "TSM", "ASM" -> district?.let { DISTRICT_CENTROIDS[it] }
            "RSM", "DEALER" -> division?.let { DIVISION_CENTROIDS[it] }
            else -> null
        } ?: return false
        return haversineKm(centroid.first, centroid.second, lat, lng) > HARD_BLOCK_THRESHOLD_KM
    }
}
