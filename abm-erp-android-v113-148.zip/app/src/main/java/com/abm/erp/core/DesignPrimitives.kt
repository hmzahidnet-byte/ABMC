package com.abm.erp.core

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Blueprint §6 — Icon Style. The signature element of the design system.
 *
 * A vector icon inside a rounded-square tinted with its own accent colour.
 * Everything in the app that used to be a bare emoji (🏭 💵 📦) becomes one of
 * these, which is the single largest visual upgrade available without adding
 * any new assets — `material-icons-extended` is already a dependency.
 *
 * Sizes per blueprint: 32dp dense grid · 40dp standard · 48dp hero.
 */
@Composable
fun IconChip(
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier,
    size: Int = 40,
    contentDescription: String? = null,
) {
    Box(
        modifier = modifier
            .size(size.dp)
            .clip(RoundedCornerShape((size * 0.33f).dp))
            .background(
                Brush.linearGradient(
                    listOf(accent.copy(alpha = 0.16f), accent.copy(alpha = 0.07f)),
                ),
            ),
        contentAlignment = Alignment.Center,
    ) {
        androidx.compose.material3.Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = accent,
            modifier = Modifier.size((size * 0.5f).dp),
        )
    }
}

/**
 * Blueprint §3.3 + §20 — one status word, one fixed colour, app-wide.
 *
 * `statusColor()` is the single source of truth for what a status word looks
 * like. PENDING is amber in HR, Finance, Purchase and Approvals — identically —
 * because they all route through here rather than each screen picking its own.
 */
@Composable
fun StatusPill(status: String, modifier: Modifier = Modifier) {
    val color = statusColor(status)
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .background(color.copy(alpha = 0.12f)),
    ) {
        Text(
            text = status.uppercase(),
            color = color,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.4.sp,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
        )
    }
}

/** Blueprint §3.3 — semantic status colour map. Add new words here, never in a screen. */
fun statusColor(status: String): Color = when (status.uppercase()) {
    // green — settled, healthy, complete
    "APPROVED", "PAID", "DELIVERED", "PRESENT", "RECEIVED", "VERIFIED",
    "COMPLETED", "SYNCED", "ACTIVE", "RECONCILED", "PASS", "FULFILLED",
    "CONFIRMED", "CONVERTED", "QUALIFIED", "RESOLVED",
    -> com.abm.erp.theme.StatusGreen

    // blue — moving, informational
    "IN_PROGRESS", "IN_TRANSIT", "SUBMITTED", "SENT", "DISPATCHED",
    "PICKING", "PICKED_UP", "OUT_FOR_DELIVERY", "ROUTED", "PROCESSING",
    "NEW", "CONTACTED", "VISIT_PLANNED", "NEGOTIATION", "PROBATION",
    -> com.abm.erp.theme.StatusBlue

    // amber — waiting on someone, or nearing a threshold
    "PENDING", "MANAGER_REVIEW", "AWAITING", "LOW", "LATE",
    "PARTIALLY_RECEIVED", "PARTIALLY_PAID", "PARTIALLY_COMPLETED", "ON_LEAVE",
    "SO_LOGGED", "ASM_VERIFIED", "DEALER_ROUTED", "OPEN",
    -> com.abm.erp.theme.StatusAmber

    // red — failed, refused, or a real problem
    "REJECTED", "OVERDUE", "DAMAGED", "FAILED", "ABSENT",
    "CANCELLED", "BLOCKED", "FAIL", "OVER_LIMIT",
    "LOST", "SUSPENDED", "TERMINATED", "RESIGNED", "EXPIRED",
    -> com.abm.erp.theme.StatusRed

    // slate — inert
    "DRAFT", "ARCHIVED", "INACTIVE", "CLOSED", "DELETED", "RETIRED", "NONE", "UNSET",
    -> com.abm.erp.theme.TextSecondary

    else -> com.abm.erp.theme.TextSecondary
}

/**
 * Blueprint §19 — a KPI value's colour IS its status: a count of things that
 * need attention is amber when non-zero and green when clear, so a glance at
 * the strip reads as "anything wrong?" without reading any labels.
 */
fun attentionColor(count: Int): Color =
    if (count > 0) com.abm.erp.theme.StatusAmber else com.abm.erp.theme.StatusGreen

fun problemColor(count: Int): Color =
    if (count > 0) com.abm.erp.theme.StatusRed else com.abm.erp.theme.StatusGreen

/**
 * Blueprint §30 — Production's signature moment: the yield bar.
 *
 * Nothing else in the app uses this shape, so a screen carrying it instantly
 * reads as factory software. Thresholds match the ones the Production screens
 * already used inline (>=85% good, >=70% acceptable, below that a problem) —
 * this only moves that rule into one shared place.
 */
@Composable
fun YieldBar(percent: Double, modifier: Modifier = Modifier, height: Int = 6) {
    val clamped = percent.coerceIn(0.0, 100.0)
    val color = when {
        clamped >= 85 -> com.abm.erp.theme.StatusGreen
        clamped >= 70 -> com.abm.erp.theme.StatusAmber
        else -> com.abm.erp.theme.StatusRed
    }
    Box(
        modifier
            .fillMaxWidth()
            .height(height.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(com.abm.erp.theme.HairlineBorder),
    ) {
        Box(
            Modifier
                .fillMaxWidth((clamped / 100.0).toFloat())
                .fillMaxHeight()
                .clip(RoundedCornerShape(999.dp))
                .background(color),
        )
    }
}

/**
 * Blueprint §31 — HR's signature moment: a presence dot on every person row.
 * Green present · amber late · slate absent. One glance down a roster answers
 * "who is in today" without reading a single word.
 */
@Composable
fun PresenceDot(present: Boolean, late: Boolean = false, modifier: Modifier = Modifier, size: Int = 8) {
    val color = when {
        present && late -> com.abm.erp.theme.StatusAmber
        present -> com.abm.erp.theme.StatusGreen
        else -> com.abm.erp.theme.StatusSlate
    }
    Box(modifier.size(size.dp).clip(RoundedCornerShape(999.dp)).background(color))
}

/**
 * Blueprint §28 — Order's signature moment: the stage rail.
 * Renders the order's progress as a row of dots joined by connectors, so the
 * stage is legible as a position rather than as a word to read.
 */
@Composable
fun StageRail(stages: List<String>, currentIndex: Int, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        stages.forEachIndexed { i, stage ->
            val done = i <= currentIndex
            val color = if (done) com.abm.erp.theme.StatusGreen else com.abm.erp.theme.HairlineBorder
            Box(Modifier.size(9.dp).clip(RoundedCornerShape(999.dp)).background(color))
            if (i < stages.lastIndex) {
                Box(
                    Modifier
                        .weight(1f)
                        .height(2.dp)
                        .background(if (i < currentIndex) com.abm.erp.theme.StatusGreen else com.abm.erp.theme.HairlineBorder),
                )
            }
        }
    }
}

/**
 * Blueprint §34 — Approval's signature moment: how long a request has waited.
 * Approvals are fundamentally about latency, so the age is shown as a coloured
 * phrase rather than a raw timestamp. Amber past 2 days, red past 5.
 */
@Composable
fun WaitingAge(since: java.time.LocalDateTime, modifier: Modifier = Modifier) {
    val days = java.time.temporal.ChronoUnit.DAYS.between(since.toLocalDate(), java.time.LocalDate.now())
    val hours = java.time.temporal.ChronoUnit.HOURS.between(since, java.time.LocalDateTime.now())
    val label = when {
        days >= 1L -> "$days দিন অপেক্ষমাণ"
        hours >= 1L -> "$hours ঘণ্টা অপেক্ষমাণ"
        else -> "এইমাত্র"
    }
    val color = when {
        days >= 5L -> com.abm.erp.theme.StatusRed
        days >= 2L -> com.abm.erp.theme.StatusAmber
        else -> com.abm.erp.theme.TextSecondary
    }
    androidx.compose.material3.Text(
        label,
        modifier = modifier,
        color = color,
        style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
    )
}

/**
 * Blueprint §29/§32 — Warehouse and Finance both need figures that line up down
 * a column rather than drifting with the text beside them. Right-aligned, bold,
 * with the unit carried in the secondary colour.
 */
@Composable
fun FigureCell(value: String, unit: String? = null, color: Color = com.abm.erp.theme.TextPrimary, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
        androidx.compose.material3.Text(
            value,
            color = color,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
        )
        if (!unit.isNullOrBlank()) {
            androidx.compose.material3.Text(
                " $unit",
                color = com.abm.erp.theme.TextSecondary,
                style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            )
        }
    }
}
