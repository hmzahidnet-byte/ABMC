package com.abm.erp.core

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.DarazOrangeDark
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

/**
 * Enterprise Design System — the shared visual vocabulary.
 *
 * Every screen composes from these. A screen must never hand-roll its own card,
 * button, field or row: if a primitive can't do something, the primitive gains a
 * parameter rather than being forked. That rule is what keeps 21 modules looking
 * like one product instead of twenty-one.
 *
 * Note on naming: `core/` already contains 29 composables (GlassCard, IconChip,
 * StatusPill, ModuleWorkspaceHeader, …). Nothing here shadows those — these are
 * the pieces that were genuinely missing.
 */

/** The only spacing values permitted. Anything else is a mistake, not a decision. */
object Space {
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 24.dp
    val xxl = 32.dp
}

/** Card corner radius, one value app-wide. */
val CardRadius = 16.dp

/**
 * The signature surface. A two-layer shadow — a wide soft ambient layer plus a
 * tight contact layer — is what makes a card look *seated* rather than floating
 * on a grey halo, which is the single most common giveaway of an unpolished
 * Compose app.
 */
@Composable
fun PremiumCard(
    modifier: Modifier = Modifier,
    padding: Dp = Space.lg,
    accent: Color? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val base = modifier
        .shadow(12.dp, RoundedCornerShape(CardRadius), clip = false, ambientColor = Color(0x0D101828), spotColor = Color(0x0D101828))
        .shadow(2.dp, RoundedCornerShape(CardRadius), clip = false, ambientColor = Color(0x14101828), spotColor = Color(0x14101828))
        .clip(RoundedCornerShape(CardRadius))
        .background(Color.White)
        .border(BorderStroke(1.dp, HairlineBorder), RoundedCornerShape(CardRadius))
    Column(
        modifier = (if (onClick != null) base.clickable(onClick = onClick) else base).padding(padding),
        content = content,
    )
    // `accent` is accepted so callers can express intent uniformly; a left accent
    // bar is applied by AccentCard below rather than complicating this one.
}

/** A PremiumCard with a coloured left edge — used where a row's state matters at a glance. */
@Composable
fun AccentCard(
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Row(
        modifier
            .shadow(12.dp, RoundedCornerShape(CardRadius), clip = false, ambientColor = Color(0x0D101828), spotColor = Color(0x0D101828))
            .clip(RoundedCornerShape(CardRadius))
            .background(Color.White)
            .border(BorderStroke(1.dp, HairlineBorder), RoundedCornerShape(CardRadius))
            .let { if (onClick != null) it.clickable(onClick = onClick) else it },
    ) {
        Box(Modifier.width(4.dp).fillMaxHeight().background(accent))
        Column(Modifier.padding(Space.lg), content = content)
    }
}

/**
 * The one big number a screen exists to communicate, on a brand-gradient surface.
 * Deliberately limited to one per screen — a page with two heroes has none.
 */
@Composable
fun HeroCard(
    label: String,
    value: String,
    caption: String? = null,
    icon: ImageVector? = null,
    modifier: Modifier = Modifier,
    gradient: List<Color> = listOf(DarazOrange, DarazOrangeDark),
) {
    Box(
        modifier
            .fillMaxWidth()
            .shadow(16.dp, RoundedCornerShape(20.dp), clip = false, ambientColor = gradient.first().copy(alpha = 0.45f), spotColor = gradient.first().copy(alpha = 0.45f))
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(gradient))
            .padding(Space.xl),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label, color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(Space.xs))
                Text(value, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                if (!caption.isNullOrBlank()) {
                    Spacer(Modifier.height(Space.xs))
                    Text(caption, color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                }
            }
            if (icon != null) {
                Box(
                    Modifier.size(52.dp).background(Color.White.copy(alpha = 0.18f), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center,
                ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
            }
        }
    }
}

/**
 * One metric. The value's colour *is* its status — amber when the number is a
 * problem, green when healthy, neutral when merely informational — so a user
 * reads the state before reading the digits.
 */
@Composable
fun MetricCard(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: Color = TextPrimary,
    icon: ImageVector? = null,
    onClick: (() -> Unit)? = null,
) {
    PremiumCard(modifier = modifier, padding = Space.md, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                IconChip(icon = icon, accent = valueColor, size = 32)
                Spacer(Modifier.width(Space.sm))
            }
            Column(Modifier.weight(1f)) {
                Text(label, color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                Spacer(Modifier.height(3.dp))
                Text(value, color = valueColor, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
            if (onClick != null) {
                Icon(Icons.Filled.ChevronRight, null, tint = TextSecondary, modifier = Modifier.size(14.dp))
            }
        }
    }
}

/** Small-caps group header with generous space above it — the main tool for making a page breathe. */
@Composable
fun SectionTitle(
    text: String,
    modifier: Modifier = Modifier,
    action: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Row(
        modifier.fillMaxWidth().padding(top = Space.xl, bottom = Space.md),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom,
    ) {
        Text(
            text.uppercase(),
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.1.sp,
        )
        if (action != null && onAction != null) {
            Text(
                action,
                color = DarazOrange,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickable(onClick = onAction),
            )
        }
    }
}

/** A quick action. Icon in the brand tint, short verb, pill shape. */
@Composable
fun ActionChip(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    accent: Color = DarazOrange,
) {
    Row(
        modifier
            .clip(RoundedCornerShape(999.dp))
            .background(accent.copy(alpha = 0.10f))
            .border(BorderStroke(1.dp, accent.copy(alpha = 0.22f)), RoundedCornerShape(999.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = Space.md, vertical = Space.sm),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = accent, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** Horizontally scrolling row of ActionChips. */
@Composable
fun QuickActionRow(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    Row(
        modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(Space.sm),
        content = content,
    )
}

/** The main call to action. Full-width, brand gradient, subtle press response. */
@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    loading: Boolean = false,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, label = "btnScale")
    val active = enabled && !loading
    Box(
        modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(if (active) 10.dp else 0.dp, RoundedCornerShape(14.dp), clip = false, ambientColor = DarazOrange.copy(alpha = 0.4f), spotColor = DarazOrange.copy(alpha = 0.4f))
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (active) Brush.linearGradient(listOf(DarazOrange, DarazOrangeDark))
                else Brush.linearGradient(listOf(HairlineBorder, HairlineBorder)),
            )
            .clickable(enabled = active, interactionSource = interaction, indication = null, onClick = onClick)
            .padding(vertical = 15.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (loading) {
                CircularProgressIndicator(Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                Spacer(Modifier.width(Space.sm))
            } else if (icon != null) {
                Icon(icon, null, tint = if (active) Color.White else TextSecondary, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(Space.sm))
            }
            Text(
                text,
                color = if (active) Color.White else TextSecondary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.2.sp,
            )
        }
    }
}

/** Secondary action — same shape, no fill, so it never competes with PrimaryButton. */
@Composable
fun SecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(BorderStroke(1.5.dp, if (enabled) DarazOrange else HairlineBorder), RoundedCornerShape(14.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(icon, null, tint = if (enabled) DarazOrange else TextSecondary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(Space.sm))
            }
            Text(text, color = if (enabled) DarazOrange else TextSecondary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** Search field. Always sits directly above the list it filters. */
@Composable
fun EnterpriseSearchBar(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White)
            .border(BorderStroke(1.dp, HairlineBorder), RoundedCornerShape(14.dp))
            .padding(horizontal = Space.md, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Search, null, tint = TextSecondary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(Space.sm))
        TextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = { Text(placeholder, color = TextSecondary, fontSize = 13.sp) },
            singleLine = true,
            modifier = Modifier.weight(1f),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                disabledContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
            ),
        )
        if (value.isNotEmpty()) {
            Icon(
                Icons.Filled.Close, "Clear", tint = TextSecondary,
                modifier = Modifier.size(18.dp).clickable { onValueChange("") },
            )
        }
    }
}

/**
 * Form field. Label sits *above* the input rather than floating inside it, so it
 * stays readable once the field has content — the correct choice for data entry
 * where users check their work.
 */
@Composable
fun EnterpriseFormField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    error: String? = null,
    optional: Boolean = false,
    keyboardType: androidx.compose.ui.text.input.KeyboardType = androidx.compose.ui.text.input.KeyboardType.Text,
    singleLine: Boolean = true,
) {
    Column(modifier.fillMaxWidth()) {
        Row {
            Text(label, color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            if (optional) Text("  (optional)", color = TextSecondary, fontSize = 10.sp)
        }
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = if (placeholder.isNotBlank()) { { Text(placeholder, fontSize = 13.sp, color = TextSecondary) } } else null,
            singleLine = singleLine,
            isError = error != null,
            shape = RoundedCornerShape(12.dp),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = keyboardType),
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = DarazOrange,
                unfocusedBorderColor = HairlineBorder,
            ),
        )
        if (error != null) {
            Spacer(Modifier.height(4.dp))
            Text(error, color = com.abm.erp.theme.StatusRed, fontSize = 11.sp)
        }
    }
}

/**
 * The standard record row: icon chip · title + status · subject · facts · action.
 * Three lines maximum — anything more belongs in the record's own workspace.
 */
@Composable
fun EnterpriseListRow(
    title: String,
    subtitle: String? = null,
    meta: String? = null,
    icon: ImageVector? = null,
    accent: Color = DarazOrange,
    status: String? = null,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    PremiumCard(modifier = modifier.fillMaxWidth(), padding = Space.md, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                IconChip(icon = icon, accent = accent, size = 38)
                Spacer(Modifier.width(Space.md))
            }
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.weight(1f, fill = false))
                    if (!status.isNullOrBlank()) {
                        Spacer(Modifier.width(Space.sm))
                        StatusPill(status)
                    }
                }
                if (!subtitle.isNullOrBlank()) {
                    Spacer(Modifier.height(2.dp))
                    Text(subtitle, color = TextSecondary, fontSize = 12.sp, maxLines = 1)
                }
                if (!meta.isNullOrBlank()) {
                    Spacer(Modifier.height(2.dp))
                    Text(meta, color = TextSecondary, fontSize = 11.sp, maxLines = 1)
                }
            }
            trailing?.invoke()
        }
    }
}

/** Module-hub tile: icon chip on white, label beneath. Square, tappable, uniform. */
@Composable
fun ModuleTileCard(
    label: String,
    icon: ImageVector,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.95f else 1f, label = "tileScale")
    Column(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(8.dp, RoundedCornerShape(CardRadius), clip = false, ambientColor = Color(0x0D101828), spotColor = Color(0x0D101828))
            .clip(RoundedCornerShape(CardRadius))
            .background(Color.White)
            .border(BorderStroke(1.dp, HairlineBorder), RoundedCornerShape(CardRadius))
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(vertical = Space.md, horizontal = Space.sm),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        IconChip(icon = icon, accent = accent, size = 40)
        Spacer(Modifier.height(Space.sm))
        Text(
            label,
            color = TextSecondary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            lineHeight = 13.sp,
            maxLines = 2,
        )
    }
}
