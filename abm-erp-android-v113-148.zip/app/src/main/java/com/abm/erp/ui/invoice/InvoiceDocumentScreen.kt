package com.abm.erp.ui.invoice

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.Space
import com.abm.erp.data.MockRepository
import com.abm.erp.data.SalesInvoice
import com.abm.erp.theme.*
import kotlinx.coroutines.launch

/**
 * Invoice Document — the printable bill, rendered on screen.
 *
 * The PDF export already produced a proper document; on screen an invoice was still
 * just a list row. This is the same document, laid out for the phone, so what a user
 * sees is what they will print. Every value comes from the real `SalesInvoice` — no
 * placeholder rows, and no figure recomputed here (subTotal / discount / total are
 * the model's own computed properties, so the numbers on screen can never drift from
 * the numbers in the ledger).
 */
@Composable
fun InvoiceDocumentScreen(invoiceId: String, onBack: () -> Unit) {
    val invoices by MockRepository.salesInvoices.collectAsState()
    val invoice = invoices.firstOrNull { it.id == invoiceId }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val company = remember { MockRepository.companySettings() }
    var busy by remember { mutableStateOf(false) }

    if (invoice == null) {
        Column(Modifier.fillMaxSize().padding(Space.xl), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(80.dp))
            com.abm.erp.core.WorkspaceEmptyState("এই ইনভয়েসটি পাওয়া যায়নি।", iconVector = Icons.Filled.ReceiptLong)
            Spacer(Modifier.height(Space.lg))
            com.abm.erp.core.SecondaryButton("← ফিরে যান", onClick = onBack)
        }
        return
    }

    Column(Modifier.fillMaxSize().background(DashBg)) {

        // ── top bar ──
        Row(
            Modifier.fillMaxWidth().background(Color.White).padding(horizontal = Space.md, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back", tint = TextPrimary) }
            Column(Modifier.weight(1f)) {
                Text("Invoice", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextPrimary)
                Text(invoice.invoiceNo, fontSize = 10.sp, color = TextSecondary)
            }
            com.abm.erp.core.StatusPill(invoice.status)
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(Space.md)) {

            // ═══ THE DOCUMENT ═══
            Column(
                Modifier.fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(16.dp)),
            ) {
                // ── branded header band ──
                Row(
                    Modifier.fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(listOf(DarazOrange, DarazOrangeDark)),
                            RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
                        )
                        .padding(Space.lg),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        // Reads the Chairman's own company settings rather than a hardcoded name,
                        // so branding configured in Company Settings actually reaches the printed bill.
                        Text(
                            company.companyName.ifBlank { "ABM CORPORATION" }.uppercase(),
                            color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                        )
                        val sub = listOfNotNull(
                            company.companyAddress.ifBlank { null },
                            company.companyPhone.ifBlank { null },
                        ).joinToString(" · ").ifBlank { "Enterprise. Control. Growth." }
                        Text(sub, color = Color.White.copy(alpha = 0.85f), fontSize = 9.sp, maxLines = 2)
                    }
                    Text("INVOICE", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }

                Column(Modifier.padding(Space.lg)) {

                    // ── meta + QR verification ──
                    Row(Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            DocLabel("Invoice No")
                            DocValue(invoice.invoiceNo)
                            Spacer(Modifier.height(Space.sm))
                            DocLabel("Date")
                            DocValue(invoice.createdAt.toLocalDate().toString())
                        }
                        // v113-87 — this used to encode a legacy "INVOICE:<id>" string,
                        // which the app's OWN scanner denies ("এই QR এই সিস্টেমের নয়"):
                        // QrRegistry.resolve only accepts registry payloads, by design.
                        // Now the corner shows the registry truth. The invoice's QR is
                        // auto-ISSUED at finalisation (activateQrFor), but its secret is
                        // hash-only, so a printable payload requires an explicit
                        // (re)issue — deliberate button, never silent-on-open, so merely
                        // viewing a document can't invalidate already-printed copies.
                        var docPayload by remember(invoice.id) { mutableStateOf<String?>(null) }
                        var qrWorking by remember(invoice.id) { mutableStateOf(false) }
                        val qrScope = rememberCoroutineScope()
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            if (docPayload != null) {
                                com.abm.erp.core.QrImage(payload = docPayload!!, size = 68.dp)
                                Text("Scan to verify", fontSize = 8.sp, color = TextSecondary)
                            } else {
                                TextButton(
                                    onClick = {
                                        qrWorking = true
                                        qrScope.launch {
                                            docPayload = com.abm.erp.data.QrRegistry.issue("SalesInvoice", invoice.id)
                                            qrWorking = false
                                        }
                                    },
                                    enabled = !qrWorking,
                                ) { Text(if (qrWorking) "…" else "Print QR", fontSize = 9.sp) }
                            }
                        }
                    }

                    Spacer(Modifier.height(Space.lg))

                    // ── dealer + payment terms ──
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Space.md)) {
                        Column(Modifier.weight(1f)) {
                            DocLabel("Dealer")
                            DocValue(invoice.dealerName)
                            Text(invoice.dealerZone, fontSize = 10.sp, color = TextSecondary)
                        }
                        Column(Modifier.weight(1f)) {
                            DocLabel("Payment Terms")
                            DocValue(if (invoice.status == "PAID") "Paid" else "Credit")
                            Text(
                                "Courier: ${invoice.courier?.ifBlank { null } ?: "—"}",
                                fontSize = 10.sp, color = TextSecondary,
                            )
                        }
                    }

                    Spacer(Modifier.height(Space.lg))

                    // ── item table ──
                    Row(
                        Modifier.fillMaxWidth()
                            .background(Color(0xFF1B2430), RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                            .padding(horizontal = Space.sm, vertical = 8.dp),
                    ) {
                        Th("#", 0.10f); Th("Item / Product", 0.42f); Th("Qty", 0.13f, TextAlign.End)
                        Th("Rate", 0.17f, TextAlign.End); Th("Amount", 0.18f, TextAlign.End)
                    }
                    invoice.lineItems.forEachIndexed { i, item ->
                        Row(
                            Modifier.fillMaxWidth()
                                .background(if (i % 2 == 1) Color(0xFFF7F8FA) else Color.White)
                                .padding(horizontal = Space.sm, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Td("%02d".format(i + 1), 0.10f)
                            Column(Modifier.weight(0.42f)) {
                                Text(item.name, fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                                Text(item.unit, fontSize = 9.sp, color = TextSecondary)
                            }
                            Td("${item.qty}", 0.13f, TextAlign.End)
                            Td("৳${"%,.0f".format(item.unitPrice)}", 0.17f, TextAlign.End)
                            Td("৳${"%,.0f".format(item.lineTotal)}", 0.18f, TextAlign.End, FontWeight.SemiBold)
                        }
                    }
                    if (invoice.lineItems.isEmpty()) {
                        Text(
                            "কোনো আইটেম নেই।",
                            fontSize = 11.sp, color = TextSecondary,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
                            textAlign = TextAlign.Center,
                        )
                    }

                    Spacer(Modifier.height(Space.md))

                    // ── totals ──
                    TotalRow("Subtotal", "৳${"%,.0f".format(invoice.subTotal)}")
                    if (invoice.dealerDiscountPct > 0) {
                        TotalRow("Discount (${invoice.dealerDiscountPct}%)", "− ৳${"%,.0f".format(invoice.dealerDiscountAmt)}", StatusRed)
                    }
                    if (invoice.paidAmount > 0) {
                        TotalRow("Paid", "৳${"%,.0f".format(invoice.paidAmount)}", StatusGreen)
                    }
                    Spacer(Modifier.height(Space.sm))
                    Row(
                        Modifier.fillMaxWidth()
                            .background(Brush.horizontalGradient(listOf(DarazOrange, DarazOrangeDark)), RoundedCornerShape(10.dp))
                            .padding(horizontal = Space.md, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Total Amount", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("৳${"%,.0f".format(invoice.total)}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }

                    // ── party balance ──
                    // Snapshot values are used when present. Invoices created before v70 have
                    // none, so those fall back to the dealer's live balance and are labelled
                    // as such — showing today's figure on an old bill without saying so would
                    // be worse than showing nothing.
                    Spacer(Modifier.height(Space.md))
                    val dealers by MockRepository.dealers.collectAsState()
                    val liveDue = dealers.firstOrNull { it.id == invoice.dealerId }?.dueBalance ?: 0.0
                    val hasSnapshot = invoice.closingDueSnapshot > 0.0 || invoice.previousDueSnapshot > 0.0
                    val prevDue = if (hasSnapshot) invoice.previousDueSnapshot else (liveDue - invoice.total).coerceAtLeast(0.0)
                    val totalDue = if (hasSnapshot) invoice.closingDueSnapshot else liveDue

                    Column(
                        Modifier.fillMaxWidth()
                            .background(Color(0xFFF7F8FA), RoundedCornerShape(10.dp))
                            .padding(Space.md),
                    ) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Previous Due", fontSize = 11.sp, color = TextSecondary)
                            Text("৳${"%,.0f".format(prevDue)}", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(Modifier.height(4.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("This Invoice", fontSize = 11.sp, color = TextSecondary)
                            Text("৳${"%,.0f".format(invoice.total)}", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(Modifier.height(6.dp))
                        Box(Modifier.fillMaxWidth().height(1.dp).background(HairlineBorder))
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Due", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                            Text(
                                "৳${"%,.0f".format(totalDue)}",
                                fontSize = 14.sp,
                                color = if (totalDue > 0) StatusAmber else StatusGreen,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                        if (!hasSnapshot) {
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "* এই ইনভয়েসের সময়ের ব্যালেন্স সংরক্ষিত নেই — বর্তমান বকেয়া দেখানো হচ্ছে।",
                                fontSize = 8.sp, color = TextSecondary,
                            )
                        }
                    }

                    Spacer(Modifier.height(Space.md))
                    Text(
                        "In Words: ${amountInWords(invoice.total)}",
                        fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.Medium,
                    )

                    Spacer(Modifier.height(Space.xl))

                    // ── signatures ──
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
                        SignatureSlot("Prepared By", invoice.createdBy, Modifier.weight(1f))
                        SignatureSlot("Checked By", "", Modifier.weight(1f))
                        SignatureSlot("Authorized By", invoice.signedByRole ?: "", Modifier.weight(1f))
                    }

                    Spacer(Modifier.height(Space.lg))
                    Text(
                        "Thank you for your business!",
                        fontSize = 10.sp, color = TextSecondary,
                        modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(Space.sm))
                }
            }

            Spacer(Modifier.height(Space.lg))
        }

        // ── actions ──
        Row(
            Modifier.fillMaxWidth().background(Color.White).padding(Space.md),
            horizontalArrangement = Arrangement.spacedBy(Space.sm),
        ) {
            Box(Modifier.weight(1f)) {
                com.abm.erp.core.SecondaryButton("Share", onClick = {
                    runCatching {
                        val summary = "Invoice ${invoice.invoiceNo}\n${invoice.dealerName}\nTotal: ৳${"%,.0f".format(invoice.total)}\nStatus: ${invoice.status}"
                        val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                            type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary)
                        }
                        context.startActivity(android.content.Intent.createChooser(i, "Share invoice"))
                    }.onFailure {
                        android.widget.Toast.makeText(context, "Share করার মতো app পাওয়া যায়নি।", android.widget.Toast.LENGTH_LONG).show()
                    }
                }, icon = Icons.Filled.Share)
            }
            Box(Modifier.weight(1.4f)) {
                com.abm.erp.core.PrimaryButton(
                    text = if (busy) "তৈরি হচ্ছে…" else "Print / PDF",
                    icon = Icons.Filled.Print,
                    loading = busy,
                    onClick = {
                        busy = true
                        scope.launch {
                            // Reuses the existing PDF exporter — the on-screen document and the
                            // printed one are generated from the same invoice, so they cannot disagree.
                            runCatching {
                                // Print = explicit user action, so (re)issuing here is the
                                // auditable "new physical copy" event the registry expects.
                                val payload = com.abm.erp.data.QrRegistry.issue("SalesInvoice", invoice.id)
                                val file = com.abm.erp.core.exportSalesInvoicePdf(context, invoice, payload)
                                val uri = androidx.core.content.FileProvider.getUriForFile(
                                    context, "${context.packageName}.fileprovider", file,
                                )
                                val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                    type = "application/pdf"
                                    putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                    addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(android.content.Intent.createChooser(i, "Invoice PDF"))
                            }.onFailure {
                                android.widget.Toast.makeText(context, "PDF তৈরি করা যায়নি।", android.widget.Toast.LENGTH_LONG).show()
                            }
                            busy = false
                        }
                    },
                )
            }
        }
    }
}

/* ── document text helpers ── */

@Composable private fun DocLabel(t: String) =
    Text(t.uppercase(), fontSize = 8.sp, color = TextSecondary, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)

@Composable private fun DocValue(t: String) =
    Text(t, fontSize = 13.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)

@Composable private fun RowScope.Th(t: String, w: Float, align: TextAlign = TextAlign.Start) =
    Text(t, Modifier.weight(w), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = align)

@Composable private fun RowScope.Td(
    t: String, w: Float, align: TextAlign = TextAlign.Start, weight: FontWeight = FontWeight.Normal,
) = Text(t, Modifier.weight(w), color = TextPrimary, fontSize = 11.sp, textAlign = align, fontWeight = weight)

@Composable private fun TotalRow(label: String, value: String, color: Color = TextPrimary) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 11.sp, color = TextSecondary)
        Text(value, fontSize = 12.sp, color = color, fontWeight = FontWeight.SemiBold)
    }
}

@Composable private fun SignatureSlot(role: String, name: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        if (name.isNotBlank()) {
            Text(name, fontSize = 9.sp, color = TextPrimary, maxLines = 1)
        } else {
            Spacer(Modifier.height(12.dp))
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(HairlineBorder))
        Spacer(Modifier.height(3.dp))
        Text(role, fontSize = 8.sp, color = TextSecondary, textAlign = TextAlign.Center)
    }
}

/**
 * Amount in words, Bangladeshi convention (lakh / crore rather than million / billion).
 *
 * Presentation only — it never feeds a calculation, and the numeric total beside it stays
 * the authority. Written here because the app had no converter; deliberately kept simple
 * and total-agnostic so it cannot alter a figure.
 */
fun amountInWords(amount: Double): String {
    val n = kotlin.math.floor(amount).toLong()
    if (n == 0L) return "Zero Taka Only"
    if (n < 0L) return "Minus ${amountInWords(-amount)}"

    val ones = listOf(
        "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
        "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen",
    )
    val tens = listOf("", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety")

    fun under100(v: Int): String = when {
        v == 0 -> ""
        v < 20 -> ones[v]
        else -> (tens[v / 10] + if (v % 10 != 0) " ${ones[v % 10]}" else "")
    }

    fun under1000(v: Int): String {
        val h = v / 100
        val r = v % 100
        val parts = mutableListOf<String>()
        if (h > 0) parts += "${ones[h]} Hundred"
        if (r > 0) parts += under100(r)
        return parts.joinToString(" ")
    }

    val crore = (n / 10_000_000).toInt()
    val lakh = ((n / 100_000) % 100).toInt()
    val thousand = ((n / 1_000) % 100).toInt()
    val rest = (n % 1_000).toInt()

    val parts = mutableListOf<String>()
    if (crore > 0) parts += "${under1000(crore)} Crore"
    if (lakh > 0) parts += "${under100(lakh)} Lakh"
    if (thousand > 0) parts += "${under100(thousand)} Thousand"
    if (rest > 0) parts += under1000(rest)

    return parts.joinToString(" ").trim() + " Taka Only"
}
