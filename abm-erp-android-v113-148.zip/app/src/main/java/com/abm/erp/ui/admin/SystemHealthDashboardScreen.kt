package com.abm.erp.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.abm.erp.data.MockRepository
import com.abm.erp.data.UserRole
import com.abm.erp.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SystemHealthDashboardScreen() {
    val currentUser = MockRepository.currentUser
    if (currentUser.role != UserRole.CHAIRMAN) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("এই স্ক্রিন শুধু Chairman-এর জন্য।") }
        return
    }
    val context = LocalContext.current
    var snapshot by remember { mutableStateOf<MockRepository.SystemHealthSnapshot?>(null) }
    var lastUpdatedAt by remember { mutableStateOf<java.time.LocalDateTime?>(null) }
    var isRefreshing by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }

    suspend fun refresh() {
        isRefreshing = true
        loadError = null
        try {
            snapshot = MockRepository.computeSystemHealthSnapshot(context)
            lastUpdatedAt = java.time.LocalDateTime.now()
        } catch (e: Exception) {
            loadError = "রিফ্রেশ ব্যর্থ হয়েছে: ${e.message}"
        } finally {
            isRefreshing = false
        }
    }

    // Initial load.
    LaunchedEffect(Unit) { refresh() }
    // Safe periodic refresh — only while this screen is actually visible/composed; cancels automatically when the user navigates away.
    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000)
            refresh()
        }
    }

    val refreshScope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("System Health Dashboard", style = MaterialTheme.typography.titleLarge)
            IconButton(onClick = { refreshScope.launch { refresh() } }, enabled = !isRefreshing) {
                if (isRefreshing) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                else Icon(Icons.Filled.Refresh, contentDescription = "Refresh")
            }
        }
        lastUpdatedAt?.let { Text("সর্বশেষ হালনাগাদ: $it", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
        loadError?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = DangerRed) }

        val s = snapshot
        if (s == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Column
        }
        if (s.errors.isNotEmpty()) {
            Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.padding(8.dp)) {
                    Text("⚠ কিছু মেট্রিক লোড করা যায়নি (শূন্য হিসেবে দেখানো হয়নি, সরাসরি ত্রুটি দেখানো হচ্ছে):", style = MaterialTheme.typography.labelSmall, color = DangerRed)
                    s.errors.forEach { Text("• $it", style = MaterialTheme.typography.labelSmall, color = DangerRed) }
                }
            }
        }
        LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { HealthCard("Database Health", if (s.databaseHealthy) "✅ Healthy" else "❌ Issue", if (s.databaseHealthy) SuccessGreen else DangerRed) }
            item { HealthCard("Server Status", if (s.serverOnline) "🟢 Online" else "🔴 Offline", if (s.serverOnline) SuccessGreen else DangerRed) }
            item {
                HealthCard(
                    "Sync Queue",
                    if (s.syncQueueAvailable) "উপলব্ধ" else "⚠️ কোনো persistent queue নেই",
                    if (s.syncQueueAvailable) SuccessGreen else WarningAmber,
                )
            }
            item { HealthCard("Failed Sync (এই সেশনে, আংশিক)", "${s.failedSyncCount}", if (s.failedSyncCount > 0) DangerRed else SuccessGreen) }
            item { HealthCard("Active Devices", "${s.activeDeviceCount}", TextPrimary) }
            item { HealthCard("Offline Devices", "${s.offlineDeviceCount}", if (s.offlineDeviceCount > 0) WarningAmber else TextSecondary) }
            item { HealthCard("Attendance % (Today)", "${"%.0f".format(s.attendanceTodayPct)}%", if (s.attendanceTodayPct < 70) DangerRed else SuccessGreen) }
            item { HealthCard("Today's Successful Logins", "${s.todaysLoginSuccessCount}", SuccessGreen) }
            item { HealthCard("Today's Failed Login Attempts", "${s.todaysLoginFailedCount}", if (s.todaysLoginFailedCount > 0) DangerRed else SuccessGreen) }
            item {
                HealthCard(
                    "Sales Total — Last 7 Days",
                    "৳${"%,.0f".format(s.salesTotalLast7Days)}",
                    TextPrimary,
                )
            }
            item {
                val growth = s.salesGrowthPct
                HealthCard(
                    "বৃদ্ধি/হ্রাস (পূর্ববর্তী ৭ দিনের তুলনায়)",
                    if (growth != null) "${if (growth >= 0) "+" else ""}${"%.1f".format(growth)}%" else "প্রযোজ্য নয় (আগের সপ্তাহে বিক্রয় ছিল না)",
                    if (growth == null) TextSecondary else if (growth >= 0) SuccessGreen else DangerRed,
                )
            }
            item { HealthCard("Pending Approvals", "${s.pendingApprovalCount}", if (s.pendingApprovalCount > 0) WarningAmber else SuccessGreen) }
            item { HealthCard("Stock Alerts", "${s.stockAlertCount}", if (s.stockAlertCount > 0) DangerRed else SuccessGreen) }
            item { HealthCard("Cloud Functions", if (s.cloudFunctionsDeployed) "✅ Deployed" else "⚠️ Not Deployed", if (s.cloudFunctionsDeployed) SuccessGreen else WarningAmber) }
            item { HealthCard("Backup Status", s.lastBackupStatus, when (s.lastBackupStatus) { "OK" -> SuccessGreen; "OVERDUE" -> WarningAmber; else -> DangerRed }) }
            item { HealthCard("Last Backup", s.lastBackupAt?.toLocalDate()?.toString() ?: "কখনো হয়নি", TextSecondary) }
        }
        s.salesDailyLast7Days?.let { daily ->
            Spacer(Modifier.height(8.dp))
            Text("দৈনিক বিক্রয় (৭ দিন, real ledger data থেকে)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            com.abm.erp.ui.components.TrendLineChart(values = daily, valueFormatter = { "৳${"%,.0f".format(it)}" })
        }
    }
}

@Composable
private fun HealthCard(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text(value, style = MaterialTheme.typography.titleMedium, color = color)
        }
    }
}
