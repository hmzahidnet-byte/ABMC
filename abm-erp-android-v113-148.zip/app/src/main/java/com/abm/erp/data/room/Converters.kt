package com.abm.erp.data.room

import com.abm.erp.data.GpsPing
import com.abm.erp.data.InvoiceLineItem
import java.time.LocalDateTime
import java.time.ZoneOffset

/**
 * Manual pack/unpack for the two nested value-object lists in the domain
 * model (FieldEmployeeRoute.breadcrumbs, VoiceInvoice.items). Kept as plain
 * delimited strings (no JSON dependency) to keep this first persistence pass
 * dependency-light. Field separator "|", record separator ";".
 */
object Converters {

    // ---- GpsPing list <-> String ----
    // record: lat,lng,epochMillis,spoofed
    fun packBreadcrumbs(pings: List<GpsPing>): String =
        pings.joinToString(";") { p ->
            val epochMillis = p.timestamp.toInstant(ZoneOffset.UTC).toEpochMilli()
            "${p.lat},${p.lng},$epochMillis,${p.spoofed}"
        }

    fun unpackBreadcrumbs(raw: String): List<GpsPing> {
        if (raw.isBlank()) return emptyList()
        return raw.split(";").filter { it.isNotBlank() }.map { record ->
            val (lat, lng, epochMillis, spoofed) = record.split(",")
            GpsPing(
                lat = lat.toDouble(),
                lng = lng.toDouble(),
                timestamp = LocalDateTime.ofInstant(
                    java.time.Instant.ofEpochMilli(epochMillis.toLong()), ZoneOffset.UTC
                ),
                spoofed = spoofed.toBoolean(),
            )
        }
    }

    // ---- InvoiceLineItem list <-> String ----
    // record: name,qty,unit,unitPrice,discountPct  (name must not contain "," or ";")
    fun packInvoiceItems(items: List<InvoiceLineItem>): String =
        items.joinToString(";") { i ->
            val safeName = i.name.replace(",", "").replace(";", "")
            "$safeName,${i.qty},${i.unit},${i.unitPrice},${i.discountPct}"
        }

    fun unpackInvoiceItems(raw: String): MutableList<InvoiceLineItem> {
        if (raw.isBlank()) return mutableListOf()
        return raw.split(";").filter { it.isNotBlank() }.map { record ->
            val parts = record.split(",")
            val name = parts[0]
            val qty = parts[1].toDouble()
            val unit = parts[2]
            val unitPrice = parts[3].toDouble()
            val discountPct = parts[4].toDouble()
            InvoiceLineItem(name, qty, unit, unitPrice, discountPct)
        }.toMutableList()
    }

    // ---- VoucherLine list <-> String (Module 11: Accounts & Finance) ----
    fun packVoucherLines(lines: List<com.abm.erp.data.VoucherLine>): String =
        lines.joinToString(";") { "${it.accountId}|${it.accountName}|${it.debit}|${it.credit}" }

    fun unpackVoucherLines(raw: String): List<com.abm.erp.data.VoucherLine> {
        if (raw.isBlank()) return emptyList()
        return raw.split(";").filter { it.isNotBlank() }.map { record ->
            val parts = record.split("|")
            com.abm.erp.data.VoucherLine(
                accountId = parts[0], accountName = parts[1],
                debit = parts.getOrNull(2)?.toDoubleOrNull() ?: 0.0, credit = parts.getOrNull(3)?.toDoubleOrNull() ?: 0.0,
            )
        }
    }

    // ---- ModulePermission list <-> String ----
    // record: moduleKey,canView,canCreate,canEdit,canApprove,canDelete,canExport
    fun packModulePermissions(perms: List<com.abm.erp.data.ModulePermission>): String =
        perms.joinToString(";") { "${it.moduleKey},${it.canView},${it.canCreate},${it.canEdit},${it.canApprove},${it.canDelete},${it.canExport}" }

    fun unpackModulePermissions(raw: String): List<com.abm.erp.data.ModulePermission> {
        if (raw.isBlank()) return emptyList()
        return raw.split(";").filter { it.isNotBlank() }.map { record ->
            val parts = record.split(",")
            com.abm.erp.data.ModulePermission(
                moduleKey = parts[0], canView = parts[1].toBoolean(), canCreate = parts[2].toBoolean(),
                canEdit = parts[3].toBoolean(), canApprove = parts[4].toBoolean(), canDelete = parts[5].toBoolean(),
                canExport = parts.getOrNull(6)?.toBoolean() ?: false,
            )
        }
    }

    // ---- SalesInvoiceLineItem list <-> String ----
    // record: productId,name,unit,qty,unitPrice,discountPct
    fun packSalesInvoiceItems(items: List<com.abm.erp.data.SalesInvoiceLineItem>): String =
        items.joinToString(";") { "${it.productId},${it.name},${it.unit},${it.qty},${it.unitPrice},${it.discountPct},${it.batchCode ?: ""}" }

    fun unpackSalesInvoiceItems(raw: String): List<com.abm.erp.data.SalesInvoiceLineItem> {
        if (raw.isBlank()) return emptyList()
        return raw.split(";").filter { it.isNotBlank() }.map { record ->
            val parts = record.split(",")
            com.abm.erp.data.SalesInvoiceLineItem(
                productId = parts[0], name = parts[1], unit = parts[2],
                qty = parts[3].toInt(), unitPrice = parts[4].toDouble(), discountPct = parts[5].toDouble(),
                batchCode = parts.getOrNull(6)?.ifBlank { null },
            )
        }
    }
}
