package com.abm.erp.data

import android.content.Context
import com.abm.erp.data.room.AppDatabase
import com.abm.erp.data.room.BackupMetadataEntity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset

/**
 * Backup & Recovery — Foundation Layer.
 *
 * Deliberately reuses the existing Firebase stack instead of adding any paid
 * service: Firestore for the actual data, Firebase Storage for the durable
 * JSON copy (both already used elsewhere in this app — Storage for the
 * Chairman's Notice image). Export/import work directly on Firestore's raw
 * document maps, so a restore just becomes a normal remote write — the
 * SAME snapshot listeners MockRepository/InventoryRepository already run
 * pick the change up and repopulate Room automatically. Backup doesn't need
 * (and deliberately avoids) its own parallel data path or custom queue.
 */
object BackupManager {
    private val firestore by lazy { FirebaseFirestore.getInstance() }
    private val storage by lazy { FirebaseStorage.getInstance() }

    /** Restore size ceiling — comfortably above this app's realistic data volume; prevents a corrupted/huge file from hanging the device. */
    private const val MAX_RESTORE_BYTES = 50L * 1024 * 1024

    /**
     * Every company-scoped collection currently written anywhere in the app
     * (MockRepository, InventoryRepository, FirebaseSync). Kept as one
     * explicit list rather than discovered dynamically, so adding a new
     * synced collection later is a deliberate one-line addition here too —
     * the same "no silent gaps" principle as the rest of Foundation Layer.
     */
    private val BACKUP_COLLECTIONS = listOf(
        "dealers", "retailOrders", "retailers", "territories", "roleDefinitions",
        "salesInvoices", "approvals", "ledger", "tasks", "shipments", "couriers",
        "auditLog", "attendance", "payroll", "campaigns", "employeeRoles",
        "products", "warehouses", "stockLevels", "stockMovements", "orgState",
        "complaints", "dealerOrders", "helpdeskTickets", "loginLog", "aiUsage",
        "quotations", "deliveryChallans", "salesReturns", "partyLedger",
        "partyCollections", "discountRules", "salesRoutes", "visitLogs",
        "suppliers", "purchaseOrders", "goodsReceivedNotes", "purchaseReturns",
        "productCategories", "productBrands", "damageReports", "stockTransfers", "inventoryLots",
        "billOfMaterials", "productionOrders", "qualityChecks", "productionLosses", "machineLogs",
        "chartOfAccounts", "vouchers",
        "leads", "opportunities", "customerSegments", "callLogs", "meetingLogs", "followUps",
        "leaveRequests", "employeeLifecycleEvents",
        "chatMessages", "announcements", "circulars",
        "vehicles", "vehicleLocationPings",
        "notifications",
    )

    private fun companyRoot(companyId: String) = firestore.collection("companies").document(companyId)
    private fun db(context: Context) = AppDatabase.getInstance(context)

    /** Live, Room-backed history list — same offline-first pattern as every other list in the app. */
    fun history(context: Context): Flow<List<BackupMetadata>> =
        db(context).backupDao().getAll().map { list -> list.map { it.toDomain() } }

    /**
     * Reads every collection above for this company into one JSON bundle,
     * writes a local copy (works even with no network afterwards) AND
     * uploads it to Firebase Storage (survives a lost/replaced phone), then
     * records BackupMetadata in Room + Firestore and an audit log entry.
     */
    suspend fun exportBackup(context: Context, companyId: String, triggeredBy: String): BackupMetadata {
        val bundle = JSONObject()
        var totalDocs = 0
        for (collectionName in BACKUP_COLLECTIONS) {
            val snapshot = companyRoot(companyId).collection(collectionName).get().await()
            val docsArray = JSONArray()
            snapshot.documents.forEach { doc ->
                val obj = JSONObject(doc.data ?: emptyMap<String, Any>())
                obj.put("__docId", doc.id)
                docsArray.put(obj)
                totalDocs++
            }
            bundle.put(collectionName, docsArray)
        }

        val timestamp = System.currentTimeMillis()
        val backupId = "backup_${companyId}_$timestamp"
        val fileName = "$backupId.json"
        val bundleBytes = bundle.toString().toByteArray()

        // Local copy on this device.
        runCatching { File(context.getExternalFilesDir(null), fileName).writeBytes(bundleBytes) }

        // Durable, cross-device copy.
        val storageRef = storage.reference.child("companies/$companyId/backups/$fileName")
        storageRef.putBytes(bundleBytes).await()
        val downloadUrl = storageRef.downloadUrl.await().toString()

        val metadata = BackupMetadata(
            id = backupId, companyId = companyId, version = "v1",
            collectionsIncluded = BACKUP_COLLECTIONS.size, fileUrl = downloadUrl,
            fileSizeBytes = bundleBytes.size.toLong(), triggeredBy = triggeredBy,
            status = BackupStatus.COMPLETED,
        )
        val entity = metadata.toEntity()
        db(context).backupDao().upsert(entity)
        companyRoot(companyId).collection("backups").document(backupId).set(entity).await()
        MockRepository.logAudit("Backup", backupId, "CREATE", newValue = "docs=$totalDocs collections=${BACKUP_COLLECTIONS.size}")
        return metadata
    }

    /**
     * Downloads a previous backup's JSON bundle and writes every document
     * straight back to its original Firestore location. UI MUST confirm
     * with the person before calling this — it overwrites live data. Every
     * restore is itself logged to the audit trail.
     */
    /**
     * v86 fix — restoreBackup previously had NO validation at all before
     * overwriting live company data: no check that the backup's companyId
     * matches the restoring user's own company, no permission gate, no
     * check that the downloaded bundle is even non-empty/well-formed. Any
     * of those could silently corrupt or cross-contaminate company data.
     */
    suspend fun restoreBackup(context: Context, metadata: BackupMetadata, restoredBy: String) {
        val role = MockRepository.currentUser.role
        if (role != UserRole.CHAIRMAN && role != UserRole.MD && role != UserRole.GM) {
            MockRepository.logAudit("Backup", metadata.id, "DENY", oldValue = role.name, newValue = "RESTORE")
            throw SecurityException("Restore denied: insufficient permission.")
        }
        if (!com.abm.erp.util.NetworkStatus.isOnline(context)) {
            MockRepository.logAudit("Backup", metadata.id, "DENY_OFFLINE", newValue = "Backup Restore requires an online connection")
            throw IllegalStateException("Restore denied: an internet connection is required for Backup Restore.")
        }
        if (metadata.companyId != MockRepository.currentUser.companyId) {
            MockRepository.logAudit("Backup", metadata.id, "DENY", oldValue = metadata.companyId, newValue = "RESTORE — company mismatch with ${MockRepository.currentUser.companyId}")
            throw SecurityException("Restore denied: this backup belongs to a different company.")
        }
        val storageRef = storage.getReferenceFromUrl(metadata.fileUrl)
        val bytes = storageRef.getBytes(MAX_RESTORE_BYTES).await()
        if (bytes.isEmpty()) {
            MockRepository.logAudit("Backup", metadata.id, "DENY", oldValue = "0 bytes", newValue = "RESTORE — empty/corrupt file")
            throw IllegalStateException("Restore aborted: downloaded backup file is empty.")
        }
        val bundle = JSONObject(String(bytes))
        val presentCollections = BACKUP_COLLECTIONS.count { bundle.has(it) }
        if (presentCollections == 0) {
            MockRepository.logAudit("Backup", metadata.id, "DENY", oldValue = "0 collections found", newValue = "RESTORE — malformed bundle")
            throw IllegalStateException("Restore aborted: backup file doesn't contain any recognizable collection.")
        }

        for (collectionName in BACKUP_COLLECTIONS) {
            val docsArray = bundle.optJSONArray(collectionName) ?: continue
            for (i in 0 until docsArray.length()) {
                val obj = docsArray.getJSONObject(i)
                val docId = obj.getString("__docId")
                obj.remove("__docId")
                val map = jsonObjectToMap(obj)
                companyRoot(metadata.companyId).collection(collectionName).document(docId).set(map).await()
            }
        }

        val restored = metadata.copy(status = BackupStatus.RESTORED, restoredAt = LocalDateTime.now(), restoredBy = restoredBy)
        val entity = restored.toEntity()
        db(context).backupDao().upsert(entity)
        companyRoot(metadata.companyId).collection("backups").document(metadata.id).set(entity).await()
        MockRepository.logAudit("Backup", metadata.id, "RESTORE", oldValue = metadata.status.name, newValue = "RESTORED")
    }

    private fun jsonObjectToMap(obj: JSONObject): Map<String, Any?> {
        val map = mutableMapOf<String, Any?>()
        obj.keys().forEach { key -> map[key] = unwrapJson(obj.get(key)) }
        return map
    }

    private fun unwrapJson(value: Any): Any? = when (value) {
        is JSONObject -> jsonObjectToMap(value)
        is JSONArray -> (0 until value.length()).map { unwrapJson(value.get(it)) }
        JSONObject.NULL -> null
        else -> value
    }
}

private fun BackupMetadata.toEntity() = BackupMetadataEntity(
    id = id, companyId = companyId, version = version, collectionsIncluded = collectionsIncluded,
    fileUrl = fileUrl, fileSizeBytes = fileSizeBytes, triggeredBy = triggeredBy, status = status.name,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    restoredAtEpochMillis = restoredAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(), restoredBy = restoredBy,
)

private fun BackupMetadataEntity.toDomain() = BackupMetadata(
    id = id, companyId = companyId, version = version, collectionsIncluded = collectionsIncluded,
    fileUrl = fileUrl, fileSizeBytes = fileSizeBytes, triggeredBy = triggeredBy,
    status = runCatching { BackupStatus.valueOf(status) }.getOrDefault(BackupStatus.COMPLETED),
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    restoredAt = restoredAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    restoredBy = restoredBy,
)
