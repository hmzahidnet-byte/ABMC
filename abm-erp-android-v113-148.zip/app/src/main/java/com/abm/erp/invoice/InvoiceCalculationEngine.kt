package com.abm.erp.invoice

import java.math.BigDecimal
import java.math.RoundingMode

/**
 * Phase 5 — the ONE authoritative place invoice math happens. Every
 * screen (cart entry, invoice detail, PDF/print, ledger posting,
 * Firestore payload) must call through here rather than each computing
 * its own subtotal/discount/tax — that duplication is exactly what
 * causes "invoice total mismatch" bugs.
 *
 * Policy decisions (explicit, not left ambiguous):
 * - Discount is applied BEFORE tax (line discount, then promotional/
 *   dealer discount, THEN VAT/tax on the discounted taxable amount) —
 *   this matches standard Bangladesh VAT practice (VAT is charged on
 *   the net sale price after trade discount, not on the gross list price).
 * - Rounding: every monetary figure is rounded to 2 decimal places using
 *   HALF_UP, applied ONCE at the very end of each stage (line net, then
 *   again at invoice net) — never rounded mid-formula, which would
 *   compound error across many lines.
 * - All arithmetic uses BigDecimal; Double/Float are never used for money
 *   anywhere in this file.
 */
object InvoiceCalculationEngine {
    private val SCALE = 2
    private val ROUNDING = RoundingMode.HALF_UP

    private fun round(v: BigDecimal): BigDecimal = v.setScale(SCALE, ROUNDING)

    data class LineInput(
        val quantity: BigDecimal,
        val freeQuantity: BigDecimal = BigDecimal.ZERO,
        val unitConversionFactor: BigDecimal = BigDecimal.ONE, // e.g. 1 carton = 24 pieces -> pass 24 when unitPrice is per-piece and quantity is in cartons
        val unitPrice: BigDecimal,
        val lineDiscountPct: BigDecimal = BigDecimal.ZERO,
        val promotionalDiscountPct: BigDecimal = BigDecimal.ZERO,
        val dealerDiscountPct: BigDecimal = BigDecimal.ZERO,
        val vatPct: BigDecimal = BigDecimal.ZERO,
        val taxPct: BigDecimal = BigDecimal.ZERO,
        val additionalCharge: BigDecimal = BigDecimal.ZERO,
        val returnAdjustment: BigDecimal = BigDecimal.ZERO, // negative value reduces the line, e.g. prior partial return credited against this line
    )

    data class LineResult(
        val baseQuantity: BigDecimal, // after unit conversion
        val grossAmount: BigDecimal, // baseQuantity * unitPrice
        val afterLineDiscount: BigDecimal,
        val afterPromoDealerDiscount: BigDecimal,
        val taxableAmount: BigDecimal,
        val vatAmount: BigDecimal,
        val taxAmount: BigDecimal,
        val netLineTotal: BigDecimal,
    )

    /** Steps 1-8: base quantity conversion through line net amount. */
    fun computeLine(input: LineInput): LineResult? {
        if (input.quantity < BigDecimal.ZERO || input.unitPrice < BigDecimal.ZERO) return null // reject negative quantities and invalid prices
        // Step 1 — base quantity conversion.
        val baseQuantity = input.quantity.multiply(input.unitConversionFactor)
        // Step 2 — quantity x unit price (free quantity contributes zero revenue, so it is excluded from the gross).
        val grossAmount = baseQuantity.multiply(input.unitPrice)
        // Step 3 — line discount.
        val afterLineDiscount = grossAmount.multiply(BigDecimal.ONE.subtract(input.lineDiscountPct.divide(BigDecimal(100))))
        // Step 4 — promotional/dealer discount (both applied on the already-line-discounted amount, compounding rather than stacking flatly against the gross).
        val combinedPromoDealerFactor = BigDecimal.ONE
            .subtract(input.promotionalDiscountPct.divide(BigDecimal(100)))
            .multiply(BigDecimal.ONE.subtract(input.dealerDiscountPct.divide(BigDecimal(100))))
        val afterPromoDealerDiscount = afterLineDiscount.multiply(combinedPromoDealerFactor)
        // Step 5 — taxable amount (discounts already applied; return adjustment also reduces the taxable base since it reverses a prior sale).
        val taxableAmount = afterPromoDealerDiscount.add(input.returnAdjustment)
        // Step 6 — VAT/tax, computed on the taxable amount, not the gross.
        val vatAmount = taxableAmount.multiply(input.vatPct.divide(BigDecimal(100)))
        val taxAmount = taxableAmount.multiply(input.taxPct.divide(BigDecimal(100)))
        // Step 7 — line additional charge (added after tax, e.g. a per-line handling fee that itself isn't taxed).
        // Step 8 — line net amount, rounded once here.
        val netLineTotal = round(taxableAmount.add(vatAmount).add(taxAmount).add(input.additionalCharge))
        return LineResult(
            baseQuantity = baseQuantity, grossAmount = round(grossAmount), afterLineDiscount = round(afterLineDiscount),
            afterPromoDealerDiscount = round(afterPromoDealerDiscount), taxableAmount = round(taxableAmount),
            vatAmount = round(vatAmount), taxAmount = round(taxAmount), netLineTotal = netLineTotal,
        )
    }

    data class InvoiceInput(
        val lines: List<LineInput>,
        val invoiceLevelDiscountPct: BigDecimal = BigDecimal.ZERO,
        val deliveryCharge: BigDecimal = BigDecimal.ZERO,
        val otherCharge: BigDecimal = BigDecimal.ZERO,
        val previousDue: BigDecimal = BigDecimal.ZERO,
        val paidAmount: BigDecimal = BigDecimal.ZERO,
    )

    data class InvoiceResult(
        val lineResults: List<LineResult>,
        val subtotal: BigDecimal, // step 9
        val afterInvoiceDiscount: BigDecimal, // step 10
        val withDeliveryAndOther: BigDecimal, // steps 11-12
        val previousDue: BigDecimal, // step 13 (display only, not added into the invoice's own net)
        val currentInvoiceNetTotal: BigDecimal, // step 14 — this invoice's own charge, excluding previous due
        val paidAmount: BigDecimal, // step 15
        val remainingDue: BigDecimal, // step 16 — currentInvoiceNetTotal + previousDue - paidAmount, the real amount the dealer now owes overall
        val rejected: Boolean = false,
        val rejectionReason: String? = null,
    )

    /** Steps 9-16, full invoice. Any invalid line rejects the whole invoice — never silently drops a bad line and posts a wrong total. */
    fun computeInvoice(input: InvoiceInput): InvoiceResult {
        if (input.lines.isEmpty()) return InvoiceResult(emptyList(), BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, rejected = true, rejectionReason = "Invoice has no line items.")
        val lineResults = mutableListOf<LineResult>()
        for (line in input.lines) {
            val r = computeLine(line) ?: return InvoiceResult(emptyList(), BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, rejected = true, rejectionReason = "Negative quantity or invalid price on one or more lines.")
            lineResults.add(r)
        }
        // Step 9 — invoice subtotal.
        val subtotal = lineResults.fold(BigDecimal.ZERO) { acc, r -> acc.add(r.netLineTotal) }
        // Step 10 — invoice-level discount.
        val afterInvoiceDiscount = subtotal.multiply(BigDecimal.ONE.subtract(input.invoiceLevelDiscountPct.divide(BigDecimal(100))))
        // Steps 11-12 — delivery/transport charge, other charge.
        val withDeliveryAndOther = round(afterInvoiceDiscount.add(input.deliveryCharge).add(input.otherCharge))
        // Step 14 — current invoice net total (this invoice's own charge only).
        val currentInvoiceNetTotal = withDeliveryAndOther
        // Step 16 — remaining due includes previous due, matching how a dealer's real outstanding balance works.
        val remainingDue = round(currentInvoiceNetTotal.add(input.previousDue).subtract(input.paidAmount))
        return InvoiceResult(
            lineResults = lineResults, subtotal = round(subtotal), afterInvoiceDiscount = round(afterInvoiceDiscount),
            withDeliveryAndOther = withDeliveryAndOther, previousDue = round(input.previousDue),
            currentInvoiceNetTotal = currentInvoiceNetTotal, paidAmount = round(input.paidAmount), remainingDue = remainingDue,
        )
    }
}
