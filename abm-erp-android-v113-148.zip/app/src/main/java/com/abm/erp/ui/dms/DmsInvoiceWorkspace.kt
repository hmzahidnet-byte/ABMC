package com.abm.erp.ui.dms

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import kotlinx.coroutines.launch
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.core.rememberVisibleDealers
import com.abm.erp.data.CodeRegistry
import com.abm.erp.data.MockRepository
import com.abm.erp.data.PermissionAction
import com.abm.erp.data.PermissionManager
import com.abm.erp.data.SalesInvoiceLineItem
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * v113-80 — DMS INVOICE WORKSPACE. The reference implementation of the person's
 * standing workspace contract (PROJECT_STATE v113-79): ONE full-screen workspace for
 * the whole invoice operation. Dealer identify (search OR code/QR autofill with geo
 * validation), dealer financial context (due / credit limit / available credit /
 * history), product add (search / category / code), offer rules, discount, commission,
 * return entry, stock availability, live summary with credit check, create, approve,
 * invoice QR payload, share — all inline. Helper actions are sheets/dialogs only;
 * nothing navigates away.
 *
 * Contract clause honoured hard: **no business logic redesigned, no duplicate
 * workflow.** Every write goes through the SAME engines the old tab used —
 * `createSalesInvoice`, `approveSalesInvoice`, `deleteSalesInvoice`,
 * `createSalesReturn`, `CodeRegistry.resolve` — with all their permission checks,
 * audit logs, Firestore sync and stock effects intact. What is new here is
 * arrangement only.
 *
 * Gift is present but disabled: its financial rule (does it reduce due? post to
 * ledger? need approval?) has never been defined by the person, and inventing a money
 * rule unasked is forbidden by the standing rules. The chip says so.
 */
@Composable
fun DmsInvoiceWorkspace(onNavigate: (String) -> Unit = {}) {
    val dealers = rememberVisibleDealers()
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val stockLevels by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
    val invoices by MockRepository.salesInvoices.collectAsState()
    val discountRules by MockRepository.discountRules.collectAsState()
    val scope = rememberCoroutineScope()

    // ---- workspace state ----
    var codeInput by remember { mutableStateOf("") }
    var codeError by remember { mutableStateOf<String?>(null) }
    var dealerQuery by remember { mutableStateOf("") }
    var selectedDealerId by remember { mutableStateOf<String?>(null) }
    var productQuery by remember { mutableStateOf("") }
    var categoryFilter by remember { mutableStateOf<String?>(null) }
    var cart by remember { mutableStateOf(listOf<SalesInvoiceLineItem>()) }
    var dealerDiscount by remember { mutableStateOf("") }
    var commission by remember { mutableStateOf("") }
    var courier by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }
    var lastResult by remember { mutableStateOf<String?>(null) }
    var showAddDealer by remember { mutableStateOf(false) }
    var showAddProduct by remember { mutableStateOf(false) }
    var showReturnSheet by remember { mutableStateOf(false) }

    val dealer = dealers.firstOrNull { it.id == selectedDealerId }
    val dealerInvoices = remember(invoices, selectedDealerId) {
        if (selectedDealerId == null) emptyList()
        else invoices.filter { !it.isDeleted && it.dealerId == selectedDealerId }.sortedByDescending { it.createdAt }
    }
    val subtotal = remember(cart) { cart.sumOf { it.lineTotal } }
    val discountPct = dealerDiscount.toDoubleOrNull() ?: 0.0
    val commissionPct = commission.toDoubleOrNull() ?: 0.0
    val total = subtotal * (1 - discountPct / 100)
    val overCredit = dealer != null && (dealer.dueBalance + total) > dealer.creditLimit && dealer.creditLimit > 0
    val canCreate = PermissionManager.canCurrentUser("bill", PermissionAction.CREATE)
    val canApprove = PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)

    // Code/QR autofill — the contract's "no manual searching if QR identifies".
    // Same resolver the universal scanner uses; DEALER fills the dealer slot,
    // PRODUCT drops straight into the cart. Cascade re-check: a resolved dealer
    // outside the viewer's visible set is REFUSED, not silently selected —
    // resolve() reads the raw registry, so the territory rule must re-apply here.
    fun applyCode() {
        codeError = null
        when (val r = CodeRegistry.resolve(codeInput)) {
            is CodeRegistry.ResolveResult.Found -> when (r.type) {
                CodeRegistry.CodeType.DEALER -> {
                    if (dealers.any { it.id == r.id }) { selectedDealerId = r.id; codeInput = "" }
                    else codeError = "এই dealer আপনার এলাকার বাইরে — নির্বাচন করা যাবে না।"
                }
                CodeRegistry.CodeType.PRODUCT -> {
                    val p = products.firstOrNull { it.id == r.id && !it.isDeleted }
                    if (p != null) {
                        cart = cart + SalesInvoiceLineItem(p.id, p.name, p.unit, 1, p.defaultUnitPrice)
                        codeInput = ""
                    } else codeError = "Product পাওয়া গেল কিন্তু লোড হয়নি।"
                }
                else -> codeError = "এই কোডটি ${r.type} — এই workspace-এ dealer/product কোড লাগবে।"
            }
            is CodeRegistry.ResolveResult.Ambiguous -> codeError = "একই কোড একাধিক রেকর্ডে মিলেছে — data integrity সমস্যা, admin-কে জানান।"
            CodeRegistry.ResolveResult.NotFound -> codeError = "কোডটি কোনো রেকর্ডে মেলেনি।"
            CodeRegistry.ResolveResult.Invalid -> codeError = "কোড খালি/অবৈধ।"
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // ── code / QR entry ──
        item {
            Spacer(Modifier.height(4.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = codeInput, onValueChange = { codeInput = it },
                        placeholder = { Text("Dealer/Product QR বা কোড…") },
                        singleLine = true, modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { applyCode() }, enabled = codeInput.isNotBlank()) { Text("Fill") }
                    IconButton(onClick = { onNavigate("universal_scanner") }) {
                        Icon(Icons.Filled.QrCodeScanner, contentDescription = "Scan", tint = TextPrimary)
                    }
                }
                codeError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
            }
        }

        // ── dealer panel ──
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Dealer", fontWeight = FontWeight.Bold, color = TextPrimary)
                    TextButton(onClick = { showAddDealer = true }) { Text("+ New Dealer") }
                }
                if (dealer == null) {
                    OutlinedTextField(
                        value = dealerQuery, onValueChange = { dealerQuery = it },
                        placeholder = { Text("নাম/এলাকা দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                    val matches = remember(dealers, dealerQuery) {
                        if (dealerQuery.isBlank()) emptyList()
                        else dealers.filter { it.name.contains(dealerQuery, true) || it.zone.contains(dealerQuery, true) }.take(5)
                    }
                    matches.forEach { d ->
                        Text(
                            "${d.name} — ${d.zone}",
                            modifier = Modifier.fillMaxWidth().clickable { selectedDealerId = d.id; dealerQuery = "" }.padding(vertical = 8.dp),
                            color = TextPrimary,
                        )
                    }
                    if (dealerQuery.isNotBlank() && matches.isEmpty()) {
                        Text("আপনার এলাকায় মেলেনি।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(dealer.name, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(dealer.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        TextButton(onClick = { selectedDealerId = null }) { Text("বদলান") }
                    }
                    // financial context — real fields, same derivation the Master Profile uses
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Outstanding Due", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("৳${"%,.0f".format(dealer.dueBalance)}", fontWeight = FontWeight.Bold, color = if (dealer.dueBalance > 0) WarningAmber else SuccessGreen)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Credit Limit", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("৳${"%,.0f".format(dealer.creditLimit)}", color = TextPrimary)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Available Credit", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("৳${"%,.0f".format((dealer.creditLimit - dealer.dueBalance).coerceAtLeast(0.0))}", color = TextPrimary)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("History (invoice)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("${dealerInvoices.size} টি · ৳${"%,.0f".format(dealerInvoices.sumOf { it.total })}", color = TextPrimary)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { onNavigate("statement/DEALER/${dealer.id}") }) { Text("Full Ledger →") }
                        TextButton(onClick = { showReturnSheet = true }) { Text("Damage/Return") }
                    }
                    // v113-141 — dealer location right inside the invoice workspace,
                    // as asked. Checked the model first: Dealer has NO lat/lng (only
                    // Retailer does), just `address` — so this opens a Maps SEARCH on
                    // the real address rather than fabricating coordinates. Same
                    // intent + fallback chain DealersScreen's navigate button already
                    // uses (Google Maps → generic geo: → honest Toast).
                    if (dealer.address.isNotBlank()) {
                        val invNavContext = androidx.compose.ui.platform.LocalContext.current
                        Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text("📍 ${dealer.address}", style = MaterialTheme.typography.labelSmall, color = TextSecondary, modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                try {
                                    val q = android.net.Uri.encode(dealer.address)
                                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("geo:0,0?q=$q")).apply { setPackage("com.google.android.apps.maps") }
                                    invNavContext.startActivity(intent)
                                } catch (e: Exception) {
                                    try {
                                        invNavContext.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("geo:0,0?q=${android.net.Uri.encode(dealer.address)}")))
                                    } catch (e2: Exception) {
                                        android.widget.Toast.makeText(invNavContext, "Maps app পাওয়া যায়নি।", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }) { Text("Map") }
                        }
                    }
                }
            }
        }

        // ── product panel ──
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("Product", fontWeight = FontWeight.Bold, color = TextPrimary)
                    // v113-141 — "product add" button right where the invoice is being
                    // built, as asked, so a missing product doesn't force the person to
                    // leave the invoice. Shown only if they genuinely hold inv-CREATE
                    // rights — a button that could only ever reject them is worse than
                    // no button. This is the WORKSPACE only; the printed/PDF invoice
                    // output is generated separately in StructuredExports.kt and has no
                    // buttons at all, so nothing leaks onto the real document.
                    if (com.abm.erp.data.PermissionManager.canCurrentUser("inv", com.abm.erp.data.PermissionAction.CREATE)) {
                        TextButton(onClick = { showAddProduct = true }) { Text("+ New Product") }
                    }
                }
                OutlinedTextField(
                    value = productQuery, onValueChange = { productQuery = it },
                    placeholder = { Text("Product নাম/SKU…") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                val categories = remember(products) { products.filter { !it.isDeleted && it.isActive }.map { it.category }.distinct().sorted() }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = categoryFilter == null, onClick = { categoryFilter = null }, label = { Text("সব") })
                    categories.forEach { c -> FilterChip(selected = categoryFilter == c, onClick = { categoryFilter = c }, label = { Text(c) }) }
                }
                val productMatches = remember(products, productQuery, categoryFilter) {
                    products.filter {
                        !it.isDeleted && it.isActive &&
                            (categoryFilter == null || it.category == categoryFilter) &&
                            (productQuery.isBlank() || it.name.contains(productQuery, true) || it.sku.contains(productQuery, true))
                    }.take(6)
                }
                productMatches.forEach { p ->
                    val onHand = stockLevels.filter { it.productId == p.id }.sumOf { it.quantityOnHand }
                    Row(
                        Modifier.fillMaxWidth().clickable { cart = cart + SalesInvoiceLineItem(p.id, p.name, p.unit, 1, p.defaultUnitPrice) }.padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column {
                            Text(p.name, color = TextPrimary)
                            Text("৳${"%,.0f".format(p.defaultUnitPrice)}/${p.unit} · stock ${"%,.0f".format(onHand)}", style = MaterialTheme.typography.labelSmall, color = if (onHand <= 0) DangerRed else TextSecondary)
                        }
                        Icon(Icons.Filled.AddCircleOutline, contentDescription = "Add", tint = TextSecondary)
                    }
                }
            }
        }

        // ── cart ──
        if (cart.isNotEmpty()) {
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Cart (${cart.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
                    cart.forEachIndexed { idx, line ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(line.name, color = TextPrimary)
                                Text("৳${"%,.0f".format(line.unitPrice)}/${line.unit}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                            IconButton(onClick = { if (line.qty > 1) cart = cart.toMutableList().also { it[idx] = line.copy(qty = line.qty - 1) } }) { Icon(Icons.Filled.RemoveCircleOutline, null, tint = TextSecondary) }
                            Text("${line.qty}", fontWeight = FontWeight.Bold, color = TextPrimary)
                            IconButton(onClick = { cart = cart.toMutableList().also { it[idx] = line.copy(qty = line.qty + 1) } }) { Icon(Icons.Filled.AddCircleOutline, null, tint = TextSecondary) }
                            IconButton(onClick = { cart = cart.filterIndexed { i, _ -> i != idx } }) { Icon(Icons.Filled.Delete, null, tint = DangerRed) }
                        }
                    }
                }
            }
        }

        // ── extras: offer / discount / commission / gift ──
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Offer · Discount · Commission", fontWeight = FontWeight.Bold, color = TextPrimary)
                val activeOffers = remember(discountRules, selectedDealerId) {
                    discountRules.filter { it.isActive && (it.scope == "ALL" || it.scope == selectedDealerId) }
                }
                if (activeOffers.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        activeOffers.forEach { rule ->
                            AssistChip(
                                onClick = { dealerDiscount = rule.discountPct.toString() },
                                label = { Text("${rule.label} ${rule.discountPct}%") },
                            )
                        }
                    }
                    Text("Offer chip চাপলে discount ঘরে বসে যায় — নিয়মগুলো Business Rules থেকে আসে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = dealerDiscount, onValueChange = { dealerDiscount = it }, label = { Text("Discount %") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = commission, onValueChange = { commission = it }, label = { Text("Commission %") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = courier, onValueChange = { courier = it }, label = { Text("Courier (ঐচ্ছিক)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                AssistChip(
                    onClick = {}, enabled = false,
                    label = { Text("Gift — টাকার নিয়ম এখনো ঠিক হয়নি, তাই বন্ধ") },
                )
            }
        }

        // ── summary + create ──
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Invoice Summary", fontWeight = FontWeight.Bold, color = TextPrimary)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Subtotal", color = TextSecondary); Text("৳${"%,.0f".format(subtotal)}", color = TextPrimary)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Discount", color = TextSecondary); Text("-${discountPct}%", color = TextPrimary)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("৳${"%,.0f".format(total)}", fontWeight = FontWeight.Bold, color = TextPrimary)
                }
                if (overCredit) {
                    Text(
                        "⚠ Credit limit ছাড়িয়ে যাবে (Due ৳${"%,.0f".format(dealer!!.dueBalance)} + এই invoice > limit ৳${"%,.0f".format(dealer.creditLimit)}) — জমা দিলে reject হবে।",
                        color = WarningAmber, style = MaterialTheme.typography.labelSmall,
                    )
                }
                if (!canCreate) {
                    Text("আপনার role-এ invoice create অনুমতি নেই।", color = DangerRed, style = MaterialTheme.typography.labelSmall)
                }
                Button(
                    onClick = {
                        val d = dealer ?: return@Button
                        isSubmitting = true
                        lastResult = null
                        val ok = MockRepository.createSalesInvoice(
                            dealerId = d.id, dealerName = d.name, dealerZone = d.zone,
                            lineItems = cart, dealerDiscountPct = discountPct, commissionPct = commissionPct,
                            courier = courier.ifBlank { null }, signedByRole = null,
                            onRejected = { reason -> lastResult = "✖ $reason" },
                        ) { created ->
                            lastResult = "✔ ${created.invoiceNo} তৈরি হয়েছে — QR payload: ${created.invoiceNo}"
                            cart = emptyList(); dealerDiscount = ""; commission = ""; courier = ""
                        }
                        if (!ok && lastResult == null) {
                            // onRejected already set a specific message for every real
                            // rejection path in createSalesInvoice — this is only a
                            // safety net if some future path returns false without
                            // calling it, so the user is never left with silence.
                            lastResult = "✖ তৈরি হয়নি — কারণ জানা যায়নি, আবার চেষ্টা করুন।"
                        }
                        isSubmitting = false
                    },
                    enabled = dealer != null && cart.isNotEmpty() && canCreate && !isSubmitting,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (isSubmitting) "তৈরি হচ্ছে…" else "Invoice তৈরি করুন") }
                lastResult?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = if (it.startsWith("✔")) SuccessGreen else DangerRed) }
            }
        }

        // ── dealer's invoice history, approve + share, inline ──
        if (dealerInvoices.isNotEmpty()) {
            item { Text("এই dealer-এর Invoice (${dealerInvoices.size})", fontWeight = FontWeight.SemiBold, color = TextPrimary) }
            items(dealerInvoices.take(10), key = { it.id }) { inv ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(inv.invoiceNo, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        com.abm.erp.core.StatusPill(inv.status)
                    }
                    Text("৳${"%,.0f".format(inv.total)} · ${inv.createdAt.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    var rowError by remember(inv.id) { mutableStateOf<String?>(null) }
                    rowError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (inv.status == "PENDING" && canApprove) {
                            // was discarding its result entirely — now reports the real reason
                            TextButton(onClick = { MockRepository.approveSalesInvoice(inv.id, onRejected = { r -> rowError = r }) }) { Text("✓ Approve", color = SuccessGreen) }
                        }
                        // v113-142 — Edit where the mistake is actually noticed, instead of
                        // making the person hunt for it. Shown only for invoices genuinely
                        // still editable: PENDING with no payment applied — the exact
                        // condition updateSalesInvoice enforces, so the button never
                        // appears only to be refused. Routes to the sales screen's Invoice
                        // tab (verified: `sales?tab=2`), which already owns the real edit
                        // form — no second editing UI. Checked first that a
                        // `sales_chain?editInvoice=` route does NOT exist rather than
                        // shipping a button pointing at nothing.
                        if (inv.status == "PENDING" && inv.paidAmount <= 0.0) {
                            TextButton(onClick = { onNavigate("sales?tab=2") }) { Text("✏ Edit") }
                        }
                        TextButton(onClick = { onNavigate("invoice_doc/${inv.id}") }) { Text("Print/Share") }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    // ── helper sheets (contract: helpers are dialogs, never navigation) ──
    if (showAddDealer) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showAddDealer = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(4.dp).heightIn(max = 560.dp)) {
                    val dealersVm: com.abm.erp.ui.dealer.DealersScreenViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
                    com.abm.erp.ui.dealer.AddDealerForm(dealersVm) { showAddDealer = false }
                }
            }
        }
    }
    if (showAddProduct) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showAddProduct = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                var pName by remember { mutableStateOf("") }
                var pSku by remember { mutableStateOf("") }
                var pUnit by remember { mutableStateOf("pcs") }
                var pCategory by remember { mutableStateOf("") }
                var pPrice by remember { mutableStateOf("") }
                var pError by remember { mutableStateOf<String?>(null) }
                Column(Modifier.padding(16.dp)) {
                    Text("নতুন Product", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("যোগ করার সাথে সাথেই এই invoice-এ ব্যবহার করা যাবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    pError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = pName, onValueChange = { pName = it }, label = { Text("নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = pSku, onValueChange = { pSku = it }, label = { Text("SKU") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = pUnit, onValueChange = { pUnit = it }, label = { Text("Unit") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = pPrice, onValueChange = { pPrice = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("দাম") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = pCategory, onValueChange = { pCategory = it }, label = { Text("Category") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            pError = null
                            // Real addProduct — same engine the Inventory screen uses,
                            // with its real duplicate/permission/validation rejections
                            // surfaced here rather than a silent failure.
                            com.abm.erp.data.InventoryRepository.addProduct(
                                sku = pSku.trim(), name = pName.trim(), unit = pUnit.trim().ifBlank { "pcs" },
                                category = pCategory.trim(), reorderThreshold = 0.0,
                                defaultUnitPrice = pPrice.toDoubleOrNull() ?: 0.0,
                                onRejected = { r -> pError = r },
                                onCreated = { showAddProduct = false },
                            )
                        },
                        enabled = pName.isNotBlank() && pSku.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("যোগ করুন") }
                }
            }
        }
    }
    if (showReturnSheet && dealer != null) {
        DealerReturnSheet(dealer = dealer, cartHint = cart, onDismiss = { showReturnSheet = false }, scope = scope)
    }
}

/**
 * Damage/Return helper — a sheet, not a page. Thin UI over the existing
 * `createSalesReturn` engine (which enforces the returnable-qty validation, restocking
 * and due reversal itself; nothing re-implemented here).
 */
@Composable
private fun DealerReturnSheet(
    dealer: com.abm.erp.data.Dealer,
    cartHint: List<SalesInvoiceLineItem>,
    onDismiss: () -> Unit,
    scope: kotlinx.coroutines.CoroutineScope,
) {
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    var productId by remember { mutableStateOf<String?>(null) }
    var qty by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<String?>(null) }
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 520.dp)) {
                Text("Damage / Return — ${dealer.name}", fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(8.dp))
                Column(Modifier.heightIn(max = 160.dp).verticalScroll(rememberScrollState())) {
                    products.filter { !it.isDeleted }.take(20).forEach { p ->
                        Text(
                            p.name,
                            fontWeight = if (productId == p.id) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().clickable { productId = p.id }.padding(vertical = 6.dp),
                        )
                    }
                }
                OutlinedTextField(value = qty, onValueChange = { qty = it }, label = { Text("Qty") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val p = products.firstOrNull { it.id == productId } ?: return@Button
                        val q = qty.toIntOrNull() ?: return@Button
                        scope.launch {
                            result = null
                            val r = MockRepository.createSalesReturn(
                                invoiceId = null, partyType = com.abm.erp.data.PartyType.DEALER,
                                partyId = dealer.id, partyName = dealer.name,
                                lineItems = listOf(SalesInvoiceLineItem(p.id, p.name, p.unit, q, p.defaultUnitPrice)),
                                reason = reason,
                                onRejected = { rejectReason -> result = "✖ $rejectReason" },
                            )
                            if (r != null) result = "✔ Return ${r.returnNo} তৈরি — approve হলে stock/due ঠিক হবে।"
                            else if (result == null) result = "✖ Return তৈরি হয়নি — আবার চেষ্টা করুন।"
                        }
                    },
                    enabled = productId != null && (qty.toIntOrNull() ?: 0) > 0 && reason.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Return জমা দিন") }
                result?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = if (it.startsWith("✔")) SuccessGreen else DangerRed) }
            }
        }
    }
}
