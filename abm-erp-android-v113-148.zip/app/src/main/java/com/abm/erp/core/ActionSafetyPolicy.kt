package com.abm.erp.core

/**
 * Task 4 — centralized transaction delete/archive-safety policy. A single
 * source of truth for "is this record in a state where soft-delete/archive
 * is safe", instead of each screen inventing its own ad-hoc status check.
 * UniversalActionMenu consults this before enabling its Archive action;
 * screens don't need to duplicate this logic themselves.
 */
object ActionSafetyPolicy {
    /** Status strings (case-insensitive) that mean "this record is committed to a business outcome" — archiving it would hide financial/operational history rather than just tidy up a draft. */
    private val PROTECTED_STATUSES = setOf(
        "SUBMITTED", "APPROVED", "POSTED", "PAID", "PARTIALLY_PAID", "DELIVERED",
        "RECEIVED", "COMPLETED", "CLOSED", "VERIFIED", "FULFILLED", "CONFIRMED",
    )

    fun isProtected(status: String?): Boolean = status != null && status.trim().uppercase() in PROTECTED_STATUSES

    /** Null when archiving is safe; otherwise a human-readable Bengali reason to show instead of the action. */
    fun archiveBlockedReason(status: String?): String? =
        if (isProtected(status)) "এই রেকর্ড \"$status\" অবস্থায় — ব্যবসায়িক ইতিহাস সংরক্ষণের জন্য সরাসরি archive/delete করা যাবে না। প্রয়োজনে existing cancel/reverse workflow ব্যবহার করুন।" else null
}
