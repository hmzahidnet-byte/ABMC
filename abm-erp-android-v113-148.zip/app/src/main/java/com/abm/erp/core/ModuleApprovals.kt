package com.abm.erp.core

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.data.ApprovalRequest
import com.abm.erp.data.advanceApproval
import com.abm.erp.data.escalateApproval
import com.abm.erp.data.forwardApproval
import com.abm.erp.data.ApprovalStatus
import com.abm.erp.data.ApprovalType
import com.abm.erp.data.MockRepository
import com.abm.erp.data.PermissionAction
import com.abm.erp.data.PermissionManager
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * Decision 2 (v113-72) — approvals are decentralised.
 *
 * There is no central Approvals inbox any more. Instead, each module renders
 * *its own* pending `ApprovalRequest` rows inline, in the tab the request is
 * actually about: LEAVE inside HRM's Leave tab, "Expense" inside Expenses,
 * "Voucher" inside Ledger's Voucher tab, "SalesInvoice" inside DMS's Dealer
 * Invoice tab, and so on.
 *
 * This is a shared *component*, not a shared *screen* — the same relationship
 * `TaskHeader` has to the module screens. Nothing here gathers records from
 * more than one module: every call site passes the narrow filter it owns.
 *
 * Deliberately NOT a LazyColumn: this is embedded inside module tabs that are
 * already inside a scrolling parent, and a nested lazy list in an unbounded
 * height constraint crashes at runtime.
 */
@Composable
fun ModuleApprovalSection(
    title: String = "অনুমোদনের অপেক্ষায়",
    entityTypes: Set<String> = emptySet(),
    approvalTypes: Set<ApprovalType> = emptySet(),
    modifier: Modifier = Modifier,
) {
    val approvals by MockRepository.approvals.collectAsState()

    // Filters are AND-ed only when both are supplied; an empty set means
    // "don't filter on this axis". A call site that passes neither would get
    // every approval in the system — which is exactly the central inbox this
    // replaces — so that case renders nothing instead.
    if (entityTypes.isEmpty() && approvalTypes.isEmpty()) return

    // remember(...) matters here: this runs inside module tabs that recompose on every
    // scroll/state change, and MockRepository.approvals can be long. Filtering raw in
    // composition would re-scan the whole list every frame — straight out of an 8.3ms
    // (120fps) budget. Keyed on the list identity, so it only re-filters on real change.
    val mine = remember(approvals, entityTypes, approvalTypes) {
        approvals.filter { req ->
            req.status == ApprovalStatus.PENDING &&
                (entityTypes.isEmpty() || req.entityType in entityTypes) &&
                (approvalTypes.isEmpty() || req.type in approvalTypes)
        }
    }
    if (mine.isEmpty()) return

    // v113-101 — canApprove here is deliberately still the coarse "has approval
    // rights at all" gate (zero permission → see nothing, unchanged). The NEW
    // per-request tier check happens inside ModuleApprovalCard itself, since only
    // it has req.level — a blanket boolean here can't tell an ASM-only user's
    // level-1 request from a GM-only level-3 one.
    val canApprove = PermissionManager.canCurrentUser("approval", PermissionAction.APPROVE)
    var forwardDialogFor by remember { mutableStateOf<String?>(null) }

    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Spacer(Modifier.width(8.dp))
            Text("${mine.size}", style = MaterialTheme.typography.labelSmall, color = WarningAmber, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        mine.forEach { req ->
            ModuleApprovalCard(req, canApprove, onForward = { forwardDialogFor = req.id })
            Spacer(Modifier.height(8.dp))
        }
        Spacer(Modifier.height(4.dp))
    }

    forwardDialogFor?.let { reqId ->
        androidx.compose.ui.window.Dialog(onDismissRequest = { forwardDialogFor = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var employeeId by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp)) {
                    Text("Forward / Reassign", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = employeeId,
                        onValueChange = { employeeId = it },
                        label = { Text("Employee ID") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { MockRepository.forwardApproval(reqId, employeeId); forwardDialogFor = null },
                        enabled = employeeId.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm") }
                }
            }
        }
    }
}

@Composable
private fun ModuleApprovalCard(req: ApprovalRequest, canApprove: Boolean, onForward: () -> Unit) {
    var justDenied by remember(req.id) { mutableStateOf<String?>(null) }
    // Mirrors advanceApproval's own tier check exactly (com.abm.erp.data.CASCADE_CHAIN,
    // the override-role set) — so a button is never shown for a tier the backend will
    // just refuse. canApprove alone (blanket permission) can't tell this apart; req.level can.
    val myRole = MockRepository.currentUser.role
    val requiredTier = com.abm.erp.data.CASCADE_CHAIN.getOrNull(req.level - 1)
    val isOverrideRole = myRole in setOf(com.abm.erp.data.UserRole.GM, com.abm.erp.data.UserRole.MD, com.abm.erp.data.UserRole.CHAIRMAN, com.abm.erp.data.UserRole.AGM)
    val canActOnThisTier = canApprove && (requiredTier == null || myRole == requiredTier || isOverrideRole)
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(req.type.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Pending", color = WarningAmber, style = MaterialTheme.typography.labelSmall)
                UniversalActionMenu(
                    moduleReference = "ApprovalRequest", entityId = req.id, entityLabel = req.type.name,
                    shareText = "${req.type} — ${req.fromEmployee}\n${req.detail}\nStatus: ${req.status}",
                    csvHeader = "Type,From,Detail,Status",
                    csvRow = toCsvRow(req.type, req.fromEmployee, req.detail, req.status),
                )
            }
        }
        if (req.fromEmployee.isNotBlank()) {
            Text(req.fromEmployee, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
        Text(req.detail, style = MaterialTheme.typography.bodyMedium)
        // v113-101 — every real approval request is created with level=1
        // (raiseApprovalRequest sets it explicitly; requestApproval defaults to
        // it) and CASCADE_CHAIN is 3 tiers (ASM → RSM → GM) — but until now the
        // only thing wired to a button was setApprovalStatus, which ignores level
        // entirely and lets ANYONE with approval-APPROVE permission flip a
        // request in one tap, ASM tier or not. advanceApproval — the real,
        // already-built cascade engine (level progression, per-tier role check,
        // voucher-specific authority limits, race-condition-safe) — had zero
        // callers anywhere in the app. Swapped in here; the level indicator below
        // makes the cascade state visible instead of invisible-but-silently-real.
        if (req.level > 1) Text("Cascade level ${req.level} of 3", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        // Blueprint §34 — approvals are about latency, so waiting age, not a raw timestamp.
        WaitingAge(req.createdAt)
        if (req.escalated) Text("⚠ Escalated", color = WarningAmber, style = MaterialTheme.typography.labelSmall)
        req.assignedToEmployeeId?.let { Text("→ Forwarded to $it", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }

        if (canActOnThisTier) {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { MockRepository.advanceApproval(req.id, ApprovalStatus.APPROVED, onRejected = { reason -> justDenied = reason }) },
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                ) { Text("Approve") }
                OutlinedButton(
                    onClick = { MockRepository.advanceApproval(req.id, ApprovalStatus.REJECTED, onRejected = { reason -> justDenied = reason }) },
                ) { Text("Reject", color = DangerRed) }
            }
        } else if (canApprove && requiredTier != null) {
            // Has real approval rights in general, just not this request's tier —
            // explained rather than the buttons simply vanishing unexplained.
            Text("এই request-এর জন্য $requiredTier tier দরকার — আপনার role ($myRole) না।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
        if (canApprove) {
            // escalateApproval/forwardApproval's own real backend permission check is
            // the same blanket "approval APPROVE" right, not tier-specific — unlike
            // Approve/Reject above, so this row correctly stays independent of
            // canActOnThisTier rather than nested inside it.
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { MockRepository.escalateApproval(req.id, onRejected = { reason -> justDenied = reason }) }) { Text("⬆ Escalate") }
                TextButton(onClick = onForward) { Text("↪ Forward/Reassign") }
            }
        }
        justDenied?.let {
            Spacer(Modifier.height(4.dp))
            Text(
                "⚠ $it",
                color = DangerRed, style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}
