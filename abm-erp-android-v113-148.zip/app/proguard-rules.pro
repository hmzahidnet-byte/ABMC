# ==================================================
# Mohona ERP — ProGuard/R8 rules (v85, Mission 1)
# ==================================================
#
# IMPORTANT, UNVERIFIED RISK (documented honestly, not tested — this sandbox
# cannot run a real Gradle release build): this app deserializes Firestore
# documents into ~69 domain/Room entity classes via reflection —
# `snapshot.toObject(XxxEntity::class.java)` — throughout MockRepository.kt,
# InventoryRepository.kt, PurchaseRepository.kt, CrmRepository.kt,
# CommsRepository.kt, AccountsRepository.kt, FirebaseSync.kt. R8 cannot see
# those field names are needed (they're never referenced by literal string
# except implicitly by Firestore's own reflection), so without explicit
# -keep rules, release minification WILL silently break Firestore
# deserialization (fields renamed/removed) and offline sync. The rules below
# are a good-faith, standard mitigation for that exact risk, but they have
# not been confirmed against an actual release build in this environment —
# treat this as require-before-ship, not verified-safe.

# ---- Room entities + domain model classes read/written via Firestore reflection ----
-keep class com.abm.erp.data.room.** { *; }
-keepclassmembers class com.abm.erp.data.room.** { *; }
-keep class com.abm.erp.data.** { *; }
-keepclassmembers class com.abm.erp.data.** { *; }

# ---- Room (generated code + annotations) ----
-keep class androidx.room.** { *; }
-dontwarn androidx.room.paging.**
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao class * { *; }

# ---- Firestore/Firebase (reflection-based POJO mapping + Auth/Functions/Messaging) ----
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes EnclosingMethod
-keepattributes InnerClasses
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.firebase.**
-dontwarn com.google.android.gms.**

# ---- Kotlin coroutines / Flow internals (reflection used by some debug tooling) ----
-dontwarn kotlinx.coroutines.**
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory

# ---- Kotlin metadata (needed for reflection-based libraries, incl. Room/Firestore field mapping) ----
-keep class kotlin.Metadata { *; }
-keepattributes RuntimeVisibleAnnotations

# ---- WorkManager (background sync retry) ----
-keep class androidx.work.** { *; }

# ---- ZXing (QR generation) — no reflection use, but keep its public API stable ----
-keep class com.google.zxing.** { *; }
-dontwarn com.google.zxing.**

# ---- Coil (image loading from Firebase Storage URLs) ----
-dontwarn coil.**

# ---- Crashlytics: keep source file + line numbers for useful stack traces, but rename otherwise ----
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
