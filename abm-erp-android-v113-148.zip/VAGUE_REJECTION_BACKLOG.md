# "Vague/silent rejection" backlog — full scope, v113-105

Same bug class as Invoice/Collection/Memo/Expense/Employee/Approval/Correction/
Complaint/Leave/Hiring/RawMaterial (already fixed): a data-layer function has
2+ real rejection reasons, all `AppLog.w`-only; UI shows a generic guess, a
hardcoded wrong string, or silently discards the result.

Full-app regex sweep (v113-104/105) found ~100 more instances. Fixed so far this
session (data fn + UI wired, verified): chairmanApproveHiring, issueRawMaterial.
Everything below is NOT yet fixed — real, found, not yet touched. Grouped by file,
highest reject-count first within each. Fix pattern for every one: read the real
function body in MockRepository.kt/*.Engine.kt, add `onRejected: (String) -> Unit
= {}` (checking existing param order for trailing-lambda callers first), give each
distinct rejection point a specific Bangla message, wire the UI call site to show
it (Toast/local error state, matching that file's existing convention), balance
sweep after every file.

## DealersScreen.kt (18 functions — highest-density file, do this one first)
~~deleteRetailer(4) rejectRetailer(4) transferRetailer(4) rejectDealer(4)
createDealer(4) createRetailer(4) setTerritoryPolygon(4) updateRetailerLocation(3)
approveRetailer(3) setRetailerGeofenceRadius(3) approveDealer(3)
assignRetailerOfficer(3)~~ — DONE (12 of 18; last 4 turned out already fixed in an
earlier batch, only updateRetailerLocation was a real remaining gap, closed v113-112).
~~setDealerCreditStatus(2) createCompanyMarket(2) verifyRetailerLocation(2)
setRetailerCreditHold(2) setDealerMonthlyTarget(2)~~ — all 5 already done in
an earlier batch, verified v113-113.
~~confirmLegacyAddressMatch(1) restoreRetailer(1) deleteDealer(1)
reviewLocationAlert(1) restoreDealer(1) reviewSecurityEvent(1)~~ — ALL DONE
v113-117. DealersScreen.kt fully closed (18/18).

## Separate, bigger item found while fixing deleteRetailer (not a quick fix)
`archiveRetailerAction`/`UniversalActionMenu.onArchive` — the shared
`UniversalActionMenu` component's `onArchive: (() -> Unit)?` callback has NO
error-reporting channel at all, used by many entity types across the app. Fixing
this properly means changing the callback's type signature and updating every
caller — a real architectural change, not a per-function patch. Left as-is.

## PayrollScreen.kt (16 functions)
~~createDelegation(4) rejectEmployeeOnboarding(4) changeEmployeeRole(4)
setEmployeeStatus(4) linkEmployeeToUserAccount(3) createTransferRequest(3)
createGeoOverride(3) assignDirectManager(3) setApprovalLimits(3)~~ — DONE (9 of 16,
v113-107/112).
~~assignEmployeeArea(2) enterManualAppraisalScores(2) resetUserAccountPin(2)
unlockUserAccount(2) generateAppraisal(2) setUserAccountActive(2)~~ — DONE v113-113.
~~transferEmployeeArea(1) finalizePayrollPreparation(1)~~ — DONE v113-120. PayrollScreen.kt fully closed (16/16).

## ProductionWarehouseScreen.kt / ProductionScreen.kt (9)
~~confirmFinishedGoods(4) dispatchWarehouseTransfer(4) receiveWarehouseTransfer(3)~~
— DONE v113-108/114.
~~createProductionPlan(2) createWarehouseTransferRequest(2) recordPacking(2)~~ —
DONE v113-115.
~~recordQualityInspection(1) updateProductionOrderStatus(1)~~ — DONE v113-118 (updateProductionOrderStatus also gained a missing permission check — 6 of its 7 buttons had none at all). ProductionWarehouseScreen.kt/ProductionScreen.kt fully closed.

## PurchaseScreen.kt (8)
~~approvePurchaseReturn(3) createSupplier(3) approvePurchaseRequest(3) receiveGoods(2)~~
— DONE v113-111/115.
~~rejectPurchaseRequest(2)~~ — DONE v113-116.
~~createPurchaseRequest(1) createPurchaseReturn(1) createPurchaseOrder(1)
restoreSupplier(1) deleteSupplier(1)~~ — DONE v113-118. PurchaseScreen.kt fully closed (8/8).

## LedgerScreen.kt (4)
~~createVoucher(4) reverseVoucher(3) createAccount(2)~~ — DONE v113-108/110/114.
~~deleteVoucher(1)~~ — DONE v113-118. LedgerScreen.kt fully closed (4/4).

## InventoryScreen.kt (4)
~~approveStockCount(4) reportDamage(3)~~ — DONE v113-109/114.
~~adjustStockToCount(2)~~ — DONE v113-116. duplicateProduct(2) — data fn done,
UI unfixable without the UniversalActionMenu onDuplicate signature change (same
gap as onArchive).
~~updateStockIntelligenceThresholds(1)~~ — DONE v113-120. InventoryScreen.kt fully closed (duplicateProduct's UI remains the one documented UniversalActionMenu exception).

## HiringApprovalCenterScreen.kt — ALL DONE (chairmanApproveHiring,
chairmanRejectHiring, chairmanReturnForCorrection, submitHiringRequest — v113-116)

## SalesChainScreen.kt / CreditAndBillingScreen.kt (6)
~~cancelSalesOrder(4) approveSalesReturn(3) approveSalesOrder(2)~~ — DONE v113-110.
~~createQuotation(1) restoreSalesInvoice(1) createPosSale(1) createDeliveryChallan(1)~~ — DONE v113-119. SalesChainScreen.kt/CreditAndBillingScreen.kt fully closed.

## GeoCrmScreen.kt (4)
~~createLead(2)~~ — DONE v113-116.
~~createOpportunity(1) createCustomerComplaint(1)~~ — DONE v113-119. rejectCustomerComplaint(1) — confirmed unreachable (call site always passes non-blank hardcoded reason), correctly not force-wired. GeoCrmScreen.kt fully closed.

## BoardroomScreen.kt (3)
~~createManagementAction(1) updateExceptionStatus(1) updateExecutiveSettings(1)~~ — DONE v113-120. BoardroomScreen.kt fully closed.

## Misc single-file (1 each — lower priority, real but isolated)
ALL DONE v113-120: postAnnouncement, postCircular, createRetailerComplaint,
createVehicle, submitVacancyRequest, unlockAccountingPeriod.
ChairmanHomeScreen.kt's 4 McRestoreRow calls (restoreRetailer/Dealer/SalesInvoice/
Supplier) — their data functions all have onRejected (fixed in earlier batches);
the display text was corrected in v113-100; McRestoreRow's own callback type
(`() -> Boolean`, no reason channel) is the same documented architectural
limitation as UniversalActionMenu — not re-litigated.

## Explicitly NOT part of this backlog (checked, correctly excluded)
`RecordQrCard.kt`/`issue`, `ModuleBrowseFlow.kt`/`issue`, `SalesChainScreen.kt`/`issue`,
`InvoiceDocumentScreen.kt`/`issue`, `StructuredExports.kt`/`issue` — all call
`QrRegistry.issue()`, a different, already-correct function (returns a real payload
string, not a reject-prone Boolean/nullable business action). `UniversalScannerScreen.kt`/
`isSecurePayload` — a query function, not an action; nothing to reject.
`ModuleApprovals.kt`/`forwardApproval`, `UniversalActionMenu.kt`/`submitCorrectionRequest`
— single-reason, already-guarded by their button's `enabled=`, matching the earlier
session's judgment call on `chairmanRejectCorrection`-style low-risk cases.

## Method for whoever (or whichever future session) continues this
1. `grep -n "fun.*<name>" -A 20 app/src/main/java/com/abm/erp/data/*.kt` — read the real body first, every time.
2. Add `onRejected`, positioned before any existing trailing-lambda param.
3. Find every UI caller (`grep -rn "<name>(" app/src/main --include=*.kt`), wire each.
4. Balance sweep after every file, not just at the end.
5. Cross off the list here as you go — don't let it silently regenerate from scratch next time.
