# ABM ERP Project State

Version: v113 → v113-1 (Section 9 — Accuracy & Audit, continuation)
Date: 2026-08-01

## Build Status
- Gradle build: **NOT RUN**. Same sandbox limitation as every prior batch (no network, no `gradle-wrapper.jar`). All findings below come from manually reading the actual v113 source — DAOs, StateFlows, coroutine scopes, and every UI call site of the functions touched — not from a compiler or test run. Please run a real build/smoke test and report back.
- Note on the PROJECT_STATE.md found in the v113 ZIP: it was still the v106-3 compile-fix state file (no mention of Section 9 at all), even though the actual source already contains a fair amount of finished Section 9 work (idempotency guards, DamageReport/Expense audit trails, the Sync Status Center screen, etc., all present and dated/commented as such in v113). This batch treated the **actual source code** as ground truth for "what's already done," not the stale doc, per your instruction not to restart or repeat completed work. This file replaces that stale one.

## Section 9 — Accuracy & Audit: Task-by-Task Status

### 1. Ignored return values on critical posting paths
Audited Collection, Expense, Production, Warehouse, Purchase, Sales Return, Stock Adjustment, Attendance Correction. Found and fixed **two confirmed, reachable bugs** (both are the same underlying anti-pattern: a function returns a value about an operation that hasn't finished yet, because the real result is only known inside a `scope.launch{}` that hasn't run when the function returns):

- **`InventoryRepository.reportDamage`** — always returned `false` to its caller, success or not (see Files Changed #1). This is the most serious finding in this batch.
- **`MockRepository.createCollection`** — always returned a non-null "success" object even when the async coroutine silently skipped persisting a zero/negative-amount collection (see Files Changed #3).

I wrote a script to scan every `*Repository.kt` file for this exact shape (`var x = false/null` → `scope.launch { ...; x = true }` → `return x`) — no third occurrence was found. Other checked functions (Expense's `submitExpense`/`approveExpense`/`rejectExpense`, `dispatchWarehouseTransfer`, `stockInWithExpiry`, `createSupplierPayment`, purchase-return flows) all validate synchronously before returning or are genuine `suspend fun`s awaited by their callers — their return values are trustworthy. Production and Warehouse creation/dispatch paths were spot-checked and are sound.

### 2. Idempotency on financial/stock/production transactions
Most critical state-transition functions already have real idempotency guards from prior audit work (`verifyCollection`, `approveDealer`, `approveSalesReturn`, `approvePurchaseReturn`, `confirmFinishedGoods`, production-plan submit, etc.) — confirmed by direct code reading, not just comments. Found **one confirmed gap**:

- **`MockRepository.chairmanApproveCorrection`** (covers Invoice/Collection/Attendance/Dealer/Retailer/Production/Warehouse/Stock/Payroll correction-and-reversal) only checked the *cached* `correctionRequests` StateFlow once, before `scope.launch`. Every sibling approval function re-checks status fresh from Room right before applying effects; this one didn't, so a double-tap (or a UI that doesn't disable the button fast enough) could double-apply a reversal — a real double-refund risk. Fixed (see Files Changed #2).

`dispatchWarehouseTransfer`'s status check is against the cached StateFlow too, but it's a genuine `suspend fun` awaited synchronously by its one caller with no fire-and-forget gap, so the exploitable window is far smaller (would need the UI to allow two truly simultaneous invocations, which it doesn't — the button isn't disabled mid-flight in the reviewed call site). Noted, not changed this batch — see Remaining Production Risks.

### 3. Immutable audit-log coverage
Checked Approval, QR Scan, Stock Movement, Financial Posting, Permission Denial, Login, Device Trust, Attendance Correction. All had real `logAudit(...)` calls already **except Device Trust**:

- **`touchOrRegisterTrustedDevice`** — new-device registration and mock-location-suspicion increments were written to Room/Firestore with zero trace in the audit log. Fixed (see Files Changed #2).

Login (`logAudit("Session", ..., "LOGIN")` + `LOGIN_BLOCKED_INACTIVE`), QR Scan (`QR_SCANNED` / `SCAN_ACCESS_DENIED` in `UniversalScannerScreen.kt`), Permission Denial (the `PermissionManager.canCurrentUser(...) → DENY` pattern used consistently everywhere), Stock Movement (every `adjustStock` call is paired with a `StockMovementEntity` insert), Financial Posting (`addLedgerEntry`/`postPartyLedgerEntry` called from every verified collection/approved expense/etc.), and Approval (every approve/reject path) were all confirmed present and unchanged.

### 4. Sync Status Center
`SyncStatusCenterScreen.kt` genuinely shows: **Saved Locally** (always true — Room write always happens before any network attempt, verified in every repository function read this batch), **Synced** (implied when `failedSyncIds` is empty), **Failed** (the real `failedSyncIds` StateFlow, per-record), and **Retry** (a real button that re-triggers `startCrossDeviceSync`). **Pending** is not shown as its own distinct state, and I did not add it this batch — the codebase only tracks a `syncStatus` column (PENDING/SYNCED/FAILED) on 3 entities total (grepped `Entities.kt` directly), not universally, and the existing code has its own honest comment on `failedSyncCount` admitting it's "partial, session-only... NOT comprehensive (most `.addOnFailureListener` call sites in this codebase don't route through it)." Building a real, universal Pending tracker would mean instrumenting dozens of Firestore `.set()`/`.update()` call sites across every repository — a genuine architecture change, not a Section 9 bug fix, so I left it as a documented gap rather than a quick patch that would just be cosmetic. Flagging this explicitly for your decision rather than silently building new infrastructure.

### 5. No success shown on underlying transaction failure
This is items #1's `reportDamage` and `createCollection` bugs again, viewed from the UI-trust angle — both are fixed. No third instance found by the systematic scan described in #1.

### 6. Project-wide search for similar hidden issues
Ran a project-wide script for the exact `var x = false` → mutated inside `scope.launch` → `return x` shape (found only `reportDamage`). Additionally grepped every `AppLog.w(..., "rejected"/"skipped")` message in every `*Repository.kt` file (56 total) and checked each one's enclosing function's return path — all except the two fixed this batch validate synchronously before any async work. Did not find further confirmed bugs; did not make speculative changes.

## Files Changed

1. **`app/src/main/java/com/abm/erp/data/InventoryRepository.kt`** — `reportDamage`: moved the insufficient-stock check to run synchronously (against the already-cached `stockLevels`, same source `reserveStock` already uses) before `scope.launch`, so the returned `Boolean` reflects reality instead of always being `false`. Added a fresh re-check inside the coroutine for real atomicity against a concurrent stock change between the cached check and the coroutine actually running. No change to `InventoryScreen.kt` — it already correctly branches on the return value; it was just always receiving the wrong value.

2. **`app/src/main/java/com/abm/erp/data/MockRepository.kt`**
   - `chairmanApproveCorrection`: added a fresh Room-sourced status re-check as the first statement inside `scope.launch`, closing the double-application race window described above.
   - `touchOrRegisterTrustedDevice`: added `logAudit("TrustedDevice", ..., "REGISTER", ...)` for new devices and `logAudit("TrustedDevice", ..., "MOCK_LOCATION_SUSPECTED", ...)` for suspicion increments.

3. **`app/src/main/java/com/abm/erp/ui/dealer/DealersScreen.kt`** — `NewCollectionForm`'s Submit button: `enabled` now requires `amount > 0` (previously only required it to parse as a Double, so `0` or a negative number enabled submission); added the same guard inside `onClick` as defense-in-depth. This is what makes `MockRepository.createCollection`'s existing `amount <= 0` guard actually unreachable from the UI instead of silently swallowing a "successful-looking" zero-amount collection.

## Completed in This Batch
- 4 confirmed, reachable production bugs found and fixed (not hypothetical — each was traced to an actual UI call site and its real user-facing consequence).
- Full re-verification pass across all 6 numbered Section 9 tasks, documented above with what was checked and what the result was for each, not just the items that needed a code change.

## Remaining Compile Errors
- None expected from these changes (small, self-contained diffs; no new imports needed, no signature changes visible to other callers). **Not verified by a real Gradle build.**

## Remaining Production Risks
- **`dispatchWarehouseTransfer`** status/stock checks are against cached StateFlow, not inside a DB transaction. Low real-world risk (suspend fun, single awaited call site, button not exploitable via true double-tap in the reviewed screen) but worth a `db.withTransaction` re-check in a future batch if this ever gets a second call site or a less-guarded UI entry point.
- **Sync Status Center "Pending" state** is not distinctly shown — see Section 9 item #4 above. This is a real gap against the letter of the spec, but closing it properly means instrumenting sync call sites project-wide, which is bigger than a Section 9 audit fix. Recommend scoping this as its own follow-up task rather than folding it into Section 9.
- **`failedSyncCount`** (used elsewhere, e.g. dashboards) is explicitly partial per its own code comment — not all `.addOnFailureListener` call sites feed it. Pre-existing, documented, not touched this batch.

## MockRepository Status
- Unchanged (no migration performed, per standing instructions not to refactor MockRepository).

## Database Status
- No schema/migration changes this batch — all fixes are logic-level (control flow, validation ordering, added audit-log calls). Room version unchanged.

## Firebase Status
- No rules/functions/schema changes. `TrustedDevice` audit entries flow through the existing `activityLog`/`logAudit` → Firestore sync path already used by every other audited entity type; no new collection created.

## Tests Performed
- Gradle build: **not run** (sandbox limitation, unchanged).
- Static verification: project-wide brace/paren balance check before and after edits (confirmed the pre-existing 1-paren imbalance in `MockRepository.kt` already existed in the untouched v113 ZIP — not introduced this batch — and that all edits are otherwise balanced); line-by-line diff of every changed file against the original v113 baseline; the two systematic pattern-scan scripts described in Section 9 items #1 and #6; manual trace of every UI caller of `reportDamage`, `createCollection`, `chairmanApproveCorrection`, and `touchOrRegisterTrustedDevice`.
- Unit/physical-device/offline-online/multi-user tests: not run.

## Recommended Next Section
1. Real device/Gradle smoke test of this batch specifically: report damaged stock (confirm the success message now matches reality), submit a ৳0 collection attempt (confirm the button stays disabled), and a rapid double-tap on Chairman's Approve Correction button (confirm only one reversal posts).
2. If the Sync Status Center's "Pending" state is actually wanted, scope it as its own task — it needs a project-wide inventory of sync call sites, not a quick patch.
3. Otherwise, continue to whichever Section comes after 9 in your working plan, or begin the standing MockRepository migration Phase 1 (Auth) if no further audit sections remain.

## Update — v113-2 (Section 9 checklist closure)
- Sync Status Center: added explicit "Sync Pending" row (shown when offline).
- Idempotency (double-tap) guards added to Collection, Stock Adjustment, Production Plan create buttons — Invoice already had this pattern; now all 4 named workflows match.
- Section 9 checklist now fully implemented: Room+Firebase ✓, 5 sync states ✓, idempotency on invoice/collection/stock/production ✓, audit logs ✓, no-false-success ✓.

## Update — v113-3 (flow verification A-H)
Bugs found & fixed:
- C (Retailer QR→order): was filtering salesInvoices.dealerId==retailerId (wrong field/model) — always empty. Now uses MockRepository.orders (RetailOrder.retailerId), the real model.
- H (offline→reconnect→sync): Sync Status Center's Retry button called startCrossDeviceSync, which no-ops once already syncing (same-companyId guard) — Retry did nothing after initial login sync. Added forceResync() (MockRepository + InventoryRepository) that resets the guard so Retry genuinely re-attaches listeners.
Verified working, no changes needed: A (PIN+biometric — device-local binding correct), B (attendance overtimeMinutes -> refreshPayrollAbsences -> payroll, real chain), D (Dealer QR->ledger, correctly typed), E (Production->QC gate->factory stock->dispatch->IN_TRANSIT->receive, atomic + idempotent), F (Invoice approve: atomic txn, stock-out, due, ledger, all present), G (Collection verify: atomic txn, due reduction, cash/bank ledger via addLedgerEntry — verified previously).
Known pre-existing gap, not touched: PIN login source is named "demoAccounts" (legacy naming, flagged in earlier PROJECT_STATE hardening list, not a functional break this pass).

## Update — v113-4 (Section 9 correctness fix, focused batch)
Date: 2026-08-01

### Files actually modified this batch (all of them, not just 3):
1. **`app/src/main/java/com/abm/erp/data/InventoryRepository.kt`**
   - `reportDamage`: now `suspend fun`. Stock check, `adjustStock`, `DamageReportEntity` save, and the audit log write all happen inside one `db.withTransaction` (Room coalesces the nested `adjustStock`'s own `db.withTransaction` into the same transaction). Returns `true` only after that transaction has actually committed — there is no `scope.launch` left in this function, so it can no longer report success before the work finishes. Returns `false` on insufficient/concurrently-changed stock (checked from Room inside the transaction, not the cached StateFlow) or on invalid input. Firestore push happens after, best-effort, and never gates the return value (matches this app's offline-first design).
   - `adjustStockToCount`: same treatment — now `suspend fun` returning `Boolean`, real transaction, awaited audit log, rejects negative counts.

2. **`app/src/main/java/com/abm/erp/data/MockRepository.kt`**
   - Added `suspend fun logAuditAwaited(...)` — same write as `logAudit`, but suspends until the Room insert actually completes instead of firing on `scope.launch`. `logAudit` itself is now a one-line wrapper (`scope.launch { logAuditAwaited(...) }`) — zero behavior change for its ~100 existing fire-and-forget callers. Needed so `reportDamage`/`adjustStockToCount` can genuinely wait for the audit write before returning.
   - `chairmanApproveCorrection`: replaced the "re-check status, then proceed" guard with a true atomic claim — one `db.withTransaction` that reads the current status AND flips it to the new `PROCESSING` state in the same transaction, returning whether the claim succeeded. Every module-specific reversal/correction side effect (Invoice/Collection/Attendance/Dealer/Retailer/Production/Warehouse/Stock/Payroll) now only runs after a successful claim. A second concurrent call sees `PROCESSING` (or `APPLIED`) inside that same atomic read and returns `false` immediately — zero side effects — instead of the previous version's non-atomic "check, then later write" gap. Finalization at the end of the function still flips `PROCESSING → APPLIED` as before.
   - No other logic in `chairmanApproveCorrection` (the `when (request.module)` block, reversal/correction id generation, ledger/stock posting) was touched — only the guard.

3. **`app/src/main/java/com/abm/erp/data/Models.kt`**
   - `CorrectionRequestStatus` enum: added `PROCESSING` between `MANAGER_REVIEW` and `CHAIRMAN_APPROVED`. Status is stored as a plain TEXT column (not a typed Room enum column), so this needed no migration and no schema change.

4. **`app/src/main/java/com/abm/erp/ui/inventory/InventoryScreen.kt`**
   - `InventoryViewModel.adjustStockToCount` and `.reportDamage`: both now `suspend fun` wrappers matching the repository.
   - `StockAdjustmentTab`: submit now launches a coroutine that awaits the real `Boolean` result. Success: shows "✓ Adjustment recorded" and clears the form. Failure: keeps the form's contents and shows a real Bangla error message in `DangerRed` (previously always green/success text regardless of outcome). `isSubmitting` now guards the button end-to-end (disabled + early-return) for the actual in-flight duration of the suspend call, not a fixed 1200ms timer.
   - `DamageTrackingTab`: same treatment — awaits `reportDamage`'s real result, only clears the form and shows the success message on `true`, added a real `isSubmitting` guard (this composable had no duplicate-submission protection at all before).

5. **`app/src/main/java/com/abm/erp/ui/admin/SyncStatusCenterScreen.kt`**
   - "Sync Pending" row's label and doc comment now explicitly say this is a live offline/online status signal, not a count from a persistent Room sync-queue table (no such table exists in this codebase).
   - Renamed the action from "Retry" to "Reconnect (listener refresh)" and added a visible line stating it does not resend the records listed in the failed-records section — `forceResync` only re-attaches Firestore listeners; there is no function anywhere in this codebase that replays a specific failed push from `failedSyncIds`. The failed-records list itself now says so directly instead of implying the reconnect action fixes it.

### Verification performed
- Project-wide brace/paren balance check before and after (braces balanced; the same single pre-existing paren imbalance in `MockRepository.kt` — present in the untouched v113 ZIP before any of my batches — is unchanged, not introduced by this batch).
- Traced every caller of `reportDamage`, `adjustStockToCount`, `logAudit`/`logAuditAwaited`, and `chairmanApproveCorrection` — confirmed no other call site besides the ones listed above needed updating for the new suspend signatures.
- Confirmed no exhaustive `when` on `CorrectionRequestStatus` exists anywhere that the new `PROCESSING` case could break.
- Gradle build: **still not run** — same sandbox limitation as every prior batch (no network, `gradle-wrapper.jar` still missing). All of the above is from direct code reading and manual tracing, not a compiler run.

### Explicitly not done this batch (out of the stated scope)
- No new persistent Room sync-queue table was added — Task 4 asked to stop *mislabeling* the existing signal, not to build the real queue. That remains a real, larger follow-up if a true "Pending" count is wanted.
- No actual retry-failed-push mechanism was built (there still isn't one for the general `failedSyncIds` set) — Task 4 also asked not to claim reconnect achieves this, which is now honestly labeled rather than implemented.
- MockRepository was not broadly refactored — only the two functions instruction #3 named, plus the one small `logAuditAwaited` extraction needed to make instruction #1's "required local audit succeed" gate real.

## Update — v113-5 (Enterprise Workspace redesign, Part 1: Home Dashboard)
Date: 2026-08-01
Scope: visual reorganization only, per explicit rules (no business-logic changes, no schema/Firestore/repository/navigation changes, no functionality removed).

### File changed
**`app/src/main/java/com/abm/erp/ui/dashboard/MainDashboardScreen.kt`**
- Added `DashboardSectionLabel(text)` — small-caps header + hairline divider, a standard enterprise-dashboard grouping convention. Purely visual; wraps no logic.
- Added `DashboardStatusStrip(...)` — compact glanceable row placed directly under the header banner, showing GPS/location (existing `employee.geoLabel`), unread Notifications count, and Pending Approvals count. Built entirely from data already loaded on this screen (`MockRepository.notifications`, `vm.approvals`); no new data source, no new route — Notifications and Approvals chips navigate to the already-existing `"notifications"`/`"approvals"` routes.
- Inserted 6 section labels at the file's own pre-existing `// ---- ... ----` comment boundaries, grouping the existing (untouched) cards into: **Overview** (Target, Chairman's Notice), **Executive Summary** (KPI grid), **Performance & Trends** (Live Business Feed / GPS Team / trend widgets), **Alerts & Activity** (Smart Alerts, Recent Activities, Today's Priority, Low-Performing Dealers), **Insights** (Top Products), **Quick Actions**.
- Every existing card, KPI tile, widget-visibility toggle, dialog, and business-logic calculation is untouched — only labels and one new status-strip row were added above/around them. No composable was deleted, renamed in a way that breaks callers, or reordered in a way that changes what data it reads.

### Not touched (explicitly out of scope this batch)
- Room schema, Firestore structure, repository architecture, navigation graph/routes — none modified.
- MainActivity.kt's top-bar Search icon / `UniversalSearchDialog` — untouched, still there, still the app-wide search entry point.
- Any other screen — this batch is Home Dashboard only, per the message's stated scope (item 1 of a larger redesign plan).

### Verification
- Brace/paren balance for `MainDashboardScreen.kt` confirmed balanced before and after (397/397 braces, 884/884 parens).
- Project-wide balance check: only the same single pre-existing `MockRepository.kt` paren imbalance from prior batches remains (not touched this batch, not new).
- Confirmed `Divider(...)` and `AssistChipDefaults.assistChipColors(...)` match this project's existing Compose BOM (2024.06.00) and match usage patterns already present elsewhere in the codebase (e.g. `LedgerScreen.kt`, `CreditAndBillingScreen.kt`).
- Gradle build: **not run** — same sandbox limitation as every prior batch (no network, no `gradle-wrapper.jar`). This batch is lower-risk than logic changes (additive composables + comment-anchored insertions, zero deletions), but still needs a real build/visual QA pass before shipping.

### Recommended next step
Real build + visual QA of the Home Dashboard specifically (confirm the status strip renders correctly across roles — note the GPS chip is disabled/informational-only by design, and Executive Summary/Performance sections are AGM+-gated same as before). Then continue the Enterprise Workspace redesign's remaining items (module list / other screens) as separate batches, since this message's stated scope was Home Dashboard only.

## Update — v113-6 (Enterprise Workspace redesign, Part 2: Module Hub Design)
Date: 2026-08-01
Scope: visual only — same rules as Part 1 (no logic/schema/Firestore/repository/nav changes, nothing removed).

The app already had a shared "branded module workspace" component (`ModuleGradientHeader` + `SubModuleGrid`, in `core/SubModuleGrid.kt`) used by 7 screens (Purchase, Inventory, Ledger/Finance, Billing, Comms, Market, Production). Of the 5 example modules named, 2 already had it (Production, Finance-via-Ledger); the other 3 didn't. Gave those 3 the same treatment:

### Files changed
1. **`app/src/main/java/com/abm/erp/ui/sales/SalesChainScreen.kt`** — replaced the plain "Sales Chain" text title with `ModuleGradientHeader("Sales / CRM Workspace", "📈", blue)`. Same `SubModuleGrid`/tab logic, same data, same navigation underneath — only the top-level Column was wrapped to add the header above the existing padded content.
2. **`app/src/main/java/com/abm/erp/ui/hrm/PayrollScreen.kt`** — replaced "HR & Payroll" text title with `ModuleGradientHeader("HR Management System", "🧑‍💼", rose)`. Same treatment.
3. **`app/src/main/java/com/abm/erp/ui/production/ProductionWarehouseScreen.kt`** — replaced "Production → Warehouse" text title with `ModuleGradientHeader("Warehouse Management System", "🚚", slate)`. Same TabRow (Production Plans / Warehouse Transfers) underneath, untouched.

Colors picked to be visually distinct from every other module's existing header color (checked all 7 existing headers first): Sales = blue (`0xFF2563EB→0xFF1E3A8A`), HR = rose (`0xFFDB2777→0xFF9D174D`), Warehouse = slate (`0xFF475569→0xFF1E293B`, the only gray-family header — reads as industrial/logistics, distinct from Production's red-orange).

### Not done this batch
- Module-specific KPI/stat strips inside each header (e.g. Production's active-batch count, Warehouse's pending-transfer count) — Part 1 established this pattern on the Dashboard; extending it per-module is a reasonable next step but wasn't done here to keep this batch strictly additive/low-risk (header only, zero data-layer reads added to these 3 files).
- Other modules beyond the 5 named as examples (Dealer/CRM, Expense, Complaint, Courier, Helpdesk, Admin, Tasks, Reports, Notifications, Approvals) — not touched; the message named 5 specific examples.

### Verification
- Project-wide brace/paren balance: only the same single pre-existing `MockRepository.kt` paren imbalance remains (untouched, not new).
- Confirmed `SubModuleGrid`/`BackToSubMenuLink`/`SubModuleItem` were already imported unqualified in all 3 files (used before this edit) — no new imports needed; `ModuleGradientHeader` called fully-qualified (`com.abm.erp.core.ModuleGradientHeader(...)`), matching the exact pattern already used in `ProductionScreen.kt`/`MarketAnalysisScreen.kt`.
- Gradle build: **not run** (same sandbox limitation, unchanged).

### Module Hub status (5 named examples)
Production ✓ (pre-existing) · Sales ✓ (this batch) · HR ✓ (this batch) · Warehouse ✓ (this batch) · Finance ✓ (pre-existing, via `LedgerScreen.kt` "Accounts & Finance").

## Update — v113-7 (Enterprise Workspace, Part 3+4: Module Header + Mini Dashboard)
Files: core/SubModuleGrid.kt (new ModuleWorkspaceHeader/ModuleStat), data/MockRepository.kt (added isLateTodayFlow/lateTodayCountFlow — read-only aggregate, same pattern as existing presentTodayCountFlow), ui/sales/SalesChainScreen.kt, ui/hrm/PayrollScreen.kt, ui/production/ProductionWarehouseScreen.kt, ui/production/ProductionScreen.kt, ui/ledger/LedgerScreen.kt.
Identity strip: name/ID/designation/company/online-offline/territory, all from MockRepository.currentUser+employeeProfiles+companySettings — no reselection. No photo field exists in the data model (no schema change made) — initials avatar used instead.
Mini-dashboards wired with real existing data per module (Sales: Today's Sales/Collection/Due/Visits/Retailers Covered; HR: Present/Absent/Late/Leave/Overtime; Warehouse: Available/Reserved/Transit/Damaged/Pending Receive; Production: Today's Batch/Running/QC Pending/Finished Goods/Machine Status; Finance: Collection/Expense/Cash/Bank/Outstanding). No fake numbers.
Balance verified (all 6 files individually + project-wide). Build not run (sandbox limitation, unchanged).

## Update — v113-8 (Enterprise Workspace, Part 5+6: Chairman Hub + Right Menu)
New file: ui/chairman/ChairmanHubScreen.kt (route "chairman_hub", registered in nav/NavGraph.kt). Access: Chairman always, or anyone with an active Delegation from a Chairman (existing Delegation system, no new access mechanism, no reselecting identity). All 8 sections (Executive Dashboard, Static Graphs, System Health, Business Risks, Approvals, Company Performance, Target Achievement, Alerts) reuse existing MockRepository functions (computeSalesKpi/computeCollectionKpi/computeRetailerKpi/topRisks/computeSmartBusinessAlerts/computeSystemHealthSnapshot) — no new business logic. Entry point: Chairman-only Quick Action chip on Dashboard.
Right menu: MainActivity.kt top bar gets a new ⋮ dropdown (Profile/Activity Log/Trusted Devices/Sync Status/Backup/Settings/Help/Logout). Reuses existing screens as-is (TrustedDevicesScreen, LoginActivityLogScreen, BackupRecoveryScreen, sync_status_center/company_settings_center/helpdesk routes). Profile is new (no prior screen existed) — read-only identity view, same session data as Module Header, no new fields/schema. Existing direct Logout icon kept — nothing removed.
Balance verified (all changed files individually + project-wide). Build not run (sandbox limitation, unchanged).

## Update — v113-9 (Enterprise Workspace, Part 7+8: Fixed Bottom Bar + Universal QR completion)
Files: data/CodeRegistry.kt (added INVOICE/COLLECTION/PRODUCT/DELIVERY types — now all 10 required types), ui/scanner/UniversalScannerScreen.kt (4 new detail views + onNavigate wiring so scan auto-opens the right workspace), nav/NavGraph.kt (wired onNavigate for scanner route), MainActivity.kt (new fixed bottom action bar: Invoice left/QR center-largest/Collection right, permission-gated via canInvoice/"bill" CREATE — added below the existing module NavigationBar, nothing removed).
Balance verified (all 4 files individually + project-wide). Build not run (sandbox limitation, unchanged).

## Correction — v113-9 traceability finding was WRONG
Rechecked `advanceOrder`'s FULFILLED-stage stock adjustment: the code comment right next to `extractQuantity` explicitly documents this as INTENTIONAL: "Retailer/Wholesale orders never generate an invoice; invoicing starts at Dealer/Depot level." Retail orders are meant to be fulfilled from a dealer's already-invoiced stock (that dealer got their stock via a real Dealer Invoice earlier, which already went through the full Invoice→Approval→Stock→Ledger cycle, verified complete). Forcing a second, fabricated invoice out of free-text order data (`"ABM Masala Tea x60 ctn"`) would invent unreliable productId/pricing data and duplicate a financial event that already happened upstream — that would be a real bug, not a fix. No code change made. Traceability for both chains in item 9 confirmed complete as designed:
- Retailer → Order → (fulfilled against dealer stock that was itself invoiced/approved/ledgered earlier) → Collection: intact.
- Production → QC → Finished Goods → Warehouse Transfer → Company Warehouse → Sales: intact (verified earlier, dispatch/receive correctly feed the same stockLevels Invoice creation checks against).

## Final status — items 1 through 11 all addressed across v113-1 through v113-9. See each versioned section above for exact files/changes. No entities renamed, no business calculations changed, no screens removed, navigation intact, project-wide brace/paren balance clean (one pre-existing, untouched paren imbalance in MockRepository.kt noted since the first batch). Gradle build still not run in this sandbox (no network/wrapper jar) — needs a real build/device pass before shipping.

## Update — v113-10 (Final Workspace Polish, partial)
Done this batch: Quick Actions row added to ModuleWorkspaceHeader (new optional `quickActions` slot, backward-compatible) and wired into all 5 named modules with their exact named actions (HR: Add Request/Attendance/Leave/Overtime; Sales: New Order/Invoice/Collection/Retailer Visit; Warehouse: Receive/Transfer/Count/Damage; Production: New Plan/Start Batch/QC/Transfer; Finance: Expense/Voucher/Reconcile/Close Period) — each jumps to the real existing tab/route, no new screens. Added `onNavigate` param (default {}, backward-compatible) to SalesChainScreen/ProductionWarehouseScreen/ProductionScreen/LedgerScreen/ChairmanHubScreen so cross-module quick actions and Chairman Hub drill-down work; wired in NavGraph.kt. Chairman Hub's 7 cards are now clickable, each drilling into its real module (ledger/system_health_dashboard/boardroom/approvals/dealers/hrm/notifications).

Files: core/SubModuleGrid.kt, ui/hrm/PayrollScreen.kt, ui/sales/SalesChainScreen.kt, ui/production/ProductionWarehouseScreen.kt, ui/production/ProductionScreen.kt, ui/ledger/LedgerScreen.kt, ui/chairman/ChairmanHubScreen.kt, nav/NavGraph.kt.

NOT done this batch (explicitly, due to scope/time — flagged rather than silently skipped): the "Standard Workspace Structure" checklist's Search/Filters, Status Tabs (as a distinct list-filter row, separate from existing SubModuleGrid navigation), and explicit Empty/Loading/Error/Retry states per screen were not audited or added across all 5 modules — that is a large, per-screen UI task each module's existing list/tab composables would need individually, and doing it safely (without touching business logic or breaking any existing list rendering) needs its own dedicated pass. Recommend as the next follow-up if still wanted.

Balance verified (all 8 changed files individually + project-wide, same single pre-existing MockRepository.kt paren note as every prior batch). Build not run (sandbox limitation, unchanged).

## Update — v113-11 (Final Workspace Polish, continued)
Added shared WorkspaceEmptyState/WorkspaceLoadingState/WorkspaceErrorState (core/SubModuleGrid.kt) and applied to one primary list per named module: HR Employee Directory (added search filter too, had none before), Sales Verify Orders, Warehouse Transfers (added status filter chips too, had none before), Production Orders (search/filter already existed, only added empty state), Finance Quick Ledger.
Still not done: every other sub-tab within each module (each module has 5-8 tabs total; this pass covered the busiest one per module). A fully exhaustive pass across all ~35 sub-tabs is a much larger follow-up if wanted.
Balance verified (all 6 files individually + project-wide). Build not run (sandbox limitation, unchanged).

## Update — v113-12 (Final Workspace Polish, continued further)
Added empty states to 15 more lists across the 5 modules:
HR: Attendance list, Payroll list, Leave list, Lifecycle Events list.
Sales: routed/fulfilled orders list, Dealer Invoices list (had filters already).
Warehouse: Production Plans list.
Production: Purchase Lots, Batches, BOM, QC Checks, Production Losses lists.
Finance: Cash/Bank Book, Trial Balance, Balance Sheet (combined 3-section check).
Not yet done: Finance Chart of Accounts/Vouchers/P&L lists, Production Machine Utilization tab, a couple of harder-to-locate list vars (multi-line items() calls the scan script missed) — diminishing remainder, most of the high-traffic lists across all 5 modules now have empty states.
Balance verified (all 5 files individually + project-wide). Build not run (sandbox limitation, unchanged).

## Update — v113-13 (Final Workspace Polish — complete)
Finished the remaining lists: Chart of Accounts, Vouchers (already had search/filter), Machine Utilization (upgraded existing plain-text empty state to shared component). P&L has no list (just 3 totals) — no empty state needed there. Rescanned all 5 module files for any items() call without an empty-state guard: 3 remaining hits were all false positives (already covered by an outer/combined check the scan's narrow window didn't see — verified manually).
Every list across HR, Sales, Warehouse, Production, and Finance now has an empty state; the busiest lists also have search/status filters. Standard Workspace Structure (item 1) and Module-Specific Workspaces (item 2) from the "Final Enterprise Workspace Polish" request are now complete to the extent safely achievable without touching business logic, schema, or navigation.
Balance verified (all files individually + project-wide, same single pre-existing MockRepository.kt note). Build not run (sandbox limitation, unchanged) — needs a real Gradle/device pass before shipping.

## Update — v113-14 (search/filter, second pass)
Added: Leave Management status filter chips (HR), Payroll search-by-name (HR), Production Plans status filter chips (Warehouse). Checked Sales RetailerTab — it's a data-entry form with its own autocomplete, not a searchable list, so left as-is (already correct).
Remaining gap, explicitly not closed: most other sub-tabs (Sales Wholesale/SalesOrder, Production BOM/Batches/QC/Loss/Machine, Finance CoA/CashBank/TrialBalance) still lack a dedicated search/filter row. Universal exhaustive coverage across all ~30 remaining sub-tabs was not attempted this round — flagging rather than claiming done.
Balance verified (all files individually + project-wide). Build not run (sandbox limitation, unchanged).

## Update — v113-15 (search/filter, third pass — largest batch)
Added dedicated search/filter to 7 more sub-tabs: Production Batches (cycle-type filter chips), Production BOM (product-name search), Production QC Checks (PASS/FAIL result filter, separate from the "record new check" selector), Production Loss (reason-text search), Finance Chart of Accounts (name/code search), Finance Cash/Bank Book (narration search), Sales Order (status filter chips).
Mid-batch caught and fixed a real brace imbalance introduced while adding a Column wrapper to BatchesTab (extra `{` with no matching `}` — verified via per-file balance check immediately after the edit, fixed before moving on). Re-verified project-wide balance clean after the fix.
Cumulative dedicated search/filter tabs across this and prior polish batches: Leave Management (status), Payroll (name search), Production Plans/Warehouse (status), Production Orders (search+status+product+date, pre-existing), Dealer Invoices (multi-filter, pre-existing), Sales Order (status) — 10 sub-tabs total now have explicit search/filter beyond the base empty-state coverage every list already has.
Not done: Trial Balance and Machine Utilization search (small/fixed-size lists, low value); universal Loading-state wiring (data is local-Room, effectively instant, so a loading spinner would rarely if ever be visible — judged low value versus risk of adding it everywhere); per-module "Recent Activity" feed distinct from the Dashboard's existing one.
Balance verified (all touched files individually + project-wide, same single pre-existing MockRepository.kt paren note unchanged since the very first batch). Build not run (sandbox limitation, unchanged) — needs a real Gradle/device pass before shipping.

## Update — v113-16 (final polish — loading states + recent activity, all items now complete)
Discovered Trial Balance and Machine Utilization already had search wired from an earlier batch (verified directly in code) — no work needed there, correcting the prior status note.
Loading states: upgraded Chairman Hub's System Health section and Universal Scanner's Employee attendance summary to the shared WorkspaceLoadingState component (the two places with a real async gap — a suspend call behind a nullable state).
Recent Activity: discovered HR and Sales already had ModuleRecentActivity wired (reads MockRepository.auditLogEntries, filtered by entity type, no new data source) — added the same to Warehouse, Production, Finance, and a company-wide version to Chairman Hub (clickable through to Enterprise Audit Center).

All items from "Final Enterprise Workspace Polish" (Standard Workspace Structure + Module-Specific Workspaces, items 1 and 2) are now complete: identity header, KPI mini-dashboard, quick actions, status/search filters (10+ sub-tabs), empty states (every list), loading states (both real async gaps), recent activity (all 5 modules + Chairman Hub), and Chairman Hub drill-down — all wired to real existing data, no new business logic, no schema/Firestore/repository changes, no removed features.
Balance verified (all touched files individually + project-wide, same single pre-existing MockRepository.kt paren note unchanged since batch 1). Build not run (sandbox limitation, unchanged) — this now genuinely needs a real Gradle/device pass before shipping; static verification has been as thorough as this environment allows across a very large number of edits.

## Update — v113-17 (items 3+4: Navigation Consistency + Professional Identity)
### Item 3 — Navigation Consistency
Found one real inconsistency: Warehouse (ProductionWarehouseScreen.kt) used a plain TabRow with no tile-grid landing and no back link, while Sales/HR/Production/Finance all use SubModuleGrid (tile grid) → BackToSubMenuLink → content. Converted Warehouse to match exactly (same "tab: Int?" null-means-grid pattern, same back-link component). All 5 modules now share identical top-level navigation shape.
Other consistency items were already true from prior batches: search/filter placement (box or filter-chip row immediately above the list, in every tab that has one), status badge coloring (SuccessGreen/WarningAmber/DangerRed used the same way everywhere), quick-action pattern (AssistChip row in the header), right-side system menu (MainActivity.kt, untouched this batch), fixed bottom Invoice/QR/Collection bar (untouched this batch).

### Item 4 — Professional Identity
ModuleWorkspaceHeader's identity strip already had name/employee ID/designation/company/territory/online-offline from an earlier batch. Added the one missing piece: explicit **sync state** (separate from online/offline) — shows "✅ Synced" or "⚠ N pending" from the real failedSyncIds tracker, stacked next to the online/offline badge. Photo: no photo field exists in the data model (no schema change made, per the strict rules) — initials avatar remains the safe placeholder, which satisfies "real employee photo or safe placeholder". Identity is still read entirely from the authenticated session; no reselection anywhere.

Files changed: core/SubModuleGrid.kt (sync-state addition), ui/production/ProductionWarehouseScreen.kt (navigation pattern conversion).
Balance verified (both files individually + project-wide, same single pre-existing MockRepository.kt paren note unchanged since batch 1). Build not run (sandbox limitation, unchanged).

## Update — v113-18 (items 5+6: Connected Workflow Shortcuts + UX Quality — FINAL polish batch)
Date: 2026-08-01

### Item 5 — Connected Workflow Shortcuts
Added navigation-only "Connected workflow" button rows to the 6 QR scan-detail views that represent each named chain's anchor record. No new data reads, no new business logic — every button calls the existing `onNavigate(route)` already wired for the scanner, jumping to the real module screen:
- Retailer detail → Order/Invoice (sales), Collection (dealers), Ledger (ledger)
- Dealer detail → Invoice (sales), Collection (dealers), Ledger (ledger)
- Production Batch detail → QC (production), Transfer (production_warehouse), Warehouse (inventory)
- Employee detail → Attendance (hrm), Payroll (hrm), Activity (enterprise_audit_center)
- Invoice detail → Invoice (sales), Stock (inventory), Ledger (ledger), Delivery (billing)
These are module-level shortcuts (jump to the right workspace), not record-level deep links to a specific detail screen for that exact invoice/order — the app has no per-record detail-screen routing today, and building one would be new navigation architecture, not a "safe deep-link" polish. Flagging this scope choice explicitly rather than silently under-delivering.

### Item 6 — UX Quality
- Removed one real duplicate: MainActivity's top bar had both a standalone Logout icon AND a Logout item in the new right-side menu. Removed the standalone icon — Logout is still fully available (via the menu), just no longer duplicated. This is the only clear duplicate-button instance found on inspection.
- Essential actions preserved: fixed bottom Invoice/QR/Collection bar and the right-side menu are both untouched this batch.
- Spacing/hierarchy/theme: unchanged — no new theme, no new color system; every addition across all polish batches reused existing theme colors (SuccessGreen/WarningAmber/DangerRed/GoldBright/etc.) and existing spacing conventions (8dp/10dp/16dp steps already used throughout the app).
- Status/validation messages: none hidden or removed — every error/empty/warning message added this session (empty states, error+retry, DENY messages) is visible by default, not tucked behind a toggle.
- "All 21 modules visually consistent": **not fully achieved** — the ModuleWorkspaceHeader/mini-dashboard/quick-actions/recent-activity shell was built and applied to the 5 named business modules (Sales, HR, Warehouse, Production, Finance) plus Chairman Hub. 7 more screens already had the older ModuleGradientHeader (Purchase, Inventory, Billing, Comms, Market) from before this session. The remaining ~9 modules (Dealer/CRM, Expense, Complaint, Courier, Helpdesk, Admin/System-Health, Tasks, Reports, Approvals, Notifications, etc.) were not touched — bringing all 21 to the same shell is a real, larger follow-up, not something achievable inside this batch without the "giant rewrite" the instructions explicitly said to avoid.

### Files changed this batch
`ui/scanner/UniversalScannerScreen.kt` (6 detail composables gained onNavigate + chain buttons), `MainActivity.kt` (removed duplicate Logout icon).

### Modules polished this batch
Retailer/Dealer/Production-Batch/Employee/Invoice scan-detail views (workflow shortcuts); global top bar (decluttered).

### Shared components created this batch
None new — reused `onNavigate`, `WorkspaceLoadingState`, existing theme colors. (Shared components created in earlier batches this session: `ModuleWorkspaceHeader`, `ModuleStat`, `ModuleRecentActivity`, `WorkspaceEmptyState`/`WorkspaceLoadingState`/`WorkspaceErrorState` — all in `core/SubModuleGrid.kt`.)

### Navigation changes this batch
No new routes. No route signatures changed. Only added chain-shortcut buttons using the scanner's existing `onNavigate` callback, and removed one redundant top-bar button (its target dialog/state untouched).

### Remaining runtime tests needed
Gradle build (still not run — sandbox has no network / no `gradle-wrapper.jar`, unchanged since the very first batch); on a real device: scan each of the 6 entity types and confirm the new chain buttons land on the right screen; confirm Logout still works from the right-side menu only; visual QA of the 5 polished modules + Chairman Hub across at least one non-Chairman role (permission-gated elements — Invoice/Collection quick actions, Chairman Hub access gate, canInvoice-gated chips) to confirm they hide/show correctly.

Balance verified (all touched files individually + project-wide, same single pre-existing MockRepository.kt paren note unchanged since batch 1 of this whole session).

## Update — v113-19 (module visual consistency — closing the "21 modules" gap)
Date: 2026-08-01

Added `ModuleGradientHeader` (title + icon + brand gradient banner) to 10 more modules that previously had a plain `Text(...)` title: CRM (🗺️), Dealers & Stock (🏢), Expenses (💸), Complaint Box (📮), Courier & Logistics (🚛), Task Manager (✅), Approvals (✅), Notifications (🔔), Helpdesk (🎧), Reports (📊). Every color chosen to match/reuse each module's own existing SubModuleItem color where one already existed, so this doesn't introduce a new palette.

Each edit was applied and balance-checked individually, one file at a time, specifically to avoid repeating the brace-mismatch mistake from the previous batch. Two edits (GeoCrmScreen, TaskManagerScreen) did initially introduce an imbalance when a `Row` layer was removed as part of the swap — both were caught immediately by the per-file check and fixed before moving to the next file, and are recorded here so the history is honest about it. All 10 files, plus the whole project, are now confirmed balanced.

Minor, disclosed trade-offs from these safe (no-new-wrapper) edits:
- Complaint Box's Chairman-only "— Inbox" title distinction was dropped (now always shows "Complaint Box"); the underlying inbox-vs-personal-view logic itself is unchanged.
- Notifications' unread count moved from being inline with the title text to a small line directly under the header — still visible, not removed.
- A few modules' action-bar (export/share) row lost its "SpaceBetween" layout (now right-aligned only) since the title that used to anchor the left side moved into the header — cosmetic only, no functionality lost.

### Cumulative module header status (all business-facing screens)
Full ModuleWorkspaceHeader (identity + KPI + quick actions + recent activity): Sales, HR, Warehouse, Production, Finance/Ledger — 5 modules, plus Chairman Hub (custom layout, same identity/gating principles).
ModuleGradientHeader only (branded banner, no mini-dashboard): Purchase, Inventory, Billing, Comms, Market (from earlier sessions) + CRM, Dealers, Expenses, Complaint Box, Courier, Tasks, Approvals, Notifications, Helpdesk, Reports (this batch) — 15 modules.
Still plain/untouched: the remaining Chairman-only admin tools (Permission Center, Hiring Center, Vacancy/Target Center, Period Lock Center, Company Settings Center, System Health Dashboard, Business Rule Engine, Enterprise Audit Center, Sync Status Center, Boardroom — Boardroom already has its own rich distinct layout and wasn't touched), Universal Scanner, Search. These are lower-traffic administrative/tool screens rather than day-to-day business workspaces, which is why they were deprioritized given the "avoid one giant screen rewrite" instruction.

Files changed this batch: `ui/crm/GeoCrmScreen.kt`, `ui/dealer/DealersScreen.kt`, `ui/expense/ExpenseScreen.kt`, `ui/complaint/ComplaintBoxScreen.kt`, `ui/courier/CourierScreen.kt`, `ui/tasks/TaskManagerScreen.kt`, `ui/approvals/ApprovalsScreen.kt`, `ui/notifications/NotificationsScreen.kt`, `ui/helpdesk/HelpdeskScreen.kt`, `ui/reports/ReportsScreen.kt`.

No schema, Firestore, repository, or calculation changes. No routes changed. No features removed (only the two disclosed cosmetic trade-offs above). Gradle build still not run — same sandbox limitation as every batch this entire session (no network, no `gradle-wrapper.jar`). This is now a very large cumulative set of UI-only changes and genuinely needs a real build + device QA pass before shipping.

## Update — v113-20 (Compile Stabilization Phase)
Date: 2026-08-01

### Root cause of every compile error

1. **`core/SubModuleGrid.kt`** — 7× "Unresolved reference 'TextSecondary'". Root cause: only `import com.abm.erp.theme.TextPrimary` existed; `TextSecondary` was used throughout the file's later additions (ModuleWorkspaceHeader, WorkspaceEmptyState, etc.) but its import was never added. Fixed by adding `import com.abm.erp.theme.TextSecondary`.

2. **`ui/hrm/PayrollScreen.kt`** — cascade of "Unresolved reference 'forEach'", "component1()/component2() ambiguous", "Unresolved reference 'name'/'geoLabel'", "Function invocation 'size(...)' expected". Root cause: `MockRepository.roleHierarchy()` returns `List<Pair<UserRole, List<Employee>>>`, not a `Map`. `EmployeeDirectoryTab`'s search-filter code called `.mapValues{}` / `.filterValues{}` / `.values` on it — none of those exist on `List`, so the compiler couldn't infer the destructured pair's types at all, and every downstream `.name`/`.geoLabel`/`.size` access failed too. Fixed by rewriting with `List`-appropriate `.map{}` / `.filter{}`. Separately, "Unresolved reference 'LeaveStatus'" — this file only imports selected `com.abm.erp.data.*` symbols (no wildcard), and `LeaveStatus` was used unqualified in the HR mini-dashboard's leave-count calculation. Fully qualified it (`com.abm.erp.data.LeaveStatus`), matching the pattern already used elsewhere in the same file.

3. **`data/CodeRegistry.kt`** — "Unresolved reference 'companyId'" on the dealer-match filter. Root cause: the `Dealer` model (confirmed in `Models.kt`) has no `companyId` field at all — this exact line existed unchanged in the original v113 baseline, predating any UI session. Every other `companyId` check in this file (`EmployeeProfile`, `ProductionPlan`, `WarehouseTransfer`) is valid; only `Dealer` lacks the field. Fixed by removing the impossible condition from the dealer filter only.

4. **`ui/dealer/DealersScreen.kt`** — "'when' expression must be exhaustive. Add 'INVOICE', 'COLLECTION', 'PRODUCT', 'DELIVERY' branches". Root cause: this QR-scan `when(resolved.type)` block was written before those 4 `CodeType` values were added to `CodeRegistry` in an earlier session, and was never revisited. Added the 4 missing branches using the same informative-toast pattern already used for `PRODUCTION_BATCH`/`WAREHOUSE_TRANSFER` (points the user to Universal Scanner for full detail) — no new logic, just completing the exhaustive match.

5. **`data/MockRepository.kt`** — "Argument type mismatch: actual type is 'kotlin.Int', but 'kotlin.Double' was expected" on `SalesReturn` approval's stock adjustment. Root cause: `SalesInvoiceLineItem.qty` is `Int`; `InventoryRepository.adjustStock(...)` expects `Double` for quantity. This line was unchanged from the original v113 baseline. Fixed with `.toDouble()` — same numeric value, no behavior change.

6. **`ui/sales/SalesChainScreen.kt`** — "Unresolved reference 'PartyType'" in the Sales mini-dashboard's "Retailers Covered" calculation — used unqualified with no import in this file (only selected `com.abm.erp.data.*` symbols imported, no wildcard). Fully qualified it. Separately, "Unresolved reference 'context'" inside `DealerInvoiceTab`'s invoice-creation failure Toast — this function never declared a `context` val at all (pre-existing, confirmed against the original v113 baseline; two OTHER nested scopes further down in the same file do declare their own local `context`, but line 603 is outside both). Added `val context = androidx.compose.ui.platform.LocalContext.current` at the top of `DealerInvoiceTab`.

### Important note on the SubModuleGrid.kt line-587-608 errors from the screenshots
Those specific errors (lines 587–608, referencing `it`, array `component1()/component2()`, `values`) **do not exist** in the actual `SubModuleGrid.kt` shipped in v113-19 — that file is only 263 lines total, confirmed by extracting and inspecting the exact ZIP I delivered. This strongly indicates the reported Android Studio project folder had stale/leftover files from a previous extraction (likely the pre-`v113-19` `EmployeeDirectoryTab`-style bug pattern, which is a near-identical symptom to fix #2 above, just in the wrong file). Recommended: delete the local project folder entirely and re-extract v113-20 fresh, or Invalidate Caches / Restart in Android Studio, before re-checking.

### Files modified this batch
`core/SubModuleGrid.kt`, `ui/hrm/PayrollScreen.kt`, `data/CodeRegistry.kt`, `ui/dealer/DealersScreen.kt`, `data/MockRepository.kt`, `ui/sales/SalesChainScreen.kt`.

### Why each fix was required
All six were genuine compiler-blocking errors: 4 were missing/unqualified imports (TextSecondary, LeaveStatus, PartyType, context — the last being a genuinely undeclared variable, not just an import issue), 1 was a wrong-collection-type API misuse (Map functions called on a List), and 1 was an Int/Double numeric mismatch. None were stylistic or optional.

### Confirmation: no business logic changed
- No Room schema changes, no Firestore structure changes, no model renames.
- `adjustStock(..., item.qty.toDouble(), ...)` — same numeric value, just widened from Int to Double as the function signature always required.
- `CodeRegistry` dealer filter — removed a condition that could never have matched anything (Dealer has no companyId), so behavior is unchanged (this filter was already effectively a no-op-that-crashed-the-compiler, not a real business rule).
- `DealersScreen.kt` when-block additions — purely informational Toast messages for 4 scan types this screen didn't previously handle at all; no state mutation, no navigation change, no data write.
- `PayrollScreen.kt` EmployeeDirectoryTab rewrite — identical filtering semantics (search by name/geoLabel, hide empty groups), only the collection API used to express it changed from (invalid) Map operations to (valid) List operations.
- `SalesChainScreen.kt` context fix — a Toast that was already coded to fire on invoice-creation failure now has a valid context to fire with; the failure-detection logic itself (`if (!created)`) is untouched.

### Remaining compile errors
None found from static verification (full project-wide brace/paren balance sweep — braces perfectly balanced across all 99 Kotlin files; the one paren-count note in `MockRepository.kt` is a pre-existing artifact inside a string/comment, present since before this session's very first batch, unchanged by this fix). **Real Gradle build still not possible in this sandbox** (no network, no `gradle-wrapper.jar`) — this remains static verification only. Please compile in Android Studio after a clean re-extract (see note above) and report back any further errors.

## Update — v113-21 (login input bug — found while testing after successful compile)
Real bug found live-testing: the mobile-number field used `KeyboardType.Phone` (numeric-only keypad, matches the screenshot) and its `onValueChange` stripped all non-digit characters. But `resolveByMobile`'s own dev fallback (pre-existing code, comment says "dev: try a demo employee id") requires typing an employee ID like `CHAIR-1` — letters + hyphen — which could never reach that code path through the actual UI. Fixed: keyboard switched to `KeyboardType.Text`, filter widened to letters/digits/hyphen. Real phone-number login is unaffected (digits still work fine on a text keyboard); this only unblocks the already-existing dev/demo login path. File: `ui/login/LoginScreen.kt`. Balance verified (file + project-wide).

## Update — v113-22 (Daraz-orange redesign, Batch 1: theme foundation)
Date: 2026-08-01
Scope: this is explicitly Batch 1 of a large, multi-batch visual redesign (per the request: "implement in small compile-safe batches, never sacrifice functionality"). Only the color foundation + one centerpiece component this batch.

### What changed
1. **`theme/Color.kt`** — added new Daraz-orange brand palette as purely additive tokens: `DarazOrange` (#F85606), `DarazOrangeDark`, `DarazOrangeSoft`, `ChairmanNavy`, `ChairmanGold`, `StatusGreen/Blue/Red/Yellow`. Nothing existing renamed or removed — every current screen referencing `Sky`/`Gold`/`TextPrimary`/etc. is untouched and still compiles.
2. **`theme/Theme.kt`** — `MaterialTheme.colorScheme.primary` changed from `Sky` (blue) to `DarazOrange`. This is the single highest-leverage change: every `Button`/`FloatingActionButton`/`TextButton` that doesn't set its own explicit color already reads this token, so this alone re-themes most default-styled interactive elements app-wide toward the vivid orange direction without touching individual screens. `secondary`/`background`/`surface`/`error` untouched.
3. **`MainActivity.kt`** — the fixed bottom bar's central QR scanner button recolored from gold to `DarazOrange` (white icon instead of dark), matching the reference design's large vivid-orange circular scan button exactly. The top-bar "ABM" logo badge keeps its gold gradient (brand logo mark, intentionally left alone).

### What was explicitly NOT done this batch (deferred to later batches, by design)
- No screen layouts changed, no cards restructured, no new "soft 3D shadow" styling applied yet.
- Dashboard was not simplified/decluttered yet (the "remove duplicate module shortcuts, keep only Search/Profile/Notification/cards" request).
- Chairman Module consolidation (moving the ~15 listed admin tools into one dedicated hub) was not done — note this is largely already the shape of the existing `ChairmanHubScreen.kt` built in an earlier session; extending it to include every tool the reference lists is a distinct follow-up batch.
- Universal Bottom Bar's extra quick-access items (Cash Book/POS/Barcode/Generator) not added — current bar still exactly Invoice/QR/Collection as built earlier.
- Invoice redesign not started.
- No business logic, repository, Room/Firebase, QR-resolution, Geo, role, or approval code touched at all this batch — purely color tokens + one button's paint.

Balance verified (all 3 files individually + full project-wide sweep, zero issues). Build not run (sandbox limitation, unchanged since every batch this session).

### Recommended next batch
Dashboard simplification (remove the Quick Actions module-shortcut row already there from earlier sessions, keep Search/Profile/Notification/KPI cards) — this is the next concrete, scoped, compile-safe step toward the reference, and was explicitly called out as a goal.

## Update — v113-23 (Batch 2: Dashboard simplification + Chairman tools consolidation)
Removed from Dashboard (`ui/dashboard/MainDashboardScreen.kt`): the full categorized module-shortcut grid (duplicated bottom-nav's job) and the 5 Chairman-only tool buttons (Vacant Positions/Account & Access Control/Trusted Devices/Login Activity Log/Backup & Recovery) + their dialogs. Dashboard now keeps: header/status strip, KPI sections, alerts/activity, target — matching "Search, profile, notification, dashboard cards only" (search/profile/notification already live in MainActivity's top bar, untouched).
Added to `ui/chairman/ChairmanHubScreen.kt`: same 5 tools, same exact screens reused (VacantPositionsScreen/AccountsScreen/TrustedDevicesScreen/LoginActivityLogScreen/BackupRecoveryScreen — zero new screens built), under a new "Admin & Access Tools" card.
POS / Barcode Generator / QR Code Generator quick-access buttons from the reference were NOT added — no such screens exist in this app yet, and building them would be a new feature (out of scope for a UI redesign). Cash Book quick-access not added to bottom bar yet either — deferred.
Files: MainDashboardScreen.kt, ChairmanHubScreen.kt. Balance verified (both files + full project sweep, zero issues).

## Update — v113-24 (Batch 3: premium Invoice PDF redesign)
Redesigned `exportSalesInvoicePdf` in `core/StructuredExports.kt`: orange branded header band (ABM ERP), embedded QR verification code (QrCodeGenerator, real invoice id), boxed dealer-details section, payment-terms/courier line, shaded-header bordered line-item table with alternating row tint, highlighted orange total box, colored approval-status badge (green/red/amber/blue by real status), and a 3-column signature line area (Prepared By uses real createdBy; Checked/Authorized are blank signature lines, not fabricated names). Same PdfDocument/Canvas mechanism, same file save/share path — only the drawing calls changed. All data drawn is real SalesInvoice fields; nothing invented.
Balance verified (file + full project sweep). Build not run (sandbox limitation, unchanged).

## Update — v113-25 (Batch 4: soft 3D shadows app-wide + bottom-bar orange accents + Cash Book quick access)
Added a subtle shadow (6dp, soft tint) to `core/DualControlComponents.kt`'s `GlassCard` — this single shared component is used across every module screen in the app, so this one change gives the "premium soft 3D card" look requested, everywhere, at once. Bottom action bar (`MainActivity.kt`): Invoice/Collection icon+text recolored from leftover cyan to the new Daraz orange; added a slim Cash Book quick-access row above the main Invoice/QR/Collection row (real existing route — ledger's Cash & Bank Book tab).
Files: core/DualControlComponents.kt, MainActivity.kt. Balance verified (both files + full project sweep).

## Update — v113-26 (Batch 5: Chairman Navy+Gold theme)
Chairman Hub header recolored from purple to the requested Navy (#0F1E3D) + Gold identity. File: ui/chairman/ChairmanHubScreen.kt. Balance verified.

## Redesign status summary (all batches this session, v113-22 through v113-26)
Done: Daraz-orange primary theme app-wide, QR scanner button orange, Dashboard simplified (module grid + Chairman tools removed), Chairman Hub consolidated (5 admin tools moved in, reusing existing screens), premium Invoice PDF (branding/QR/boxed sections/status badge/signatures), soft 3D shadow on every card app-wide (GlassCard), bottom bar orange accents + Cash Book quick access, Chairman Navy+Gold header.
Not done (would need new screens/features, out of scope for a UI-only redesign per the strict rules given): POS screen, Barcode Generator, QR Code Generator, Excel/PDF Report Generator utilities — none of these exist as real screens in this app yet.
Not done (lower value / higher risk, deferred): mass-renaming status colors to the new Status* tokens (functionally near-identical to existing SuccessGreen/DangerRed/WarningAmber already used everywhere — no visual gain worth the risk of touching hundreds of call sites); Login screen restyle (has its own established Sky/Gold identity from an earlier session, left alone to avoid risk on the one screen every user must pass through).
No business logic, repository, Room/Firebase, QR-resolution, Geo, role, or approval code touched in any redesign batch this session. Build not run (sandbox limitation, unchanged throughout).

## Update — v113-27 (Batch 6: Full-Screen Workspace conversions)
Converted Collection creation (DealersScreen.kt) and Expense creation (ExpenseScreen.kt) from small centered popup Dialogs into genuine full-screen workspaces (branded header, close button, scrollable full-height body) — matching "no tiny embedded forms for major operations." Same form fields, same business logic/submit calls, only the container changed (Dialog with usePlatformDefaultWidth=false + full-size Surface instead of a small wrapped Surface).
Noted: UniversalActionMenu.kt already covers the "Universal Menu" request (Edit/Duplicate/Archive/Restore/Submit/Approve/Reject/Export/History/Share, permission-gated) — pre-existing from earlier sessions, confirmed still comprehensive, no changes needed.
Files: ui/dealer/DealersScreen.kt, ui/expense/ExpenseScreen.kt. Balance verified (both files + full project sweep).

### Remaining for full completion of this request (large, deferred)
Invoice/Order creation flows are embedded inline within their tabs (not dialogs), so converting them to "full-screen workspace" would mean restructuring navigation (new routes/nav-graph entries), a bigger and riskier change than the dialog→full-screen conversions done here — flagging as the next distinct batch rather than attempting blind. Attendance/Payroll/Production/Warehouse/QC/Transfer full-screen conversions not started. Universal QR's asset/vehicle/machine types not added (no such entities exist in the data model yet — would be new features). Animation/motion polish not attempted (Compose default transitions only).

## Update — v113-28 (Batch 7: Apply Leave full-screen)
Converted Apply Leave dialog (PayrollScreen.kt) to full-screen workspace, same pattern as Collection/Expense. Same fields/logic, only container changed. Balance verified (file + full project sweep).
Reviewed DealerInvoiceTab for the same treatment — it's a large (~450 line) function mixing an invoice list view with an always-inline cart-builder, not a separate dialog. Converting it safely needs real restructuring (separating list from builder, likely a new route), which is a materially bigger and riskier change than the dialog conversions done so far — deferred as its own dedicated batch rather than attempted blind on a revenue-critical screen.

## Update — v113-29 (Batch 8: three more full-screen workspace conversions)
Converted to full-screen workspaces: Record Employee Event (PayrollScreen.kt), New Bill of Materials (ProductionScreen.kt), New Production Order (ProductionScreen.kt). Same safe pattern as prior batches — swapped the small Dialog+Surface container for a full-size one and replaced the plain title with a title+Close row; inner form content and all business logic untouched. Added the one missing `verticalScroll` import in ProductionScreen.kt.
Cumulative full-screen conversions so far: Collection, Expense, Apply Leave, Record Employee Event, New BOM, New Production Order (6 total).
Files: ui/hrm/PayrollScreen.kt, ui/production/ProductionScreen.kt. Balance verified (both files + full project sweep, zero issues).

## Update — v113-30 (Batch 9: three more full-screen workspace conversions)
Converted to full-screen workspaces: New Production Plan and New Warehouse Transfer (ProductionWarehouseScreen.kt), New Stock Count (InventoryScreen.kt). Same safe container-swap pattern. Added missing `FontWeight` import in ProductionWarehouseScreen.kt (caught by post-edit import check).
Cumulative full-screen conversions: Collection, Expense, Apply Leave, Record Employee Event, New BOM, New Production Order, New Production Plan, New Warehouse Transfer, New Stock Count (9 total).
Files: ui/production/ProductionWarehouseScreen.kt, ui/inventory/InventoryScreen.kt. Balance verified (both files + full project sweep, zero issues).
Remaining dialogs not yet converted (smaller/settings-type, correctly staying as dialogs per the request's "use dialogs only for confirmation or small settings"): variance report viewer, inventory settings, plan detail viewer, transfer receive form, purchase supplier/PO forms. The Invoice creation flow (DealerInvoiceTab) remains the one major inline form still deferred — needs navigation restructuring, flagged since batch 7.

## Update — v113-31 (Batch 10: Invoice creation full-screen workspace — the last major inline form)
Converted DealerInvoiceTab's cart-builder (SalesChainScreen.kt) from an always-visible inline card at the top of the invoice list into a proper full-screen workspace:
- The list now opens with a "+ Create Dealer Invoice" launcher button (label switches to "Continue editing invoice" when an edit is in progress).
- The entire builder — dealer picker, credit-limit warning, product search, cart lines with +/− qty controls, courier selection, discount/commission fields, signature toggle, and the create/update submit button — moved verbatim into a full-screen Dialog. No field, validation, guard (including the double-tap `isSubmitting` protection), or repository call was changed.
- Edit and Reorder actions on existing invoice cards now set `showBuilder = true` so those workflows still open the builder as before.
- Successful submit now closes the workspace (alongside the existing state reset), which is the correct behavior for a full-screen form.
This clears the item flagged as deferred since batch 7. Cumulative full-screen conversions: 10.
File: ui/sales/SalesChainScreen.kt. Balance verified (581/581 braces, 1084/1084 parens + full project sweep, zero issues). Build not run (sandbox limitation, unchanged).

## Update — v113-31 (Batch 10: full workspace header rollout to remaining modules — part 1)
Correction to an earlier note: Invoice creation (DealerInvoiceTab) was ALREADY converted to a full-screen workspace in a prior batch (verified in code: usePlatformDefaultWidth=false + full-size Surface + title/Close row). Full-screen conversions total 10, not 9 — nothing outstanding there.
Upgraded from plain ModuleGradientHeader to full ModuleWorkspaceHeader (identity strip + KPI mini-dashboard + quick actions + recent activity):
- **Expenses** (ui/expense/ExpenseScreen.kt) — KPIs: today's expense, pending count, approved total, rejected count (all computed from the already-loaded expenses list).
- **Purchase** (ui/purchase/PurchaseScreen.kt) — KPIs: supplier count, pending requests, open POs, received POs (from existing PurchaseRepository flows). Quick actions jump to existing tabs.
All KPI values come from data the screen already loads — no new repository calls, no new data sources, no business logic touched.
Balance verified (both files individually + full project sweep, zero issues).
Remaining modules still on plain gradient header only: CRM, Dealers, Inventory, Billing, Courier, Tasks, Approvals, Notifications, Helpdesk, Reports, Comms, Market, Complaint (~13). Continuing in subsequent batches.
Still not done anywhere: "Related records" and "Timeline" sections (would need a new shared component — no equivalent exists yet).

## Update — v113-32 (Batch 11: workspace header rollout — part 2)
Upgraded to full ModuleWorkspaceHeader (identity + KPI + quick actions + recent activity):
- **Dealers & Stock** (ui/dealer/DealersScreen.kt) — KPIs: dealer count (territory-scoped, uses the existing scoped `dealers` list so geo/role visibility rules are preserved), retailer count, total due, collected today, over-credit-limit count.
- **Inventory & Stock Management** (ui/inventory/InventoryScreen.kt) — KPIs: product count, total on hand, reserved, low-stock count; quick actions jump to existing Adjust/Transfer/Count/Damage tabs.
All values from already-exposed repository flows; no new data sources, no business logic touched. Verified `creditLimit` exists on the Dealer model before using it.
Balance verified (both files + full project sweep, zero issues).
Modules now on full workspace header (9): Sales, HR, Warehouse, Production, Finance, Chairman Hub, Expenses, Purchase, Dealers, Inventory.
Still on plain gradient header (~11): CRM, Billing, Courier, Tasks, Approvals, Notifications, Helpdesk, Reports, Comms, Market, Complaint.

## Update — v113-33 (Batch 12: workspace header rollout — part 3)
Upgraded to full ModuleWorkspaceHeader: **Approvals** (KPIs: pending/approved/rejected/total from the already-loaded approvals list) and **Task Manager** (KPIs: pending/in-progress/completed/total using the real TaskStatus enum; Trash toggle moved into quick actions). Added missing SuccessGreen/WarningAmber imports in TaskManagerScreen.kt (caught by post-edit import check). Verified TaskItem.status/TaskStatus and ApprovalStatus enum values in Models.kt before use.
Balance verified (both files + full project sweep, zero issues).
Modules on full workspace header (12): Sales, HR, Warehouse, Production, Finance, Chairman Hub, Expenses, Purchase, Dealers, Inventory, Approvals, Tasks.
Remaining on plain gradient header (~9): CRM, Billing, Courier, Notifications, Helpdesk, Reports, Comms, Market, Complaint.

## Update — v113-34 (Batch 13: workspace header rollout — part 4)
Upgraded to full ModuleWorkspaceHeader: **Geo CRM** (KPIs: retailers, dealers, visits today, retailers covered today, campaigns; quick actions to Route Audit/Leads/Live Tracking) and **Courier & Logistics** (KPIs: couriers, in-transit, out-for-delivery, delivered — using the real ShipmentStatus enum; quick actions to Book/Track/Vehicles).
Caught and fixed during this batch: CourierScreen needed one extra closing brace for the new content Column (verified by tracing brace depth back to 0 at the function's end, not just a whole-file count), and a missing WarningAmber import.
Balance verified (both files + full project sweep, zero issues).
Modules on full workspace header (14): Sales, HR, Warehouse, Production, Finance, Chairman Hub, Expenses, Purchase, Dealers, Inventory, Approvals, Tasks, CRM, Courier.
Remaining on plain gradient header (~7): Billing, Notifications, Helpdesk, Reports, Comms, Market, Complaint.

## Update — v113-35 (Batch 14: workspace header rollout COMPLETE — final 7 modules)
Upgraded the remaining 7 modules to full ModuleWorkspaceHeader in one batch:
- **Credit Risk & Billing** — KPIs: outstanding, over-limit dealers, unpaid invoices, challans; quick actions Risk/Payments/Challan.
- **Notifications** — KPIs: unread, total, visible, muted; Preferences quick action.
- **Market Analysis** — KPIs: zones, dealers, total due.
- **Reports** — KPIs: payroll total, pending gatepass (both already computed on-screen).
- **Communication Hub** — identity + Chat/Announcements quick actions + recent activity (no numeric KPIs — this module has no countable business metrics, so none were invented).
- **Complaint Box** — KPIs: open, resolved, total.
- **Helpdesk** — KPIs: open, resolved, total tickets (fit inside the existing LazyColumn item slot, no structural change).
Per-file brace-depth tracing used again (not just whole-file counts) — caught and fixed missing closing Columns in Notifications, Reports, and Complaint Box, plus missing TextPrimary/WarningAmber imports in Complaint Box.

### ALL 21 modules now have the full workspace header
Sales, HR, Warehouse, Production, Finance, Chairman Hub, Expenses, Purchase, Dealers, Inventory, Approvals, Tasks, CRM, Courier, Billing, Notifications, Market, Reports, Comms, Complaint, Helpdesk.
Every KPI value is computed from data the screen already loads — no new repository calls, no new data sources, no invented numbers, no business logic touched anywhere in this rollout.

### Still genuinely outstanding (unchanged from before)
"Related records" and "Timeline" sections — no shared component exists for these yet; would need to be designed and built. Asset/Vehicle/Machine QR types — no data models exist. Animation/motion polish — Compose defaults only. Login screen restyle. Remaining Sky-blue accents in ~6 files (mostly intentional chart/data-viz colors).
Balance verified (every touched file individually + full project sweep, zero issues). Build not run (sandbox limitation, unchanged all session).

## Update — v113-36 (Batch 15: QR generation completed — the missing half of the Universal QR engine)
Correction to an earlier statement in this session: QR *generation* was NOT limited to the Invoice PDF. Auditing every `QrCodeGenerator.generate` call site found it already present in 6 places (Dealer QR, Retailer shop QR, Employee QR, Carton Code128 barcode, Sales/Order QR, Invoice PDF QR). The real gap was 5 entity types that the scanner could RESOLVE but that had no way to SHOW their own QR.

New shared component `core/RecordQrCard.kt` — `RecordQrButton` / `RecordQrDialog`: renders any record's own scannable QR, plus print/share (saves a PNG then opens the standard share sheet via the FileProvider already configured in AndroidManifest.xml and already used by the CSV/PDF exports). Encodes exactly the code string `CodeRegistry.resolve()` matches on, so every generated tag is guaranteed to scan back to its own record; never encodes sensitive data, only the public identifier.

Wired into the 5 previously-missing entity types:
- **Collection** (DealersScreen.kt) — encodes `collectionNo`
- **Warehouse Transfer** (ProductionWarehouseScreen.kt) — encodes `transferNumber`
- **Production Batch** (ProductionWarehouseScreen.kt) — encodes `batchNumber`
- **Product** (InventoryScreen.kt) — encodes `sku`
- **Delivery Challan** (CreditAndBillingScreen.kt) — encodes `challanNo`

The Universal QR engine is now round-trip complete: all 10 scannable types can both generate and resolve. No business logic, repository, schema, or scanner-resolution logic changed — generation is display-only and reuses the existing QrCodeGenerator.
Balance verified (every touched file + full project sweep, zero issues). Build not run (sandbox limitation, unchanged).

### Optional future cleanup (not done, low value)
The 6 pre-existing QR call sites each have their own inline bitmap/Image code; they could be consolidated onto the new RecordQrButton component for consistency, but they work correctly as-is and touching them would risk regressions for purely cosmetic gain.

## Update — v113-37 (Blueprint approved; Batch 1 of transformation: design-system foundation)
`ABM-ERP-UI-UX-Blueprint.md` added to the project root — the 40-section approved design plan, now the reference every subsequent batch is checked against.

**Near-miss caught this batch:** started writing a new `core/DesignSystem.kt` with `IconChip`/`StatusPill`/`statusColorFor`, then discovered `core/DesignPrimitives.kt` already existed with the same declarations in the same package — shipping both would have been a duplicate-declaration compile error. Deleted the new file and kept the incumbent instead (it is already blueprint-shaped and has zero call sites, so nothing regressed).

Changes:
- `theme/Color.kt` — status tokens renamed to the blueprint's §3.3 semantic names: `StatusYellow` → `StatusAmber`; added `StatusSlate` and `HairlineBorder`. Safe rename: the only references were inside `DesignPrimitives.kt`, repointed in the same batch, verified zero dangling references project-wide.
- `core/DesignPrimitives.kt` — repointed to `StatusAmber`.

Existing primitives confirmed present and blueprint-conformant: `IconChip` (32/40/48dp, gradient tint, vector icon), `StatusPill`, `statusColor()` (single source of truth for status colour), `attentionColor()`, `problemColor()`.

**Not yet done (next batches, in blueprint Part VI order):** rolling `IconChip` out to replace emoji app-wide (the largest visual gain and by far the biggest batch — ~21 module headers plus every `SubModuleItem` grid), `StatusPill` adoption on record rows, card/shadow/radius retune to §5/§8/§9, Dashboard 2-column KPI grid, Chairman 3-column tool grid, module signature moments.
Balance verified (full project sweep, zero issues). Build not run (sandbox limitation, unchanged).

## Update — v113-38 (Batch 2: vector-icon migration begins — Blueprint §6/§10/§23)
`core/SubModuleGrid.kt`:
- `ModuleGradientHeader` and `ModuleWorkspaceHeader` gained an optional `iconVector: ImageVector? = null`. When supplied the header renders the vector inside a translucent white chip (§6); the emoji parameter is retained so all ~21 existing call sites keep compiling while modules migrate one at a time. **No signature break anywhere.**
- `SubModuleItem` gained an optional `iconVector` (6th param, defaulted) — every existing positional construction still compiles; tiles render a white vector icon when supplied.
- **Removed the infinite pulse animation** on the header icon. An endlessly pulsing icon is not in the blueprint's motion budget (§10) and is a classic demo-ware tell. Cleaned up the 5 animation imports this orphaned (verified each was import-only before deleting, so no compile risk).

Migrated the 6 flagship module headers to real Material vector icons: Sales → `TrendingUp`, HR → `Groups`, Warehouse → `Warehouse`, Production → `Factory`, Finance → `AccountBalance`, Chairman → `WorkspacePremium`. All from `material-icons-extended`, already a dependency — no new assets.

Balance verified per file and project-wide, zero issues. Build not run (sandbox limitation, unchanged).
**Next:** migrate the remaining 15 module headers, then the `SubModuleItem` tile grids (the largest remaining emoji surface), then `StatusPill` adoption on record rows.

## Update — v113-39 (Batch 3: all module headers now on vector icons)
Migrated the remaining 18 header call sites off emoji onto Material vector icons, completing the header layer:
CRM → `Map` · Tasks → `TaskAlt` · Approvals → `FactCheck` · Notifications → `Notifications` · Billing → `CreditScore` · Inventory → `Inventory2` · Purchase → `ShoppingCart` · Apply Leave → `BeachAccess` · Courier → `LocalShipping` · Reports → `InsertChart` · Expenses & New Expense → `Payments` · Helpdesk → `SupportAgent` · Comms → `Forum` · Complaint → `MarkunreadMailbox` · Dealers → `Storefront` · Record Collection → `AccountBalanceWallet` · Market → `QueryStats`.

**Every module header in the app (21) is now on a real vector icon.** All names are genuine `material-icons-extended` symbols; the library was already a dependency so no assets were added. Emoji strings remain in the call signatures as the untouched fallback parameter — harmless, and they keep the diff minimal.

Balance verified project-wide, zero issues.
**Next batch:** the 64 `SubModuleItem` tiles across 10 files (Billing 7 · Courier 3 · CRM 10 · HR 6 · Inventory 10 · Finance 7 · Production 8 · Warehouse 2 · Purchase 6 · Sales 5) — the largest remaining emoji surface, and the one most visible to users since the tile grid is every module's landing view.

## Update — v113-40 (Batch 4: all 64 module-hub tiles on vector icons — emoji removed from UI chrome)
Migrated every `SubModuleItem` tile across all 10 module files to Material vector icons (64 tiles, verified: zero remaining without one). Icons chosen per tile meaning, e.g. Finance: Quick Ledger→`MenuBook`, Chart of Accounts→`AccountTree`, Vouchers→`ReceiptLong`, Cash & Bank→`AccountBalance`, Trial Balance→`Balance`, P&L→`TrendingUp`, Balance Sheet→`PieChart`. Production: Materials→`Layers`, BOM→`Architecture`, Orders→`Factory`, QC→`VerifiedUser`, Loss→`TrendingDown`, Machines→`Build`. Inventory: Levels→`Inventory2`, Adjustment→`Balance`, Damage→`BrokenImage`, Expiry→`HourglassBottom`, Count→`Calculate`, Intelligence→`Psychology`.

Applied as a positional 6th argument matching the defaulted `iconVector` field added in v113-38, so every construction stays valid Kotlin. The emoji string remains in position 3 as the untouched fallback — not rendered any more, but keeping it avoids touching the data class's required params.

**Blueprint §6 ("emoji are banned in UI chrome") is now satisfied for the two largest surfaces: all 21 module headers and all 64 hub tiles.** Remaining emoji are in quick-action chip labels, empty-state glyphs, and body text — smaller, lower-traffic surfaces for a later pass.

Balance verified project-wide, zero issues. Build not run (sandbox limitation, unchanged).
**Next in blueprint order:** `StatusPill` adoption on record rows (§20), then card/shadow/radius retune (§5/§8/§9), then Dashboard 2-column KPI grid (§22) and Chairman 3-column tool grid (§24).

## Update — v113-41 (Batch 5: card retune §5/§8/§9 + StatusPill adoption §20)
`core/DualControlComponents.kt` — `GlassCard` retuned to blueprint: radius 18→16dp, and the single 6dp shadow replaced with the two-layer recipe (wide 10dp ambient + tight 2dp contact). One shadow reads as a grey halo; stacking two is what makes a card look seated. This one component is used on every module screen, so the depth change lands app-wide.

`theme/Color.kt` — `GlassBorder` retuned to the blueprint hairline `#E4E7EC`. **Bug caught and avoided:** first wrote it as `val GlassBorder = HairlineBorder`, but `HairlineBorder` is declared later in the same file and Kotlin initialises top-level vals in declaration order — that would have silently rendered every card border transparent at runtime. Kept the literal value instead, with a comment explaining why.

`StatusPill` adopted on 5 record rows (Collection, Lead, Production Order, Leave, Employee), replacing hand-rolled `when` colour expressions. Extended `statusColor()` to cover the enum values those rows surface — `EmployeeStatus` (CONFIRMED/PROBATION/SUSPENDED/TERMINATED/RESIGNED/RETIRED), `LeadStatus` (NEW/CONTACTED/QUALIFIED/VISIT_PLANNED/NEGOTIATION/CONVERTED/LOST) and `OrderStage` (SO_LOGGED/ASM_VERIFIED/DEALER_ROUTED) — so none fall through to grey. Verified zero duplicate literals across the `when` branches (a duplicate would be a compile error).

Balance verified project-wide, zero issues.

## Update — v113-42 (Batch 6: Dashboard Executive Summary → 2-column white KPI grid, §19/§22)
Replaced the Executive Summary's dark-gradient panel (`#1B2340`→`#141A30`, a leftover from the app's old dark theme that fought the bright-white direction everything else now uses) with a 2-column grid of individual white `GlassCard` KPIs.

Same six metrics, same `UniversalActionMenu`, same CSV/share payload — only arrangement and surface changed. Sales now uses the brand orange rather than the old `ElectricCyan`.

**Preserved rather than dropped:** the count-up animation. The first version of the new `DashboardKpiCard` took a pre-formatted `String`, which would have silently lost the animated counter that blueprint §10 lists as already-implemented behaviour. Reworked it to take `(value: Double, format: (Double) -> String)` like the old `KpiTile` did, and updated all five call sites. Then removed `KpiTile` itself, now genuinely unused (verified: only a comment mentions it).

Status colours now route through `attentionColor()` / `problemColor()` instead of inline `if` expressions, so Low Stock and Pending Approvals follow the same green/amber/red rule as every other KPI in the app.

Balance verified project-wide, zero issues.

## Update — v113-43 (Batch 7: Chairman tool grid, §24)
`ui/chairman/ChairmanHubScreen.kt` — replaced the stacked list of 5 emoji `OutlinedButton`s with a **3-column icon-chip tile grid of 15 tools**, matching blueprint §24 and the design reference.

The 5 dialog-backed tools keep their existing dialogs (Vacant Positions, Account & Access, Trusted Devices, Login Activity, Backup). Added 10 more Chairman destinations the blueprint lists — Chairman Notice, Communication Hub, Helpdesk, Complaint Box, Audit Log, System Health, Business Rules, Global Settings, Sync Status, Reports — each navigating to a route **already registered in NavGraph** (verified all 10 resolve before wiring them). No new screens, no new permissions, no change to the Chairman access gate.

Added the imports the grid needs (`Icons`, `icons.filled.*`, `Alignment`, `sp`) and confirmed `IconChip`'s `size: Int` parameter matches the call. Verified zero `OutlinedButton` references remain in the file.

Balance verified project-wide, zero issues.

## Update — v113-44 (Batch 8: module signature moments, §28–§34)
Added 5 shared primitives to `core/DesignPrimitives.kt` — the things that make each module read as its own trade's software rather than the same list in a different colour:
- **`YieldBar`** (§30, Production) — green ≥85%, amber ≥70%, red below. Thresholds lifted verbatim from the inline logic Production already used, now in one place.
- **`PresenceDot`** (§31, HR) — green present / amber late / slate absent.
- **`StageRail`** (§28, Orders) — dots joined by connectors, so stage reads as a position not a word.
- **`WaitingAge`** (§34, Approvals) — "3 দিন অপেক্ষমাণ", amber past 2 days, red past 5. Approvals are about latency, so age is surfaced instead of a raw timestamp.
- **`FigureCell`** (§29/§32, Warehouse & Finance) — right-aligned bold figure with the unit in secondary colour.

Wired in: Production batch rows now use `YieldBar` (replacing the hand-rolled two-Box bar); HR attendance rows show a presence dot beside each name; pending approval rows show waiting age; routed order rows show the 4-stage rail and a `StatusPill` in place of the old cyan text.

Checks done: `OrderStage`'s `when` covers all 5 enum values (exhaustive — a missing branch is a compile error); switched `DesignPrimitives.kt` to the `layout.*` wildcard import since the new primitives need `Row`/`fillMaxWidth`/`height`/`Arrangement`; removed a leftover empty `Row { }` created during the order-row edit.

Balance verified project-wide, zero issues.
**Remaining from the blueprint's 9-step order:** step 9 — KPI tap-through to filtered lists. Plus minor surfaces: quick-action chip emoji, empty-state glyphs, and full §20 record-row shape on lists not yet touched.

## Update — v113-45 (Batch 9: KPI tap-through, §19 — final step of the blueprint's 9-step order)
`core/SubModuleGrid.kt` — `ModuleStat` gained an optional trailing `onClick: (() -> Unit)?`. When supplied the stat becomes clickable and shows a small chevron; when not, it renders exactly as before. Optional so all ~60 existing `ModuleStat` calls stay valid untouched, and the chevron only appears on stats that actually respond — users aren't invited to tap dead numbers.

Wired tap-through on 7 KPIs that have an unambiguous destination: HR Present→Attendance tab, HR Leave→Leave tab, Warehouse Pending Receive→Transfers, Production QC Pending→QC tab, Purchase Pending Requests→Requests, Purchase Open POs→PO tab, Inventory Low Stock→Stock Levels.

**One reverted:** initially wired the Expense "Pending" stat too, but Expense has no separate filtered list to land on, so the tap would have done nothing visible. A dead tap is worse than no tap — reverted it rather than shipping a control that lies about being interactive.

Balance verified per file and project-wide, zero issues.

### Blueprint 9-step implementation order — COMPLETE
1. ✅ IconChip primitive + emoji replaced across 21 headers and 64 hub tiles
2. ✅ StatusPill + unified status colours
3. ✅ Card/shadow/radius retune (§5/§8/§9)
4. ✅ Dashboard 2-column KPI grid (§22)
5. ✅ Chairman 3-column tool grid, 15 tiles (§24)
6. ✅ Module hub tiles on icon chips (§23)
7. ✅ Record rows — StatusPill adoption (§20, on the rows that carried ad-hoc status text)
8. ✅ Module signature moments — YieldBar, PresenceDot, StageRail, WaitingAge, FigureCell (§28–§34)
9. ✅ KPI tap-through (§19)

### Honestly still open (smaller surfaces, and the items Part VI flagged as out of scope)
- Emoji remain in quick-action chip labels, empty-state glyphs and some body text — lower-traffic than the header/tile surfaces already done.
- `FigureCell` is defined but not yet adopted in Warehouse/Finance rows; §20's full three-line record-row shape is not applied to every list.
- Unchanged and still out of scope as new features, not UI work: Asset/Vehicle/Machine QR (no data models), POS screen, Generator utility screens, Geo map screen, dark mode, custom typeface.
- **Gradle build still never run in this sandbox** (no network, no wrapper jar). Every batch this session was verified by per-file brace/paren balance, import checks, enum-exhaustiveness checks and signature checks — but that is static verification, not compilation. A real build plus device QA remains required before shipping.

## Update — v113-46 (Batch 10: final polish — chip icons, empty/error states, FigureCell adoption)
- **36 quick-action chips** across 12 modules converted from emoji-in-label to a proper Material `leadingIcon` + clean text label (Attendance→`Schedule`, Leave→`BeachAccess`, Transfer→`LocalShipping`, Count→`Calculate`, Damage→`BrokenImage`, QC→`FactCheck`, Reconcile→`Balance`, Risk→`Warning`, Challan→`LocalShipping`, Start Batch→`PlayArrow`, New PO→`EditNote`, Receive→`MoveToInbox`, and so on). Verified `Modifier`/`size`/`dp` imports exist in all 12 files before writing.
- **`WorkspaceEmptyState`** now renders an `IconChip` (default `Inbox`) instead of an emoji glyph, per §14. The `icon: String` parameter is retained but no longer rendered, so all ~35 existing call sites keep compiling untouched — a new `iconVector` param lets screens pick a better icon over time.
- **`WorkspaceErrorState`** uses an `ErrorOutline` chip in `StatusRed` instead of ⚠️.
- **`FigureCell` adopted** in the Inventory stock rows (§29) — the WMS column-alignment look it was defined for in the previous batch, rather than leaving the primitive unused.
- Switched both state icons to `Icons.Filled.*` rather than mixing in `Icons.Outlined.*`, keeping one icon family across the app.

Verified after: full project brace/paren sweep clean; no emoji remain in any `AssistChip` label (only Bangla text, which is correct).

### Status: the blueprint is implemented end to end.
All 9 steps plus the follow-on polish are done. What remains is what Part VI of the blueprint always listed as **out of scope for UI work** and unchanged: Asset/Vehicle/Machine QR (no data models exist), POS screen, Generator utility screens, Geo map screen, dark mode, custom typeface.

**The one thing I cannot verify:** a real Gradle build has never run in this sandbox (no network, no `gradle-wrapper.jar`) — true for every batch this entire session. Everything above was checked by per-file brace/paren balance, import presence, enum exhaustiveness, route existence and signature matching. That is static verification, not compilation. Please build in Android Studio; if anything fails, the error list will point straight at it and it will be quick to fix.

# ============================================================
# v113-47 — SECURE QR ARCHITECTURE (closure batch)
# ============================================================
Date: 2026-08-02

## Exact current version
**v113-47.** Room schema **v68 → v69**. Previous shipped version was v113-46.

## Real build status
**NO REAL GRADLE BUILD WAS RUN.** Attempted this batch and confirmed the cause:
`gradle/wrapper/` contains only `gradle-wrapper.properties` and a `MISSING_WRAPPER_JAR.md`
placeholder — the wrapper jar is absent and the sandbox has no network to fetch it
(`./gradlew --version` fails with `Could not find or load main class "-Xmx64m"`).
Everything below was verified statically: per-file brace/paren balance, import presence,
API-signature checks against the real declarations, permission-key checks against actual
usage, and route-existence checks. **Compile success is NOT claimed.**

## Root changes
Replaced business-identifier QRs with an opaque, revocable, company-scoped QR registry.
Previously a QR encoded `dealerCode` / `invoiceNo` / `sku` — sequential, guessable, and
impossible to invalidate once printed, because the code *was* the record's name. A QR now
carries `ABMQR:1:<opaqueId>:<token>` and nothing else; all meaning and validity live in the
registry and are checked at scan time.

## Files changed
| File | Change |
|---|---|
| `data/room/Entities.kt` | **NEW** `QrRegistryEntity`, `QrScanLogEntity` |
| `data/room/Daos.kt` | **NEW** `QrRegistryDao` (company-scoped queries), `QrScanLogDao` (append-only: no update/delete method exists) |
| `data/room/AppDatabase.kt` | version 68→69, two entities + two DAOs registered, `MIGRATION_68_69` added |
| `data/QrRegistry.kt` | **NEW** — token generation, lifecycle, validated resolution, scan logging |
| `data/CodeRegistry.kt` | **NEW** `resolveRegistered()` — id-only lookup bridge, performs no matching |
| `data/MockRepository.kt` | `internal val database` accessor so `QrRegistry` shares one DB/transaction scope. **No business logic touched.** |
| `ui/scanner/UniversalScannerScreen.kt` | secure path primary; denial + offline-verification states |
| `firestore.rules` | QR registry + append-only scan-log rules |

## Database changes
`MIGRATION_68_69` — **purely additive**: two `CREATE TABLE IF NOT EXISTS` plus three indices.
No existing table altered, no row rewritten, no data deleted. No `fallbackToDestructiveMigration`
anywhere (confirmed still absent). Transactions used for issue/reissue so a record can never
hold two ACTIVE QRs.

## Rules changes — **must be published before this build is used**
- `qrRegistry/{qrId}` — read same-company only (no cross-company read at *any* role, Chairman included, since Chairman heads one company and is not a platform admin); create requires manager tier + own-company stamp + non-empty tokenHash; update forbids changing `companyId`/`entityType`/`entityId`/`tokenHash`/`issuedAt`, so a revoked tag can never be re-pointed at another record while its printed token stays in circulation; **a REVOKED/REISSUED/EXPIRED row can never return to ACTIVE**; delete always denied.
- `qrScanLogs/{logId}` — create only, with `userId == request.auth.uid` so a client cannot forge a log under another identity; update and delete denied outright.
- **No existing rule was weakened.**

## QR entities supported
Dealer · Retailer · Employee · Invoice · Collection · Product · Carton · Production Batch ·
Warehouse Transfer · Delivery. Permission mapping verified against the module keys actually
in use (`hr`, `dealer`, `bill`, `inv`, `prod`, `stock`, `purchase`, `order`, `settings`).
Unknown entity types are **refused**, not waved through.

## QR lifecycle implemented
`issue()` (auto-supersedes any existing ACTIVE in one transaction) · `revoke()` (atomic
conditional update; concurrent revokes cannot both succeed) · `reissue()` · `activeFor()` ·
`historyFor()` · `resolve()` validating in order: payload shape → registry presence →
company isolation → token hash → status → expiry → permission. Every denial is audited and
never reveals what the QR pointed at.

## PENDING CORE EXPANSION (not implemented, not claimed)
- **Auto-activation at lifecycle points** (invoice finalization, dealer approval, batch
  confirmation, etc.) is **NOT wired**. `QrRegistry.issue()` exists and works, but nothing
  calls it automatically yet — QRs must currently be issued explicitly. Wiring those ~10 call
  sites touches approval/finalization flows and was left out of a batch already this large.
- **Show/Print/Share/Reissue/Revoke/History UI actions** are not yet added to workspaces.
  `RecordQrButton` still renders the *legacy* code, not a registry token.
- **Firestore sync** for `qrRegistry`/`qrScanLogs` is not wired into `FirebaseSync`; rows are
  currently Room-only with `syncStatus = "PENDING"`. Offline resolution therefore works only
  for locally-created rows.
- **Firebase indexes required** once sync is wired: `qrRegistry` composite on
  (`companyId`, `entityType`, `entityId`) and (`companyId`, `status`); `qrScanLogs` on
  (`companyId`, `timestampEpochMillis` desc).
- Asset / Vehicle / Machine QR — real data models still do not exist.
- POS — see below.

## POS status (honest audit)
`SubModuleItem("pos", "POS Billing", …)` exists in the Billing module's tile grid and routes
into the existing billing tabs. There is **no dedicated full-screen POS workspace** and no
POS-specific transaction model. Accurate statement: **"POS entry point exists inside Billing;
dedicated POS workspace pending."** Not built this batch, per instruction.

## Known production risks
1. **Unbuilt.** Highest risk item — a v69 migration ships untested. Verify on a device that
   upgrades from a v68 install without data loss before release.
2. **Legacy fallback still active.** Codes that are not `ABMQR:` payloads still resolve via the
   old identifier matcher, so old printed tags keep working. This is deliberate for continuity
   but means the insecure path is not yet closed. Closing it requires reissuing every physical
   tag first.
3. Registry rows do not sync yet (see above), so revocation is device-local until sync is wired.

## Runtime tests required
- Upgrade v68 → v69 on a device with existing data; confirm no loss and both tables created.
- Issue a QR, scan it → opens correct workspace. Revoke it, scan again → denial + audit row.
- Reissue → old token denied, new token allowed.
- Scan a QR from another company's registry → `CROSS_COMPANY` denial, record never shown.
- Scan with a role lacking the module permission → `PERMISSION` denial.
- Airplane mode → cached QR shows the "offline verification" warning honestly.
- Confirm `qrScanLogs` rows appear for both allowed and denied scans.

## Exact next task
Wire `QrRegistry.issue()` into the ~10 approval/finalization points listed above, and replace
`RecordQrButton`'s legacy payload with a registry token — in that order, since the second is
useless without the first.

# ============================================================
# v113-48 — SECURE QR COMPLETION (all deferred items closed)
# ============================================================
Date: 2026-08-02

## Build status
**Still NO REAL GRADLE BUILD.** Attempted again this batch; same cause — wrapper jar absent,
no network. 103 Kotlin files swept clean (brace/paren), every cross-object API verified against
its actual declaration, all model fields and StateFlows confirmed to exist. **Compile not claimed.**

## What v113-47 left undone — now done

### 1. Auto-activation wired (was: "NOT wired, nothing calls issue()")
Added `MockRepository.activateQrFor()` — fire-and-forget on the existing repo scope, wrapped in
`runCatching`, so QR issuance can never delay or fail the business operation that triggered it.
Hooked at 7 lifecycle points, each placed immediately after the operation's own success audit:
- `approveSalesInvoice` → invoice QR (after APPROVE_AND_POST)
- `approveDealer` → dealer QR · `approveRetailer` → retailer QR
- `verifyCollection` → collection receipt QR
- `dispatchWarehouseTransfer` → transfer QR
- `createDeliveryChallan` → delivery QR
- `approveProductionPlan` → batch QR

### 2. Revocation on invalidation (new)
`MockRepository.revokeQrFor()` — same fire-and-forget contract. Wired at collection rejection and
invoice deletion. The registry row is marked REVOKED, never deleted, so what was printed and when
it stopped being valid stays auditable.

### 3. Workspace QR actions (was: "not yet added")
`RecordQrButton` gained optional `entityType`/`entityId`. When supplied it opens the new
`SecureRecordQrDialog` with **Issue / Reissue / Revoke / History**; without them it falls back to
the legacy plain-code render, so no call site broke. All 5 call sites (Collection, Warehouse
Transfer, Production Batch, Product, Delivery) upgraded to the secure path.

**A deliberate honesty point in this UI:** an already-issued token *cannot be re-displayed*,
because only its hash is stored. Rather than fake a re-render, the dialog says so plainly and
offers Reissue (which invalidates the old print). That is the correct security property, and
hiding it would have been the wrong call.

### 4. Firestore sync wired (was: "Room-only, revocation device-local")
`QrRegistry.pushRegistry()` / `pushScanLog()` follow the existing `pushAuditLog` pattern exactly —
best-effort, never gating the local write, flipping `syncStatus` to SYNCED/FAILED. Registry rows
push on issue and on revoke; scan logs push on write. `syncPending()` flushes offline-recorded scan
logs and is called from `forceResync()`, so scan evidence survives a connectivity gap.
Added `MockRepository.qrSyncCollection()` and `launchInRepoScope()` so QrRegistry shares the same
tenant path builder and the same IO scope rather than creating a second one.

## Firebase indexes now required (sync is live)
- `qrRegistry`: (`companyId`, `entityType`, `entityId`) and (`companyId`, `status`)
- `qrScanLogs`: (`companyId`, `timestampEpochMillis` DESC)

## Still deliberately open
- **Legacy fallback remains active.** Non-`ABMQR:` codes still resolve via the old matcher so
  existing printed tags keep working, and are audited as `QR_SCANNED_LEGACY`. Closing this path
  is a business decision (it requires reissuing every physical tag first), not a code change.
- POS dedicated workspace · Asset/Vehicle/Machine QR (no data models) · Map · dark mode · custom
  font — unchanged, out of scope as previously documented.
- Tablet layout untested.

## Runtime tests required (unchanged list, plus)
- Approve an invoice → confirm a `qr_registry` row appears ACTIVE for it automatically.
- Reject a collection → confirm its QR flips to REVOKED and a subsequent scan is denied.
- Issue from a workspace, print, then Reissue → old token denied, new one allowed.
- Airplane mode: scan, then reconnect → confirm the scan log reaches Firestore via `forceResync`.

# ============================================================
# v113-49 — COMPILE REPAIR (root cause fix for the 135 errors)
# ============================================================

## Root cause #1 — ~125 of the 135 errors were ONE mistake
`Icons.Filled.Foo` is an **extension property** declared in package
`androidx.compose.material.icons.filled`. It is *not* a member of the `Icons.Filled`
object. Kotlin cannot resolve an extension property through a fully-qualified path — it
must be imported.

Across v113-38 → v113-46 I wrote icons as
`androidx.compose.material.icons.Icons.Filled.TrendingUp`, assuming a qualified path would
work. It cannot. That single wrong assumption produced every "Unresolved reference
'Warning' / 'CreditCard' / 'LocalShipping' / …" error. The icon names were all valid —
`MainActivity.kt` used the same ones successfully because it has `import ...icons.filled.*`.

**Fix:** stripped the qualified prefix to `Icons.Filled.Foo` and ensured both
`import androidx.compose.material.icons.Icons` and `...icons.filled.*` in the 23 affected
files. The 12 pre-existing files that use specific per-icon imports were checked and left
untouched — they were already correct.

Verified all 100 distinct icon names in use are genuine `material-icons-extended` symbols.
**No icon was substituted or invented** — none needed replacing, because none were wrong.

## Root cause #2 — 8 redeclaration errors
`data/room/QrRegistry.kt` already contained `QrRegistryEntity`, `QrScanLogEntity`,
`QrRegistryDao`, `QrScanLogDao`. In v113-47 I appended a second set to `Entities.kt` and
`Daos.kt` without checking, giving two declarations of each in the same package.

**Fix:** kept `data/room/QrRegistry.kt` as canonical (better written — indices declared in
the `@Entity` annotation, uses `@Upsert`) and removed my appended blocks. Then adapted
`data/QrRegistry.kt` to the canonical DAO API: `findScoped`→`findByQrId` + Kotlin-side
company check, `activeFor`→`findActiveFor`, `revokeIfActive`→`transitionStatus`,
`markSynced`→re-insert with SYNCED, `lat/lng`→`gpsLat/gpsLng`. Company isolation is
preserved exactly — enforced one layer up instead of in SQL.

## Root cause #3 — `resolveRegistered` unresolved
It is a top-level **extension function** on `CodeRegistry`; importing `CodeRegistry` does
not import its extensions. Added `import com.abm.erp.data.resolveRegistered`.

## Bonus: a runtime crash caught while repairing (not in the error list)
My `MIGRATION_68_69` created `lat`/`lng` columns and only 3 of the 5 indices the canonical
entities declare. Room validates the migrated schema against the entities at open time, so
this would have thrown `IllegalStateException` on every v68→v69 upgrade — a crash, not a
compile error, so the compiler would never have caught it. Corrected the column names to
`gpsLat`/`gpsLng` and added `index_qr_registry_status` and `index_qr_scan_logs_qrId`, and
renamed `index_qr_registry_entity` to Room's expected
`index_qr_registry_entityType_entityId`.

## Summary
| | |
|---|---|
| Errors addressed | 135 (≈125 icon-path, 8 redeclaration, 1 `resolveRegistered`, 1 `QrCode2`) |
| Files modified | 27 (23 icon-import fixes + `Entities.kt`, `Daos.kt`, `data/QrRegistry.kt`, `AppDatabase.kt`, `UniversalScannerScreen.kt`) |
| Duplicate declarations removed | 4 (`QrRegistryEntity`, `QrScanLogEntity`, `QrRegistryDao`, `QrScanLogDao`) |
| Invalid icons replaced | 0 — all names were valid; the reference *syntax* was wrong |
| APIs reconnected | `resolveRegistered`, 6 DAO methods remapped to canonical names |
| Business logic / schema / QR architecture changed | none |

## Compile status
**NOT VERIFIED — no Gradle build was run.** The wrapper jar is still absent and the sandbox
has no network, so I cannot claim compile success and am not doing so. What I can state:
103 files sweep clean for brace/paren balance and duplicate imports; zero fully-qualified
icon paths remain; zero duplicate declarations remain; every icon name validated; every
changed call site checked against its actual declaration. Please rebuild — if anything
remains it should be a small, localised set rather than a systemic pattern.

# ============================================================
# v113-50 — ENTERPRISE DESIGN SYSTEM (UI rebuild, batch 1)
# ============================================================

## Approach
Before writing anything I inventoried `core/` and found **29 composables already exist**
(GlassCard, IconChip, StatusPill, ModuleWorkspaceHeader, ModuleStat, WorkspaceEmptyState…).
Twice this session I have shipped duplicate declarations by not checking first
(DesignPrimitives.kt, room/QrRegistry.kt), so this batch started with a collision audit and
every new name was verified unique before the file was written.

## New file: `core/EnterpriseDesignSystem.kt`
The primitives that were genuinely missing:
| Primitive | Purpose |
|---|---|
| `Space` (xs/sm/md/lg/xl/xxl) | the only permitted spacing values — 4/8/12/16/24/32 |
| `CardRadius` | one radius app-wide (16dp) |
| `PremiumCard` | two-layer shadow surface (wide ambient + tight contact) |
| `AccentCard` | PremiumCard with a coloured left edge for state-bearing rows |
| `HeroCard` | the one big number per screen, brand gradient, coloured glow |
| `MetricCard` | one KPI; the value's colour *is* its status |
| `SectionTitle` | small-caps header with 24dp above — the main breathing tool |
| `ActionChip` / `QuickActionRow` | tinted pill actions |
| `PrimaryButton` / `SecondaryButton` | gradient CTA with press-scale; outline secondary |
| `EnterpriseSearchBar` | sits directly above the list it filters |
| `EnterpriseFormField` | label above the input, not floating inside it |
| `EnterpriseListRow` | icon chip · title + status pill · subject · facts · action |
| `ModuleTileCard` | uniform hub tile |

Design decisions worth stating: the **two-layer shadow** is what makes a card look seated
rather than sitting on a grey halo, which is the most common giveaway of an unpolished
Compose app. **Labels above inputs** (not floating) because ERP users re-read filled forms
to check their work, and a floating label vanishes exactly when it is still needed.

## Migrated this batch
- **Dashboard KPIs** now render through the shared `MetricCard` — the Dashboard no longer
  maintains its own card. The count-up animation stays at the Dashboard call site, since it
  is specific to dashboard figures rather than to every metric in the app.
- **Dashboard target** promoted to a `HeroCard` (gradient, large figure, achievement caption).
  The detailed target/progress/comparison card remains below it, unchanged.

## Not yet migrated (next batches)
Module screens still use `GlassCard` directly and build their own rows/fields. `GlassCard`
was retuned in v113-41 so they are not *wrong*, but they do not yet use `EnterpriseListRow`,
`PremiumCard`, `SectionTitle` spacing or `PrimaryButton`. Migration order: Invoice →
Collection → Order → Warehouse → Production → HR → Finance → remaining modules.

## Unchanged
Business logic, repositories, Room, Firestore, QR architecture, permissions, workflows,
ViewModels, data models — none touched. Compile status: **not verified**, no Gradle build
available in this environment (unchanged limitation). Project-wide brace/paren sweep clean,
zero name collisions, all icon references import-verified.

# ============================================================
# v113-51 — NAVIGATION RESTRUCTURE (bottom bar removed, QR to top)
# ============================================================

## What changed
1. **Entire bottom bar removed** from `MainActivity.kt` — both the module `NavigationBar`
   (Dashboard/Sales/Inventory/CRM/HRM/Billing/Production/Boardroom) and the fixed action bar
   (Invoice · QR FAB · Collection, plus the Cash Book quick row). ~75 lines deleted.
2. **QR moved to the top bar**, beside search, at matching weight: a 38dp orange rounded-square
   button. One tap still opens the camera directly — no intermediate menu.
3. **Module grid added to the Dashboard.** This was necessary, not optional: with the bottom
   nav gone there was otherwise **no route to any module** and the app would have been
   unusable. The grid is 4-across, uses the new `ModuleTileCard`, and is filtered by the
   existing `visibleModulesFor(role)` — so users see exactly what their role already allowed.
   No permission logic changed, only the place you tap.
4. **`moduleIconFor()`** added in the UI layer, mapping each module key to a real
   material-icons-extended vector. `AppModule.icon` (emoji) is part of the data model and was
   deliberately left untouched — icon choice is a UI concern, so the mapping lives in the UI.

## Cleanup done with it
Removed the imports orphaned by the deletion (`bottomNavItems`, `ElectricCyan`,
`horizontalScroll`, `rememberScrollState`), added `RoundedCornerShape`, and switched the
Dashboard to the `icons.filled.*` wildcard since it now references ~22 icons.
`nav/NavGraph.kt`'s `bottomNavItems` val is now unused but left in place — it is a harmless
public declaration and deleting it would touch the nav file for no benefit.

## Still to come (the larger half of this request)
Every feature opening its own full-screen workspace — Retailer Order, Retailer List, Dealer
List, Ledger Book and the rest — is **not done yet**. Ten flows already open full-screen
(Collection, Expense, Leave, Employee Event, BOM, Production Order, Production Plan,
Warehouse Transfer, Stock Count, Invoice); the remaining lists and sub-tabs still render
inline within their module. That is the next batch, and it is a large one because it needs
new routes rather than dialog swaps.

## Unchanged
Business logic, repositories, Room, Firestore, QR architecture, permissions, workflows,
ViewModels, data models. Project-wide brace/paren sweep clean. Compile not verified — no
Gradle available in this environment.

# ============================================================
# v113-52 — SUITE NAVIGATION (21 flat modules → 11 segment suites)
# ============================================================

## What changed
**New `data/SuiteRegistry.kt`** — pure navigation metadata, 11 suites / 85 functions:
DMS · SFA · **CRM (now separate from SFA)** · HRM · WMS · MES · FMS · SCM · BI · Workspace · Command.
Each `SuiteFunction` points at an **existing** NavGraph route plus the tab index inside
that screen. No screen was reimplemented; nothing new was built.

**New `ui/suite/SuiteHomeScreen.kt`** — suite identity banner, identity strip
(name/ID/designation/company/territory/online/sync), live KPIs read from StateFlows the app
already exposes, and the suite's functions grouped by purpose.

**`startTab` added to 10 module screens** as a defaulted parameter
(`startTab: Int? = null`), initialising the existing `tab` state. Every existing call site
keeps compiling untouched — this is why the screens themselves needed no rewrite.

**NavGraph:** the 10 module routes now accept an optional `?tab={tab}` argument. Compose
Navigation matches the bare route too, so every pre-existing `navigate("dealers")` call still
works. Added `suite/{key}`.

**Dashboard:** flat module grid → suite cards (icon, name, function count, tagline).

**Login:** same layout, blue sky gradient → orange, and the one remaining `Sky` accent
recoloured.

## Why the business logic is safe
The logic lives in `MockRepository`, `InventoryRepository`, `PurchaseRepository`,
`AccountsRepository`, `PermissionManager`, `QrRegistry`, the Room DAOs and the Firestore
rules. **None of those files were touched in this batch.** What changed is which composable a
route calls and how it is laid out.

The real risk in work like this is not lost logic but lost *gating*. That is handled
explicitly: `visibleSuitesFor()` and `visibleFunctionsFor()` are both derived from the
existing `visibleModulesFor()`, and each `SuiteFunction` carries the `moduleKey` it is
filtered against. A suite can surface a function only if the role could already reach that
module — this cannot widen access, only reorganise it.

## Verified
All 28 routes referenced by the registry exist in NavGraph (checked individually). All 10
edited screens balance-clean with correct signatures. Project-wide sweep clean.

## Not done
Individual functions still open their parent screen at a tab rather than each having a
fully separate composable. That is the intended next step, and it is now cheap: the registry
already names every function and its destination.

## Compile status
Not verified — no Gradle in this environment. This batch adds 2 files, changes NavGraph
route signatures and touches 12 screens, so it is worth compiling before going further.

# ============================================================
# v113-53 — INVOICE DOCUMENT PAGE (reference-matched, full screen)
# ============================================================

## New: `ui/invoice/InvoiceDocumentScreen.kt`
The printable bill, rendered on screen — previously an invoice was a premium PDF but only a
plain list row inside the app. Matches the reference layout:
orange ABM CORPORATION header band · Invoice No / Date · **QR verification block** ·
Dealer box + Payment Terms · dark-header item table with alternating row tint
(# / Item / Qty / Rate / Amount) · Subtotal / Discount / Paid · **orange Total Amount block** ·
**In Words** · three signature slots · "Thank you for your business!" · Share + Print/PDF.

### Two correctness points
- **No figure is recomputed here.** Subtotal, discount and total read the model's own computed
  properties, so what is displayed cannot drift from what the ledger posted.
- **Print reuses `exportSalesInvoicePdf`**, so the on-screen document and the printed PDF are
  generated from the same invoice and cannot disagree.

### `amountInWords()` — new, and why it is safe
The app had no number-to-words converter, so one was written using the Bangladeshi
crore/lakh/thousand convention. It is **presentation only** — it never feeds a calculation,
and the numeric total sits beside it as the authority. This is the only new logic in the batch
and it cannot alter a financial value.

## Wiring
New route `invoice_doc/{id}`. Reached from: the invoice number in `InvoiceCard` (now orange and
tappable) and the QR scanner's Invoice result, which previously dropped the user on the Sales
hub and now opens the actual scanned invoice. `onNavigate` was threaded through
`DealerInvoiceTab` → `InvoiceCard` as a defaulted parameter, so no existing call broke.

## Unchanged
Repositories, Room, Firestore, QR architecture, permissions, approval/stock/ledger rules.

## Next (agreed, not started)
Retailer Order as its own POS-style page. That one requires extracting `RetailerTab` out of
`SalesChainScreen`, which shares `draft` / `vm` / `lastAgentAction` state with sibling tabs —
materially riskier than this batch, so it gets its own batch and its own compile.

## Compile status
Not verified — no Gradle here. Adds 1 file, 1 route, and touches 3 screens.

# ============================================================
# v113-54 — RETAILER ORDER AS ITS OWN PAGE
# ============================================================

New `ui/sales/RetailOrderScreen.kt` + route `retail_order`. Suite function "Retailer Order"
now opens this instead of `sales?tab=0`.

**How the risk was contained.** The order-taking body is *not* reimplemented — the new page
reuses the existing `RetailerTab` composable unchanged (visibility widened `private` →
`internal`, nothing else touched). Every validation, GPS check, duplicate-order guard and
permission rule inside it therefore still applies exactly as before. This was the concern
flagged before starting, and reusing rather than rewriting is what avoids it.

The route gets its own `SalesChainViewModel`, so a draft started here is independent of any
half-finished draft in the Sales module — correct behaviour for a dedicated order screen.
Header shows today's order count and value, both computed from `MockRepository.orders`.

Sweep clean. Compile not verified — no Gradle here. Adds 1 file, 1 route, 1 visibility change.

# ============================================================
# v113-55 — EMPLOYEE SETUP (Chairman self-service onboarding)
# ============================================================

## Why
Adding one employee required four screens: employee draft in HR, login account behind a
dialog inside HR, permissions in the Permission Center, territory elsewhere again. That is
the "hassle" this removes — not by changing any rule, but by putting the same operations on
one page.

## Audit findings first (this is what the work was based on)
Checked what already existed before building anything. Most of the security foundation was
already there and correct: PINs stored as **hash + salt + 120k iterations** (never plain
text), weak-PIN rejection, forced change on first login, 5-attempt lockout, account creation
already permission-gated. So almost nothing security-related needed to be built.

**The one real gap:** `resetPin(oldPin)` required the *old* PIN — precisely what someone who
has forgotten it cannot provide — and it only mutated the in-memory demo-account map, not a
real `UserAccount`. There was no way for a Chairman to help an employee locked out of their
own login.

## Added to MockRepository (3 functions, no existing logic altered)
- **`chairmanResetEmployeePin()`** — Chairman-gated, audited on both success and denial. The
  new PIN is *generated*, never chosen by the resetter, and re-rolled until it passes the same
  `isWeakPin` check new accounts face. Sets `mustChangePinOnNextLogin` so the Chairman never
  ends up knowing a PIN the employee keeps using, and clears lockout state since a forgotten
  PIN usually arrives with a locked account. **The PIN is never written to the audit log** —
  only the fact of the reset.
- **`setAccountActive()`** — suspend/restore a login without deleting the account or its
  history. Chairman-gated, audited.
- **`hasLoginAccount()`** — read-only helper.

## New screen `ui/admin/EmployeeSetupScreen.kt`
Search, add employee (name → mobile → designation → role → territory), and per-employee
**PIN Reset · Disable · Enable**. A reset PIN is shown once in a reveal card with an explicit
warning that it will not be shown again.

**Two deliberate non-features:**
- It does **not** edit permissions. Role carries the tier; per-module overrides stay in the
  Permission Center. Duplicating that editor here would create two sources of truth for
  access — the kind of thing that produces a security hole nobody notices for months.
- It does **not** bypass the hiring workflow. New employees still go through
  `createEmployeeDraft()`, so whatever approval normally governs a hire still applies. This
  is a faster way in, not a way around.

## Verified against real signatures before wiring
`createEmployeeDraft` needed `email` / `department` / `companyId` (my first call omitted them);
`UserAccountEntity` uses `lockedUntilEpochMillis`, not `lockedUntil`. Both corrected.

Route `employee_setup`, added to the Command suite. Sweep clean. Compile not verified — no
Gradle here.

# ============================================================
# v113-56 — CHAIRMAN CONFIGURABILITY (rules + branding reach the output)
# ============================================================

## Two gaps closed, both found by checking rather than assuming

### 1. Two rules the code used but nobody could edit
`STANDARD_SHIFT_HOURS` and `OVERTIME_RATE_MULTIPLIER` were already read live by the
attendance/payroll logic, but were absent from the Business Rule screen — so a Chairman
could not change shift length or the OT rate without a code change. Both added.

The defaults in the editor (8.0 and 1.5) were copied from the exact fallbacks the code uses
(`MockRepository` ~7795 and ~7833). This matters: if the screen showed a different default,
it would display a number the app does not actually apply — the specific failure mode worth
avoiding here, because it produces false confidence rather than a visible error.

Business Rules editable by the Chairman: **7 → 9**.

### 2. Company branding never reached the invoice
`CompanySettings` already stored company name, address, phone, email, VAT number — and the
Chairman could already edit them in Company Settings. But both the on-screen invoice and the
PDF exporter **hardcoded "ABM ERP"**, so none of that configuration ever appeared on a bill.

Both now read `MockRepository.companySettings()`, falling back to the old literals when a
field is blank. Screen and print read the same source, so they cannot disagree.

## Unchanged
No business calculation, repository logic, schema, permission rule or workflow was modified.
The rule *values* were always live — `businessRuleDouble()` reads the StateFlow on every
call, so a Chairman edit takes effect immediately with no restart.

Sweep clean. Compile not verified — no Gradle in this environment.

## Remaining from the configurability discussion
Approval Matrix (which role approves what, above which amount) — discussed and agreed as
low-risk, not yet built. Module ordering / hiding and KPI selection per Chairman — also
agreed, not yet built. Theme-colour selection was deliberately excluded: it would break the
semantic status colours (green = approved, red = rejected) that the design system depends on.

# ============================================================
# v113-57 — CONFIGURATION CENTER
# ============================================================

## Audit first — most of the wish-list already existed
Before building, checked each item from the configurability discussion:

| Wanted | Reality |
|---|---|
| Approval matrix (who approves how much) | **Already exists** — per-employee limits (financial / credit-override / discount / stock / purchase), editable in HR → employee → Approval Limits |
| Dashboard KPI/widget selection | **Already exists** — Customize dialog, persisted per device |
| Module enable/disable | Exists as `ModuleRegistry`, but it is a **developer readiness flag** (ENABLED / LIMITED / DISABLED), not a preference. Correctly left non-editable: it states what is production-safe, which is not a Chairman judgement |
| Business rules | 9 rules, live |
| Company branding | Exists, and since v113-56 actually reaches the invoice |

So the gap was never missing capability — it was that **no one could see the configuration as a
whole**, because it was spread across five screens.

## New `ui/admin/ConfigurationCenterScreen.kt`
One page showing the **live value** of every configurable setting, with a link to the screen
that owns each. Values are read through the same accessors the business logic uses
(`businessRuleDouble`, `companySettings`), so the page cannot show a number the app does not
actually apply.

Sections: company identity · all 9 business rules with current values · people & access
(with a direct link to Approval Limits, which was previously buried inside an HR employee
dialog) · period control.

**It also states what is deliberately not configurable, and why** — workflow step order,
semantic status colours, and audit-log immutability. An operator who assumes a setting exists
when it doesn't is worse off than one who knows the boundary, so the boundary is written down
rather than left to be discovered.

Route `configuration_center`, added to the Command suite. No new settings, no logic change.
Sweep clean. Compile not verified — no Gradle here.

# ============================================================
## v113-57 continued — INVOICE: PREVIOUS DUE & TOTAL DUE (both ক and খ)
(Verified via file timestamps while auditing this document: Configuration Center and this
Invoice Due work were both completed before the single v113-57.zip delivery — not two
separate versions. Corrected the duplicate top-level header to make that unambiguous.)
# ============================================================

## What was added
`SalesInvoice.previousDueSnapshot` and `.closingDueSnapshot`, plus the matching entity
columns and **`MIGRATION_69_70`** (two `ALTER TABLE ... ADD COLUMN ... NOT NULL DEFAULT 0`).
Purely additive: no table rebuilt, no existing invoice row rewritten. Room v69 → **v70**.

## Why stored rather than computed
Recomputing from today's dealer balance would make an old invoice silently disagree with the
paper copy in the dealer's file — the printed bill and the app would show different numbers
for the same document. The snapshot is taken once at creation and never changes.

**It records the dealer's position; it does not change it.** The actual due movement still
happens only in `approveSalesInvoice`, exactly as before — no business calculation was
touched.

## Both approaches, as requested
- **(খ) stored snapshot** — used whenever present.
- **(ক) live fallback** — invoices created before v70 have no snapshot, so those fall back to
  the dealer's current balance **and say so**: a small footnote marks the figure as current
  rather than as-printed. Showing today's number on an old bill without disclosing it would
  be worse than showing nothing.

## Shown in both places
Screen and PDF now both render Previous Due → This Invoice → **Total Due**, using the same
source and the same fallback rule, so print and screen cannot disagree.

Sweep clean. Compile not verified — no Gradle here. **This batch changes the Room schema, so
verify a v69 → v70 upgrade on a device with existing data before relying on it.**

## Still outstanding from this request
- Chairman control over invoice discount permission toggles (logo/address now flow through
  from Company Settings as of v113-56).
- Retailer Order line items with photo — needs `RetailOrder.items: String` to become real
  line items, which also changes the order-taking screen. Larger change, its own batch.

# ============================================================
# v113-58 — RETAIL ORDER LINE ITEMS (data layer) + CHAIRMAN LINKS
# ============================================================

## Retail order line items — data layer complete
`RetailOrder.lineItems` + `RetailOrderEntity.lineItemsRaw` + **`MIGRATION_70_71`**
(one additive column, `TEXT NOT NULL DEFAULT ''`). Room v70 → **v71**.

**The existing free-text `items` column is kept and still written.** That was deliberate:
`extractQuantity()`, the order displays and the CSV exports all read it, and replacing it
would have broken the fulfilment path. Both are stored — the summary for the logic that
already depends on it, the structured lines for a printable memo.

`logNewOrder()` gained a defaulted `lineItems` parameter, so every existing caller compiles
and behaves exactly as before. Line items are packed with the same
`Converters.packSalesInvoiceItems` the invoice uses, so one format serves both.

## Chairman: discount permission
Checked before building — this **already exists**. Enforcement is
`min(MAX_DISCOUNT_PCT rule, employee's own discountApprovalLimitPct)`, and the per-employee
limit is already editable in HR's authority-limits editor. Anything above it raises a
DISCOUNT approval request.

So rather than duplicate that editor into Employee Setup, Employee Setup now **links** to it.
Two places to set the same access value is exactly how a permission hole survives unnoticed —
one source of truth is worth more here than one less tap.

## Honest status of the remaining piece
The retail-order **UI** still captures a free-text item string; the line-item picker with
photo is not built yet. The data layer above is what that UI needs, so it is now a
self-contained screen job rather than a schema change. I stopped here rather than start it
and leave it half-wired, since this batch already changes the schema and is worth compiling
on its own.

**Two migrations since your last compile (v69→v70→v71).** Please verify an upgrade from a
device with existing data before relying on either.

# ============================================================
# v113-59 — RETAILER ORDER PAGE COMPLETE (line items + photo)
# ============================================================

## ViewModel: cart state
`SalesChainViewModel` gained `cart`, `addToCart`, `updateCartQty`, `removeFromCart`,
`clearCart`, `cartTotal`.

**The safety property that matters:** `submitOrder()` uses the cart only when it has lines.
With an empty cart it behaves *exactly* as before — typed item text, typed amount — so the
original order entry, and anyone still using it, is untouched. When lines exist they are the
single source for both the summary string and the amount, so a memo's total can never
disagree with the lines printed on it.

Adding the same product twice increases quantity instead of creating a second row —
otherwise a memo shows one item on two lines and the shopkeeper queries it.

## Screen
`RetailOrderScreen` now has: cart list with **− qty +** steppers and per-line totals, an
orange **Total Items / Total Amount** bar, "+ পণ্য যোগ করুন", and a full-screen product picker
searching the real product master by name or SKU. The picker shows the **real product photo**
via `photoUri` when the company uploaded one, and an icon chip when it did not — no
placeholder image is invented for products without one.

Below the cart, the original `RetailerTab` is still rendered **unchanged**, so retailer
selection, photo capture, GPS tagging, the duplicate-order guard and the anonymous-sale path
all continue to apply exactly as before. This page adds to that flow rather than replacing it.

## Verified before wiring
`Product` fields (`id/sku/name/unit/category/defaultUnitPrice/photoUri`), `SalesInvoiceLineItem`
signature, `coil-compose` already a dependency with `AsyncImage` used elsewhere in the app,
and the `flow.update` / `draw.clip` imports.

Sweep clean. Compile not verified — no Gradle here.
**Reminder: three migrations since your last successful compile (v69→v70→v71).** Test an
upgrade with existing data.

# ============================================================
# v113-60 — PARTY STATEMENT (bank-statement ledger)
# ============================================================

## New `ui/ledger/PartyStatementScreen.kt`, route `statement/{type}/{id}`
Opening Balance → dated rows (Date · Particulars · Debit · Credit · **running Balance**) →
Total Debit / Total Credit → **Closing Balance**. Date range as quick chips
(This Month · Last Month · 3 Months · Custom) with a real **calendar picker** for Custom —
option (গ) as requested.

### Two correctness points
- **The running balance is read, not recomputed.** `PartyLedgerEntry.balanceAfter` is already
  posted at transaction time, so the statement shows what was actually recorded and cannot
  drift from the ledger. Opening balance is likewise taken from the last entry *before* the
  window rather than recalculated.
- **Cascade visibility is enforced on the screen itself**, using the existing
  `visibleDealerIds` / `visibleRetailerIds`. A direct link or a search result cannot be used
  to open a party outside your territory — the screen refuses and says so. This mattered
  because the screen is reachable by URL-style route, not only from a filtered list.

Universal Menu gives Print / Share / CSV with the company header, so the output looks like a
company statement rather than a data dump.

## Bug found and fixed while wiring (would not have compiled)
`DealerScanDetail` contained `onNavigate("invoice_doc/$invoiceId")` — but `invoiceId` is not
one of its parameters. An earlier edit of mine had matched the wrong row, since the Dealer and
Invoice chains both contained an identical `Text("Invoice")` button. That is an unresolved
reference, i.e. a hard compile error, introduced in v113-53 and only surfacing now.

Fixed, and while there each scan result was pointed at its **own** record: Dealer → that
dealer's statement, Retailer → that retailer's statement, Invoice → that invoice's document.
Previously they all dropped the user on a module hub, which defeats the point of scanning.

Sweep clean. Compile not verified — no Gradle here.

## Still open from this discussion
Search results opening the right destination — including geo/territory entries opening a
territory summary, and a territory-wise retailer list. Not started; that is the next batch.

# ============================================================
# v113-61 — SEARCH LANDS ON THE RECORD + TERRITORY OVERVIEW
# ============================================================

## 1. Search results now open the thing you found
Every result previously routed to a module hub — searching a dealer dropped you on the
Dealers screen, where you had to find them again. That defeats the point of searching.
Now: Dealer → that dealer's statement · Retailer → that retailer's statement ·
Invoice → that invoice's document. Other types keep module routes because no record-level
page exists for them yet.

The search dialog already navigated via `navRoute`, so this took effect by correcting the
routes at the source rather than changing the dialog.

## 2. Territory as a real destination
Searching a place name now returns a **Territory** result with its own page
(`territory/{zone}`), showing for that area:
- KPIs: dealers · retailers · total due · over-credit-limit · 7-day sales
- **Sales trend** and **Collection trend** graphs (7 days, from real invoice/collection dates)
- **Product-wise sales** — aggregated from actual invoice line items, ranked, with share bars
- Dealer list and Retailer list, each row opening that party's statement

Zones are derived from the dealer/retailer data that already exists — no new master list was
introduced.

## Cascade rule, applied where it actually matters
Scoping is applied to the **underlying lists**, not just the header: dealers and retailers go
through `visibleDealerIds` / `visibleRetailerIds` first, and every KPI, graph and product
figure is computed from those already-scoped lists. So an SR opening a zone sees it as far as
their own scope reaches, and the totals cannot leak company-wide numbers through an aggregate.
Had the filter been applied only to the visible lists, the graphs above them would have
silently shown everyone's data.

## Field checks done before wiring (two would have failed to compile)
`Retailer` has **no** `zone` field — it uses `market`; corrected in the search aggregation.
Confirmed `retailerCode`, `outletCategory`, `dueBalance`, `creditLimit` on Retailer and
`partyId`/`amount`/`createdAt` on PartyCollection before use.

Sweep clean. Compile not verified — no Gradle here.

# ============================================================
# v113-62 — MODULE BOUNDARIES CORRECTED
# ============================================================

## The rule applied
Each module is the complete application for its own segment. A function belongs where its
segment's daily work happens — even when a similar function exists in another module.

| Module | Now holds | Moved out |
|---|---|---|
| **DMS** | Dealer Add · Directory · **Dealer Stock** · Retailer Network · Collection · Dealer Invoice · Credit Risk · Payments · Challan · Return | Company Ledger Book → FMS |
| **MES** | Plan · BOM · Batch · QC · Machine · Yield · FG · **Factory Workforce & attendance** | — |
| **HRM** | **Office staff only** — directory, attendance, leave, payroll, lifecycle | factory workers → MES |
| **FMS** | The company's books — ledger, cash/bank, CoA, trial balance, P&L, balance sheet | — |

Taglines now state the boundary explicitly ("Office staff —", "Factory —", "Company books —")
so nobody hunts for a function in the wrong module.

## Removed a duplicate
"Factory HR" and "Factory Workforce" were two entries pointing at the same screen and tab.
Kept one. 89 → 88 functions.

## Three findings worth recording, because two were mistakes of mine

**1. `Workforce` enum — added, then fully reverted.** I added a `Workforce { OFFICE, FACTORY }`
field with its own column and migration, before discovering `EmployeeType { OFFICE, FACTORY }`
already exists *and is already used* in three places. Two competing fields for the same
concept is precisely the two-sources-of-truth problem that produces silent misclassification —
and payroll is not a place to guess. Reverted the enum, the domain field, the entity column and
the migration.

**2. A field landed in the wrong entity.** The first insert matched `val department` inside
`vacancies` rather than `employee_profiles`, because both entities have that column. Caught by
checking which `@Entity` the new line actually fell under, not by trusting the edit.

**3. My revert then broke a pre-existing migration.** Backing out the version bump also
un-registered `MIGRATION_71_72`, which is *not* mine — it adds the real `employeeType` column.
Since the entity declares that column, the database must be at v72 with that migration
registered, or Room fails schema validation at open. Restored: version 72,
`MIGRATION_71_72` re-registered.

**Net schema change from this batch: none.** v72 with the same migrations as before.

## Already correct, verified rather than assumed
The fake `FactoryHrmTab` (hardcoded "Laborer 12/27/33") is gone — it now reads the real
factory workforce via `employeeType == FACTORY`. Dealer Add / Directory / Stock were already
in DMS, and the company ledger already out of it.

Sweep clean. Compile not verified — no Gradle here.

## Still genuinely missing (not built, not claimed)
`Dealer.stockUnits` is a single Int — total units, not per-product. A true product-wise Dealer
Stock page needs a `dealerId + productId + qty` table, which is a new entity and migration. The
DMS "Dealer Stock" entry currently opens the dealer directory where that total is shown.

# ============================================================
# v113-63 — DOCUMENTATION ACCURACY + PRODUCT-WISE DEALER STOCK
# ============================================================

## 1. Documentation accuracy pass (requested explicitly)
Audited this file for internal consistency. Found one real defect: **v113-57 was used as a
header twice** (Configuration Center, and Invoice Previous Due). Verified via actual file
modification timestamps (`InvoiceDocumentScreen.kt` last touched 04:47:48, one minute before
the single `v113-57.zip` was packaged at 04:48) that both pieces of work genuinely shipped in
the *same* delivery — not a numbering error, just an unclear header. Merged into one section
with a note explaining the correction, rather than silently rewriting history.

## 2. Product-wise Dealer Stock — the gap flagged as "genuinely missing" in v113-62

### The honesty constraint that shaped the design
`Dealer.stockUnits` (a single Int) is trusted and complete — it's driven by real events and
several existing flows depend on it. A product-wise breakdown can only be built from
*structured* line items, which exist for invoices from the baseline and for retail orders only
from v113-59 onward. **Backfilling from history was rejected**: it could reconstruct "stock
arrived via invoice" accurately but not "stock left via old-style retail order fulfillment" —
producing a breakdown that looks precise but overstates dealer stock. Decided against
manufacturing an appearance of accuracy the underlying data can't support. Tracking starts
from this ship date, forward-only, and the screen says so explicitly.

### What was built
- **New `DealerStockLineEntity`** (`dealerId`+`productId` primary key) + `DealerStockLineDao`,
  registered with **`MIGRATION_72_73`** (one new, empty table — `Dealer.stockUnits` and every
  table that already existed are completely untouched). Room v72 → **v73**.
- **`adjustDealerStockLine()`** — a private mirror function, called *alongside* every existing
  `dealerDao().adjustStock()` call, from the exact same line items and the exact same event,
  so the aggregate and the breakdown can never fall out of sync. Wired at all **4** real
  write-paths found by auditing every call site of `adjustStock`:
  - Invoice approval (stock arrives)
  - Invoice edit (reverse old lines, then apply new — both mirrored separately, matching the
    two existing aggregate calls exactly)
  - Sales return approval (stock leaves)
  - Retail order fulfillment — mirrored **only** when the order has structured line items
    (v113-59+); older free-text-only orders still decrement the aggregate exactly as before,
    with no product-level guess.
- **Not clamped at zero.** If a line ever goes negative, that reflects a real discrepancy in
  the underlying events (e.g. a return recorded against stock whose arrival was never
  captured) and is shown in red with an explanation — clamping would hide the evidence of
  exactly the problem this feature exists to surface.
- **New `ui/dealer/DealerStockScreen.kt`** (route `dealer_stock/{id}`) — shows the trusted
  total, then (if the total exceeds the tracked sum) an explicit disclosure of how many units
  predate product-level tracking, then the per-product breakdown with share bars.
- Reached via a new **"📦 View Product Breakdown"** row inside the existing dealer detail
  panel, next to the dealer's PIN controls. `onNavigate` was threaded through `DealersScreen`
  → `DealerDetailPanel` as a defaulted parameter (both the NavGraph call site and the panel
  signature updated), so no existing caller broke.

### Verified against real code before wiring
Traced all 4 `adjustStock` call sites individually and read their surrounding code rather than
assuming; confirmed `SalesInvoiceLineItem` field names (`productId`, `name`, `qty`); confirmed
`updated` at the retail-order-fulfillment site is `RetailOrderEntity` (has `.lineItemsRaw`) —
not the domain type.

Sweep clean. Compile not verified — no Gradle here. **This batch changes the Room schema
(v72 → v73)** — verify an upgrade with existing data before relying on it, in addition to the
v70 and v71 upgrades still pending verification from earlier batches.

# ============================================================
# v113-64 — RULES AUDIT (repackage only — no app code changed)
# ============================================================
Full audit of `firestore.rules` against every Firestore collection actually referenced in
code (~100 collections, checked programmatically): **zero gaps**. No changes needed.

`storage.rules` had **two real gaps**: `companies/{id}/products/{productId}/...` (product
photo upload) and `companies/{id}/orders/{orderId}/...` (retail-order visit photo) had **no
rule at all** — meaning both uploads have been silently failing (Storage default-denies an
unmatched path). Added both, same pattern as the existing employee/retailer photo rules
(company-scoped, 10MB cap).

Repackaged because the previous zip (v113-63) predates this storage.rules fix — this is the
first delivery where app code and rules are both current together.

**Must be published to Firebase before the two photo upload paths will work**:
`firebase deploy --only firestore:rules,storage`

No Kotlin/Room/business-logic changes in this batch.

# ============================================================
# v113-65 — COMPILE FIX: fully-qualified `items()` inside LazyColumn
# ============================================================

## Root cause
`items(...)` inside a `LazyColumn` is not a regular function — it's an **extension function
on `LazyListScope`**. Extension functions cannot be invoked via a fully-qualified package
path (`androidx.compose.foundation.lazy.items(filtered) { ... }`); they must be imported and
called unqualified from inside the receiver's scope (here, `LazyColumn { ... }`'s content
lambda, which provides `LazyListScope` as the implicit receiver).

Written this way in `RetailOrderScreen.kt`'s `ProductPickerDialog`, the call failed to
resolve at all — which is why the reported errors cascaded far past the `items` line itself:
once `items(filtered) { p -> ... }` doesn't resolve, `p` never gets typed as `Product`, so
every subsequent `p.id` / `p.name` / `p.unit` / `p.defaultUnitPrice` / `p.photoUri` / `p.sku`
inside that lambda becomes "Unresolved reference" too — 13 errors from one root cause.

## Fix
Added `import androidx.compose.foundation.lazy.LazyColumn` and
`import androidx.compose.foundation.lazy.items`, then called both unqualified. `LazyColumn`
itself was harmless fully-qualified (it's a plain composable, not an extension function) but
simplified to match for consistency.

## Checked for the same pattern elsewhere
Grepped the full project for `androidx.compose.foundation.lazy.items(` — this was the only
occurrence. No other file has this bug.

Sweep clean. Compile not verified — no Gradle here, but this is a narrow, well-understood
fix (one call site, root cause identified with certainty from the error pattern itself).

# ============================================================
# v113-66 — CRASH FIX: Retailer Order (nested LazyColumn under infinite scroll)
# ============================================================

## Root cause
`RetailOrderScreen` wrapped its content in `Column(...).verticalScroll(rememberScrollState())`,
and that content included the reused `RetailerTab` composable — which internally renders its
own `LazyColumn`. A `LazyColumn` measured inside a `verticalScroll` parent (which gives its
content **infinite** height) throws immediately at runtime:
`IllegalStateException: Vertically scrollable component was measured with an infinity maximum
height constraints`. This is invisible to the compiler — it only surfaces as a crash the
moment the screen is opened, exactly as reported.

## Fix
Restructured into two independent regions instead of one shared scroll:
- The cart (product list + total bar) now sits in its own `Column` capped at
  `heightIn(max = 320.dp)` with its own `verticalScroll` — a normal, bounded scroll region.
- `RetailerTab` now sits in a `Box(Modifier.weight(1f))` inside a **non-scrolling** parent
  `Column`, so it receives a bounded height (the remaining screen space) and its own internal
  `LazyColumn` can measure and scroll itself correctly — exactly how it already worked as a
  tab inside `SalesChainScreen` before this page existed.

`RetailerTab` itself was not touched — same reuse-not-rewrite approach as before.

## Checked for the same pattern elsewhere
None of the other pages built this session (`EmployeeSetupScreen`, `ConfigurationCenterScreen`,
`PartyStatementScreen`, `TerritoryOverviewScreen`, `SuiteHomeScreen`, `InvoiceDocumentScreen`,
`DealerStockScreen`) embed a pre-existing composable known to contain its own `LazyColumn`
inside a `verticalScroll` — `RetailOrderScreen` was the only one that reused a
`LazyColumn`-containing function this way, so this crash pattern is confirmed isolated to it.

Sweep clean. Compile not verified — no Gradle here, but this is a well-understood Compose
constraint violation with a standard fix, not a speculative change.

## Also found while investigating this batch's report (not yet acted on)
`MockRepository.uploadProductPhoto()` exists and is fully implemented, but **is never called
from any UI** — there is no photo-upload button anywhere in the product screens, unlike
Chairman Notice which has a real working upload flow. This is the concrete reason product
photo "upload" doesn't work: nothing in the UI ever invokes it. Flagged for the next batch,
not fixed in this one, to keep this crash-fix batch isolated and easy to verify on its own.

# ============================================================
# v113-67 — DEALER INVOICE: THE BILL IS THE FORM
# ============================================================

## The design principle applied
Confirmed with the person before building: the Dealer box and the item table are not
decoration around a form — they **are** the form. Tapping "Dealer" opens a picker; selecting
one fills the name/zone directly into the bill header and immediately shows that dealer's
**real** `dueBalance` and `creditLimit`. "+ Add Item" is the table's own next row, not a
separate control above it; picking a product adds a real row with live qty +/− and a running
line total. Subtotal → Discount → Total recompute on every change, and a live "projected due
after this invoice" line appears once a dealer is selected — all read from real data, nothing
simulated.

## What is reused, unchanged
- **`MockRepository.createSalesInvoice(...)`** — identical parameters to the old
  `DealerInvoiceTab` form. Same stock check, same credit-limit block, same closed-period
  rejection. This page changed the layout leading up to the call, not the call itself.
- **`ProductPickerDialog`** — the exact component built for Retailer Order. Rather than
  writing a second copy for this screen (which is exactly the kind of duplication this
  project has been burned by twice already), it was extracted into
  `core/InvoicePickers.kt` as a shared, public composable. `RetailOrderScreen` now imports
  it from there instead of holding a private copy.
- **New in the same file: `DealerPickerDialog`** — same shared-picker pattern, shows each
  dealer's live due/over-limit status directly on the picker row, not only after selection.

## New route
`dealer_invoice_new`. The suite's "Dealer Invoice" function now opens this instead of
`sales?tab=2`. The old tab-based flow inside `SalesChainScreen` (including its edit-mode
path) was **not removed** — only the *create* entry point moved. Editing an existing invoice
still goes through the original in-module flow for now.

## Verified against real code before wiring
`createSalesInvoice`'s exact parameter names and its `Boolean` return type (confirmed by
reading the declaration directly, not assumed from the old call site's usage pattern);
`Dealer.dueBalance` (`var`, no default) and `Dealer.creditLimit`; `Product` fields already
verified in an earlier batch.

Sweep clean. Compile not verified — no Gradle here.

## Still open from this discussion
Retailer Order's own "memo" restyle (same principle, applied to `RetailOrderScreen` — the
functional cart/retailer-selection already works after the v113-66 crash fix; what remains
is visual, matching this invoice's bill styling) and product-photo upload UI. Both deferred
to keep this batch focused and easy to verify on its own.

# ============================================================
# v113-68 — RETAILER ORDER MEMO STYLING + PRODUCT PHOTO UPLOAD FIXED
# ============================================================

## 1. Retailer Order — memo styling
Cart area rebuilt into the same bill-table language as `DealerInvoiceScreen`: branded header
("ABM CORPORATION / Retailer Order Memo"), a live **"TO:"** line, dark-header item table with
inline qty ± and an "+ Add Item" row that is the table's own next row, then a blue Total block.

**A boundary was kept, and it's worth explaining why.** The retailer-name field, its
area-suggestions dropdown, and the "verified shop" total are tightly coupled inside
`RetailerTab`'s own logic — extracting just the name field would have meant touching the
duplicate-order-detection code that depends on it, which was flagged as too risky to do under
time pressure for a visual change. Instead, the memo's "TO:" line reads the **same draft
state** live — the name is still typed once, in `RetailerTab`'s existing field below (now
labelled "Order Details"), and the memo header reflects it immediately as you type. No
duplicate input, no risk to the duplicate-guard logic, and the bill still visibly shows who
it's for.

## 2. Product photo upload — the real bug, found and fixed

### What was actually wrong
`AddProductTab` already had a photo picker (`photoLauncher`) — but it passed the **raw local
`content://` URI** straight into `addProduct(photoUri = ...)`, which saved it as-is. A
content URI is only valid on the exact device that picked it; it was never uploaded to
Storage at all. This is the concrete, verified reason products never showed a photo anywhere
but the picking device — not a missing button, but a missing upload step behind an
already-present one.

### Fix
- **`InventoryRepository.addProduct`** gained a defaulted `onCreated: (String) -> Unit = {}`
  callback — needed because `addProduct` generates the product's id internally, so there was
  no way to know it in advance for a create → upload → attach sequence. Threaded through the
  `InventoryViewModel` wrapper the same way.
- **New `InventoryRepository.setProductPhoto(productId, photoUri)`** — persists a photo URL
  onto an *existing* product row. Separate from `addProduct` because `uploadProductPhoto`
  only ever returned a URL; nothing wrote it back onto the product, which is the other half
  of why photos never stuck.
- **Create flow corrected**: `photoUri` is no longer passed to `addProduct` directly. The
  product is created first (no photo), then — only if a photo was picked — the local file is
  uploaded via `MockRepository.uploadProductPhoto(context, newId, ...)`, and the real
  `https://` download URL is attached via `setProductPhoto`.
- **Existing products** (created before this fix, or any product with no photo) now have a
  **"📷 Add Photo" / "📷 Change Photo"** action directly on their row in the Product
  Directory, using the same real upload path. This matters because most products already in
  the app predate this fix and had no way to get a photo added retroactively until now.

### Caught while wiring (would have been a compile error)
`db.productDao().getById(...)` does not exist — `ProductDao` (declared in
`room/InventoryDaos.kt`, a different file than `room/Daos.kt`) has no single-row fetch.
Used the same `getAll().first().firstOrNull { it.id == id }` pattern already established
elsewhere in this codebase instead of adding a new DAO method for one caller.

Also caught: a second `val context = LocalContext.current` already existed later in the same
function — hoisting `context` to the top of `AddProductTab` for the new upload code would
have collided with it (a real "conflicting declarations" error). Removed the now-redundant
second declaration.

## Verified before wiring
`uploadProductPhoto`'s exact signature and behaviour (it uploads and returns a URL via
callback; confirmed it does **not** touch the product row itself, which is exactly the gap
`setProductPhoto` fills). `ProductDao`'s real method list, read in full rather than assumed.

Sweep clean. Compile not verified — no Gradle here.

# ============================================================
# v113-69 — COMPILE FIX: orphaned KDoc + @Composable in RetailOrderScreen.kt
# ============================================================

## Root cause
When `ProductPickerDialog` was extracted out of this file into `core/InvoicePickers.kt`
(v113-67), the removal script deleted from `private fun ProductPickerDialog(` down to its
matching closing brace — but the KDoc comment and `@Composable` annotation immediately
**above** that line were untouched by that range and were left behind, now with nothing
following them. Kotlin expects a declaration (fun/class/etc.) after an annotation; finding
none, it reported exactly what the screenshot showed: "Expecting a top level declaration"
at the file's new end.

## Fix
Removed the two orphaned lines. File now ends cleanly after the closing brace of
`RetailOrderScreen`.

## Checked for the same pattern elsewhere
Grepped the whole project for any file ending on a bare annotation, and for any other
`@Composable` with nothing following it — none found. This was isolated to the one file
touched by that extraction.

Sweep clean. Compile not verified — no Gradle here, but this is a narrow, fully-understood
fix (one root cause, traced directly to the specific prior edit that caused it).

# ============================================================
# v113-70 — COMPILE FIX: missing import + repeat of the Icons.Filled root cause
# ============================================================

## Issue 1 — `InventoryScreen.kt`: missing import, not a bug in the new code itself
The two `MockRepository.uploadProductPhoto(...)` calls added in v113-68 were the **only**
bare references to `MockRepository` in this file — everything else routes through the
`InventoryViewModel`/`InventoryRepository` wrappers, which were already imported.
`import com.abm.erp.data.MockRepository` had never been added. Every other reported error in
this file (6 total) was a direct cascade from that one missing import: once `MockRepository`
fails to resolve, the compiler can't infer the trailing lambda's parameter type either, which
produces the "Cannot infer type" and "Any vs String" errors on the very next line — one root
cause, not three. Fixed with a single import line.

## Issue 2 — repeat of the v113-49 root cause, found in a file written after that fix
`core/InvoicePickers.kt` (written in v113-67, two batches after v113-49 diagnosed and fixed
this exact pattern project-wide) used `androidx.compose.material.icons.Icons.Filled.Business`
— the fully-qualified path to an extension property, which cannot be called that way. Fixed
by importing `androidx.compose.material.icons.filled.Business` and using it unqualified at
both call sites, matching how every other icon in that file is already referenced.

**This was a real repeat of a documented mistake** — the earlier fix corrected every instance
that existed *at the time*, but nothing prevented the same wrong pattern from being written
again in new code afterward. Worth stating plainly rather than treating it as a one-off.

## A third instance found by re-sweeping, not reported in this build
Re-checking the *entire* project for this pattern (not just the two files the build output
named) turned up a third case: `ui/production/ProductionScreen.kt` had the same fully-qualified
`Icons.Filled.Engineering` reference, introduced in the v113-62 Factory Workforce batch. It
was not in this build's error list — most likely Gradle's incremental compiler had not
re-checked that file in this particular pass — but it is a real, live compile error waiting
in a clean build. Fixed the same way (the file already had the `icons.filled.*` wildcard
import, so this one only needed the qualified prefix removed).

## Final check
Broadened the search beyond the two exact substrings used above to catch any
`androidx.compose.material.icons.Icons.*` reference outside an import line, anywhere in the
project. Zero remain.

Sweep clean. Compile not verified — no Gradle here.

# ============================================================
# v113-71 — TASK HEADER: THE "GATHERING" CLUTTER FIX, ALL 10 SHARED SCREENS
# ============================================================

## The exact problem, confirmed before touching anything
Verified against real code that **65 of 87** Suite functions (~75%) routed into old
multi-tab screens (`SalesChainScreen`, `InventoryScreen`, `PayrollScreen`,
`ProductionScreen`, `ProductionWarehouseScreen`, `GeoCrmScreen`, `PurchaseScreen`,
`DealersScreen`, `CreditAndBillingScreen`, `LedgerScreen`). Every one of these 10 screens
rendered its full `ModuleWorkspaceHeader` (identity strip + KPI mini-dashboard + quick-action
chips + recent activity) **unconditionally** — even when the user arrived via a Suite's
clean list asking for one specific task. So the actual experience was: tap "Dealer Invoice"
from a tidy list → land on a second full module dashboard → *then* reach the invoice form.
That second dashboard, appearing every time for every one of the 65 functions, was the exact
"গ্যাদারিং" (everything gathered together) feeling described.

`DealersScreen` was structurally different from the other 9 — no null/landing tab state at
all, an always-visible 6-tab `TabRow` at the top regardless of how the screen was reached.
Confirmed by reading its `var tab` declaration before assuming it matched the other 9.

Also confirmed: the app-wide `TopAppBar` in `MainActivity.kt` has no `navigationIcon` — no
back arrow exists anywhere in global chrome. The old screens relied entirely on the system
back gesture; the in-screen "← Back to sub-menu" link only reset local tab state, it never
left the screen. So suppressing the grid/tab-row without adding a real back arrow would have
trapped the user with no way out.

## The fix — one new component, applied uniformly
**New `core.TaskHeader`** (in `SubModuleGrid.kt`): a minimal header — real back arrow, small
icon chip, task title — nothing else. Rendered in place of the full `ModuleWorkspaceHeader`
whenever `startTab != null` (i.e., reached from a Suite's specific function). When
`startTab == null`, every screen's original full dashboard and landing grid/tab-row behaviour
is **completely unchanged** — this only affects the Suite-launched path.

Applied identically across all 10 files:
- Added `onBack: () -> Unit = {}` as a defaulted parameter (no existing call site broken).
- Wrapped the `ModuleWorkspaceHeader` call in `if (startTab == null) { ... } else { TaskHeader(...) }`.
- Built each screen's tab→title reverse-lookup **from its own real `SubModuleItem` list**,
  not assumed — `PurchaseScreen` and `CreditAndBillingScreen` in particular have tab indices
  that do NOT match their `SubModuleItem` list order (e.g. Purchase: tab 5 = "Purchase
  Requests", tab 1 = "Purchase Orders"), confirmed by reading each file's real key→tab map
  before writing the reverse of it.
- Suppressed the in-screen `BackToSubMenuLink` (or, for `DealersScreen`, the entire `TabRow`)
  when `startTab != null`, since the real back arrow in `TaskHeader` now handles leaving the
  screen — no redundant, confusing second "back" control.
- Wired `onBack = { navController.popBackStack() }` at all 10 NavGraph call sites.

## Verified, not assumed, at every step
Read each file's actual header/tab block before editing (not templated blindly); confirmed
`SubModuleItem.label` field name; traced `DealersScreen`'s different `tab: Int` (non-nullable)
declaration before treating it as a special case; balance-checked all 10 files plus
`SubModuleGrid.kt` plus `NavGraph.kt` individually as each was completed, then a full
project-wide sweep at the end — zero issues.

## Net effect
All 65 Suite functions that route through these 10 screens now open directly into a clean,
single-purpose task view with nothing above it but a back arrow and the task's own title —
matching exactly how the hand-built dedicated pages (Retailer Order, Dealer Invoice, Party
Statement, Territory Overview, Dealer Stock) already looked. This was achieved by fixing the
**shared mechanism** 10 times rather than rebuilding 65 individual screens — the "pin-point
accurate but simple" approach discussed before starting.

Sweep clean. Compile not verified — no Gradle here.

## Still open from the module-reorganization discussion
The central "Approvals" inbox (Leave/Expense/Correction Request together, under Workspace)
versus per-module approval buttons — awaiting the person's decision on whether to keep it as
a convenience view alongside in-module buttons, or remove it entirely in favour of purely
in-module approval actions. RMS naming/scope, CRM redefinition (HQ-to-dealer/retailer
promotional tools vs. current sales-pipeline CRM), and HRM absorbing officer
location/target-assignment from SFA/CRM — all discussed, none yet implemented, awaiting
confirmation before starting.

# ============================================================
# ARCHITECTURE DECISIONS — this session's discussion, confirmed by the person
# ============================================================
Date: 2026-08-05. These are confirmed decisions, not yet all implemented. Read this section
before starting the next chat's work — it is the record of *why*, which matters as much as
the *what*.

## Decision 1 — CONFIRMED: no centralized cross-cutting screens. Ever.
The person's core principle, stated directly: **"একটা মডিউলের মধ্যে ঢুকলে যত ফিচার বা অপশনই
আসুক না কেন ওগুলো ওই মডিউল আকারেই হবে"** — whatever features a module needs, they live
*inside* that module, presented as a clean list, never gathered into a separate small
button/tile that opens something disconnected. This was traced to a real, measurable problem
(v113-71): 75% of Suite functions opened a screen that rendered a *second* full module
dashboard before reaching the task — fixed by `TaskHeader`.

## Decision 2 — CONFIRMED: Approvals are decentralized, not centralized
Directly answered: **প্রতিটা approval তার নিজের module-এর ভিতরেই থাকবে** — Leave approval
inside HRM, Expense approval inside FMS, Correction Request wherever it belongs, Dealer
Invoice approval inside DMS (already correct — verified in the prior turn). The centralized
`ApprovalsScreen` under the "Workspace" suite (currently pooling
`ApprovalRequest/LeaveRequest/Expense/CorrectionRequest` together) contradicts this and
**should be removed as a cross-cutting inbox** — each approval type's UI moves into its
owning module instead. **Not yet implemented** — this is the next chat's first real task.

## Decision 3 — module boundary redefinition (discussed at length, not yet implemented)
The person's own definitions, to build against exactly — not the current code's shape:

- **DMS (Dealer Management System)** — everything about a dealer: entry, data, due,
  invoice, commission, sales graph, geo-based employee assignment. Current code is close
  (dealer add/directory/stock/statement/invoice/collection all present) but has **no
  commission view** and **no dealer-specific sales graph** yet.
- **RMS (Retailer Management System)** — currently named "SFA" in the Suite registry, and
  incomplete against the person's definition: needs retailer memo, damage collection,
  retailer list, add retailer, retailer live location, full retailer data — all under one
  roof. Current "SFA" only has order/visit/route/target; retailer add, damage collection and
  live location are not present there.
- **CRM** — currently built as a sales-pipeline CRM (Leads/Opportunities/Engagement/
  Communication Log/Complaints), which is **not what was asked for**. The person's CRM is
  narrower and different: a tool for **HQ/Chairman to reach dealers and retailers directly**
  — promotional notices, special discounts, extras. This needs redefinition, not extension.
- **HRM** — should hold the whole sales wing's (everyone under Chairman) salary, employee
  location assignment, market/target fixing. Currently these are split: attendance/leave/
  payroll/lifecycle are in HRM, but location and target assignment currently live in
  SFA/CRM instead. **Needs consolidation into HRM.**
- **MFS/MES (factory)** — already matches the person's definition as of v113-62: raw
  material list, consumption list, finished-goods list, carton QR for traceability, and a
  **separate** factory workforce (add/salary/attendance) distinct from office HRM. No
  further change needed here.
- **Chairman panel** — observes/reports on everything; unchanged, already correct.

## Decision 4 — a real gap found while discussing this, not yet fixed
`DealerPickerDialog` (used by `DealerInvoiceScreen`) and the old `DealerInvoiceTab` both read
the **raw, unscoped** `MockRepository.dealers` list — cascade (`visibleDealerIds`) is not
applied. This means an SR can currently select and invoice a dealer outside their own
territory from these two screens. This is **not new** — it predates this session's UI work —
but it is real and should be fixed as part of the DMS work above. The proposed fix (discussed,
not built): a single centralized `visibleDealersFor(...)` — and its Retailer/Employee
equivalents — that every screen calls instead of ever touching `MockRepository.dealers`
directly, so cascade cannot be forgotten screen-by-screen again.

## What v113-71 already fixed (do not redo)
The `TaskHeader` clutter fix across all 10 shared multi-tab screens. See the v113-71 entry
above for full detail. This is done and verified (statically).

# ============================================================
# v113-72 — DECISION 2 IMPLEMENTED: APPROVALS DECENTRALISED
# ============================================================
Date: 2026-08-05. Implements ARCHITECTURE DECISIONS §Decision 2 ("প্রতিটা approval তার
নিজের module-এর ভিতরেই থাকবে"). The centralized `ApprovalsScreen` is gone.

## Build status
Gradle build **NOT RUN** — same sandbox limitation as every prior batch (no network, no
`gradle-wrapper.jar`). What was actually done instead:
- brace/paren/bracket balance check on every touched file;
- a project-wide balance sweep across all 117 `.kt` files, **diffed against a pristine
  extraction of the v113-71 ZIP** so pre-existing checker false positives (nested quotes
  inside `${...}` string templates in SalesChainScreen / InventoryScreen /
  MainDashboardScreen / DealersScreen) could be told apart from anything I introduced.
  Every delta was zero;
- project-wide grep sweep for dangling references to the deleted screen and route.
No compile success is being claimed. The person is compiling this batch himself.

## What was verified in the source before writing anything
Not assumed, not from memory — read from the actual code:
- `ApprovalsScreen` only ever rendered `MockRepository.approvals`, i.e. the generic
  `ApprovalRequest` entity. It never rendered `LeaveRequest` / `Expense` /
  `CorrectionRequest` rows themselves, despite its header's `ModuleRecentActivity` set
  naming all four. The prompt's description of it as "pooling all four" was true of the
  header only.
- **Leave and Expense approval already live in the right module.** `setLeaveStatus` is
  wired into HRM's `LeaveManagementTab` (PayrollScreen.kt), `approveExpense`/`rejectExpense`
  into `ExpenseScreen`. Nothing needed moving for those two — the duplicate was the
  central inbox, not a missing module UI.
- Every `raiseApprovalRequest(...)` call site was traced. `ApprovalRequest.entityType` only
  ever takes five values in this codebase: `SalesInvoice` (discount % and over-limit),
  `Expense`, `Voucher` (AccountsRepository, over-limit voucher), `Payroll` (finalization),
  `AttendanceRecord` (attendance correction). No sixth case exists, so the routing table
  below is complete rather than a guess.
- **`CorrectionRequest` has no UI anywhere in the project.** `submitCorrectionRequest`,
  `managerReviewCorrection`, `chairmanApproveCorrection`, `chairmanRejectCorrection` all
  exist in MockRepository with zero call sites outside it. So there was nothing to move
  for Correction Requests — see Open Questions.

## Files changed
1. **NEW `core/ModuleApprovals.kt`** — `ModuleApprovalSection(title, entityTypes,
   approvalTypes)`. A shared **component**, not a shared screen — the same relationship
   `TaskHeader` has to module screens. It renders inline inside a module tab, shows only
   that module's own pending requests, and renders nothing at all when there are none.
   Three deliberate details:
   - It is **not** a `LazyColumn`. It gets embedded inside tabs that are already inside a
     scrolling parent, and a nested lazy list under an unbounded height constraint crashes
     at runtime.
   - If a caller passes neither filter it returns without rendering, so the component can
     never accidentally be used to rebuild the central inbox it replaced.
   - The filter is wrapped in `remember(...)` — see Performance note below.
   Name-collision grep run before creating it (`ModuleApprovalSection`, `approvalOwnerRoute`):
   no existing declarations.
2. **NEW `data/ApprovalRouting.kt`** — `approvalOwnerRoute(entityType, type)`. Maps an
   approval to the module that owns it, for the inbound links that used to point at the
   deleted route. Every route/tab index was checked against NavGraph and against the
   target screen's own `when (key)` block:
   `SalesInvoice → sales?tab=2` (Dealer Invoice) · `Expense → expenses` ·
   `Voucher → ledger?tab=2` · `Payroll → hrm?tab=1` · `AttendanceRecord → hrm?tab=0` ·
   `ApprovalType.LEAVE → hrm?tab=2`. Unknown → `dashboard` (honest dead-end, not a wrong one).
3. **`ui/hrm/PayrollScreen.kt`** — section added to three tabs: Leave (`LEAVE`), Payroll
   (`Payroll`), Attendance (`AttendanceRecord`).
4. **`ui/expense/ExpenseScreen.kt`** — section added (`Expense`).
5. **`ui/ledger/LedgerScreen.kt`** — section added to the Vouchers tab (`Voucher`).
6. **`ui/sales/SalesChainScreen.kt`** — section added to the Dealer Invoice tab
   (`SalesInvoice`). The invoice's own ✓ Approve button there was already correct and is
   untouched; this only adds the discount/over-limit `ApprovalRequest` rows.
7. **`ui/dashboard/MainDashboardScreen.kt`** — the "Approvals" Quick Action chip removed
   (it was a shortcut to the central inbox). The status-strip Approvals chip **keeps its
   count** but is no longer tappable — a dashboard may observe, not collect.
8. **`ui/chairman/ChairmanHubScreen.kt`** — Approvals card is now count-only, not
   clickable. Chairman observes everything; he actions each approval in its own module.
9. **`ui/notifications/NotificationsScreen.kt`** — `APPROVAL` category now routes to
   `dashboard`. See Known imprecision below.
10. **`data/MockRepository.kt`** — universal-search hits on `ApprovalRequest` now route via
    `approvalOwnerRoute(...)` instead of the dead `"approvals"` string. One line, no logic
    change, no schema change.
11. **`data/SuiteRegistry.kt`** — "Approvals" removed from the Workspace suite; its tagline
    updated. Workspace's Action group is now Task Manager only.
12. **`data/ModuleAccess.kt`** — the dead `"approval" to "approvals"` route entry removed.
    The `"approval"` **module key itself is kept** — `PermissionManager.canCurrentUser
    ("approval", APPROVE)` still uses it, now from inside each owning module. (This map,
    `IMPLEMENTED_MODULE_ROUTES`, turns out to have no call sites at all — checked.)
13. **DELETED `ui/approvals/ApprovalsScreen.kt`** and its NavGraph `Dest.Approvals`, route
    composable and import.

## Known imprecision, stated rather than hidden
`NotificationCategory.APPROVAL` is a catch-all: hiring, security events, stock alerts, HR
lifecycle, expense results and SLA reminders all use it, and `NotificationEntry` carries no
`entityType`/`entityId`. So a notification cannot be routed to an owning module the way a
search hit can. `dashboard` is the deliberate fallback. Routing these properly needs an
entity link on the notification record — a schema change, so **not done unasked**.

## Performance note (the person raised 120fps this batch)
`ModuleApprovalSection` filters inside `remember(approvals, entityTypes, approvalTypes)`
rather than raw in composition. These sections sit in tabs that recompose on every scroll,
and `MockRepository.approvals` can be long; an unmemoised filter would re-scan the whole
list every frame, which does not fit a 120fps (8.3 ms) budget. This same pattern —
`collectAsState()` then filter/sort directly in composition without `remember` — exists in
a number of older screens in this project and is the most likely source of jank if 120fps
is a real target. Not touched this batch (out of scope, and the person has a UI draft
coming); flagged for a dedicated performance pass.

## Mistakes / corrections during this batch
- First draft of `ModuleApprovalSection` filtered raw in composition. Corrected to a
  `remember(...)` block after the person raised the 120fps target.
- The initial plan assumed Leave and Expense approval UI would have to be *built* inside
  HRM/FMS. Reading the source first showed both already existed and were correctly placed —
  building them would have created duplicate approval paths. This is exactly the case the
  "verify against the actual code, don't assume" rule is for.

## Open question carried to the next batch
`CorrectionRequest` has full repository support and **no UI at all**. Decision 2 says its
approval belongs "wherever that correction actually applies", and `CorrectionRequest.module`
already carries that. Deferred rather than guessed: building a first-ever UI for it is new
feature work, not a relocation, and the person has a hand-drawn draft coming that may cover
where it should live.

## Next work, unchanged from the ARCHITECTURE DECISIONS list
Decision 4 (the `visibleDealersFor(...)` cascade gap in `DealerPickerDialog` and
`DealerInvoiceTab`) is the next confirmed item and is **not** touched by this batch.

# ============================================================
# v113-73 — DECISION 4 IMPLEMENTED: ONE CASCADE ACCESSOR, TERRITORY HOLE CLOSED
# ============================================================
Date: 2026-08-05. Implements ARCHITECTURE DECISIONS §Decision 4.

## Build status
Gradle build **NOT RUN** (no network, no `gradle-wrapper.jar` in this sandbox). What was
done instead: per-file balance checks, a project-wide balance sweep across all `.kt` files
**diffed against a pristine extraction of v113-71** (all deltas zero), and greps for every
dangling local after each dedupe. No compile success claimed.

## The bug, confirmed in source
`DealerPickerDialog` itself was fine — it takes `dealers: List<Dealer>` as a parameter. The
hole was in its **callers**:
- `DealerInvoiceScreen.kt:49` — `MockRepository.dealers.collectAsState()`, raw, fed straight
  into `DealerPickerDialog`.
- `SalesChainScreen.kt:143` — same raw read, fed into `DealerInvoiceTab`'s dealer chooser
  **and** `SalesOrderTab`'s.
An SR could select, invoice, and raise a sales order against a dealer outside his own
territory. The scoping rule already existed and was correct — it was simply not applied on
those screens.

## The fix — an accessor, not another inline filter
1. **`MockRepository.visibleDealersFor(all, profiles)` / `visibleRetailersFor(...)` /
   `visibleEmployeeProfilesFor(...)`** (new). These encode the full three-branch rule that
   previously existed only as copy-paste inside DealersScreen:
   1. viewer has a real `EmployeeProfile` → hierarchy scope via `visible*Ids`
   2. no profile yet but SR/TSM → only own assigned records (`assignedEmployeeId`/`officerId`)
   3. anything else (Chairman/MD/admin) → unrestricted
   Branch 2 is copied verbatim from the DealersScreen implementation — **not new behaviour**.
   It exists because a fresh login can have no `EmployeeProfile` row yet, and without it an
   SR would fall through to branch 3 and see the whole company.
   Lists are passed in rather than read from `.value`, so Compose call sites stay reactive.
2. **NEW `core/CascadeScope.kt`** — `rememberVisibleDealers()`, `rememberVisibleRetailers()`,
   `rememberVisibleEmployeeProfiles()`. This is what screens call. A screen that calls the
   accessor cannot forget the cascade; a screen that copy-pastes a filter can. Each wraps
   the hierarchy walk in `remember(...)` — these lists are read inside tabs that recompose
   on scroll, so re-walking the hierarchy every frame would blow the 120fps budget.
3. **`MockRepository.dealers` now carries a KDoc warning banner** stating it is the raw
   unscoped list, that selection/action surfaces must not read it directly, and which direct
   uses remain legitimate. Cheap regression guard for future batches.

## Files changed
- **`ui/sales/DealerInvoiceScreen.kt`** — the actual fix. Now `rememberVisibleDealers()`.
- **`ui/sales/SalesChainScreen.kt`** — the actual fix. Also fixes a **crash**: `AsmVerifyTab`
  had `dealers.firstOrNull { it.zone == order.zone } ?: dealers.first()`. `first()` throws on
  an empty list; that was already latent, and scoping makes an empty list genuinely
  reachable. Now `firstOrNull()` with a real "আপনার এলাকায় কোনো dealer নেই" message instead
  of a Verify button.
- **`ui/dealer/DealersScreen.kt`** — three inline copies of the scoping rule (dealer list,
  QR-scan retailer list, `OutletsTab` retailer list) replaced by the accessor. Same logic,
  one implementation. Removed the now-unused `rawDealers` / `currentRoleForDealerScope` /
  `employeeProfilesForDealerScope` / `matchingProfile*` locals, and rewrote the `isScopedEmpty`
  empty-state check that depended on them (same meaning: "the company has outlets but none
  are mine" vs "there are no outlets at all").
- **`ui/crm/GeoCrmScreen.kt`** — the "New Complaint" dealer chooser is a selection surface of
  the same class, so it is scoped now (plus an empty-state line). The tab's `dealers`
  parameter, which also feeds counts and the performance ranking, is deliberately **left
  alone** — see below.
- **`data/MockRepository.kt`** — the three accessors + the warning banner. No schema change,
  no repository logic change, no calculation change.

## Deliberate limit — what was NOT changed, and why
~20 other places still read `MockRepository.dealers` raw. They were each looked at:
- **Legitimate, left as-is**: single-record lookup by id (`InvoiceDocumentScreen`,
  `StructuredExports`, `DealersScreen` line ~1842), QR/code resolution (`CodeRegistry` —
  access is re-checked afterwards in `UniversalScannerScreen` via `visibleDealerIds`), the
  dealer's own portal (`DealerLoginScreen`, `DealerHomeScreen`, `DealerStockScreen`), and
  `TerritoryOverviewScreen` / `PartyStatementScreen`, which already scope correctly by hand.
- **Left as-is on purpose, needs the person's decision**: KPI/analytics surfaces —
  `MainDashboardScreen`, `SuiteHomeScreen` (×3), `LedgerScreen` (×2),
  `CreditAndBillingScreen` (×2), `ReportsScreen`, `MarketAnalysisScreen`, `BoardroomScreen`,
  `NotificationsScreen`, CRM's performance ranking. Scoping these would change **numbers the
  person already sees on screen** (e.g. total outstanding due), and the standing rule is no
  business-calculation changes unless explicitly asked. Flagged, not silently changed.

## One behaviour change that IS shipped — stated openly, easy to revert
`SalesChainScreen`'s mini-dashboard "Due" stat and `DealerInvoiceTab`'s
`totalOutstandingDue` now sum the **scoped** dealer list, because they share the same
`dealers` variable that had to be scoped to fix the picker. For Chairman/MD/GM (branch 3)
nothing changes. For an SR/TSM these figures now show his own territory instead of the whole
company. That is the fail-safe direction and matches the intent of Decision 4, but it is a
visible number change and the person should confirm. Reverting is a two-line change (keep a
separate unscoped `dealersForMini`).

## Mistakes / corrections during this batch
- First pass replaced the DealersScreen inline scoping without checking what else used its
  locals — `isScopedEmpty` at line ~1264 was left referencing deleted variables. Caught by
  the post-edit grep, fixed. This is exactly why the grep-after-every-edit rule exists.
- Nearly shipped the `dealers.first()` crash: scoping the list turned a latent
  `NoSuchElementException` into a reachable one. Found by reading every use of the variable
  being changed rather than only the line being changed.

## Next work
Decision 3 (**CRM redefinition** — HQ/Chairman → dealer/retailer promotional notices,
discounts, extras, replacing the sales-pipeline CRM) is the next item and is **large enough
to need scope confirmation before any code**, per the person's own instruction. Decision 3's
RMS/HRM items (§4, §5 of the continuation prompt) follow it. Also still open from v113-72:
`CorrectionRequest` has repository support and no UI at all.

# ============================================================
# v113-74 — MOTHER MODULES: DMS + RMS BUILT ON A SHARED DRAWER SHELL
# ============================================================
Date: 2026-08-05. First batch of the six-mother-module restructure, built from the
person's hand-drawn DMS and RMS drafts plus his spoken corrections in the same session.

## Build status
Gradle build **NOT RUN** (no network, no `gradle-wrapper.jar`). Done instead: duplicate-
declaration grep for all 14 new top-level names (all 1), signature/field verification
against the real source for every composable and model field used, and a project-wide
balance sweep diffed against pristine v113-71 — all deltas zero. **The person is
compiling this himself.** No compile success claimed.

## The rule this implements (person's own words, condensed)
- Home Dashboard shows exactly six mother modules: DMS, RMS, HR, FMS, Chairman, AI.
- Entering one opens a **left drawer** listing only that module's options. Picking an
  option **closes the drawer**, so the option gets the full screen — that is the whole
  point ("phone er display ta onek boro pabo").
- One module's drawer never shows another module's items. To switch, go back Home.
- Options differ per module; only the shell is shared.

## Files added
1. **`core/ModuleDrawerScaffold.kt`** — the shared shell (`ModuleDrawerScaffold`,
   `ModuleDrawerItem`, `ModuleDrillRow`, `NotBuiltYet`). One shell, six modules, so the
   navigation behaviour can't drift between them. Drawer body is a plain scrolling Column,
   not a LazyColumn — 8–11 items, where a lazy list costs more than it saves at 90–120Hz.
2. **`ui/dms/DmsHomeScreen.kt`** — 11 drawer items: Dashboard, Invoice, Ledger,
   Message/CRM, Stock, List, Approve, Logistic, New Dealer Add, Finance, Complain.
3. **`ui/rms/RmsHomeScreen.kt`** — 10 drawer items: Dashboard, Order (Memo), Relation,
   List, Retailer Add, Retailer Stock, Complaint, Finance, Approvals, Report.

## Draft items deliberately NOT built as UI, on the person's instruction
QR Center, Universal Features, Cascade & Geo Rule appear as cards in the RMS drawing but
he corrected this directly: those are back-end logic (QR resolve, permission scope,
sync), so there is nothing to display and nothing was displayed. Settings and Help &
Support dropped from the RMS sidebar as unnecessary. Complain **added** to DMS at his
request (the drawing didn't have it). Retailer Stock **added** to RMS at his request.

## Hosting, not duplicating
Where an option already exists as working code, the new module hosts that exact
composable. Seven functions were changed from `private` to `internal` for this
(`DealerInvoiceTab`, `SalesOrderTab`, `AsmVerifyTab` in SalesChainScreen;
`DirectoryTab`, `CollectionsTab`, `AddDealerForm`, `OutletsTab`, `AddRetailerForm`,
`DealerDetailPanel`, `RetailerDetailPanel` in DealersScreen). Visibility only — no logic,
no signature, no schema change. Writing second copies would have meant two places to fix
every future bug, against the standing one-home-per-feature rule.

## Honest placeholders instead of fake screens
`NotBuiltYet` renders a plain statement of what's missing and why. Used for: DMS
Message/CRM and Complain (both blocked on the CRM redefinition, Decision 3), RMS
Retailer Stock, Retailer Complaint, Retailer Finance, Relation and Report. These are real
gaps found by reading the source, not guesses:
- **Retailer stock does not exist in this codebase at all.** `dealerStockLinesFor` exists;
  there is no retailer-stock entity, DAO or flow. Building it needs a Room table, i.e.
  v73 → v74 additive migration — deliberately its own batch so the migration gets tested
  properly, given none of v68→v73 has been verified on a device with real data yet.
- **`CustomerComplaint` is dealer-hardwired** (`dealerId`/`dealerName` as fixed fields, no
  retailer field). Retailer complaints need a model change, so same schema batch.
- The four stock worlds are now settled per the person: **Dealer / Retailer / Factory /
  Warehouse**, mutually independent. Factory and Warehouse get split out of today's
  `InventoryScreen` when FMS is built.

## Not enforced yet — stated in the UI, not hidden
RMS Approvals shows a visible warning that the "only that geo area's TSM approves" rule
is **not** in the code yet. `AsmVerifyTab` has no role gate of its own; adding one changes
approval permissions, which is business logic and needs its own deliberate change.

## Home Dashboard — partial on purpose
`MotherModuleGrid` was added to `MainDashboardScreen` with all six modules; DMS and RMS
navigate, the other four render as "শীঘ্রই" and are not clickable. **The old dashboard
content below it was left in place.** Removing it now would strand every screen that
HR/FMS/Chairman/AI have not absorbed yet. Stripping the Home Dashboard down to only the
six is the *last* step of this restructure, not the first.

## Still owed, in order
1. Schema batch: retailer stock table + retailer complaint model (v73 → v74, additive).
2. Correction/fix flow UI — the person asked for a way to fix a wrong invoice or memo.
   `CorrectionRequest` + `submitCorrectionRequest`/`chairmanApproveCorrection` already
   exist in MockRepository with **no UI anywhere**; this is surfacing, not new backend.
3. Gift item / gift entry — appears in both drafts, exists nowhere in the models.
4. TSM geo role gate for retailer memo approval.
5. CRM redefinition (Decision 3) — unblocks DMS Message/CRM + Complain and RMS Relation.
6. HR, FMS, Chairman, AI modules — drafts not yet supplied.
7. Final step: strip Home Dashboard to the six mother modules only.

# ============================================================
# v113-75 — RETAILER STOCK + RETAILER COMPLAINT: BOTH RMS GAPS CLOSED
# ============================================================
Date: 2026-08-05. Finishes the two items v113-74 left as `NotBuiltYet` placeholders,
per the person's instruction not to carry pending work into the HR/FMS/Chairman/AI
batches.

## Build status
Gradle build **NOT RUN** (no network, no `gradle-wrapper.jar`). Done instead:
duplicate-declaration grep for every new name (all exactly 1 — including the two new
migration `val`s, checked separately since the first grep pass missed `val`
declarations), a project-wide balance sweep diffed against pristine v113-71 (all
deltas zero), and every field/type used (`Retailer.market: String?`,
`RetailOrder.retailerId: String?`, `PartyType.RETAILER`, etc.) verified against the
real model before use, not assumed. **Compiling is the person's job.**

## Room: v73 → v75, two additive migrations
Both follow the exact shape of the two most recent real migrations (`MIGRATION_71_72`,
`MIGRATION_72_73`) as templates — same style, same guarantees:
- **`MIGRATION_73_74`** — `CREATE TABLE retailer_stock_lines`, new and empty, nothing
  existing touched. Structurally identical to `dealer_stock_lines` (`MIGRATION_72_73`).
- **`MIGRATION_74_75`** — three `ALTER TABLE customer_complaints ADD COLUMN` statements
  (`partyType TEXT NOT NULL DEFAULT 'DEALER'`, `retailerId TEXT`, `retailerName TEXT`).
  Every existing row gets `partyType='DEALER'` and null retailer fields on upgrade —
  exactly what it already was, so no existing dealer complaint changes shape or meaning.
No destructive migration fallback used, matching the project's standing rule.

## Retailer Stock — built to mirror Dealer Stock exactly, one real difference stated
`RetailerStockLineEntity` / `RetailerStockLineDao` / `MockRepository.retailerStockLinesFor`
/ `adjustRetailerStockLine` are structural mirrors of the dealer versions. Two write
hooks, found by reading the existing dealer-side hooks and mirroring them exactly:
- **`advanceOrder(..., FULFILLED)`** already decrements the fulfilling dealer's stock
  (goods leave the dealer). Now, when the order carries a real `retailerId` (not every
  order does — anonymous/legacy orders have none, and are skipped rather than guessed
  at, same rule the dealer table already follows for its own gaps), the same structured
  line items **increment** that retailer's stock — goods arriving is the mirror image of
  goods leaving.
- **`approveSalesReturn`'s `PartyType.RETAILER` branch** previously only fixed the
  retailer's due balance (a real gap from v87, per the code's own comment) and had no
  stock effect at all, because there was no retailer stock to affect. It now decrements
  retailer stock lines exactly like the `DEALER` branch already does for dealer stock.

**`RetailerStockScreen`** mirrors `DealerStockScreen` visually, but does not show a
"Total Units (trusted aggregate)" card — `Retailer` has no such field (confirmed by
reading the model; `Dealer.stockUnits` has no counterpart). Showing a fabricated total
would look more complete than the data actually is, so the screen states plainly that
the product breakdown is the only figure available and that it is unrelated to dealer
stock, per the person's explicit instruction.

RMS's "Retailer Stock" drawer item now hosts a real retailer picker
(`RmsRetailerStockPicker`) that navigates to a new `retailer_stock/{id}` route.

## Retailer Complaint — additive fields, not a rewrite
`CustomerComplaint`/`CustomerComplaintEntity` gained `partyType` (default `DEALER`),
`retailerId`, `retailerName` — all additive with defaults, so every existing dealer
complaint (model, entity, the one existing call site in `GeoCrmScreen`) is untouched.
New `MockRepository.createRetailerComplaint(...)` mirrors `createCustomerComplaint`
exactly, with `dealerId`/`dealerName` passed as explicit `""` (they have no default) and
the party fields carrying the real retailer identity instead.

**Known shape wart, not hidden:** this keeps parallel `dealerId`/`retailerId` fields
rather than the single generic `partyId`/`partyName` + `partyType` shape this codebase
already uses elsewhere (`PartyCollection`, `SalesReturn`). The generic shape would be
cleaner but means renaming `dealerId`→`partyId` on every existing dealer-complaint call
site for no functional gain — a bigger, riskier change than what was asked. Flagged for
a future cleanup if the person wants it; not done unasked.

RMS's "Complaint" drawer item now hosts a real `RmsComplaintsTab` — same shape as CRM's
`CustomerComplaintsTab`, filtered to `partyType == RETAILER`, with its own "+ New
Complaint" dialog using `rememberVisibleRetailers()` for the chooser (cascade-scoped,
matching Decision 4).

## Deliberately NOT touched this batch, and why
- **DMS's "Complain" drawer item stays a placeholder.** It is a genuinely different
  situation from RMS's: the dealer complaint feature already fully works today, just
  inside `GeoCrmScreen`'s numbered-tab `SubModuleGrid` (tab index 8 of 10). Moving it
  into DMS without duplicating it means either surgically removing and renumbering a
  tab in a screen this batch wasn't asked to touch, or temporarily duplicating it —
  both against the person's explicit "no duplicate" rule. This is exactly the
  relocation Decision 3 (CRM redefinition) already covers, so it stays queued there
  rather than being done as a rushed side-effect of this batch.
- RMS's Finance, Relation, and Report drawer items are unchanged `NotBuiltYet`
  placeholders — the person's instruction was specifically retailer stock and customer
  complaint; these three were not part of that request.

## Next work
HR, FMS, Chairman, AI drafts — waiting on the person. DMS Complain relocation rides
with Decision 3 (CRM redefinition) whenever that's scoped.

# ============================================================
# v113-76 — HR + FMS + CHAIRMAN: ALL FIVE MOTHER MODULES LIVE
# ============================================================
Date: 2026-08-05. Built from the HR, FMS and Chairman draft images plus the person's
spoken decisions in this session. With this batch, all five mother modules exist on the
shared drawer shell (v113-74): DMS · RMS · HR · FMS · CHAIRMAN.

## Decisions recorded (person's explicit words this session)
- **AI is not a top-level module.** It lives inside Chairman ("Ai module sudu chairman
  module er modde thakbe"). The Home grid is FIVE modules, and the Chairman tile only
  renders for the CHAIRMAN role.
- **Chairman Approval Center is the ONE sanctioned exception to Decision 2** ("1 no
  numberta"). Everyone else still approves inside the owning module — nothing about
  v113-72's decentralisation changes for any other role.
- **Master Controller = soft-delete view + restore ONLY.** No hard delete exists in
  this app and none was added ("soft delete dekha and restore korara khomota").

## Build status
Gradle build **NOT RUN** (sandbox has no wrapper jar/network). Done instead: duplicate-
declaration grep on all 9 new top-level names (all 1), balance sweep vs pristine
v113-71 (all deltas NONE), and every hosted screen signature / tab index / model field
verified against the source. One real error caught this way before shipping:
`LeaveRequest` has `createdAt`, not `appliedAt` — the first draft of the Chairman
approval list used the wrong name; fixed after checking the model. **Compile is the
person's job.**

## Files added
1. **`ui/hr/HrHomeScreen.kt`** — 11 drawer items. Almost pure hosting:
   Employee List / Attendance / Payroll / Leave / Lifecycle / Employee Add all host
   `PayrollScreen(startTab = 4/0/1/2/3/5)` (indices verified against its `when(tab)`);
   Target hosts `VacancyTargetCenterScreen` (the target system already fully exists
   there — Decision 3 §5's "target fixing moves into HRM", done by hosting); Complain
   Box hosts `ComplaintBoxScreen`. Dashboard is a compact stat card — deliberately NOT
   `PayrollScreen(startTab = null)`, which would render the old full module dashboard
   inside the drawer, the exact clutter v113-71 removed. Performance and HR Reports are
   honest `NotBuiltYet` (performance is tangled with CRM's PerformanceTab → Decision 3).
   The draft's card 9 (HR-Factory) is deliberately NOT a drawer item here — factory HR
   lives in FMS, listing it in both modules would break one-home-per-feature.
2. **`ui/fms/FmsHomeScreen.kt`** — 11 drawer items. This is where the person's
   four-stock-world rule lands for the company side: Factory pipeline = ProductionScreen
   (Raw Material tab 0, Production Orders 4, QC 5, Factory HRM 2) + PurchaseScreen
   (GRN, startTab 2); Warehouse pipeline = InventoryScreen (Levels 0, Damage 6);
   Send-to-Warehouse = ProductionWarehouseScreen (Transfers, tab 1). All indices
   verified. Combined one-page factory report = `NotBuiltYet`.
3. **`ui/chairmanmodule/ChairmanHomeScreen.kt`** — 13 drawer items, role-gated at the
   door (non-chairman sees a refusal, not the option list) with every hosted action
   still re-checked in the repository (defense in depth).
   - **Approve Center** (`ChairmanApprovalCenter`) — the sanctioned exception. Reuses
     `ModuleApprovalSection` with the complete entityType set from v113-72's call-site
     trace (SalesInvoice/Expense/Voucher/Payroll/AttendanceRecord) plus "" for the older
     `requestApproval` path (default verified in `ApprovalRequestEntity`). Pending
     LeaveRequests actioned via the same `setLeaveStatus` HRM uses. Pending invoices
     shown as a COUNT pointing at DMS, deliberately not actionable here: approving an
     invoice blind from a list hides the totals/due/timeline context the approval
     exists to check. No new write path anywhere — audit trail identical.
   - **Master Controller** (`ChairmanMasterController`) — lists soft-deleted records
     per type and offers Restore. Only types that BOTH carry isDeleted AND have a real
     repository restore function are listed (Invoice, Dealer, Retailer, Product,
     Supplier, Task — each verified); types with soft delete but no restore function
     are omitted rather than given a fake button. Every restore is the existing
     permission-checked function; denial renders a visible "blocked at repository
     layer" line.
   - **AI** hosts `BoardroomScreen`. Dashboard hosts `ChairmanHubScreen`. Ledger /
     Reports / Company Setup / Business Rules / Permission Control / Audit / Backup all
     host their existing admin screens. Notice Board = `NotBuiltYet` (no direct
     chairman→employee notice feature exists; Communication Hub's announcements live in
     the Workspace suite — relocation rides with Decision 3).
4. **NavGraph** — `hr_module`, `fms`, `chairman_module` routes (`hr` was taken by the
   old HRM route; kept untouched so nothing breaks before the final strip-down).
5. **MainDashboardScreen** — MotherModuleGrid now five live modules; Chairman tile
   role-gated.

## Known gaps carried forward, stated not hidden
- ProductionScreen's Batches / BOM / Loss / Machine tabs have no FMS drawer item yet
  (drafts didn't name them individually). They stay reachable through the old suite
  navigation, which is still present by design until the final Home-strip-down batch.
- Old suite/dashboard navigation still fully present (deliberate — final step remains
  stripping Home to the five modules once the person confirms everything's reachable).
- Still queued from before: CRM redefinition (Decision 3) which unblocks DMS
  Message/Complain, RMS Relation/Finance/Report, HR Performance/Reports, Chairman
  Notice Board; TSM geo gate for memo approval; gift entry; CorrectionRequest UI.

## Mistakes / corrections during this batch
- `l.appliedAt` → `l.createdAt` (wrong field name caught by model verification).
- First HR dashboard draft hosted the full PayrollScreen dashboard — replaced with a
  compact card after re-reading the person's clutter rule.
- FMS Purchase first hosted `startTab = null` (full sub-dashboard) — changed to the GRN
  tab for the same reason.

# ============================================================
# v113-77 — GAPS CLOSED + THE CLEAN HOME. RESTRUCTURE COMPLETE.
# ============================================================
Date: 2026-08-05. The person's instruction: finish everything still pending, then he
compiles. Plus his final Home spec, verbatim intent: "main dashboard e akn sudu 3 ta
notice slot ar 5 ta module show korbe. Echara ar head e ager motoei search and qr
button thakbe. Akdm nit n clean UI."

## Build status
Gradle build **NOT RUN** (sandbox limitation, unchanged). Duplicate-declaration grep on
all 10 new/renamed top-level names (all 1), balance sweep vs pristine v113-71 (NONE),
and every field/signature verified in source before use (`EmployeePerformance`'s seven
fields, `createCollection`, `broadcastCampaign`, `createNotification`,
`UniversalSearchDialog`, `NotificationEntry.createdAt/isRead`,
`CorrectionRequestStatus` states — all checked, none assumed). **The person compiles.**

## The new Home (`ui/home/HomeScreen.kt`)
Exactly his spec and nothing else: header (brand + Search opening UniversalSearchDialog
+ QR opening the universal scanner), THREE notice slots (unread-first, newest-first,
tap → Notifications), FIVE module tiles (Chairman tile role-gated). Every old widget
(KPIs, trends, quick actions, alerts) is gone from Home — that data lives inside its
module now. `MainDashboardScreen` stays in the tree **un-routed**, not deleted: its
private widgets are reuse candidates for module dashboards, and deleting 61KB of
working code in the same batch as the navigation swap would make any compile error
ambiguous. Deleting it is a one-line follow-up after on-device confirmation.

## Gaps closed this batch
1. **DMS · Message/CRM** — new shared `core/PartyCampaignSection` (Decision 3's actual
   definition: HQ → dealers/retailers, offers/due/notices), backed entirely by the real
   `broadcastCampaign`/`campaigns` system with its honest sentCount. Zones come from the
   cascade-scoped dealer list, so nobody broadcasts outside their territory.
2. **DMS · Complain** — `CustomerComplaintsTab` relocated whole from GeoCrmScreen (made
   internal, hosted by DMS). CRM's grid tile removed; CRM tab index 8 kept as a redirect
   note so old deep links degrade gracefully instead of opening the wrong tab. One
   implementation, one home.
3. **RMS · Relation** — same `PartyCampaignSection`, retailer markets as zones.
4. **RMS · Finance** — retailer-only due list + today's collection + New Collection via
   the existing `createCollection(PartyType.RETAILER, …)` write path (same verification/
   ledger/audit as everywhere else). **Gift entry deliberately NOT included**: the drafts
   show it but its financial semantics (reduce due? ledger post? approval?) were never
   defined, and inventing money rules unasked is exactly what the standing rules forbid.
   One question to the person unlocks it.
5. **RMS · Report** — retailer-scoped month report (memo count/amount, visits, due, top
   5 retailers), computed from already-scoped lists.
6. **RMS · Approvals — the TSM geo gate is now REAL.** Chairman sees all; a TSM sees
   only orders whose zone matches his own directory geo (market/district/division/
   zoneDivisions, case-insensitive contains both ways since order.zone is free text);
   every other role gets a read-only explanation. This is the "geo rule wise oi arear
   tsm ei korbe" instruction, implemented.
7. **HR · Performance** — hosts the real `computeEmployeePerformance` engine (Foundation
   2 §16 — coverage, 90d sales/collection, efficiency, visit compliance), which existed
   with no UI. Employee list is cascade-scoped.
8. **HR · Reports** — one-page month summary from existing flows.
9. **Chairman · Notice Board** — direct notice via the existing `createNotification`
   pipeline (null target = broadcast, or one employee). No new delivery mechanism.
10. **Chairman · Correction Requests** — first-ever UI for the long-dormant correction
    backend, inside the Approval Center: SUBMITTED → Review ✓ (`managerReviewCorrection`),
    MANAGER_REVIEW → Approve & Apply (`chairmanApproveCorrection`, the real
    reversal-and-repost), Reject with reason. The submit side already existed in
    UniversalActionMenu — only review was missing.

## Deliberately still open (each needs the person, not code)
- **Gift entry** — needs the financial rule (see #4).
- **FMS Batches/BOM/Loss/Machine** as individual drawer items — reachable today via FMS →
  Production's own navigation; drafts didn't name them as separate cards.
- **Old MainDashboardScreen deletion** + retiring the legacy suite routes — after the
  person confirms the new Home and all five modules on a real device.
- FMS combined one-page factory report (the batch's one remaining NotBuiltYet).

## Mistakes / corrections during this batch
- A tool-retry left partial phantom edits in several files mid-batch (GeoCrm/DMS/RMS had
  a half-applied state with a `PartyCampaignTab`≠`PartyCampaignSection` name mismatch
  that would not have compiled). Caught by re-reading every touched file end-to-end and
  grepping for the dead name; core file renamed to match, zero references remain.
- Unused `NotBuiltYet` imports left behind by the wiring were swept; FMS's (still used)
  was restored after the sweep over-removed it.

# ============================================================
# v113-78 — PRE-COMPILE REVIEW: FULL RE-READ OF EVERY TOUCHED FILE
# ============================================================
Date: 2026-08-05. The person is compiling at 11am; asked to fix as much as possible
before then. This batch is a dedicated review pass — no new features, no drafts —
re-reading every file touched since v113-72 end-to-end (not just the diffs) and
verifying every symbol against source, specifically hunting for the kind of bug a
balance-sweep and a duplicate-grep cannot catch: wrong field names, stale filters,
cross-contamination between record types sharing a table.

## Real bugs found and fixed
1. **DMS's dealer complaint list would have shown retailer complaints too.**
   `CustomerComplaintsTab` (hosted in DMS since v113-77) filtered `customerComplaints`
   with no `partyType` guard. Since v113-75 added `createRetailerComplaint`, which
   writes into this same collection, RMS's retailer complaints would have leaked into
   DMS's dealer-only list — the exact kind of cross-module data leak the whole
   restructure exists to prevent. Fixed: filter now requires
   `partyType == PartyType.DEALER` explicitly.
2. **RetailerDetailPanel's "Complaints" and "Overview" tabs were silently, permanently
   empty** — pre-existing, from before v113-75. They filtered
   `it.dealerId == retailer.id`, which could never match: nothing ever wrote a
   retailer's id into the `dealerId` field. This predates my work, but v113-75's new
   `retailerId` field makes it trivially fixable, and it is directly downstream of the
   retailer-complaint feature I built, so it was fixed rather than left: both now
   filter on `partyType == RETAILER && retailerId == retailer.id`, the real field.
3. **`ApprovalRouting.kt` pointed at legacy suite routes** (`sales?tab=2`, `hrm?tab=1`)
   instead of the new drawer modules those features actually moved into. Not a compile
   error — the legacy routes still exist and still work — but stale UX after the
   restructure. Repointed to `dms?key=invoice`, `hr_module?key=payroll`, etc., using
   each module's real drawer key (verified against DMS/HR's own `ModuleDrawerItem`
   lists). Two entries (`Expense`, `Voucher`) deliberately left on their legacy routes
   and commented as such — FMS/Chairman have no drawer item for those yet, so pointing
   there would be a dead end worse than the working legacy screen.
4. **`ModuleDrawerScaffold` used `HorizontalDivider()`**, an API never otherwise used
   anywhere in this ~230-file project (everywhere else uses `Divider()`). Almost
   certainly fine on this BOM, but "almost certainly" is not a standard worth keeping
   hours before a compile — switched to the proven `Divider()` already used 8 other
   places in this codebase, eliminating the risk entirely rather than trusting it.

## What was re-verified with no issue found (for the record, not because anything was
## wrong, but because each was a real risk worth checking)
- Every hosted screen's actual parameter names against its real `fun` signature:
  `DealerInvoiceTab`, `CollectionsTab`, `AddDealerForm`, `DirectoryTab`, `OutletsTab`,
  `AddRetailerForm`, `ProductionScreen`, `ProductionWarehouseScreen`, `InventoryScreen`,
  `PurchaseScreen`, `PayrollScreen`, `LedgerScreen`, `ReportsScreen`,
  `ChairmanHubScreen`, `EmployeeSetupScreen`, `BackupRecoveryScreen`,
  `VacancyTargetCenterScreen`, `ComplaintBoxScreen`, `BoardroomScreen` — all match.
- Every model field used across the five modules against `Models.kt`:
  `Retailer.market/dueBalance`, `Dealer.zone/dueBalance`, `RetailOrder.retailerId`,
  `PartyCollection.amount/createdAt/partyType`, `AppUser.employeeId`,
  `EmployeeProfile.fullName/department`, `PayrollLine.basePay/commission/overtimePay`
  (`commission` is a computed property, not a stored field — confirmed, not assumed),
  `LeaveRequest.createdAt` (not `appliedAt` — this one was already caught and fixed in
  v113-76; re-verified here, still correct), `VisitLog.checkInAt/partyType`,
  `CorrectionRequestStatus`'s four relevant states.
- `GeoScope`'s fields for the TSM geo-gate (`market/district/division/zoneDivisions`)
  match `OrgDirectory.kt` exactly, and the doubled `if (startTab == null) if (startTab
  == null)` line near `RouteAuditTab` was checked against the pristine v113-71 ZIP —
  confirmed pre-existing, not something introduced this session, left untouched.
- Full project-wide balance sweep (brace/paren/bracket) across all 127 touched `.kt`
  files, diffed against the pristine v113-71 extraction: zero deltas.
- Duplicate-declaration grep for every top-level name introduced since v113-72: all
  exactly 1.

## Still true, unchanged
Gradle **was not run** — this remains a sandbox with no wrapper jar and no network.
Everything above is static review, not a build. The person compiles at 11am and this
batch is aimed at maximizing the odds that compile succeeds cleanly, not a substitute
for it.

# ============================================================
# v113-79 — NEW STANDING ARCHITECTURE RULE: WORKSPACE CONTRACT
# ============================================================
Date: 2026-08-06. Doc-only batch. The person issued a new, top-priority architecture
rule. Recorded here as the standing contract so every future session acts on it.

## The rule (condensed, faithful)
1. **A module is NOT complete because a screen exists.** Complete = every feature on
   the approved five posters implemented with real data, real workflow, Firebase sync,
   QR integration, role/cascade/geo permissions, reports, graphs, history, approvals,
   production-ready UI. The five posters are the functional contract — 100%, not
   approximated.
2. **One business operation = ONE full-screen professional workspace.** No page
   chains, no navigation away mid-task. Example: DMS Invoice opens ONE workspace
   containing dealer search/QR/add, latest ledger, outstanding due, credit limit,
   history, financial summary, product search/category/QR/add, gift, offer, discount,
   damage, return, stock availability, invoice summary, approve, invoice-QR generate,
   print, share, universal menu — all inline. Helper actions may be sheets/dialogs
   only. Same rule for: Retail Order, Collection, Expense, Purchase, Warehouse
   Transfer, Production Order, Payroll, Attendance, Leave, Dealer/Retailer/Employee
   Registration, Factory Production.
3. **QR deep integration:** scanning any entity QR (dealer/retailer/employee/product/
   carton/invoice/warehouse) auto-fills that entity, auto-loads its ledger/due/credit,
   runs geo validation and role permission. No manual search when QR identifies.
4. **Enterprise UI everywhere:** large header, professional cards, soft spacing,
   modern typography, premium KPI, universal menu, cascade/geo/role, Firebase + offline
   sync, audit log — inside the workspace.
5. **Do NOT redesign business logic. Do NOT duplicate workflows. Reuse existing
   engines; only reorganize into workspaces.**

## Honest current-state assessment against this contract
The v113-74..78 drawer modules are **hosting shells** — they reorganized existing
tabs, which was what was asked then. Against THIS contract, **no module is complete**:
e.g. the Invoice drawer item hosts DealerInvoiceTab, which has no inline dealer-QR
autofill, no gift/offer, no inline ledger/history panel. The drawer restructure stands
(it is the entry layer); the workspace conversion is the next major phase, per
operation, reusing the same engines.

## Proposed build order (needs the person's confirmation)
1. **DMS Invoice Workspace** first — the person's own example; becomes the reference
   pattern, exactly as Dealer Invoice approval once was for Decision 2.
2. Then Retail Order (Memo) Workspace, then Collection, then the rest in his order.
Blockers unchanged: gift needs its financial rule defined before it can be inside any
workspace; posters don't individually cover some listed workflows (Expense, Purchase,
Payroll workspaces) — pattern will be extrapolated from the DMS Invoice reference
once approved.

## Compile baseline
v113-78 remains the 11am compile baseline. Workspace conversion starts AFTER the
baseline compiles, so build errors stay attributable.

# ============================================================
# v113-80 — WORKSPACE CONTRACT PHASE 1: DMS INVOICE + RMS MEMO WORKSPACES
# ============================================================
Date: 2026-08-06. First two implementations of the v113-79 workspace contract, built
before compile at the person's instruction ("age tumi motamuti full kaj gula ses koro").

## NEW `ui/dms/DmsInvoiceWorkspace.kt` — the reference implementation
ONE screen, whole invoice operation: code/QR entry (CodeRegistry.resolve; DEALER
autofills the dealer slot with a cascade re-check — a resolved dealer outside the
viewer's visible set is refused, since resolve() reads the raw registry; PRODUCT drops
into the cart), dealer search + New Dealer dialog (hosts the existing AddDealerForm),
dealer financial context (due / credit limit / available credit / invoice history
count+total), Full-Ledger link, Damage/Return sheet (thin UI over createSalesReturn —
its qty validation/restock/due logic untouched), product search + category chips +
live stock from stockLevels, cart with qty steppers, Offer chips from the real
DiscountRule flow (tap → fills discount %), discount/commission/courier, Gift chip
present but DISABLED with the honest reason (financial rule still undefined), live
summary with over-credit warning (engine still enforces the actual approval routing),
create via createSalesInvoice (permission-gated, double-submit-guarded), and the
dealer's invoice history inline with ✓ Approve (approveSalesInvoice) and Print/Share →
invoice_doc. No engine changed; arrangement only.

## NEW `ui/rms/RmsMemoWorkspace.kt`
Same pattern, retailer side: retailer QR/search with cascade re-check, due/credit/memo
history, product+stock, memo summary with over-credit note, create via logNewOrder now
passing the REAL retailerId, retailer's memo history inline (matched by linked id, by
name only for pre-link legacy memos). Old free-text RetailerTab still serves the
legacy Sales suite until strip-down — one engine, two arrangements, zero duplicated
logic.

## REAL BUG FIXED — found by building the workspace, not by a compiler
`MockRepository.logNewOrder` NEVER wrote `retailerId`: the entity column existed since
the Data Design step, `RetailOrder.retailerId` existed, `advanceOrder`'s v113-75
retailer-stock increment keyed on it — but no writer ever set it, so **every
app-created memo had retailerId = null and the v113-75 retailer-stock pipeline could
never fire on the main path.** Fixed additively: `retailerId: String? = null`
parameter (every existing caller unaffected), stored into the entity. The memo
workspace passes the real id, completing the memo → FULFILLED → retailer-stock chain
end to end for the first time.

## Also this batch
- DMS "Invoice" drawer item now opens the workspace; DMS "Approve" no longer hosts a
  second copy of the invoice list — ApprovalRequest rows stay, plus a pending-invoice
  count pointing at the workspace (one implementation of invoice-approve, in context).
- RmsHomeScreen's now-unused salesVm/draft/lastAgentAction locals removed.
- Two of my own compile errors caught in self-review before they ever reached the
  person: `com.abm.erp.data.CodeType` → `CodeRegistry.CodeType` (nested enum), and a
  malformed `.androidx.compose...verticalScroll` modifier chain + missing
  `kotlinx.coroutines.launch` import in the return sheet.

## Contract status after this batch (honest)
DMS Invoice and RMS Memo now MEET the workspace contract's shape. Everything else on
the contract's list (Collection, Expense, Purchase, Warehouse Transfer, Production
Order, Payroll, Attendance, Leave, three Registrations, Factory Production) does NOT
yet — those remain hosted screens. Gift stays blocked on its financial rule. Balance
sweep vs pristine: NONE; duplicate grep: all 1. Gradle still not run — compile when
the person says.

# ============================================================
# v113-81 — MOCKREPOSITORY SPLIT (PHASE 1) + COLLECTION WORKSPACE
# ============================================================
Date: 2026-08-06.

## MockRepository split — what was actually done, and what deliberately was not
The person asked for the split now ("mock repository file e sobkisu rakhle pore alada
korte problem hote pare"). Done, honestly scoped:
- **NEW `data/MockRepositoryMappers.kt` (1,124 lines)** — all ~65 entity↔domain mapper
  extension functions that sat below the object's closing brace, moved mechanically.
  File-`private` → `internal` (they're now called from another file in the same
  module); same package, so all 306 call sites inside the object and `isWeakPin`'s two
  external callers are untouched. MockRepository.kt: 10,422 → 9,386 lines, ending
  exactly at the object's closing brace. Import block copied wholesale (unused-import
  warnings possible, never errors).
- **NOT done, on purpose:** splitting the object's business-logic groups into separate
  repository objects. The StateFlows/DAOs/sync-listeners are interlocked; that's real
  re-architecture, and doing it in a rush right before first compile would make every
  build error unattributable. The mappers were the one cleanly separable piece.
  Recommended next split candidates once the build is green: Collections/Ledger group,
  Approval group, HR group — each behind its own object with MockRepository delegating,
  one group per batch, compiled between each.

## NEW `core/CollectionWorkspace.kt` — workspace contract, third implementation
Shared by DMS·Finance (DEALER) and RMS·Finance (RETAILER) — one component, two hosts.
Party QR/code autofill (type-checked against the host's party type, cascade re-checked
against the host's scoped list), top-due suggestions, due + ledger link, method chips
(the four the model documents), amount with over-payment notice (books as advance —
that's what the engine already does), create via `createCollection` (dual-control
preserved: PENDING until a permission-holder verifies), and the party's collection
history inline with Verify/Reject via the real `verifyCollection`/`rejectCollection`.
`RmsFinanceTab` (v113-77) removed — superseded, not duplicated. DMS Finance no longer
hosts `CollectionsTab`; that tab still serves the legacy Dealers screen.

## Contract scoreboard (honest)
MEETS the workspace shape: DMS Invoice · RMS Memo · Collection (both modules).
DOES NOT yet: Expense, Purchase, Warehouse Transfer, Production Order, Payroll,
Attendance, Leave, the three Registrations, Factory Production — still hosted screens.
Gift still blocked on its undefined financial rule. "100% workable" cannot be claimed
by anyone until Gradle runs — balance sweep NONE, duplicate greps all 1, every engine
signature verified in source; the compile is the arbiter.

# ============================================================
# v113-81b — MOCKREPOSITORY SPLIT PHASES 2 & 3: COLLECTIONS + APPROVALS ENGINES
# ============================================================
Date: 2026-08-06, same session. The person asked for the remaining split phases now.

## The mechanism (why call sites didn't change)
Kotlin has no partial classes, but `MockRepository.x()` resolves identically whether
`x` is a member or a same-package **extension function on the object**. The object
already exposes internal bridges built for exactly this (`database` → db,
`launchInRepoScope` → scope.launch, `qrSyncCollection` → syncCollection — the QR
split's pattern). So each group was cut out, de-indented, `fun X` → `fun
MockRepository.X`, and the three private-member accesses rewritten to the bridges.
Function BODIES otherwise untouched. Every call site — UI and inside the object —
is textually identical to before.

## Phase 2 — `data/CollectionsEngine.kt` (175 lines)
createCollectionWithMultipleAllocations, createCollection, verifyCollection,
rejectCollection. One mechanical hazard found and fixed: `return@launch` labels break
when the lambda becomes `launchInRepoScope { }` — all rewritten to
`return@launchInRepoScope` (the `return@withTransaction` labels were fine).
Dual-control, period-close guard, online-only verify, allocation-transaction: as-is.

## Phase 3 — `data/ApprovalsEngine.kt` (273 lines)
requestApproval, setApprovalStatus, advanceApproval (the full cascade-level engine),
overdueApprovals, pendingApprovalSlaItems, checkAndNotifySlaBreaches,
escalateApproval, forwardApproval, reassignApproval, private slaTierFor. Three
declarations rode along because they belonged to nobody else (verified by grep):
`private val CASCADE_CHAIN`, the SLA-dedup `slaLastNotifiedTier` map, and the
formerly-nested `SlaTier` enum + `PendingApprovalSlaItem` data class — those two are
now top-level in the same package, and the ONLY external references
(`MockRepository.SlaTier.*` in BoardroomScreen, 5 lines) were repointed. Callers
verified: `ApprovalSlaWorker.MockRepository.checkAndNotifySlaBreaches()` — unchanged
and resolves against the extension.

## State of the split, honestly
MockRepository.kt: 10,422 → **8,977 lines** across four files (Mappers 1,124 ·
CollectionsEngine 175 · ApprovalsEngine 273). Remaining large groups (Corrections
engine ~270 lines with the reversal logic, HR/leave/payroll, invoice/order chain) are
still in the object — each is the same mechanical recipe now that it's proven twice,
but chairmanApproveCorrection's reversal engine deserves its own careful batch, not a
rushed one. Balance sweep vs pristine: NONE. Duplicate greps: all 1. Compile remains
the arbiter; when it runs, any error in these two new files is isolated by
construction to the mechanics (labels/bridges), never to business logic.

# ============================================================
# v113-81c — MOCKREPOSITORY SPLIT PHASE 4: CORRECTIONS/REVERSAL ENGINE
# ============================================================
Date: 2026-08-06, same session.

## NEW `data/CorrectionsEngine.kt` (309 lines)
submitCorrectionRequest, managerReviewCorrection, chairmanApproveCorrection (the full
per-module reversal engine — invoice due/status REVERSED/CORRECTED, collection status,
attendance, dealer/retailer soft-delete/edit, productionPlan CANCELLED, warehouse
transfer, payroll), chairmanRejectCorrection, and the five private `applyFieldChange`
overloads (verified via grep to have no caller outside this group before moving — they
rode along whole rather than being left orphaned). Same recipe as Phases 2-3: extension
functions on MockRepository, `db`→`database`, `scope.launch`→`launchInRepoScope`,
`syncCollection`→`qrSyncCollection`, `return@launch`→`return@launchInRepoScope`.
External callers checked and unaffected: `ChairmanHomeScreen`'s Correction section
(v113-77) and `UniversalActionMenu`'s submit path both call
`MockRepository.xCorrection(...)` exactly as before.

## MockRepository.kt: 10,422 → 8,694 lines, across five files
Mappers (1,124) + CollectionsEngine (175) + ApprovalsEngine (273) +
CorrectionsEngine (309) = 1,881 lines extracted this session.

## HONEST FINAL ASSESSMENT — why this is where the split stops for tonight
Checked every remaining `// Section N` marker in the file (46 total) before deciding
this: only four were real top-level section boundaries with contiguous, self-
contained code (Corrections — done; Accounting Period Lock, Central Number Series,
Data Ownership Transfer — each under 40 lines, tightly woven into surrounding code
with no clean seam). All other "Section N" comments are inline design-history notes
scattered across the whole file, not extraction boundaries — HR/Leave (line 7829),
Payroll (5704), Performance (5629) are three separate, non-contiguous locations
with thousands of unrelated lines between them, not one group.

The other ~440 remaining functions split into two real categories:
1. **The Firestore real-time sync engine — 49 `listenXRemote()` functions + 45
   matching `private var XListenerReg` fields**, each field used by exactly one
   listener, all registered/torn down together in `init()`/`forceResync()`/
   `startCrossDeviceSync()`. This is NOT one more business-logic group like the four
   already moved (which had 2-3 shared private helpers at most) — it's 45 pieces of
   tightly-coupled lifecycle state. Extracting it needs either exposing 45 new
   internal fields (defeats the point of the split) or a real redesign into its own
   sync-engine class. That is a legitimate next project, not a mechanical extraction,
   and rushing it hours before the person's first-ever compile of this codebase is
   exactly the kind of decision the standing rules warn against.
2. **The rest of core CRUD/business logic** (dealer, retailer, product, invoice,
   order, HR) — thousands of lines, calling each other constantly, not organized into
   movable sections. Splitting this properly means real repository-per-domain
   architecture with MockRepository delegating, decided deliberately, one domain per
   batch, each compiled before the next — not a rename-and-move pass.

**What "the MockRepository split is done" honestly means right now:** every group
that could be cleanly, mechanically, low-risk extracted — has been. What's left is
either genuine future re-architecture (the sync engine) or the core object itself,
which is supposed to stay the coordinating object rather than be dissolved entirely.
Balance sweep vs pristine: NONE. Duplicate greps: all 1. All four new files' external
callers verified against source.

# ============================================================
# v113-82 — DECISION: MOCKREPOSITORY SPLIT PAUSED HERE; CONTINUED WITH EXPENSE WORKSPACE
# ============================================================
Date: 2026-08-06. Person said "Continue" right after the honest v113-81c stopping-point
explanation. Judgment call made and recorded here rather than silently guessing:

**Did NOT continue splitting MockRepository further.** Surveyed the next candidate
(HR/Leave/Payroll — named in earlier session notes as queued) before touching it: its
functions are scattered across ~20 non-contiguous locations from line 366 to 7878,
interleaved with privilege-escalation fixes (Section 13), geofencing tied to
LocationVerification, and PIN/account-creation flows. This is categorically different
from the four groups already extracted (which sat under clean, contiguous section
comments with 2-3 shared helpers at most). Forcing this split tonight, scattered and
security-adjacent, risks silently breaking something the four clean phases didn't risk
— exactly what "Continue" should not mean hours before the person's first compile.

**Instead continued the OTHER active, explicitly-approved thread: the workspace
contract (v113-79).** Built the fourth implementation:

## NEW `core/ExpenseWorkspace.kt`
Category quick-chips + amount + payment method + description + submit
(`submitExpense` — unchanged, still raises the ApprovalType.EXPENSE request itself),
submitter's expense history inline with Approve/Reject for permission-holders
(`approveExpense`/`rejectExpense` — approval is still the only point that posts to the
ledger, exactly as before). Fills a gap flagged by name since v113-77: no module
had ever hosted Expense; `ApprovalRouting.kt` said so in its own comment.

**New FMS drawer item: "Expense"** (utility/office/transport/maintenance — FMS-typical
operational costs, sits next to Purchase/GRN as the other money-out-of-FMS flow).
`ApprovalRouting.kt` repointed: `"Expense" -> "fms?key=expense"` (was the legacy
`"expenses"` route).

## Workspace contract scoreboard, updated
MEETS the shape: DMS Invoice · RMS Memo · Collection (DMS+RMS) · **Expense (FMS,
new)**. Still hosted screens, not workspaces: Purchase, Warehouse Transfer,
Production Order, Payroll, Attendance, Leave, the three Registrations, Factory
Production. Gift still blocked on its undefined rule.

Balance sweep: NONE. Duplicate grep: 1. `expenses` StateFlow confirmed public.

# ============================================================
# v113-83 — HOME KPI CARD RESTORED (from DMS full-flow reference discussion)
# ============================================================
Date: 2026-08-06. Person shared a new reference image (DMS full flow, 12 screens) and
answered three clarifying questions raised about it.

## Answers recorded as standing rules
1. **Home Dashboard: KPI card is back, notices stay at 3.** Reverses part of v113-77
   ("akdm nit n clean UI" meant no KPI card at all) — person now wants the reference
   poster's "Today's Overview" KPI card kept, with only the notice count trimmed from
   the poster's 5 to 3. Quick Actions row and bottom nav were NOT mentioned as
   returning, so they stay absent — only the KPI card was added.
2. **Module-internal navigation pattern = the reference poster's visual pattern,
   applied to EVERY module** — grouped drawer sections, drill-down List → Details →
   Ledger/Graph/Calendar/Documents (each its own full screen with its own bottom
   toolbar), a dedicated QR ID Card screen, a Custom Filter screen, a universal QR
   Scanner popup, a "More Actions" bottom sheet (Import/Export Excel, Bulk SMS,
   WhatsApp, Print All, Sync, Help). **The actual feature/option list per module stays
   what was already defined from each module's own poster** — the reference's own
   grouping/labels (MASTER/TRANSACTIONS/REPORTS, "Dealer List" etc.) are a visual
   pattern to copy, not a relabeling instruction.
3. **List → Details → Ledger drill-down does NOT violate the Workspace Contract.**
   The person's own reasoning: "List means its full history plus activity, so being
   able to see the ledger is natural." This draws the contract's real boundary: the
   ONE-full-screen-no-navigation-chain rule applies to ACTION/transactional flows
   (Invoice, Memo, Collection, Expense, Payroll, Registration — "do a business
   operation"). Browse/review flows (List, Ledger, reports, calendar, documents) are
   naturally hierarchical drill-downs and are expected to be multi-screen, matching
   the reference poster's own List→Details→Ledger pattern.

## Built this batch
`ui/home/HomeScreen.kt` — added the KPI card (Sales / Collection / Total Due / Stock
Value), computed from real flows: Sales/Collection scoped to today
(SalesInvoice.createdAt / PartyCollection.createdAt+VERIFIED), Total Due = the same
dealer+retailer sum the old dashboard used, Stock Value = Σ(on-hand qty × product's
own defaultUnitPrice) from InventoryRepository. No percentage-change chip shown next
to any figure — the reference poster has one (+12.5% etc.) but this app has no
trusted previous-period baseline computed anywhere to support it, and fabricating one
would violate the person's own "no invented numbers" standard. Flagged, not silently
faked.

## NOT yet built (scope confirmation still needed before starting)
Item 2 above (QR ID Card screen, Custom Filter screen, More Actions bottom sheet,
List→Details→Ledger drill-down) is a real, sizeable UI pattern that needs to be
applied across all five modules — not started yet. This is a discussion-phase batch;
building it out module-by-module needs the person's go-ahead on order/scope, same as
every other major phase in this project.

Balance sweep: NONE.

# ============================================================
# v113-84 — DMS BROWSE FLOW IN KOTLIN (approved reference → production code)
# ============================================================
Date: 2026-08-06. Person approved the DMS full-flow JSX preview ("DMS er aitai curanto,
kotlin e jao. Ar baki gulao same vabe hbe") — so this batch ports it to Kotlin. The
remaining four modules get the same pattern in later batches.

## NEW `ui/dms/DmsBrowseFlow.kt` — 8 screens, matching the reference 1:1
DealerListScreen (search over name/code/phone/zone, three quick-filter chips, live
Total/Active/Inactive counts, initials-avatar rows, bottom toolbar, floating QR-scan
button), DealerDetailsScreen (QR+identity header, Call/SMS/Location/Ledger/90-Days
action row, 4 tabs, full Basic Information incl. the four fields the JSX review caught
as missing — Owner Name, Address, Category, Join Date), DealerLedgerScreen (running
balance table off `partyLedgerFor(DEALER,id)`, debit/credit totals, closing balance),
DealerProductGraphScreen (real product split from that dealer's own invoice line
items), Dealer90DaySummaryScreen (dealer-scoped per the person's explicit correction),
DealerCalendarScreen (month grid with activity dots, per-day invoice/collection list +
day summary), DealerQrCardScreen, and a Custom Filter dialog.

## Boundary honoured
This is the BROWSE half and is deliberately multi-screen — per v113-83's recorded
boundary: action flows = one workspace, browse flows = hierarchical drill-down
("List means its full history plus activity, so seeing the ledger is natural").
Data is cascade-scoped throughout (`rememberVisibleDealers()`), no raw registry reads.

## Two judgment calls, both stated in-code rather than faked
1. **List-level toolbar actions are dealer-scoped.** QR Card / Product Graph / Calendar
   need a dealer; from the list none is chosen. Rather than silently using the first
   dealer or inventing an all-dealer aggregate, tapping asks which dealer
   (`DealerPickerForViewDialog`). This also honours the person's own correction that
   90-Days belongs on the dealer's ID, not the list.
2. **Documents tab says it's not wired.** An Attachment engine exists in the codebase
   but is not bound to Dealer; showing an empty list would imply "no documents" rather
   than "not connected yet". The screen says which it is.
   Likewise the QR card renders a placeholder icon, not a fabricated QR image — actual
   rendering belongs to the untouchable QR foundation.

## Wiring
DMS drawer "list" → `DealerListScreen` (old flat `DirectoryTab` still serves the legacy
Dealers screen until the final strip-down — replaced, not duplicated).

Verified: balance sweep vs pristine NONE; all 16 new top-level names unique
project-wide; every icon used confirmed against the project's proven icon set; every
model field (`proprietorName`, `classification`, `dealerCode`, `stockUnits`,
`lineTotal`, `balanceAfter`) verified in source. Gradle still not run.

# ============================================================
# v113-85 — BROWSE FLOW GENERALISED TO ALL MODULES
# ============================================================
Date: 2026-08-06. Person: "Jeita kotlin korco oita ar baki gulao eki pattern e koro."

## Approach: one engine, not four copies
v113-84's `DmsBrowseFlow.kt` was DMS-specific. Copying it into RMS/HR/FMS would create
four places to fix every future bug — against the standing "one home per feature, no
duplicates" rule. So the pattern was extracted into a generic engine and the
DMS-specific file DELETED (zero external references, verified by grep first).

**NEW `core/ModuleBrowseFlow.kt`** — the 7 browse screens, generic over the record
type: List (search + facet chips + counts + avatar rows + toolbar + QR FAB), Detail
(identity header + capability-driven action row + tabs + Basic Information + KPIs),
Ledger, Product Graph, 90-Day Summary, Activity Calendar, QR ID Card. A module
supplies a `BrowseConfig<T>` describing its records; screens are written once.

**NEW `core/ModuleBrowseConfigs.kt`** — the descriptors:
 - `rememberDealerBrowseConfig` (DMS) — full set; ledger from `partyLedgerFor`,
   graph from that dealer's own invoice line items, 90-day from real invoices +
   VERIFIED collections, Transactions tab.
 - `rememberRetailerBrowseConfig` (RMS) — same shape, memo-based (RetailOrder) instead
   of invoices, matched by real `retailerId` with a name fallback for pre-v113-80 memos.
 - `rememberEmployeeBrowseConfig` (HR) — identity/role/geo/status only. **No
   ledger/graph/90-day buttons**: employees are not money-bearing parties in this
   codebase, so those drill-downs would have nothing behind them. The engine's
   capability flags mean the buttons simply don't render — no dead UI.

## Wiring
DMS "list", RMS "list" (replacing OutletsTab), HR "employees" (replacing the
PayrollScreen directory tab) all now open the same browse pattern with their own
config. FMS deliberately not wired: its "list" concept is product/warehouse stock,
which is a different shape (quantity-per-warehouse, not a party record) and already
has its own working screens — forcing it into a party-shaped browse flow would be
worse UX, not better. Flagged for the person rather than guessed at.

## Real compile-risk caught in self-review, before shipping
The first draft declared drill-down hooks as NULLABLE @Composable lambdas and called
them via `?.invoke()`. That makes a composable call conditional, which breaks Compose's
group structure — a genuine compile/runtime hazard, not a style issue. Restructured to
explicit capability flags (`hasLedger`/`hasGraph`/`has90Day`) plus always-present,
always-callable lambdas defaulting to empty. Same for `extraTabContent`.

Verified: balance sweep vs pristine NONE; all new top-level names unique project-wide
(generic `fun <T>` declarations re-checked with the correct grep after the first pass
under-counted); every model field used confirmed in source (`retailerCode`, `ownerName`,
`market`, `employeeCode`, `mobile`, `status`, `hasActiveAccess`, `loggedAt`,
`lineItems`). Gradle still not run — the person compiles.

# ============================================================
# v113-86 — EVERY MODULE CARRIES ITS OWN OPTIONS IN THE DMS PATTERN
# ============================================================
Date: 2026-08-06. Person: "sob module tar oi related option feature thakbe, sob
complete kore zip + jsx deo, ami compile korbo pore."

## FMS — Product List browse + real combined report
**NEW `rememberProductBrowseConfig`** in ModuleBrowseConfigs.kt — FMS's browse subject
is the PRODUCT (stock-shaped, not party-shaped), mapped honestly: infoRows =
SKU/category/unit/rates/reorder/on-hand; KPIs = total on-hand, stock value at the
product's own defaultUnitPrice, LOW/OK vs its own reorderThreshold; facets =
Category/Status/Low-Stock; graph = per-warehouse quantity split (real
InventoryRepository.stockLevels). hasLedger=false, has90Day=false — product-money
data doesn't exist in this codebase, so those buttons don't render. The generic graph
screen gained `graphTitle` + `sliceFormat` config fields for exactly this reason:
FMS slices are quantities and printing them as "৳" would have been a lie.
**New FMS drawer item "productlist" ("Product List")**, and FMS "reports" —
NotBuiltYet since v113-76 — replaced with **`FmsCombinedReport`**: this-month
production (plans/completed/planned qty from `productionPlans`), current warehouse
stock (total on-hand/rows/low-stock from `stockLevels`), this-month damage
(reports/qty/top-5 lines from `InventoryRepository.damageReports` — first draft
wrongly read it off MockRepository; caught by source-grep before shipping).

## Chairman — poster feature 3 gets its home
**New drawer item "parties" ("Dealer & Retailer List")** — a two-tab host (Dealers /
Retailers) over the SAME shared browse engine with the same dealer/retailer configs
the modules use. Cascade scoping still applies (Chairman's scope = everything).

## Key audit — all five modules, every drawer key has a real branch
DMS 11/11 · RMS 10/10 · HR 11/11 · FMS 13/13 (incl. new productlist; reports now real)
· Chairman 14/14 (incl. new parties). Verified by extracting keys from both the
ModuleDrawerItem lists and the when-branches and diffing.

## JSX — abm-erp-full-preview.jsx
The APPROVED dms-full-flow-preview.jsx extended (original kept untouched as the DMS
reference): the four stubs replaced by a config-driven `GenericModule` — each module's
OWN poster options in its drawer sections, its own color, dashboard KPI, List →
Details → drill-downs in the approved pattern. Honest asymmetries preserved in the
preview too: HR shows only QR Card (no money drill-downs), FMS shows Graph
(warehouse-wise stock) + QR Card. DMS remains the fully-detailed flow.

## Not silently included
Sample rows in the JSX are illustrative (a preview has no database); the Kotlin side
reads only live flows. The workspace-contract remainder (Purchase, Payroll,
Attendance, Leave, Registrations, Production as workspaces) is unchanged — that's the
action-flow track, separate from this browse/options track, still pending as listed
in v113-82.

Balance sweep vs pristine: NONE. New names unique (rememberProductBrowseConfig,
FmsCombinedReport). All fields source-verified: Product.sku/category/unit/
defaultUnitPrice/costPrice/reorderThreshold/barcodeValue, StockLevelView
.quantityOnHand/.warehouseName/.isLowStock, ProductionPlan.productionDate/
.plannedQuantity/.status, DamageReport.productName/.qty/.reason. Compile pending —
the person compiles next.

# ============================================================
# v113-86 — EVERY MODULE CARRIES ITS OWN FEATURES; ALL-MODULE JSX
# ============================================================
Date: 2026-08-06. Person: "Sob module tar oi related option feature thakbe. Sob kisu
complete kore zip o deo sathe jsx o deo. Ami compile korbo pore."

## Audit result: every drawer key in every module now renders something real
Walked every branch of all five module shells. Findings and what changed:

**FMS — two gaps closed:**
- NEW drawer item "Product List" → the shared browse engine with a NEW
  `rememberProductBrowseConfig` (ModuleBrowseConfigs.kt). The FMS record is a PRODUCT,
  not a party, and the config carries that honestly: SKU/category/unit/price/on-hand
  info rows, KPIs = On Hand + Stock Value (qty × the product's own defaultUnitPrice) +
  warehouse count, Graph = the real per-warehouse stock split. hasLedger/has90Day stay
  false — a product has no party ledger or due, so those buttons don't render at all.
- "reports" was the last `NotBuiltYet` placeholder anywhere in the five shells. NEW
  `FmsCombinedReport`: this month's production plans (planned/completed/qty from
  `productionPlans`), live warehouse totals + low-stock count (from `stockLevels` /
  `isLowStock`), this month's damage reports with the top rows (`damageReports`),
  and a pointer to the per-section detail reports. Every field verified in source
  (`ProductionPlanStatus`, `plannedQuantity`, `productionDate: LocalDate`,
  `DamageReport.qty/reason/productName/createdAt`).

**Chairman — dealer/retailer browse wired** ("parties" key, Dealers/Retailers tabs over
the same two configs DMS/RMS use — one engine everywhere). "Employee Control"
deliberately KEPT as `EmployeeSetupScreen` rather than replaced with the browse list:
that screen is the hiring/access-management tool from the poster's Employee Management
feature list; swapping it for a read-only browse would remove capability, not add it.
The browse-style employee list already lives in HR·Employee List.

**DMS / RMS / HR** — re-audited, every key real (browse engine on DMS list / RMS list /
HR employees; workspaces on invoice/order/finance/expense; hosted screens elsewhere).

Unused `NotBuiltYet` import removed from FmsHomeScreen.

## NEW JSX: abm-all-modules-preview.jsx
The approved DMS pattern applied to ALL five modules in one runnable preview: Home
(KPI card + 3 notices + 5 tiles) → each module's clean dashboard (menu icon left, no
back beside it, no bottom nav) → left drawer with "← Home" + Dashboard + that module's
OWN poster sections → List → Details → drill-downs. Capability differences are visible
in the preview exactly as in Kotlin: HR employee has no ledger/graph (not a money
party), FMS product's graph is a warehouse-stock split and it has no ledger/90-day,
DMS/RMS/Chairman parties have the full money set. More-Actions sheet + QR-scanner
modal included. Mock data is illustrative; Kotlin drives from Room/Firebase.

## Verification
Balance sweep vs pristine: NONE. No duplicate declarations. No `NotBuiltYet` left in
any module shell. JSX balanced, single App export. **Not compiled — the person
compiles next and pastes errors back; 15 batches (72→86) are pending that run.**

# ============================================================
# v113-87 — REAL QR EVERYWHERE + REPOSITORY SPLIT PHASES 5-6
# ============================================================
Date: 2026-08-06. Person's correction, verbatim intent: "Really QR generate kora to
amader total app-er foundation — eita kivabe miss koro." He is right that the browse
QR cards showed placeholders; the fix below is registry-CONFORMANT, not a bypass.

## What the foundation actually is (read from source, drives every decision below)
`QrRegistry.issue()` returns the scannable payload `ABMQR:1:<qrId>:<token>` ONCE; only
the token's HASH is stored. So an existing QR can never be re-rendered — showing a
scannable code means an explicit (re)issue, which auto-marks the old row REISSUED
(auditable). The scanner has two paths: secure payloads → full registry validation
(never falls through), bare codes (dealerCode/sku/…) → legacy CodeRegistry match,
labelled unverified. Bare-code cards in legacy screens are therefore VALID legacy tags
and were left alone.

## Built
- **`core/QrImage.kt`** — composable that renders a real ZXing QR from a payload.
  First draft re-implemented the bitmap loop; caught against "grep before creating"
  (the app already has `util/QrCodeGenerator` for retailer shop tags) and rewritten to
  DELEGATE to it. One generator in the codebase.
- **Browse QR ID Card is now the real thing** (`ModuleBrowseQrCard` +
  `BrowseConfig.qrEntityType`): shows the record's live registry status
  (ACTIVE/version/qrId-prefix or "never issued"), and a Generate button that calls
  `QrRegistry.issue` and renders the returned payload — scanning it with the app's own
  scanner resolves Allowed. Explains on-screen why an old QR can't be re-shown (hash-
  only secret) and that generating supersedes the previous print. Wired types:
  Dealer, Retailer, Employee, Product — the latter two were never auto-issued at
  approval, so the card's Issue button is their entry point; `resolveRegistered`
  already maps both types, so the scan loop closes.
- **The genuinely broken QR found and fixed:** invoices printed `"INVOICE:<id>"`,
  which BOTH scan paths reject (secure path: not a registry payload; legacy path:
  CodeRegistry knows invoiceNo, not that prefixed string). Every printed bill carried
  a dead code. Fixed in all three places: `InvoiceDocumentScreen` corner (explicit
  "Print QR" button → issue → real render; deliberately not silent-on-open so merely
  viewing can't invalidate already-printed copies), `exportSalesInvoicePdf` (new
  `qrPayload` param; prints an honest "not issued" line if null instead of a dead
  code), and both SalesChain PDF/print handlers (issue-then-export inside a scope;
  try/catch → runCatching preserved with identical Toasts).

## MockRepository split, phases 5-6 (mechanical recipe, 3rd & 4th application)
- **`data/ExpensesEngine.kt` (81)** — submitExpense / approveExpense (still the only
  ledger-posting point) / rejectExpense. `expenses` StateFlow stayed in the object.
- **`data/ComplaintsEngine.kt` (115)** — createCustomerComplaint,
  createRetailerComplaint (v113-77 partyType guard intact), assign/setStatus/resolve/
  rejectCustomerComplaint.
MockRepository.kt: 8,694 → **8,518 lines**; six engine files total. Remaining =
the sync engine (45 interlocked listener fields — real re-architecture) and scattered
core CRUD — same honest boundary as v113-81c, unchanged.

Verified: balance sweep vs pristine NONE; every moved fn declared exactly once; no
`"INVOICE:` payload left in code (comments retain it as history); unused imports
pruned. NOT compiled — 16 batches pending the person's Gradle run.

# ============================================================
# v113-88 — SPLIT PHASE 7: THE SYNC ENGINE (the deferred piece, done properly)
# ============================================================
Date: 2026-08-07. Person, third ask: "MockRepository-r baki kaj ekhoni ses koro."
The earlier deferrals said the sync engine needed either 45 widened fields or a
redesign. A third option existed and was proven first, then executed:

## The closure proof that made it safe
A script verified BEFORE any line moved that the cluster is CLOSED: all 44
`xListenerReg` fields are referenced ONLY inside the 49 `listenXRemote()` functions +
`startCrossDeviceSync`/`forceResync` — zero references elsewhere. (The earlier count
of "45 fields" was a loose grep matching `liveLocationsListener`'s TYPE
`ListenerRegistration`; that field belongs to live-tracking's separate lifecycle and
stayed behind.) A closed cluster means the fields can move as FILE-PRIVATE top-level
vars — the ApprovalsEngine SLA-map pattern, just 44 of them — with zero widening.

## NEW `data/SyncEngine.kt` (699 lines)
49 listeners + start/force as MockRepository extensions; 44 registration fields as
file-private vars; bodies byte-identical (server-wins upserts, AppLog warnings,
re-attach guards). Bridges as in every phase. Two visibility widenings, each forced by
a real cross-file reference and commented at the declaration: `syncCompanyId`
(private→internal; two push-payload builders in the object read it) and
`_marketSummary` (private→internal; the ONE listener whose flow is in-memory, not
Room-backed). One extension widened file-private→internal: `listenRetailersRemote`,
because the object's own `refreshRetailers()` delegates to it from the other file.

## Mistake made and caught in-batch
The `internal` widening edit initially appended its comment AFTER `()` on the
signature line, swallowing the opening `{` into the comment — balance sweep caught it
(-1) immediately; comment moved above the signature; balance restored. Recorded
because the sweep-after-every-edit rule is what caught it.

## The split, final state — and what "finished" means now
MockRepository.kt: 10,422 → **8,006 lines**, seven files:
Mappers 1,124 · SyncEngine 699 · CorrectionsEngine 309 · ApprovalsEngine 273 ·
CollectionsEngine 175 · ComplaintsEngine 115 · ExpensesEngine 81 = 2,776 extracted.
Every group that exists as a coherent, closure-verifiable unit is now out. What
remains IS the repository: interleaved core CRUD (dealer/retailer/product/invoice/
order/HR) sharing state and calling each other — splitting that further means
domain-repository re-architecture with delegation, a design decision to take AFTER
first compile, not a mechanical move. False-duplicate note: `startCrossDeviceSync`/
`forceResync` also exist as members of Inventory/Purchase/Accounts/Crm/Comms
repositories — different receivers, no clash.
Balance sweep: NONE. 51 moved declarations each exactly once. NOT compiled — 17
batches pending the person's Gradle run.

# ============================================================
# v113-89 — CI WORKFLOW: COMPILE VIA GITHUB (no local computer needed)
# ============================================================
Date: 2026-08-07. Person has no computer right now, so Android Studio is out; asked
for a build.yml that unzips the delivered zip and compiles it via GitHub instead.

## Two real project facts drove the design — checked in source before writing anything
1. `gradle/wrapper/MISSING_WRAPPER_JAR.md` (already in the repo, from an earlier
   session): the wrapper's binary jar was never produced — this sandbox has no
   network access to fetch it. `./gradlew` would fail before touching a single
   Kotlin file. gradle-wrapper.properties already pins Gradle 8.7 as the version
   compatible with this project's AGP 8.5.2 / Kotlin 2.0.20.
2. `app/google-services.json` already exists and is valid JSON (a real placeholder,
   per SETUP_FIREBASE.md — app builds and runs fine on it, only Firestore-synced
   features stay local-only until the person's own Firebase project replaces it).
   No signingConfig block exists beyond the default debug signing. Net effect:
   `assembleDebug` needs no secrets to succeed.

## NEW `.github/workflows/build-android.yml`
Named "Build Android APK" / artifact "abm-erp-debug-apk" — matching the existing
`GITHUB_ACTIONS_SETUP_BN.md` guide exactly, so that doc stays correct without a
rewrite. Steps: checkout → locate the project (finds the newest `*.zip` at repo root
and extracts it, OR uses the repo as-is if project files are ever pushed unzipped —
same workflow serves both today's zip-upload flow and a future normal-git-push flow)
→ JDK 17 (Temurin) → **Gradle 8.7 installed directly via
`gradle/actions/setup-gradle`, bypassing the missing wrapper entirely** (`gradle`
command used throughout, never `./gradlew`) → `gradle assembleDebug --stacktrace
--no-daemon` → upload the APK as a build artifact on success. No separate Android SDK
setup step: `ubuntu-latest` ships platform 34 + build-tools preinstalled with
ANDROID_HOME already set, so nothing else needs installing for this project's
compileSdk 34.

## Doc updated, not rewritten
`GITHUB_ACTIONS_SETUP_BN.md` step 3: previously said extract locally then upload the
extracted files. Now says upload the `.zip` itself, unextracted — the workflow's own
job. Added one line about deleting old zips on re-upload (the workflow picks the
newest by mtime, but an accumulating repo helps no one). Everything else in that doc
(steps 1-2, 4-6) was already correct and untouched.

## Honest limits
This catches real compile errors (Kotlin, resource/manifest merge, KSP/Room codegen)
— exactly what's needed after 18 uncompiled batches. It does NOT run unit tests or
lint (kept minimal on purpose: the goal right now is a green/red compile signal, not
a full pipeline) and does NOT verify anything about runtime behaviour, database
migrations executing correctly on-device, or Firestore sync — a green checkmark means
"the code compiles," not "the app is fully correct." Not tested end-to-end myself
(no network access in this sandbox to actually run a GitHub Actions job) — YAML
syntax verified valid; every version/path claim above traced to this project's own
files, not assumed.

# ============================================================
# v113-90 — FIRST REAL CI RUN: caught a stale-zip upload, workflow more tolerant now
# ============================================================
Date: 2026-08-07. First actual GitHub Actions run — real signal, not a static claim.

## What happened
"Set up job" and "Checkout repository" both succeeded. "Locate project" step FAILED
with the workflow's own designed error message — meaning the detection logic worked
exactly as intended: it caught a structural mismatch cleanly instead of failing deep
inside an opaque Gradle error. The uploaded file was `abm-erp-android-v83-1.zip` — a
name that matches NONE of this session's deliveries (all named
`abm-erp-android-v113-NN.zip`, latest v113-89). Near-certain cause: an old/different
zip from the person's device got uploaded instead of the latest one — not a defect in
the workflow or the project.

## Workflow made more tolerant anyway
Rather than only pointing at "upload the right zip," the extraction step in
`.github/workflows/build-android.yml` now also handles a zip that wraps everything in
one extra top-level folder (e.g. `extracted/abm-erp-android/settings.gradle.kts`):
it searches one level deeper, and if exactly one `settings.gradle.kts` is found there,
uses that as the project root instead of failing. Only errors for real if neither
shape matches, with a clearer message pointing at the version-name mismatch as the
likely cause. Verified: YAML re-validated, no other file touched.

## Status
Still not a green build — same 18 pending batches, now plus this CI-tooling fix.
Next step is the person deleting the stale zip and uploading v113-89 (or later).

# ============================================================
# v113-91 — FIRST REAL COMPILE OUTPUT, FULL ROOT-CAUSE FIX
# ============================================================
Date: 2026-08-07. Person pasted the complete `:app:compileDebugKotlin` error log
(~100 `e:` lines across ~20 files) from the GitHub Actions run. This is the first
real compiler feedback after 18 uncompiled batches, and it earned its keep — every
error traced to a real, fixable cause; none were environment/tooling noise.

## Root cause 1 — a genuine duplicate, and its mechanism is worth recording
`ModuleBrowseConfigs.kt` contained TWO different `rememberProductBrowseConfig`
functions plus a duplicated `Product` import. Investigated rather than assumed:
the second (kept) version matches exactly what this session's v113-86 and v113-87
tool calls actually wrote (verified by diffing against my own action history) and
carries the real QR wiring (`qrEntityType = "Product"`). The FIRST version — using
`graphTitle`/`sliceFormat`/a "Low Stock" facet/`barcodeValue` in search, none of
which my visible v113-86 action wrote — almost certainly dates from FMS work done
in the pre-compaction portion of this same v113-86 batch; the compacted summary
preserved "FMS audit completed" as prose but not the code already written, so the
post-compaction continuation rebuilt the same function from scratch without knowing
a first attempt already existed, and my insertion script only checked that its
ANCHOR text was unique — not that the function name wasn't already present. Kept
the QR-wired version (the person's most recent, most emphatic priority); folded in
one good idea from the deleted version (`graphTitle = "Warehouse Wise Stock"`,
since the default title says "Sales" which doesn't fit a stock-split graph).

## Root cause 2 — the real blind spot: extension functions need imports across packages
This is the one worth stating plainly: every "call sites are textually identical"
claim made across v113-81 through v113-87 was TRUE only for callers already inside
`com.abm.erp.data`. Kotlin resolves a MEMBER function through its receiver with no
import needed — which is what `MockRepository.createCollection(...)` was, before
the split. An EXTENSION function (`fun MockRepository.createCollection(...)`,
what it became) needs to be imported BY NAME in any file outside the extension's own
package, even to call it in identical `Receiver.method(...)` syntax. My grep-based
"call site unchanged" verification could see the text was identical; it could not
see that Kotlin's import rules had silently changed underneath that identical text.
Fixed with a project-wide script — not just the ~10 files the error log named, but
every file calling any of the 29 extension functions across all 6 split engines,
checked by scanning for the call pattern and verifying an import exists for it.
Found and fixed one the error log's file hadn't reached yet:
`BoardroomScreen.kt` → `pendingApprovalSlaItems`.

## Root cause 3 — two files split without carrying their own imports
`ExpensesEngine.kt` (v113-87) and — going further back — none of the other engine
files had this specific gap, but this one did: no imports at all, needed
`androidx.room.withTransaction` and `kotlinx.coroutines.flow.first`. Their absence
cascaded into the confusing type-mismatch noise further down that file (`'C'`,
`CharCategory` — the compiler guessing wildly once `existing`'s type couldn't be
inferred) — fixed at the root, not chased downstream.

## Root cause 4 — nested types/members inside MockRepository, referenced unqualified
`ApprovalLimitType` (nested enum) and `ZoneSummary` (nested data class) were both
referenced bare (`ApprovalLimitType.FINANCIAL`, `ZoneSummary(...)`) from
ApprovalsEngine.kt/SyncEngine.kt — valid when that code lived inside the object,
broken once it moved to another file. Qualified both as `MockRepository.X`. Three
more private members (`pushDealerIncrement`, `pushApproval`,
`updateWeeklyPaidAmount`) needed the same private→internal widening already used for
`syncCompanyId`/`_marketSummary`/`listenRetailersRemote` in v113-88 — this session's
splits simply hadn't been compiler-checked yet to surface them.

## Root cause 5 — a real, independent bug, confirmed by direct inspection (not a cascade)
`FmsHomeScreen.kt`'s `FmsCombinedReport()` (v113-86) used `verticalScroll`,
`rememberScrollState`, `FontWeight` without importing any of them. Checked the
actual import block before concluding this — genuinely missing, not downstream
noise. Fixed directly.

## What was verified NOT to need touching
`BoardroomScreen.kt`'s field-level errors (`.tier`, `.label`, `.ageHours`,
`.approvalKind`) were checked against `PendingApprovalSlaItem`'s real declared
fields — they match exactly. Those errors were pure cascade from ApprovalsEngine.kt
failing to compile (once a file has a hard error, Kotlin can cascade confusing
secondary diagnostics through everything that depends on it) — no code change
needed there beyond the one missing import above. Likely the same mechanism explains
most of the `items`/`id`/`it`-shaped errors in HrHomeScreen.kt/RmsHomeScreen.kt
(their surrounding code was checked and is unrelated to any of this batch's actual
bugs) — flagged as the most probable remaining noise, not silently assumed away.

## Verification performed (no compiler available here — same honest limit as always)
Balance sweep vs pristine: NONE. Duplicate-import check across all 14 touched files:
NONE. Project-wide re-scan confirming every extension-function call site outside
`com.abm.erp.data` now has its import: confirmed zero remaining gaps. Every fix
traced to actual source, not pattern-matched from the error text alone.

**Honest expectation for the next run:** every error in the pasted log has a traced,
applied fix. Given the scale (~100 errors across code spanning 18 uncompiled
batches), a small residual — most likely exactly the cascade-shaped items in
HrHomeScreen/RmsHomeScreen if they turn out not to be pure cascade — is realistic.
That would be a normal, much shorter second round, not a sign this pass was
careless.

# ============================================================
# v113-92 — THE REAL BUG BEHIND THE "CASCADE": FULLY-QUALIFIED items() ISN'T VALID KOTLIN
# ============================================================
Date: 2026-08-07. Person's own observation (these errors persisted at the SAME lines
after v113-91's fix) correctly disproved my "pure cascade" theory — investigated
properly instead of re-asserting it.

## The real mechanism
`items` (LazyListScope.items), like `horizontalScroll`/`verticalScroll`, is a Kotlin
EXTENSION function. Extension functions have exactly two valid call forms:
`receiver.fn(...)`, or bare `fn(...)` where `fn` is imported and an implicit receiver
of the right type is in scope (e.g. inside a `LazyColumn { }` trailing lambda, whose
receiver is `LazyListScope`). Writing the function's full PACKAGE PATH in call
position — `androidx.compose.foundation.lazy.items(profiles, ...)` — is NOT a third
valid form for an extension function; Kotlin looks for a zero-receiver top-level
callable at that exact path, doesn't find one (only the extension exists), and
reports exactly what was seen: "Unresolved reference 'items'" — with everything
inside that one call's trailing lambdas (`{ it.id }`, `{ p -> ... }`) cascading from
that single failure, confined to that one call, which is exactly why nothing else in
the same function (`currentPerf.retailerCoverage` etc., well after the LazyColumn
block) showed any error. `LazyColumn` itself is a plain top-level `@Composable fun`
(not an extension), which is why the outer call was always fine and only the inner
`items` call broke — the person's screenshots showing errors isolated to those two
exact lines were the tell, once actually looked at instead of assumed away.

## Fix
`HrHomeScreen.kt` (1 site) and `RmsHomeScreen.kt` (2 sites): added
`import androidx.compose.foundation.lazy.items`, changed all three call sites from
the fully-qualified form to bare `items(...)`. `RmsHomeScreen.kt` also genuinely
missing `import androidx.compose.foundation.horizontalScroll` (`rememberScrollState`
was imported, the extension it's paired with wasn't) — a second, independent bug at
the same line region, confirmed by checking the actual import block rather than
assumed to be part of the same issue.

## Verification, including the check this whole misdiagnosis should have prompted
Confirmed the `items = HR_ITEMS` / `items = RMS_ITEMS` named-argument usages
elsewhere in both files can't collide with the new import (named-argument labels
aren't independent identifiers subject to import resolution — a Kotlin-semantics
fact, not a guess). Project-wide grep for the same fully-qualified-extension-call
pattern across `items`/`horizontalScroll`/`verticalScroll`/`item`/`itemsIndexed`/
`stickyHeader`/`weight`/`align`: found and fixed exactly the 3 known sites, zero
others anywhere in the codebase. Balance sweep vs pristine: NONE. No duplicate
imports in either touched file.

## Honest note on the earlier misdiagnosis
v113-91 called this "likely the same cascade mechanism as BoardroomScreen" without
verifying it the way BoardroomScreen's fields were actually checked against
`PendingApprovalSlaItem`'s declaration. That was the difference between a verified
conclusion and a plausible-sounding guess, and it cost a round trip. Recorded so the
same shortcut isn't taken again: "probably cascade" needs the same source-level check
as everything else, every time, not just when the theory is inconvenient.

# ============================================================
# v113-93 — REAL DATA-GAP FOUND: RETAILERS WERE NEVER SEEDED, ANYWHERE
# ============================================================
Date: 2026-08-07. Person, after installing the first successful APK: "shudu design
bade sob kisui dummy lage, real invoice generate hoy na, purah mockup lage sob option
gula" — investigated with source, not defended.

## Confirmed by grep before writing anything
`db.retailerDao().upsertAll(...)` had ZERO call sites anywhere in the codebase —
neither in `MockRepository.seedIfEmpty()` (which seeds 3 dealers, retail orders,
production, payroll, etc.) nor via any Firestore sync path. Retailers could only ever
exist if created by hand through "Add Retailer." On a fresh install — the exact
scenario the person just ran — RMS's list, memo workspace, ledger, everything
retailer-scoped was reliably empty. This alone explains a large share of "feels like
mockup": there was nothing seeded to interact with.

## Fixed
Added a retailer seed block to `seedIfEmpty()`, same pattern/place as the existing
dealer seed: 3 retailers (R-1/R-2/R-3) with real field values matching
`RetailerEntity`'s actual schema (verified against source, not assumed) —
retailerCode, market, area, classification, dueBalance, creditLimit, isActive,
createdAtEpochMillis.

## What was checked and is NOT the (or not the only) cause
- Dealers (3, D-1/D-2/D-3) and Products ARE seeded (`InventoryRepository.seedIfEmpty`)
  — so DMS Invoice should have real dealers and products to select from.
- `PermissionManager.canCurrentUser` falls back to role-based permission when no
  EmployeeProfile/override/template exists — doesn't hard-require a seeded profile.
- `visibleDealersFor`/`visibleRetailersFor` fall back to showing ALL records when the
  current user has no matching EmployeeProfile AND isn't SR/TSM — only SR/TSM roles
  get filtered to nothing without an assignment. Matters for diagnosis: which login
  role was used changes what should be visible.
- EmployeeProfile itself is genuinely NOT locally seeded (only ever arrives via
  Firestore sync, which won't populate against the placeholder google-services.json)
  — HR's employee list will stay sparse/empty until either a real Firebase project is
  connected or a local employee seed is added. Flagged, not yet fixed — didn't want to
  guess at seed employee data without knowing which role the person is testing as.

## Still needed from the person to close the loop on "invoice doesn't generate"
Which login role/account was used, and what EXACTLY happens on submit — a specific
error toast, a silently-unresponsive button, or a crash. Each points to a different
one of: permission denial, closed-period guard, or a genuine UI bug in
DmsInvoiceWorkspace — and only one of those three needs a different fix.

Balance sweep vs pristine: NONE.

# ============================================================
# v113-94 — THE "ENGINE" TEXT WAS LITERAL: FOUND IT, FIXED THE ROOT CAUSE
# ============================================================
Date: 2026-08-07. Person (Chairman login): "invoice ki jeno engine ai type lekha othe"
— the word "engine" wasn't a garbled description, it was literally on screen.

## Found by direct source read, not guessed
`DmsInvoiceWorkspace.kt` had it hardcoded: `"✖ তৈরি হয়নি — অনুমতি বা ভ্যালিডেশন
engine-এ আটকেছে।"` ("stuck in the engine") — a vague catch-all shown on ANY
`createSalesInvoice` rejection, because that function only ever returned a bare
`Boolean`; the real reason went to `AppLog.w(...)`, a debug log the UI never sees.
Two more instances of the same pattern: the Sales Return sheet's rejection message,
and a pre-submit credit-limit warning that additionally claimed the over-limit
invoice would "go to approval" — checked against the actual credit-limit check in
`createSalesInvoice` and confirmed that's false; it flatly rejects, no approval
routing exists. All three fixed.

## Investigated and ruled out first, so the fix targets the real problem
Before touching any UI text, checked every hard business rule `createSalesInvoice`
enforces, against a Chairman login on a fresh install: permission (Chairman is in
`fullAccessRoles`, always allowed) — not it; closed period (nothing pre-seeded
closed) — not it; credit limit (seeded dealers have `creditLimit=0`, check is
skipped) — not it; weekly-due suspension (`creditStatus` defaults `"ACTIVE"`) — not
it; warehouse (`WH-1`, STORE category, is seeded) — not it; stock (`PRD-1`/`PRD-2`
opening stock seeded at WH-1) — exists but LIMITED (320 / 45 units), so the most
likely real trigger is simply a test quantity exceeding seeded stock — a rule
working correctly, just never explained.

## Real fix: createSalesInvoice now reports WHY, not just whether
Added `onRejected: (String) -> Unit = {}` to `createSalesInvoice`, called with a
specific Bangla message at every one of its 7 rejection points (permission, closed
period, empty/invalid lines, engine-computed rejection, credit limit, weekly-due
suspension, no warehouse, insufficient stock — the last one names the product and
gives the real available quantity). Same pattern added to `createSalesReturn`'s 3
rejection points. Updated all callers: `DmsInvoiceWorkspace.kt` (both the invoice
button and the return sheet) plus the two legacy screens still wired to the same
engine function, `DealerInvoiceScreen.kt` and `SalesChainScreen.kt` — so the fix
isn't confined to the one screen that was reported, matching the person's own "sob
option gula" framing.

## A real bug caught in self-review before shipping — parameter order
First draft put the new `onRejected` parameter AFTER the existing `onCreated`
parameter. `DmsInvoiceWorkspace.kt` calls `createSalesInvoice(...) { created -> ... }`
using TRAILING LAMBDA syntax, which Kotlin always binds to the function's LAST
parameter — putting `onRejected` last would have silently redirected that trailing
lambda away from `onCreated`, breaking the invoice-created callback with a type
mismatch (`created` inferred as `String`, `.invoiceNo` unresolved) — a compile error
I would have shipped. Caught by checking the actual call site's syntax, not just the
new function body; reordered so `onCreated` stays last.

## Root-data fix from the same debugging session
Confirmed separately that retailers were never seeded anywhere (v113-93, same session)
— combined with this fix, both halves of "everything feels fake" — no data to act on,
and no real explanation when an action failed — are addressed together.

Verified: balance sweep vs pristine NONE; zero remaining "engine" in any user-facing
string (the one hit, `BusinessRuleEngineScreen`'s title, is a real named feature, left
alone); `createSalesInvoice`/`createSalesReturn` each declared exactly once; the
legacy screens' calls checked to confirm neither uses trailing-lambda syntax that the
parameter change could have broken.

# ============================================================
# v113-95 — THE SAME TWO PATTERNS, APPLIED ACROSS THE OTHER REAL WORKSPACES
# ============================================================
Date: 2026-08-07. Person, after 40 days on this project: "cascade wise sob kisu
really functional koro... aisob bug err dami ar valo lagce na... akhon shesh koro."
Read as what it is — not "add one more feature," but "the two patterns you just
found in Invoice are probably elsewhere too; go find them" — which is exactly what
this batch did, methodically, across the other three real (non-legacy) workspaces.

## Audited and fixed: `createCollection` (Collection Workspace, DMS+RMS)
Two real gaps, both worse in kind than Invoice's: **no permission check at all**
(unlike Invoice's "bill" CREATE gate), and a **non-nullable return type** — even the
one internal guard (non-positive amount) that silently skipped the save still
returned what looked like a successful `PartyCollection` object. The UI in
`CollectionWorkspace.kt` then showed "✔ ... জমা হয়েছে" — a false-positive success
message — with the result Text's color **hardcoded to green regardless of content**,
so even a real failure message would have displayed in green. Fixed: permission
check added, return type now honestly nullable, `onRejected` reports the specific
reason, and the color now checks the message itself (✔ → green, else → red) —
verified across all 3 real call sites (2 in `DealersScreen.kt` discard the return
harmlessly, `CollectionWorkspace.kt` updated to handle null).

## Audited and fixed: `logNewOrder` (RMS Memo Workspace)
Found with **zero permission check and zero validation of any kind** — any role
could log a memo with a blank retailer name or a negative amount, and it always
silently "succeeded" (`Unit` return, no way to fail). `RmsMemoWorkspace.kt` had the
exact same two bugs as Collection: unconditional success message, hardcoded-green
color regardless of content. Fixed: permission check ("order" module, matching
`QrRegistry`'s own existing use of that key), blank-name/non-positive-amount/empty-
items validation, return type changed `Unit` → `Boolean`, `onRejected` reports the
real reason. Verified the two legacy `SalesChainScreen.kt` call sites still compile
(both discard the return as a bare statement — safe with any return type change).

## Audited and fixed: `submitExpense` (Expense Workspace)
Already had a permission check and a nullable return (better-shaped from the start)
— only missing was WHICH of category/amount/permission actually failed;
`ExpenseWorkspace.kt` was showing a guess-list ("category/amount বা অনুমতি চেক
করুন") rather than the one real reason. Added `onRejected`, wired it through.

## Found, NOT fixed — stated plainly rather than left implicit
- **`ExpenseScreen.kt` (legacy)**: discards `submitExpense`'s return entirely — on
  any rejection it silently closes the dialog as if it succeeded. Same class of bug,
  lower priority than the four workspaces above (matches the person's own standing
  direction to retire legacy hosted screens once their workspace replacement exists).
- **EmployeeProfile seeding (HR module emptiness)**: investigated, not solved. The
  cascade-visibility match (`profiles.firstOrNull { it.userAccountId == me.id }`)
  requires knowing exactly how a demo login's `currentUser.id` maps to
  `EMPLOYEE_DIRECTORY`'s procedurally-generated per-district IDs — traced far enough
  to confirm this is a real, separate investigation (`demoAccounts` map, a distinct
  keyspace from `EMPLOYEE_DIRECTORY`), not a quick seed-and-done fix. Shipping a
  guessed seed here risked the exact failure mode this whole session has been
  correcting: something that LOOKS fixed without actually being verified. Flagged
  honestly instead of guessed at.

## What "cascade wise sob kisu really functional" honestly means after this batch
The two systemic patterns just uncovered (data never seeded; real failure reasons
swallowed behind vague or wrong messages) are now closed across DMS Invoice, DMS
Return, DMS+RMS Collection, RMS Memo, and FMS/Chairman Expense — the five real,
data-writing workspaces this project has. That is real, verified progress, checked
the same way each time: read the actual function, find every real rejection point,
confirm every caller, sweep balance after every edit. It is not "everything in the
whole project is now finished" — HR's employee data gap is real and open, the
legacy-screen backlog from earlier PROJECT_STATE entries is unchanged, and Gradle
has not run on this exact batch yet. Saying otherwise would repeat the exact problem
this conversation has been about.

Verified: balance sweep vs pristine NONE across the whole batch. Every changed
function's callers re-checked individually for signature-change safety (nullable
return, Unit→Boolean, parameter reordering) rather than assumed compatible.

# ============================================================
# v113-96 — NEW FAILURE CLASS: GRADLE DAEMON CRASHED DURING SETUP, NOT A CODE ERROR
# ============================================================
Date: 2026-08-07. First-ever failure at a DIFFERENT step: "Set up Gradle 8.7" itself
red-X'd (not "Build debug APK") — "Daemon has terminated unexpectedly on startup
attempt #1 with exit code: 8". Genuinely different in kind from every prior fix in
this log: nothing in the app's Kotlin source could cause this — it crashed before a
single project file was touched.

## Fix
`gradle.properties`: added `org.gradle.daemon=false`. The workflow's own
`gradle assembleDebug --stacktrace --no-daemon` already disabled the daemon for
that ONE command; this makes it a project-wide default instead, so nothing else
Gradle does with this project — including whatever `setup-gradle`'s own
provisioning/validation does internally — tries to start a daemon that can crash.
On a CI runner that builds once and exits, a persistent daemon has no upside anyway.

## Honest limits
This is a well-targeted, defensible fix for exactly the failure signature described
(a daemon STARTUP crash) — but the screenshot's log text was heavily compressed/
hard to read in full, so this is the best-supported hypothesis from what was legible,
not a certainty confirmed against the complete error output. If it recurs, the
*full*, clearly-legible text of the "Set up Gradle 8.7" step specifically (not
"Build debug APK") is needed to go further — this is infrastructure/tooling
territory, not something further Kotlin source reading can diagnose.

# ============================================================
# v113-97 — REAL FIX: retailerDao() DOESN'T HAVE count()/upsertAll(). CORRECTING v113-96 TOO.
# ============================================================
Date: 2026-08-08. Person sent the same two screenshots again, this time fully
legible — enough to see the actual picture clearly, which was different from what
v113-96 concluded from the earlier, heavily-compressed version of the same log.

## Correcting the record on v113-96
The "Daemon has terminated unexpectedly on startup attempt #1" line is genuinely in
the log — but reading the FULL surrounding text now shows it was never fatal: the
very next lines are `:app:kspDebugKotlin` and "Kotlin compile daemon is ready" — the
build recovered on its own (an automatic retry) and continued normally through
`mergeExtDexDebug` into `:app:compileDebugKotlin`, where the REAL failure was.
v113-96's `org.gradle.daemon=false` was reasoning from a screenshot too compressed to
show that context — not wrong to add (harmless, stays in place), but it wasn't the
actual fix, because there wasn't a fatal daemon problem to fix.

## The real, fatal error
`e: MockRepository.kt:7976:30 Unresolved reference 'count'.` and
`e: MockRepository.kt:7977:30 Unresolved reference 'upsertAll'.` — squarely inside
the retailer seed block v113-93 added. Checked `RetailerDao` itself (`Daos.kt`) for
the first time — it has neither method: only `getAll(): Flow<List<RetailerEntity>>`
and a SINGULAR `suspend fun upsert(retailer: RetailerEntity)`. v113-93 wrote
`.count()`/`.upsertAll()` by pattern-matching the `dealerDao()` call sitting right
above it in the same function, without checking whether `RetailerDao` actually has
the same convenience methods — it doesn't; those were added to some DAOs and not
others as the project grew. This is exactly the mistake the real compiler exists to
catch, and did.

## Fix
`getAll().first().isEmpty()` instead of `count() == 0` (the `.first()` idiom on a
DAO's `Flow` is already used successfully elsewhere in this exact file, e.g. line
~3911 — confirmed, not assumed). `.forEach { db.retailerDao().upsert(it) }` instead
of a single `.upsertAll(listOf(...))` call — `upsert` is `suspend`, `forEach` is
`inline`, so calling it inside `forEach` within `seedIfEmpty`'s `runBlocking` body is
valid Kotlin (the same reasoning already used for the `logNewOrder`/collection
fixes' `onRejected` lambdas this session, applied here to confirm the pattern holds).

## Checked the other 11 DAOs used in the same seed function, not just this one
Same `.count()`/`.upsertAll()` shape appears for dealer/courier/payroll/production/
raw-material/payment-proof/ledger/approval/retailOrder/roleDefinition/
fieldEmployeeRoute — all PRE-EXISTING code, not written this session. The compiler
run that flagged retailerDao's two lines reported EVERY error in the same pass (this
whole session's logs have consistently shown multi-error dumps, never just the
first) and flagged nothing else in this function — strong evidence the other 11 are
fine, not just an assumption. Spot-checked two anyway against their real DAO
interfaces (`CourierDao`, `PaymentProofDao`) to build direct confidence rather than
rely on absence-of-error alone: both genuinely have `count()`/`upsertAll()`.
`RetailerDao` was the one DAO in this list that was ever simpler/less-built-out —
consistent with everything else this session has found about Retailer being the
least-developed party type in the codebase.

Verified: balance sweep vs pristine NONE. Every other `retailerDao()` call site in
the file (24 of them, listed) uses methods that genuinely exist on the interface —
none use `count`/`upsertAll`, confirming the fix aligns with how this DAO is used
everywhere else.

# ============================================================
# v113-98 — SYSTEMIC VERIFICATION PASS ACROSS ALL FIVE MODULES (no new code bugs found)
# ============================================================
Date: 2026-08-08. Person: "cascade wise sob kisu... barbar compile kora onk hastle...
please do it all the mother module and their proper function full 100%... then I
will compile." Read as: minimize the next compile round by doing every check I can
actually perform without a real compiler, project-wide, before the next upload —
not by claiming completeness I can't back up.

## 1. Every DAO method call, project-wide, mechanically cross-checked against real interfaces
The exact bug class that just cost a round (v113-97: `retailerDao().count()` —
assumed, not real) could exist anywhere else the same way. Built a script: parse
every `@Dao interface` and its real method names from `Daos.kt`, parse the real
accessor-method → interface-type mapping from `AppDatabase.kt` (not a naive
case-guess — confirmed accessor names don't always mirror interface names 1:1),
then check all 708 `db.xxxDao().method(...)` / `database.xxxDao().method(...)` call
sites project-wide. First run showed 700+ false positives — the script itself had a
bug (compared accessor name to interface name directly, wrong case). Fixed the
checker, re-ran: **708 real call sites, 1 flagged — and that one was inside the
v113-97 changelog comment quoting the old broken line as history, not live code.**
Every actual DAO call in the entire codebase now confirmed to use a method that
genuinely exists on that DAO's interface.

## 2. Extension-function imports, re-verified after v113-94/95's changes
Re-ran the cross-package extension-function import check (first built in v113-91)
against the current state of all 29 extension functions across the 6 split engine
files. Zero missing imports anywhere in the app.

## 3. Every drawer item, all five modules, confirmed wired to a real branch
DMS (11), RMS (10), HR (11), FMS (13), Chairman (14) — 59 drawer items total, zero
orphaned keys. Nothing routes to a dead end.

## 4. Approvals / Corrections engines checked against the "vague reason" pattern
Unlike Invoice/Collection/Memo (which had 3-7 distinct rejection reasons each,
genuinely worth distinguishing), `setApprovalStatus` and `submitCorrectionRequest`
each have exactly ONE possible rejection cause (permission; blank reason
respectively) — a plain `false`/`null` already unambiguously means that one thing,
and `ModuleApprovals.kt` already reports it correctly. `UniversalActionMenu.kt`'s
correction-submit button already disables while the reason field is blank, so the
one failure path is unreachable in normal use. Checked, not just assumed — genuinely
lower-value to touch further than the other four were.

## What this batch changed: nothing in the Kotlin source
Every check came back clean. No `.kt` file was edited this batch — balance sweep vs
pristine: NONE, because nothing moved. The zip attached is code-identical to
v113-97; this entry exists so the verification itself is on the record.

## What "100%" honestly means after this
Everything mechanically checkable without running the real Kotlin/Gradle compiler —
DAO signatures, extension-function visibility, drawer-to-branch wiring, rejection-
message coverage on every data-writing workspace — has been checked project-wide,
not spot-checked. That is real, substantial risk reduction for the next compile.
It is NOT a guarantee of zero remaining errors — some classes of mistake (a typo in
a type name that still resolves to a wrong-but-real symbol, a logic error that
compiles fine but behaves wrong, Room's own schema/migration validation, Firebase
rule mismatches) are outside what static text analysis can catch, and only the real
compiler and a real device run can close those. Known, already-recorded gaps
(EmployeeProfile seeding, the legacy ExpenseScreen silent-failure) remain open and
unchanged — carried forward honestly, not re-claimed as fixed.

**This is the point to compile.** Every check available without a compiler has been
run against the whole project, not just the file that broke last time.

# ============================================================
# v113-99 — WENT THROUGH EACH ITEM: EMPLOYEE ADD (real bug fixed), LOCATION (real,
# confirmed working), CHAIRMAN DEEPER SCREENS (real, honestly scoped)
# ============================================================
Date: 2026-08-08. Person: "Sob gula dhoro" — go through every item from the previous
honest breakdown (Employee Add, Dealer Add, Chairman deeper features, Location).

## Employee Add — found and fixed a real bug, same pattern as Invoice/Collection
`createEmployeeDraft` had 5 distinct rejection points (permission, privilege-
escalation on Chairman/MD-level roles, missing name/contact, duplicate mobile/email,
duplicate National ID) — all logged only, never reaching the UI. Same `onRejected`
treatment applied. Updated both real callers: `PayrollScreen.kt`'s "+ New Employee
(Draft)" dialog, and — more importantly — **`EmployeeSetupScreen.kt`, the Chairman
module's own employee-add screen, had a genuine false-success bug**: it wrapped the
call in `runCatching { }`, but `createEmployeeDraft` REJECTS by returning `null`, it
never throws — so `runCatching`'s `onSuccess` fired even when creation failed
outright (duplicate contact, blank name, privilege escalation attempt), showing
"✓ added" for an employee that was never saved. Fixed to check the real return value
plus report the real reason. Searched the whole UI for the same
runCatching-around-a-nullable-return pattern — the other 4 `runCatching` blocks in
the app all wrap genuine exception-throwing operations (file I/O, PDF/print, enum
parsing) — this was the only instance of the bug.

## Location — checked properly this time; it's real, not touched-and-broken
Backend DAOs (`retailerLocationHistoryDao`, etc.) are real (confirmed in v113-98's
708-call-site sweep). Checked whether any UI actually calls the save path:
`MockRepository.updateRetailerLocation(...)` — a real wrapper with its own validation
(valid-coordinate check, blank-reason check) — IS called, from `DealersScreen.kt`'s
GPS-capture dialog, alongside genuinely substantial display logic (distance-moved
calculation, accuracy/quality classification, revision history). The dialog's two
reachable-in-practice rejection paths are already button-guarded (blank reason
disables Submit); the third (invalid coordinate) is practically unreachable from a
real GPS reading. Left as-is — correcting my own earlier answer: this is legacy code,
not part of this session's new workspaces, but it is real and functions, not an
unverified unknown.

## Chairman's four deeper screens — real, but "Master Controller" is honestly narrower than the poster
- `ChairmanMasterController()`: a soft-delete restore console (Invoice/Dealer/
  Retailer/Product/Supplier/Task) — every restore button calls a real, verified
  function (`restoreDealer`, `restoreSalesInvoice`, etc., all confirmed to exist).
  Its own on-screen text says exactly what it is ("Soft-deleted রেকর্ড দেখা ও
  restore"). What it is NOT, and doesn't claim to be: the poster's full "All Module
  Control / Workflow Controller / Permission Controller / System Parameter" vision —
  that's a materially bigger feature this screen doesn't attempt. Naming this gap
  explicitly rather than letting the screen's title imply more than it does.
- `CompanySettingsCenterScreen.kt`, `PermissionControlCenterScreen.kt`: no stub
  markers found in either.
- `BackupRecoveryScreen.kt`: real `createBackup()`/`restoreBackup()`, properly
  try/catch'd, calling a genuine `BackupManager.exportBackup(...)`, not a placeholder.

## What's still open, unchanged from before
EmployeeProfile seeding (HR list still starts sparse on a fresh install — now at
least the ADD path is honest about failures, but nothing is pre-populated), the
legacy `ExpenseScreen.kt` silent-discard, and the fact that "Master Controller"
undersells its name relative to the original poster (a scope decision to flag for
the person, not a bug to silently patch over).

Verified: balance sweep vs pristine NONE. All 3 `createEmployeeDraft` call sites
(the function itself, `PayrollScreen.kt`, `EmployeeSetupScreen.kt`) checked
individually — no other callers exist anywhere in the app.

# ============================================================
# v113-100 — SYSTEMATIC SWEEP COMPLETE: "vague/silent rejection" bug class closed
# app-wide, across all 5 modules
# ============================================================
Date: 2026-08-08. Continuation of the same batch (tool-call limit paused mid-way;
person said "Continue" and this picked up exactly where it stopped).

## Method — not manual guessing, a real search
Built a script (`find every function in data/ with 2+ distinct return-null/return-
false rejection points that does NOT already have onRejected`) — the same class of
bug already fixed for Invoice/Collection/Memo/EmployeeDraft, searched for
systematically instead of waiting for another report. Found and fixed, in order of
severity:

- **`verifyCollection` / `rejectCollection`** (5 + 3 rejection points). Real UI
  impact found: `CollectionWorkspace.kt`'s own Verify/Reject buttons — built THIS
  session — discarded the result entirely, silent on every failure.
  `DealersScreen.kt`'s Verify Toast already guessed at 2 of 4 real reasons; now
  exact.
- **`approveExpense` / `rejectExpense`** (2 + 3 points) → wired into
  `ExpenseWorkspace.kt`'s per-item buttons.
- **`managerReviewCorrection` / `chairmanApproveCorrection` / `chairmanRejectCorrection`**
  (1 + 3 + 2 points) → `ChairmanHomeScreen.kt`'s correction-review block had **"(repository
  layer)" literally in the Bangla UI text** — the same class of leak as the "engine"
  bug, just not caught by the earlier keyword-only search because the words differed.
  Replaced the boolean `denied` flag with a real reason string throughout.
- **`assignCustomerComplaint` / `resolveCustomerComplaint`** (2 + 2 points) →
  `GeoCrmScreen.kt`'s two dialogs closed unconditionally regardless of the real
  result — same "looks like it worked" bug as `EmployeeSetupScreen.kt`'s runCatching
  issue from the previous batch, different mechanism (missing a result check instead
  of misusing runCatching), same effect. Now check the real return value.
- **`setApprovalStatus` / `escalateApproval`** (1 + 3 points) → `ModuleApprovals.kt`
  had **a second "repository layer" leak**, and worse: it hardcoded "permission
  denied" as the shown reason for ALL THREE buttons (Approve/Reject/Escalate) even
  though Escalate alone has 3 real distinct failure causes, only one of which is
  permission. Fixed to show the real reason per action.
- **`approveSalesInvoice` / `deleteSalesInvoice`** (2 + 1 points) → found via a full
  project grep for "repository layer" after fixing the two known instances turned up
  **two more**: `SalesChainScreen.kt`'s Approve/Delete buttons (same hardcoded-wrong-
  reason pattern as ModuleApprovals had) and a third, previously-unknown caller in
  `CreditAndBillingScreen.kt` — confirmed genuinely unused dead code there, no fix
  needed, not silently assumed.
- **Master Controller's Restore button** (`ChairmanHomeScreen.kt`) — checked all 4
  backing restore functions individually; each has exactly ONE real rejection cause
  (permission), so the existing generic message was substantively correct — only the
  jargon suffix ("repository layer-এ আটকেছে") and an inaccurate "or record not found"
  clause needed removing. Didn't rebuild working code to fix a wording problem.

## A parameter-order check repeated, correctly, every time
Every new `onRejected` parameter was checked against its function's existing
call sites for trailing-lambda usage before deciding where to insert it in the
signature — the same class of mistake caught once already this session
(`createSalesInvoice` in v113-94) was checked for and avoided at each of these
7 functions, not just the one that had already bitten once.

## Honest scope note
`advanceApproval` (ApprovalsEngine) — the multi-level SO→ASM→RSM→GM cascade engine —
has zero UI callers anywhere in the app. `setApprovalStatus` (which IS wired) does a
flat single-level approve/reject, bypassing the cascade logic entirely. This is a
real structural gap, recorded rather than silently left implicit: the sophisticated
multi-level approval chain described throughout this codebase's comments may not
actually be reachable from the live app. Not fixed this batch — wiring a dead,
substantial engine into the UI is a design decision (which screen, what flow) beyond
a mechanical rejection-message fix, and doesn't belong in the same batch as the other
work here.

Verified: balance sweep vs pristine NONE across the full two-part batch. Every
touched function's declaration count re-confirmed exactly 1 (including catching a
false alarm — a third caller of approveSalesInvoice/deleteSalesInvoice in
CreditAndBillingScreen.kt, confirmed dead code, not a duplicate). Full project grep
for the jargon phrase itself, not just the functions already known to have it —
zero remaining instances in user-facing text.

# ============================================================
# v113-101 — WIRED IN THE DEAD CASCADE ENGINE: advanceApproval REPLACES THE FLAT
# setApprovalStatus, LIVE ACROSS 6 SCREENS
# ============================================================
Date: 2026-08-08. Person: "mechanical ar design decision bujhi na, amr kaj 100 te
100 hoite hobe, tate jeta valo hoy koro" — explicit instruction not to stop at
"this needs a judgment call," so the advanceApproval gap flagged (not fixed) in
v113-100 was picked up and finished.

## What was actually wrong, verified before touching anything
`raiseApprovalRequest` (the only real, live request-creation path — its sibling
`requestApproval` has zero callers, confirmed) sets `level = 1` on every request,
and `ApprovalRequestEntity.level` defaults to 1 either way. `CASCADE_CHAIN =
[ASM, RSM, GM]` exists and is fully implemented in `advanceApproval` — real level
progression, real per-tier role check, voucher-specific authority limits,
race-condition-safe atomic claim, entity-specific side effects on final approval.
But the only function actually wired to a button, `setApprovalStatus`, ignores
`level` completely — anyone with blanket "approval APPROVE" permission could flip
ANY request regardless of which tier it needed. The cascade was being built
(requests created cascade-ready) but never enforced (approval action bypassed it
entirely) — a real functional gap, not a stylistic one.

## Fix
`ModuleApprovals.kt` — the shared composable rendering approval cards, confirmed
reused by 6 screens (`SalesChainScreen`, `LedgerScreen`, `DmsHomeScreen`,
`PayrollScreen`, `ChairmanHomeScreen`, `ExpenseScreen`) — swapped its Approve/Reject
buttons from `setApprovalStatus` to `advanceApproval`. `setApprovalStatus` is now
itself unwired (confirmed zero remaining callers project-wide) — left in place,
harmless, not deleted.

## Went further than the minimum swap, and caught my own mistake doing it
A blanket "has approval rights" boolean can't tell an ASM-tier request from a
GM-tier one, so a permission-holder could still tap Approve on the wrong tier and
get bounced — correct on the backend, but exactly the "tap it, nothing real
happens" feeling this whole session has been fixing. Widened `CASCADE_CHAIN` from
`private` to `internal` (module-wide visible, same pattern as prior widenings) and
added a real per-request tier computation in `ModuleApprovalCard`, mirroring
`advanceApproval`'s own check exactly — Approve/Reject only render when this
user's role genuinely matches this request's required tier (or is an override
role); otherwise a real explanation ("এই request-এর জন্য {tier} দরকার") shows
instead of the buttons silently vanishing. **Caught before shipping**: first draft
nested Escalate/Forward inside this new stricter tier-check too — but
`escalateApproval`'s real backend permission is the same blanket check as before,
not tier-specific, so nesting it would have hidden a button from someone who
genuinely has the right to use it. Split into two independent conditions, each
matching its own action's real backend rule instead of assuming they're the same.

## Verified
Balance sweep vs pristine: NONE. `CASCADE_CHAIN` has exactly one declaration,
checked for naming collisions project-wide before widening its visibility — none.
All `UserRole` values referenced (`GM`/`MD`/`CHAIRMAN`/`AGM`/`ASM`/`RSM`) confirmed
against the real enum. Zero remaining `setApprovalStatus` call sites anywhere.

# ============================================================
# v113-102 — CORRECTED A CONCERN I RAISED, THEN FIXED THE REAL GAP, THEN CAUGHT
# MY OWN BUG WHILE DOING IT
# ============================================================
Date: 2026-08-08. Person picked both "audit FMS/HR" and "handle the cascade risk" —
the cascade risk (self-flagged after v113-101) was the more urgent one and is what
this entry covers in full; FMS/HR tab auditing is the next turn's work, not
compressed into this one.

## The concern I raised turned out to be wrong — investigated properly instead of leaving it standing
v113-101 warned that thin EmployeeProfile data could leave approval-cascade requests
"stuck" at a tier nobody could fill. Checked properly this time instead of guessing
further: `currentUser.role` — the field `advanceApproval`'s tier check actually
reads — comes from the LOGIN system (`AppUser`, populated via the demo PIN
accounts), not from `EmployeeProfile` (the separate, empty, HR-database entity).
Real demo logins exist for every cascade tier (PIN 33333=ASM, 22222=RSM, 66666=GM)
and every override role (Chairman/MD/GM/AGM). The only place `advanceApproval`
touches `EmployeeProfile` at all is a Voucher-specific extra authority-amount check
that SKIPS itself (doesn't deny) when no profile is found. So the cascade cannot
actually get stuck from this — the concern was real-sounding but checking the
actual field the code reads, not just the field name, showed it doesn't apply.
Corrected here rather than left uncorrected.

## The real, separate gap — fixed properly this time, not guessed at like v113-93 declined to
`EmployeeProfile` (HR's own database entity — genuinely distinct from
`EMPLOYEE_DIRECTORY`, the login-only static directory) was never seeded, which is
the real reason HR's employee list looked empty. v113-93 correctly declined to seed
this without understanding the login→employee linkage; that linkage is now
understood (`userAccountId` on `EmployeeProfile` ↔ `AppUser.id`), so seeded properly:
one `EmployeeProfileEntity` per demo login account (Chairman, MD, GM, AGM, NSM,
RSM, ASM, SR), `userAccountId` set to match each account's real login id exactly.
This closes two things at once: HR's list is no longer empty, and cascade-visibility
scoping (`visibleDealersFor`/`visibleRetailersFor`/`visibleEmployeeProfilesFor`) now
has a real profile to match for every demo role instead of silently falling back to
"show everything" for lack of any match — which happened to look correct before
only by accident (the fallback branch), not by the intended per-role filtering.

## Caught and fixed my own mistake before shipping
The `str_replace` inserting this block accidentally deleted the line immediately
after its anchor point — `if (db.fieldEmployeeRouteDao().count() == 0) {` — because
that line wasn't included in the replacement text. The routine balance sweep run
immediately after (same discipline as every edit this whole session) caught it at
once: a real brace-count deficit in `MockRepository.kt`, not a false alarm. Restored
the missing guard line in place, re-swept clean. Also added the missing
`EmployeeProfileEntity` import — this file uses explicit named imports throughout,
no wildcard, checked against that pattern rather than assumed.

Verified: balance sweep vs pristine NONE (after the self-correction). Single import.
Every `EmployeeProfileEntity` field used checked against the real entity
declaration, not assumed from the retailer-seed's field-name mistake pattern.
`employeeProfileDao().upsertAll()` confirmed to genuinely exist before use (unlike
`retailerDao`'s missing one from v113-93/97) — checked, not repeated blind.

## Still next (not this entry): FMS + HR tab-by-tab audit
Person's other stated priority. Not started this entry — the cascade-risk
investigation and its self-caught bug took the full turn honestly, and compressing
a proper FMS/HR audit into the same response risked the same kind of rushed mistake
this entry just had to catch and fix.

# v113-103 — HR+FMS approve/advance flows (submitEmployeeForReview,
# advanceEmployeeOnboarding, approveProductionPlan, approveWarehouseTransfer):
# same onRejected treatment, real UI wiring (Toast where no local state existed).
# CRITICAL CATCH: full-app re-sweep found advanceApproval itself never received
# the onRejected parameter v113-101 already had ModuleApprovals.kt passing to it —
# a real compile error sitting in the last shipped zip. Fixed now, all 5 of its
# rejection points, before another round could hit it. Balance clean, single
# declarations confirmed, all callers re-verified.

# v113-104 — full-app re-verification pass, zero new issues found
Project-wide re-scans: multi-reject functions w/ real UI callers missing onRejected
→ NONE remaining anywhere. Silent-discard onClick (incl. single-reject fns) → only
2 hits, both confirmed unreachable via their actual call sites (hardcoded non-blank
args), skipped as genuinely low-risk. Duplicate declarations across all 23 functions
touched this session → all exactly 1 (2 apparent dupes for approveSalesInvoice/
deleteSalesInvoice are the already-verified-dead CreditAndBillingScreen wrapper, not
real duplicates). Jargon leak re-check → 0 remaining in user-facing text. Balance
sweep vs pristine → NONE. Nothing left incomplete from this session's scope.

# v113-105 — TRUE SCOPE OF THE VAGUE-REJECTION BUG CLASS FOUND: ~100 more instances
Broader regex re-scan (permissive, catches any call shape not just bare-onClick)
found ~100 additional functions with the same bug, far beyond what manual spot-
checking had reached. Fixed 2 more this batch (chairmanApproveHiring,
issueRawMaterial — both data fn + UI wired + verified). The rest is real, found,
NOT yet fixed — written into NEW FILE `VAGUE_REJECTION_BACKLOG.md` at repo root,
grouped by file, reject-count, with the exact fix method — so it survives across
sessions instead of needing rediscovery. Attempting all ~100 in one turn was
rejected as the wrong call (matches this session's own earlier lesson: rushing
breaks things, like the brace-deletion in v113-102). setLeaveStatus also found and
fixed (2 points, 2 UI callers: PayrollScreen.kt + ChairmanHomeScreen.kt) — missed by
the earlier automated scan's call-shape assumption, found by manual reading while
auditing Chairman's remaining drawer items as requested. Chairman's other 9
unchecked drawer items (dashboard/ai/reports/company/rules/permissions/audit/
backup/notice) — routed to real, non-stub screens, confirmed this entry; deeper
per-screen audit is part of the same backlog file, not separately tracked.
Balance sweep vs pristine: NONE.

# v113-106 — DealersScreen.kt: 7 of 18 backlog functions done (all 4-point ones)
deleteRetailer rejectRetailer transferRetailer rejectDealer createDealer
createRetailer setTerritoryPolygon — data fn onRejected + UI wired + verified.
Found: UniversalActionMenu's onArchive callback has no error channel at all
(architectural, affects many entity types) — noted in backlog, not fixed here.
Balance clean. 11 DealersScreen functions + all other files remain — backlog
updated.

# v113-107 — PayrollScreen.kt: 4 of 16 backlog functions done (all 4-point ones)
createDelegation rejectEmployeeOnboarding changeEmployeeRole setEmployeeStatus —
data fn + UI wired + verified. Caught missing delegateError state declaration
before shipping (used but never declared). Balance clean.

# v113-108 — confirmFinishedGoods, dispatchWarehouseTransfer, createVoucher done
Data fn (4 rejection points each) + UI wired (ProductionWarehouseScreen.kt ×2,
LedgerScreen.kt) + verified. createVoucher's 4th point (closed-period, was in
AccountsRepository.kt, separate file from the other 2) caught and included, not
missed. Balance clean, zero stale callers.

# v113-109 — approveStockCount, chairmanRejectHiring, chairmanReturnForCorrection done
All 3 (4-point each) data fn + UI wired + verified. HiringApprovalCenterScreen.kt's
3 Chairman-decision functions now all fixed; only submitHiringRequest(2) remains
there. Balance clean, zero stale callers.

# v113-110 — cancelSalesOrder, approveSalesReturn, approveSalesOrder, reverseVoucher done
4 fns (4+3+2+3 rejection points) + 5 UI edits across SalesChainScreen/LedgerScreen/
CreditAndBillingScreen (incl. threading 2 vm wrappers). reverseVoucher's UI also
gained a real success check (was closing the dialog unconditionally). Balance
clean, zero stale callers.

# v113-111 — approvePurchaseReturn, createSupplier, approvePurchaseRequest done
3 fns (3 rejection points each) + UI wired across PurchaseScreen.kt (2 vm wrappers
threaded, 1 direct Toast site). createSupplier's unusual runBlocking(Dispatchers.IO)
structure handled correctly — onRejected called from inside the block, verified
this doesn't need suspend context. Balance clean, zero stale callers.

# v113-112 — DealersScreen.kt 3-point cluster + PayrollScreen.kt 3-point cluster
Discovery: 4 of the 5 flagged DealersScreen 3-point functions (approveRetailer,
setRetailerGeofenceRadius, approveDealer, assignRetailerOfficer) were ALREADY fixed
in an earlier batch — backlog was stale on this point, verified rather than
re-fixed blindly. Only updateRetailerLocation was a real gap — closed. PayrollScreen:
linkEmployeeToUserAccount, createTransferRequest, createGeoOverride,
assignDirectManager, setApprovalLimits — all 5 genuinely fixed, data fn + UI wired.
assignDirectManager's manager-picker already showed the reason proactively per-row
(disabled+labeled); added the permission-path error on top, not a redundant rebuild.
Balance clean, zero stale callers (one look-alike DAO function correctly excluded).

# v113-113 — DealersScreen 2-pt cluster (all 5 already done, verified not re-fixed)
# + PayrollScreen 6 functions (assignEmployeeArea, enterManualAppraisalScores,
# resetUserAccountPin, unlockUserAccount, generateAppraisal, setUserAccountActive)
# genuinely fixed, data fn + UI wired. Balance clean, zero stale callers.

# v113-114 — receiveWarehouseTransfer, reportDamage, createAccount done
3 fns (3+3+2 rejection points) + UI wired (Production/Inventory/Ledger). Caught
missing acctError declaration before shipping. Balance clean, zero stale callers.

# v113-115 — createProductionPlan, createWarehouseTransferRequest, recordPacking,
# receiveGoods done. 4 fns + UI wired across ProductionWarehouseScreen/PurchaseScreen.
# 3 missing state declarations (planError, wtCreateContext, receiveError) caught
# and added before shipping. Balance clean, zero stale callers.

# v113-116 — rejectPurchaseRequest, adjustStockToCount, createLead, submitHiringRequest
# done (4 fns + UI wired). duplicateProduct's data fn also fixed but its UI caller
# goes through UniversalActionMenu.onDuplicate — same no-error-channel gap as
# onArchive, correctly not force-fixed. HiringApprovalCenterScreen.kt's backlog
# entry now fully closed. Balance clean, zero stale callers.

# v113-117 — DealersScreen.kt backlog FULLY CLOSED (18/18)
Last 6 single-reason functions (confirmLegacyAddressMatch, restoreRetailer,
deleteDealer, reviewLocationAlert, restoreDealer, reviewSecurityEvent) done —
data fn + UI wired (Toast, matching each already having exactly 1 real reason).
Master Controller's restoreDealer/restoreRetailer calls, and the 3
UniversalActionMenu-routed callers (onArchive/onRestore for Dealer/Retailer),
correctly left as-is — same documented architectural gap, not re-litigated.
Balance clean.

# v113-118 — Production/ProductionScreen, PurchaseScreen, LedgerScreen ALL FULLY
# CLOSED. 8 fns fixed: createPurchaseRequest/Return/Order, restoreSupplier,
# deleteSupplier, deleteVoucher, recordQualityInspection, updateProductionOrderStatus.
# Real bonus find: updateProductionOrderStatus had ZERO permission check for 6 of
# its 7 status-transition buttons (only "Complete" was ever guarded) — added.
# Balance clean, zero stale callers.

# v113-119 — SalesChain/CreditAndBilling + GeoCrmScreen backlogs FULLY CLOSED
6 fns: createQuotation, restoreSalesInvoice, createPosSale, createDeliveryChallan,
createOpportunity, createCustomerComplaint. Self-caught a real brace mismatch mid-
edit (createPosSale's if(ok){} block) via the routine balance sweep — fixed before
it went anywhere near the person. Balance clean now, zero stale callers.

# ============================================================
# v113-120 — VAGUE_REJECTION_BACKLOG.md FULLY CLOSED. All ~100 functions found in
# v113-104/105's full-app scan now have onRejected + wired UI, except two
# documented, unchanged architectural exceptions (UniversalActionMenu.onArchive/
# onDuplicate and McRestoreRow's callback — both () -> Boolean/Unit with no error
# channel, affecting many entity types each; fixing properly means a signature
# change across many call sites, a deliberate design decision not bundled into
# this mechanical sweep).
# ============================================================
Final batch: transferEmployeeArea, finalizePayrollPreparation,
updateStockIntelligenceThresholds, createManagementAction, updateExceptionStatus,
updateExecutiveSettings, postAnnouncement, postCircular, createRetailerComplaint,
createVehicle, submitVacancyRequest, unlockAccountingPeriod — 12 functions, all
single-reason (permission or blank-field), all now report their real reason.

Files now at 100% of their backlog entries: DealersScreen.kt (18/18),
PayrollScreen.kt (16/16), ProductionWarehouseScreen.kt/ProductionScreen.kt (9/9),
PurchaseScreen.kt (8/8), LedgerScreen.kt (4/4), InventoryScreen.kt (4/4, minus the
one architectural exception), HiringApprovalCenterScreen.kt (4/4),
SalesChainScreen.kt/CreditAndBillingScreen.kt (10/10), GeoCrmScreen.kt (4/4, minus
one confirmed-unreachable case), BoardroomScreen.kt (3/3), all 6 misc single-file
entries.

Verified: balance sweep vs pristine NONE. Zero stale callers across all 12
functions checked individually. What "closed" honestly means: every function this
session's systematic regex scans could find, with a real UI caller, now reports
its real rejection reason instead of a generic guess, a wrong hardcoded string, or
silence. It does NOT mean every button in the app is now audited line-by-line for
business-logic correctness — that was never this backlog's scope, and remains
open work distinct from this specific, now-closed bug class.

# v113-121 — DEEP DIVE into previously-unaudited areas: RMS (beyond Memo/Collection),
# Chairman's Permission Control Center
Person's request: go deep into all 5 modules, not just the backlog's mechanical scope.

## RMS — RmsApprove, RmsRetailerStockPicker, RmsComplaintsTab, PartyCampaignSection
All read/checked in full for the first time this session (not just routing).
RmsApprove: real geo-scoped TSM approval logic, correctly reuses the already-
verified AsmVerifyTab. RmsRetailerStockPicker/RmsComplaintsTab: real filters, real
navigation (`retailer_stock/{id}` confirmed to hit a real NavGraph route backed by
a real Room table, not a dead link). PartyCampaignSection (shared by both DMS's
"message" tab and RMS's "relation" tab): confirmed `sentCount` is real dealer-count
data (a prior session's fix, re-verified not a regression) — but found a genuine,
new gap: `broadcastCampaign` had NO permission check at all, any logged-in user
could send a campaign broadcast regardless of role. Fixed (added canCurrentUser
"dealer" CREATE check + onRejected), wired both real UI call sites
(GeoCrmScreen.kt's own broadcast tab, and PartyCampaignSection itself) — reaches
DMS and RMS simultaneously since the component is shared.

## Chairman's Permission Control Center — read in full, genuinely substantial
Not a stub: Chairman-gated at screen entry, real template CRUD (create/edit/
duplicate/delete), real per-module access-level assignment (HIDE/VIEW_ONLY/
FULL_ACCESS), real bulk template-to-employee assignment, real per-employee
per-module overrides with clear. All 6 backing PermissionManager functions
(createTemplate, duplicateTemplate, deleteTemplate, updateTemplate,
assignTemplateToEmployees, setEmployeeOverride) confirmed to genuinely exist, not
assumed. Screen-level Chairman gate means individual mutation functions don't need
their own onRejected in the same way the backlog's functions did — the entry gate
is the real protection, correctly noted rather than force-fitting the pattern.

Balance sweep vs pristine: NONE. This is real, continued depth beyond the closed
backlog — not a re-audit of what's already verified, and not a claim that all 5
modules are now exhaustively covered either.

# v113-122 — FMS module read in full; found + fixed a real UI-only-gate bug in
# the employee Complaint Box (separate feature from customer/dealer complaints)
FMS's own unique screens (FmsDashboard, productlist, FmsCombinedReport,
ComplaintBoxScreen) read in full — the rest of FMS's drawer routes into
Production/Inventory/Purchase/Expense screens already fully closed this session.
FmsDashboard/FmsCombinedReport: confirmed all real StateFlow-derived numbers, zero
fabrication.

Real bug found in ComplaintBoxScreen.kt (Firebase-backed employee whistleblower
box, SR-to-MD, distinct from ComplaintsEngine's customer/dealer complaints):
`isChairman` was computed and correctly used to hide the complaint list (and its
Mark Resolved/Reopen button) from non-Chairman users in the UI — but the backend
function itself, `FirebaseSync.setComplaintResolved`, had no permission check at
all, violating this app's own stated principle (PermissionControlCenterScreen.kt's
comment: every Chairman-only mutation re-checks server/repo-side too, the UI isn't
the only line of defense). Fixed: added the Chairman-only backend check +
onRejected, wired the one real UI caller. submitComplaint itself correctly has NO
permission gate — every employee SR-to-MD is meant to be able to file a complaint,
verified this is intentional, not an oversight.

Balance sweep vs pristine: NONE. Same-package reference to UserRole confirmed
needing no new import.

# v113-123 — Chairman's Business Rule Engine + Enterprise Audit Center + Reports,
# HR's Attendance + Directory tabs — all read in full, all confirmed genuinely
# real, no new bugs found this pass
Business Rule Engine: all 9 configurable rules individually cross-checked against
their real consumption sites in MockRepository.kt (WEEKLY_DUE_PCT, MAX_DISCOUNT_PCT,
ATTENDANCE_RADIUS_M, LATE_ENTRY_GRACE_MIN, INVOICE_LIMIT,
DEALER_CREDIT_LIMIT_DEFAULT, MIN_CREDIT_LIMIT, STANDARD_SHIFT_HOURS,
OVERTIME_RATE_MULTIPLIER) — every one genuinely read by real business logic via
`businessRuleDouble(...)`, not an orphaned setting. Enterprise Audit Center:
real, correctly read-only, displays the same real audit log every logAudit() call
this whole session has written to. ReportsScreen: no random()/fabricated-number
generation found. AttendanceTab: real cascade-scoped roster + real presence flow +
reuses the already cascade-aware ModuleApprovalSection (v113-101's fix applies
here too). EmployeeDirectoryTab: real hierarchy grouping and search, backed by
EMPLOYEE_DIRECTORY so unaffected by the separate EmployeeProfile-seeding gap.

No code changes this pass — everything checked came back genuinely solid, which is
itself the honest finding to record, not silently skipped. Balance sweep vs
pristine: NONE (nothing edited).

## What's still genuinely unaudited (honest, not exhaustive)
HR's Hierarchy/Lifecycle sub-tabs specifically (Directory and Attendance now
checked, Payroll/Leave/EmployeeManagement checked across earlier batches — Lifecycle
and the org-chart Hierarchy view itself not yet read). Chairman's Company Settings
screen beyond its 2 already-checked functions. RMS's own dashboard composable
(RmsDashboard) not yet read. DMS has had the most cumulative attention this session
by far and is the strongest-verified of the five.

# v113-124 — LifecycleEventsTab, RmsDashboard, CompanySettingsCenterScreen (full,
# not just the 2 previously-checked functions) — all read in full, all clean
LifecycleEventsTab: real recordLifecycleEvent, single permission-reason correctly
already unreachable (Record Event button itself gated by the same canApproveHr()
check). RmsDashboard: real cascade-scoped stats (retailer count, total due,
today's memo/visit counts), zero fabrication. CompanySettingsCenterScreen: full
file re-read, confirmed only 2 real mutating actions exist (addCompanyHoliday,
updateCompanySettings — both already fixed/verified), everything else is local UI
state feeding into those 2; screen-level Chairman gate confirmed present, matching
BusinessRuleEngineScreen/PermissionControlCenterScreen/EnterpriseAuditCenterScreen's
consistent pattern.

No code changes this pass. Balance sweep vs pristine: NONE.

## Session-wide deep-dive status across all 5 modules (honest running account)
DMS: most extensively covered all session (Invoice/Collection/Memo/Dealer/Retailer
flows, QR, browse flow) — strongest confidence.
RMS: Memo/Collection (earlier), Approve/StockPicker/Complaints/Campaign/Dashboard
(this and last turn) all now read — broadcastCampaign gap found+fixed. Genuinely
well-covered now.
HR: Payroll/Leave/Onboarding/Approval-limits (backlog), Attendance/Directory/
Lifecycle (this and last turn) all read — well-covered. EmployeeManagement's
sub-screens (EmployeeSetupScreen etc.) covered earlier too.
FMS: Production/Inventory/Purchase/Ledger backlogs fully closed + FMS's own unique
screens (Dashboard/CombinedReport/ComplaintBox) read — ComplaintBox backend-gate
gap found+fixed. Well-covered.
Chairman: Approval Center/Master Controller/Correction/Hiring (earlier),
PermissionControl/BusinessRuleEngine/EnterpriseAudit/CompanySettings (this and
last turn) all read — genuinely thorough now, several confirmed solid, none found
newly broken this pass. Reports/Rules screens also checked.

Not yet read this session: HR's raw Payroll-calculation formulas' correctness
(the numbers compute, not independently re-derived by hand), Room migration
version history, Firebase security rules content itself. These remain explicitly
open — real code-reading depth has been substantial and is honestly reported
above, not claimed as total.

# v113-125 — HAND-VERIFIED the payroll formula itself (not just that it compiles/
# displays), found and fixed a real business-rule consistency bug
Read PayrollLine's actual computed properties (achievementPct, scalingFactor,
commission, absencePenalty, netPayable) and independently hand-computed the
formula against real seed data (Sales Officer Rafiq: base ৳22000, 92% achievement,
1.5% commission rate, 1 unapproved absence day) — confirmed netPayable = ৳26,407
matches exactly what the formula should produce. The "3-layer: base pay ×
achievement curve + commission − absence penalty" description in PayrollScreen.kt's
UI text is genuinely accurate, not just marketing copy — scalingFactor correctly
bounds the achievement curve to 50%-150% (real business protection against
runaway payroll on wild overachievement, and a floor even at 0% achievement).

Found a real inconsistency while verifying overtime: `refreshPayrollAbsences()`
computed overtime MINUTES against the configurable STANDARD_SHIFT_HOURS business
rule (correct, at the checkout function ~line 7235) but converted dailyWage to an
hourly RATE for paying that overtime using a hardcoded `/8.0` — so a Chairman
changing the shift-length rule via Business Rule Engine would shift what counts as
overtime without shifting what it's paid at. Fixed: hourlyRate now uses the same
`businessRuleDouble("STANDARD_SHIFT_HOURS", 8.0)` call. Checked project-wide for
the same hardcoded-8.0 pattern elsewhere — this was the only instance.
OVERTIME_RATE_MULTIPLIER's own usage separately re-checked — correctly consistent,
single real consumption site, no matching bug.

Balance sweep vs pristine: NONE.

# v113-126 — Room migration chain audited (new area this session), full DAO
# re-verification, schema-drift check
Migration chain: 52 migrations registered, versions 23→75 continuous with zero
gaps, every defined MIGRATION_X_Y object confirmed actually passed to
addMigrations() (none orphaned/forgotten). Spot-verified the two most recent
(MIGRATION_73_74 creating `retailer_stock_lines`, MIGRATION_74_75 adding 3 columns
to `customer_complaints`) against the live Entity definitions — column names,
types, and defaults match exactly.

Schema-drift check: confirmed via direct diff against the pristine reference copy
that `Entities.kt` has never been touched anywhere in this entire session — every
fix this session used only pre-existing fields on pre-existing tables (consistent
with the standing rule of verifying field names against source, never assuming),
so no migration gap was introduced by this session's own work.

Full DAO re-verification: 710 real call sites (up from 708 — the 2 new ones are
this session's own EmployeeProfileDao.upsertAll/getAll additions), only the
already-known changelog-comment false positive, zero real mismatches. Balance
sweep vs pristine: NONE.

This closes out Room/schema as a checked area — genuinely new ground for this
session, came back clean rather than needing a fix, which is itself the honest
result to report.

# ============================================================
# v113-127 — THE UniversalActionMenu ARCHITECTURAL GAP, FULLY FIXED (not just
# flagged). Person's direct request: "real universal menu."
# ============================================================
Changed `UniversalActionMenu`'s `onArchive`/`onDuplicate` signature from
`(() -> Unit)?` (no error channel, flagged as a known gap since v113-100) to
`((onError: (String) -> Unit) -> Unit)?` — the caller's lambda now receives a
real error-reporting callback. Wired both internal invocations (Archive confirm
button, Duplicate menu item) to the same Toast pattern the component already uses
for its other messages (blocked-reason, permission-denied) — no new UI pattern
introduced, consistent with what was already there.

Then fixed all 17 real call sites across 9 files (SalesChainScreen, GeoCrmScreen,
TaskManagerScreen ×2, LedgerScreen, CreditAndBillingScreen, InventoryScreen ×2,
PurchaseScreen ×3, CommunicationHubScreen ×2, DealersScreen ×4) to the new
error-carrying lambda shape, and their 14 backing wrapper functions to thread
`onRejected` through.

Reading the 14 real backing repo-layer functions turned up 4 genuine, previously-
undiscovered gaps — functions with NO permission check at all:
- `deleteTask` (MockRepository) — anyone could delete any task
- `deleteProduct` had a check but no onRejected — now reports it
- `deleteAnnouncement` (CommsRepository) — anyone could delete company
  announcements
- `deleteCircular` (CommsRepository) — anyone could delete circulars
All 4 fixed with real permission checks (task/inv/notify DELETE) + onRejected.

The other 10 functions (duplicateLead, duplicateTask, duplicateQuotation,
duplicateDealer, duplicateRetailer, duplicateSupplier, duplicatePurchaseOrder) are
all "create a copy" functions that already delegated to their respective
createX(...) function — every one of those createX functions already had
onRejected from the closed backlog (v113-106 through v113-119), so the fix here
was propagating that existing, real reason through the duplicate wrapper, not
inventing new logic.

Verified: balance sweep vs pristine NONE across every touched file. Every one of
the 11 newly-onRejected repo functions confirmed to have exactly 1 declaration
(no duplicates from the batch edits). All 17 call sites re-grepped — zero old-
shape survivors anywhere in the codebase; the search for the old signature
pattern came back empty project-wide, not just in the files I intended to touch.

## What this means, honestly
UniversalActionMenu's Archive and Duplicate actions — used in every module, on
Invoices, Tasks, Vouchers, Quotations, Products, Suppliers, Purchase Orders,
Announcements, Circulars, Dealers, and Retailers — now report their real reason
on failure instead of silently doing nothing. This was a real architectural gap,
not a cosmetic one, and it's closed everywhere it existed, not partially.

# v113-128 — Direct answer-check to "are all 59 drawer items proper working":
# found and fixed ChairmanNoticeBoard's missing defense-in-depth gate
Checked the one Chairman drawer item not yet explicitly verified by name this
session ("notice" -> ChairmanNoticeBoard). Real: genuine createNotification call,
real employeeProfiles-backed recipient list. But unlike every sibling Chairman-only
screen in this same file, it had no entry-level role check — relying solely on the
outer ChairmanHomeScreen's gate (confirmed present at line 82) rather than the
defense-in-depth pattern this codebase states as its own principle. Added the same
check for consistency. Balance clean.

# ============================================================
# v113-129 — REAL "More Actions" panel built into the shared browse engine —
# Export/Share/Print, all genuinely working, applies to EVERY module at once
# ============================================================
Person's request, after comparing the RMS poster against reality: build the
genuinely-achievable pieces of the missing "More Actions" bottom sheet
(Export/Print/Share — not Import/Bulk SMS/WhatsApp, correctly deferred as needing
real messaging infra this session doesn't have).

Added to `ModuleBrowseFlow.kt` (the SAME shared engine every module's browse list
already uses — DMS Dealers, RMS Retailers, HR Employees, whatever else is
configured) — a 5th toolbar action, "More", opening a real bottom sheet with:

1. **Export List (CSV/Excel)** — new `exportListAsCsv()` in StructuredExports.kt,
   real file write + real FileProvider share (same proven mechanism the app's
   existing PDF exports already use, not a new untested path), using the
   already-verified-real CSV field-escaping from UniversalActionMenu.kt
   (`escapeCsvField`). Opens in Excel/Sheets like any real CSV.
2. **Share List Summary** — real text share via the standard ACTION_SEND intent,
   real computed counts (total/active/inactive from the actually-filtered list,
   not fabricated).
3. **Print List** — new `exportBrowseListPdf()` (real, paginating
   android.graphics.pdf.PdfDocument generation — genuinely handles more than one
   page's worth of records, not silently truncating) + new `printPdfFile()` which
   hands the file to Android's real `android.print.PrintManager` via a
   `PrintDocumentAdapter` — opens the device's actual print dialog, any real
   installed printer/PDF app, not a share-sheet pretending to be print.

Verified before shipping: FileProvider is genuinely registered in
AndroidManifest.xml (not assumed). `escapeCsvField` confirmed non-private and
same-package, no import needed. `Context.PRINT_SERVICE` needs no manifest
permission (system Print Spooler handles its own). All 4 new functions confirmed
declared exactly once. Balance sweep vs pristine: NONE.

## Honest comparison against the uploaded RMS poster, now updated
Of the poster's 11 screens: Dashboard, Module Menu, List, Details, Ledger,
Product Graph, 90-Day Summary, Calendar, QR ID Card, Custom Filter, and now
Export/Share/Print — all genuinely real, and via the shared engine, present for
every module configured with it, not just RMS. Still genuinely not built (correctly
not claimed as done): Import (Excel upload with parsing/validation), Bulk SMS,
WhatsApp broadcast, a manual "Sync Data" button, and Custom Filter's extra
criteria (Date Range, Product, Salesman/Agent — currently Market/Category/Status
only). These remain open, real, named gaps for a future session, not silently
dropped.

# v113-130 — HRM/FMS/Chairman poster comparison: found and fixed a real
# fabricated-numbers bug in Employee Attendance, found a real gap in Chairman's
# "Business Overview"
Employee's browse config explicitly (and correctly, per its own comment) has no
Ledger/Graph/90-Day — employees aren't money-bearing parties. But the poster's
separate claim (Employee Attendance & 90-Day Summary as its own real screen) led
to checking PayrollScreen.kt's employee-attendance-detail view directly, where a
stats card showed literal hardcoded numbers — Present 13, Absent 0, Holiday 4,
Half Day 6, Week Off 4, Leave 3 — for every employee, always, the exact
fabrication class a "v86 fix" comment on the very next card up had already caught
and corrected. Missed here. Fixed: real counts from
`MockRepository.attendanceRecordsFor(employeeId)` over a real 30-day window
(checkedIn/isOnLeave/isLate — the only fields AttendanceRecordEntity actually has).
Holiday/Half Day/Week Off dropped rather than approximated — no real field backs
any of the three, matching the exact same call the v86 fix already made rather
than inventing a derived approximation under time pressure.

Caught and fixed my own scope bug while writing this: first draft referenced
`records`, a val declared in a sibling `item { }` LazyColumn block — not visible
across item-block boundaries in Compose. Declared it locally with the same real
data source instead of assuming cross-block scope.

Chairman's "Business Overview" (poster's 4-KPI header + Sales-vs-Collection bar
chart, as its own screen) — checked ChairmanHomeScreen.kt and ChairmanHubScreen.kt
directly: only "Total Due" exists as a real KPI on the hub; Total Sales, Total
Dealers, Total Retailers, Total Products, and the Sales vs Collection chart are
not built as this dedicated screen. Real, named gap — not fixed this entry, flagged
for the person to prioritize.

Balance sweep vs pristine: NONE.

# ============================================================
# v113-131 — Chairman's "Business Overview" built — completing what the drawer's
# own subtitle already promised, not a new competing screen
# ============================================================
Extended `ChairmanHubScreen.kt` (the real screen "dashboard" already routes to,
whose own drawer subtitle already says "Business Overview in Real Time") instead
of creating a second, separate "business" screen — one home per feature.

Added, all real:
- Total Sales / Collection / Total Due — reused `computeSalesKpi()`/
  `computeCollectionKpi()`, the exact same already-verified real functions this
  screen's "Executive Dashboard" card already calls (BoardroomScreen and the main
  Dashboard use the same two functions too — no new calculation logic written).
- Total Dealers / Total Retailers / Total Products — real counts
  (`dealers.count { !it.isDeleted }` etc.), Product's `isDeleted` field confirmed
  against its real declaration in InventoryModels.kt before use.
- Sales vs Collection — Last 5 Weeks — genuinely new computation, Monday-anchored
  real weekly buckets built directly from `MockRepository.salesInvoices`/
  `partyCollections`, using the exact same field references
  (`!isDeleted`/`lineItems.sumOf{lineTotal}`/`status=="VERIFIED"`/`amount`)
  `computeSalesKpi`/`computeCollectionKpi` already use — not fabricated shape.
  Drawn with a new `SalesVsCollectionBarChart` composable using plain Canvas/Box
  bars, the same real charting technique `com.abm.erp.ui.core.TrendLineChart`
  (used one card below it, unchanged) already establishes in this codebase — no
  new charting dependency introduced.
- Download (real CSV export + real FileProvider share, reusing v113-129's
  `exportListAsCsv`/`shareStructuredCsv`) and Share (real text summary with the
  real numbers above, standard ACTION_SEND) — both genuinely working, not stubs.
  "Full Report" navigates to the existing real "reports" screen rather than
  duplicating it.

Verified before shipping: `ElectricCyan` confirmed a real existing theme color
(not assumed). `products` StateFlow confirmed as the exact real
`InventoryRepository.products` already used successfully elsewhere this session.
No duplicate declarations. Balance sweep vs pristine: NONE.

# ============================================================
# v113-132 — PHASE 10 + 12 (cross-module integration + financial/stock integrity)
# executed by real source-tracing, per the directive's Section 31 test scenarios
# ============================================================
Person asked for "all phases 100%". Phases 10 and 12 are genuinely doable by
tracing business EFFECTS through the source (which the directive explicitly asks
for: "validate BUSINESS EFFECTS, not only screen navigation"). Phase 14 (real
build) remains impossible in this sandbox — stated plainly rather than faked.

## DEALER end-to-end chain (Section 31) — traced, correct
- `createSalesInvoice` writes ONLY the invoice — no premature stock/ledger/due
  effect. Correct: effects belong at approval, not draft creation.
- `approveSalesInvoice` produces all four real effects in one place:
  warehouse stock OUT (InventoryRepository.adjustStock, MovementType.OUT),
  dealer due +net (dealerDao().adjustDueBalance), dealer-side stock increase,
  and a ledger DEBIT via postPartyLedgerEntry. Chain is complete, not partial.
- `verifyCollection` closes the loop: due -amount, invoice allocation when
  present, ledger CREDIT. Dealer and Retailer handled on separate real branches
  (not one collapsed path that would corrupt the other party type).

## Section 15 (financial integrity) — ONE canonical source confirmed
`postPartyLedgerEntry` is the single ledger-posting function; `balanceAfter` is
read from the actual Room row (`dealerDao().getById`), NOT from a cached
StateFlow — a race the codebase had already found and fixed ("Part M fix"), and
which this trace re-confirms is still correct. No competing UI-side balance
formula found. This satisfies the directive's explicit "do not calculate UI /
Repository / Report / Ledger balance with four unrelated formulas" rule.

## Section 16 (stock integrity) — the directive's strictest rule holds
"Never increase warehouse stock merely because a dispatch was created if the
business flow requires receiving confirmation." Traced
`dispatchWarehouseTransfer`: source warehouse OUT, then IN to a real IN_TRANSIT
system warehouse — destination stock is NOT touched at dispatch. Only
`receiveWarehouseTransfer` credits the destination. Correct, and the in-transit
bucket is genuinely tracked rather than stock vanishing between the two steps.

## Section 14 (sync/duplicate prevention) — 20 real idempotency guards
Counted across CollectionsEngine (2), CorrectionsEngine (2), ExpensesEngine (2),
InventoryRepository (1), MockRepository (10), PurchaseRepository (3) — each a
real status re-check before applying financial/stock effects, which is what
prevents duplicate posting on retry.

No code changes this entry — the traced chains were already correct, which is the
honest finding. Balance sweep: nothing edited.

# ============================================================
# v113-133 — PHASE 9 (universal search) + PHASE 11 (offline/sync) — found and
# fixed a REAL security leak in search; offline/sync verified correct
# ============================================================

## Phase 9 — real Section 19/11 security leak found and FIXED
`MockRepository.universalSearch()` filtered the raw company-wide
`dealers.value`/`retailers.value` lists directly, with no cascade scoping — so an
SR or ASM typing a name could surface, and tap through to, dealers/retailers
outside their own territory (search results route straight to
`statement/DEALER/{id}`). The directive names this exact leak twice: Section 19
("Do not expose unauthorized records through search suggestions") and Section 11
("UI hiding alone is NOT security — data access must also enforce the correct
scope"). The Territory/zone aggregate above it leaked the same way, and worse —
it summed a company-wide due figure per zone regardless of the viewer's scope.

Fixed by routing all three (Dealer results, Retailer results, Territory
aggregates) through the SAME already-real `visibleDealersFor()`/
`visibleRetailersFor()` functions the module list screens already use — reusing
the canonical scoping rule rather than writing a second parallel permission
check, per the directive's "search before creating anything / do not create a
second implementation" rule. Confirmed afterwards that no unscoped
`dealers.value`/`retailers.value` access remains anywhere inside the function.

## Phase 11 — offline/Firebase/sync verified, no changes needed
- **Offline policy is deliberate, not accidental**: only 7 genuinely
  irreversible/high-risk operations are online-gated (SalesInvoice approval,
  Collection verify, EmployeeProfile activation, WarehouseTransfer approval,
  Backup, Target, EmployeePermissionOverride) — every other business operation
  works offline, satisfying "do not make the application unusable merely because
  the internet is temporarily unavailable."
- **Duplicate-on-retry is structurally prevented**: every Firestore write uses
  `syncCollection(...).document(entity.id).set(entity)` — the entity's own
  deterministic ID, never an auto-generated one. A retry overwrites the same
  document rather than creating a second. Combined with the 20 idempotency
  guards verified in v113-132, this is what makes the "exactly-once effective
  synchronization" requirement of Section 14/31 hold.

Balance sweep vs pristine: NONE.

# ============================================================
# v113-134 — REAL COMPILE ERRORS from the person's GitHub Actions build, all 7
# fixed. Every one was mine, from this session.
# ============================================================
The real build finally ran and reported exactly what a source sweep could not.
All 7 errors traced to my own edits in this session — recorded plainly:

1-2. `MockRepository.kt:4572` / `:4786` — Argument type mismatch, String? vs
   String. `validateManagerAssignment()` returns `Pair<Boolean, String?>` and I
   passed its `reason`/`validationReason` straight into `onRejected(String)` in
   v113-112 (assignDirectManager, createTransferRequest). I read that function's
   return type at the time but not closely enough to catch the nullability.
   Fixed with a real fallback message on each, not `!!`.
3-6. `ChairmanHubScreen.kt:387/388/397/398` — Unresolved 'background'. My
   v113-131 bar chart uses `Modifier.background(...)`; the file imports
   `foundation.clickable` but never `foundation.background`. I checked
   `ElectricCyan` and `sp` were available and stopped there.
7. `CourierScreen.kt:249` + `RmsHomeScreen.kt:267` — Unresolved 'DangerRed'. I
   assumed a wildcard `theme.*` import; both files use explicit named imports and
   had no DangerRed. Added to both.
8. `DealersScreen.kt:2482` — Unresolved 'marketContext'. I referenced it in
   v113-113's createCompanyMarket wiring but never declared it. Declared now.
9. `ProductionWarehouseScreen.kt:389` — Unresolved 'wtContext'. Declared at line
   311 inside a different composable scope than the receive dialog at 389 — I
   checked "same when-block" for the dispatch site and wrongly assumed the
   receive site shared it. Given its own `receiveContext` in the correct scope.

## Then swept for siblings of each bug class, project-wide
- Undeclared Toast context vars anywhere: NONE remaining.
- Theme colors used without their explicit import (all non-wildcard files):
  NONE remaining.
- `onRejected(...)` passed a bare nullable: NONE remaining.
So the same three classes shouldn't reappear on the next run.

## Honest note on what this proves
The balance sweep, DAO verifier and field checks I ran all session are real and
caught real problems — but they cannot catch nullability, missing imports, or
Compose scope boundaries. The real compiler caught all three in 1m31s. This is
exactly why the directive's Section 32 says a source sweep is not a build, and
why I kept saying I couldn't claim compile-clean. Balance sweep vs pristine: NONE.

# ============================================================
# v113-135 — BUILD IS CLEAN (person confirmed errorless on v113-134). Continuing
# the remaining directive items: real SMS + WhatsApp handoff.
# ============================================================
Section 5 (DMS Message/CRM) and Section 6 (RMS Relation/CRM) both list SMS,
WhatsApp and call as required communication actions; the uploaded poster shows
them too. Only Call existed (real ACTION_DIAL). Added real SMS (ACTION_SENDTO
smsto:) and real WhatsApp (ACTION_VIEW https://wa.me/<intl>) beside it, for both
Dealer and Retailer detail screens — plain Intents to the device's own apps, so
these need no backend or API key and are genuinely functional, NOT a
"configuration required" placeholder. Each has its own real failure path (no SMS
app installed / WhatsApp not installed), matching the existing Call action's
try-catch + Toast pattern already in the file rather than inventing a new one.
BD number normalization (0-prefix → 88…) is real string handling, no fabrication.

## Icon safety — learned directly from last round's build failure
Wanted Icons.Filled.Sms / .Chat. Rather than assume they exist in this project's
icon artifact, checked the PRISTINE copy (the last state that actually built
clean): neither appears anywhere, nor does .Email. Only `Send` and
`MarkunreadMailbox` are proven present in a green build, so those are what
shipped. This is exactly the "unresolved reference" class that broke v113-133 —
verified against a known-good build instead of assuming.

## Found and fixed a real flaw in my OWN balance-sweep tool
The sweep flagged DealersScreen as +3 parens. Investigated rather than trusting
it: the tool stripped `//` comments BEFORE string literals, so the `//` inside
`"https://wa.me/$intl"` was treated as a comment start and ate the rest of the
line including its closing parens. Re-ran with strings stripped first (correct
order) — proj and orig both balance at exactly 0/0, so the file was always fine
and the tool was wrong. Corrected sweep re-run across the whole project: all
files clean. Worth recording because every "balance: NONE" earlier in this
session used the flawed order — it could only ever produce FALSE ALARMS on lines
containing URLs (never false clean), so no earlier result is invalidated.

# ============================================================
# v113-136 — PHASE 13 (UI consistency) — measured first, then fixed only what was
# genuinely inconsistent
# ============================================================
Rather than "polish" by feel, measured consistency across the five module homes:

## What was ALREADY consistent (verified, left alone)
- All five module homes use the same `ModuleDrawerScaffold` — one navigation
  shell, no module inventing its own.
- Titles follow one naming pattern ("<X> Management System" / "Full Control
  Center").
- Browse-list capability flags differ per entity (Dealer/Retailer have
  Ledger+90-Day, Employee/Product don't) — checked the reasoning: this is the
  DELIBERATE, already-documented call that employees/products aren't
  money-bearing parties, so those drill-downs would have no real data behind
  them. Making them uniform would mean adding dead buttons — the opposite of the
  directive's "no dead buttons" rule. Correctly NOT changed.

## What was genuinely inconsistent — fixed
Empty states: a shared `WorkspaceEmptyState` component exists (icon chip + one
centered sentence) and is used in 13 files, but 97 raw `Text("...নেই")` calls
exist app-wide. Rather than mass-rewriting all 97 (exactly the kind of sweeping
change that broke the build two rounds ago), I checked each one in the two
measured-inconsistent module homes and converted only the ones that are
genuinely LIST-LEVEL empty states — RMS's retailer list and complaint list.

Deliberately NOT converted, after reading each in context: RMS's
dropdown-internal hint, its TSM "no memo to approve" branch message, its
"এখনো তথ্য নেই" inline stat line, and Chairman's "কোনো soft-deleted রেকর্ড নেই"
— that last one is intentionally SuccessGreen because for a restore console,
nothing deleted is good news, not an empty-list failure. Converting these to a
centered 32dp-padded empty-state block would have been visually wrong and would
have destroyed real meaning. Measured, judged individually, not batch-replaced.

Balance sweep (corrected strip order): NONE.

## Phase status after this entry
Phases 1-13 complete to the extent source work allows. Phase 14 partially
complete: v113-134 built ERRORLESS on the person's real CI (first fully green
build of this session). v113-135 and v113-136 add real changes on top of that
green build and have NOT yet been compiled — that verification is the remaining
step, and cannot be done from here.

# ============================================================
# v113-137 — Answering the person's direct question by CHECKING each feature.
# Found a real §27 violation (fake courier API) and a genuinely missing feature.
# ============================================================
Person asked whether login, courier API, raw material, employee/dealer/product
add-edit actually work. Checked each rather than answering from memory:

## Login — REAL and genuinely strong (no change needed)
`verifyUserAccountPin`: PBKDF2 hash verify (PinHashing.verify), real lockout
counter persisted in Room, every attempt written to loginAttemptDao, a real
SecurityEvent raised on lockout, and deliberately identical failure text for
"wrong PIN" vs "no such account" (anti-enumeration). Weak-PIN rejection exists on
change. This is real auth, not a demo check.

## Courier API — REAL §27 VIOLATION FOUND AND FIXED
No courier API is integrated (bookShipment's own comment admits the tracking id
is a local placeholder). But the UI showed "API connected" in green for couriers
flagged hasApi, and a "🔄 Refresh API status" button whose backing function
(`refreshShipmentStatus`) simply advanced the shipment one stage locally — no
network call anywhere. That is exactly the directive's "fake tracking" /
"placeholder buttons" prohibition, and it would mislead a real user into telling
a customer their parcel had moved. Fixed:
- Renamed to `advanceShipmentStageManually`, with a real permission check, a real
  "already at final stage" rejection, and a real audit entry (none existed).
- Button now reads "▶ Advance stage (manual)".
- Badge now reads "API-ready (integration not configured)" in amber, not
  "API connected" in green.
- Footer text now states plainly that no courier API is connected, the ref is
  internal only and won't work on the courier's own site — the "surface that
  configuration is required" boundary §27 asks for.

## Product EDIT — genuinely missing, now implemented
Directive §9 requires Chairman Product Control to "add, EDIT, deactivate".
`ProductDao.upsert` existed but NO repository function exposed editing — a
Chairman could create and soft-delete a product but never correct its
name/price/category/unit. Added `updateProduct(...)` with: real inv-EDIT
permission check, blank/negative validation, dedup check that correctly EXCLUDES
the product's own row (so re-saving unchanged isn't blocked by its own key), and
a real audit entry carrying before→after name and price so a price change is
traceable. Caught mid-write that `Product.toEntity()` does NOT exist in this
codebase (verified, not assumed) — built ProductEntity directly instead, mirroring
addProduct's real construction and preserving photo/barcode/category/brand/creator
fields the edit form doesn't expose rather than blanking them.

## addProduct — vague-rejection gap the earlier sweep missed
It returns Unit (not Boolean/nullable), so the backlog scanner's pattern never
matched it; all 4 rejection points were silent. Added onRejected, positioned
BEFORE the existing `onCreated` trailing lambda so every current call site still
compiles (verified: the one wrapper passes all args by name).

## Raw material / dealer add / employee add — confirmed real, unchanged
issueRawMaterial (5 real rejection points, stock+warehouse-category validated),
createDealer and createEmployeeDraft (both real, both already carrying full
onRejected coverage from earlier batches).

Balance sweep: NONE. No stale callers of the renamed courier function.

# ============================================================
# v113-138 — UX batch 1 of the person's list: wasted header space, QR two-tap +
# landscape, portrait lock everywhere
# ============================================================
Person gave a long UX list. Taking it in small verified batches rather than all at
once, because the last sweeping multi-file change is what broke the build.

## 1. Header no longer eats screen space inside modules — FIXED
The ABM badge / name / post TopAppBar lived in MainActivity's Scaffold, so it
rendered on EVERY route — dashboard, module home, and every feature screen inside
it. Inside a module that strip is pure loss: the person already read it on the
dashboard, and each module draws its own contextual header anyway via
ModuleDrawerScaffold. Now shown only when the current route is Dest.Dashboard.
Work screens get the full height, exactly as asked.

## 2. QR is now ONE tap, and portrait-locked — FIXED
- Tapping any QR entry point opened a landing page that itself had a "Scan QR"
  button — two taps to reach the camera. The camera now launches automatically
  on entry (LaunchedEffect + rememberSaveable guard so it fires once, not again
  on every recomposition/rotation). The screen underneath remains as the RESULT
  view, and its button is relabelled "আবার স্ক্যান করুন" (scan again), which is
  what it now genuinely is.
- Every scanner used setOrientationLocked(FALSE) — tilting the phone flipped the
  camera to landscape, which is wrong for a QR held in front of you. Locked to
  portrait in all 3 places (UniversalScannerScreen + the 2 in DealersScreen), so
  every QR entry point in the app now behaves identically.
- Introduced one shared `abmScanOptions()` so the config lives in a single place
  instead of each call site re-specifying it.

## Verified before shipping (lesson from the build that failed)
setPrompt/setBeepEnabled/setOrientationLocked all confirmed present in the
PRISTINE copy (last known-green build). Wanted setDesiredBarcodeFormats with
ScanOptions.QR_CODE constants — NOT proven anywhere in this project, so removed
rather than guessed; the scanner reads all formats by default so nothing is lost.
`rememberSaveable` needed its own import (runtime.saveable, not covered by the
runtime.* wildcard) — added, not assumed. Balance sweep: NONE.

## Deliberately NOT done in this batch, and why
Courier API paste-slot: CourierPartnerEntity has no field to hold a key, so this
needs a Room schema change + migration. Not bundling a migration into a batch
that already has 3 behavioural changes — a migration mistake risks real data,
unlike a UI mistake. Next batch, on its own.

## Still open from the person's list (named, not dropped)
Invoice/memo: dealer location + product-add inside the workspace but NOT on the
printed output; edit/draft for invoice and memo. Module dashboards: KPI graphics.
Chairman: reference-image layout. Search: location result → that geo's KPI +
sales + dealer/retailer/employee A2Z. Login: remember the number, ask only PIN
next time, remove fingerprint.

# ============================================================
# v113-139 — UX batch 2: login (PIN-only return, no fingerprint), module
# dashboard KPI graphics
# ============================================================

## Login — fingerprint removed, number remembered
- Removed the optional "Fingerprint / Face unlock" button and its error line, as
  asked. Deliberately did NOT rip out the biometric machinery: the MANDATORY
  biometric phase for strict/privileged accounts is a separate security path that
  was never part of the request, and it still references those helpers (verified
  9 remaining references — no dead code left behind).
- Added `getRememberedMobile`/`saveRememberedMobile` to SessionPrefs, matching
  that file's existing read/write pattern exactly. Saved ONLY at
  `finalizeSuccessfulLogin` — the single confirmed-success point — so a failed,
  blocked or pending attempt never remembers a number. Cleared inside
  `clearLastLoggedInAccount`, so logout on a shared phone doesn't leak the
  previous user's number.
- After the intro, a device with a remembered number now goes straight to the PIN
  pad. Guarded a real edge case while writing it: the flow sets `phase = "mobile"`
  BEFORE resolving, so if the saved number no longer resolves (employee
  deactivated, account locked, number reassigned) the person lands on the normal
  mobile screen with the error visible instead of being stranded on a blank intro
  with no way forward.
- The PIN itself is still fully verified against the PBKDF2 hash every time —
  remembering the number is convenience, not a credential shortcut.

## Module dashboard KPI graphics
Extracted the v113-131 weekly bar chart out of ChairmanHubScreen into a shared
`core/DualSeriesBarChart.kt`, so all five module dashboards can carry the same
real chart instead of five near-identical copies. Chairman now calls the shared
one (0 stale references left). Added it to the DMS dashboard with real weekly
Sales-vs-Collection buckets computed from real invoices/collections, scoped to
the dealers already in that user's cascade — and it renders only when there is
actually data, so an empty install shows no empty chart frame.

Verified every field touched against its real declaration before use
(SalesInvoice.dealerId/createdAt/lineItems/isDeleted, PartyCollection.partyId/
status/amount/createdAt) — the exact assumption class that broke an earlier build.
Balance sweep: NONE, including the newly created file.

## Still open from the person's list
Invoice/memo: dealer location + product-add in the workspace but NOT on the
printed output; edit/draft for both. Courier API paste-slot (needs a Room
migration — kept separate on purpose). Chairman reference-image layout. Search
location result → that geo's KPI + sales + dealer/retailer/employee A2Z. KPI
graphs on the remaining three module dashboards (RMS/HR/FMS) now that the shared
component exists.

# ============================================================
# v113-140 — KPI graphic now on ALL FIVE mother-module dashboards
# ============================================================
Each uses the SAME shared `core/DualSeriesBarChart` (extracted in v113-139), and
each shows the series that actually fits that module rather than forcing one
metric everywhere:
- DMS: Sales vs Collection (real invoices/collections, dealers in cascade scope)
- RMS: Memo vs Collection (real RetailOrder/collections, retailers in scope)
- HR: Leave Approved vs Pending
- FMS: Planned vs Produced
- Chairman: Sales vs Collection (already present, now on the shared component)
All render ONLY when there is real data, so an empty install shows no empty chart
frame.

## Three real errors caught BEFORE compiling, by checking the model each time
1. FMS: wrote `plan.producedQuantity` — read ProductionPlan's real declaration
   and that field does NOT exist. Actual output lives on
   `FinishedGoodsReceipt.quantity`, joined by `productionPlanId`. Rewrote against
   the real source.
2. HR: wrote `MockRepository.attendanceRecords` — no such app-wide StateFlow
   exists (only the per-employee `attendanceRecordsFor(id)` query). Rather than
   invent an aggregate, switched HR's chart to real leave-request data, which HR
   genuinely has at dashboard level.
3. RMS: `RetailOrder.retailerId` is NULLABLE — older orders carry only
   `retailerName`. Matched this file's own existing name-fallback instead of
   silently dropping those orders from the chart.
Also: str_replace refused an ambiguous anchor in HrHomeScreen (the same
`Spacer(...)` appears twice) — used a unique anchor rather than forcing it.

## Balance sweep caught a real brace error again
RmsHomeScreen came back +1 brace: my replacement had dropped the `if` block's
closer. Found and fixed before shipping. Final sweep across the project: NONE.

## Still open from the person's list
Invoice/memo: dealer location + product-add in the workspace but NOT on the
printed output; edit/draft for both (the biggest remaining item). Courier API
paste-slot (needs a Room migration, kept separate deliberately). Chairman
reference-image layout. Search location result → that geo's KPI + sales +
dealer/retailer/employee A2Z.

# ============================================================
# v113-141 — Invoice workspace: dealer location + in-place product add
# ============================================================

## Dealer location inside the invoice — added
Checked the model first: `Dealer` has NO lat/lng (only Retailer does), just
`address`. So rather than fabricate coordinates, this shows the real address with
a "Map" action that opens a Maps SEARCH on it, reusing the exact intent +
fallback chain DealersScreen's navigate button already uses (Google Maps →
generic geo: → honest "Maps app পাওয়া যায়নি" Toast). Hidden entirely when the
dealer has no address, so there's never a button that can't do anything.

## "+ New Product" inside the invoice — added
A missing product used to force the person out of the half-built invoice. Now a
real dialog in the product panel, wired to the genuine
`InventoryRepository.addProduct` (the same engine Inventory uses) with its real
duplicate/permission/validation rejections surfaced inline — this is exactly why
addProduct got its `onRejected` in v113-137. On success `onCreated` closes the
dialog and the product is immediately selectable, because the workspace already
observes `InventoryRepository.products` as a StateFlow.
Permission-gated: the button only appears for someone who genuinely holds
inv-CREATE, since a button that could only ever reject them is worse than no
button.

## The person's specific objection — verified, not just asserted
They said an "add product" button appearing on the real printed invoice/memo
would look wrong. Confirmed it cannot: the printed/PDF invoice is generated in
`StructuredExports.kt` by drawing directly onto a PDF Canvas, and that entire
file contains ZERO Button/TextButton/onClick occurrences (grep-verified). The
workspace UI and the printed document are completely separate render paths, so
workspace controls can never leak onto the output document.

Balance sweep: NONE. DangerRed confirmed already imported in this file before use.

## Still open from the person's list
Invoice/memo EDIT + DRAFT (the remaining half of this item), the same
location/product-add treatment for the RMS memo workspace, courier API paste-slot
(needs a Room migration), Chairman reference-image layout, and search location
result → that geo's KPI + sales + dealer/retailer/employee A2Z.

# ============================================================
# v113-142 — Invoice EDIT surfaced, memo location added, and a silent
# rejection path closed
# ============================================================

## Invoice edit — the engine already existed, the access didn't
Found `updateSalesInvoice` already implemented and careful (it refuses to edit an
APPROVED or partly-paid invoice, because that would leave a payment allocated
against a total that no longer matches). It was reachable ONLY from
SalesChainScreen — not from the invoice workspace, which is where a person
actually notices a mistake right after creating one.
- Added an "✏ Edit" action to the workspace's invoice list, shown only when the
  invoice is genuinely still editable (PENDING and paidAmount <= 0) — the exact
  condition the engine enforces, so the button never appears just to be refused.
- It routes to `sales?tab=2`, the Invoice tab that already owns the real edit
  form — no second editing UI. Verified first that `sales_chain?editInvoice=`
  does NOT exist as a route rather than shipping a button pointing at nothing.
- `updateSalesInvoice` had 3 silent rejection paths and NO permission check at
  all (it predates the vague-rejection sweep, and its name/return shape meant the
  scanner never flagged it). Added a real bill-EDIT permission check plus specific
  reasons for locked-period, approved, and partly-paid — the last two now say
  which one it was and point at Return/Credit-Note. Wired the existing
  SalesChainScreen caller, replacing a hardcoded message that was simply wrong for
  the permission and locked-period cases.
- Also caught the workspace's Approve button discarding its rejection reason
  entirely — now reports it inline.

## On "draft" — no new status invented
An invoice already sits at PENDING with zero stock/ledger/due effect until
approval; that IS the draft state. Adding a separate DRAFT status would mean a
Room migration and a second half-committed state to reason about, for no
behaviour the person doesn't already have. Made PENDING genuinely editable
instead.

## Memo workspace — retailer location added
Unlike Dealer (address only), Retailer genuinely has lat/lng, so this gives real
turn-by-turn navigation when a GPS fix was captured and falls back to an address
search when it wasn't — labelled "Navigate" vs "Map" so the person knows which
they're getting. Hidden entirely when there's neither. Same proven intent chain
as DealersScreen.

Verified before shipping: SalesInvoice.paidAmount, Retailer.address/lat/lng all
confirmed against their real declarations. Balance sweep: NONE.

## Still open
Product-add inside the RMS memo (invoice has it; memo's product panel is
structured differently and needs its own read), courier API paste-slot (Room
migration), Chairman reference-image layout, search location → geo KPI/report.

# ============================================================
# v113-143 — Product-add in the memo, and the location/territory screen completed
# ============================================================

## RMS memo — in-place product add
Same treatment as the invoice workspace (v113-141): permission-gated "+ New
Product" in the product panel, opening a real dialog wired to the genuine
`InventoryRepository.addProduct` with its real rejection reasons surfaced inline.
Matters more here than in DMS — an SR writing a memo in the field can't leave to
go create a product. Workspace only; the printed memo is a separate render path
with no controls.

## Location/territory screen — checked what was actually missing before adding
The person said the search→location page "valley lge na". Read it rather than
rebuilding: it ALREADY had area KPIs (dealers, retailers, total due, over-limit,
7-day sales), a sales trend graph, a collection trend graph, product-wise sales
with share bars, a dealer list and a retailer list. So it wasn't empty — the one
thing genuinely absent from what they asked for ("employee a2z oi specific
area") was the EMPLOYEE list. Added exactly that, matching the existing
EnterpriseListRow style, rather than replacing a screen that was mostly right.

Employees are matched on region/area/branch, because EmployeeProfile has no
single "zone" field — checked the model instead of inventing one.

## Everything verified against source before shipping
EmployeeProfile.region/area/branch/hasActiveAccess (real, hasActiveAccess is a
computed property not a stored field), Icons.Filled.Person (proven present in the
last green build), `hr_module?key={key}` route accepts the parameter, and
"employees" is a real drawer key with a real handler — so the row's tap target is
not a dead link. material3 wildcard import covers Surface/Button/TextButton in
RmsMemoWorkspace. Balance sweep: NONE.

## Still open from the person's list
Courier API paste-slot (needs a Room migration — deliberately kept out of mixed
batches), and the Chairman reference-image layout.

# ============================================================
# v113-144 — Courier API paste-slot (DB v75 → v76, the migration kept deliberately
# alone in its own batch)
# ============================================================
Held back from v113-138 on purpose: a migration mistake risks real data in a way
a UI mistake doesn't, so it got its own batch with nothing else mixed in.

## Schema change — additive only, chain re-verified
- `CourierPartnerEntity` gains `apiBaseUrl` and `apiKey`, both nullable TEXT, so
  every existing courier row migrates untouched.
- `MIGRATION_75_76` adds exactly those two columns — column names and types match
  the entity exactly (Room validates this at open time and crashes on mismatch).
- Version bumped 75 → 76 and the migration registered, all in one step.
- Re-ran the migration-chain verifier: 53 migrations, 23 → 76 continuous, ZERO
  gaps, nothing defined-but-unregistered, nothing registered-but-undefined, and
  the top migration reaches the declared version. Full DAO sweep also re-run —
  only the long-known changelog-comment false positive.
- Domain model `CourierPartner` and its single mapper extended together, so the
  fields actually reach the UI (checked there was exactly one construction site).

## The slot itself
Chairman-only, both in `setCourierApiConfig` and on the button that opens it, so
it never appears for someone it would only refuse. `hasApi` is now DERIVED from
whether both fields are actually filled, instead of being a flag someone could
set without any config behind it. Clearing is supported. The API key is never
written into the audit trail — only the fact that config changed.

## Kept honest about what saving a key does (§27)
The dialog states plainly that saving stores the configuration but that the live
courier connection is still not implemented and tracking remains manual. The row
badge says "API config saved (integration not active)" rather than anything that
implies live tracking appeared the moment a key was pasted. This is the
"implement the correct integration boundary and surface that configuration is
required" behaviour the directive asks for, instead of fabricating a working
integration.

## Verified before shipping
CourierDao has NO singular upsert (only upsertAll) — checked and used upsertAll
rather than assuming. `couriers` confirmed in composable scope for the dialog.
Balance sweep: NONE.

## Remaining from the person's list
Only the Chairman reference-image layout.

# ============================================================
# v113-145 — Chairman module matched to the reference layout (last item on the
# person's list)
# ============================================================
Compared the Chairman drawer against the reference poster's Chairman column
rather than rebuilding it: 12 of the 14 listed areas already existed and were
already wired. Exactly two were missing, and both were real gaps:

## Product Control — was genuinely absent
The reference lists product master control (name/category/rate/status — add,
EDIT, activate/deactivate) as a Chairman area. There was no such screen anywhere,
so a Chairman could not correct a product's name or price from their own module.
Built `ChairmanProductControl`:
- Uses the real `InventoryRepository.updateProduct` (added v113-137, which is
  exactly why that gap mattered) plus the existing `deleteProduct`. No new
  product engine.
- Reads the SAME `InventoryRepository.products` flow every other module uses —
  NOT a second product master, so an edit here is immediately visible in
  invoice, memo, inventory and FMS.
- "Deactivate" is the repository's soft delete, never a hard delete, because
  products are referenced by historical invoices (directive's delete policy).
  Restore already exists in Master Controller.
- Chairman-gated at the composable itself, matching every sibling screen's
  defense-in-depth pattern, and every rejection surfaces its real reason.

## Support / Helpdesk — screen existed, entry point didn't
`HelpdeskScreen` was already a real screen reachable only from the global
overflow menu. Added the Chairman drawer entry the reference shows. Verified its
signature is no-arg before wiring it.

## Verified before shipping
Both icons (Inventory2, HelpOutline) confirmed present in the PRISTINE last-green
build, not assumed. Product.costPrice/reorderThreshold/isActive checked against
the real model. LazyColumn/items/verticalScroll/rememberScrollState imports all
already present in the file. Checked the inserted @Composable didn't duplicate
the following function's annotation. Drawer verifier re-run: 16 items, ZERO
unrouted — no dead menu entries. Balance sweep: NONE.

## The person's UX list is now complete
Header space, one-tap portrait QR, PIN-only return login with fingerprint
removed, KPI graphics on all five dashboards, invoice dealer-location +
product-add + edit, memo location + product-add, search location → full geo
report incl. employees, courier API paste-slot, and the Chairman layout. The
remaining honest gaps are unchanged and previously named: no live courier API
integration (config stores, tracking stays manual), and Import-Excel / Bulk-SMS
broadcast are still not built.

# ============================================================
# v113-146 — Import implemented for real. Honest assessment of the other two gaps.
# ============================================================
Person asked to complete the three remaining gaps. Checked what each genuinely
requires before starting, rather than half-building all three.

## 1. Import — BUILT, real
New `core/CsvImport.kt` + an `importCsv` hook on BrowseConfig + an "Import (CSV)"
action in the browse-list's More Actions panel, wired for Dealers first.
- Reuses the file-picker contract (`GetContent`) already proven working elsewhere
  in this app, not a new mechanism.
- The CSV parser honours quoted fields and doubled quotes exactly the way
  `escapeCsvField` writes them, so a sheet EXPORTED by this app, edited in Excel
  and saved back as CSV, round-trips without a comma inside a name splitting the
  row.
- Columns are matched BY NAME, case-insensitively — column order can differ and
  extra columns are ignored, instead of a shifted column silently corrupting
  every record. A missing required column is a named fatal error, not a partial
  import.
- Each row is passed to the SAME real `createDealer` the manual form uses, so
  permission, duplicate and validation rules are identical for imported and typed
  records. That's what makes the per-row result honest.
- Result dialog reports total / added / skipped AND lists every failed row with
  the real reason its create function gave. A bulk import that only says
  "12 imported" hides which 3 failed and why; this doesn't.
- The button appears only for entities that actually have an import path
  (`importCsv != null`) — no dead menu item on the others.

**Stated plainly in the code:** this reads CSV, not binary .xlsx. Real .xlsx
parsing needs Apache POI, which is not a dependency here, and accepting a renamed
file would fail confusingly at run time. Every spreadsheet tool exports CSV, and
this app's own export is CSV, so that's the format that genuinely round-trips.

## 2. Live courier API — NOT built, and here is the honest reason
Checked the dependencies: this project has NO HTTP client at all (no OkHttp, no
Retrofit, no Ktor). Beyond that, a courier integration needs the specific
courier's endpoint paths, auth scheme and response JSON shape — Pathao, Steadfast,
RedX and Sundarban all differ. Writing a client against a guessed contract would
produce code that compiles, looks finished, and fails on first real use, which is
worse than the current honest state. What EXISTS is the correct boundary: the
config slot stores the credentials (v113-144) and the UI says plainly that the
live connection isn't active and tracking stays manual. Completing this needs a
decision from the person (which courier) plus their API docs — then it's a real,
bounded task.

## 3. Bulk SMS — NOT built this batch, honest reason
Android does not allow an app to silently send SMS to many recipients without the
SEND_SMS permission, and Play Store policy restricts that permission to apps
whose core function is messaging — this app would likely be rejected for
requesting it. The workable, policy-safe version is a multi-recipient handoff
that opens the device's SMS app pre-filled, which is real but is a different
thing from "the app sends them". Worth doing, but it deserves its own batch and a
clear explanation to the person about what it will and won't do, rather than
being slipped in beside an import feature.

Verified before shipping: Icons.Filled.UploadFile is NOT proven in the last green
build (nor CloudUpload) — used Icons.Filled.Add, which is already used in this
exact file. CsvImport is same-package so needs no import. createDealer confirmed
`suspend`, matching the suspend hook. Balance sweep: NONE.

# ============================================================
# v113-147 — Photo slots audited; Dealer's missing one added (DB v76 → v77).
# FMS checked against the reference — already matches.
# ============================================================

## Photo slots — checked each, found exactly one real gap
- Product: `photoUri` — EXISTS
- Retailer: `photoUri` (shop front) + `ownerPhotoUri` — EXISTS, two of them
- EmployeeProfile: `profilePhotoUri` — EXISTS (with a real
  `employeeProfileDao.updateProfilePhoto`)
- **Dealer: NOTHING.** The only party entity in the app with no photo field at
  all, despite the reference showing dealer photos. Added it.

Full stack wired so it can't drift: DealerEntity gains nullable `photoUri`,
domain `Dealer` gains it, BOTH mapper directions carry it (toDomain and
toEntity — checked both existed), `createDealer` accepts it (positioned BEFORE
`onRejected` so existing trailing-lambda callers still compile), the constructed
Dealer passes it, and the registration form got a real photo picker using the
same GetContent + coil pattern the product form already uses.

MIGRATION_76_77 adds one nullable TEXT column to `dealers` — table name verified
against the entity's own @Entity annotation, not assumed. Chain verifier re-run:
54 migrations, no gaps, nothing unregistered, top migration reaches version 77.

## FMS vs the reference — already matched, nothing to change
Compared the FMS drawer item by item: Dashboard, Raw Material, Production,
Product List, Quality Control, Send to Warehouse, Warehouse Stock,
Damage/Wastage, Factory HR, Purchase/GRN, Expense, Complaint Box, Reports — all
13 present and all routed (verified earlier by the drawer verifier). No work
needed, which is the honest answer rather than inventing changes.

## Two real errors caught before compiling
1. `.clip()` was used in the new picker but `androidx.compose.ui.draw.clip` was
   NOT imported in DealersScreen (it's used nowhere else in that file) — added.
2. str_replace refused an ambiguous anchor: `var adminSelection by remember` appears
   in BOTH the dealer and retailer forms. Targeted the dealer form by line instead
   of forcing it, which would have put the dealer's photo state in the retailer form.
Also verified coil is a real dependency (io.coil-kt:coil-compose:2.6.0) before
relying on rememberAsyncImagePainter. Balance sweep: NONE.

# ============================================================
# v113-148 — Real build errors fixed. All three were mine, all from insertion
# mistakes rather than logic mistakes.
# ============================================================

## 1. ChairmanHomeScreen.kt:367 — "This annotation is not repeatable"
My v113-145 insert placed the new ChairmanProductControl block BETWEEN
ChairmanNoticeBoard's `@Composable` and its `fun` line, so that orphaned
annotation ended up stacked on top of my function's own — two @Composable on one
function. I DID check for this at the time and concluded it was fine; the check
was wrong because it only looked at the line directly above the `fun`, not at
what my insertion had orphaned above the doc comment. Removed the orphan;
verified both functions are now annotated exactly once.

## 2. CourierScreen.kt — ~12 unresolved references, all one root cause
My v113-144 paste-dialog landed inside `VehicleTrackingTab`, not inside
`CourierScreen`, because I anchored on "the closing braces at the end of the
composable" and matched the wrong function's. `configuringCourierId` and
`couriers` are declared in CourierScreen, so from VehicleTrackingTab every single
reference was unresolved — which is why one placement mistake produced a dozen
errors. Extracted the block by brace-matching and reinserted it inside
CourierScreen, then verified by brace-matching (not by eye) that the dialog now
sits between the function's real start and real end.

## 3. DealersScreen.kt — 3 missing imports
The v113-147 photo picker used `.background()`, `Color(...)` and `.sp`, none of
which this file imported (it had `clickable` and `Image` but not these). I
checked `clip` last round and added it, but stopped there instead of checking
every symbol the new block used.

## Swept all three classes project-wide so siblings don't surface next build
- Missing imports for background/Color/sp/clip across every file: NONE remaining.
- Duplicate or orphaned @Composable anywhere: NONE.
- Balance sweep vs pristine: NONE.

## Honest note
Every error this round came from WHERE code was placed, not what it did — and
the balance sweep can't catch that, because a block pasted into the wrong
function still balances perfectly. Brace-matching to confirm the enclosing
function is the check that would have caught #2, and I've now used it. That's the
lesson worth keeping, not "be more careful".
