# প্রজেক্টের নিয়ম ও বর্তমান অবস্থা (PROJECT_NOTES.md)

এই ফাইলটা প্রজেক্টের সাথেই থাকে — নতুন চ্যাট শুরু করলেও এই ফাইলটা Claude-কে
দেখালে (বা এই ফোল্ডার আপলোড করলে) ও সাথে সাথে পুরো নিয়ম আর এখন পর্যন্ত কী
হয়েছে বুঝে যাবে।

## কাজের নিয়ম (workflow) — এটাই সবচেয়ে জরুরি
1. যেকোনো **নতুন মডিউল/ফিচার/মডিফিকেশন** → প্রথমে **JSX প্রোটোটাইপে** বানাতে
   হবে (দ্রুত visual দেখে ঠিক করার জন্য, ক্লিক করলেই preview হয়)।
2. ব্যবহারকারী (মালিক) JSX দেখে approve করলে, **তারপরই** সেটা **Kotlin/
   Jetpack Compose**-এ কনভার্ট হবে।
3. কখনো সরাসরি Kotlin-এ নতুন/অপ্রমাণিত ফিচার বানানো হবে না — JSX ধাপ বাদ
   দেওয়া যাবে না।
4. প্রতিবার Kotlin প্রজেক্ট দেওয়ার সময় **পুরো প্রজেক্ট নতুন করে zip** করে
   দেওয়া হয় (আলাদা টুকরো/প্যাচ না) — ব্যবহারকারী পুরনো ফোল্ডার মুছে নতুন
   zip extract করে Android Studio-তে খোলেন।
5. ব্যবহারকারী কোনো কোডিং জানেন না এবং শিখতেও চান না — শুধু copy-paste +
   Sync + Run করবেন। তাই প্রতিটা ডেলিভারি নিজে থেকেই সম্পূর্ণ/build-যোগ্য
   হতে হবে, আর কোনো ম্যানুয়াল কোড-এডিট করতে বলা যাবে না।
6. Error এলে ব্যবহারকারী শুধু error message কপি করে পাঠাবেন — Claude সেটা
   দেখে ঠিক করে নতুন zip দেবে।

## Firebase (সেটআপ হয়ে গেছে)
- প্রজেক্ট: **abm-corporation** (project_number 114190194137)
- `app/google-services.json` এ আসল কনফিগ বসানো আছে — এটা প্রতিটা zip-এ
  এমনিতেই থাকবে, নতুন করে বসাতে হবে না
- Firestore + Anonymous Authentication চালু করা আছে ব্যবহারকারীর কনসোলে
- Security rules: `firestore.rules` ফাইলে আছে (ইতিমধ্যে console-এ paste করা)
- এখন যা Firestore দিয়ে সিঙ্ক হয় (v48-v55): Complaint Box, Vacant Positions,
  Sales Chain, Dealer, HR (Attendance/Payroll), Ledger, Inventory/Product,
  Warehouse, Stock Movement/Level, CRM Campaign, Task, Approval, Courier,
  Shipment, Sales Invoice, **Audit Log** (নতুন — v55), **Role-claim
  enforcement** Cloud Function (`functions/index.js`, deploy করার জন্য
  দেখুন `DEPLOY_CLOUD_FUNCTION_BN.md`)। বাকি নেই — সব module-ই এখন sync হয়।

## Multi-tenant architecture (গুরুত্বপূর্ণ — Foundational কাজের ধাপ ১/৪ সম্পন্ন)

## Geo hard-block (৫০ কিমি) — SR/TSM/ASM/RSM
LocationAnomalyChecker.isTooFarToLogin() — নিজের এলাকা (SR/TSM/ASM: জেলা,
RSM: বিভাগ) থেকে ৫০ কিমি-র বেশি দূরে হলে login-ই সম্পূর্ণ হবে না (soft flag
না, hard block — Login Log-এও "Failed" হিসেবে যায়)। ৬৪ জেলার approximate
centroid যোগ হয়েছে (district সদর শহরের কেন্দ্র, সঠিক polygon-সীমানা না —
"100% accurate লাগবে না, motamuti controlled thakle hobe" মেনেই)। এই একই
change-এ একটা logic bug নিজেই ধরে ঠিক করেছি: আগে unlock-device/save-last-
employee/attendance-check-in এই side-effect গুলো geo-check-এর **আগেই**
চলে যেত, আর একই login attempt-এর জন্য দুইবার (একবার সফল, একবার ব্যর্থ)
log হতো — এখন geo-check সবার আগে হয়, block হলে কোনো side-effect চলে না।

## Login flow — Designation → Area → PIN (blind PIN lookup বাদ)
এখন PIN দেওয়ার আগে: **পদবী বেছে নিন** → **এলাকা বেছে নিন** (পদবী অনুযায়ী
ধাপ কমবেশি — SR/TSM/ASM: বিভাগ+জেলা, RSM: শুধু বিভাগ, DSM: zone, NSM+:
কিছুই না) → **PIN** (এখন শুধু "এই নির্দিষ্ট মানুষটাই কিনা" যাচাই করে,
পুরো ডাটাবেস ঘেঁটে খোঁজে না)। Employee ID প্যাটার্ন: `SR-{district}`,
`TSM-{district}`, `ASM-{district}`, `RSM-{division}`, `DSM-{zoneName}`,
আর NSM/AGM/GM/MD/Chairman-এর জন্য fixed ID (`CHAIR-1` ইত্যাদি) —
`resolveEmployeeId()` ফাংশনে (LoginScreen.kt) এই লজিক আছে।

**মনে রাখবেন:** NSM/AGM/GM/MD পদের জন্য EMPLOYEE_DIRECTORY-তে কোনো real
employee record নেই (শুধু Chairman-এর আছে) — তাই এই ৪টা পদ বেছে নিলে
"no demo PIN" বার্তা দেখাবে, এটা bug না, ইচ্ছাকৃত (demo data-এর সীমাবদ্ধতা)।
Firestore-এর সব collection (companies রেজিস্ট্রি বাদে) এখন
`companies/{companyId}/...` — নেস্টেড। এটাই আসল isolation boundary, একটা
কোম্পানির ডেটা আরেকটা কোম্পানি কখনো query করেই পাবে না।

- `FirebaseSync.currentCompanyId` — এই ডিভাইস কোন কোম্পানির সাথে যুক্ত
- `FirebaseSync.startCompanyScopedListeners(companyId)` — Company Code
  validate হওয়ার পরে (বা app cold-start-এ আগে থেকে save করা code থাকলে)
  একবার কল হয়, এরপর complaints/vacancy/dealerOrders/loginLog/helpdesk/
  chairmanNotice/trustedDevices — সব এই company-র subtree থেকেই আসবে
- নতুন কোনো Firestore ফিচার যোগ করলে **অবশ্যই** `companyCollection(name)`
  দিয়ে যেতে হবে, `db.collection(name)` সরাসরি না (companies registry বাদে)
- SessionPrefs.kt-এ company code/language/device-id/last-employee — এখন
  সবার-ব্যবহারযোগ্য (আগে LoginScreen.kt-এর ভেতরে আটকে ছিল)

**সব ৪টা foundational ধাপই এখন Kotlin-এ আছে:** Multi-tenant retrofit → Super Admin Portal → AI Assistant → Live Presence Heartbeat।

## AI Assistant (৩/৪ — AI Boardroom module-এর ভেতরেই, ✨ আইকন)
দুটো ট্যাব: **Assistant** (action সনাক্ত করে — order/vacancy/notice শব্দ চিনলে
দেখায়, real বাস্তবায়ন Firebase Blaze লাগবে) আর **Analysis** (dealers/ledger/
stock-এর real ডেটা থেকে উত্তর দেয়, কিছু বদলায় না)। মাইক বাটন দিয়ে ভয়েস input
(Android-এর নিজস্ব speech recognizer, ফ্রি)। মাসিক ব্যবহার সীমা company-wide
(Firestore-এ, `aiUsage/{yearMonth}` — মাস বদলালে নিজে থেকেই রিসেট হয়)।

## Live Presence Heartbeat (৪/৪ — সৎভাবে সীমাবদ্ধতাসহ বলি)
`PresenceHeartbeatService` — foreground service, প্রতি ৩০ মিনিটে একবার GPS
নেয় (persistent notification-সহ, Android-এর নিয়ম মেনেই), GeoCrmScreen-এর
"Live Presence Heartbeat" কার্ড থেকে চালু/বন্ধ করা যায় (দুই-ধাপে permission:
আগে foreground location, তারপর background location Settings থেকে)। Login
করার সময়ও একই location fix attendance-এ যোগ হয় ("Login = Auto Attendance")।

**যা এখনো বাকি ছিল, এখন সম্পূর্ণ:** `refreshPayrollAbsences()` — Payroll
screen খোলার সাথেই চলে (true midnight cron job না, কারণ Android-এ exact-time
background scheduling ব্যাটারি-অপ্টিমাইজেশনের কারণে অনির্ভরযোগ্য — এই lazy
sweep পদ্ধতিই বেশি নির্ভরযোগ্য এই ধাপে)। গত ৩০ দিনের মধ্যে যেদিন কোনো
check-in নেই, সেদিন "absent" হিসেবে লেখা হয়, তারপর `unapprovedAbsenceDays`
real ডেটা থেকে recompute হয় — payroll-এর `absencePenalty`/`netPayable` এখন
সত্যিই attendance-নির্ভর, static seed number না। এই কাজে `PayrollDao`-তে
`updateAbsenceDays` কোয়েরিও যোগ হয়েছে (আগে ছিল না)।

## Super Admin Portal (২/৪ — যাচাই করে নিশ্চিত হয়েছি, একটা গ্যাপ পেয়ে ঠিক করেছি)
Login-এর "Super Admin? এখানে লগইন করুন" লিংক থেকে ঢোকা যায় (company code লাগে
না, `MockRepository.SUPER_ADMIN_PASSCODE` দিয়ে যাচাই)। ৪টা ট্যাব: Companies
(তৈরি/suspend/reactivate), Revenue, Support (cross-company ticket), **Audit
Log** (এইমাত্র যোগ করা হয়েছে — ডেটা আগে থেকেই রেকর্ড হচ্ছিল কিন্তু দেখার
কোনো screen ছিল না)। "View company data" প্রতিটা ব্যবহার audit log-এ যায়।

## Super Admin Portal (২/৪ সম্পন্ন)
- আলাদা লগইন পথ (Company Code screen থেকে "Super Admin? Log in here" লিংক), passcode: 999999 (demo)
- Companies ট্যাব — তালিকা + নতুন কোম্পানি/কোড তৈরি + Suspend/Reactivate
- Revenue ট্যাব — মোট monthly recurring revenue + company-wise ভাঙন
- Support ট্যাব — কোম্পানিগুলো থেকে আসা support ticket (Helpdesk থেকে আলাদা — ওটা dealer-facing, এটা company-থেকে-platform)
- **View Company Data** — Firestore-এ যা আছে তাই দেখায় (Complaints, Vacancy, Dealer Orders, Helpdesk, Login Log সংখ্যা) — **প্রতিটা দেখাই Super Admin Audit Log-এ রেকর্ড হয়**
- ⚠️ সততার সাথে সীমাবদ্ধতা: Sales/Inventory/HR/Billing/Production/Ledger এখনো local Room DB-তে (company-র নিজস্ব ডিভাইসে), তাই এখান থেকে দেখা যায় না — সেগুলো Firestore-এ গেলে পরে যোগ হবে

## হার্ডওয়্যার/GPS/permission নিয়ে standard (গুরুত্বপূর্ণ)
প্রতিটা `uses-permission` এর সাথে অবশ্যই বাস্তব, properly-guarded runtime
request + কার্যকরী ফিচার থাকতে হবে — permission declare করে রাখা কিন্তু
আসল runtime request/foreground service না থাকা মানেই ভবিষ্যতে ঠিক GPS/
biometric-এর মতো bug। শেষ অডিটে এই কারণেই `ACCESS_BACKGROUND_LOCATION`
আর `RECORD_AUDIO` সরানো হয়েছিল (declared ছিল কিন্তু কোনো কোড actually
ব্যবহার করছিল না)। নতুন কোনো হার্ডওয়্যার ফিচার (camera, microphone, ইত্যাদি)
যোগ করার সময় permission + runtime request + ফিচার — তিনটাই একসাথে, একই
commit-এ যোগ করতে হবে।

## এখন পর্যন্ত Kotlin-এ যা পোর্ট হয়েছে (real APK-তে কাজ করে)
- Login (PIN + Fingerprint/Face, gold-sky থিম)
- Device lockout (৩ বার ভুল PIN → লক, শুধু Chairman-এর PIN দিয়ে আনলক)
- Forgot PIN → OTP flow (simulated, demo OTP: 0000)
- Dashboard (Employee Directory ২০৯ জন, ৬৪ জেলা, role-wise module grid,
  personal target/achievement, vacancy banner)
- Chairman's Notice (Firebase Storage image upload, সবাই দেখে)
- Vacant Positions (per-employee cascade)
- Account & Access Control (Chairman-only: PIN reset, device unlock)
- Complaint Box (Firestore-synced)
- Dealer Login + Order + ASM Approval (Firestore-synced — dealer এক ফোনে
  অর্ডার দেয়, ASM অন্য ফোনে approve করে)
- Sales Chain — এখন সহ ছবি/GPS ট্যাগ/real QR কোড (ZXing) retailer শপের জন্য
- Stock Management — Production vs Store category split
- Courier & Logistics (API + manual couriers)
- Task Manager, Approvals, Notifications (aggregated), Market Analysis
- CRM/GPS, Inventory, HR/Payroll, Billing, Production, AI Boardroom

## ১৯টা মডিউল — সবগুলোই এখন সম্পূর্ণ ✅
Sales Chain, CRM, Dealers, GPS Track, Billing, Courier & Logistics,
Inventory, Stock Mgmt, Production, Market Analysis, AI Boardroom, Reports,
Accounts/Ledger, HR & Payroll, Approvals, Task Manager, Notifications,
Helpdesk, Complaint Box — প্রতিটার নিজস্ব route + role-based access, verified।

## এখনো বাকি (মডিউল না, deeper polish)
- HR module-এ real employee directory sync (এখনো demo/generated data)
- Reports module আরও গভীর trend/history (এখন live snapshot, সময়ের সাথে history না)

## Chain of command (ভুলে গেলে এটা দেখুন)
SR → TSM → ASM → RSM → DSM → NSM → AGM → GM → MD → **Chairman** (admin, সর্বোচ্চ)
