# gradle-wrapper.jar is not included

This sandbox has no network access and no local Gradle installation, so the
compiled `gradle-wrapper.jar` binary (the small launcher Gradle normally
generates) could not be produced here — it is not something that can be
hand-written, only downloaded or extracted from an existing Gradle install.

`gradlew`, `gradlew.bat`, and `gradle-wrapper.properties` (pointing at Gradle
8.7, compatible with this project's AGP 8.5.2 / Kotlin 2.0.20) are real and
included.

To finish the wrapper on a machine with internet access or a local Gradle
install, run once from the project root:

```
gradle wrapper --gradle-version 8.7
```

This regenerates `gradle-wrapper.jar` in place; the properties file this
project ships already matches, so no other files need to change. After that,
`./gradlew assembleDebug` will work normally.
