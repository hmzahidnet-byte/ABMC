# ABM ERP — UI/UX Blueprint v1
**Status as of v113-47: implemented, with the exceptions listed per section and in Part VI.**

| Legend | Meaning |
|---|---|
| ✅ IMPLEMENTED | Built and in the shipped code |
| 🟡 PARTIAL | Core is in; named gaps remain |
| ⏳ PENDING CORE EXPANSION | Blocked on data models or backend that do not exist yet |
| 🚫 DEFERRED | Deliberately not done, with a stated reason |

**Section status:** §1–§10 foundations ✅ · §11–§13 structure ✅ · §14 empty ✅ · §15 loading 🟡 (only the two real async gaps) · §16 error ✅ · §17 search 🟡 (10 sub-tabs, not all) · §18 filters 🟡 · §19 KPI ✅ (7 tap-throughs wired) · §20 tables 🟡 (StatusPill adopted; full 3-line row shape not on every list) · §21 forms ✅ (10 full-screen workspaces) · §22 dashboard ✅ · §23 modules ✅ · §24 Chairman ✅ · **§25 QR 🟡 — secure registry, lifecycle and validated resolution are IMPLEMENTED in v113-47; auto-activation at lifecycle points, workspace QR actions and Firestore sync are PENDING** · §26–§34 module designs 🟡 (signature moments built and wired: YieldBar, PresenceDot, StageRail, WaitingAge, FigureCell) · §35 universal menu ✅ · §36 bottom bar ✅ · §37 FAB ✅ · §38 dialogs ✅ · §39 theme ✅ · §40 responsive 🟡 (phone verified; tablet untested).

Every rule below is written against the app as it actually exists today (v113-36): 21 modules, Jetpack Compose, Material 3, Compose BOM 2024.06.00, `material-icons-extended` already a dependency. Where a rule needs something the app does not have yet, it is marked **[NEW]** so scope stays honest.

---

## 0. The one-line thesis

> **A field-force ERP where the QR camera is the primary index of the business, and every module is the same skeleton wearing its own trade's colours.**

Two consequences drive every decision in this document:

1. **One skeleton, 21 identities.** Modules must *not* be individually designed. They share one structural template; what differs is accent colour, icon set, KPI vocabulary, and the shape of the working list. This is how "Invoice feels like billing software, Warehouse feels like a WMS" is achieved *without* 21 divergent codebases — and it is the only version of that goal that is maintainable.
2. **The camera is a navigation device.** In a distribution business the fastest route to a record is not a menu — it is pointing a phone at the thing itself. QR is treated as a peer of the bottom navigation bar, not as a feature inside a module.

---

# PART I — FOUNDATIONS

## 1. Design Philosophy

| Principle | Rule |
|---|---|
| **Density with air** | ERP users scan numbers, not paragraphs. Pack information, but separate groups with real whitespace (16dp+). Never a wall of unlabelled rows. |
| **Status is colour, colour is status** | Colour carries meaning first, decoration second. Orange = brand/action. Green/amber/red = state. Navy+gold = executive authority. Nothing is coloured "because it looks nice". |
| **The screen announces itself in one glance** | Within 300ms a user must know: which module, who they are, what state the business is in. Hence the mandatory header stack (§13). |
| **Work happens full-screen** | Dialogs are for confirming and toggling. Anything with more than 3 inputs opens full-screen. |
| **Nothing lies** | Every number on screen is real data from the repository. No placeholder figures, no invented trend lines, no "sample" states shipped in production. |
| **Offline is a first-class state, not an error** | Sync state is always visible in the header, never a surprise modal. |

**Anti-goals** (explicitly rejected): glassmorphism as a global look, neon-on-black, decorative gradients on content cards, animated splash sequences, skeleton shimmer on local Room reads that complete in <50ms.

---

## 2. Design System

The system is defined by **six primitives**. Everything else composes from these.

| # | Primitive | Status |
|---|---|---|
| P1 | `SurfaceCard` — white, 16dp radius, 2-layer shadow, 1dp hairline border | Exists as `GlassCard` (needs radius/shadow retune) |
| P2 | `IconChip` — tinted rounded-square holding a vector icon | **[NEW]** — the single highest-impact addition |
| P3 | `ModuleWorkspaceHeader` — identity + KPI + quick actions + activity | Exists, rolled out to all 21 modules |
| P4 | `StatusPill` — small filled capsule carrying one state word | **[NEW]** (currently ad-hoc coloured `Text`) |
| P5 | `WorkspaceState` — empty / loading / error+retry | Exists (`WorkspaceEmptyState` etc.) |
| P6 | `UniversalActionMenu` — the ⋮ record menu | Exists, permission-gated |

**Rule:** no screen may invent its own version of a primitive. If a screen needs something a primitive can't do, the primitive gains a parameter — it is never forked.

---

## 3. Color System

### 3.1 Brand
| Token | Hex | Use |
|---|---|---|
| `DarazOrange` | `#F85606` | Primary. FAB, primary buttons, active nav, key figures, module accents that have no trade colour. |
| `DarazOrangeDark` | `#C23F00` | Pressed state, gradient end. |
| `DarazOrangeSoft` | `#FFE7DA` | Chip/badge tint on white. |

### 3.2 Neutrals
| Token | Hex | Use |
|---|---|---|
| `DashBg` | `#F5F6F8` | App background. Never pure white — cards must lift off it. |
| `CardWhite` | `#FFFFFF` | Card surface. |
| `TextPrimary` | `#101828` | Headings, figures. |
| `TextSecondary` | `#667085` | Labels, meta, captions. |
| `HairlineBorder` | `#E4E7EC` | 1dp card border. **[NEW token]** |

### 3.3 Status — semantic, fixed meaning app-wide
| Token | Hex | Means, always |
|---|---|---|
| `StatusGreen` | `#12A867` | Approved · Paid · Delivered · Present · In stock · Synced |
| `StatusBlue` | `#2563EB` | In progress · In transit · Submitted · Informational |
| `StatusAmber` | `#F5A623` | Pending · Awaiting approval · Low stock · Late · Over threshold |
| `StatusRed` | `#DC3626` | Rejected · Overdue · Damaged · Failed · Over credit limit |
| `StatusSlate` | `#667085` | Draft · Cancelled · Archived · Inactive |

> **Rule:** a status word never appears in two different colours in two different modules. `PENDING` is amber in HR, Finance, Purchase, and Approvals — identically.

### 3.4 Chairman (restricted palette)
| Token | Hex | Use |
|---|---|---|
| `ChairmanNavy` | `#0F1E3D` | Executive surfaces only. |
| `ChairmanGold` | `#D4AF37` | Executive accent only. |

> **Rule:** navy+gold appear **only** inside Chairman Hub and the Chairman entry point. Using them elsewhere destroys their signal value.

### 3.5 Module accent map
Each module owns one accent, used for its header gradient, its icon chips, and its primary figures. Trade-derived where possible.

| Module | Accent | Rationale |
|---|---|---|
| Sales / CRM | `#2563EB` blue | Ledger blue, the traditional sales-book colour |
| HR | `#DB2777` rose | People, distinct from every operational colour |
| Warehouse | `#475569` slate | Industrial steel, deliberately the only grey-family accent |
| Production | `#E85D4A` kiln red | Heat, the factory floor |
| Finance | `#12C2A9` teal | Cash-green adjacent without colliding with `StatusGreen` |
| Chairman | `#0F1E3D` navy + gold | Authority |
| Inventory | `#12C2A9` teal | Shares Finance's family — both are "counting" modules |
| Purchase | `#8A6DFF` violet | Procurement, upstream mirror of Sales |
| Dealers | `#B45CFF` orchid | Partner network |
| Billing | `#F5A623` amber | Credit risk = caution |
| Courier | `#8A6DFF` violet | Logistics rides with Purchase |
| Expenses | `#E85D4A` red | Outflow |
| Tasks / Approvals | `#12A867` green | Completion |
| Notifications | `#F5A623` amber | Attention |
| Reports / Market | `#9C6EFF` purple | Analysis |
| Helpdesk / Comms | `#2563EB` blue | Communication |
| Complaint | `#FF6B6B` coral | Sensitive |

---

## 4. Typography

Compose default (Roboto). **No custom font is proposed** — a font file is an asset addition, and Roboto at correct weights reads as professional. Personality comes from *weight and spacing discipline*, not from a typeface purchase.

| Role | Size | Weight | Letter-spacing | Colour | Used for |
|---|---|---|---|---|---|
| Display figure | 22sp | Bold | −0.5 | accent | The one hero number on a screen |
| Screen title | 18sp | Bold | −0.3 | `TextPrimary` | Module / workspace title |
| Section label | 11sp | Bold | +1.2, UPPERCASE | `TextSecondary` | Group headers ("EXECUTIVE SUMMARY") |
| KPI value | 15sp | Bold | −0.2 | status/accent | Numbers in KPI cards |
| KPI label | 9sp | Medium | 0 | `TextSecondary` | Label above a KPI value |
| Body | 13sp | Normal | 0 | `TextPrimary` | Record rows, descriptions |
| Meta | 11sp | Normal | 0 | `TextSecondary` | Timestamps, codes, sub-lines |
| Button | 14sp | SemiBold | +0.2 | — | All buttons |

**Rules**
- Max **3** type sizes visible in any one card.
- Numbers use tabular alignment; currency always `৳` + thousands separators + zero decimals (`৳1,29,000` style not required — plain `৳129,000`).
- Bangla and English mix freely in body/meta; **labels and status words stay English** so they remain scannable and consistent with the data layer.

---

## 5. Card Style

One card. Three densities.

```
┌─────────────────────────────────┐  radius 16dp
│  ▢  Label                       │  border 1dp #E4E7EC
│      Value                      │  bg #FFFFFF
└─────────────────────────────────┘  shadow: 2-layer (§8)
```

| Density | Padding | Used for |
|---|---|---|
| Compact | 10dp | KPI tiles, icon-grid tiles |
| Standard | 14dp | Record rows, list items |
| Roomy | 18dp | Hero cards, detail panels, forms |

**Rules**
- Cards never nest more than one level deep.
- A card has **one** job: one record, or one metric group. Two unrelated things = two cards.
- No card carries a gradient. Gradients belong to headers and the FAB only.

---

## 6. Icon Style

**This is the signature element of the system.**

Every icon sits inside an `IconChip`: a rounded-square (13dp radius) filled with the accent at ~12% opacity, with the icon stroked in the accent at full strength.

```
 ╭──────╮
 │  ▤   │   40dp chip · 20dp icon · radius 13dp
 ╰──────╯   bg = accent @ 12%   ·  icon = accent @ 100%
```

| Rule | Detail |
|---|---|
| Source | `androidx.compose.material.icons.Icons.Filled.*` / `.Outlined.*` — already a dependency, no new assets |
| **Emoji are banned in UI chrome** | Emoji may remain only inside user-authored content. Every 🏭💵📦 currently used as an interface icon is replaced by a vector. |
| Sizes | 32dp chip (dense grids) · 40dp (standard) · 48dp (hero) |
| Stroke | Use `Filled` for navigation/actions, `Outlined` for informational icons. Never mix within one grid. |
| Colour | Icon always takes the module accent or the status colour — never plain grey unless disabled |

---

## 7. Elevation

Four tiers. Nothing else.

| Tier | dp | Applies to |
|---|---|---|
| E0 | 0 | Page background, section labels |
| E1 | 2 | Standard cards, list rows |
| E2 | 6 | Headers, sticky bars, hero cards |
| E3 | 12 | FAB, full-screen workspace scrims, dialogs |

Elevation communicates *layer*, never *importance*. An important card gets a colour accent, not extra shadow.

---

## 8. Shadow

Compose's single-shadow default reads as a grey halo. The system uses a **two-layer recipe** instead:

```
layer 1 (contact) : y=1dp,  blur 2dp,  #101828 @ 4%
layer 2 (ambient) : y=4dp,  blur 12dp, #101828 @ 5%
```

- FAB gets a **coloured** shadow: `#F85606 @ 40%`, y=8dp, blur 20dp — it should look lit, not just raised.
- Chairman surfaces: `#0F1E3D @ 30%`, y=6dp, blur 18dp.
- Shadows are never black; always the neutral-dark or the accent.

---

## 9. Border Radius

| Element | Radius |
|---|---|
| Card | 16dp |
| Icon chip | 13dp |
| Button | 12dp |
| Input field | 12dp |
| Chip / filter pill | full (999dp) |
| Status pill | full |
| Dialog | 20dp |
| FAB | full circle |
| Header banner | 0 (edge-to-edge, bleeds to screen edges) |

Rule: radius decreases as the element gets smaller; never a 24dp radius on a 32dp chip.

---

## 10. Animation

Motion budget is deliberately small. Over-animation is the clearest "AI-generated demo" tell.

| Where | Motion | Spec |
|---|---|---|
| KPI figures | Count-up on first appear | 900ms, `FastOutSlowInEasing` — **already implemented** |
| Screen enter | Fade + 8dp rise | 220ms |
| Full-screen workspace | Slide up from bottom | 280ms, decelerate |
| FAB press | Scale 0.94 | 120ms |
| Card press | Elevation E1→E2 | 100ms |
| List item appear | None | — |
| Loading | Circular indicator only | No shimmer skeletons |

**Rules**
- `prefers-reduced-motion` equivalent: all motion is decorative and safely skippable.
- **Never** animate a number that changes because of a sync — it reads as instability in a financial app.
- No page-load choreography, no staggered card reveals.

---

# PART II — STRUCTURE

## 11. Screen Layout

Every screen is one of exactly **four** archetypes.

```
A. DASHBOARD          B. MODULE HUB         C. WORKING LIST       D. FULL WORKSPACE
┌──────────────┐      ┌──────────────┐      ┌──────────────┐      ┌──────────────┐
│ top bar      │      │ header stack │      │ header stack │      │ title + ✕    │
├──────────────┤      ├──────────────┤      ├──────────────┤      ├──────────────┤
│ hero metric  │      │ tile grid    │      │ search       │      │              │
│ KPI grid 2×n │      │ (sub-modules)│      │ filter chips │      │  form body   │
│ perf tiles   │      │              │      ├──────────────┤      │  (scrolls)   │
│ alerts       │      │              │      │ record rows  │      │              │
├──────────────┤      ├──────────────┤      ├──────────────┤      ├──────────────┤
│ bottom bar   │      │ bottom bar   │      │ bottom bar   │      │ primary CTA  │
└──────────────┘      └──────────────┘      └──────────────┘      └──────────────┘
```

**Spacing scale:** 4 · 8 · 12 · 16 · 24 dp. Nothing else. Screen edge padding = 16dp. Card gap = 12dp. Section gap = 24dp.

---

## 12. Navigation Flow

```
                    ┌──────────────┐
                    │  DASHBOARD   │  ← entrance only, never a workplace
                    └──────┬───────┘
              ┌────────────┼────────────┐
        bottom bar     QR camera     ⋮ system menu
              │            │              │
        ┌─────▼─────┐  ┌───▼────┐   ┌─────▼──────┐
        │ MODULE HUB│  │ SCAN → │   │ Profile    │
        │ tile grid │  │ detect │   │ Activity   │
        └─────┬─────┘  │ resolve│   │ Devices    │
              │        └───┬────┘   │ Sync       │
        ┌─────▼─────┐      │        │ Backup     │
        │ WORKING   │◄─────┘        │ Settings   │
        │ LIST      │  jumps straight│ Help      │
        └─────┬─────┘  to the right  │ Logout    │
              │        workspace     └────────────┘
        ┌─────▼──────────┐
        │ FULL WORKSPACE │  create / edit
        └────────────────┘
```

**Back behaviour (uniform, no exceptions)**
- Full workspace → closes to the working list it came from.
- Working list → `BackToSubMenuLink` returns to the module's tile grid.
- Module hub → system back returns to Dashboard.
- Scan result → back returns to the camera, not the Dashboard.

---

## 13. Workspace Layout (the shared skeleton)

Every one of the 21 modules renders this exact stack. Only the *content* of each band changes.

```
╔═══════════════════════════════════════╗
║ 1  BRAND BAND    accent gradient      ║  ← module identity: icon + title
╠═══════════════════════════════════════╣
║ 2  IDENTITY STRIP                     ║  ← avatar · name · ID · designation
║    ▢ ZH  Zahid Hossain      ● Online  ║     company · territory · sync state
║       CHAIR-1 · Chairman · ABM        ║
╠═══════════════════════════════════════╣
║ 3  KPI STRIP     scrollable           ║  ← 3–5 live metrics, real data only
║    Today  Pending  Approved  Rejected ║
╠═══════════════════════════════════════╣
║ 4  QUICK ACTIONS  chip row            ║  ← 2–4 verbs, permission-gated
╠═══════════════════════════════════════╣
║ 5  RECENT ACTIVITY  (collapsible)     ║  ← from the real audit log
╠═══════════════════════════════════════╣
║ 6  SEARCH + FILTERS                   ║  ← only on list views
╠═══════════════════════════════════════╣
║ 7  WORKING CONTENT                    ║  ← tile grid OR record list
╚═══════════════════════════════════════╝
```

Bands 1–5 are `ModuleWorkspaceHeader` — **already built and rolled out to all 21 modules.** Bands 6–7 are the module's own content.

> **How "each module feels like its own app" is achieved:** band 1 colour + band 3 vocabulary + band 7 row shape. A warehouse row shows quantities and bin locations; a finance row shows debit/credit columns; an HR row shows a person with an attendance dot. Same skeleton, unmistakably different trade.

---

## 14. Empty State

```
        ╭────╮
        │ ▤  │      icon chip, 48dp, accent @ 12%
        ╰────╯
   No invoices yet          17sp SemiBold
   Create one to get started  13sp secondary
      [ + Create Invoice ]    primary button, only if user has permission
```

**Rules**
- Every empty state names the *thing* ("No invoices yet"), never "No data".
- If the empty state is caused by a filter, say so and offer **Clear filters** instead of the create action.
- Never show an empty state and a loading state simultaneously.

---

## 15. Loading State

- Local Room reads are effectively instant → **no loading UI at all**. Showing a spinner for a 20ms read is noise.
- Loading UI appears **only** for genuinely async work: `computeSystemHealthSnapshot`, attendance summaries, Firestore-dependent fetches, PDF generation.
- Form submits: button becomes `[ ⟳ Saving… ]`, disabled, for the true duration of the suspend call — never a fixed timer.
- **No shimmer skeletons.** They imply slow network on a local-first app.

---

## 16. Error State

```
        ╭────╮
        │ !  │      icon chip in StatusRed @ 12%
        ╰────╯
   Couldn't load stock levels     17sp SemiBold
   Check your connection and try again   13sp secondary
        [ Try again ]              outlined button
```

**Rules**
- State what failed and what to do. Never "Error 500", never an exception string.
- Errors do not apologise.
- Form validation appears **inline under the field**, red, not as a toast.
- A failed action leaves the form filled — the user never re-types.

---

## 17. Search UX

| Rule | Detail |
|---|---|
| Placement | Always immediately above the list it filters. Never in the header band. |
| Global search | Lives in the top bar (magnifier icon), opens `UniversalSearchDialog` — already built |
| Behaviour | Live filter as you type. No search button. |
| Scope hint | Placeholder names the field(s): "Search by name or territory…" |
| Empty result | Empty state with **Clear search**, not the create action |
| Persistence | Query clears when leaving the tab — filters are not sticky across sessions |

---

## 18. Filter UX

```
[ All ] [ Pending ] [ Approved ] [ Rejected ]     ← horizontal scroll, full-radius pills
```

| Rule | Detail |
|---|---|
| Type | Single-select status pills for state; date-range chips where time matters |
| Default | Always "All" selected, never a pre-applied hidden filter |
| Active style | Filled with accent, white text. Inactive: white with hairline border. |
| Count | Show result count next to the section title, not on each pill |
| Placement | Directly under search, above the list |
| Reset | If any non-default filter is active, a **Clear** pill appears at the end of the row |

---

# PART III — COMPONENTS

## 19. KPI Card Design

```
┌───────────────────┐
│ Pending           │  9sp Medium, TextSecondary
│ 12                │  15sp Bold, status colour
└───────────────────┘  compact card, 10dp padding
```

**Rules**
- 2-column grid on Dashboard; horizontally scrolling strip inside module headers.
- 3–6 KPIs per module. More than 6 = nothing stands out.
- The value's colour **is** its status: amber if the number is a problem, green if healthy, neutral if merely informational. A "Pending: 0" is green; "Pending: 12" is amber.
- Currency KPIs: `৳` + no decimals. Count KPIs: bare integer.
- Tapping a KPI navigates to the filtered list that explains it. *(Currently only Chairman Hub does this — extending it is a real improvement.)*

---

## 20. Table Design

Mobile ERP has no real tables — it has **structured rows**. A row is a card:

```
┌──────────────────────────────────────────┐
│ ╭──╮  INV-1001258            [ PAID ]    │  ← title + status pill
│ │▤ │  Barisal Central Dealer             │  ← subject
│ ╰──╯  ৳190,000 · 17 May · 4 items    ⋮   │  ← facts (meta) + action menu
└──────────────────────────────────────────┘
```

**Rules**
- Left: icon chip (type or status colour). Right: `⋮` `UniversalActionMenu`.
- Line 1 = identifier + status pill. Line 2 = the human subject. Line 3 = the numbers.
- Max 3 lines. Anything more goes in the detail workspace.
- Genuinely tabular data (Trial Balance, Balance Sheet) keeps a 2-column label/value layout with a hairline divider — the one permitted exception.

---

## 21. Form Design

| Rule | Detail |
|---|---|
| Container | Full-screen workspace (§13-D), never a cramped dialog |
| Field order | Follows the real business sequence: who → what → how much → how paid → note |
| Grouping | Related fields in one card with a section label; 24dp between groups |
| Labels | Above the field, not floating placeholders that vanish on focus |
| Required | Mark optional fields "(optional)" rather than starring required ones — fewer marks |
| Validation | Inline, on blur, under the field |
| Keyboard | Numeric for amounts/quantities, text elsewhere. *(A real bug was found here: the login field forced a numeric keypad that made valid IDs untypeable — the class of error this rule prevents.)* |
| Primary CTA | Pinned to the bottom, full-width, disabled until valid |
| Cancel | Top-right `✕`. No bottom "Cancel" button competing with the CTA. |
| In-flight | CTA shows progress and is disabled — no double submission |
| On failure | Form stays filled, error inline |

---

## 22. Dashboard Design

**Dashboard is the entrance, not the workplace.** It answers three questions and then gets out of the way: *Am I on target? What needs me? What just happened?*

```
┌─ top bar ──── ☰ Dashboard        🔍  🔔  ⋮ ─┐
├─────────────────────────────────────────────┤
│ HERO — My Target                    ╭───╮   │  the single most important number
│ ৳0 this month                       │ ◎ │   │
├─────────────────────────────────────────────┤
│ EXECUTIVE SUMMARY               Today ▾     │
│ ┌──────────┐ ┌──────────┐                   │
│ │Sales 90d │ │Collection│   2-column grid   │
│ ├──────────┤ ├──────────┤                   │
│ │Total Due │ │Low Stock │                   │
│ ├──────────┤ ├──────────┤                   │
│ │Approvals │ │Invoices  │                   │
│ └──────────┘ └──────────┘                   │
├─────────────────────────────────────────────┤
│ TODAY'S PERFORMANCE   [▤][▤][▤]  3 tiles    │
├─────────────────────────────────────────────┤
│ SMART ALERTS                     View All   │
│ ⚠ Low-Performing Dealers (1)                │
├─────────────────────────────────────────────┤
│ RECENT ACTIVITY (3 rows, tap → audit log)   │
└─ bottom bar ────────────────────────────────┘
```

**Removed and staying removed:** the duplicated module-shortcut grid (bottom nav does this) and Chairman-only tool buttons (they live in Chairman Hub).

**Role adaptation:** SR sees today's collection/visits/orders. Chairman sees company-wide totals + the Chairman Hub entry. Same layout, different KPI set — driven by existing role checks.

---

## 23. Module Design

Each module declares five things; everything else is inherited:

```kotlin
// conceptual — not an implementation proposal
ModuleIdentity(
  title      = "Warehouse Management System",
  icon       = Icons.Filled.Warehouse,
  accent     = Slate,
  kpis       = [Available, Reserved, Transit, Damaged, PendingReceive],
  actions    = [Receive, Transfer, Count, Damage],
)
```

**Module hub tile grid** (3 columns):
```
╭──────╮ ╭──────╮ ╭──────╮
│  ▤   │ │  ▤   │ │  ▤   │   icon chip + label
│Plans │ │Trans-│ │Count │   square tiles, accent-tinted
╰──────╯ ╰fers──╯ ╰──────╯
```
This replaces today's stacked buttons and coloured `SubModuleItem` rectangles.

---

## 24. Chairman Design

The only module allowed to look different — and it must, because it is the only one whose audience is a single person with total visibility.

```
┌─ ← Chairman Module        Only Chairman & Super Admin ─┐
├────────────────────────────────────────────────────────┤
│ ╔══════════════════════════════════════════════════╗   │
│ ║ ╭──╮  Chairman Module            navy + gold     ║   │  ← authority banner
│ ║ │👑│  Executive Control Center                   ║   │
│ ╚══════════════════════════════════════════════════╝   │
├────────────────────────────────────────────────────────┤
│ EXECUTIVE KPIs — approvals · due · low stock · alerts  │
├────────────────────────────────────────────────────────┤
│ TOOL GRID  3 columns × 5 rows, icon chips              │
│  ╭──╮ ╭──╮ ╭──╮   Notice · Comms · Helpdesk           │
│  ╭──╮ ╭──╮ ╭──╮   Complaint · Vacancy · Access        │
│  ╭──╮ ╭──╮ ╭──╮   Audit · Login · Devices             │
│  ╭──╮ ╭──╮ ╭──╮   Backup · Health · Rules             │
│  ╭──╮ ╭──╮ ╭──╮   Settings · Export · Integrations    │
├────────────────────────────────────────────────────────┤
│ INTELLIGENCE — risks · target · performance · alerts   │
│ every card taps through to the real module             │
└────────────────────────────────────────────────────────┘
```

**Access:** Chairman role, or an active Chairman delegation — the existing `activeDelegationFor` gate. Unchanged.

---

## 25. QR Workflow Design

**QR is a foundation, ranked with the bottom bar.**

```
   ┌─────────────────────────────────────────────────┐
   │  TAP FAB  →  camera opens immediately           │
   │             (never a "what do you want to scan?"│
   │              menu — that question is the bug)   │
   └──────────────────┬──────────────────────────────┘
                      ▼
   ┌─────────────────────────────────────────────────┐
   │  DETECT   prefix + shape → CodeType             │
   │  RESOLVE  match against real loaded data        │
   │  VALIDATE permission check for that type        │
   └──────────────────┬──────────────────────────────┘
                      ▼
        ┌─────────────┴──────────────┐
   found│                            │not found / no permission
        ▼                            ▼
   record sheet:                honest failure:
   identity · live facts ·      "No matching record"
   connected-workflow row       or "You don't have access"
        │                       never a blank screen
        ▼
   correct workspace
```

### Scan coverage (today)
| Type | Resolve | Generate |
|---|---|---|
| Dealer · Retailer · Employee · Invoice · Collection · Product · Carton · Batch · Warehouse Transfer · Delivery | ✅ | ✅ |
| **Asset · Vehicle · Machine** | ❌ | ❌ **[NEW — no data model exists; these are new entities, not UI work]** |

### Generation rules
- Every generated QR encodes **exactly** the string `CodeRegistry.resolve()` matches (`dealerCode`, `invoiceNo`, `sku`, `batchNumber`…). This guarantees round-trip.
- QR contains **only the public identifier** — never a name, amount, or phone number.
- Every record with a QR offers **Show QR → print/share** (`RecordQrButton`).
- Carton/product physical labels use **Code128 barcode**, not QR — cheap warehouse laser scanners read linear codes far better. Already implemented.

### Scan-result sheet
```
╭──╮  Invoice
│▤ │  INV-1001258            [ PAID ]
╰──╯  Barisal Central Dealer · ৳190,000
      ─────────────────────────────────
      Connected workflow
      [Invoice] [Stock] [Ledger] [Delivery]
```

---

# PART IV — MODULE-SPECIFIC DESIGN

Each module below states: **the software it should feel like**, its accent, its KPI vocabulary, and the one row-shape that makes it recognisable.

## 26. Invoice Design — *feels like billing software*
- **Accent** blue · **KPIs** Today's Sales · Collection · Due · Unpaid count
- **Row:** invoice no + status pill / dealer name / amount · date · item count
- **Detail:** a document, not a form — branded header, QR verification block, dealer box, line-item table with alternating row tint, orange total block, status badge, three signature lines. **Already implemented in the PDF export; the on-screen detail should mirror it.**
- **Print/PDF is a first-class action**, not buried in a menu.

## 27. Collection Design — *feels like a banking app*
- **Accent** green · **KPIs** Collected Today · Pending Verification · This Month · Rejected
- **Row:** receipt no + status / party name / amount · method · collector
- **Signature moment:** amount entry is the hero — large numeric field, method chips (Cash/Bank/Cheque/Mobile) directly under it, allocation to invoices below.
- Verification is a two-person action; the UI must show *who collected* and *who verified* on every row.

## 28. Order Design — *feels like an order desk*
- **Accent** blue · **KPIs** Today's Orders · Pending Verification · Routed · Fulfilled
- **Row:** order no + stage pill / retailer / amount · SR name
- **Stage is a progress track**, not a word: `Logged → Verified → Routed → Fulfilled` shown as a 4-dot rail.

## 29. Warehouse Design — *feels like a WMS*
- **Accent** slate · **KPIs** Available · Reserved · In Transit · Damaged · Pending Receive
- **Row:** product / bin + warehouse / quantity with unit, right-aligned and tabular
- **Signature moment:** quantities are always right-aligned monospace-ish figures with the unit in secondary colour — the WMS look.
- Transfer rows show `Source → Destination` with an arrow glyph, and a receive-progress bar when partially received.

## 30. Production Design — *feels like manufacturing software*
- **Accent** kiln red · **KPIs** Today's Batch · Running · QC Pending · Finished Goods · Machines Active
- **Row:** batch no + status / product / planned vs actual with a yield bar
- **Signature moment:** the **yield bar** — green ≥85%, amber ≥70%, red below. Nothing else in the app uses this, and it instantly reads "factory".

## 31. HR Design — *feels like an HRMS*
- **Accent** rose · **KPIs** Present · Absent · Late · On Leave · Overtime
- **Row:** avatar chip with a presence dot / name / designation · territory
- **Signature moment:** the **presence dot** on every person row (green present, amber late, grey absent) — the single most HRMS-like detail available.
- Attendance never shows raw epoch values; always "9:14 AM · 12 min late".

## 32. Finance Design — *feels like accounting software*
- **Accent** teal · **KPIs** Collection · Expense · Cash · Bank · Outstanding
- **Row:** voucher no + type / narration / debit and credit in **two aligned columns**
- **Signature moment:** the debit/credit column pair. Trial Balance and Balance Sheet keep true two-column tabular layout with hairline rules — the one place tables are correct.
- Every figure carries its sign convention consistently; negatives in `StatusRed`, never parentheses-only.

## 33. Reports Design — *feels like analytics*
- **Accent** purple · **KPIs** the report's own headline figures
- Sections, not a wall: one card per domain (Sales / Collection / Inventory / Production / HR).
- Charts stay **blue/green/red by series meaning** — deliberately *not* orange. Brand colour on a data series would misread as "this series is special".
- Every report card offers Export (CSV/PDF) via the universal menu.

## 34. Approval Design — *feels like an inbox*
- **Accent** green · **KPIs** Pending · Approved · Rejected · Total
- **Row:** request type icon chip / requester + designation / detail · age of request
- **Signature moment:** **age** ("3 days waiting") in amber past a threshold — approvals are about latency.
- Approve/Reject are inline on the row for permitted users; Forward/Escalate live in `⋮`.

---

# PART V — GLOBAL PATTERNS

## 35. Universal Menu Design

The `⋮` on every record. Contents are permission-filtered — a user never sees an action they cannot perform.

```
  Print          ← where a document exists
  Share
  Export (CSV / PDF)
  ─────────────
  History        ← audit trail for this record
  Correction     ← opens the correction-request workflow
  ─────────────
  Approve / Reject   ← only if pending + permitted
  Archive / Restore
  ─────────────
  Settings       ← rare; module-level only
```

**Rules:** identical order everywhere. Destructive items last, separated, in `StatusRed`. Already implemented as `UniversalActionMenu` — this section is the specification it should conform to.

## 36. Bottom Navigation Design

```
┌───────────────────────────────────────────────┐
│                    ╭─────╮                    │
│   🧾 Invoice       │ ▣ QR│       💵 Collection│
│                    ╰─────╯                    │
└───────────────────────────────────────────────┘
   permission-gated    always      permission-gated
```

- **Always visible**, on every screen, including inside modules.
- Centre FAB overlaps the bar by 24dp and is the largest touch target in the app (58–64dp).
- Left/right actions hide (not disable) when the role lacks permission — the bar re-centres.
- A slim secondary row above may carry **Cash Book** and other quick jumps.
- **[NEW, not proposed]** POS / Barcode / Generator entries from the reference require screens that do not exist; they are feature work, not UI work, and are explicitly out of scope for this blueprint.

## 37. FAB Design

- 58–64dp circle, `DarazOrange` → `#FF6A2B` diagonal gradient, white QR icon, coloured shadow (§8).
- Single purpose: **open the scanner**. It never becomes a "create" button that changes meaning per screen — ambiguity here would undermine the QR-as-foundation thesis.
- Press: scale 0.94, 120ms. Long-press: nothing (no hidden menus).

## 38. Dialog Design

**Dialogs are for confirming and toggling. Nothing else.**

| Allowed | Not allowed |
|---|---|
| Confirm destructive action | Creating a record |
| Single toggle / small setting | Multi-field forms |
| Showing a QR | Any workflow with a submit + validation |
| Rejection-reason entry | Anything needing scroll |

Spec: 20dp radius, E3, ≤2 buttons, primary right. Destructive confirmations name the record: "Delete invoice INV-1001258?"

Full-screen workspaces already implemented for: Collection, Expense, Apply Leave, Employee Event, BOM, Production Order, Production Plan, Warehouse Transfer, Stock Count, Invoice creation.

## 39. Theme Rules

| Rule | Detail |
|---|---|
| Single light theme | Dark mode is **not** proposed — a half-migrated dark theme across 21 modules is worse than none, and field use is daylight-dominant |
| Colour source | Every colour comes from a named token in `Color.kt`. Raw hex literals in screen files are prohibited. |
| Primary | `MaterialTheme.colorScheme.primary = DarazOrange` — already set, so default-styled controls inherit correctly |
| Accent scope | A module accent may tint that module's chrome only. It never overrides a status colour. |
| Chairman palette | Navy+gold, Chairman surfaces only |
| Contrast floor | Body text ≥ 4.5:1 on its background; status pills use dark text on light tint, never light-on-light |
| Charts | Series colours are semantic (blue = sales, green = collection, red = outstanding), never brand orange |

## 40. Responsive Rules

Phone-first; the app is a field tool.

| Width | Behaviour |
|---|---|
| < 360dp | KPI grid 2 cols · tool grid 2 cols · reduce card padding to compact |
| 360–599dp (default) | KPI grid 2 cols · tool grid 3 cols · standard padding |
| ≥ 600dp (tablet) | KPI grid 4 cols · tool grid 4–5 cols · content max-width 840dp, centred |
| Landscape | Header bands collapse to a single line; KPI strip scrolls horizontally |

Other rules: minimum touch target 48dp; text scales with system font size (no fixed `sp` overrides that break at 130%); long names truncate with ellipsis, never wrap to a third line in a row.

---

# PART VI — SCOPE HONESTY

Everything above is achievable as **UI work on the existing engine** — *except* the following, which are listed so approval is informed:

| Item | Why it is not UI work |
|---|---|
| Asset · Vehicle · Machine QR | No data models exist. New entities = new schema = new feature. |
| POS screen | No POS screen exists in the app. |
| Barcode / QR / PDF / Excel **Generator** utility screens | No such screens exist. (The underlying generators exist and are used inline.) |
| Geo / Visit **Map** screen | No map view exists; would need a maps SDK integration. |
| Dark mode | Deliberately excluded (§39). |
| Custom typeface | Deliberately excluded (§4) — asset addition with low return. |

**Work that is genuinely available**, in the order I would sequence it by impact-per-risk:

1. `IconChip` primitive + replace emoji with vector icons app-wide — *the single largest visual gain*
2. `StatusPill` primitive + unify status colours against §3.3
3. Card/shadow/radius retune to §5, §8, §9
4. Dashboard → 2-column KPI grid (§22)
5. Chairman → 3-column tool grid (§24)
6. Module hub tile grids → icon-chip tiles (§23)
7. Record rows → §20 shape
8. Module signature moments: yield bar, presence dot, debit/credit columns, stage rail, approval age
9. KPI tap-through to filtered lists (§19)

---

**Implemented.** All 9 steps were delivered across v113-37 → v113-46, then the secure QR
architecture in v113-47 (which did change schema and QR-resolution code — authorised
explicitly by that batch's brief, and covered by an additive, non-destructive migration).

**One standing caveat that applies to every batch:** no real Gradle build has ever run in the
environment these changes were written in — the wrapper jar is absent and there is no network.
All verification was static. See PROJECT_STATE.md for the exact runtime tests still required.
