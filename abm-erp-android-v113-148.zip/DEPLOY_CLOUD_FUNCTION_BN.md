# Cloud Function চালু করার ধাপ (একবারই করতে হবে)

এটা Android Studio-র কাজ না — এটা কম্পিউটারের terminal/command প্রম্পট
দিয়ে একবার "deploy" করতে হয়। এই ধাপগুলো একবার করে ফেললে, ভবিষ্যতে যতবার
`functions/index.js` ফাইল বদলাবে, শুধু ধাপ ৫টাই আবার করলেই চলবে।

## ধাপ ১ — Node.js ইনস্টল করুন (যদি না থাকে)
https://nodejs.org থেকে **LTS** ভার্সনটা ডাউনলোড করে সাধারণ Windows
installer-এর মতোই ইনস্টল করুন (Next, Next, Finish)।

## ধাপ ২ — Firebase CLI ইনস্টল করুন
Command Prompt (বা PowerShell) খুলে লিখুন:
```
npm install -g firebase-tools
```

## ধাপ ৩ — Firebase-এ লগইন করুন
```
firebase login
```
একটা ব্রাউজার খুলবে — যেই Google একাউন্ট দিয়ে Firebase Console ব্যবহার
করেন, সেটা দিয়েই লগইন করুন।

## ধাপ ৪ — প্রজেক্ট ফোল্ডারে যান
Command Prompt-এ, এই zip যেখানে extract করেছেন সেই `abm-erp` ফোল্ডারে যান:
```
cd C:\path\to\abm-erp
```
(আপনার আগের screenshot অনুযায়ী সম্ভবত `cd C:\abm-erp`)

## ধাপ ৫ — Deploy করুন
```
firebase deploy --only functions,firestore:rules
```
এই কমান্ডটাই একসাথে Cloud Function-টা চালু করবে **এবং** নতুন
`firestore.rules`-ও publish করবে (তাই Firebase Console-এ গিয়ে আলাদা করে
rules paste করার দরকার নেই এবার থেকে — এই কমান্ডই দুটো কাজ একসাথে করে)।

প্রথমবার একটা প্রশ্ন আসতে পারে "Which Firebase project?" — সেখানে
আপনার প্রজেক্ট (`abm-corporation`) বেছে নিন।

২-৩ মিনিট সময় লাগতে পারে। শেষে "Deploy complete!" দেখালে হয়ে গেছে।

## যাচাই করবেন কীভাবে
Deploy করার পর app-এ লগইন করুন। যদি সব ঠিকঠাক হয়, কিছুই আলাদা দেখাবে না
(এটাই স্বাভাবিক) — কিন্তু এখন থেকে Firestore rules সত্যিই যাচাই করবে কে
কোন role, শুধু "লগইন আছে কিনা" না।

## যদি কোনো ধাপে আটকে যান
error message-টা কপি করে পাঠান — screenshot-ও দিতে পারেন, আগের মতোই।
