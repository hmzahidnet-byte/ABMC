/**
 * ABM ERP — Cloud Functions
 *
 * SECURITY REDESIGN (this pass): the previous setUserRoleClaim accepted an
 * arbitrary `employeeId` from ANY authenticated (including anonymous)
 * caller and stamped THAT employee's role onto the caller's own token —
 * meaning any signed-in device could impersonate the MD by simply passing
 * the MD's employeeId. This is now fixed by requiring a real, server-
 * or-admin-created UserIdentityBinding record between the caller's own
 * Firebase UID and one specific employee — the function no longer trusts
 * anything the client supplies for "who am I", only what's already bound.
 */

const functions = require("firebase-functions");
const admin = require("firebase-admin");
const { onDocumentWritten } = require("firebase-functions/v2/firestore");
const { onSchedule } = require("firebase-functions/v2/scheduler");

admin.initializeApp();

/**
 * Part F — setUserRoleClaim, redesigned.
 *
 * The client sends ONLY companyId (which company's binding to look up —
 * still not "who am I", just "which tenant"). Everything about identity
 * (employeeId, role, division, district) is derived server-side from a
 * UserIdentityBinding document keyed by the CALLER'S OWN uid, which only
 * a trusted onboarding/admin flow may have created. If no binding exists,
 * or it's inactive, or the bound account/employee is inactive, this fails
 * closed — no claim is issued, ever, rather than falling back to trusting
 * the client.
 */
exports.setUserRoleClaim = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      "unauthenticated",
      "You must be signed in to claim a role.",
    );
  }

  const companyId = data.companyId;
  if (!companyId) {
    throw new functions.https.HttpsError(
      "invalid-argument",
      "companyId is required.",
    );
  }

  const db = admin.firestore();
  const callerUid = context.auth.uid;

  // The binding is looked up by the CALLER'S OWN uid — never by a
  // client-supplied employeeId. A client cannot request "give me the MD's
  // role" by passing a different id; there is no id parameter to abuse.
  const bindingSnap = await db
    .collection("companies").doc(companyId)
    .collection("identityBindings").doc(callerUid)
    .get();

  if (!bindingSnap.exists) {
    throw new functions.https.HttpsError(
      "permission-denied",
      "No authorized identity binding exists for this device/account yet. Contact your administrator to complete account setup.",
    );
  }

  const binding = bindingSnap.data() || {};
  if (binding.active !== true) {
    throw new functions.https.HttpsError(
      "permission-denied",
      "This identity binding has been deactivated.",
    );
  }

  const employeeId = binding.employeeProfileId;
  const userAccountId = binding.userAccountId;
  if (!employeeId || !userAccountId) {
    throw new functions.https.HttpsError(
      "failed-precondition",
      "Identity binding is incomplete.",
    );
  }

  // Verify the bound UserAccount itself is still active/not locked — a
  // binding can exist but the account may have since been suspended.
  const accountSnap = await db
    .collection("companies").doc(companyId)
    .collection("userAccounts").doc(userAccountId)
    .get();
  if (!accountSnap.exists || accountSnap.data().active !== true || accountSnap.data().locked === true) {
    throw new functions.https.HttpsError(
      "permission-denied",
      "This account is not active.",
    );
  }

  const roleSnap = await db
    .collection("companies").doc(companyId)
    .collection("employeeRoles").doc(employeeId)
    .get();

  if (!roleSnap.exists) {
    throw new functions.https.HttpsError(
      "not-found",
      "No role record found for the bound employee.",
    );
  }

  const record = roleSnap.data() || {};

  const claims = {
    role: record.role || null,
    companyId: companyId,
    division: record.division || null,
    district: record.district || null,
    employeeId: employeeId,
    userAccountId: userAccountId,
  };

  await admin.auth().setCustomUserClaims(callerUid, claims);

  // Section G/29 — audit every claim issuance server-side (clients can never write this).
  await db
    .collection("companies").doc(companyId)
    .collection("auditLogs").add({
      entityType: "RoleClaim",
      entityId: callerUid,
      action: "ISSUE_CLAIM",
      performedBy: employeeId,
      performedByRole: record.role || "unknown",
      newValueJson: JSON.stringify(claims),
      timestampEpochMillis: Date.now(),
    });

  return { success: true, role: record.role || null };
});

/**
 * Part B/F — createIdentityBinding: the ONLY way a UserIdentityBinding can
 * be created. Requires the CALLER to already hold an HR/Admin/GM/MD/
 * Chairman role claim from their OWN prior legitimate login — an
 * unauthenticated or unprivileged caller cannot create a binding for
 * themselves or anyone else. This is the safe interface Part F calls for;
 * it deliberately does NOT attempt full server-side PIN verification in
 * this source-only pass (that would need a real SMS/PIN backend this
 * project doesn't have configured) — it only ensures no claim can ever be
 * issued without a trusted, audited, admin-authorized binding existing first.
 */
exports.createIdentityBinding = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign-in required.");
  }
  const callerRole = context.auth.token.role;
  const authorizedRoles = ["GM", "MD", "CHAIRMAN", "NSM"]; // HR/Admin-tier — matches this project's existing role hierarchy
  if (!authorizedRoles.includes(callerRole)) {
    throw new functions.https.HttpsError(
      "permission-denied",
      "Only an authorized HR/Admin-tier account may create a login binding.",
    );
  }

  const { companyId, targetUid, employeeProfileId, userAccountId } = data;
  if (!companyId || !targetUid || !employeeProfileId || !userAccountId) {
    throw new functions.https.HttpsError("invalid-argument", "companyId, targetUid, employeeProfileId, and userAccountId are all required.");
  }

  const db = admin.firestore();
  // Fail closed if this uid or employee is already bound to something else — never silently overwrite (Part F: no impersonation, no silent rebinding).
  const existingForUid = await db.collection("companies").doc(companyId).collection("identityBindings").doc(targetUid).get();
  if (existingForUid.exists && existingForUid.data().active === true) {
    throw new functions.https.HttpsError("already-exists", "This device/account is already bound to an employee.");
  }

  await db.collection("companies").doc(companyId).collection("identityBindings").doc(targetUid).set({
    firebaseUid: targetUid,
    companyId,
    userAccountId,
    employeeProfileId,
    active: true,
    verifiedAt: Date.now(),
    verifiedBy: context.auth.uid,
  });

  await db.collection("companies").doc(companyId).collection("auditLogs").add({
    entityType: "IdentityBinding",
    entityId: targetUid,
    action: "CREATE",
    performedBy: context.auth.token.employeeId || context.auth.uid,
    performedByRole: callerRole,
    newValueJson: JSON.stringify({ employeeProfileId, userAccountId }),
    timestampEpochMillis: Date.now(),
  });

  return { success: true };
});

/**
 * Part F bootstrap fix — createIdentityBinding above requires the CALLER
 * to already hold an admin-tier claim, which is exactly the problem: a
 * brand-new employee's own device has NO claim yet, so it can never call
 * createIdentityBinding for itself. Something has to be the first,
 * narrower trust boundary that lets a legitimate new device attach to
 * ITS OWN account for the first time.
 *
 * This function is that boundary. It does NOT verify the PIN itself
 * (this project has no server-side PIN-hash comparison service) — the
 * real trust check is: the UserAccount must exist, be active, not
 * locked, and — critically — have NO existing active binding yet. Once
 * one device has bound to an account, this function refuses to bind a
 * second device to the same account (an admin must use the full
 * createIdentityBinding/re-provisioning flow to move it, which IS
 * claim-gated). This is honestly a narrower guarantee than full
 * server-side PIN verification, but it closes the "never bootstraps at
 * all" gap while keeping a real, single-use trust boundary rather than
 * an open one.
 */
exports.bindDeviceOnFirstLogin = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError("unauthenticated", "Sign-in required.");
  }
  const { companyId, employeeProfileId, userAccountId } = data;
  if (!companyId || !employeeProfileId || !userAccountId) {
    throw new functions.https.HttpsError("invalid-argument", "companyId, employeeProfileId, and userAccountId are all required.");
  }

  const db = admin.firestore();
  const accountSnap = await db.collection("companies").doc(companyId).collection("userAccounts").doc(userAccountId).get();
  if (!accountSnap.exists) {
    throw new functions.https.HttpsError("not-found", "No such account.");
  }
  const account = accountSnap.data();
  if (account.employeeProfileId !== employeeProfileId) {
    throw new functions.https.HttpsError("permission-denied", "Account/employee mismatch.");
  }
  if (account.active !== true || account.locked === true) {
    throw new functions.https.HttpsError("permission-denied", "This account is not active.");
  }

  // RC-1 fix — the original read-then-write here (query for an existing
  // binding, then write) had a real TOCTOU race: two devices calling this
  // within milliseconds of each other could both pass the "no existing
  // binding" check before either writes, both ending up bound to the same
  // employee (breaking the single-slot guarantee entirely). A Firestore
  // transaction on a deterministic lock document (keyed by
  // employeeProfileId, not by the caller's own uid) makes the check-and-
  // claim atomic — only one concurrent transaction can win.
  const targetUid = context.auth.uid;
  const lockRef = db.collection("companies").doc(companyId).collection("employeeBindingLocks").doc(employeeProfileId);
  const bindingRef = db.collection("companies").doc(companyId).collection("identityBindings").doc(targetUid);

  await db.runTransaction(async (tx) => {
    const lockSnap = await tx.get(lockRef);
    if (lockSnap.exists && lockSnap.data().active === true) {
      throw new functions.https.HttpsError("already-exists", "This employee's account is already bound to a device. Contact an administrator to re-provision.");
    }
    tx.set(lockRef, { employeeProfileId, boundUid: targetUid, active: true, claimedAt: Date.now() });
    tx.set(bindingRef, {
      firebaseUid: targetUid,
      companyId,
      userAccountId,
      employeeProfileId,
      active: true,
      verifiedAt: Date.now(),
      verifiedBy: "self-service-first-login",
    });
  });

  await db.collection("companies").doc(companyId).collection("auditLogs").add({
    entityType: "IdentityBinding",
    entityId: targetUid,
    action: "CREATE_SELF_SERVICE",
    performedBy: employeeProfileId,
    performedByRole: "unclaimed",
    newValueJson: JSON.stringify({ employeeProfileId, userAccountId, note: "first-login self-service binding, not admin-verified" }),
    timestampEpochMillis: Date.now(),
  });

  return { success: true };
});

/**
 * Chairman-এর Notice Board-এ কিছু পোস্ট/বদল হলেই সাথে সাথে চলে — company-র
 * সবার registered ফোনে push notification পাঠায়। App-এর নিজের কাজ শুধু
 * "receive" করা (AbmFirebaseMessagingService.kt); "পাঠানো"-টা এখানেই হয়,
 * কারণ এটা একটা server-side trigger — কেউ notice লিখলেই আপনাআপনি চলে,
 * app খোলা থাকুক বা না থাকুক।
 */
exports.onChairmanNoticePosted = onDocumentWritten(
  "companies/{companyId}/orgState/chairmanNotice",
  async (event) => {
    const companyId = event.params.companyId;
    const after = event.data?.after?.data();
    if (!after) return; // deleted, nothing to notify about

    const tokensSnap = await admin
      .firestore()
      .collection("companies").doc(companyId)
      .collection("fcmTokens")
      .get();

    const tokens = tokensSnap.docs
      .map((d) => d.data().token)
      .filter((t) => typeof t === "string" && t.length > 0);

    if (tokens.length === 0) return;

    const message = {
      notification: {
        title: "Chairman-এর নতুন নোটিশ",
        body: after.caption || "একটা নতুন নোটিশ পোস্ট হয়েছে।",
      },
      tokens: tokens,
    };

    const response = await admin.messaging().sendEachForMulticast(message);
    functions.logger.info(
      `Chairman notice push: ${response.successCount} success, ${response.failureCount} failed`,
    );
  },
);

/**
 * প্রতিদিন রাতে একবার নিজে থেকে চলে (Payroll screen খোলার অপেক্ষা করে না)
 * — প্রতিটা কোম্পানির প্রতিটা employee-র জন্য আজকের attendance record
 * আছে কিনা চেক করে, না থাকলে "অনুপস্থিত" হিসেবে লিখে রাখে। এর ফলে
 * Payroll-এর absence-count সবসময় real-time-এর কাছাকাছি থাকে, কেউ app
 * না খুললেও।
 */
exports.dailyAbsenceSweep = onSchedule(
  { schedule: "0 20 * * *", timeZone: "Asia/Dhaka" }, // প্রতিদিন রাত ৮টা, বাংলাদেশ সময়
  async () => {
    const db = admin.firestore();
    const companiesSnap = await db.collection("companies").get();
    const todayEpochDay = Math.floor(Date.now() / 86400000);

    for (const companyDoc of companiesSnap.docs) {
      const companyId = companyDoc.id;
      const payrollSnap = await db
        .collection("companies").doc(companyId)
        .collection("payroll")
        .get();

      for (const payrollDoc of payrollSnap.docs) {
        const employeeId = payrollDoc.id;
        const attendanceDocId = `${employeeId}_${todayEpochDay}`;
        const attendanceRef = db
          .collection("companies").doc(companyId)
          .collection("attendance").doc(attendanceDocId);
        const existing = await attendanceRef.get();
        if (existing.exists) continue; // already checked in today, nothing to do

        await attendanceRef.set({
          employeeId,
          dateEpochDay: todayEpochDay,
          checkedIn: false,
          gpsValid: false,
        });
      }
    }
    functions.logger.info(`dailyAbsenceSweep: processed ${companiesSnap.size} companies`);
  },
);

/**
 * Market Analysis-এর ভারী হিসাব (সব dealer-এর zone-wise sales/due যোগফল)
 * প্রতি ঘণ্টায় একবার আগে থেকেই বানিয়ে রাখে, যাতে Chairman/MD-এর ফোন
 * প্রতিবার screen খোলার সময় শত শত dealer-এর ডেটা টেনে নিজে যোগফল না করে
 * — শুধু এই ছোট্ট, আগে-থেকে-বানানো summary document-টা পড়লেই হয়।
 */
exports.hourlyMarketSummary = onSchedule(
  { schedule: "0 * * * *", timeZone: "Asia/Dhaka" }, // প্রতি ঘণ্টায় একবার
  async () => {
    const db = admin.firestore();
    const companiesSnap = await db.collection("companies").get();

    for (const companyDoc of companiesSnap.docs) {
      const companyId = companyDoc.id;
      const dealersSnap = await db
        .collection("companies").doc(companyId)
        .collection("dealers")
        .get();

      const byZone = {};
      dealersSnap.docs.forEach((d) => {
        const data = d.data();
        const zone = data.zone || "Unknown";
        if (!byZone[zone]) byZone[zone] = { salesLast90Days: 0, dueBalance: 0 };
        byZone[zone].salesLast90Days += data.salesLast90Days || 0;
        byZone[zone].dueBalance += data.dueBalance || 0;
      });

      await db
        .collection("companies").doc(companyId)
        .collection("orgState").doc("marketSummary")
        .set({ byZone, computedAtMillis: Date.now() });
    }
    functions.logger.info(`hourlyMarketSummary: processed ${companiesSnap.size} companies`);
  },
);
