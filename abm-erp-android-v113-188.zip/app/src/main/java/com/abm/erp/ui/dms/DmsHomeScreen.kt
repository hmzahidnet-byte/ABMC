package com.abm.erp.ui.dms

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.core.ModuleDrawerItem
import com.abm.erp.core.ModuleDrawerScaffold
import com.abm.erp.core.ModuleDrillRow
import com.abm.erp.core.rememberVisibleDealers
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * DMS — Dealer Management System. One of the six mother modules.
 *
 * Built to the person's hand-drawn DMS draft: a left drawer with the module's own
 * options, and everything about a dealer living *inside* here — nothing pulled out
 * into a cross-cutting screen, and no other mother module visible from in here.
 *
 * Where an option already exists as working code elsewhere, this hosts that exact
 * composable rather than writing a second copy. That is deliberate: duplicating the
 * dealer invoice UI would mean two places to fix every future bug, and the person's
 * standing rule is one home per feature.
 */
private val DMS_COLOR_START = 0xFF2563EB
private val DMS_COLOR_END = 0xFF1E3A8A

private val DMS_ITEMS_BASE = listOf(
    ModuleDrawerItem("dashboard", "DMS Dashboard", Icons.Filled.Home, "সারসংক্ষেপ"),
    ModuleDrawerItem("invoice", "Invoice", Icons.Filled.Description, "Direct Invoice + Auto Data"),
    ModuleDrawerItem("ledger", "Ledger", Icons.Filled.MenuBook, "Financial Reports"),
    ModuleDrawerItem("message", "Message / CRM", Icons.Filled.Forum, "Offer / Due / Custom SMS"),
    ModuleDrawerItem("stock", "Stock", Icons.Filled.Inventory2, "Dealer Stock Control"),
    ModuleDrawerItem("list", "List", Icons.Filled.ListAlt, "Dealer Info & Full History"),
    ModuleDrawerItem("approve", "Approve", Icons.Filled.FactCheck, "Approvals & Permissions"),
    ModuleDrawerItem("logistic", "Logistic", Icons.Filled.LocalShipping, "Courier Tracking & API"),
    ModuleDrawerItem("newdealer", "New Dealer Add", Icons.Filled.PersonAdd, "Add Dealer & QR Generate"),
    ModuleDrawerItem("finance", "Finance", Icons.Filled.Payments, "Finance & Cash Management"),
    ModuleDrawerItem("complain", "Complain", Icons.Filled.ReportProblem, "Dealer Complaints"),
)

// v113-167 — same pattern as HR: one drawer item, always last, Chairman-only,
// hosting every Chairman-only-gated action for this module. Dealer/Retailer
// approve uses the broader GM/MD/AGM/Chairman tier (same as Invoice) so it
// stays in "approve" as-is — only setCourierApiConfig is genuinely
// Chairman-only-gated in DMS.
private val DMS_CHAIRMAN_ITEM = ModuleDrawerItem("chairman", "Chairman", Icons.Filled.Star, "Dealer Control · Product · Restore · Courier API")

@Composable
fun DmsHomeScreen(
    startKey: String? = null,
    onBackToHome: () -> Unit = {},
    onNavigate: (String) -> Unit = {},
) {
    var selected by remember { mutableStateOf(startKey ?: "dashboard") }
    val salesVm: com.abm.erp.ui.sales.SalesChainViewModel = viewModel()
    val dealersVm: com.abm.erp.ui.dealer.DealersScreenViewModel = viewModel()
    val dealers = rememberVisibleDealers()
    val isChairman = MockRepository.currentUser.role == com.abm.erp.data.UserRole.CHAIRMAN
    val items = if (isChairman) DMS_ITEMS_BASE + DMS_CHAIRMAN_ITEM else DMS_ITEMS_BASE

    ModuleDrawerScaffold(
        moduleName = "DMS",
        moduleSubtitle = "Dealer Management System",
        colorStart = DMS_COLOR_START,
        colorEnd = DMS_COLOR_END,
        moduleIcon = Icons.Filled.Business,
        items = items,
        selectedKey = selected,
        onSelect = { selected = it },
        onBackToHome = onBackToHome,
    ) { key ->
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            when (key) {
                "dashboard" -> DmsDashboard(dealers)
                // v113-80 — the workspace contract's reference implementation: the whole
                // invoice operation in ONE screen (dealer QR/search/add + financial
                // context + product + offer/discount + return + summary + approve +
                // history). Old DealerInvoiceTab remains for legacy Sales suite until
                // the final strip-down.
                "invoice" -> DmsInvoiceWorkspace(onNavigate)
                "ledger" -> DmsDealerPickerList(
                    dealers = dealers,
                    emptyText = "আপনার এলাকায় কোনো dealer নেই।",
                    subtitleFor = { d -> "Due ৳${"%,.0f".format(d.dueBalance)}" },
                ) { d -> onNavigate("statement/DEALER/${d.id}") }
                "stock" -> DmsDealerPickerList(
                    dealers = dealers,
                    emptyText = "আপনার এলাকায় কোনো dealer নেই।",
                    subtitleFor = { d -> d.zone },
                ) { d -> onNavigate("dealer_stock/${d.id}") }
                // v113-84 — the approved DMS browse flow (reference image + signed-off
                // JSX): List → Details → Ledger / Product Graph / 90 Days / Calendar /
                // QR ID Card, with search, quick-filter chips and custom filter. Replaces
                // the old flat DirectoryTab, which stays available to the legacy Dealers
                // screen until the final strip-down.
                "list" -> com.abm.erp.core.ModuleBrowseList(
                    config = com.abm.erp.core.rememberDealerBrowseConfig(
                        zones = remember(dealers) { dealers.map { it.zone }.filter { it.isNotBlank() }.distinct().sorted() },
                    ),
                    records = dealers,
                    onBack = { selected = "dashboard" },
                    onNavigate = onNavigate,
                )
                "approve" -> DmsApprove(dealers, salesVm, onNavigate)
                "logistic" -> com.abm.erp.ui.courier.CourierScreen()
                "newdealer" -> com.abm.erp.ui.dealer.AddDealerForm(dealersVm) { selected = "list" }
                // v113-81 — workspace contract: whole collection operation in one screen
                // (party QR/search + due context + entry + dual-control verify history).
                "finance" -> com.abm.erp.core.CollectionWorkspace(
                    partyType = com.abm.erp.data.PartyType.DEALER, partyLabel = "Dealer",
                    parties = remember(dealers) { dealers.map { com.abm.erp.core.CollectionParty(it.id, it.name, it.zone, it.dueBalance) } },
                    onNavigate = onNavigate,
                )
                "message" -> com.abm.erp.core.PartyCampaignSection(
                    audienceLabel = "Dealer",
                    zones = remember(dealers) { dealers.map { it.zone }.filter { it.isNotBlank() }.distinct().sorted() },
                )
                // v113-77 — hosted from GeoCrmScreen (made internal); CRM's own tab now
                // points here. One implementation, one home.
                "complain" -> com.abm.erp.ui.crm.CustomerComplaintsTab(dealers)
                "chairman" -> if (isChairman) DmsChairmanPanel() else DmsDashboard(dealers)
                else -> DmsDashboard(dealers)
            }
        }
    }
}

/**
 * v113-175 — person's specific request for DMS's Chairman panel: a clean
 * approval-only view, not a full browse. If someone wants to add a dealer,
 * that shows here for Chairman to approve — plus Dealer Cancellation and
 * Collection verification (anyone can log a collection; Chairman verifies
 * it). All three already exist as real repository functions
 * (approveDealer/rejectDealer, deleteDealer, verifyCollection/
 * rejectCollection) — this is their first home inside the new DMS module
 * (previously only reachable via the legacy DealersScreen).
 */
@Composable
private fun DmsApprovalsPanel() {
    val dealers by MockRepository.dealers.collectAsState()
    val collections by MockRepository.partyCollections.collectAsState()
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    val pendingDealers = remember(dealers) { dealers.filter { !it.isDeleted && !it.isActive && it.status == "PENDING_APPROVAL" } }
    val activeDealers = remember(dealers) { dealers.filter { !it.isDeleted && it.isActive } }
    val pendingCollections = remember(collections) { collections.filter { it.status == "PENDING" } }

    fun toast(msg: String) = android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()

    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Text("Dealer Add (${pendingDealers.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingDealers.isEmpty()) Text("কোনো pending dealer নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingDealers.forEach { d ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(d.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(d.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { scope.launch { MockRepository.approveDealer(d.id, onRejected = { r -> toast(r) }) } }) { Text("Approve") }
                    TextButton(onClick = { scope.launch { MockRepository.rejectDealer(d.id, "Rejected by Chairman", onRejected = { r -> toast(r) }) } }) { Text("Reject", color = DangerRed) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Dealer Cancellation", fontWeight = FontWeight.Bold, color = TextPrimary)
        Text("সক্রিয় dealer বাতিল করুন — soft delete, পুনরুদ্ধার Restore tab থেকে সম্ভব।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        var cancelQuery by remember { mutableStateOf("") }
        OutlinedTextField(value = cancelQuery, onValueChange = { cancelQuery = it }, placeholder = { Text("Dealer নাম খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        activeDealers.filter { cancelQuery.isBlank() || it.name.contains(cancelQuery, true) }.take(20).forEach { d ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(d.name, color = TextPrimary, modifier = Modifier.weight(1f))
                    TextButton(onClick = { scope.launch { MockRepository.deleteDealer(d.id, onRejected = { r -> toast(r) }) } }) { Text("Cancel", color = DangerRed) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Dealer Collections (${pendingCollections.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingCollections.isEmpty()) Text("কোনো pending collection নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingCollections.forEach { c ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.partyName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("৳${"%,.0f".format(c.amount)} · ${c.method}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { scope.launch { MockRepository.verifyCollection(c.id, onRejected = { r -> toast(r) }) } }) { Text("Verify") }
                    TextButton(onClick = { scope.launch { MockRepository.rejectCollection(c.id, onRejected = { r -> toast(r) }) } }) { Text("Reject", color = DangerRed) }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun DmsChairmanPanel() {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        androidx.compose.material3.ScrollableTabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Approvals") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Dealer Control") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Product Control") })
            Tab(selected = tab == 3, onClick = { tab = 3 }, text = { Text("Restore") })
            Tab(selected = tab == 4, onClick = { tab = 4 }, text = { Text("Courier API") })
        }
        when (tab) {
            0 -> DmsApprovalsPanel()
            1 -> {
                // v113-172 — moved from the central Chairman module's "parties" item
                // (dealer half — retailer half is now RMS's own Chairman tab).
                val dealers = com.abm.erp.core.rememberVisibleDealers()
                com.abm.erp.core.ModuleBrowseList(
                    config = com.abm.erp.core.rememberDealerBrowseConfig(
                        zones = remember(dealers) { dealers.map { it.zone }.filter { it.isNotBlank() }.distinct().sorted() },
                    ),
                    records = dealers,
                    onBack = {},
                    onNavigate = {},
                )
            }
            2 -> com.abm.erp.ui.chairmanmodule.ChairmanProductControl()
            3 -> Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
                Text("Soft-deleted রেকর্ড দেখা ও restore — hard delete এই অ্যাপে নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Spacer(Modifier.height(8.dp))
                com.abm.erp.ui.chairmanmodule.DmsInvoiceRestoreSection()
                Spacer(Modifier.height(8.dp))
                com.abm.erp.ui.chairmanmodule.DmsDealerRestoreSection()
                Spacer(Modifier.height(8.dp))
                com.abm.erp.ui.chairmanmodule.DmsProductRestoreSection()
            }
            else -> com.abm.erp.ui.courier.CourierApiConfigPanel()
        }
    }
}

@Composable
private fun DmsDashboard(dealers: List<com.abm.erp.data.Dealer>) {
    val invoices by MockRepository.salesInvoices.collectAsState()
    val approvals by MockRepository.approvals.collectAsState()
    val totalDue = remember(dealers) { dealers.sumOf { it.dueBalance } }
    val pendingInvoices = remember(invoices) { invoices.count { it.status == "PENDING" && !it.isDeleted } }
    val pendingApprovals = remember(approvals) {
        approvals.count { it.status == com.abm.erp.data.ApprovalStatus.PENDING && it.entityType == "SalesInvoice" }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("DMS Overview", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(4.dp))
        Text(
            "আপনার cascade scope অনুযায়ী — অন্য এলাকার dealer এখানে গোনা হয় না।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(12.dp))
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            DmsStatRow("Dealer", "${dealers.size}", TextPrimary)
            DmsStatRow("Total Due", "৳${"%,.0f".format(totalDue)}", if (totalDue > 0) WarningAmber else SuccessGreen)
            DmsStatRow("Pending Invoice", "$pendingInvoices", if (pendingInvoices > 0) WarningAmber else SuccessGreen)
            DmsStatRow("Pending Approval", "$pendingApprovals", if (pendingApprovals > 0) WarningAmber else SuccessGreen)
        }
        // v113-139 — person asked every mother-module dashboard to carry a KPI
        // graphic. Uses the SHARED DualSeriesBarChart and real invoice/collection
        // rows for the dealers in this user's own cascade scope — no sample data,
        // and no second charting implementation.
        val collections by MockRepository.partyCollections.collectAsState()
        val myDealerIds = remember(dealers) { dealers.map { it.id }.toSet() }
        val weekly = remember(invoices, collections, myDealerIds) {
            val today = java.time.LocalDate.now()
            val thisMonday = today.minusDays((today.dayOfWeek.value - 1).toLong())
            (4 downTo 0).map { w ->
                val start = thisMonday.minusWeeks(w.toLong())
                val end = start.plusDays(7)
                val sales = invoices.filter { !it.isDeleted && it.dealerId in myDealerIds && !it.createdAt.toLocalDate().isBefore(start) && it.createdAt.toLocalDate().isBefore(end) }
                    .sumOf { inv -> inv.lineItems.sumOf { it.lineTotal } }
                val col = collections.filter { it.status == "VERIFIED" && it.partyId in myDealerIds && !it.createdAt.toLocalDate().isBefore(start) && it.createdAt.toLocalDate().isBefore(end) }
                    .sumOf { it.amount }
                Triple("${start.dayOfMonth}/${start.monthValue}", sales, col)
            }
        }
        if (weekly.any { it.second > 0.0 || it.third > 0.0 }) {
            Spacer(Modifier.height(12.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Sales vs Collection — Last 5 Weeks", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                com.abm.erp.core.DualSeriesBarChart(weekly, "Sales", "Collection")
            }
        }
    }
}

@Composable
private fun DmsStatRow(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Text(value, fontWeight = FontWeight.Bold, color = color)
    }
}

/** Shared "pick a dealer, then drill in" list — used by Ledger and Stock. */
@Composable
private fun DmsDealerPickerList(
    dealers: List<com.abm.erp.data.Dealer>,
    emptyText: String,
    subtitleFor: (com.abm.erp.data.Dealer) -> String,
    onPick: (com.abm.erp.data.Dealer) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(dealers, query) {
        if (query.isBlank()) dealers
        else dealers.filter { it.name.contains(query, true) || it.zone.contains(query, true) }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text("নাম বা এলাকা দিয়ে খুঁজুন…") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(10.dp))
        if (filtered.isEmpty()) Text(emptyText, color = TextSecondary)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { d ->
                ModuleDrillRow(d.name, subtitleFor(d)) { onPick(d) }
            }
        }
    }
}

/**
 * Approve — invoice/discount approvals for dealers, inside DMS where they belong
 * (Decision 2). ApprovalRequest rows (discount/over-limit) are actioned here; the
 * invoice's own ✓ Approve lives inline in the Invoice Workspace's history list
 * (v113-80), so this section points there rather than hosting a second copy.
 */
@Composable
private fun DmsApprove(
    dealers: List<com.abm.erp.data.Dealer>,
    salesVm: com.abm.erp.ui.sales.SalesChainViewModel,
    onNavigate: (String) -> Unit,
) {
    val invoices by MockRepository.salesInvoices.collectAsState()
    val pendingCount = remember(invoices) { invoices.count { it.status == "PENDING" && !it.isDeleted } }
    Column(Modifier.fillMaxSize()) {
        com.abm.erp.core.ModuleApprovalSection(
            title = "Discount / limit অনুমোদনের অপেক্ষায়",
            entityTypes = setOf("SalesInvoice"),
        )
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Pending Invoice", color = TextSecondary)
                Text("$pendingCount", fontWeight = FontWeight.Bold, color = if (pendingCount > 0) WarningAmber else SuccessGreen)
            }
            Text(
                "Invoice-এর ✓ Approve বোতাম Invoice Workspace-এর history তালিকায় — সেখানে dealer-এর due/limit/timeline পাশে থাকে।",
                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
            )
        }
    }
}
