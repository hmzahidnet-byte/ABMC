# Evidence folder
Put raw logs/screenshots here, named `<test-or-spike>_<UTC-timestamp>.<ext>`. For Spike S3 seed one test company, one employee, one `employee_accounts` row mapped to a Supabase test user, and grant that employee a role (e.g. CASHIER) through `core.user_roles`, using a dev seed written for Staging only. Never commit keys, passwords or personal data.
