# Build Verification Report — Mohona ERP Android v0.2

## 1. Result (read this first)
| Item | Result |
| --- | --- |
| Gradle Sync | **UNVERIFIED** — never run |
| Kotlin / Compose compile | **UNVERIFIED** — never run |
| Debug APK | **NOT BUILT** — none is included |
| Install and run on a phone (crash test) | **UNVERIFIED** |
| GitHub Actions workflow run | **UNVERIFIED** — YAML syntax checked locally only |
| Official `gradle-wrapper.jar` | **NOT INCLUDED** (cannot be created without running Gradle; no hand-made binary is supplied). Reliable alternative: the workflow installs the official Gradle 8.9; an optional manual workflow generates the official wrapper. |

Why: the authoring environment had only a Java runtime — no Android SDK, no Gradle, no `javac`/`kotlinc`, and no network.
**No compile success is claimed.**

## 2. What was checked (static checks only — they do NOT prove compilation)
Run on all 23 Kotlin files (3,229 lines):
- Braces/parentheses/brackets balanced in every file.
- Every `com.mohona.erp.*` import resolves to a declaration in the project (0 unresolved).
- Identifier-resolution script: every capitalised identifier (composables, classes, objects) is imported, declared in the same package/file, or a Kotlin built-in. Two findings were reviewed and are **false positives** of the script (a `//` inside a URL string confused its comment stripper; `size`/`width` are properties, not extension functions).
- Extension-function imports (`padding`, `size`, `fillMaxWidth`, `clip`, `background`, `clickable`, `remember`, `pointerInput`, `items`, `dp`, delegates `getValue/setValue`, …): none missing.
- Duplicate public top-level declarations: none. Duplicate feature IDs: none. Every registry `previewKey` has sample data.
- Navigation: 9 `composable()` destinations (login, home, scan, reports, profile, notifications, qr detail, module/{id}, feature/{id}); every route string used by `navigate()` is one of them; every feature ID referenced in code exists in the registry; unknown module/feature IDs render a safe "not found" screen instead of crashing; a missing session redirects to login (no null dereference).
- Namespace = applicationId = `com.mohona.erp`; package directories match; manifest references (theme, icon, round icon, label) all exist; `R.drawable.mohona_logo` exists.
- No experimental Material 3 API, no `@OptIn`, no TopAppBar/ExposedDropdownMenu/Surface(onClick)/chips/LazyVerticalGrid/Divider (all common sources of compile errors).
- GitHub workflow YAML parses.

## 3. Version matrix (chosen from prior knowledge; NOT re-verified online)
Gradle 8.9 • Android Gradle Plugin 8.5.2 (needs Gradle ≥ 8.7) • Kotlin 2.0.20 with `org.jetbrains.kotlin.plugin.compose` (no separate Compose-compiler version) • Compose BOM 2024.09.00 (Material 3 1.3.0) • Navigation Compose 2.8.0 • Activity Compose 1.9.2 • Lifecycle 2.8.5 • Core KTX 1.13.1 • Coroutines 1.8.1 • compileSdk/targetSdk 34, minSdk 26 • Java 17.
Known harmless warnings expected: deprecated `Icons.Filled.TrendingUp` (AutoMirrored variant exists) and `window.statusBarColor`.
If a newer Android Studio asks to upgrade AGP/Gradle, accepting is expected to be fine; if a first build fails, send the first `e:` error lines.

## 4. Remaining compile risks I could not eliminate without a compiler
1. Icon names from `material-icons-extended` (e.g. `Inventory2`, `QrCode2`, `CalendarMonth`, `Storage`, `Science`, `Factory`, `Payments`) — believed correct.
2. Lambda-to-`@Composable` conversions in `ReportWidgets` / `Dashboard` list handling — standard pattern, believed correct.
3. Any API-signature detail that only a compiler would catch.

## 5. Changes from v0.1 to v0.2 (what and why)
- **Registry architecture:** `registry/` (Wing/Feature registry, Wing 1 with 18 planned features, Finance and HR core modules, shared report widgets). Navigation is now generic (`module/{id}`, `feature/{id}`); adding a wing needs no change to login, dashboard or navigation.
- **Login:** removed the guessed company-code→e-mail conversion. Connected mode takes the login ID provisioned for that company account (OD-02), separates authentication from authorization, shows explicit errors for no provisioned account / unprovisioned backend, keeps tokens in memory only, clears state on logout and ends the device session on the server (best effort).
- **Roles:** multi-role users (union of visibility); preview can show two roles; Factory P&L is only a planned, MD-only entry (the sample P&L number card from v0.1 was removed); roles in connected mode come from the server only.
- **States/QR/Menu:** loading/empty/error components; QR resolver abstraction with honest "not verified" results; ⋮ menu catalog lists planned WhatsApp-visual/JPG/PNG/PDF/A4/POS/QR actions as disabled.
- **Build:** GitHub Actions workflow (+ manual wrapper-generator workflow), version 0.2.0 (code 2).
- **Backend:** untouched. SHA-256 of all 36 files under `backend/` is identical to v0.1. Nothing in it has been executed against PostgreSQL/Supabase; none of it is Verified.

## 6. Acceptance checklist
1 Android Studio project ✔ • 2 all Kotlin sources ✔ • 3 Gradle config ✔ • 4 wrapper: documented alternative ✔ (jar absent) • 5 GitHub Actions workflow ✔ (unrun) • 6 Compose UI and navigation ✔ (unbuilt) • 7 multi-wing structure ✔ • 8 preview mode ✔ • 9 connected-mode foundation ✔ (unverified against any server) • 10 backend and appendices preserved ✔ • 11 Bengali README ✔ • 12 this report ✔.
