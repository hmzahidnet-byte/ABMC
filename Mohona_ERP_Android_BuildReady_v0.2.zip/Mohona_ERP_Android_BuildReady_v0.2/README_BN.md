# মোহনা — Android অ্যাপ v0.2 (GitHub-এ Build-Ready প্রিভিউ)

Native Android: Kotlin • Jetpack Compose • Material 3 • MVVM • Navigation Compose। কমলা-সাদা, শুধু হালকা থিম, সব লেখা বাংলা।

> **সততা-নোট:** এই ZIP তৈরির পরিবেশে Android SDK, Gradle ও নেটওয়ার্ক ছিল না, তাই প্রকল্প **কখনো Build করা হয়নি**। Gradle Sync, Compile, APK তৈরি ও ফোনে চালানো **UNVERIFIED**। বিস্তারিত: `BUILD_VERIFICATION_REPORT.md`। কোনো APK দেওয়া হয়নি।

## ক) GitHub Actions দিয়ে APK বানানো (প্রস্তাবিত, কম্পিউটারে Android Studio না থাকলেও চলে)
1. GitHub-এ একটি **Private** Repository খুলুন।
2. ZIP আনজিপ করে **ভেতরের সব ফাইল ও ফোল্ডার** (`app`, `gradle`, `.github`, `backend`, `build.gradle.kts` ইত্যাদি) Repository-র মূল স্তরে আপলোড করুন (ZIP নিজে নয়; লুকানো `.github` ফোল্ডারটিও দিন)।
3. Repository-র **Actions** ট্যাবে যান। আপলোডের সাথেই “Android Debug APK” চলবে; না চললে ওই Workflow বেছে **Run workflow** চাপুন।
4. সবুজ টিক এলে Run খুলে নিচে **Artifacts → mohona-erp-debug-apk** ডাউনলোড করুন। ভেতরে `app-debug.apk`।
5. APK ফোনে পাঠিয়ে খুলুন; “অজানা উৎস থেকে ইনস্টল” অনুমতি দিন।
6. লাল ✗ এলে Run-এর লগ খুলে `e:` দিয়ে শুরু লাইনগুলো কপি করে পাঠান; ঠিক করে দেব। (“build-failure-logs” নামের Artifact-এও লগ থাকে।)

কোনো Secret/Key Repository-তে রাখবেন না। সংযুক্ত মোডের কী শুধু আপনার নিজের কম্পিউটারের `local.properties`-এ (Git-এ যায় না)।

## খ) Android Studio দিয়ে Build
Android Studio Koala (২০২৪.১.১) বা নতুন → **Open** → ফোল্ডার বাছুন → Gradle Sync শেষ হলে **Build → Build APK(s)** → `app/build/outputs/apk/debug/app-debug.apk`।

## Gradle Wrapper (`gradle-wrapper.jar`) — সীমাবদ্ধতা
এই ZIP-এ **gradle-wrapper.jar নেই**: অফিসিয়াল Gradle চালানো যায়নি, আর অযাচাইকৃত Binary বানিয়ে দেওয়া হয়নি। বিকল্প (সবগুলোই অফিসিয়াল Gradle দিয়ে):
- **GitHub Actions** (`android-build.yml`) নিজেই অফিসিয়াল Gradle ৮.৯ ইনস্টল করে Build করে — Wrapper লাগে না।
- Wrapper চাইলে **Actions → “Generate Gradle Wrapper (manual)” → Run workflow** চালান, Artifact `gradle-wrapper-files` নামিয়ে `gradle/wrapper/gradle-wrapper.jar` Repository-তে যোগ করুন। তখন Workflow স্বয়ংক্রিয়ভাবে Wrapper-যাচাই (validation) করবে।
- অথবা নিজের কম্পিউটারে Gradle থাকলে `gradle wrapper --gradle-version 8.9`।
- Android Studio Wrapper-এর jar ছাড়াই `gradle-wrapper.properties` দেখে Gradle ৮.৯ নামিয়ে নেয়।

## মোড
**প্রিভিউ (ডিফল্ট):** ইন্টারনেট/Supabase ছাড়া চলে। ১৭ ভূমিকার একটি (ঐচ্ছিক দ্বিতীয় ভূমিকাসহ) বেছে প্রবেশ। এটি শুধু ডেমো-পর্দা বদলায়; কোনো ব্যাকএন্ড-অধিকার দেয় না। সব তথ্য নমুনা, কিছুই সংরক্ষণ/পোস্ট হয় না।

**সংযুক্ত (Staging, ঐচ্ছিক):** `local.properties.example` কপি করে `local.properties` করুন এবং `SUPABASE_URL`, `SUPABASE_ANON_KEY` (শুধু anon/publishable কী; service_role/secret কী অ্যাপ প্রত্যাখ্যান করে) দিন।
- লগইন আইডি = **ওই কোম্পানির জন্য প্রদত্ত** অ্যাকাউন্টের আইডি; অ্যাপ কোম্পানি-কোড থেকে ইমেইল অনুমান করে না (OD-02: প্রতি কোম্পানিতে আলাদা অ্যাকাউন্ট)।
- ধাপ ১ প্রমাণীকরণ; ধাপ ২ সার্ভার থেকে অনুমতি-তালিকা (`api.v1_get_my_permissions`)। অ্যাকাউন্ট প্রদান না হলে বা ব্যাকএন্ড Migration প্রয়োগ না থাকলে পরিষ্কার বাংলা Error দেখায়।
- টোকেন শুধু মেমরিতে; লগআউটে সার্ভারে এই ডিভাইসের সেশন শেষ (সর্বোত্তম চেষ্টা) ও লোকাল অবস্থা মোছা।
- এখন ব্যাকএন্ডে কেবল ওই একটি ফাংশন লেখা আছে (এবং Database-এ এখনো চালানো হয়নি)। বাকি পর্দা সংযুক্ত মোডেও প্রিভিউ।

## ভবিষ্যৎ Wing যোগ করার নিয়ম (Core না ভেঙে)
`app/src/main/java/com/mohona/erp/registry/`:
- `Registry.kt` — `AppRegistry.modules` তালিকা, `Feature`/`ModuleDef`।
- `ManufacturingWing.kt` — Wing ১ (৫টি প্রিভিউ-পর্দা + ২১টির মধ্যে বাকি **পরিকল্পিত** ফিচার, যেমন BOM, QC, Factory P&L (শুধু এমডি))।
- `CoreModules.kt` — অর্থ ও এইচআর (কোম্পানি-ব্যাপী)।
- `ReportWidgets.kt` — চার্ট/সারাংশ কার্ড।
নতুন Wing = একটি নতুন `XxxWing.kt` ফাইল + `AppRegistry.modules`-এ এক লাইন। লগইন, ড্যাশবোর্ড, নেভিগেশন, QR, ⋮ মেনু বদলাতে হয় না। ভবিষ্যৎ Wing-এর নাম/নিয়ম এখন অনুমান করে বসানো হয়নি।

## কী আছে
লগইন • ড্যাশবোর্ড (লোগো-হেডার, বিজ্ঞপ্তি/প্রোফাইল, দ্রুত কাজ, সারাংশ কার্ড, ৫টি ইন্টারঅ্যাক্টিভ চার্ট, সাম্প্রতিক কার্যক্রম) • উইং ১ (উৎপাদন): কাঁচামাল, উৎপাদন, তৈরি পণ্য, স্টক, কিউসি (নমুনা) ও পরিকল্পিত ফিচারের তালিকা • অর্থ: ভাউচার, লেজার, অনুমোদন, রিপোর্ট (নমুনা) • এইচআর: কর্মী, হাজিরা, বেতন (নমুনা) • স্ক্যান ও QR বিবরণ • রিপোর্ট • প্রোফাইল • বিজ্ঞপ্তি • নিচের বার: হোম, স্ক্যান, রিপোর্ট, প্রোফাইল।

## যা এখনো প্রিভিউ/নিষ্ক্রিয়/পরিকল্পিত (ভান করা হয়নি)
- কোনো আর্থিক, অনুমোদন, স্টক বা এইচআর লেনদেন সংরক্ষণ হয় না; “নতুন ভাউচার”, “অনুমোদন/ফেরত” বোতাম নিষ্ক্রিয়।
- “পরিকল্পিত” চিহ্নিত ফিচারে চাপলে শুধু ব্যাখ্যা-পাতা খোলে; ভেতরে কোনো কার্যকারিতা নেই।
- ক্যামেরা-QR-স্ক্যানার নেই; QR-ছবি “ডেমো”।
- ⋮ মেনুতে শুধু “রেফারেন্স কপি” (ক্লিপবোর্ড) ও “QR দেখুন (ডেমো)” সক্রিয়। WhatsApp-এ হুবহু পর্দা-ছবি, JPG/PNG, PDF, A4/POS প্রিন্ট, QR তৈরি, ইতিহাস, কল/WhatsApp/ইমেইল **নিষ্ক্রিয়/পরিকল্পিত**।
- চার্ট ও সারাংশের সব সংখ্যা নমুনা (“নমুনা তথ্য” চিহ্নসহ)।
- Factory P&L শুধু “পরিকল্পিত” তালিকায় এবং শুধু এমডি-ভূমিকায় দেখা যায়; কোনো সংখ্যা দেখানো হয় না।
- কোম্পানির মধ্যে লেনদেন বন্ধ; VAT/Tax ও CCTV নেই।

## ব্যাকএন্ড (অপরিবর্তিত)
`backend/` — SQL Migration (৯টি), Test, Spike-স্ক্রিপ্ট, Release-Gate, Appendix E–H। **v0.1-এর সাথে প্রতিটি ফাইলের SHA-256 হুবহু এক**। কোনোটি এখনো Database-এ চালানো হয়নি; Verified নয়।

## লোগো বদলানো
`app/src/main/res/drawable/mohona_logo.xml` (প্লেসহোল্ডার) মুছে একই নামে `mohona_logo.png` রাখুন। অ্যাপ-আইকন: `ic_launcher_foreground.xml`।
