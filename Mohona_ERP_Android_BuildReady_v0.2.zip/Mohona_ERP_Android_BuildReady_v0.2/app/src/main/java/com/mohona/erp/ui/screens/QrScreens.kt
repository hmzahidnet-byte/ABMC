package com.mohona.erp.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.PreviewQrResolver
import com.mohona.erp.core.QrResolutionStatus
import com.mohona.erp.data.SampleData
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.KeyValueRow
import com.mohona.erp.ui.components.PreviewBadge
import com.mohona.erp.ui.components.PreviewBanner
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.UniversalActionMenu
import com.mohona.erp.ui.components.rememberRecordActions
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.OrangeDark
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.TextDark
import com.mohona.erp.ui.theme.TextMuted

/**
 * Scan tab. v0.1 does NOT include the camera scanner: the button is visibly disabled.
 * Typing a code opens the detail screen, which clearly states that no backend verification has happened.
 */
@Composable
fun ScannerScreen(onOpenCode: (String) -> Unit) {
    var manual by remember { mutableStateOf("") }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundGray)
            .verticalScroll(rememberScrollState())
    ) {
        Box(modifier = Modifier.background(Color.White).fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp)) {
            Text("স্ক্যান", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        }
        Column(modifier = Modifier.padding(16.dp)) {
            // Viewfinder frame (decoration only; no camera is opened)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(TextDark),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(220.dp)) {
                    val len = 42.dp.toPx()
                    val sw = 5.dp.toPx()
                    val w = size.width
                    val h = size.height
                    val c = OrangePrimary
                    fun corner(x: Float, y: Float, dx: Float, dy: Float) {
                        drawRoundRect(c, Offset(minOf(x, x + dx * len), y - sw / 2), Size(len, sw), CornerRadius(sw))
                        drawRoundRect(c, Offset(x - sw / 2, minOf(y, y + dy * len)), Size(sw, len), CornerRadius(sw))
                    }
                    corner(0f, 0f, 1f, 1f)
                    corner(w, 0f, -1f, 1f)
                    corner(0f, h, 1f, -1f)
                    corner(w, h, -1f, -1f)
                }
                Text(
                    text = "ক্যামেরা-স্ক্যানার এই সংস্করণে নেই",
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 56.dp)
                )
            }
            Spacer(Modifier.height(14.dp))
            Button(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                Text("ক্যামেরা চালু করুন (শীঘ্রই)")
            }
            Spacer(Modifier.height(18.dp))
            AppCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("কোড হাতে লিখুন", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = manual,
                        onValueChange = { manual = it },
                        label = { Text("QR-কোডের মান") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { onOpenCode(manual.trim()) },
                            enabled = manual.isNotBlank(),
                            modifier = Modifier.weight(1f)
                        ) { Text("খুলুন") }
                        Spacer(Modifier.size(10.dp))
                        OutlinedButton(
                            onClick = { onOpenCode(SampleData.DEMO_QR_CODE) },
                            modifier = Modifier.weight(1f)
                        ) { Text("নমুনা QR দেখুন") }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            PreviewBanner("QR শুধু রেকর্ড চিহ্নিত করে। অনুমোদন, পোস্টিং বা নিরাপত্তা-নিয়ম কখনো এড়ানো হয় না; কাজ চলে অনুমোদিত RPC-র মাধ্যমে।")
        }
    }
}

/** Detail screen for a scanned/typed code. No backend lookup exists yet, and the screen says so. */
@Composable
fun QrDetailScreen(code: String, onBack: () -> Unit) {
    val resolution = remember(code) { PreviewQrResolver().resolve(code) }
    val isDemo = resolution.status == QrResolutionStatus.DEMO_SAMPLE
    val actions = rememberRecordActions(reference = code, onShowQr = null, withContact = false)
    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
        Box(modifier = Modifier.background(Color.White)) {
            ScreenHeader(title = "QR বিবরণ", onBack = onBack, trailing = { UniversalActionMenu(actions) })
        }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            PreviewBanner(resolution.noteBn)
            Spacer(Modifier.height(14.dp))
            AppCard {
                Column(
                    modifier = Modifier.padding(18.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    DemoCodeImage(seed = code)
                    Spacer(Modifier.height(8.dp))
                    PreviewBadge("ডেমো-চিত্র • স্ক্যানযোগ্য নয়")
                    Spacer(Modifier.height(10.dp))
                    Text(code, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(14.dp))
            AppCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    KeyValueRow("কোডের মান", code)
                    KeyValueRow("ধরন", resolution.entityType?.nameBn ?: "অজানা")
                    KeyValueRow("সার্ভার-যাচাই", "হয়নি (ব্যাকএন্ড যুক্ত নয়)")
                    KeyValueRow("অনুমতি-যাচাই", "প্রযোজ্য নয় (প্রিভিউ)")
                }
            }
            Spacer(Modifier.height(14.dp))
            Button(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                Text("রেকর্ড খুলুন (শীঘ্রই)")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                Text("QR প্রিন্ট (শীঘ্রই)")
            }
            Text(
                text = "স্ক্যান থেকে সরাসরি পোস্ট বা অনুমোদন করা যায় না।",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}

/** Pseudo-random square pattern derived from the code. Decoration only; it is NOT a valid QR symbol. */
@Composable
private fun DemoCodeImage(seed: String) {
    val n = 21
    var state = seed.hashCode().toLong() and 0x7fffffffL
    if (state == 0L) state = 12345L
    val cells = BooleanArray(n * n)
    for (i in cells.indices) {
        state = (state * 1103515245L + 12345L) and 0x7fffffffL
        cells[i] = (state shr 16) % 2L == 0L
    }
    Canvas(modifier = Modifier.size(190.dp).background(Color.White)) {
        val cell = size.width / n
        for (r in 0 until n) {
            for (c in 0 until n) {
                val inFinder = (r < 7 && c < 7) || (r < 7 && c >= n - 7) || (r >= n - 7 && c < 7)
                if (!inFinder && cells[r * n + c]) {
                    drawRect(TextDark, Offset(c * cell, r * cell), Size(cell, cell))
                }
            }
        }
        fun finder(r0: Int, c0: Int) {
            drawRect(OrangeDark, Offset(c0 * cell, r0 * cell), Size(7 * cell, 7 * cell))
            drawRect(Color.White, Offset((c0 + 1) * cell, (r0 + 1) * cell), Size(5 * cell, 5 * cell))
            drawRect(OrangeDark, Offset((c0 + 2) * cell, (r0 + 2) * cell), Size(3 * cell, 3 * cell))
        }
        finder(0, 0)
        finder(0, n - 7)
        finder(n - 7, 0)
    }
}
