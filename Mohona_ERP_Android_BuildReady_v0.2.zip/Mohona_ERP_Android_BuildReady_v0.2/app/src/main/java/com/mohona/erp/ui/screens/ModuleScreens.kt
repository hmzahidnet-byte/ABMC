package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.PreviewData
import com.mohona.erp.data.RecordItem
import com.mohona.erp.registry.AppRegistry
import com.mohona.erp.registry.Feature
import com.mohona.erp.registry.FeatureStatus
import com.mohona.erp.registry.ModuleDef
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.PreviewBadge
import com.mohona.erp.ui.components.PreviewBanner
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.SectionTitle
import com.mohona.erp.ui.components.StatusPill
import com.mohona.erp.ui.components.Tone
import com.mohona.erp.ui.components.UniversalActionMenu
import com.mohona.erp.ui.components.rememberRecordActions
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.OrangeDark
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.OrangeSoft
import com.mohona.erp.ui.theme.TextMuted

/** Landing screen of any registry module (Wing or Core): shows existing sample screens first, then planned features. */
@Composable
fun ModuleScreen(
    module: ModuleDef,
    roles: List<String>,
    onBack: () -> Unit,
    onOpenFeature: (String) -> Unit
) {
    val visible = AppRegistry.visibleFeatures(roles, module)
    val preview = visible.filter { it.status == FeatureStatus.PREVIEW }
    val planned = visible.filter { it.status == FeatureStatus.PLANNED }
    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
        Box(modifier = Modifier.background(Color.White)) { ScreenHeader(title = module.nameBn, onBack = onBack) }
        if (visible.isEmpty()) {
            EmptyState("এই ভূমিকার জন্য এই বিভাগে দেখানোর মতো কিছু নেই।")
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { PreviewBanner(module.descBn + "। সব তথ্য নমুনা; ব্যাকএন্ড এখনো যুক্ত নয়।") }
                if (preview.isNotEmpty()) item { SectionTitle("প্রিভিউ-পর্দা (নমুনা তথ্য)") }
                items(preview) { f -> FeatureRow(f, false, onOpenFeature) }
                if (planned.isNotEmpty()) item { SectionTitle("পরিকল্পিত (এখনো তৈরি হয়নি)") }
                items(planned) { f -> FeatureRow(f, true, onOpenFeature) }
            }
        }
    }
}

@Composable
private fun FeatureRow(f: Feature, planned: Boolean, onOpen: (String) -> Unit) {
    AppCard(onClick = { onOpen(f.id) }) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(if (planned) BackgroundGray else OrangeSoft),
                contentAlignment = Alignment.Center
            ) {
                Icon(f.icon, contentDescription = null, tint = if (planned) TextMuted else OrangePrimary)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(f.nameBn, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(f.descBn, style = MaterialTheme.typography.labelSmall, color = TextMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(8.dp))
            if (planned) StatusPill("পরিকল্পিত", Tone.NEUTRAL) else PreviewBadge("নমুনা")
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = TextMuted)
        }
    }
}

/** Opens a feature: a sample-data list for PREVIEW features, an honest "planned" page for the rest. */
@Composable
fun FeatureScreen(
    moduleName: String,
    feature: Feature,
    onBack: () -> Unit,
    onShowQr: (String) -> Unit
) {
    if (feature.status == FeatureStatus.PLANNED) {
        PlannedFeatureScreen(moduleName, feature, onBack)
    } else {
        RecordListScreen(
            title = feature.nameBn,
            intro = "নমুনা তথ্য। কোনো বাস্তব লেনদেন সংরক্ষণ বা পোস্ট হয় না।",
            records = PreviewData.records(feature.previewKey ?: ""),
            onBack = onBack,
            onShowQr = onShowQr,
            primaryActionLabel = feature.primaryActionLabel,
            approvalButtons = feature.approvalButtons
        )
    }
}

@Composable
fun PlannedFeatureScreen(moduleName: String, feature: Feature, onBack: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
        Box(modifier = Modifier.background(Color.White)) { ScreenHeader(title = feature.nameBn, onBack = onBack) }
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            AppCard {
                Column(modifier = Modifier.padding(18.dp)) {
                    StatusPill("পরিকল্পিত — এখনো তৈরি হয়নি", Tone.NEUTRAL)
                    Spacer(Modifier.height(10.dp))
                    Text(feature.nameBn, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(moduleName, style = MaterialTheme.typography.labelMedium, color = OrangeDark)
                    Spacer(Modifier.height(8.dp))
                    Text(feature.descBn, style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "এই বৈশিষ্ট্যের ব্যবসায়িক নিয়ম, ডেটা ও ব্যাকএন্ড এখনো তৈরি হয়নি। তৈরি হলে এই জায়গাতেই যুক্ত হবে; অ্যাপের লগইন, ড্যাশবোর্ড বা নেভিগেশন নতুন করে লিখতে হবে না।",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                    if (feature.requiredPermission != null) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "ভবিষ্যতে সার্ভার-অনুমতি লাগবে: " + feature.requiredPermission,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }
                }
            }
        }
    }
}

/**
 * Generic list screen for sample records. Nothing here is saved or posted;
 * action buttons for operations that need the backend are visibly disabled.
 */
@Composable
fun RecordListScreen(
    title: String,
    intro: String,
    records: List<RecordItem>,
    onBack: () -> Unit,
    onShowQr: (String) -> Unit,
    primaryActionLabel: String? = null,
    approvalButtons: Boolean = false
) {
    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
        Box(modifier = Modifier.background(Color.White)) { ScreenHeader(title = title, onBack = onBack) }
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { PreviewBanner(intro) }
            if (primaryActionLabel != null) {
                item {
                    Button(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                        Text(primaryActionLabel + " (শীঘ্রই)")
                    }
                }
            }
            if (records.isEmpty()) {
                item { EmptyState("দেখানোর মতো কোনো তথ্য নেই।") }
            }
            items(records) { rec -> RecordCard(rec, onShowQr, approvalButtons) }
        }
    }
}

@Composable
private fun RecordCard(rec: RecordItem, onShowQr: (String) -> Unit, approvalButtons: Boolean) {
    val actions = rememberRecordActions(
        reference = rec.reference,
        onShowQr = { onShowQr(rec.reference) },
        withContact = rec.hasContact
    )
    AppCard {
        Column(modifier = Modifier.padding(start = 16.dp, top = 8.dp, end = 4.dp, bottom = 12.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(modifier = Modifier.weight(1f).padding(top = 8.dp)) {
                    Text(rec.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(rec.subtitle, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    Text(rec.reference, style = MaterialTheme.typography.labelSmall, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                UniversalActionMenu(actions)
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(end = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (rec.status.isNotEmpty()) StatusPill(rec.status, rec.tone)
                Spacer(Modifier.weight(1f))
                if (rec.trailing.isNotEmpty()) {
                    Text(rec.trailing, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                }
            }
            if (approvalButtons) {
                Spacer(Modifier.height(10.dp))
                Row(modifier = Modifier.padding(end = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = {}, enabled = false, modifier = Modifier.weight(1f)) { Text("অনুমোদন") }
                    OutlinedButton(onClick = {}, enabled = false, modifier = Modifier.weight(1f)) { Text("ফেরত") }
                }
                Text(
                    "অনুমোদন-ফাংশন ব্যাকএন্ড যুক্ত হলে চালু হবে। প্রিভিউ মোডে কোনো অনুমোদন সংরক্ষিত হয় না।",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted,
                    modifier = Modifier.padding(top = 6.dp, end = 12.dp)
                )
            }
        }
    }
}
