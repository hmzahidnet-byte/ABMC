package com.mohona.erp.registry

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Factory
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import com.mohona.erp.data.Bn
import com.mohona.erp.data.ModuleKeys
import com.mohona.erp.data.RoleAccess
import com.mohona.erp.ui.components.DueCollectionOverview
import com.mohona.erp.ui.components.ProductSalesChart
import com.mohona.erp.ui.components.ProductionComparisonChart
import com.mohona.erp.ui.components.SalesTrendChart
import com.mohona.erp.ui.components.StockSummaryChart

/** Shared reporting infrastructure: wings contribute chart widgets and summary cards here; the dashboard and the reports tab just render them. */
data class ReportWidget(val id: String, val moduleKeys: Set<String>, val content: @Composable () -> Unit)

data class SummaryDef(
    val id: String,
    val moduleKeys: Set<String>,
    val title: String,
    val value: String,
    val caption: String,
    val icon: ImageVector
)

object ReportWidgets {
    val charts: List<ReportWidget> = listOf(
        ReportWidget("sales_trend", setOf(ModuleKeys.REPORTS, ModuleKeys.FINANCE)) { SalesTrendChart() },
        ReportWidget("production_comparison", setOf(ModuleKeys.MANUFACTURING)) { ProductionComparisonChart() },
        ReportWidget("product_sales", setOf(ModuleKeys.REPORTS)) { ProductSalesChart() },
        ReportWidget("stock_summary", setOf(ModuleKeys.MANUFACTURING)) { StockSummaryChart() },
        ReportWidget("due_collection", setOf(ModuleKeys.FINANCE, ModuleKeys.REPORTS)) { DueCollectionOverview() }
    )

    val summaries: List<SummaryDef> = listOf(
        SummaryDef("sales_today", setOf(ModuleKeys.REPORTS, ModuleKeys.FINANCE), "আজকের বিক্রয়", Bn.taka(320000), "গতকালের চেয়ে ৮% বেশি", Icons.Filled.TrendingUp),
        SummaryDef("production_today", setOf(ModuleKeys.MANUFACTURING), "আজকের উৎপাদন", Bn.num(1250) + " ইউনিট", "লক্ষ্যের ৯৬%", Icons.Filled.Factory),
        SummaryDef("stock_value", setOf(ModuleKeys.MANUFACTURING), "মোট স্টক-মূল্য", Bn.taka(26800000), "৩টি গুদাম", Icons.Filled.Storage),
        SummaryDef("due_collection", setOf(ModuleKeys.FINANCE, ModuleKeys.REPORTS), "বকেয়া আদায়", "৬১%", "৫২ লাখ / ৮৫ লাখ", Icons.Filled.Payments),
        SummaryDef("pending_approvals", setOf(ModuleKeys.FINANCE), "অনুমোদন অপেক্ষমাণ", Bn.num(2) + "টি", "ভাউচার", Icons.Filled.CheckCircle),
        SummaryDef("attendance_today", setOf(ModuleKeys.HR), "আজকের উপস্থিতি", Bn.num(42) + " / " + Bn.num(45), "জন কর্মী", Icons.Filled.People)
    )

    fun chartsFor(roles: List<String>): List<ReportWidget> {
        val mods = RoleAccess.modulesFor(roles)
        return charts.filter { w -> w.moduleKeys.any { it in mods } }
    }

    fun summariesFor(roles: List<String>): List<SummaryDef> {
        val mods = RoleAccess.modulesFor(roles)
        return summaries.filter { s -> s.moduleKeys.any { it in mods } }
    }
}
