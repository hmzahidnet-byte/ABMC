package com.mohona.erp.registry

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Factory
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.TrendingUp
import com.mohona.erp.data.ModuleKeys

/**
 * Wing 1 — Manufacturing. Only the five PREVIEW screens exist today (sample data).
 * Everything else is registered as PLANNED so the structure is ready, but nothing pretends to work.
 */
object ManufacturingWing {
    val module = ModuleDef(
        id = "mfg",
        kind = ModuleKind.WING,
        nameBn = "উইং ১ — উৎপাদন",
        descBn = "ফ্যাক্টরির কাঁচামাল, উৎপাদন, মান, স্টক, কর্মী ও হিসাব",
        icon = Icons.Filled.Factory,
        accessKey = ModuleKeys.MANUFACTURING,
        sectioned = true,
        features = listOf(
            // ---- sample-data screens that exist in v0.2 ----
            Feature("mfg.raw", "কাঁচামাল", "মজুত ও গ্রহণ", Icons.Filled.Inventory2, FeatureStatus.PREVIEW, section = "raw", previewKey = "raw", quickAction = true),
            Feature("mfg.production", "উৎপাদন", "ব্যাচ ও অগ্রগতি", Icons.Filled.Factory, FeatureStatus.PREVIEW, section = "production", previewKey = "production", quickAction = true),
            Feature("mfg.fg", "তৈরি পণ্য", "প্রস্তুত মাল", Icons.Filled.ShoppingCart, FeatureStatus.PREVIEW, section = "fg", previewKey = "fg", quickAction = true),
            Feature("mfg.stock", "গুদাম ও স্টক", "গুদামভিত্তিক মূল্য", Icons.Filled.Storage, FeatureStatus.PREVIEW, section = "stock", previewKey = "stock", quickAction = true),
            Feature("mfg.qc", "কিউসি", "মান-পরীক্ষা", Icons.Filled.Science, FeatureStatus.PREVIEW, section = "qc", previewKey = "qc", quickAction = true),
            // ---- planned (no implementation yet) ----
            Feature("mfg.purchase", "কাঁচামাল ক্রয় ও সরবরাহকারীর বকেয়া", "ক্রয়, সরবরাহকারী ও বকেয়া ব্যবস্থাপনা", Icons.Filled.ShoppingCart, FeatureStatus.PLANNED, section = "purchase"),
            Feature("mfg.consumption", "কাঁচামাল ব্যবহার", "উৎপাদনে কাঁচামাল ইস্যু ও ব্যবহার", Icons.Filled.Inventory2, FeatureStatus.PLANNED, section = "consumption"),
            Feature("mfg.planning", "উৎপাদন পরিকল্পনা", "চাহিদা অনুযায়ী উৎপাদন-পরিকল্পনা", Icons.Filled.CalendarMonth, FeatureStatus.PLANNED, section = "planning"),
            Feature("mfg.bom", "রেসিপি / BOM", "পণ্যের উপাদান-তালিকা", Icons.Filled.Description, FeatureStatus.PLANNED, section = "bom"),
            Feature("mfg.batch", "ব্যাচ উৎপাদন", "ব্যাচ-ভিত্তিক উৎপাদন-রেকর্ড", Icons.Filled.Factory, FeatureStatus.PLANNED, section = "batch"),
            Feature("mfg.waste", "অপচয় ও ক্ষতি", "উৎপাদনের অপচয়-হিসাব", Icons.Filled.Refresh, FeatureStatus.PLANNED, section = "waste"),
            Feature("mfg.fgqr", "তৈরি পণ্যের QR", "পণ্য/ব্যাচের QR-লেবেল", Icons.Filled.QrCodeScanner, FeatureStatus.PLANNED, section = "fgqr"),
            Feature("mfg.stockverify", "বাস্তব স্টক যাচাই", "গণনা ও অমিল-নিষ্পত্তি", Icons.Filled.Storage, FeatureStatus.PLANNED, section = "stockverify"),
            Feature("mfg.factory_hr", "ফ্যাক্টরি এইচআর", "কারখানার কর্মী-ব্যবস্থাপনা", Icons.Filled.People, FeatureStatus.PLANNED, section = "factory_hr"),
            Feature("mfg.qr_attendance", "QR হাজিরা", "নির্ধারিত ডিভাইসে QR-হাজিরা", Icons.Filled.QrCodeScanner, FeatureStatus.PLANNED, section = "qr_attendance"),
            Feature("mfg.payroll", "বেতন ও কর্মঘণ্টা", "কর্মঘণ্টা-ভিত্তিক বেতন", Icons.Filled.Payments, FeatureStatus.PLANNED, section = "payroll"),
            Feature("mfg.factory_fin", "ফ্যাক্টরি অর্থ ও লেজার", "কারখানার হিসাব ও খতিয়ান", Icons.Filled.AccountBalance, FeatureStatus.PLANNED, section = "factory_fin"),
            Feature("mfg.costing", "পণ্যের খরচ-নির্ধারণ", "ব্যাচ/পণ্য-ভিত্তিক ব্যয়", Icons.Filled.TrendingUp, FeatureStatus.PLANNED, section = "costing"),
            Feature("mfg.pnl", "ফ্যাক্টরি লাভ-ক্ষতি (শুধু এমডি)", "শুধু সংশ্লিষ্ট কোম্পানির এমডি", Icons.Filled.Assessment, FeatureStatus.PLANNED, onlyRoles = setOf("MD"), requiredPermission = "fin.report.factory_pl"),
            Feature("mfg.maintenance", "মেশিন রক্ষণাবেক্ষণ", "মেশিনের নিয়মিত সেবা ও মেরামত", Icons.Filled.Build, FeatureStatus.PLANNED, section = "maintenance"),
            Feature("mfg.spares", "স্পেয়ার পার্টস", "যন্ত্রাংশের মজুত ও ব্যবহার", Icons.Filled.Settings, FeatureStatus.PLANNED, section = "spares"),
            Feature("mfg.supplier_perf", "সরবরাহকারীর কার্যকারিতা", "সময়মতো ও মানসম্মত সরবরাহ-মূল্যায়ন", Icons.Filled.TrendingUp, FeatureStatus.PLANNED, section = "supplier"),
            Feature("mfg.returns", "বাজার-ফেরত পুনঃপ্যাকেজিং", "ফেরত পণ্য যাচাই ও পুনঃপ্যাক", Icons.Filled.Refresh, FeatureStatus.PLANNED, section = "returns")
        )
    )
}
