package com.mohona.erp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.mohona.erp.ui.navigation.MohonaApp
import com.mohona.erp.ui.theme.MohonaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MohonaTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color.White) {
                    MohonaApp()
                }
            }
        }
    }
}
