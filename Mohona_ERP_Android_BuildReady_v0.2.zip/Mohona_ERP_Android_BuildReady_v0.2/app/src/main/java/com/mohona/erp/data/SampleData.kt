package com.mohona.erp.data

import com.mohona.erp.ui.components.Tone

/** EVERYTHING in this file is SAMPLE data for the UI preview. None of it is a real business record. */
data class RecordItem(
    val reference: String,
    val title: String,
    val subtitle: String,
    val trailing: String = "",
    val status: String = "",
    val tone: Tone = Tone.NEUTRAL,
    val hasContact: Boolean = false
)

data class ActivityItem(val title: String, val detail: String, val time: String)

object SampleData {
    const val DEMO_QR_CODE = "DEMO-VCH-0001"

    val rawMaterials = listOf(
        RecordItem("RM-0001", "কাঁচামাল-ক", "গুদাম-১ • সর্বশেষ গ্রহণ: ৩ দিন আগে", Bn.num(4200) + " কেজি", "পর্যাপ্ত", Tone.GOOD),
        RecordItem("RM-0002", "কাঁচামাল-খ", "গুদাম-১ • সর্বশেষ গ্রহণ: ৯ দিন আগে", Bn.num(850) + " কেজি", "কম", Tone.WARN),
        RecordItem("RM-0003", "প্যাকেজিং ফিল্ম", "গুদাম-২ • সর্বশেষ গ্রহণ: ১ সপ্তাহ আগে", Bn.num(120) + " রোল", "কম", Tone.WARN),
        RecordItem("RM-0004", "রাসায়নিক-গ", "গুদাম-১ • সর্বশেষ গ্রহণ: ২ দিন আগে", Bn.num(60) + " লিটার", "পর্যাপ্ত", Tone.GOOD)
    )

    val productionOrders = listOf(
        RecordItem("PO-0101", "পণ্য-ক • ব্যাচ ১০১", "লক্ষ্য: " + Bn.num(1200) + " ইউনিট", "৮০% সম্পন্ন", "চলমান", Tone.WARN),
        RecordItem("PO-0102", "পণ্য-খ • ব্যাচ ১০২", "লক্ষ্য: " + Bn.num(900) + " ইউনিট", "১০০% সম্পন্ন", "সম্পন্ন", Tone.GOOD),
        RecordItem("PO-0103", "পণ্য-গ • ব্যাচ ১০৩", "লক্ষ্য: " + Bn.num(600) + " ইউনিট", "০% সম্পন্ন", "অপেক্ষমাণ", Tone.NEUTRAL)
    )

    val finishedGoods = listOf(
        RecordItem("FG-0001", "পণ্য-ক", "ব্যাচ ১০১ • গুদাম-৩", Bn.num(960) + " ইউনিট", "প্রস্তুত", Tone.GOOD),
        RecordItem("FG-0002", "পণ্য-খ", "ব্যাচ ১০২ • গুদাম-৩", Bn.num(900) + " ইউনিট", "প্রস্তুত", Tone.GOOD),
        RecordItem("FG-0003", "পণ্য-ঘ", "ব্যাচ ০৯৮ • গুদাম-৩", Bn.num(140) + " ইউনিট", "কিউসি অপেক্ষমাণ", Tone.WARN)
    )

    val stock = listOf(
        RecordItem("ST-0001", "গুদাম-১ (কাঁচামাল)", "৪টি আইটেম", Bn.taka(12000000), "", Tone.NEUTRAL),
        RecordItem("ST-0002", "গুদাম-২ (প্যাকেজিং)", "২টি আইটেম", Bn.taka(1800000), "", Tone.NEUTRAL),
        RecordItem("ST-0003", "গুদাম-৩ (তৈরি পণ্য)", "৫টি আইটেম", Bn.taka(10800000), "", Tone.NEUTRAL)
    )

    val qcChecks = listOf(
        RecordItem("QC-0201", "ব্যাচ ১০১ • চূড়ান্ত পরীক্ষা", "নমুনা: " + Bn.num(30) + "টি", "পাস", "পাস", Tone.GOOD),
        RecordItem("QC-0202", "ব্যাচ ১০২ • চূড়ান্ত পরীক্ষা", "নমুনা: " + Bn.num(30) + "টি", "পাস", "পাস", Tone.GOOD),
        RecordItem("QC-0203", "ব্যাচ ০৯৮ • চূড়ান্ত পরীক্ষা", "নমুনা: " + Bn.num(30) + "টি", "অপেক্ষমাণ", "অপেক্ষমাণ", Tone.WARN)
    )

    val vouchers = listOf(
        RecordItem(DEMO_QR_CODE, "নগদ পরিশোধ ভাউচার", "ক্যাশবাক্স-১ • বিদ্যুৎ বিল", Bn.taka(18500), "খসড়া", Tone.NEUTRAL),
        RecordItem("DEMO-VCH-0002", "নগদ প্রাপ্তি ভাউচার", "ক্যাশবাক্স-১ • খুচরা বিক্রয়", Bn.taka(42000), "অনুমোদনের অপেক্ষায়", Tone.WARN),
        RecordItem("DEMO-VCH-0003", "নগদ পরিশোধ ভাউচার", "ক্যাশবাক্স-২ • পরিবহন", Bn.taka(7200), "পোস্টকৃত", Tone.GOOD)
    )

    val ledger = listOf(
        RecordItem("DEMO-LGR-0001", "নগদ হিসাব • খোলা জের", "০১ নভে", Bn.taka(250000), "জের", Tone.NEUTRAL),
        RecordItem("DEMO-LGR-0002", "নগদ প্রাপ্তি", "০২ নভে • ডেবিট " + Bn.taka(42000), Bn.taka(292000), "", Tone.NEUTRAL),
        RecordItem("DEMO-LGR-0003", "নগদ পরিশোধ", "০৩ নভে • ক্রেডিট " + Bn.taka(7200), Bn.taka(284800), "", Tone.NEUTRAL)
    )

    val approvals = listOf(
        RecordItem("DEMO-APR-0001", "নগদ প্রাপ্তি ভাউচার", "জমাদাতা: নমুনা কর্মী-১", Bn.taka(42000), "অপেক্ষমাণ", Tone.WARN),
        RecordItem("DEMO-APR-0002", "নগদ পরিশোধ ভাউচার", "জমাদাতা: নমুনা কর্মী-২", Bn.taka(9300), "অপেক্ষমাণ", Tone.WARN)
    )

    val financeReports = listOf(
        RecordItem("RPT-F1", "ট্রায়াল ব্যালেন্স", "সব হিসাবের ডেবিট-ক্রেডিট", "", "শীঘ্রই", Tone.NEUTRAL),
        RecordItem("RPT-F2", "ক্যাশ বুক", "ক্যাশবাক্সভিত্তিক", "", "শীঘ্রই", Tone.NEUTRAL),
        RecordItem("RPT-F3", "লেজার বিবরণী", "হিসাবভিত্তিক", "", "শীঘ্রই", Tone.NEUTRAL)
    )

    val employees = listOf(
        RecordItem("EMP-0001", "নমুনা কর্মী-১", "ক্যাশিয়ার • অর্থ বিভাগ", "", "সক্রিয়", Tone.GOOD, true),
        RecordItem("EMP-0002", "নমুনা কর্মী-২", "স্টোরকিপার • গুদাম-১", "", "সক্রিয়", Tone.GOOD, true),
        RecordItem("EMP-0003", "নমুনা কর্মী-৩", "উৎপাদন সুপারভাইজার", "", "সক্রিয়", Tone.GOOD, true),
        RecordItem("EMP-0004", "নমুনা কর্মী-৪", "কিউসি কর্মকর্তা", "", "ছুটিতে", Tone.WARN, true)
    )

    val attendance = listOf(
        RecordItem("ATT-0001", "নমুনা কর্মী-১", "প্রবেশ: ০৮:৫৫ • QR + PIN", "", "উপস্থিত", Tone.GOOD),
        RecordItem("ATT-0002", "নমুনা কর্মী-২", "প্রবেশ: ০৯:১৫ • QR + PIN", "", "দেরিতে", Tone.WARN),
        RecordItem("ATT-0003", "নমুনা কর্মী-৩", "প্রবেশ: ০৮:৫০ • QR + PIN", "", "উপস্থিত", Tone.GOOD),
        RecordItem("ATT-0004", "নমুনা কর্মী-৪", "ছুটি অনুমোদিত", "", "ছুটি", Tone.NEUTRAL)
    )

    val salary = listOf(
        RecordItem("SAL-1", "মোট বেতন-বিল (চলতি মাস)", "নমুনা হিসাব; Payroll মডিউল নকশাধীন", Bn.taka(1250000), "", Tone.NEUTRAL),
        RecordItem("SAL-2", "পরিশোধিত", "নমুনা", Bn.taka(0), "বাকি", Tone.WARN),
        RecordItem("SAL-3", "কর্তন", "স্বয়ংক্রিয় কর্তন নিষিদ্ধ; শুধু অনুমোদিত নীতিতে", Bn.taka(0), "", Tone.NEUTRAL)
    )

    val notifications = listOf(
        ActivityItem("অনুমোদনের অপেক্ষায় ২টি ভাউচার", "নমুনা বিজ্ঞপ্তি", "আজ"),
        ActivityItem("কাঁচামাল-খ মজুত কম", "নমুনা বিজ্ঞপ্তি", "গতকাল"),
        ActivityItem("ব্যাচ ০৯৮-এর কিউসি অপেক্ষমাণ", "নমুনা বিজ্ঞপ্তি", "২ দিন আগে")
    )

    val recentActivities = listOf(
        ActivityItem("ভাউচার তৈরি", "নগদ পরিশোধ • " + Bn.taka(18500), "১০ মিনিট আগে"),
        ActivityItem("উৎপাদন আপডেট", "ব্যাচ ১০১ • ৮০% সম্পন্ন", "১ ঘণ্টা আগে"),
        ActivityItem("কাঁচামাল গ্রহণ", "কাঁচামাল-ক • " + Bn.num(500) + " কেজি", "আজ সকাল"),
        ActivityItem("উপস্থিতি", "৪২ জন কর্মী উপস্থিত", "আজ সকাল")
    )
}

/** Maps a Feature.previewKey to its SAMPLE records. Wings add their own keys here until a real repository exists. */
object PreviewData {
    fun records(key: String): List<RecordItem> = when (key) {
        "raw" -> SampleData.rawMaterials
        "production" -> SampleData.productionOrders
        "fg" -> SampleData.finishedGoods
        "stock" -> SampleData.stock
        "qc" -> SampleData.qcChecks
        "voucher" -> SampleData.vouchers
        "ledger" -> SampleData.ledger
        "approval" -> SampleData.approvals
        "finreports" -> SampleData.financeReports
        "employees" -> SampleData.employees
        "attendance" -> SampleData.attendance
        "salary" -> SampleData.salary
        else -> emptyList()
    }
}
