package com.mohona.erp.registry

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Receipt
import com.mohona.erp.data.ModuleKeys

/** Company-wide finance (CORE module shared by all wings). Sample screens only; the backend ledger is not connected yet. */
object FinanceModule {
    private val cashierHidden = setOf("CASHIER")
    val module = ModuleDef(
        id = "fin",
        kind = ModuleKind.CORE,
        nameBn = "অর্থ বিভাগ",
        descBn = "ভাউচার, লেজার, অনুমোদন, রিপোর্ট",
        icon = Icons.Filled.AccountBalance,
        accessKey = ModuleKeys.FINANCE,
        sectioned = false,
        features = listOf(
            Feature("fin.voucher", "ভাউচার", "নগদ প্রাপ্তি ও পরিশোধ", Icons.Filled.Receipt, FeatureStatus.PREVIEW, previewKey = "voucher", quickAction = true, primaryActionLabel = "নতুন ভাউচার", requiredPermission = "txn.create"),
            Feature("fin.ledger", "লেজার", "হিসাব-খতিয়ান", Icons.Filled.AccountBalance, FeatureStatus.PREVIEW, previewKey = "ledger", quickAction = true, hideForRoles = cashierHidden, requiredPermission = "fin.cash.view"),
            Feature("fin.approval", "অনুমোদন", "অপেক্ষমাণ ভাউচার", Icons.Filled.CheckCircle, FeatureStatus.PREVIEW, previewKey = "approval", quickAction = true, hideForRoles = cashierHidden, approvalButtons = true, requiredPermission = "approval.approve"),
            Feature("fin.reports", "অর্থ-রিপোর্ট", "ট্রায়াল ব্যালেন্স, ক্যাশ বুক, লেজার বিবরণী", Icons.Filled.Description, FeatureStatus.PREVIEW, previewKey = "finreports", hideForRoles = cashierHidden, requiredPermission = "fin.report.view")
        )
    )
}

/** Company-wide HR (CORE module). Sample screens only. */
object HrModule {
    private val selfOnly = setOf("EMPLOYEE_SELF")
    val module = ModuleDef(
        id = "hr",
        kind = ModuleKind.CORE,
        nameBn = "এইচআর বিভাগ",
        descBn = "কর্মী, হাজিরা, বেতন-সারসংক্ষেপ",
        icon = Icons.Filled.People,
        accessKey = ModuleKeys.HR,
        sectioned = false,
        features = listOf(
            Feature("hr.employees", "কর্মী তালিকা", "কর্মী ও যোগাযোগ", Icons.Filled.People, FeatureStatus.PREVIEW, previewKey = "employees", quickAction = true, hideForRoles = selfOnly, requiredPermission = "hr.employee.view"),
            Feature("hr.attendance", "হাজিরা", "QR + PIN হাজিরা", Icons.Filled.CalendarMonth, FeatureStatus.PREVIEW, previewKey = "attendance", quickAction = true, requiredPermission = "hr.attendance.view"),
            Feature("hr.salary", "বেতন-সারসংক্ষেপ", "Payroll নকশাধীন", Icons.Filled.Payments, FeatureStatus.PREVIEW, previewKey = "salary", quickAction = true, hideForRoles = selfOnly)
        )
    )
}
