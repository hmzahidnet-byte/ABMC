package com.mohona.erp.ui.navigation

import android.net.Uri
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mohona.erp.data.SessionViewModel
import com.mohona.erp.data.UserProfile
import com.mohona.erp.registry.AppRegistry
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.screens.DashboardScreen
import com.mohona.erp.ui.screens.FeatureScreen
import com.mohona.erp.ui.screens.LoginScreen
import com.mohona.erp.ui.screens.ModuleScreen
import com.mohona.erp.ui.screens.NotificationsScreen
import com.mohona.erp.ui.screens.ProfileScreen
import com.mohona.erp.ui.screens.QrDetailScreen
import com.mohona.erp.ui.screens.ReportsScreen
import com.mohona.erp.ui.screens.ScannerScreen

object Routes {
    const val LOGIN = "login"
    const val HOME = "home"
    const val SCAN = "scan"
    const val REPORTS = "reports"
    const val PROFILE = "profile"
    const val NOTIFICATIONS = "notifications"

    // Registry-driven routes: one pattern for every module/wing and every feature.
    const val MODULE_PATTERN = "module/{moduleId}"
    const val FEATURE_PATTERN = "feature/{featureId}"
    fun module(id: String): String = "module/" + Uri.encode(id)
    fun feature(id: String): String = "feature/" + Uri.encode(id)

    const val QR_DETAIL = "qr/detail/{code}"
    fun qrDetail(code: String): String = "qr/detail/" + Uri.encode(code)
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab(Routes.HOME, "হোম", Icons.Filled.Home),
    Tab(Routes.SCAN, "স্ক্যান", Icons.Filled.QrCodeScanner),
    Tab(Routes.REPORTS, "রিপোর্ট", Icons.Filled.Assessment),
    Tab(Routes.PROFILE, "প্রোফাইল", Icons.Filled.Person)
)

private fun NavController.goToTab(route: String) {
    navigate(route) {
        popUpTo(Routes.HOME) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

private fun NavController.goTo(route: String) {
    if (tabs.any { it.route == route }) goToTab(route) else navigate(route)
}

@Composable
fun MohonaApp() {
    val session: SessionViewModel = viewModel()
    val nav = rememberNavController()
    val backStackEntry by nav.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBar = tabs.any { it.route == currentRoute }
    val state = session.state

    Scaffold(
        containerColor = Color.White,
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = Color.White) {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = currentRoute == t.route,
                            onClick = { nav.goToTab(t.route) },
                            icon = { Icon(t.icon, contentDescription = t.label) },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Routes.LOGIN,
            modifier = Modifier.padding(padding)
        ) {
            composable(Routes.LOGIN) {
                LoginScreen(
                    session = state,
                    onSelectMode = { session.selectMode(it) },
                    onStartPreview = { primary, secondary ->
                        session.startPreview(primary, secondary)
                        nav.navigate(Routes.HOME) { popUpTo(Routes.LOGIN) { inclusive = true } }
                    },
                    onConnectedLogin = { loginId, password ->
                        session.loginConnected(loginId, password) {
                            nav.navigate(Routes.HOME) { popUpTo(Routes.LOGIN) { inclusive = true } }
                        }
                    }
                )
            }
            composable(Routes.HOME) {
                Guard(state.profile, nav) { p -> DashboardScreen(p) { nav.goTo(it) } }
            }
            composable(Routes.SCAN) {
                Guard(state.profile, nav) { _ -> ScannerScreen { code -> nav.navigate(Routes.qrDetail(code)) } }
            }
            composable(Routes.REPORTS) {
                Guard(state.profile, nav) { p -> ReportsScreen(p) { nav.goTo(it) } }
            }
            composable(Routes.PROFILE) {
                Guard(state.profile, nav) { p ->
                    ProfileScreen(state, p) {
                        session.logout()
                        nav.navigate(Routes.LOGIN) { popUpTo(nav.graph.id) { inclusive = true } }
                    }
                }
            }
            composable(Routes.NOTIFICATIONS) { NotificationsScreen { nav.popBackStack() } }
            composable(
                route = Routes.QR_DETAIL,
                arguments = listOf(navArgument("code") { type = NavType.StringType })
            ) { entry ->
                QrDetailScreen(code = entry.arguments?.getString("code") ?: "", onBack = { nav.popBackStack() })
            }

            // Every wing / core module opens through the registry; adding a wing needs no change here.
            composable(
                route = Routes.MODULE_PATTERN,
                arguments = listOf(navArgument("moduleId") { type = NavType.StringType })
            ) { entry ->
                val id = entry.arguments?.getString("moduleId") ?: ""
                Guard(state.profile, nav) { p ->
                    val m = AppRegistry.module(id)
                    if (m == null) {
                        EmptyState("এই বিভাগ পাওয়া যায়নি।")
                    } else {
                        ModuleScreen(
                            module = m,
                            roles = p.roleCodes,
                            onBack = { nav.popBackStack() },
                            onOpenFeature = { fid -> nav.navigate(Routes.feature(fid)) }
                        )
                    }
                }
            }
            composable(
                route = Routes.FEATURE_PATTERN,
                arguments = listOf(navArgument("featureId") { type = NavType.StringType })
            ) { entry ->
                val id = entry.arguments?.getString("featureId") ?: ""
                Guard(state.profile, nav) { _ ->
                    val found = AppRegistry.find(id)
                    if (found == null) {
                        EmptyState("এই পর্দা পাওয়া যায়নি।")
                    } else {
                        FeatureScreen(
                            moduleName = found.first.nameBn,
                            feature = found.second,
                            onBack = { nav.popBackStack() },
                            onShowQr = { ref -> nav.navigate(Routes.qrDetail(ref)) }
                        )
                    }
                }
            }
        }
    }
}

/** If the process was recreated without a session, send the user back to the login screen. */
@Composable
private fun Guard(profile: UserProfile?, nav: NavController, content: @Composable (UserProfile) -> Unit) {
    if (profile == null) {
        LaunchedEffect(Unit) {
            nav.navigate(Routes.LOGIN) { popUpTo(nav.graph.id) { inclusive = true } }
        }
    } else {
        content(profile)
    }
}
