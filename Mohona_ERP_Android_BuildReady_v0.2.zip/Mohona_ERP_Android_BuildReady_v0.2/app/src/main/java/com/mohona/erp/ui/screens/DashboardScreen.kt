package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.ModuleKeys
import com.mohona.erp.data.RoleAccess
import com.mohona.erp.data.Roles
import com.mohona.erp.data.SampleData
import com.mohona.erp.data.UserProfile
import com.mohona.erp.registry.AppRegistry
import com.mohona.erp.registry.ReportWidgets
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.MohonaLogo
import com.mohona.erp.ui.components.PreviewBadge
import com.mohona.erp.ui.components.PreviewBanner
import com.mohona.erp.ui.components.SectionTitle
import com.mohona.erp.ui.components.SummaryCard
import com.mohona.erp.ui.navigation.Routes
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.OrangeDark
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.OrangeSoft
import com.mohona.erp.ui.theme.TextMuted

private data class QuickAction(val label: String, val icon: ImageVector, val route: String)

@Composable
fun DashboardScreen(profile: UserProfile, onNavigate: (String) -> Unit) {
    val roles = profile.roleCodes
    val visibleModules = AppRegistry.visibleModules(roles)
    val summaries = ReportWidgets.summariesFor(roles)
    val charts = ReportWidgets.chartsFor(roles)

    val actions = ArrayList<QuickAction>()
    for (pair in AppRegistry.quickActions(roles)) {
        actions.add(QuickAction(pair.second.nameBn, pair.second.icon, Routes.feature(pair.second.id)))
    }
    if (RoleAccess.canSeeModule(roles, ModuleKeys.QR)) actions.add(QuickAction("স্ক্যান", Icons.Filled.QrCodeScanner, Routes.SCAN))
    if (RoleAccess.canSeeModule(roles, ModuleKeys.REPORTS)) actions.add(QuickAction("রিপোর্ট", Icons.Filled.Assessment, Routes.REPORTS))

    val hasBusinessContent = visibleModules.isNotEmpty() || actions.isNotEmpty() || charts.isNotEmpty()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundGray)
            .verticalScroll(rememberScrollState())
    ) {
        // Header: company logo only (no product-name text), notification and profile icons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MohonaLogo(size = 42.dp)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { onNavigate(Routes.NOTIFICATIONS) }) {
                Icon(Icons.Filled.Notifications, contentDescription = "বিজ্ঞপ্তি", tint = OrangeDark)
            }
            IconButton(onClick = { onNavigate(Routes.PROFILE) }) {
                Icon(Icons.Filled.Person, contentDescription = "প্রোফাইল", tint = OrangeDark)
            }
        }

        // Greeting card
        Box(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Brush.horizontalGradient(listOf(OrangePrimary, OrangeDark)))
                .padding(18.dp)
        ) {
            Column {
                Text(text = "শুভ দিন", style = MaterialTheme.typography.labelLarge, color = Color.White.copy(alpha = 0.9f))
                Text(
                    text = profile.name,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(4.dp))
                Text(text = Roles.namesOf(roles), style = MaterialTheme.typography.bodyMedium, color = Color.White)
                Text(text = profile.companyName, style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.9f))
                if (profile.isPreview) {
                    Spacer(Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(Color.White)
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    ) {
                        Text("প্রিভিউ ভূমিকা • ব্যাকএন্ড-অধিকার নয়", style = MaterialTheme.typography.labelSmall, color = OrangeDark)
                    }
                }
            }
        }

        if (!hasBusinessContent) {
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                AppCard {
                    EmptyState("এই ভূমিকার জন্য ব্যবসায়িক ডেটা দেখানো হয় না। অনুমোদিত নিয়ম অনুযায়ী এই ভূমিকা ব্যবসায়িক তথ্যে প্রবেশ করে না। প্রোফাইল দেখতে ওপরের ব্যক্তি-আইকনে চাপুন।")
                }
            }
        } else {
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                PreviewBanner(
                    if (profile.isPreview) "এটি নমুনা তথ্যসহ প্রিভিউ। কোনো বাস্তব লেনদেন সংরক্ষণ বা পোস্ট হয় না।"
                    else "সংযুক্ত মোড: লগইন ও অনুমতি-তালিকা সার্ভার থেকে এসেছে। বাকি সব পর্দা এখনো নমুনা তথ্যের প্রিভিউ।"
                )
            }

            if (actions.isNotEmpty()) {
                SectionTitle("দ্রুত কাজ")
                Column(modifier = Modifier.padding(horizontal = 12.dp)) {
                    actions.chunked(4).forEach { rowItems ->
                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            rowItems.forEach { a ->
                                QuickActionTile(a, Modifier.weight(1f)) { onNavigate(a.route) }
                            }
                            repeat(4 - rowItems.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }

            if (visibleModules.isNotEmpty()) {
                SectionTitle("বিভাগ")
                Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    visibleModules.forEach { m ->
                        ModuleLink(m.nameBn, m.descBn, m.icon) { onNavigate(Routes.module(m.id)) }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            if (summaries.isNotEmpty()) {
                SectionTitle("এক নজরে")
                Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    summaries.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            pair.forEach { s ->
                                SummaryCard(s.title, s.value, s.caption, s.icon, Modifier.weight(1f))
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }

            if (charts.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                SectionTitle("চার্ট ও গ্রাফ")
                Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    charts.forEach { w -> w.content() }
                }
            }

            Spacer(Modifier.height(12.dp))
            SectionTitle("সাম্প্রতিক কার্যক্রম")
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                AppCard {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Spacer(Modifier.weight(1f))
                            PreviewBadge()
                        }
                        SampleData.recentActivities.forEach { a ->
                            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                                Text(a.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                Text(a.detail + " • " + a.time, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun QuickActionTile(a: QuickAction, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(OrangeSoft),
            contentAlignment = Alignment.Center
        ) {
            Icon(a.icon, contentDescription = a.label, tint = OrangePrimary, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = a.label,
            style = MaterialTheme.typography.labelMedium,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ModuleLink(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    AppCard(onClick = onClick) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(OrangeSoft),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = OrangePrimary)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = TextMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
