package com.mohona.erp.registry

import androidx.compose.ui.graphics.vector.ImageVector
import com.mohona.erp.data.RoleAccess

/** PREVIEW = a sample-data screen exists. PLANNED = nothing is built yet (shown honestly as "পরিকল্পিত"). */
enum class FeatureStatus { PREVIEW, PLANNED }

enum class ModuleKind { WING, CORE }

/**
 * One feature inside a module. Adding a feature = adding one entry; no navigation or dashboard code changes.
 * [section] is used by sectioned modules (Wing 1) to decide which roles see it; [onlyRoles] hard-limits it
 * (e.g. Factory P&L = MD only); [hideForRoles] hides it from specific roles even if they see the module.
 */
data class Feature(
    val id: String,
    val nameBn: String,
    val descBn: String,
    val icon: ImageVector,
    val status: FeatureStatus,
    val section: String? = null,
    val previewKey: String? = null,
    val quickAction: Boolean = false,
    val onlyRoles: Set<String>? = null,
    val hideForRoles: Set<String> = emptySet(),
    val approvalButtons: Boolean = false,
    val primaryActionLabel: String? = null,
    val requiredPermission: String? = null
)

/** A Wing (business unit workspace) or a CORE company-wide module. */
data class ModuleDef(
    val id: String,
    val kind: ModuleKind,
    val nameBn: String,
    val descBn: String,
    val icon: ImageVector,
    val accessKey: String,
    val sectioned: Boolean,
    val features: List<Feature>
)

/**
 * Wing / Feature registry. TO ADD A NEW WING: create its ModuleDef in its own file and add it to [modules].
 * Login, dashboard, navigation, QR, reports and the action menu do not need to change.
 */
object AppRegistry {
    val modules: List<ModuleDef> = listOf(
        ManufacturingWing.module,
        FinanceModule.module,
        HrModule.module
    )

    fun module(id: String): ModuleDef? = modules.firstOrNull { it.id == id }

    fun find(featureId: String): Pair<ModuleDef, Feature>? {
        for (m in modules) {
            val f = m.features.firstOrNull { it.id == featureId }
            if (f != null) return Pair(m, f)
        }
        return null
    }

    private fun roleSees(role: String, m: ModuleDef, f: Feature): Boolean {
        if (!RoleAccess.roleSeesModule(role, m.accessKey)) return false
        val only = f.onlyRoles
        if (only != null) return role in only
        if (role in f.hideForRoles) return false
        val section = f.section
        if (m.sectioned && section != null) return RoleAccess.roleSeesSection(role, section)
        return true
    }

    fun isVisible(roles: List<String>, m: ModuleDef, f: Feature): Boolean = roles.any { roleSees(it, m, f) }

    fun visibleFeatures(roles: List<String>, m: ModuleDef): List<Feature> =
        m.features.filter { isVisible(roles, m, it) }

    fun visibleModules(roles: List<String>): List<ModuleDef> =
        modules.filter { m -> visibleFeatures(roles, m).isNotEmpty() }

    fun quickActions(roles: List<String>): List<Pair<ModuleDef, Feature>> {
        val out = ArrayList<Pair<ModuleDef, Feature>>()
        for (m in modules) {
            for (f in m.features) {
                if (f.quickAction && f.status == FeatureStatus.PREVIEW && isVisible(roles, m, f)) out.add(Pair(m, f))
            }
        }
        return out
    }
}
