package com.mohona.erp.data

/** The 17 owner-approved roles (OD-04). Codes are the stable role IDs used by the backend. */
data class RoleInfo(val code: String, val nameBn: String, val descBn: String)

/** Keys that connect roles to registry modules. New wings add their own key here (or in their own file). */
object ModuleKeys {
    const val MANUFACTURING = "manufacturing"
    const val FINANCE = "finance"
    const val HR = "hr"
    const val QR = "qr"
    const val REPORTS = "reports"
}

object Roles {
    val all: List<RoleInfo> = listOf(
        RoleInfo("CHAIRMAN", "চেয়ারম্যান", "গ্রুপ-স্তরের তদারকি"),
        RoleInfo("MD", "ব্যবস্থাপনা পরিচালক (এমডি)", "কোম্পানির সর্বোচ্চ ব্যবস্থাপনা; ফ্যাক্টরি লাভ-ক্ষতির একমাত্র দর্শক"),
        RoleInfo("WING_HEAD", "উইং প্রধান", "উইং/বিভাগ পরিচালনা"),
        RoleInfo("FIN_MANAGER", "অর্থ ব্যবস্থাপক", "অর্থ বিভাগের প্রধান"),
        RoleInfo("ACCOUNTANT", "হিসাবরক্ষক", "ভাউচার ও হিসাব-পোস্টিং"),
        RoleInfo("CASHIER", "ক্যাশিয়ার", "নগদ লেনদেন (নিজের ক্যাশবাক্স)"),
        RoleInfo("HR_OFFICER", "এইচআর কর্মকর্তা", "কর্মী ও উপস্থিতি ব্যবস্থাপনা"),
        RoleInfo("STOREKEEPER", "স্টোরকিপার", "গুদাম ও মজুত"),
        RoleInfo("PROD_SUPERVISOR", "উৎপাদন সুপারভাইজার", "ফ্যাক্টরির উৎপাদন তদারকি"),
        RoleInfo("QC_OFFICER", "কিউসি কর্মকর্তা", "মান-নিয়ন্ত্রণ"),
        RoleInfo("PURCHASE_OFFICER", "ক্রয় কর্মকর্তা", "কাঁচামাল ক্রয়"),
        RoleInfo("SALES_MANAGER", "বিক্রয় ব্যবস্থাপক", "বিক্রয় তদারকি"),
        RoleInfo("FIELD_SALES", "ফিল্ড সেলস", "ডিলার/রিটেইলার-ভিত্তিক মাঠ-কাজ"),
        RoleInfo("AUDITOR", "নিরীক্ষক", "শুধু পাঠ ও যাচাই"),
        RoleInfo("EMPLOYEE_SELF", "কর্মী (নিজের তথ্য)", "নিজের উপস্থিতি ও তথ্য"),
        RoleInfo("EMERGENCY_ADMIN", "জরুরি অ্যাডমিন", "সিল-করা ভূমিকা; নীতি এখনো অনুমোদিত নয়"),
        RoleInfo("TECH_ADMIN", "টেক অ্যাডমিন", "প্রযুক্তিগত ব্যবস্থাপনা; ব্যবসায়িক ডেটা-প্রবেশ নেই")
    )

    fun find(code: String): RoleInfo? = all.firstOrNull { it.code == code }
    fun nameOf(code: String): String = find(code)?.nameBn ?: code
    fun namesOf(codes: List<String>): String =
        if (codes.isEmpty()) "ভূমিকা নেই" else codes.joinToString(", ") { nameOf(it) }
}

/**
 * UI-ONLY visibility hints per role. They NEVER grant backend access: real authorization is enforced by
 * Supabase RLS / RPC (Appendix F). A user with several roles sees the union of what each role would show.
 */
object RoleAccess {
    private val modules: Map<String, Set<String>> = mapOf(
        "CHAIRMAN" to setOf(ModuleKeys.FINANCE, ModuleKeys.HR, ModuleKeys.REPORTS, ModuleKeys.QR),
        "MD" to setOf(ModuleKeys.MANUFACTURING, ModuleKeys.FINANCE, ModuleKeys.HR, ModuleKeys.REPORTS, ModuleKeys.QR),
        "WING_HEAD" to setOf(ModuleKeys.MANUFACTURING, ModuleKeys.REPORTS, ModuleKeys.QR),
        "FIN_MANAGER" to setOf(ModuleKeys.FINANCE, ModuleKeys.REPORTS, ModuleKeys.QR),
        "ACCOUNTANT" to setOf(ModuleKeys.FINANCE, ModuleKeys.REPORTS),
        "CASHIER" to setOf(ModuleKeys.FINANCE, ModuleKeys.QR),
        "HR_OFFICER" to setOf(ModuleKeys.HR, ModuleKeys.QR),
        "STOREKEEPER" to setOf(ModuleKeys.MANUFACTURING, ModuleKeys.QR),
        "PROD_SUPERVISOR" to setOf(ModuleKeys.MANUFACTURING, ModuleKeys.QR),
        "QC_OFFICER" to setOf(ModuleKeys.MANUFACTURING, ModuleKeys.QR),
        "PURCHASE_OFFICER" to setOf(ModuleKeys.MANUFACTURING, ModuleKeys.QR),
        "SALES_MANAGER" to setOf(ModuleKeys.REPORTS, ModuleKeys.QR),
        "FIELD_SALES" to setOf(ModuleKeys.REPORTS, ModuleKeys.QR),
        "AUDITOR" to setOf(ModuleKeys.FINANCE, ModuleKeys.HR, ModuleKeys.REPORTS),
        "EMPLOYEE_SELF" to setOf(ModuleKeys.HR, ModuleKeys.QR),
        "EMERGENCY_ADMIN" to emptySet<String>(),
        "TECH_ADMIN" to emptySet<String>()
    )

    /** Which sections of a sectioned module (Wing 1) a role sees. "*" = all. */
    private val sections: Map<String, Set<String>> = mapOf(
        "MD" to setOf("*"),
        "WING_HEAD" to setOf("*"),
        "STOREKEEPER" to setOf("raw", "stock", "fg", "consumption", "stockverify"),
        "PROD_SUPERVISOR" to setOf("production", "planning", "bom", "batch", "waste", "fg", "stock", "consumption"),
        "QC_OFFICER" to setOf("qc"),
        "PURCHASE_OFFICER" to setOf("raw", "purchase", "supplier")
    )

    fun modulesOf(role: String): Set<String> = modules[role] ?: emptySet()
    fun modulesFor(roles: List<String>): Set<String> = roles.flatMap { modulesOf(it) }.toSet()
    fun canSeeModule(roles: List<String>, key: String): Boolean = roles.any { key in modulesOf(it) }
    fun roleSeesModule(role: String, key: String): Boolean = key in modulesOf(role)
    fun roleSeesSection(role: String, section: String): Boolean {
        val s = sections[role] ?: return false
        return "*" in s || section in s
    }
}

data class PermissionGrant(val code: String, val scope: String)

data class UserProfile(
    val name: String,
    val roleCodes: List<String>,
    val companyName: String,
    val companyCode: String,
    val isPreview: Boolean,
    val permissions: List<PermissionGrant> = emptyList(),
    val organizationId: String = "",
    val employeeId: String = ""
)

object PreviewProfiles {
    /** Preview only: changes what the demo UI shows; grants nothing on the backend. */
    fun forRoles(primary: String, secondary: String?): UserProfile {
        val roles = ArrayList<String>()
        roles.add(primary)
        if (secondary != null && secondary != primary) roles.add(secondary)
        return UserProfile(
            name = "নমুনা ব্যবহারকারী",
            roleCodes = roles,
            companyName = "নমুনা কোম্পানি লিমিটেড",
            companyCode = "DEMO",
            isPreview = true
        )
    }
}
