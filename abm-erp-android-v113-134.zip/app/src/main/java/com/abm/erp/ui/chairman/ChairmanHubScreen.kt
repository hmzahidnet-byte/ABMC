package com.abm.erp.ui.chairman

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.MockRepository
import com.abm.erp.data.UserRole
import com.abm.erp.theme.*

/**
 * Enterprise Workspace redesign — Chairman Intelligence Hub. A dedicated executive workspace,
 * not a new business module: every number here is read from repository functions that already
 * existed (computeSalesKpi/computeCollectionKpi/computeRetailerKpi/topRisks/
 * computeSmartBusinessAlerts/computeSystemHealthSnapshot — the same ones BoardroomScreen and the
 * Dashboard already use), reused rather than reimplemented. No new business logic.
 *
 * Access: Chairman always. Anyone else only if the Chairman has explicitly delegated authority to
 * them via the existing Delegation system (MockRepository.activeDelegationFor) — never a new
 * access-control mechanism, and never an identity re-selection.
 */
@Composable
fun ChairmanHubScreen(onNavigate: (String) -> Unit = {}) {
    val context = LocalContext.current
    val currentUser = MockRepository.currentUser
    val profiles by MockRepository.employeeProfiles.collectAsState()

    val activeDelegation = remember(currentUser.employeeId) { MockRepository.activeDelegationFor(currentUser.employeeId) }
    val delegatorRole = remember(activeDelegation) { activeDelegation?.let { d -> profiles.firstOrNull { it.id == d.delegatorId }?.role } }
    val authorized = currentUser.role == UserRole.CHAIRMAN || delegatorRole == UserRole.CHAIRMAN

    if (!authorized) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("🔒 Chairman Intelligence Hub", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(
                "শুধু Chairman অথবা Chairman কর্তৃক explicitly authorized ব্যক্তি এই workspace দেখতে পারবেন।",
                style = MaterialTheme.typography.bodyMedium, color = TextSecondary,
            )
        }
        return
    }

    val dealers by MockRepository.dealers.collectAsState()
    val retailers by MockRepository.retailers.collectAsState()
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val stockLevels by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
    val approvals by MockRepository.approvals.collectAsState()
    val payroll by MockRepository.payroll.collectAsState()

    // v113-131 — real weekly Sales-vs-Collection buckets for the last 5 weeks
    // (Monday-anchored), computed directly from the same real salesInvoices/
    // partyCollections lists every other KPI on this screen already reads —
    // no separate/duplicate data source, no fabricated week-over-week shape.
    val salesInvoicesAll by MockRepository.salesInvoices.collectAsState()
    val collectionsAll by MockRepository.partyCollections.collectAsState()
    val weeklySalesVsCollection = remember(salesInvoicesAll, collectionsAll) {
        val today = java.time.LocalDate.now()
        val thisMonday = today.minusDays(((today.dayOfWeek.value - 1).toLong()))
        (4 downTo 0).map { weeksAgo ->
            val weekStart = thisMonday.minusWeeks(weeksAgo.toLong())
            val weekEnd = weekStart.plusDays(7)
            val sales = salesInvoicesAll.filter { !it.isDeleted && !it.createdAt.toLocalDate().isBefore(weekStart) && it.createdAt.toLocalDate().isBefore(weekEnd) }
                .sumOf { it.lineItems.sumOf { li -> li.lineTotal } }
            val collected = collectionsAll.filter { it.status == "VERIFIED" && !it.createdAt.toLocalDate().isBefore(weekStart) && it.createdAt.toLocalDate().isBefore(weekEnd) }
                .sumOf { it.amount }
            Triple("${weekStart.dayOfMonth} ${weekStart.month.name.take(3).lowercase().replaceFirstChar { c -> c.uppercase() }}", sales, collected)
        }
    }

    val salesKpi = remember { MockRepository.computeSalesKpi() }
    val collectionKpi = remember { MockRepository.computeCollectionKpi() }
    val retailerKpi = remember { MockRepository.computeRetailerKpi() }
    val risks = remember { MockRepository.topRisks() }
    var smartAlerts by remember { mutableStateOf<List<MockRepository.SmartBusinessAlert>>(emptyList()) }
    var healthSnapshot by remember { mutableStateOf<MockRepository.SystemHealthSnapshot?>(null) }
    LaunchedEffect(Unit) {
        smartAlerts = MockRepository.computeSmartBusinessAlerts()
        healthSnapshot = MockRepository.computeSystemHealthSnapshot(context)
    }

    val pendingApprovalsCount = approvals.count { it.status == com.abm.erp.data.ApprovalStatus.PENDING }
    val totalDue = dealers.sumOf { it.dueBalance } + retailers.sumOf { it.dueBalance }
    val lowStockCount = stockLevels.count { it.isLowStock }
    val dashTarget = payroll.sumOf { it.targetAmount }
    val dashAchieved = payroll.sumOf { it.achievedAmount }

    Column(Modifier.fillMaxSize()) {
        com.abm.erp.core.ModuleWorkspaceHeader("Chairman Intelligence Hub", "👑", 0xFF0F1E3D, 0xFF0A1428, iconVector = Icons.Filled.WorkspacePremium, miniDashboard = {
            com.abm.erp.core.ModuleStat("Pending Approvals", "$pendingApprovalsCount", if (pendingApprovalsCount > 0) WarningAmber else SuccessGreen)
            com.abm.erp.core.ModuleStat("Total Due", "৳${"%,.0f".format(totalDue)}", if (totalDue > 0) WarningAmber else SuccessGreen)
            com.abm.erp.core.ModuleStat("Low Stock", "$lowStockCount", if (lowStockCount > 0) DangerRed else SuccessGreen)
            com.abm.erp.core.ModuleStat("Alerts", "${smartAlerts.size}", if (smartAlerts.isNotEmpty()) DangerRed else SuccessGreen)
        })

        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            // ---- Executive Dashboard ----
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("ledger") }) {
                Text("Executive Dashboard", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Today's Sales", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(salesKpi.today)}", fontWeight = FontWeight.Bold) }
                    Column { Text("This Month", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(salesKpi.thisMonth)}", fontWeight = FontWeight.Bold) }
                    Column { Text("Collection Efficiency", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${"%.0f".format(collectionKpi.efficiencyPct)}%", fontWeight = FontWeight.Bold) }
                }
            }

            // v113-131 — the drawer's own subtitle for this screen already says
            // "Business Overview in Real Time" — this card completes what that
            // promised but the screen didn't yet deliver: Total Sales/Collection/
            // Due (already-computed real KPIs, reused not reinvented) plus Total
            // Dealers/Retailers/Products (real counts) and a real weekly
            // Sales-vs-Collection comparison, not a second competing screen.
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Business Overview — This Month", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Total Sales", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(salesKpi.thisMonth)}", fontWeight = FontWeight.Bold, color = SuccessGreen) }
                    Column { Text("Collection", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(collectionKpi.thisMonth)}", fontWeight = FontWeight.Bold, color = SuccessGreen) }
                    Column { Text("Total Due", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(collectionKpi.outstandingDue)}", fontWeight = FontWeight.Bold, color = WarningAmber) }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Total Dealers", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${dealers.count { !it.isDeleted }}", fontWeight = FontWeight.Bold) }
                    Column { Text("Total Retailers", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${retailers.count { !it.isDeleted }}", fontWeight = FontWeight.Bold) }
                    Column { Text("Total Products", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${products.count { !it.isDeleted }}", fontWeight = FontWeight.Bold) }
                }
                Spacer(Modifier.height(14.dp))
                Text("Sales vs Collection — Last 5 Weeks", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = TextSecondary)
                Spacer(Modifier.height(8.dp))
                if (weeklySalesVsCollection.all { it.second == 0.0 && it.third == 0.0 }) {
                    Text("এই সময়ে দেখানোর মতো যথেষ্ট ডেটা নেই।", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                } else {
                    SalesVsCollectionBarChart(weeklySalesVsCollection)
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    var overviewError by remember { mutableStateOf<String?>(null) }
                    TextButton(onClick = {
                        try {
                            val file = com.abm.erp.core.exportListAsCsv(
                                context, "BusinessOverview", weeklySalesVsCollection,
                                listOf("Week" to { w: Triple<String, Double, Double> -> w.first }, "Sales" to { w -> "%,.0f".format(w.second) }, "Collection" to { w -> "%,.0f".format(w.third) }),
                            )
                            com.abm.erp.core.shareStructuredCsv(context, file, "Business Overview")
                        } catch (e: Exception) { overviewError = "Export ব্যর্থ হয়েছে: ${e.message ?: "unknown error"}" }
                    }) { Text("↓ Download") }
                    TextButton(onClick = {
                        val summary = "Business Overview — This Month\nTotal Sales: ৳${"%,.0f".format(salesKpi.thisMonth)}\nCollection: ৳${"%,.0f".format(collectionKpi.thisMonth)}\nTotal Due: ৳${"%,.0f".format(collectionKpi.outstandingDue)}\nDealers: ${dealers.count { !it.isDeleted }} · Retailers: ${retailers.count { !it.isDeleted }} · Products: ${products.count { !it.isDeleted }}"
                        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                        context.startActivity(android.content.Intent.createChooser(intent, "Business Overview"))
                    }) { Text("↗ Share") }
                    TextButton(onClick = { onNavigate("reports") }) { Text("Full Report") }
                    overviewError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                }
            }

            // ---- Static Graphs: real last-7-days sales trend (non-interactive, board-report style) ----
            val dailySales = healthSnapshot?.salesDailyLast7Days
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Sales Trend — Last 7 Days", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                if (dailySales != null && dailySales.size >= 2) {
                    com.abm.erp.ui.core.TrendLineChart(values = dailySales)
                } else {
                    Text("গ্রাফ দেখানোর জন্য যথেষ্ট ডেটা এখনো নেই।", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }

            // ---- System Health ----
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("system_health_dashboard") }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("System Health", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                val h = healthSnapshot
                if (h == null) {
                    com.abm.erp.core.WorkspaceLoadingState("System Health লোড হচ্ছে…")
                } else {
                    Text(if (h.serverOnline) "🟢 Server Online" else "🔴 Server Offline", color = if (h.serverOnline) SuccessGreen else DangerRed, style = MaterialTheme.typography.bodySmall)
                    Text("Devices: ${h.activeDeviceCount} active · ${h.offlineDeviceCount} offline", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Text("Today's Login: ${h.todaysLoginSuccessCount} success · ${h.todaysLoginFailedCount} failed", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Text("Sync Failures (session): ${h.failedSyncCount}", style = MaterialTheme.typography.bodySmall, color = if (h.failedSyncCount > 0) WarningAmber else TextSecondary)
                    if (h.errors.isNotEmpty()) Text("⚠ ${h.errors.size} system error(s) detected", style = MaterialTheme.typography.bodySmall, color = DangerRed)
                }
            }

            // ---- Business Risks ----
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("boardroom") }) {
                Text("Business Risks", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = DangerRed)
                Spacer(Modifier.height(6.dp))
                if (risks.isEmpty()) {
                    Text("এই মুহূর্তে কোনো চিহ্নিত ঝুঁকি নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                } else {
                    risks.forEach { r -> Text("• ${r.type} — ${r.evidence}", style = MaterialTheme.typography.bodySmall) }
                }
            }

            // ---- Approvals ----
            // Decision 2 (v113-72) — Chairman *observes* here; he doesn't action from here.
            // The central Approvals screen is gone, so this card is a count only and each
            // approval is approved inside its own module (HRM / Expenses / Ledger / DMS).
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Approvals", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    if (pendingApprovalsCount > 0) "$pendingApprovalsCount টি অনুমোদন অপেক্ষমাণ — যে মডিউলের অনুমোদন, সেই মডিউলেই অনুমোদন করুন।" else "কোনো অপেক্ষমাণ অনুমোদন নেই।",
                    color = if (pendingApprovalsCount > 0) WarningAmber else SuccessGreen, style = MaterialTheme.typography.bodySmall,
                )
            }

            // ---- Company Performance ----
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("dealers") }) {
                Text("Company Performance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Active Retailers", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${retailerKpi.totalActive}", fontWeight = FontWeight.Bold) }
                    Column { Text("New This Month", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${retailerKpi.newThisMonth}", fontWeight = FontWeight.Bold, color = SuccessGreen) }
                    Column { Text("Inactive", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${retailerKpi.inactive}", fontWeight = FontWeight.Bold, color = if (retailerKpi.inactive > 0) WarningAmber else SuccessGreen) }
                }
            }

            // ---- Target Achievement ----
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("hrm") }) {
                Text("Target Achievement", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(if (dashTarget > 0) "৳${"%,.0f".format(dashAchieved)} / ৳${"%,.0f".format(dashTarget)} (${"%.0f".format(dashAchieved / dashTarget * 100)}%)" else "কোনো টার্গেট নির্ধারিত নেই।", fontWeight = FontWeight.Bold, color = Gold)
                if (dashTarget > 0) {
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(progress = (dashAchieved / dashTarget).toFloat().coerceIn(0f, 1f), modifier = Modifier.fillMaxWidth().height(6.dp), color = Gold)
                }
            }

            // ---- Alerts ----
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("notifications") }) {
                Text("Alerts", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                if (smartAlerts.isEmpty()) {
                    Text("এই মুহূর্তে কোনো সতর্কতা নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                } else {
                    smartAlerts.forEach { a ->
                        Text(
                            "${if (a.severity == MockRepository.SmartAlertSeverity.CRITICAL) "🔴" else "⚠"} ${a.message}",
                            color = if (a.severity == MockRepository.SmartAlertSeverity.CRITICAL) DangerRed else WarningAmber,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }

            // ---- Recent Activity (company-wide) ----
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("enterprise_audit_center") }) {
                com.abm.erp.core.ModuleRecentActivity(
                    setOf("SalesInvoice", "PartyCollection", "Collection", "WarehouseTransfer", "ProductionOrder", "Voucher", "CorrectionRequest"),
                    limit = 6,
                )
            }

            // ---- Admin & Access Tools (moved here from Dashboard) ----
            var showVacancyPanel by remember { mutableStateOf(false) }
            var showAccountsPanel by remember { mutableStateOf(false) }
            var showDevicesPanel by remember { mutableStateOf(false) }
            var showLoginLogPanel by remember { mutableStateOf(false) }
            var showBackupPanel by remember { mutableStateOf(false) }
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Admin & Access Tools", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                // Blueprint §24 — 3-column icon-chip tile grid. Dialog-backed tools open their
                // existing screens; route-backed tools navigate to routes already registered in
                // NavGraph. No new screens, no new permissions.
                val tools: List<Triple<String, androidx.compose.ui.graphics.vector.ImageVector, () -> Unit>> = listOf(
                    Triple("Vacant\nPositions", Icons.Filled.PersonSearch) { showVacancyPanel = true },
                    Triple("Account &\nAccess", Icons.Filled.VpnKey) { showAccountsPanel = true },
                    Triple("Trusted\nDevices", Icons.Filled.PhoneAndroid) { showDevicesPanel = true },
                    Triple("Login\nActivity", Icons.Filled.History) { showLoginLogPanel = true },
                    Triple("Backup &\nRecovery", Icons.Filled.Backup) { showBackupPanel = true },
                    Triple("Chairman\nNotice", Icons.Filled.Campaign) { onNavigate("notifications") },
                    Triple("Communication\nHub", Icons.Filled.Forum) { onNavigate("comms") },
                    Triple("Helpdesk", Icons.Filled.SupportAgent) { onNavigate("helpdesk") },
                    Triple("Complaint\nBox", Icons.Filled.MarkunreadMailbox) { onNavigate("complaint") },
                    Triple("Audit Log", Icons.Filled.Assignment) { onNavigate("enterprise_audit_center") },
                    Triple("System\nHealth", Icons.Filled.MonitorHeart) { onNavigate("system_health_dashboard") },
                    Triple("Business\nRules", Icons.Filled.Rule) { onNavigate("business_rule_engine") },
                    Triple("Global\nSettings", Icons.Filled.Settings) { onNavigate("company_settings_center") },
                    Triple("Sync\nStatus", Icons.Filled.Sync) { onNavigate("sync_status_center") },
                    Triple("Reports", Icons.Filled.InsertChart) { onNavigate("reports") },
                )
                val accents = listOf(
                    com.abm.erp.theme.StatusRed, com.abm.erp.theme.StatusGreen, com.abm.erp.theme.StatusBlue,
                    com.abm.erp.theme.DarazOrange, com.abm.erp.theme.StatusGreen, com.abm.erp.theme.StatusRed,
                    com.abm.erp.theme.StatusBlue, com.abm.erp.theme.DarazOrange, com.abm.erp.theme.StatusAmber,
                    com.abm.erp.theme.StatusBlue, com.abm.erp.theme.StatusRed, com.abm.erp.theme.StatusAmber,
                    com.abm.erp.theme.StatusBlue, com.abm.erp.theme.StatusGreen, com.abm.erp.theme.DarazOrange,
                )
                tools.chunked(3).forEachIndexed { rowIdx, rowTools ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowTools.forEachIndexed { colIdx, (label, icon, action) ->
                            val accent = accents[(rowIdx * 3 + colIdx) % accents.size]
                            Column(
                                Modifier.weight(1f)
                                    .clickable(onClick = action)
                                    .padding(vertical = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                com.abm.erp.core.IconChip(icon = icon, accent = accent, size = 38)
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    lineHeight = 13.sp,
                                )
                            }
                        }
                        repeat(3 - rowTools.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            if (showVacancyPanel) {
                Dialog(onDismissRequest = { showVacancyPanel = false }) {
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                        com.abm.erp.ui.dashboard.VacantPositionsScreen(onClose = { showVacancyPanel = false })
                    }
                }
            }
            if (showAccountsPanel) {
                Dialog(onDismissRequest = { showAccountsPanel = false }) {
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                        com.abm.erp.ui.dashboard.AccountsScreen(onClose = { showAccountsPanel = false })
                    }
                }
            }
            if (showDevicesPanel) {
                Dialog(onDismissRequest = { showDevicesPanel = false }) {
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                        com.abm.erp.ui.dashboard.TrustedDevicesScreen(onClose = { showDevicesPanel = false })
                    }
                }
            }
            if (showLoginLogPanel) {
                Dialog(onDismissRequest = { showLoginLogPanel = false }) {
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                        com.abm.erp.ui.dashboard.LoginActivityLogScreen(onClose = { showLoginLogPanel = false })
                    }
                }
            }
            if (showBackupPanel) {
                Dialog(onDismissRequest = { showBackupPanel = false }) {
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                        com.abm.erp.ui.dashboard.BackupRecoveryScreen(onClose = { showBackupPanel = false })
                    }
                }
            }
        }
    }
}

/**
 * v113-131 — real dual-series (Sales/Collection) weekly bar chart, drawn with
 * plain Canvas the same way com.abm.erp.ui.core.TrendLineChart already draws
 * this screen's sales-trend line — no new charting dependency, matching the
 * technique already proven in this codebase rather than introducing another one.
 */
@Composable
private fun SalesVsCollectionBarChart(weekly: List<Triple<String, Double, Double>>) {
    val maxVal = (weekly.maxOfOrNull { maxOf(it.second, it.third) } ?: 0.0).coerceAtLeast(1.0)
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().height(140.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
            weekly.forEach { (label, sales, collected) ->
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Box(Modifier.width(14.dp).height((110 * (sales / maxVal)).dp.coerceAtLeast(2.dp)).background(SuccessGreen, androidx.compose.foundation.shape.RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp)))
                    Box(Modifier.width(14.dp).height((110 * (collected / maxVal)).dp.coerceAtLeast(2.dp)).background(ElectricCyan, androidx.compose.foundation.shape.RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp)))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            weekly.forEach { (label, _, _) -> Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontSize = 10.sp) }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(10.dp).background(SuccessGreen, androidx.compose.foundation.shape.RoundedCornerShape(2.dp))); Spacer(Modifier.width(4.dp)); Text("Sales", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
            Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(10.dp).background(ElectricCyan, androidx.compose.foundation.shape.RoundedCornerShape(2.dp))); Spacer(Modifier.width(4.dp)); Text("Collection", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
        }
    }
}
