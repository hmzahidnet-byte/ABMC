package com.abm.erp.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.abm.erp.data.*
import com.abm.erp.theme.*
import kotlinx.coroutines.launch

@Composable
fun PeriodLockCenterScreen() {
    val currentUser = MockRepository.currentUser
    val employeeProfiles by MockRepository.employeeProfiles.collectAsState()
    val myProfile = employeeProfiles.firstOrNull { it.id == currentUser.employeeId }
    val isAccountsWithAuthority = myProfile?.department?.contains("account", ignoreCase = true) == true && myProfile.financialApprovalLimit > 0
    val canLock = currentUser.role == UserRole.CHAIRMAN || isAccountsWithAuthority
    val periodLockScope = rememberCoroutineScope()
    if (!canLock) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("এই স্ক্রিন শুধু Chairman/Accounts (financial approval authority সহ)-এর জন্য।") }
        return
    }
    val locks by MockRepository.accountingPeriodLocks.collectAsState()
    var showLockDialog by remember { mutableStateOf(false) }
    var showUnlockReasonFor by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Accounting Period Lock", style = MaterialTheme.typography.titleLarge)
        Text("লক করা period-এ Invoice edit, Payment delete, Stock edit, Production edit, Attendance edit — সব বন্ধ হয়ে যাবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(10.dp))
        Button(onClick = { showLockDialog = true }) { Text("+ Lock a Period") }
        Spacer(Modifier.height(10.dp))
        Text("Existing Locks", style = MaterialTheme.typography.titleMedium)
        LazyColumn {
            items(locks.sortedByDescending { it.lockedAt }) { lock ->
                Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), tonalElevation = 2.dp) {
                    Column(Modifier.padding(10.dp)) {
                        Text("${lock.scope}: ${lock.periodStart} → ${lock.periodEnd}", style = MaterialTheme.typography.titleSmall)
                        Text(if (lock.isLocked) "🔒 Locked by ${lock.lockedByName}" else "🔓 Unlocked", style = MaterialTheme.typography.bodySmall, color = if (lock.isLocked) DangerRed else SuccessGreen)
                        if (lock.isLocked) {
                            if (currentUser.role == UserRole.CHAIRMAN) TextButton(onClick = { showUnlockReasonFor = lock.id }) { Text("Unlock") }
                        }
                    }
                }
            }
        }
    }

    if (showLockDialog) {
        var scope by remember { mutableStateOf(PeriodLockScope.MONTH) }
        var start by remember { mutableStateOf(java.time.LocalDate.now().withDayOfMonth(1)) }
        var end by remember { mutableStateOf(java.time.LocalDate.now()) }
        Dialog(onDismissRequest = { showLockDialog = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Lock a Period", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PeriodLockScope.values().forEach { s -> FilterChip(selected = scope == s, onClick = {
                            scope = s
                            end = java.time.LocalDate.now()
                            start = when (s) {
                                PeriodLockScope.MONTH -> end.withDayOfMonth(1)
                                PeriodLockScope.QUARTER -> end.minusMonths(3)
                                PeriodLockScope.YEAR -> end.withDayOfYear(1)
                            }
                        }, label = { Text(s.name) }) }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Period: $start → $end", style = MaterialTheme.typography.bodyMedium)
                    var lockPeriodError by remember { mutableStateOf<String?>(null) }
                    lockPeriodError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val ok = MockRepository.lockAccountingPeriod(scope, start, end, onRejected = { r -> lockPeriodError = r })
                            if (ok) showLockDialog = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm Lock") }
                }
            }
        }
    }

    showUnlockReasonFor?.let { lockId ->
        var reason by remember { mutableStateOf("") }
        Dialog(onDismissRequest = { showUnlockReasonFor = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Unlock Period", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason (required)") }, modifier = Modifier.fillMaxWidth())
                    var unlockError by remember { mutableStateOf<String?>(null) }
                    unlockError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { periodLockScope.launch { if (MockRepository.unlockAccountingPeriod(lockId, reason, onRejected = { r -> unlockError = r })) showUnlockReasonFor = null } },
                        enabled = reason.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm Unlock") }
                }
            }
        }
    }
}
