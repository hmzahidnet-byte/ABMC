package com.abm.erp

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.fragment.app.FragmentActivity
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.abm.erp.data.MockRepository
import com.abm.erp.nav.Dest
import com.abm.erp.nav.ABMNavGraph
import com.abm.erp.theme.ABMErpTheme
import com.abm.erp.theme.TextSecondary
import com.abm.erp.ui.login.LoginScreen
import kotlinx.coroutines.launch

/**
 * FragmentActivity (not plain ComponentActivity) because androidx.biometric's
 * BiometricPrompt requires a FragmentActivity host to attach its dialog to.
 * FragmentActivity is itself a ComponentActivity, so setContent{} below still
 * works exactly the same way.
 */
class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestHighestAvailableRefreshRate()
        setContent {
            ABMErpTheme {
                var mode by remember { mutableStateOf("login") } // "login" | "staff" | "dealerLogin" | "dealer" | "retailerLogin" | "retailer"
                var activeDealerId by remember { mutableStateOf<String?>(null) }
                var activeRetailerId by remember { mutableStateOf<String?>(null) }

                when (mode) {
                    "staff" -> ABMApp(onLogout = { MockRepository.logout(this); mode = "login" })
                    "dealerLogin" -> com.abm.erp.ui.dealer.DealerLoginScreen(
                        onDealerChosen = { id -> activeDealerId = id; mode = "dealer" },
                        onBackToStaffLogin = { mode = "login" },
                    )
                    "dealer" -> com.abm.erp.ui.dealer.DealerHomeScreen(
                        dealerId = activeDealerId ?: "",
                        onLogout = { mode = "login" },
                    )
                    // v113-203 — Retailer's own login/home, same shape as Dealer's
                    // two branches just above.
                    "retailerLogin" -> com.abm.erp.ui.rms.RetailerLoginScreen(
                        onRetailerChosen = { id -> activeRetailerId = id; mode = "retailer" },
                        onBackToStaffLogin = { mode = "login" },
                    )
                    "retailer" -> com.abm.erp.ui.rms.RetailerHomeScreen(
                        retailerId = activeRetailerId ?: "",
                        onLogout = { mode = "login" },
                    )
                    else -> LoginScreen(
                        activity = this,
                        onLoginSuccess = { mode = "staff" },
                        onDealerLoginRequested = { mode = "dealerLogin" },
                        onRetailerLoginRequested = { mode = "retailerLogin" },
                    )
                }
            }
        }
    }

    // v113-236 — the person's own explicit request: the whole app should
    // run at least 90Hz, up to 120Hz, on capable screens. Android does
    // NOT do this automatically — without requesting it, the system
    // defaults to 60Hz even on a 90Hz/120Hz-capable device. The
    // documented, standard AOSP mechanism (Display.supportedModes +
    // Window.attributes.preferredDisplayModeId) has existed since API 23,
    // well under this app's minSdk 26, so no version gate is needed for
    // the mechanism itself — only for HOW the Display is obtained
    // (Activity.display is API 30+; windowManager.defaultDisplay is the
    // correct fallback below that, deprecated but still functional and
    // the only option on API 26-29, which this app's own minSdk still
    // has to support). Picks the single highest refresh-rate mode the
    // real, connected screen actually supports — 120Hz where available,
    // 90Hz where that's the ceiling, and a graceful no-op (stays at
    // whatever the device's own default is) on older/cheaper screens
    // that only have 60Hz, since a mode that doesn't exist can't be
    // requested. This must run before setContent() — the mode has to be
    // requested before the window's first frame, not after.
    private fun requestHighestAvailableRefreshRate() {
        try {
            val display = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                this.display
            } else {
                @Suppress("DEPRECATION")
                windowManager.defaultDisplay
            } ?: return
            val bestMode = display.supportedModes.maxByOrNull { it.refreshRate } ?: return
            if (bestMode.refreshRate > display.refreshRate) {
                val params = window.attributes
                params.preferredDisplayModeId = bestMode.modeId
                window.attributes = params
            }
        } catch (e: Exception) {
            // Never worth crashing the app over a refresh-rate preference —
            // the app still works correctly at whatever rate the system
            // falls back to.
            com.abm.erp.config.AppLog.w("MainActivity", "high refresh rate request failed, continuing at default rate", e)
        }
    }
}

private val destIcons = mapOf(
    Dest.Dashboard.route to Icons.Filled.Dashboard,
    Dest.Sales.route to Icons.Filled.PointOfSale,
    Dest.Inventory.route to Icons.Filled.Inventory2,
    Dest.Crm.route to Icons.Filled.Map,
    Dest.Hrm.route to Icons.Filled.Groups,
    Dest.Billing.route to Icons.Filled.ReceiptLong,
    Dest.Production.route to Icons.Filled.Factory,
    Dest.Boardroom.route to Icons.Filled.Insights, // "Master Advisory" boardroom slot
)

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun ABMApp(onLogout: () -> Unit = {}) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: Dest.Dashboard.route
    val currentUser by MockRepository.currentUserFlow.collectAsState()
    var showLogoutConfirm by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    var showRightMenu by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showActivityLogDialog by remember { mutableStateOf(false) }
    var showTrustedDevicesDialog by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            // v113-138 — the ABM/name/post banner used to render on EVERY screen,
            // so entering a module or one of its features permanently lost that
            // vertical strip to a header the person had already read on the
            // dashboard. Now it shows only on the dashboard itself; inside modules
            // the work screen gets the full height (each module already draws its
            // own contextual header via ModuleDrawerScaffold, so nothing is lost).
            if (backStackEntry?.destination?.route == Dest.Dashboard.route) {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(
                                    brush = Brush.linearGradient(listOf(com.abm.erp.theme.GoldBright, com.abm.erp.theme.Gold, com.abm.erp.theme.GoldDeep)),
                                    shape = CircleShape,
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("ABM", color = Color(0xFF241A08), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(currentUser.name, style = MaterialTheme.typography.titleSmall)
                            Text("${currentUser.role} · ${currentUser.zone}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { showSearch = true }) {
                        Icon(Icons.Filled.Search, contentDescription = "Search")
                    }
                    // QR moved out of the (now removed) bottom bar and up here beside search,
                    // at the same weight as search. It stays the fastest route into a record —
                    // one tap opens the camera directly, no intermediate menu.
                    IconButton(
                        onClick = { navController.navigate(Dest.UniversalScanner.route) { launchSingleTop = true } },
                        modifier = Modifier
                            .size(38.dp)
                            .background(com.abm.erp.theme.DarazOrange, RoundedCornerShape(11.dp)),
                    ) {
                        Icon(
                            Icons.Filled.QrCodeScanner,
                            contentDescription = "Universal QR Scanner",
                            tint = Color.White,
                            modifier = Modifier.size(21.dp),
                        )
                    }
                    Spacer(Modifier.width(4.dp))
                    Box {
                        IconButton(onClick = { showRightMenu = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
                        }
                        DropdownMenu(expanded = showRightMenu, onDismissRequest = { showRightMenu = false }) {
                            DropdownMenuItem(text = { Text("Profile") }, leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) }, onClick = { showRightMenu = false; showProfileDialog = true })
                            DropdownMenuItem(text = { Text("Activity Log") }, leadingIcon = { Icon(Icons.Filled.History, contentDescription = null) }, onClick = { showRightMenu = false; showActivityLogDialog = true })
                            DropdownMenuItem(text = { Text("Trusted Devices") }, leadingIcon = { Icon(Icons.Filled.PhoneAndroid, contentDescription = null) }, onClick = { showRightMenu = false; showTrustedDevicesDialog = true })
                            DropdownMenuItem(text = { Text("Sync Status") }, leadingIcon = { Icon(Icons.Filled.Sync, contentDescription = null) }, onClick = { showRightMenu = false; navController.navigate(Dest.SyncStatusCenter.route) { launchSingleTop = true } })
                            DropdownMenuItem(text = { Text("Backup") }, leadingIcon = { Icon(Icons.Filled.Backup, contentDescription = null) }, onClick = { showRightMenu = false; showBackupDialog = true })
                            DropdownMenuItem(text = { Text("Settings") }, leadingIcon = { Icon(Icons.Filled.Settings, contentDescription = null) }, onClick = { showRightMenu = false; navController.navigate(Dest.CompanySettingsCenter.route) { launchSingleTop = true } })
                            DropdownMenuItem(text = { Text("Help") }, leadingIcon = { Icon(Icons.Filled.HelpOutline, contentDescription = null) }, onClick = { showRightMenu = false; navController.navigate(Dest.Helpdesk.route) { launchSingleTop = true } })
                            // v113-244 — three real, fully working screens
                            // found with a registered NavGraph route but no
                            // navigation trigger anywhere — confirmed, before
                            // assuming they were safe to delete as "orphaned",
                            // that every function/field each one calls
                            // (PermissionManager's template functions,
                            // MockRepository.businessRules/auditLogEntries)
                            // still exists with a matching signature; none
                            // were bitrotted, none were truly superseded by
                            // the later module-specific business-rule split
                            // or the Employee Access toggle — each offers a
                            // genuinely different, complementary view (every
                            // rule in one place; reusable permission
                            // templates for bulk assignment; a full
                            // company-wide audit trail) that those newer,
                            // narrower tools don't replace. Reconnected here
                            // rather than on the Chairman dashboard itself,
                            // matching this exact menu's own established
                            // role as where less-frequent admin tools
                            // already live (Sync Status, Backup, Settings) —
                            // keeping the earlier redesign's own decluttering
                            // intent intact rather than undoing it.
                            if (currentUser.role == com.abm.erp.data.UserRole.CHAIRMAN) {
                                Divider()
                                DropdownMenuItem(text = { Text("Business Rules (সব)") }, leadingIcon = { Icon(Icons.Filled.Rule, contentDescription = null) }, onClick = { showRightMenu = false; navController.navigate(Dest.BusinessRuleEngine.route) { launchSingleTop = true } })
                                DropdownMenuItem(text = { Text("Permission Templates") }, leadingIcon = { Icon(Icons.Filled.Security, contentDescription = null) }, onClick = { showRightMenu = false; navController.navigate(Dest.PermissionCenter.route) { launchSingleTop = true } })
                                DropdownMenuItem(text = { Text("Audit Trail (সম্পূর্ণ)") }, leadingIcon = { Icon(Icons.Filled.FactCheck, contentDescription = null) }, onClick = { showRightMenu = false; navController.navigate(Dest.EnterpriseAuditCenter.route) { launchSingleTop = true } })
                            }
                            Divider()
                            DropdownMenuItem(text = { Text("Logout") }, leadingIcon = { Icon(Icons.Filled.Logout, contentDescription = null) }, onClick = { showRightMenu = false; showLogoutConfirm = true })
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding)) {
            ABMNavGraph(navController = navController)
        }
    }

    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            title = { Text("Logout করবেন?") },
            text = { Text("আবার ঢুকতে PIN/biometric আবার লাগবে।") },
            confirmButton = {
                TextButton(onClick = { showLogoutConfirm = false; onLogout() }) { Text("হ্যাঁ, Logout") }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false }) { Text("বাতিল") }
            },
        )
    }
    if (showSearch) {
        com.abm.erp.ui.search.UniversalSearchDialog(
            onDismiss = { showSearch = false },
            onNavigate = { route -> showSearch = false; navController.navigate(route) { launchSingleTop = true } },
        )
    }
    if (showProfileDialog) {
        val profiles by MockRepository.employeeProfiles.collectAsState()
        val profile = profiles.firstOrNull { it.id == currentUser.employeeId } ?: profiles.firstOrNull { it.userAccountId == currentUser.id }
        val company = remember(currentUser.companyId) { MockRepository.companySettings() }
        // v113-241 — acknowledgeAppraisal already existed, fully real,
        // Chairman-role-independent (an employee acknowledging their own
        // appraisal is deliberately not gated behind any special
        // permission — see the function's own check), but had zero UI
        // callers anywhere. Nowhere in the whole app let an employee see
        // their own appraisal at all, let alone acknowledge one. Added
        // here, in the Profile dialog — reachable from literally
        // anywhere in the app via the top-right menu, the same natural
        // home as the rest of "my own information" already shown here.
        val appraisals by MockRepository.employeeAppraisals.collectAsState()
        val myAppraisals = remember(appraisals, profile) {
            if (profile == null) emptyList() else appraisals.filter { it.employeeId == profile.id }.sortedByDescending { it.periodEnd }
        }
        val appraisalScope = rememberCoroutineScope()
        AlertDialog(
            onDismissRequest = { showProfileDialog = false },
            title = { Text("Profile") },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    Text(currentUser.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Employee ID: ${profile?.employeeCode?.ifBlank { null } ?: currentUser.employeeId}", style = MaterialTheme.typography.bodySmall)
                    Text("Designation: ${profile?.designation?.ifBlank { null } ?: "—"}", style = MaterialTheme.typography.bodySmall)
                    Text("Company: ${company.companyName.ifBlank { "—" }}", style = MaterialTheme.typography.bodySmall)
                    Text("Territory: ${currentUser.zone}", style = MaterialTheme.typography.bodySmall)
                    Text("Phone: ${currentUser.phone.ifBlank { "—" }}", style = MaterialTheme.typography.bodySmall)
                    if (myAppraisals.isNotEmpty()) {
                        Spacer(Modifier.height(14.dp))
                        Divider()
                        Spacer(Modifier.height(10.dp))
                        Text("My Appraisals", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        myAppraisals.forEach { ap ->
                            Column(Modifier.padding(vertical = 6.dp)) {
                                Text("${ap.periodStart} — ${ap.periodEnd}", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                                ap.rating?.let { Text(it, color = com.abm.erp.theme.SuccessGreen, style = MaterialTheme.typography.labelSmall) }
                                ap.managerComment?.ifBlank { null }?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                                if (ap.employeeAcknowledged) {
                                    Text("✓ Acknowledged", color = com.abm.erp.theme.SuccessGreen, style = MaterialTheme.typography.labelSmall)
                                } else {
                                    TextButton(onClick = { appraisalScope.launch { MockRepository.acknowledgeAppraisal(ap.id) } }) { Text("Acknowledge") }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showProfileDialog = false }) { Text("Close") } },
        )
    }
    if (showActivityLogDialog) {
        Dialog(onDismissRequest = { showActivityLogDialog = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                com.abm.erp.ui.dashboard.LoginActivityLogScreen(onClose = { showActivityLogDialog = false })
            }
        }
    }
    if (showTrustedDevicesDialog) {
        Dialog(onDismissRequest = { showTrustedDevicesDialog = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                com.abm.erp.ui.dashboard.TrustedDevicesScreen(onClose = { showTrustedDevicesDialog = false })
            }
        }
    }
    if (showBackupDialog) {
        Dialog(onDismissRequest = { showBackupDialog = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                com.abm.erp.ui.dashboard.BackupRecoveryScreen(onClose = { showBackupDialog = false })
            }
        }
    }
}
