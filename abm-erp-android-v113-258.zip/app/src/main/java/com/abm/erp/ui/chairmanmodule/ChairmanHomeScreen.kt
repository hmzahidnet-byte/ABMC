package com.abm.erp.ui.chairmanmodule

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.core.ModuleDrawerItem
import com.abm.erp.core.ModuleDrawerScaffold
import com.abm.erp.data.MockRepository
import com.abm.erp.data.chairmanApproveCorrection
import com.abm.erp.data.chairmanRejectCorrection
import com.abm.erp.data.managerReviewCorrection
import com.abm.erp.data.UserRole
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import kotlinx.coroutines.launch

/**
 * CHAIRMAN — Full Control Center. Mother module #5 (of five: the person moved AI
 * inside Chairman, so the Home Dashboard shows DMS · RMS · HR · FMS · CHAIRMAN).
 *
 * Two decisions the person made explicitly for this module, recorded here because
 * both are exceptions or refinements of earlier rules:
 *
 * 1. **Approval Center is the ONE sanctioned exception to Decision 2.** Every other
 *    role approves inside the owning module (leave in HR, expense in FMS, invoice in
 *    DMS — unchanged). The Chairman alone gets a cross-module approval inbox,
 *    because observing and deciding across everything IS the Chairman's job. It is
 *    role-gated at render time AND every action still goes through the same
 *    permission-checked repository functions, so a non-chairman reaching this screen
 *    can see nothing and force nothing.
 *
 * 2. **Master Controller has NO hard delete.** The person confirmed: view
 *    soft-deleted records and restore them, nothing more. The app's everything-is-
 *    soft-delete policy stays intact; no data-destruction path exists here.
 */
private val CH_COLOR_START = 0xFF0F1E3D
private val CH_COLOR_END = 0xFF0A1428

private val CH_ITEMS = listOf(
    ModuleDrawerItem("dashboard", "Dashboard", Icons.Filled.Home, "Business Overview in Real Time"),
    // v113-221 — the person's own full redesign of this module, done over
    // an extended discussion rather than guessed at. Central principle:
    // DMS/RMS/FMS/HR each already have their own complete Chairman-tier
    // admin section — this central module should not duplicate any of
    // that, and should carry only the things genuinely central: business-
    // wide summary, the two Chairman-locked base identities (Product,
    // Raw Material), company identity, a simple notice slot, AI, and
    // backup. "Approval Center" removed — its one genuinely homeless
    // piece (Correction Requests) moved to the Dashboard itself as a
    // section, not a separate drawer destination; everything else it
    // showed was already duplicating a module's own approval panel.
    // "Support/Helpdesk", "Business Rules" (split to each rule's actual
    // module — HR got the payroll/attendance ones, DMS got the
    // sales/credit ones), "Permission Control" (superseded by the real
    // per-employee Access control on Employee List's own Manage tab),
    // and "System Logs" all removed the same way — not because the
    // underlying capability is gone, but because it now lives where the
    // person said it actually belongs, not centralized generically.
    ModuleDrawerItem("product", "Product", Icons.Filled.Inventory2, "Add, Edit & Base QR Lock"),
    ModuleDrawerItem("rawmaterial", "Raw Material", Icons.Filled.Layers, "Add, Edit & Purchase"),
    ModuleDrawerItem("ai", "AI", Icons.Filled.Insights, "AI Boardroom & Intelligence"),
    ModuleDrawerItem("reports", "Reports & Analytics", Icons.Filled.InsertChart, "Advanced Reports"),
    ModuleDrawerItem("company", "Company Info", Icons.Filled.Business, "Name, Address & Logo"),
    ModuleDrawerItem("backup", "Backup & Restore", Icons.Filled.CloudUpload, "Online & Offline Backup"),
    ModuleDrawerItem("notice", "Notices / Announcement", Icons.Filled.Campaign, "Direct Notice to Employees"),
)

@Composable
fun ChairmanHomeScreen(
    startKey: String? = null,
    onBackToHome: () -> Unit = {},
    onNavigate: (String) -> Unit = {},
) {
    // Role gate at the door. The drawer items host real admin screens; those screens
    // and every repository write re-check permissions themselves (defense in depth),
    // but a non-chairman shouldn't even see this module's option list.
    if (MockRepository.currentUser.role != UserRole.CHAIRMAN) {
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            Text("এই মডিউল শুধু Chairman-এর জন্য।", fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(Modifier.height(6.dp))
            TextButton(onClick = onBackToHome) { Text("← Home") }
        }
        return
    }

    var selected by remember { mutableStateOf(startKey ?: "dashboard") }

    ModuleDrawerScaffold(
        moduleName = "CHAIRMAN",
        moduleSubtitle = "Full Control Center",
        colorStart = CH_COLOR_START,
        colorEnd = CH_COLOR_END,
        moduleIcon = Icons.Filled.WorkspacePremium,
        items = CH_ITEMS,
        selectedKey = selected,
        onSelect = { selected = it },
        onBackToHome = onBackToHome,
    ) { key ->
        when (key) {
            "dashboard" -> com.abm.erp.ui.chairman.ChairmanHubScreen(onNavigate = onNavigate)
            "product" -> ChairmanProductControl()
            "rawmaterial" -> ChairmanRawMaterialControl()
            "ai" -> com.abm.erp.ui.advisory.BoardroomScreen(onNavigate = onNavigate)
            "reports" -> com.abm.erp.ui.reports.ReportsScreen()
            "company" -> com.abm.erp.ui.admin.CompanySettingsCenterScreen()
            "backup" -> com.abm.erp.ui.dashboard.BackupRecoveryScreen(onClose = { selected = "dashboard" })
            "notice" -> ChairmanNoticeBoard()
            else -> com.abm.erp.ui.chairman.ChairmanHubScreen(onNavigate = onNavigate)
        }
    }
}


/**
 * Master Controller — the person's confirmed scope: **view soft-deleted records and
 * restore them. No hard delete exists and none is added.**
 *
 * Each section below is a record type that (a) actually carries `isDeleted` and
 * (b) actually has a repository restore function — both verified against the source,
 * not assumed. Types with soft delete but no restore function (e.g. leads) are not
 * listed: showing a Restore button that silently can't work would be a fake screen.
 * Every restore call is the existing permission-checked repository function; DELETE-
 * tier permission is re-checked inside each one.
 */
// v113-172 — was one monolithic Chairman-only "Master Controller" listing every
// entity type together. Person's decision: DMS/RMS/FMS/HR-type administration
// work currently sitting in the central Chairman module moves into each
// module's own Chairman tab, so the central module gets lighter and each
// module becomes self-contained for its Chairman. Split into one focused,
// public composable per entity type — each collects its own StateFlow
// directly rather than sharing a parent's collected state, so each can be
// called independently from its owning module's Chairman panel.

@Composable
fun DmsInvoiceRestoreSection() {
    val invoices by MockRepository.salesInvoices.collectAsState()
    val delInvoices = remember(invoices) { invoices.filter { it.isDeleted } }
    Column {
        if (delInvoices.isEmpty()) {
            Text("কোনো soft-deleted Invoice নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        } else {
            McSectionHeader("Invoice", delInvoices.size)
            delInvoices.forEach { r -> McRestoreRow(r.invoiceNo, r.dealerName) { MockRepository.restoreSalesInvoice(r.id) } }
        }
    }
}

@Composable
fun DmsDealerRestoreSection() {
    val dealers by MockRepository.dealers.collectAsState()
    val delDealers = remember(dealers) { dealers.filter { it.isDeleted } }
    Column {
        if (delDealers.isEmpty()) {
            Text("কোনো soft-deleted Dealer নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        } else {
            McSectionHeader("Dealer", delDealers.size)
            delDealers.forEach { r -> McRestoreRow(r.name, r.zone) { MockRepository.restoreDealer(r.id) } }
        }
    }
}

@Composable
fun DmsProductRestoreSection() {
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val delProducts = remember(products) { products.filter { it.isDeleted } }
    Column {
        if (delProducts.isEmpty()) {
            Text("কোনো soft-deleted Product নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        } else {
            McSectionHeader("Product", delProducts.size)
            delProducts.forEach { r -> McRestoreRow(r.name, r.sku) { com.abm.erp.data.InventoryRepository.restoreProduct(r.id) } }
        }
    }
}

@Composable
fun RmsRetailerRestoreSection() {
    val retailers by MockRepository.retailers.collectAsState()
    val delRetailers = remember(retailers) { retailers.filter { it.isDeleted } }
    Column {
        if (delRetailers.isEmpty()) {
            Text("কোনো soft-deleted Retailer নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        } else {
            McSectionHeader("Retailer", delRetailers.size)
            delRetailers.forEach { r -> McRestoreRow(r.name, r.market.orEmpty()) { MockRepository.restoreRetailer(r.id) } }
        }
    }
}

@Composable
fun FmsSupplierRestoreSection() {
    val suppliers by com.abm.erp.data.PurchaseRepository.suppliers.collectAsState()
    val delSuppliers = remember(suppliers) { suppliers.filter { it.isDeleted } }
    Column {
        if (delSuppliers.isEmpty()) {
            Text("কোনো soft-deleted Supplier নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        } else {
            McSectionHeader("Supplier", delSuppliers.size)
            delSuppliers.forEach { r -> McRestoreRow(r.name, r.phone) { com.abm.erp.data.PurchaseRepository.restoreSupplier(r.id) } }
        }
    }
}

@Composable
fun HrTaskRestoreSection() {
    val tasks by MockRepository.tasks.collectAsState()
    val delTasks = remember(tasks) { tasks.filter { it.isDeleted } }
    Column {
        if (delTasks.isEmpty()) {
            Text("কোনো soft-deleted Task নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        } else {
            McSectionHeader("Task", delTasks.size)
            delTasks.forEach { r -> McRestoreRow(r.title, r.assignee) { MockRepository.restoreTask(r.id) } }
        }
    }
}

@Composable
fun McSectionHeader(label: String, count: Int) {
    Text("$label ($count)", fontWeight = FontWeight.SemiBold, color = TextPrimary, modifier = Modifier.padding(top = 8.dp))
}

@Composable
fun McRestoreRow(title: String, subtitle: String, onRestore: suspend () -> Boolean) {
    var denied by remember(title) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                if (subtitle.isNotBlank()) Text(subtitle, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            OutlinedButton(onClick = { scope.launch { denied = !onRestore() } }) { Text("↩ Restore") }
        }
        if (denied) {
            Text(
                "⚠ Restore ব্যর্থ — আপনার role-এ এই কাজের অনুমতি নেই।",
                style = MaterialTheme.typography.labelSmall, color = DangerRed,
            )
        }
    }
}

/**
 * v113-77 — Chairman → employees direct notice. Uses the existing
 * `createNotification` (targetEmployeeId = null broadcasts to everyone's Notification
 * screen; a specific employeeId targets one person) — the same pipeline every system
 * alert already rides, so no new delivery mechanism and no new schema.
 */
/**
 * v113-145 — Product Control, from the reference layout's Chairman column
 * (product name/category/rate/status — add, EDIT, activate/deactivate).
 *
 * Uses the real `InventoryRepository.updateProduct` added in v113-137 and the
 * existing `addProduct`/`deleteProduct` — no new product engine, and no second
 * product master: this reads the SAME `InventoryRepository.products` flow every
 * other module uses, so an edit here shows up everywhere immediately.
 *
 * Deactivate is a soft delete (the repository's own `deleteProduct`), never a
 * hard delete, because products are referenced by historical invoices — the
 * directive's delete policy. Restore is available from Master Controller.
 */
@Composable
fun ChairmanProductControl() {
    if (MockRepository.currentUser.role != UserRole.CHAIRMAN) {
        Text("এই স্ক্রিন শুধু Chairman-এর জন্য।", color = TextSecondary)
        return
    }
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    var query by remember { mutableStateOf("") }
    var editingId by remember { mutableStateOf<String?>(null) }
    var actionError by remember { mutableStateOf<String?>(null) }
    // v113-221 — the person's own explicit reasoning: Product's base
    // identity — its Add and its QR — needs to be Chairman-locked
    // specifically because leaving it editable from a regular module
    // (Inventory) means it never actually stays fixed. Added here (the
    // one edit capability already existed; creation + QR were the two
    // real gaps).
    var showNewProduct by remember { mutableStateOf(false) }
    val productScope = rememberCoroutineScope()
    val live = remember(products, query) {
        products.filter { !it.isDeleted && (query.isBlank() || it.name.contains(query, true) || it.sku.contains(query, true)) }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Product Control (${live.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
            TextButton(onClick = { showNewProduct = true }) { Text("+ নতুন Product") }
        }
        Text("নাম, দাম, category, base QR ঠিক করুন — পরিবর্তন সাথে সাথে সব module-এ প্রতিফলিত হবে। Inventory-তে শুধু দেখা যাবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        actionError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("নাম/SKU দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        if (live.isEmpty()) {
            com.abm.erp.core.WorkspaceEmptyState("কোনো product পাওয়া যায়নি।")
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(live, key = { it.id }) { p ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${p.sku} · ${p.category.ifBlank { "—" }} · ৳${"%,.0f".format(p.defaultUnitPrice)}/${p.unit}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text(if (p.isActive) "Active" else "Inactive", color = if (p.isActive) SuccessGreen else WarningAmber, style = MaterialTheme.typography.labelSmall)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { editingId = p.id }) { Text("✏ Edit") }
                        com.abm.erp.core.RecordQrButton(code = p.sku.ifBlank { p.id }, title = p.name, entityType = "Product", entityId = p.id, label = "QR")
                        TextButton(onClick = {
                            productScope.launch { com.abm.erp.data.InventoryRepository.deleteProduct(p.id, onRejected = { r -> actionError = r }) }
                        }) { Text("Deactivate", color = DangerRed) }
                    }
                }
            }
        }
    }

    if (showNewProduct) {
        var name by remember { mutableStateOf("") }
        var sku by remember { mutableStateOf("") }
        var unit by remember { mutableStateOf("pcs") }
        var category by remember { mutableStateOf("") }
        var price by remember { mutableStateOf("") }
        var cost by remember { mutableStateOf("") }
        // v113-249 — the person's own direct request for a real "shortage"
        // definition: reorderThreshold already existed on Product and was
        // already well-used for company/warehouse stock alerts
        // (InventoryScreen's own low-stock/reorder-suggestion logic), but
        // every real creation site hardcoded it to 0.0 and no Chairman UI
        // ever let it be set to anything meaningful — confirmed by
        // checking, not assumed, before building anything new.
        var reorderThreshold by remember { mutableStateOf("") }
        var newError by remember { mutableStateOf<String?>(null) }
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNewProduct = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                    Text("নতুন Product", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = sku, onValueChange = { sku = it }, label = { Text("SKU") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text("Unit") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = price, onValueChange = { price = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("বিক্রয় দাম") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = cost, onValueChange = { cost = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("ক্রয় দাম") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = reorderThreshold, onValueChange = { reorderThreshold = it.filter { c -> c.isDigit() || c == '.' } },
                        label = { Text("Reorder Threshold (শর্টেজ ধরার সীমা)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                    newError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 6.dp)) }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            newError = null
                            com.abm.erp.data.InventoryRepository.addProduct(
                                sku = sku.trim(), name = name.trim(), unit = unit.trim().ifBlank { "pcs" }, category = category.trim(),
                                reorderThreshold = reorderThreshold.toDoubleOrNull() ?: 0.0, defaultUnitPrice = price.toDoubleOrNull() ?: 0.0, costPrice = cost.toDoubleOrNull() ?: 0.0,
                                onRejected = { r -> newError = r },
                                onCreated = { showNewProduct = false },
                            )
                        },
                        enabled = name.isNotBlank() && sku.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("তৈরি করুন") }
                }
            }
        }
    }

    editingId?.let { pid ->
        val p = products.firstOrNull { it.id == pid }
        if (p != null) {
            androidx.compose.ui.window.Dialog(onDismissRequest = { editingId = null }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                    var name by remember { mutableStateOf(p.name) }
                    var sku by remember { mutableStateOf(p.sku) }
                    var unit by remember { mutableStateOf(p.unit) }
                    var category by remember { mutableStateOf(p.category) }
                    var price by remember { mutableStateOf(p.defaultUnitPrice.toString()) }
                    var cost by remember { mutableStateOf(p.costPrice.toString()) }
                    var reorderThreshold by remember { mutableStateOf(p.reorderThreshold.toString()) }
                    var editError by remember { mutableStateOf<String?>(null) }
                    // v113-225 — a real regression, found by checking rather
                    // than assuming: making Inventory's old "Add Product" tab
                    // read-only (v113-221) removed its per-row photo upload,
                    // and the new Chairman Add/Edit built to replace it never
                    // carried photo capability over — so product photos
                    // became impossible to set anywhere in the app, a real
                    // loss the person never asked for. uploadProductPhoto/
                    // setProductPhoto were both still fully real and working,
                    // just orphaned with zero callers left. Restored here,
                    // in the one place product identity is now managed.
                    val photoContext = androidx.compose.ui.platform.LocalContext.current
                    var uploadingPhoto by remember { mutableStateOf(false) }
                    val photoScope = rememberCoroutineScope()
                    val photoPicker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
                        if (uri != null) {
                            uploadingPhoto = true
                            MockRepository.uploadProductPhoto(photoContext, pid, uri.toString()) { url ->
                                uploadingPhoto = false
                                if (url != null) photoScope.launch { com.abm.erp.data.InventoryRepository.setProductPhoto(pid, url) }
                            }
                        }
                    }
                    Column(Modifier.padding(16.dp).heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                        Text("Product সম্পাদনা", fontWeight = FontWeight.Bold, color = TextPrimary)
                        editError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (!p.photoUri.isNullOrBlank()) {
                                coil.compose.AsyncImage(
                                    model = p.photoUri, contentDescription = p.name,
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                    modifier = Modifier.size(48.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp)),
                                )
                            }
                            TextButton(onClick = { photoPicker.launch("image/*") }) {
                                Text(if (uploadingPhoto) "Uploading…" else if (p.photoUri.isNullOrBlank()) "📷 Photo যোগ করুন" else "Photo বদলান")
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(value = sku, onValueChange = { sku = it }, label = { Text("SKU") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text("Unit") }, singleLine = true, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, singleLine = true, modifier = Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(value = price, onValueChange = { price = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("বিক্রয় দাম") }, singleLine = true, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = cost, onValueChange = { cost = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("ক্রয় দাম") }, singleLine = true, modifier = Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(
                            value = reorderThreshold, onValueChange = { reorderThreshold = it.filter { c -> c.isDigit() || c == '.' } },
                            label = { Text("Reorder Threshold (শর্টেজ ধরার সীমা)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = {
                                editError = null
                                com.abm.erp.data.InventoryRepository.updateProduct(
                                    productId = pid, sku = sku.trim(), name = name.trim(), unit = unit.trim().ifBlank { "pcs" },
                                    category = category.trim(), reorderThreshold = reorderThreshold.toDoubleOrNull() ?: p.reorderThreshold,
                                    defaultUnitPrice = price.toDoubleOrNull() ?: 0.0, costPrice = cost.toDoubleOrNull() ?: 0.0,
                                    onRejected = { r -> editError = r },
                                )
                                if (editError == null) editingId = null
                            },
                            enabled = name.isNotBlank() && sku.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("সংরক্ষণ করুন") }
                    }
                }
            }
        }
    }
}

// v113-221 — the person's own explicit request: raw material (the
// production-side input, distinct from a sellable Product) needs the same
// Add/Edit/Purchase treatment as Product, in the same central Chairman
// module. Uses the real repository functions added alongside this
// (recordRawMaterialPurchase/updateRawMaterialLot) — Chairman recording a
// purchase directly, bypassing the formal Purchase-Request/Approval/GRN
// chain that still exists unchanged for regular Purchase-module use.
@Composable
fun ChairmanRawMaterialControl() {
    if (MockRepository.currentUser.role != UserRole.CHAIRMAN) {
        Text("এই স্ক্রিন শুধু Chairman-এর জন্য।", color = TextSecondary)
        return
    }
    val lots by MockRepository.lots.collectAsState()
    var query by remember { mutableStateOf("") }
    var editingId by remember { mutableStateOf<String?>(null) }
    var showNewLot by remember { mutableStateOf(false) }
    var actionError by remember { mutableStateOf<String?>(null) }
    val materialScope = rememberCoroutineScope()
    val live = remember(lots, query) {
        lots.filter { query.isBlank() || it.materialName.contains(query, true) }.sortedByDescending { it.purchasedOn }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Raw Material Control (${live.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
            TextButton(onClick = { showNewLot = true }) { Text("+ নতুন ক্রয়") }
        }
        Text("নাম, পরিমাণ, দাম ঠিক করুন — Production-এর Materials tab-এ সাথে সাথে প্রতিফলিত হবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        actionError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("নাম দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        if (live.isEmpty()) {
            com.abm.erp.core.WorkspaceEmptyState("কোনো কাঁচামাল lot পাওয়া যায়নি।")
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(live, key = { it.id }) { lot ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(lot.materialName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${"%,.1f".format(lot.qtyKg)} kg · ৳${"%,.0f".format(lot.costPerKg)}/kg · ${lot.purchasedOn}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { editingId = lot.id }) { Text("✏ Edit") }
                    }
                }
            }
        }
    }

    if (showNewLot || editingId != null) {
        val editing = editingId?.let { id -> lots.firstOrNull { it.id == id } }
        var materialName by remember(editingId) { mutableStateOf(editing?.materialName ?: "") }
        var qty by remember(editingId) { mutableStateOf(editing?.qtyKg?.toString() ?: "") }
        var cost by remember(editingId) { mutableStateOf(editing?.costPerKg?.toString() ?: "") }
        var formError by remember(editingId) { mutableStateOf<String?>(null) }
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNewLot = false; editingId = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    Text(if (editing != null) "কাঁচামাল সম্পাদনা" else "নতুন কাঁচামাল ক্রয়", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = materialName, onValueChange = { materialName = it }, label = { Text("নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = qty, onValueChange = { qty = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("পরিমাণ (kg)") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = cost, onValueChange = { cost = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("দাম/kg (৳)") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    formError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 6.dp)) }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            formError = null
                            materialScope.launch {
                                val ok = if (editing != null) {
                                    MockRepository.updateRawMaterialLot(editing.id, materialName.trim(), qty.toDoubleOrNull() ?: 0.0, cost.toDoubleOrNull() ?: 0.0, onRejected = { r -> formError = r })
                                } else {
                                    MockRepository.recordRawMaterialPurchase(materialName.trim(), qty.toDoubleOrNull() ?: 0.0, cost.toDoubleOrNull() ?: 0.0, onRejected = { r -> formError = r }) != null
                                }
                                if (ok) { showNewLot = false; editingId = null }
                            }
                        },
                        enabled = materialName.isNotBlank() && (qty.toDoubleOrNull() ?: 0.0) > 0,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("সংরক্ষণ করুন") }
                }
            }
        }
    }
}

@Composable
private fun ChairmanNoticeBoard() {
    // v113-128 — defense-in-depth, matching every sibling Chairman-only screen
    // in this file (Master Controller, and the standalone PermissionControl/
    // BusinessRuleEngine/EnterpriseAudit/CompanySettings screens). The outer
    // ChairmanHomeScreen already gates entry to the whole module, but this
    // codebase's own stated principle is that no Chairman-only mutation relies
    // on a single line of defense — this screen was the one exception.
    if (MockRepository.currentUser.role != UserRole.CHAIRMAN) {
        Text("এই স্ক্রিন শুধু Chairman-এর জন্য।", color = TextSecondary)
        return
    }
    val profiles by MockRepository.employeeProfiles.collectAsState()
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var targetId by remember { mutableStateOf<String?>(null) } // null = সবাই
    var sentMsg by remember { mutableStateOf<String?>(null) }
    // v113-224 — the person's own explicit request: the notice slot should
    // take a photo, not just text. Optional — sending stays exactly as
    // simple as before when no photo is picked.
    val noticeContext = androidx.compose.ui.platform.LocalContext.current
    var pickedPhotoUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var uploadingPhoto by remember { mutableStateOf(false) }
    val noticePhotoPicker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
        pickedPhotoUri = uri
    }

    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Text("Notice Board", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
        Text("সরাসরি employee-দের কাছে notice — Notification-এ ও main dashboard-এ পৌঁছাবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("শিরোনাম") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Notice (ঐচ্ছিক যদি ছবি দেন)") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (pickedPhotoUri != null) {
                coil.compose.AsyncImage(
                    model = pickedPhotoUri, contentDescription = "Notice photo",
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier.size(56.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp)),
                )
            }
            TextButton(onClick = { noticePhotoPicker.launch("image/*") }) { Text(if (pickedPhotoUri == null) "📷 ছবি যোগ করুন (ঐচ্ছিক)" else "ছবি বদলান") }
            if (pickedPhotoUri != null) { TextButton(onClick = { pickedPhotoUri = null }) { Text("সরান", color = DangerRed) } }
        }
        Spacer(Modifier.height(8.dp))
        Text("প্রাপক", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = targetId == null, onClick = { targetId = null }, label = { Text("সবাই") })
        }
        Column(Modifier.heightIn(max = 160.dp).verticalScroll(rememberScrollState())) {
            profiles.forEach { p ->
                Text(
                    p.fullName,
                    fontWeight = if (targetId == p.id) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        .clickable { targetId = p.id },
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                val photo = pickedPhotoUri
                if (photo == null) {
                    MockRepository.createNotification(com.abm.erp.data.NotificationCategory.ALERT, "📢 ${title.trim()}", body.trim(), targetEmployeeId = targetId)
                    sentMsg = if (targetId == null) "সবাইকে পাঠানো হয়েছে।" else "পাঠানো হয়েছে।"
                    title = ""; body = ""
                } else {
                    uploadingPhoto = true
                    MockRepository.uploadNoticePhoto(noticeContext, photo.toString()) { url ->
                        uploadingPhoto = false
                        if (url != null) {
                            MockRepository.createNotification(com.abm.erp.data.NotificationCategory.ALERT, "📢 ${title.trim()}", body.trim(), targetEmployeeId = targetId, imageUri = url)
                            sentMsg = if (targetId == null) "সবাইকে পাঠানো হয়েছে।" else "পাঠানো হয়েছে।"
                            title = ""; body = ""; pickedPhotoUri = null
                        } else {
                            sentMsg = "ছবি আপলোড করা যায়নি — আবার চেষ্টা করুন।"
                        }
                    }
                }
            },
            enabled = title.isNotBlank() && (body.isNotBlank() || pickedPhotoUri != null) && !uploadingPhoto,
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (uploadingPhoto) "পাঠানো হচ্ছে…" else "Notice পাঠান") }
        sentMsg?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
        }
        Spacer(Modifier.height(24.dp))
    }
}


/**
 * v113-77 — first UI for the long-existing CorrectionRequest backend. Two action
 * tiers, exactly matching the repository's own state machine (verified, not guessed):
 * SUBMITTED → managerReviewCorrection → MANAGER_REVIEW → chairmanApproveCorrection
 * (applies real reversal + corrected repost) or chairmanRejectCorrection. All three
 * functions permission-check internally; denial shows the standard blocked-at-
 * repository line.
 */
@Composable
fun ChairmanCorrectionSection() {
    val corrections by MockRepository.correctionRequests.collectAsState()
    val open = remember(corrections) {
        corrections.filter {
            it.status == com.abm.erp.data.CorrectionRequestStatus.SUBMITTED ||
                it.status == com.abm.erp.data.CorrectionRequestStatus.MANAGER_REVIEW
        }
    }
    var rejectFor by remember { mutableStateOf<String?>(null) }
    var denyReason by remember { mutableStateOf<String?>(null) }
    if (open.isEmpty()) return

    Text("Correction Request (${open.size})", fontWeight = FontWeight.SemiBold, color = TextPrimary)
    Spacer(Modifier.height(8.dp))
    open.forEach { c ->
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${c.module} · ${c.correctionType}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text(c.status.name, style = MaterialTheme.typography.labelSmall, color = WarningAmber)
            }
            Text("${c.requestedByName} — ${c.reason}", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (c.status == com.abm.erp.data.CorrectionRequestStatus.SUBMITTED) {
                    Button(onClick = { MockRepository.managerReviewCorrection(c.id, null, onRejected = { reason -> denyReason = reason }) }) { Text("Review ✓") }
                } else {
                    Button(
                        onClick = { MockRepository.chairmanApproveCorrection(c.id, onRejected = { reason -> denyReason = reason }) },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                    ) { Text("Approve & Apply") }
                }
                OutlinedButton(onClick = { rejectFor = c.id }) { Text("Reject", color = DangerRed) }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
    denyReason?.let {
        Text("⚠ $it", color = DangerRed, style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(6.dp))
    }

    rejectFor?.let { id ->
        androidx.compose.ui.window.Dialog(onDismissRequest = { rejectFor = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var reason by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp)) {
                    Text("Reject Correction", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { MockRepository.chairmanRejectCorrection(id, reason, onRejected = { r -> denyReason = r }); rejectFor = null },
                        enabled = reason.isNotBlank(), modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm Reject") }
                }
            }
        }
    }
}
