package com.abm.erp.ui.admin

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abm.erp.data.*
import com.abm.erp.theme.*

/**
 * v113-221 — everything relocated out of the old, oversized central
 * "Company Settings Center" (fiscal year / working days / holidays / the
 * five policy notes) plus the HR-relevant subset of the old central
 * "Business Rule Engine" (the DMS-relevant rules went to DMS's own
 * Chairman panel instead — see DmsBusinessRulesSection). Matches the
 * person's own principle directly: these are HR/payroll operating
 * parameters, so they live in HR's own Chairman panel, not a generic
 * central list unrelated to where they're actually used.
 */
private data class HrRuleDef(val key: String, val label: String, val type: BusinessRuleType, val default: Double)

private val HR_RULES = listOf(
    HrRuleDef("STANDARD_SHIFT_HOURS", "Standard Shift Length (hours) — overtime counts beyond this", BusinessRuleType.COUNT, 8.0),
    HrRuleDef("OVERTIME_RATE_MULTIPLIER", "Overtime Rate Multiplier (× normal hourly rate)", BusinessRuleType.COUNT, 1.5),
    HrRuleDef("ATTENDANCE_RADIUS_M", "Attendance/Visit Radius (meters)", BusinessRuleType.DISTANCE_METERS, 100.0),
    HrRuleDef("LATE_ENTRY_GRACE_MIN", "Late Entry Grace Period (minutes after 9:00 AM)", BusinessRuleType.MINUTES, 30.0),
)

@Composable
fun CompanyPayrollSetupScreen() {
    if (MockRepository.currentUser.role != UserRole.CHAIRMAN) {
        Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) { Text("এই স্ক্রিন শুধু Chairman-এর জন্য।") }
        return
    }
    val settingsList by MockRepository.companySettingsList.collectAsState()
    val settings = remember(settingsList) { MockRepository.companySettings() }
    val rules by MockRepository.businessRules.collectAsState()
    var editingKey by remember { mutableStateOf<String?>(null) }

    var fiscalYearStartMonth by remember(settings) { mutableStateOf(settings.fiscalYearStartMonth) }
    var workingDays by remember(settings) { mutableStateOf(settings.workingDays.toSet()) }
    var attendancePolicyNote by remember(settings) { mutableStateOf(settings.attendancePolicyNote) }
    var payrollPolicyNote by remember(settings) { mutableStateOf(settings.payrollPolicyNote) }
    var invoicePolicyNote by remember(settings) { mutableStateOf(settings.invoicePolicyNote) }
    var dealerPolicyNote by remember(settings) { mutableStateOf(settings.dealerPolicyNote) }
    var targetPolicyNote by remember(settings) { mutableStateOf(settings.targetPolicyNote) }
    var saved by remember { mutableStateOf(false) }
    val allDays = listOf("SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY")
    val monthNames = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Text("Company & Payroll Setup", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(10.dp))

        Text("Financial Year — Start Month", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            monthNames.forEachIndexed { index, name ->
                FilterChip(selected = fiscalYearStartMonth == index + 1, onClick = { fiscalYearStartMonth = index + 1 }, label = { Text(name, style = MaterialTheme.typography.labelSmall) })
            }
        }
        Text("বর্তমান: ${monthNames[fiscalYearStartMonth - 1]}-এ শুরু (number-series-এ প্রতিফলিত হবে)।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)

        Spacer(Modifier.height(14.dp))
        Text("Working Days", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            allDays.forEach { day ->
                FilterChip(selected = day in workingDays, onClick = { workingDays = if (day in workingDays) workingDays - day else workingDays + day }, label = { Text(day.take(3), style = MaterialTheme.typography.labelSmall) })
            }
        }

        Spacer(Modifier.height(14.dp))
        Text("Holidays", style = MaterialTheme.typography.titleMedium)
        var holidayName by remember { mutableStateOf("") }
        var holidayDate by remember { mutableStateOf(java.time.LocalDate.now()) }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(value = holidayName, onValueChange = { holidayName = it }, label = { Text("Holiday name") }, modifier = Modifier.weight(1f))
            Button(onClick = { if (holidayName.isNotBlank()) { MockRepository.addCompanyHoliday(holidayDate, holidayName); holidayName = "" } }) { Text("+ Add ($holidayDate)") }
        }
        settings.holidays.forEach { h -> Text("${h.date} — ${h.name}", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }

        Spacer(Modifier.height(14.dp))
        Text("Policies", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(value = attendancePolicyNote, onValueChange = { attendancePolicyNote = it }, label = { Text("Attendance Policy") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = payrollPolicyNote, onValueChange = { payrollPolicyNote = it }, label = { Text("Payroll Policy") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = invoicePolicyNote, onValueChange = { invoicePolicyNote = it }, label = { Text("Invoice Policy") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = dealerPolicyNote, onValueChange = { dealerPolicyNote = it }, label = { Text("Dealer Policy") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = targetPolicyNote, onValueChange = { targetPolicyNote = it }, label = { Text("Target Policy") }, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(16.dp))
        if (saved) { Text("✓ সংরক্ষিত হয়েছে", color = SuccessGreen, style = MaterialTheme.typography.labelSmall); Spacer(Modifier.height(8.dp)) }
        Button(
            onClick = {
                saved = MockRepository.updateCompanySettings(
                    settings.copy(
                        fiscalYearStartMonth = fiscalYearStartMonth, workingDays = workingDays.toList(),
                        attendancePolicyNote = attendancePolicyNote, payrollPolicyNote = payrollPolicyNote,
                        invoicePolicyNote = invoicePolicyNote, dealerPolicyNote = dealerPolicyNote, targetPolicyNote = targetPolicyNote,
                    ),
                )
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Save") }

        Spacer(Modifier.height(20.dp))
        Text("Payroll & Attendance Rules", style = MaterialTheme.typography.titleMedium)
        Text("পরিবর্তন সাথে সাথে সারা ERP-এ প্রতিফলিত হবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(6.dp))
        HR_RULES.forEach { def ->
            val current = rules.firstOrNull { it.key == def.key }
            val currentValue = current?.value ?: def.default
            Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), tonalElevation = 2.dp) {
                Column(Modifier.padding(10.dp)) {
                    Text(def.label, style = MaterialTheme.typography.titleSmall)
                    Text("বর্তমান মান: $currentValue", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    TextButton(onClick = { editingKey = def.key }) { Text("সম্পাদনা করুন") }
                }
            }
        }
    }

    editingKey?.let { key ->
        val def = HR_RULES.first { it.key == key }
        val current = rules.firstOrNull { it.key == key }?.value ?: def.default
        var newValue by remember { mutableStateOf(current.toString()) }
        androidx.compose.ui.window.Dialog(onDismissRequest = { editingKey = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(def.label, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newValue, onValueChange = { newValue = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("নতুন মান") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val v = newValue.toDoubleOrNull()
                            if (v != null) { MockRepository.setBusinessRule(def.key, def.label, def.type, v); editingKey = null }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("সংরক্ষণ করুন") }
                }
            }
        }
    }
}
