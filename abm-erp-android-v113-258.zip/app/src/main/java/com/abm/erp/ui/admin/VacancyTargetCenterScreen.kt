package com.abm.erp.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.abm.erp.data.*
import com.abm.erp.theme.*
import kotlinx.coroutines.launch

@Composable
fun VacancyTargetCenterScreen() {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Vacancy & Target Control Center", style = MaterialTheme.typography.titleLarge)
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Vacancies") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Targets") })
        }
        if (tab == 0) VacancyTab() else TargetTab()
    }
}

@Composable
private fun VacancyTab() {
    val scope = rememberCoroutineScope()
    val currentUser = MockRepository.currentUser
    val isChairman = currentUser.role == UserRole.CHAIRMAN
    val vacancies by MockRepository.vacancies.collectAsState()
    val profiles by MockRepository.employeeProfiles.collectAsState()
    var showSubmit by remember { mutableStateOf(false) }
    // v113-225 — a real, previously-undiscovered dead end, found while
    // checking for backend functions with no UI trigger: chairmanMarkVacancyFilled
    // existed and worked, but nothing ever called it — its own doc comment
    // claimed chairmanApproveHiring calls it automatically, but that
    // function doesn't even receive a vacancyId to know which vacancy to
    // fill, so the automatic link was never actually built. Without this,
    // a Vacancy could never reach FILLED — which also meant "Close" (shown
    // only for FILLED) was permanently unreachable too. Rather than a
    // heuristic auto-match (ambiguous when multiple open vacancies share a
    // designation/department), this gives Chairman explicit, deliberate
    // control: pick which employee filled which vacancy.
    var markFillingId by remember { mutableStateOf<String?>(null) }

    Spacer(Modifier.height(8.dp))
    Button(onClick = { showSubmit = true }) { Text("+ Submit Vacancy Request") }
    Spacer(Modifier.height(8.dp))
    LazyColumn {
        items(vacancies) { v ->
            Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), tonalElevation = 2.dp) {
                Column(Modifier.padding(10.dp)) {
                    Text("${v.designation} — ${v.department}", style = MaterialTheme.typography.titleSmall)
                    Text("Status: ${v.status}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    v.reason?.let { Text(it, style = MaterialTheme.typography.labelSmall) }
                    if (isChairman) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 6.dp)) {
                            when (v.status) {
                                VacancyStatus.PENDING_CHAIRMAN_APPROVAL -> TextButton(onClick = { scope.launch { MockRepository.chairmanApproveVacancy(v.id) } }) { Text("Approve→Open") }
                                VacancyStatus.OPEN -> {
                                    TextButton(onClick = { markFillingId = v.id }) { Text("Mark Filled") }
                                    TextButton(onClick = { scope.launch { MockRepository.chairmanHoldVacancy(v.id) } }) { Text("Hold") }
                                    TextButton(onClick = { scope.launch { MockRepository.chairmanFreezeVacancy(v.id) } }) { Text("Freeze") }
                                }
                                VacancyStatus.ON_HOLD, VacancyStatus.FROZEN -> TextButton(onClick = { scope.launch { MockRepository.chairmanReopenVacancy(v.id) } }) { Text("Reopen") }
                                else -> {}
                            }
                            if (v.status !in setOf(VacancyStatus.CLOSED, VacancyStatus.CANCELLED, VacancyStatus.FILLED)) {
                                TextButton(onClick = { scope.launch { MockRepository.chairmanCancelVacancy(v.id) } }) { Text("Cancel", color = DangerRed) }
                            }
                            if (v.status == VacancyStatus.FILLED) TextButton(onClick = { scope.launch { MockRepository.chairmanCloseVacancy(v.id) } }) { Text("Close") }
                        }
                        if (v.status == VacancyStatus.FILLED && v.filledByEmployeeId != null) {
                            val filledByName = profiles.firstOrNull { it.id == v.filledByEmployeeId }?.fullName ?: v.filledByEmployeeId
                            Text("Filled by: $filledByName", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                        }
                    } else {
                        Text("শুধু Chairman স্ট্যাটাস পরিবর্তন করতে পারবেন।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }
            }
        }
    }

    if (markFillingId != null) {
        val vacancyId = markFillingId!!
        var selectedEmployeeId by remember { mutableStateOf<String?>(null) }
        var fillError by remember { mutableStateOf<String?>(null) }
        Dialog(onDismissRequest = { markFillingId = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 400.dp).verticalScroll(rememberScrollState())) {
                    Text("কোন employee এই vacancy পূরণ করলেন?", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    fillError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    profiles.filter { !it.isDeleted }.forEach { p ->
                        Text(
                            p.fullName, style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (selectedEmployeeId == p.id) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { selectedEmployeeId = p.id },
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val empId = selectedEmployeeId
                            if (empId != null) {
                                scope.launch {
                                    val ok = MockRepository.chairmanMarkVacancyFilled(vacancyId, empId)
                                    if (ok) markFillingId = null else fillError = "সংরক্ষণ করা যায়নি — আবার চেষ্টা করুন।"
                                }
                            }
                        },
                        enabled = selectedEmployeeId != null,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm") }
                }
            }
        }
    }

    if (showSubmit) {
        var designation by remember { mutableStateOf("") }
        var department by remember { mutableStateOf("") }
        var reason by remember { mutableStateOf("") }
        Dialog(onDismissRequest = { showSubmit = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("New Vacancy Request", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(value = designation, onValueChange = { designation = it }, label = { Text("Designation") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = department, onValueChange = { department = it }, label = { Text("Department") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
                    var vacancyError by remember { mutableStateOf<String?>(null) }
                    vacancyError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { scope.launch { val created = MockRepository.submitVacancyRequest(designation, department, null, reason.ifBlank { null }, onRejected = { r -> vacancyError = r }); if (created != null) showSubmit = false } }, modifier = Modifier.fillMaxWidth()) { Text("Submit for Chairman Approval") }
                }
            }
        }
    }
}

@Composable
private fun TargetTab() {
    val scope = rememberCoroutineScope()
    val currentUser = MockRepository.currentUser
    val isChairman = currentUser.role == UserRole.CHAIRMAN
    val targets by MockRepository.targets.collectAsState()
    var showCreate by remember { mutableStateOf(false) }

    Spacer(Modifier.height(8.dp))
    if (isChairman) Button(onClick = { showCreate = true }) { Text("+ Create Target") }
    Text("Employees দেখবে নিজের assigned target/achievement/remaining — এখানে Chairman-এর তালিকা:", style = MaterialTheme.typography.labelSmall, color = TextSecondary, modifier = Modifier.padding(top = 6.dp))
    LazyColumn {
        items(targets) { t ->
            val pct = if (t.targetValue > 0) (t.achievedValue / t.targetValue * 100) else 0.0
            Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), tonalElevation = 2.dp) {
                Column(Modifier.padding(10.dp)) {
                    Text("${t.targetType} — ${t.scopeType}:${t.scopeId}", style = MaterialTheme.typography.titleSmall)
                    Text("Target: ${t.targetValue} · Achieved: ${t.achievedValue} (${"%.1f".format(pct)}%) · Remaining: ${(t.targetValue - t.achievedValue).coerceAtLeast(0.0)}", style = MaterialTheme.typography.bodySmall)
                    Text("Period: ${t.periodStart} → ${t.periodEnd} · Days left: ${(t.periodEnd.toEpochDay() - java.time.LocalDate.now().toEpochDay()).coerceAtLeast(0)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    if (t.isOverride) Text("⚠ Override: ${t.overrideReason}", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                    if (isChairman) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 6.dp)) {
                            TextButton(onClick = { scope.launch { MockRepository.chairmanIncreaseTarget(t.id, t.targetValue * 0.1, "Quick +10% adjustment") } }) { Text("+10%") }
                            TextButton(onClick = { scope.launch { MockRepository.chairmanReduceTarget(t.id, t.targetValue * 0.1, "Quick -10% adjustment") } }) { Text("-10%") }
                            TextButton(onClick = { scope.launch { MockRepository.chairmanPauseTarget(t.id, "Paused by Chairman") } }) { Text("Pause") }
                            TextButton(onClick = { scope.launch { MockRepository.chairmanCancelTarget(t.id, "Cancelled by Chairman") } }) { Text("Cancel", color = DangerRed) }
                        }
                    }
                }
            }
        }
    }

    if (showCreate) {
        var scopeType by remember { mutableStateOf(TargetScopeType.EMPLOYEE) }
        var scopeId by remember { mutableStateOf("") }
        var targetType by remember { mutableStateOf(TargetType.SALES_AMOUNT) }
        var targetValue by remember { mutableStateOf("") }
        var periodType by remember { mutableStateOf(TargetPeriodType.MONTHLY) }
        var context by remember { mutableStateOf<MockRepository.TargetHistoricalContext?>(null) }
        var overrideReason by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        Dialog(onDismissRequest = { showCreate = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                    Text("Create Target", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text("Scope", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        TargetScopeType.values().forEach { s -> FilterChip(selected = scopeType == s, onClick = { scopeType = s }, label = { Text(s.name, style = MaterialTheme.typography.labelSmall) }) }
                    }
                    OutlinedTextField(value = scopeId, onValueChange = { scopeId = it }, label = { Text("Scope ID (employee/dealer/retailer/zone name)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Text("Target type", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        TargetType.values().forEach { t -> FilterChip(selected = targetType == t, onClick = { targetType = t }, label = { Text(t.name.take(6), style = MaterialTheme.typography.labelSmall) }) }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Period", style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TargetPeriodType.values().forEach { p -> FilterChip(selected = periodType == p, onClick = { periodType = p }, label = { Text(p.name.take(4), style = MaterialTheme.typography.labelSmall) }) }
                    }
                    OutlinedTextField(value = targetValue, onValueChange = { targetValue = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Target value") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Button(onClick = { scope.launch { context = MockRepository.targetHistoricalContext(scopeType, scopeId) } }, enabled = scopeId.isNotBlank()) { Text("Load Historical Context") }
                    context?.let { c ->
                        Column(Modifier.padding(top = 6.dp)) {
                            Text("Previous 3-month avg: ${"%.0f".format(c.previous3MonthAverage)}", style = MaterialTheme.typography.labelSmall)
                            Text("Previous achievement: ${"%.1f".format(c.previousAchievementPct)}%", style = MaterialTheme.typography.labelSmall)
                            Text("Active dealers: ${c.activeDealerCount} · retailers: ${c.activeRetailerCount}", style = MaterialTheme.typography.labelSmall)
                            Text("Outstanding due: ৳${"%,.0f".format(c.outstandingDue)} · Stock: ${c.availableStock}", style = MaterialTheme.typography.labelSmall)
                            val v = targetValue.toDoubleOrNull() ?: 0.0
                            if (c.previous3MonthAverage > 0 && (v > c.previous3MonthAverage * 1.5 || v < c.previous3MonthAverage * 0.5)) {
                                Text("⚠ এই target history-র চেয়ে অস্বাভাবিক — override reason দিন।", color = WarningAmber, style = MaterialTheme.typography.labelSmall)
                                OutlinedTextField(value = overrideReason, onValueChange = { overrideReason = it }, label = { Text("Override reason (required)") }, modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                    err?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val v = targetValue.toDoubleOrNull() ?: 0.0
                            val today = java.time.LocalDate.now()
                            val periodEnd = when (periodType) {
                                TargetPeriodType.DAILY -> today
                                TargetPeriodType.WEEKLY -> today.plusDays(7)
                                TargetPeriodType.MONTHLY -> today.plusMonths(1)
                                TargetPeriodType.QUARTERLY -> today.plusMonths(3)
                                TargetPeriodType.YEARLY -> today.plusYears(1)
                                TargetPeriodType.CUSTOM -> today.plusMonths(1)
                            }
                            val created = MockRepository.chairmanCreateTarget(scopeType, scopeId, null, periodType, today, periodEnd, targetType, v, context?.previous3MonthAverage ?: 0.0, overrideReason.ifBlank { null })
                            if (created != null) showCreate = false else err = "তৈরি করা যায়নি — override reason দরকার হতে পারে, অথবা আপনি Chairman না।"
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Create Target") }
                }
            }
        }
    }
}
