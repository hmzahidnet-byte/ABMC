package com.abm.erp.core

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.MarkunreadMailbox
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.CampaignChannel
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

/** A dealer/retailer as this composer needs to see them — just enough to call/text/select. */
data class CampaignParty(val id: String, val name: String, val phone: String, val zone: String, val due: Double = 0.0)

/**
 * v113-249 — full rebuild, the person's own direct, confirmed complaint: this used to
 * only support "compose a message, pick one zone, tap পাঠান" — which just wrote a log
 * entry with a computed sentCount, never actually sent anything to a real phone. No way
 * to reach one specific dealer, or a hand-picked few, and no Call button at all.
 *
 * Now: real, per-party Call/SMS/WhatsApp (the exact same device-Intent pattern already
 * proven in DealerAccountControlTab — not a new mechanism), plus real multi-select with
 * a genuine bulk SMS (Android's own smsto: scheme accepts comma-separated numbers, opening
 * one real compose screen addressed to everyone selected). WhatsApp has no reliable
 * multi-recipient deep link — Meta's own wa.me scheme is single-contact only — so bulk
 * WhatsApp stays honestly single-recipient-at-a-time rather than pretending otherwise.
 * The campaign log below is kept for what it was always good at — a real record of what
 * was sent to whom — but no longer stands in for actually sending it.
 */
@Composable
fun PartyCampaignSection(
    /** e.g. "Dealer" / "Retailer" — display only. */
    audienceLabel: String,
    parties: List<CampaignParty>,
) {
    val campaigns by MockRepository.campaigns.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current
    var query by remember { mutableStateOf("") }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }
    var message by remember { mutableStateOf("") }
    // v113-252 — the person's own direct question: was there any option
    // here specifically for due collection? Honestly, no — added rather
    // than assumed away. dealer.dueBalance already existed and was
    // already flowing through to CampaignParty's own construction at
    // both real call sites (DMS/RMS), just never used inside this
    // composable itself.
    var dueOnly by remember { mutableStateOf(false) }

    val filtered = remember(parties, query, dueOnly) {
        val base = if (dueOnly) parties.filter { it.due > 0 } else parties
        (if (query.isBlank()) base else base.filter { it.name.contains(query, ignoreCase = true) || it.zone.contains(query, ignoreCase = true) })
            .sortedByDescending { it.due }
    }
    val selectedParties = remember(parties, selectedIds) { parties.filter { it.id in selectedIds } }

    fun toast(msg: String) = android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()

    fun callOne(phone: String) {
        try { context.startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:$phone"))) }
        catch (e: Exception) { toast("Call করা যায়নি।") }
    }
    fun smsMany(phones: List<String>, body: String) {
        try {
            val intent = android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:${phones.joinToString(",")}"))
            if (body.isNotBlank()) intent.putExtra("sms_body", body)
            context.startActivity(intent)
        } catch (e: Exception) { toast("SMS app পাওয়া যায়নি।") }
    }
    fun whatsappOne(phone: String, body: String) {
        try {
            val digits = phone.filter { it.isDigit() }
            val intl = if (digits.startsWith("880")) digits else "88" + digits.removePrefix("0").let { d -> if (d.startsWith("1")) "0$d" else d }
            val encoded = java.net.URLEncoder.encode(body, "UTF-8")
            context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://wa.me/$intl?text=$encoded")))
        } catch (e: Exception) { toast("WhatsApp খোলা যায়নি।") }
    }
    // v113-252 — {নাম}/{বকেয়া} in the message box only mean anything if
    // something actually substitutes them before the message goes out —
    // done here, once, real per-dealer values, used by every individual
    // (not bulk — a single shared SMS intent to many numbers has no way
    // to carry a different body per recipient, stated plainly in the UI
    // rather than silently sending the literal placeholder text) send
    // button below.
    fun personalize(p: CampaignParty, body: String) = body
        .replace("{নাম}", p.name)
        .replace("{বকেয়া}", "%,.0f".format(p.due))

    Column(Modifier.fillMaxSize()) {
        Text("$audienceLabel-দের সাথে সরাসরি যোগাযোগ", fontWeight = FontWeight.SemiBold, color = TextPrimary)
        Text(
            "বেছে নিন — একজন বা অনেকজন — তারপর Call/SMS/WhatsApp সরাসরি এখান থেকেই।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("নাম বা এলাকা দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilterChip(selected = dueOnly, onClick = { dueOnly = !dueOnly }, label = { Text("শুধু বকেয়া আছে এমন", fontSize = 11.sp) })
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = message, onValueChange = { message = it },
            label = { Text("বার্তা (SMS/WhatsApp-এ পাঠানোর সময় এটাই যাবে)") }, minLines = 2, modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(4.dp))
        TextButton(onClick = { message = "প্রিয় {নাম}, আপনার বর্তমান বকেয়া ৳{বকেয়া}। দ্রুত পরিশোধের অনুরোধ রইলো। ধন্যবাদ — ABM Corporation" }) {
            Text("💰 বকেয়া রিমাইন্ডার টেমপ্লেট বসান", fontSize = 11.sp)
        }
        Text(
            "এককজনকে পাঠালে {নাম}/{বকেয়া} সেই dealer-এর real তথ্য দিয়ে বসে যাবে। একসাথে অনেকজনকে পাঠালে হুবহু যাবে — তাই bulk-এ {নাম}/{বকেয়া} ব্যবহার না করাই ভালো।",
            fontSize = 9.5.sp, color = TextSecondary,
        )
        Spacer(Modifier.height(8.dp))

        if (selectedIds.isNotEmpty()) {
            Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text("${selectedIds.size} জন বেছে নেওয়া হয়েছে", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            smsMany(selectedParties.map { it.phone }, message)
                            MockRepository.broadcastCampaign(CampaignChannel.SMS, message, selectedParties.map { it.zone }.distinct().joinToString(", "), onRejected = {})
                        }) { Text("📱 সবাইকে SMS") }
                        if (selectedIds.size == 1) {
                            OutlinedButton(onClick = {
                                whatsappOne(selectedParties.first().phone, personalize(selectedParties.first(), message))
                                MockRepository.broadcastCampaign(CampaignChannel.WHATSAPP, message, selectedParties.first().zone, onRejected = {})
                            }) { Text("💬 WhatsApp") }
                        }
                        TextButton(onClick = { selectedIds = emptySet() }) { Text("বাতিল") }
                    }
                    if (selectedIds.size > 1) {
                        Spacer(Modifier.height(4.dp))
                        Text("WhatsApp একসাথে একাধিক জনকে পাঠানো যায় না (WhatsApp-এর নিজস্ব সীমাবদ্ধতা) — একজন একজন করে নিচের তালিকা থেকে পাঠান।", fontSize = 9.sp, color = TextSecondary)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        Text("$audienceLabel তালিকা (${filtered.size})", fontWeight = FontWeight.SemiBold, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            filtered.take(50).forEach { p ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = p.id in selectedIds,
                            onCheckedChange = { checked -> selectedIds = if (checked) selectedIds + p.id else selectedIds - p.id },
                        )
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.SemiBold, color = TextPrimary, maxLines = 1)
                            Text("${p.zone} · ${p.phone.ifBlank { "নম্বর নেই" }}", style = MaterialTheme.typography.labelSmall, color = TextSecondary, maxLines = 1)
                            if (p.due > 0) {
                                Text("বকেয়া ৳${"%,.0f".format(p.due)}", style = MaterialTheme.typography.labelSmall, color = com.abm.erp.theme.WarningAmber, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        if (p.phone.isNotBlank()) {
                            IconButton(onClick = { callOne(p.phone) }) { Icon(Icons.Filled.Call, contentDescription = "Call ${p.name}", tint = TextPrimary) }
                            IconButton(onClick = { smsMany(listOf(p.phone), personalize(p, message)) }) { Icon(Icons.Filled.MarkunreadMailbox, contentDescription = "SMS ${p.name}", tint = TextPrimary) }
                            IconButton(onClick = { whatsappOne(p.phone, personalize(p, message)) }) { Icon(Icons.Filled.Send, contentDescription = "WhatsApp ${p.name}", tint = TextPrimary) }
                        }
                    }
                }
            }
            if (filtered.isEmpty()) Text("কোনো $audienceLabel পাওয়া যায়নি।", color = TextSecondary, modifier = Modifier.padding(vertical = 8.dp))
        }

        Spacer(Modifier.height(16.dp))
        Text("পাঠানো Campaign — রেকর্ড (${campaigns.size})", fontWeight = FontWeight.SemiBold, color = TextPrimary)
        Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            campaigns.take(20).forEach { c ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(c.channel.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("→ ${c.targetZone}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Text(c.message, style = MaterialTheme.typography.bodySmall)
                    Text("পৌঁছেছে: ${c.sentCount}", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                }
            }
            if (campaigns.isEmpty()) Text("এখনো কোনো campaign পাঠানো হয়নি।", color = TextSecondary)
        }
    }
}
