package com.abm.erp.core

import android.content.Context
import com.abm.erp.data.SalesInvoice
import java.io.File

/**
 * Task D — structured business-document export. Unlike the generic
 * title/body fallback in UniversalActionMenu.kt, this draws an actual
 * invoice layout: company header, reference, date, dealer, a real
 * line-item table (name/qty/unit price/discount/line total), subtotal,
 * discount amount, grand total, status and a footer — using ONLY fields
 * that genuinely exist on SalesInvoice. No fabricated line items or totals.
 *
 * This is the first of the requested structured templates to be
 * completed; Dealer Statement, Purchase Order, Production Sheet,
 * Voucher/Ledger record and Payslip still use the generic fallback as of
 * this version (see the v82 continuation report's honest gap list).
 */
fun exportSalesInvoicePdf(
    context: Context,
    invoice: SalesInvoice,
    /**
     * v113-87 — a REGISTRY payload from `QrRegistry.issue("SalesInvoice", id)`, issued by
     * the caller inside its own coroutine (this fn stays non-suspend for Canvas work).
     * The old hardcoded "INVOICE:<id>" string was scannable by NOTHING — the secure path
     * rejects non-registry payloads and the legacy CodeRegistry matcher knows invoiceNo,
     * not a prefixed id — so a broken QR was printed on every bill. Null now prints an
     * honest line instead of a dead code.
     */
    qrPayload: String? = null,
): File {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas

    // v113-212 — full redesign to match the on-screen InvoiceDocumentBody
    // this session already rebuilt (v113-198): white page, colour spent
    // only on the logo mark / "INVOICE" label / table header / total
    // figure, not a filled banner — plus the grid table, ledger-style
    // totals rule, In Words, and ABM-mark logo the on-screen version has.
    // Same `orange` hex as DarazOrange (0xFFF85606, confirmed directly
    // against theme/Color.kt before assuming they already matched).
    val orange = android.graphics.Color.rgb(0xF8, 0x56, 0x06)
    val orangeDark = android.graphics.Color.rgb(0xC2, 0x3F, 0x00)
    val navy = android.graphics.Color.rgb(0x1B, 0x24, 0x30)
    val gray = android.graphics.Color.rgb(0x64, 0x74, 0x8B)
    val lightGray = android.graphics.Color.rgb(0xF7, 0xF8, 0xFA)
    val borderGray = android.graphics.Color.rgb(0xD5, 0xDB, 0xE3)
    val statusColor = when (invoice.status) {
        "PAID" -> android.graphics.Color.rgb(0x22, 0xA0, 0x6B)
        "CANCELLED" -> android.graphics.Color.rgb(0xE2, 0x4A, 0x3B)
        "PARTIALLY_PAID" -> android.graphics.Color.rgb(0xF5, 0xA6, 0x23)
        else -> android.graphics.Color.rgb(0x2E, 0x6F, 0xE0)
    }

    val logoTextPaint = android.graphics.Paint().apply { textSize = 9f; isFakeBoldText = true; color = android.graphics.Color.WHITE; textAlign = android.graphics.Paint.Align.CENTER }
    val companyNamePaint = android.graphics.Paint().apply { textSize = 15f; isFakeBoldText = true; color = navy }
    val taglinePaint = android.graphics.Paint().apply { textSize = 8f; color = gray }
    val docTitlePaint = android.graphics.Paint().apply { textSize = 17f; isFakeBoldText = true; color = orange; textAlign = android.graphics.Paint.Align.RIGHT }
    val labelPaint = android.graphics.Paint().apply { textSize = 8f; isFakeBoldText = true; color = gray }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f; color = navy }
    val boldBodyPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true; color = navy }
    val headerTextPaint = android.graphics.Paint().apply { textSize = 9.5f; isFakeBoldText = true; color = android.graphics.Color.WHITE }
    val footerPaint = android.graphics.Paint().apply { textSize = 9f; color = gray }
    val italicFooterPaint = android.graphics.Paint().apply { textSize = 9f; color = gray; textSkewX = -0.2f; textAlign = android.graphics.Paint.Align.RIGHT }
    val fillPaint = android.graphics.Paint()
    val linePaint = android.graphics.Paint().apply { color = borderGray; strokeWidth = 1f }
    val ruleDarkPaint = android.graphics.Paint().apply { color = navy; strokeWidth = 1.2f }
    val cellBorderPaint = android.graphics.Paint().apply { color = borderGray; strokeWidth = 0.7f; style = android.graphics.Paint.Style.STROKE }

    val left = 40f
    val right = 555f
    val width = right - left

    // ---- masthead — white page, logo mark, orange INVOICE label ----
    val company = com.abm.erp.data.MockRepository.companySettings()
    fillPaint.color = orange
    canvas.drawRoundRect(android.graphics.RectF(left, 30f, left + 32f, 62f), 5f, 5f, fillPaint)
    canvas.drawText("ABM", left + 16f, 50f, logoTextPaint)
    canvas.drawText(company.companyName.ifBlank { "ABM Corporation" }, left + 42f, 46f, companyNamePaint)
    canvas.drawText(
        listOfNotNull(company.companyAddress.ifBlank { null }, company.companyPhone.ifBlank { null })
            .joinToString(" · ").ifBlank { "Enterprise. Control. Growth." },
        left + 42f, 58f, taglinePaint,
    )
    canvas.drawText("INVOICE", right, 48f, docTitlePaint)
    canvas.drawRect(left, 72f, right, 74.5f, fillPaint)
    linePaint.color = android.graphics.Color.rgb(0xFF, 0xD9, 0xC4)
    canvas.drawRect(left, 74.5f, right, 76f, linePaint)
    linePaint.color = borderGray

    // ---- meta box: Invoice No / Date (left) + QR (right), one bordered box ----
    var y = 90f
    canvas.drawRect(android.graphics.RectF(left, y, right, y + 90f), cellBorderPaint)
    canvas.drawLine(right - 74f, y, right - 74f, y + 90f, linePaint)
    canvas.drawText("INVOICE NO", left + 12f, y + 20f, labelPaint)
    canvas.drawText(invoice.invoiceNo, left + 12f, y + 36f, boldBodyPaint)
    canvas.drawText("DATE", left + 12f, y + 58f, labelPaint)
    canvas.drawText(invoice.createdAt.toLocalDate().toString(), left + 12f, y + 74f, bodyPaint)
    // v113-211 — QR isolated in its own try/catch so a QR failure degrades
    // to an honest note instead of failing the whole document.
    if (qrPayload != null) {
        try {
            val qrBitmap = com.abm.erp.util.QrCodeGenerator.generate(qrPayload, 200)
            canvas.drawBitmap(qrBitmap, null, android.graphics.RectF(right - 64f, y + 10f, right - 10f, y + 64f), null)
            val centerPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; textSize = 7.5f }
            canvas.drawText("Scan to verify", right - 37f, y + 78f, centerPaint)
        } catch (e: Exception) {
            com.abm.erp.config.AppLog.w("StructuredExports", "QR generation failed for invoice PDF", e)
            val centerPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; textSize = 7.5f }
            canvas.drawText("QR could not", right - 37f, y + 40f, centerPaint)
            canvas.drawText("be generated", right - 37f, y + 52f, centerPaint)
        }
    } else {
        val centerPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; textSize = 7.5f }
        canvas.drawText("QR not issued", right - 37f, y + 46f, centerPaint)
    }
    y += 100f

    // ---- Dealer — orange bar + bordered box, matching the on-screen DocBar pattern ----
    fillPaint.color = orange
    canvas.drawRect(left, y, right, y + 20f, fillPaint)
    canvas.drawText("DEALER", left + 10f, y + 14f, headerTextPaint)
    y += 20f
    canvas.drawRect(android.graphics.RectF(left, y, right, y + 56f), cellBorderPaint)
    canvas.drawLine(left + width / 2, y, left + width / 2, y + 56f, linePaint)
    canvas.drawText(invoice.dealerName, left + 12f, y + 20f, boldBodyPaint)
    canvas.drawText(invoice.dealerZone, left + 12f, y + 36f, footerPaint)
    canvas.drawText("PAYMENT TERMS", left + width / 2 + 12f, y + 18f, labelPaint)
    canvas.drawText(if (invoice.status == "PAID") "Paid" else "Credit", left + width / 2 + 12f, y + 34f, boldBodyPaint)
    canvas.drawText("Courier: ${invoice.courier?.ifBlank { null } ?: "—"}", left + width / 2 + 12f, y + 48f, footerPaint)
    y += 70f

    // ---- item table — real grid (both horizontal and vertical rules), orange header ----
    val colX = floatArrayOf(left, left + 34f, left + 290f, left + 350f, left + 420f, right)
    fillPaint.color = orange
    canvas.drawRect(left, y, right, y + 22f, fillPaint)
    canvas.drawText("#", colX[0] + 8f, y + 15f, headerTextPaint)
    canvas.drawText("Item / Product", colX[1] + 8f, y + 15f, headerTextPaint)
    canvas.drawText("Qty", colX[2] + 8f, y + 15f, headerTextPaint)
    canvas.drawText("Rate", colX[3] + 8f, y + 15f, headerTextPaint)
    canvas.drawText("Amount", colX[4] + 8f, y + 15f, headerTextPaint)
    for (i in 0..5) canvas.drawLine(colX[i], y, colX[i], y + 22f, android.graphics.Paint().apply { color = android.graphics.Color.WHITE; strokeWidth = 0.5f; alpha = 90 })
    y += 22f

    invoice.lineItems.forEachIndexed { idx, item ->
        if (y > 700f) return@forEachIndexed // page-overflow guard — stops adding rows rather than crashing; multi-page support is a future refinement
        val rowH = 24f
        if (idx % 2 == 1) { fillPaint.color = lightGray; canvas.drawRect(left, y, right, y + rowH, fillPaint) }
        canvas.drawText("%02d".format(idx + 1), colX[0] + 8f, y + 16f, bodyPaint)
        canvas.drawText(item.name.take(28), colX[1] + 8f, y + 16f, bodyPaint)
        canvas.drawText("${item.qty}", colX[2] + 8f, y + 16f, bodyPaint)
        canvas.drawText("৳${"%.0f".format(item.unitPrice)}", colX[3] + 8f, y + 16f, bodyPaint)
        canvas.drawText("৳${"%.0f".format(item.lineTotal)}", colX[4] + 8f, y + 16f, boldBodyPaint)
        for (i in 0..5) canvas.drawLine(colX[i], y, colX[i], y + rowH, cellBorderPaint)
        canvas.drawLine(left, y + rowH, right, y + rowH, cellBorderPaint)
        y += rowH
    }
    canvas.drawLine(left, y, right, y, cellBorderPaint) // closes the table's bottom edge
    y += 16f

    // ---- totals — plain rows, ledger double-rule above Total, no tax line, no heavy banner ----
    val totalsX = right - 200f
    canvas.drawText("Subtotal", totalsX, y, footerPaint)
    canvas.drawText("৳${"%,.0f".format(invoice.subTotal)}", right, y, android.graphics.Paint(bodyPaint).apply { textAlign = android.graphics.Paint.Align.RIGHT })
    y += 16f
    if (invoice.dealerDiscountPct > 0) {
        canvas.drawText("Discount (${invoice.dealerDiscountPct}%)", totalsX, y, footerPaint)
        canvas.drawText("− ৳${"%,.0f".format(invoice.dealerDiscountAmt)}", right, y, android.graphics.Paint(bodyPaint).apply { textAlign = android.graphics.Paint.Align.RIGHT })
        y += 16f
    }
    y += 4f
    canvas.drawLine(totalsX, y, right, y, ruleDarkPaint)
    y += 3f
    canvas.drawLine(totalsX, y, right, y, ruleDarkPaint)
    y += 20f
    canvas.drawText("TOTAL", totalsX, y, android.graphics.Paint(boldBodyPaint).apply { textSize = 12f })
    canvas.drawText(
        "৳${"%,.0f".format(invoice.netAfterDiscount)}", right, y,
        android.graphics.Paint().apply { textSize = 19f; isFakeBoldText = true; color = orange; textAlign = android.graphics.Paint.Align.RIGHT },
    )
    y += 24f

    // ---- In Words — same amountInWords() the on-screen invoice already uses, not a duplicate ----
    canvas.drawText(
        "In Words: ${com.abm.erp.core.amountInWords(invoice.netAfterDiscount)}", right, y,
        android.graphics.Paint(italicFooterPaint).apply { textSkewX = -0.2f },
    )
    y += 30f

    // ---- Party balance (same source and fallback rule as the on-screen invoice) ----
    val liveDue = com.abm.erp.data.MockRepository.dealers.value.firstOrNull { it.id == invoice.dealerId }?.dueBalance ?: 0.0
    val hasSnapshot = invoice.closingDueSnapshot > 0.0 || invoice.previousDueSnapshot > 0.0
    val prevDue = if (hasSnapshot) invoice.previousDueSnapshot else (liveDue - invoice.total).coerceAtLeast(0.0)
    val approvedTotalDue = if (hasSnapshot) invoice.closingDueSnapshot else liveDue
    // v113-213 — same additive pending-balance rule as the on-screen
    // document (see that file's own v113-213 note for the full reasoning):
    // other pending invoices for this dealer now count toward the Total
    // Due shown here too, but stay on their own explicit line rather than
    // being silently folded into one number.
    val otherPendingSum = com.abm.erp.data.MockRepository.salesInvoices.value
        .filter { it.dealerId == invoice.dealerId && it.status == "PENDING" && it.id != invoice.id && !it.isDeleted }
        .sumOf { it.total }
    val totalDue = approvedTotalDue + otherPendingSum
    val balanceBoxH = if (otherPendingSum > 0) 72f else 56f
    fillPaint.color = lightGray
    canvas.drawRoundRect(android.graphics.RectF(left, y, left + 340f, y + balanceBoxH), 4f, 4f, fillPaint)
    var balanceY = y + 18f
    canvas.drawText("Previous Due (Approved)", left + 12f, balanceY, footerPaint)
    canvas.drawText("৳${"%,.0f".format(prevDue)}", left + 240f, balanceY, bodyPaint)
    if (otherPendingSum > 0) {
        balanceY += 16f
        val amberPaint = android.graphics.Paint(bodyPaint).apply { color = android.graphics.Color.rgb(0xF5, 0xA6, 0x23) }
        canvas.drawText("Pending (other invoices)", left + 12f, balanceY, android.graphics.Paint(footerPaint).apply { color = android.graphics.Color.rgb(0xF5, 0xA6, 0x23) })
        canvas.drawText("৳${"%,.0f".format(otherPendingSum)}", left + 240f, balanceY, amberPaint)
    }
    balanceY += 16f
    canvas.drawText("This Invoice", left + 12f, balanceY, footerPaint)
    canvas.drawText("৳${"%,.0f".format(invoice.total)}", left + 240f, balanceY, bodyPaint)
    balanceY += 16f
    canvas.drawText(if (otherPendingSum > 0) "Total Due (incl. pending)" else "Total Due", left + 12f, balanceY, boldBodyPaint)
    canvas.drawText("৳${"%,.0f".format(totalDue)}", left + 240f, balanceY, boldBodyPaint)

    // status badge, right-aligned beside the balance box
    val statusFillPaint = android.graphics.Paint().apply { color = statusColor }
    canvas.drawRoundRect(android.graphics.RectF(right - 100f, y + 6f, right, y + 26f), 10f, 10f, statusFillPaint)
    val statusTextPaint = android.graphics.Paint().apply { textSize = 9.5f; isFakeBoldText = true; color = android.graphics.Color.WHITE; textAlign = android.graphics.Paint.Align.CENTER }
    canvas.drawText(invoice.status, right - 50f, y + 20f, statusTextPaint)
    y += balanceBoxH + 20f

    // ---- Signature area ----
    canvas.drawLine(left, y, left + 150f, y, linePaint)
    canvas.drawLine(left + 190f, y, left + 340f, y, linePaint)
    canvas.drawLine(left + 380f, y, right, y, linePaint)
    y += 14f
    canvas.drawText("Prepared By (${invoice.createdBy})", left, y, footerPaint)
    canvas.drawText("Checked By", left + 190f, y, footerPaint)
    canvas.drawText("Authorized By${invoice.signedByRole?.let { " ($it)" } ?: ""}", left + 380f, y, footerPaint)
    y += 26f

    // ---- Thank you footer, matching the on-screen document ----
    val centerFooterPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; isFakeBoldText = true }
    canvas.drawText("Thank you for your business!", left + width / 2, y, centerFooterPaint)

    canvas.drawText("Generated ${java.time.LocalDateTime.now()} — ${company.companyName.ifBlank { "ABM ERP" }}", left, 815f, footerPaint)

    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "invoice_${invoice.invoiceNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/**
 * v113-153 — the memo's PDF, same drawing mechanism as exportSalesInvoicePdf (same
 * PdfDocument/Canvas approach, so the two look like siblings when printed side by
 * side), but built only from RetailOrder's own real fields. No dealer-style discount
 * row, no due-snapshot section — a retail order carries neither in this app's data
 * model, and inventing them would misrepresent what the memo actually is.
 */
fun exportRetailOrderPdf(
    context: Context,
    order: com.abm.erp.data.RetailOrder,
    qrPayload: String? = null,
): File {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas

    // v113-212 — same redesign as exportSalesInvoicePdf above, matching the
    // on-screen MemoDocumentBody (also rebuilt at v113-200). Memo's own
    // real distinctions preserved exactly, not flattened to match Invoice:
    // "Retailer" not "Dealer", no discount/subtotal row (a memo carries
    // neither in this app's data model), a standalone independent due box
    // rather than previous+this+total, and its own real signature chain
    // (Logged By SO / Verified By ASM / Retailer Signature).
    val orange = android.graphics.Color.rgb(0xF8, 0x56, 0x06)
    val navy = android.graphics.Color.rgb(0x1B, 0x24, 0x30)
    val gray = android.graphics.Color.rgb(0x64, 0x74, 0x8B)
    val lightGray = android.graphics.Color.rgb(0xF7, 0xF8, 0xFA)
    val borderGray = android.graphics.Color.rgb(0xD5, 0xDB, 0xE3)
    val statusColor = when (order.stage) {
        com.abm.erp.data.OrderStage.FULFILLED -> android.graphics.Color.rgb(0x22, 0xA0, 0x6B)
        com.abm.erp.data.OrderStage.REJECTED -> android.graphics.Color.rgb(0xE2, 0x4A, 0x3B)
        com.abm.erp.data.OrderStage.DEALER_ROUTED -> android.graphics.Color.rgb(0xF5, 0xA6, 0x23)
        else -> android.graphics.Color.rgb(0x2E, 0x6F, 0xE0)
    }

    val logoTextPaint = android.graphics.Paint().apply { textSize = 9f; isFakeBoldText = true; color = android.graphics.Color.WHITE; textAlign = android.graphics.Paint.Align.CENTER }
    val companyNamePaint = android.graphics.Paint().apply { textSize = 15f; isFakeBoldText = true; color = navy }
    val taglinePaint = android.graphics.Paint().apply { textSize = 8f; color = gray }
    val docTitlePaint = android.graphics.Paint().apply { textSize = 17f; isFakeBoldText = true; color = orange; textAlign = android.graphics.Paint.Align.RIGHT }
    val labelPaint = android.graphics.Paint().apply { textSize = 8f; isFakeBoldText = true; color = gray }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f; color = navy }
    val boldBodyPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true; color = navy }
    val headerTextPaint = android.graphics.Paint().apply { textSize = 9.5f; isFakeBoldText = true; color = android.graphics.Color.WHITE }
    val footerPaint = android.graphics.Paint().apply { textSize = 9f; color = gray }
    val italicFooterPaint = android.graphics.Paint().apply { textSize = 9f; color = gray; textSkewX = -0.2f; textAlign = android.graphics.Paint.Align.RIGHT }
    val fillPaint = android.graphics.Paint()
    val linePaint = android.graphics.Paint().apply { color = borderGray; strokeWidth = 1f }
    val ruleDarkPaint = android.graphics.Paint().apply { color = navy; strokeWidth = 1.2f }
    val cellBorderPaint = android.graphics.Paint().apply { color = borderGray; strokeWidth = 0.7f; style = android.graphics.Paint.Style.STROKE }

    val left = 40f
    val right = 555f
    val width = right - left

    // ---- masthead ----
    val company = com.abm.erp.data.MockRepository.companySettings()
    fillPaint.color = orange
    canvas.drawRoundRect(android.graphics.RectF(left, 30f, left + 32f, 62f), 5f, 5f, fillPaint)
    canvas.drawText("ABM", left + 16f, 50f, logoTextPaint)
    canvas.drawText(company.companyName.ifBlank { "ABM Corporation" }, left + 42f, 46f, companyNamePaint)
    canvas.drawText(
        listOfNotNull(company.companyAddress.ifBlank { null }, company.companyPhone.ifBlank { null })
            .joinToString(" · ").ifBlank { "Enterprise. Control. Growth." },
        left + 42f, 58f, taglinePaint,
    )
    canvas.drawText("MEMO", right, 48f, docTitlePaint)
    canvas.drawRect(left, 72f, right, 74.5f, fillPaint)
    linePaint.color = android.graphics.Color.rgb(0xFF, 0xD9, 0xC4)
    canvas.drawRect(left, 74.5f, right, 76f, linePaint)
    linePaint.color = borderGray

    // ---- meta box: Memo No / Date (left) + QR (right) ----
    var y = 90f
    canvas.drawRect(android.graphics.RectF(left, y, right, y + 90f), cellBorderPaint)
    canvas.drawLine(right - 74f, y, right - 74f, y + 90f, linePaint)
    canvas.drawText("MEMO NO", left + 12f, y + 20f, labelPaint)
    canvas.drawText(order.orderNo, left + 12f, y + 36f, boldBodyPaint)
    canvas.drawText("DATE", left + 12f, y + 58f, labelPaint)
    canvas.drawText(order.loggedAt.toLocalDate().toString(), left + 12f, y + 74f, bodyPaint)
    // v113-211 — QR isolated in its own try/catch, same reasoning as the invoice.
    if (qrPayload != null) {
        try {
            val qrBitmap = com.abm.erp.util.QrCodeGenerator.generate(qrPayload, 200)
            canvas.drawBitmap(qrBitmap, null, android.graphics.RectF(right - 64f, y + 10f, right - 10f, y + 64f), null)
            val centerPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; textSize = 7.5f }
            canvas.drawText("Scan to verify", right - 37f, y + 78f, centerPaint)
        } catch (e: Exception) {
            com.abm.erp.config.AppLog.w("StructuredExports", "QR generation failed for memo PDF", e)
            val centerPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; textSize = 7.5f }
            canvas.drawText("QR could not", right - 37f, y + 40f, centerPaint)
            canvas.drawText("be generated", right - 37f, y + 52f, centerPaint)
        }
    } else {
        val centerPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; textSize = 7.5f }
        canvas.drawText("QR not issued", right - 37f, y + 46f, centerPaint)
    }
    y += 100f

    // ---- Retailer — orange bar + bordered box ----
    val loggedByName = com.abm.erp.data.MockRepository.demoAccounts.values
        .firstOrNull { it.id == order.loggedBySoId }?.name ?: order.loggedBySoId
    fillPaint.color = orange
    canvas.drawRect(left, y, right, y + 20f, fillPaint)
    canvas.drawText("RETAILER", left + 10f, y + 14f, headerTextPaint)
    y += 20f
    canvas.drawRect(android.graphics.RectF(left, y, right, y + 56f), cellBorderPaint)
    canvas.drawLine(left + width / 2, y, left + width / 2, y + 56f, linePaint)
    canvas.drawText(order.retailerName, left + 12f, y + 20f, boldBodyPaint)
    canvas.drawText(order.zone, left + 12f, y + 36f, footerPaint)
    canvas.drawText("LOGGED BY", left + width / 2 + 12f, y + 18f, labelPaint)
    canvas.drawText(loggedByName, left + width / 2 + 12f, y + 34f, boldBodyPaint)
    canvas.drawText(if (order.channel == "wholesale") "Wholesale" else "Retail", left + width / 2 + 12f, y + 48f, footerPaint)
    y += 70f

    // ---- item table (or free-text summary for pre-v71 memos) ----
    if (order.lineItems.isNotEmpty()) {
        val colX = floatArrayOf(left, left + 34f, left + 310f, left + 380f, left + 460f, right)
        fillPaint.color = orange
        canvas.drawRect(left, y, right, y + 22f, fillPaint)
        canvas.drawText("#", colX[0] + 8f, y + 15f, headerTextPaint)
        canvas.drawText("Item / Product", colX[1] + 8f, y + 15f, headerTextPaint)
        canvas.drawText("Qty", colX[2] + 8f, y + 15f, headerTextPaint)
        canvas.drawText("Rate", colX[3] + 8f, y + 15f, headerTextPaint)
        canvas.drawText("Amount", colX[4] + 8f, y + 15f, headerTextPaint)
        y += 22f
        order.lineItems.forEachIndexed { idx, item ->
            if (y > 700f) return@forEachIndexed
            val rowH = 24f
            if (idx % 2 == 1) { fillPaint.color = lightGray; canvas.drawRect(left, y, right, y + rowH, fillPaint) }
            canvas.drawText("%02d".format(idx + 1), colX[0] + 8f, y + 16f, bodyPaint)
            canvas.drawText(item.name.take(30), colX[1] + 8f, y + 16f, bodyPaint)
            canvas.drawText("${item.qty}", colX[2] + 8f, y + 16f, bodyPaint)
            canvas.drawText("৳${"%.0f".format(item.unitPrice)}", colX[3] + 8f, y + 16f, bodyPaint)
            canvas.drawText("৳${"%.0f".format(item.lineTotal)}", colX[4] + 8f, y + 16f, boldBodyPaint)
            for (i in 0..5) canvas.drawLine(colX[i], y, colX[i], y + rowH, cellBorderPaint)
            canvas.drawLine(left, y + rowH, right, y + rowH, cellBorderPaint)
            y += rowH
        }
        canvas.drawLine(left, y, right, y, cellBorderPaint)
        y += 16f
    } else {
        canvas.drawText("ITEMS", left, y, labelPaint)
        canvas.drawText(order.items.ifBlank { "—" }.take(80), left, y + 16f, bodyPaint)
        y += 40f
    }

    // ---- total — plain, ledger rule, no discount/subtotal (a memo carries neither) ----
    val totalsX = right - 200f
    canvas.drawLine(totalsX, y, right, y, ruleDarkPaint)
    y += 3f
    canvas.drawLine(totalsX, y, right, y, ruleDarkPaint)
    y += 20f
    canvas.drawText("TOTAL", totalsX, y, android.graphics.Paint(boldBodyPaint).apply { textSize = 12f })
    canvas.drawText(
        "৳${"%,.0f".format(order.amount)}", right, y,
        android.graphics.Paint().apply { textSize = 19f; isFakeBoldText = true; color = orange; textAlign = android.graphics.Paint.Align.RIGHT },
    )
    y += 24f

    // ---- In Words — same amountInWords() the on-screen memo already uses ----
    canvas.drawText("In Words: ${com.abm.erp.core.amountInWords(order.amount)}", right, y, italicFooterPaint)
    y += 30f

    // ---- Retailer's standing due — explicitly independent, not "previous+this+total" ----
    val retailer = com.abm.erp.data.MockRepository.retailers.value.firstOrNull { it.id == order.retailerId }
    if (retailer != null) {
        fillPaint.color = lightGray
        canvas.drawRoundRect(android.graphics.RectF(left, y, left + 340f, y + 42f), 4f, 4f, fillPaint)
        canvas.drawText("Retailer's Current Due", left + 12f, y + 18f, footerPaint)
        canvas.drawText("৳${"%,.0f".format(retailer.dueBalance)}", left + 220f, y + 18f, boldBodyPaint)
        canvas.drawText("* Independent of this memo — billing happens at Dealer level.", left + 12f, y + 34f, footerPaint)
        y += 58f
    }

    // ---- Stage badge ----
    val statusFillPaint = android.graphics.Paint().apply { color = statusColor }
    canvas.drawRoundRect(android.graphics.RectF(left, y, left + 130f, y + 22f), 11f, 11f, statusFillPaint)
    val statusTextPaint = android.graphics.Paint().apply { textSize = 9.5f; isFakeBoldText = true; color = android.graphics.Color.WHITE; textAlign = android.graphics.Paint.Align.CENTER }
    canvas.drawText(order.stage.name, left + 65f, y + 15f, statusTextPaint)
    y += 50f

    // ---- Signature area — the real SO → ASM → Retailer chain, not Invoice's Prepared/Checked/Authorized ----
    canvas.drawLine(left, y, left + 150f, y, linePaint)
    canvas.drawLine(left + 190f, y, left + 340f, y, linePaint)
    canvas.drawLine(left + 380f, y, right, y, linePaint)
    y += 14f
    canvas.drawText("Logged By ($loggedByName)", left, y, footerPaint)
    canvas.drawText("Verified By (ASM)", left + 190f, y, footerPaint)
    canvas.drawText("Retailer Signature", left + 380f, y, footerPaint)
    y += 26f

    val centerFooterPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; isFakeBoldText = true }
    canvas.drawText("Thank you for your business!", left + width / 2, y, centerFooterPaint)

    canvas.drawText("Generated ${java.time.LocalDateTime.now()} — ${company.companyName.ifBlank { "ABM ERP" }}", left, 815f, footerPaint)

    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "memo_${order.orderNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/** Shared FileProvider-share step for every structured PDF below — one place to get the MIME type/authority/error-safety right instead of repeating it at each call site. */
fun shareStructuredPdf(context: Context, file: File, label: String) {
    val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(android.content.Intent.createChooser(intent, label))
}

/**
 * v113-129 — "Export List (Excel/CSV)" for the browse-list's real "More Actions"
 * panel. Reuses the exact CSV field-escaping already proven correct in
 * UniversalActionMenu.kt (`escapeCsvField`/`toCsvRow`) and the exact same real
 * FileProvider mechanism `shareStructuredPdf` above already uses for PDFs — a new
 * file format through an already-working share pipeline, not an untested one.
 * `columns` is (header label, per-record value) so every module's existing
 * `infoRows` field list can feed this directly with no per-entity special-casing.
 */
fun <T> exportListAsCsv(context: Context, entityLabel: String, records: List<T>, columns: List<Pair<String, (T) -> String>>): File {
    val header = columns.joinToString(",") { escapeCsvField(it.first) }
    val rows = records.joinToString("\n") { r -> columns.joinToString(",") { escapeCsvField(it.second(r)) } }
    val file = File(context.getExternalFilesDir(null), "${entityLabel}_list_${System.currentTimeMillis()}.csv")
    file.writeText("$header\n$rows")
    return file
}

/** Same real FileProvider share step as shareStructuredPdf, for the CSV file exportListAsCsv just wrote — one real, working mechanism for both file types rather than a second untested one. */
fun shareStructuredCsv(context: Context, file: File, label: String) {
    val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "text/csv"
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(android.content.Intent.createChooser(intent, label))
}

/**
 * v113-129 — "Print List" for the browse-list's More Actions panel. A real,
 * simple multi-page list PDF (code · name · detail · status per row), built with
 * the same raw android.graphics.pdf.PdfDocument API every other export in this
 * file already uses — paginates for real once a page fills, rather than silently
 * dropping rows past the first page.
 */
fun <T> exportBrowseListPdf(
    context: Context, entityLabel: String, records: List<T>,
    codeOf: (T) -> String, titleOf: (T) -> String, subtitleOf: (T) -> String, isActiveOf: (T) -> Boolean,
): File {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    val pageWidth = 595; val pageHeight = 842 // A4 at 72dpi
    val titlePaint = android.graphics.Paint().apply { textSize = 16f; isFakeBoldText = true }
    val rowPaint = android.graphics.Paint().apply { textSize = 10f }
    val rowsPerPage = 45
    var pageNum = 1
    var rowIndex = 0
    val chunks = records.chunked(rowsPerPage)
    if (chunks.isEmpty()) {
        val page = pdfDocument.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create())
        page.canvas.drawText("$entityLabel List — কোনো রেকর্ড নেই", 40f, 60f, titlePaint)
        pdfDocument.finishPage(page)
    }
    for (chunk in chunks) {
        val page = pdfDocument.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        val canvas = page.canvas
        canvas.drawText("$entityLabel List (${records.size}) — page $pageNum/${chunks.size}", 40f, 40f, titlePaint)
        var y = 70f
        for (r in chunk) {
            canvas.drawText("${codeOf(r)} · ${titleOf(r)} — ${subtitleOf(r)} [${if (isActiveOf(r)) "Active" else "Inactive"}]", 40f, y, rowPaint)
            y += 16f
            rowIndex++
        }
        canvas.drawText("Generated ${java.time.LocalDateTime.now()} — ABM ERP", 40f, 815f, rowPaint)
        pdfDocument.finishPage(page)
        pageNum++
    }
    val file = File(context.getExternalFilesDir(null), "${entityLabel}_list_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/**
 * v113-129 — hands an already-written PDF file to Android's real print
 * subsystem (android.print.PrintManager), so "Print" opens the device's actual
 * print dialog (any installed printer app, PDF-to-file, etc.) instead of only
 * ever being a share-sheet in disguise. PrintDocumentAdapter here wraps a file
 * that's already fully rendered, so onWrite just streams it — no re-rendering.
 */
fun printPdfFile(context: Context, file: File, jobName: String) {
    val printManager = context.getSystemService(Context.PRINT_SERVICE) as android.print.PrintManager
    val adapter = object : android.print.PrintDocumentAdapter() {
        override fun onLayout(oldAttributes: android.print.PrintAttributes?, newAttributes: android.print.PrintAttributes, cancellationSignal: android.os.CancellationSignal?, callback: LayoutResultCallback, extras: android.os.Bundle?) {
            if (cancellationSignal?.isCanceled == true) { callback.onLayoutCancelled(); return }
            val info = android.print.PrintDocumentInfo.Builder(file.name).setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build()
            callback.onLayoutFinished(info, true)
        }
        override fun onWrite(pages: Array<out android.print.PageRange>?, destination: android.os.ParcelFileDescriptor, cancellationSignal: android.os.CancellationSignal?, callback: WriteResultCallback) {
            try {
                java.io.FileInputStream(file).use { input -> java.io.FileOutputStream(destination.fileDescriptor).use { output -> input.copyTo(output) } }
                callback.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
            } catch (e: Exception) {
                callback.onWriteFailed(e.message)
            }
        }
    }
    printManager.print(jobName, adapter, android.print.PrintAttributes.Builder().build())
}

/** Shared PDF-page bootstrap (company header + document title) reused by every structured template below, so each function only draws its own body content. */
private fun newInvoiceStylePage(title: String): Triple<android.graphics.pdf.PdfDocument, android.graphics.pdf.PdfDocument.Page, Float> {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas
    val headerPaint = android.graphics.Paint().apply { textSize = 20f; isFakeBoldText = true }
    val subHeaderPaint = android.graphics.Paint().apply { textSize = 12f; color = android.graphics.Color.DKGRAY }
    canvas.drawText("Mohona ERP", 40f, 45f, headerPaint)
    canvas.drawText(title, 40f, 67f, subHeaderPaint)
    return Triple(pdfDocument, page, 97f)
}

/**
 * Dealer Statement — Dealer profile + real PartyLedgerEntry history. Uses
 * MockRepository.partyLedgerFor's already-loaded Flow value at call time
 * (passed in as a plain List so this stays a non-suspend, non-Compose
 * function callable from anywhere).
 */
fun exportDealerStatementPdf(context: Context, dealer: com.abm.erp.data.Dealer, ledger: List<com.abm.erp.data.PartyLedgerEntry>): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("DEALER STATEMENT")
    val canvas = page.canvas
    val labelPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Dealer: ${dealer.name}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Zone: ${dealer.zone}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Classification: ${dealer.classification}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Current Due: ৳${"%.2f".format(dealer.dueBalance)}", 40f, y, totalPaint); y += 28f

    canvas.drawText("Date", 40f, y, labelPaint)
    canvas.drawText("Reason", 140f, y, labelPaint)
    canvas.drawText("Type", 380f, y, labelPaint)
    canvas.drawText("Amount", 460f, y, labelPaint)
    y += 6f
    canvas.drawLine(40f, y, 555f, y, bodyPaint)
    y += 16f
    if (ledger.isEmpty()) {
        canvas.drawText("Data unavailable — no ledger entries recorded yet.", 40f, y, bodyPaint)
    } else {
        ledger.forEach { entry ->
            if (y > 780f) return@forEach
            canvas.drawText("${entry.createdAt.toLocalDate()}", 40f, y, bodyPaint)
            canvas.drawText(entry.reason.take(30), 140f, y, bodyPaint)
            canvas.drawText(entry.type, 380f, y, bodyPaint)
            canvas.drawText("৳${"%.2f".format(entry.amount)}", 460f, y, bodyPaint)
            y += 16f
        }
    }
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "dealer_statement_${dealer.name.take(12)}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

fun exportPurchaseOrderPdf(context: Context, po: com.abm.erp.data.PurchaseOrder): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("PURCHASE ORDER")
    val canvas = page.canvas
    val labelPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("PO No: ${po.poNo}", 40f, y, bodyPaint)
    canvas.drawText("Date: ${po.createdAt.toLocalDate()}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Supplier: ${po.supplierName}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Status: ${po.status}", 40f, y, bodyPaint); y += 28f

    canvas.drawText("Item", 40f, y, labelPaint)
    canvas.drawText("Qty", 300f, y, labelPaint)
    canvas.drawText("Unit Cost", 370f, y, labelPaint)
    canvas.drawText("Amount", 480f, y, labelPaint)
    y += 6f
    canvas.drawLine(40f, y, 555f, y, bodyPaint)
    y += 16f
    po.lineItems.forEach { item ->
        if (y > 760f) return@forEach
        canvas.drawText(item.name.take(30), 40f, y, bodyPaint)
        canvas.drawText("${item.qty}", 300f, y, bodyPaint)
        canvas.drawText("৳${"%.2f".format(item.unitCost)}", 370f, y, bodyPaint)
        canvas.drawText("৳${"%.2f".format(item.lineTotal)}", 480f, y, bodyPaint)
        y += 18f
    }
    y += 12f
    canvas.drawLine(350f, y, 555f, y, bodyPaint)
    y += 22f
    canvas.drawText("Total:", 400f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(po.subTotal)}", 480f, y, totalPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "purchase_order_${po.poNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/** Production Sheet — ProductionOrder has no line-item breakdown in the current data model (BOM is a separate lookup by bomId this function doesn't join against), so this stays a header-level sheet rather than fabricating a materials table. */
fun exportProductionOrderPdf(context: Context, order: com.abm.erp.data.ProductionOrder): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("PRODUCTION SHEET")
    val canvas = page.canvas
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Order No: ${order.orderNo}", 40f, y, bodyPaint)
    canvas.drawText("Scheduled: ${order.scheduledDate.toLocalDate()}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Finished Product: ${order.finishedProductName}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Target Quantity: ${order.targetQty}", 40f, y, totalPaint); y += 22f
    canvas.drawText("Status: ${order.status}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Created by: ${order.createdBy.ifBlank { "Data unavailable" }}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("BOM Reference: ${order.bomId}", 40f, y, bodyPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "production_sheet_${order.orderNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

fun exportVoucherPdf(context: Context, voucher: com.abm.erp.data.Voucher): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("${voucher.type} VOUCHER")
    val canvas = page.canvas
    val labelPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Voucher No: ${voucher.voucherNo}", 40f, y, bodyPaint)
    canvas.drawText("Date: ${voucher.voucherDate.toLocalDate()}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Narration: ${voucher.narration.ifBlank { "Data unavailable" }}", 40f, y, bodyPaint); y += 28f

    canvas.drawText("Account", 40f, y, labelPaint)
    canvas.drawText("Debit", 350f, y, labelPaint)
    canvas.drawText("Credit", 460f, y, labelPaint)
    y += 6f
    canvas.drawLine(40f, y, 555f, y, bodyPaint)
    y += 16f
    voucher.lines.forEach { line ->
        if (y > 780f) return@forEach
        canvas.drawText(line.accountName.take(35), 40f, y, bodyPaint)
        canvas.drawText(if (line.debit > 0) "৳${"%.2f".format(line.debit)}" else "-", 350f, y, bodyPaint)
        canvas.drawText(if (line.credit > 0) "৳${"%.2f".format(line.credit)}" else "-", 460f, y, bodyPaint)
        y += 16f
    }
    y += 12f
    canvas.drawLine(300f, y, 555f, y, bodyPaint)
    y += 22f
    canvas.drawText("Total:", 250f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(voucher.totalDebit)}", 350f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(voucher.totalCredit)}", 460f, y, totalPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "voucher_${voucher.voucherNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/** Payslip — PayrollLine has no employee address/designation/period fields in the current model, so those are shown as "Data unavailable" rather than fabricated; every number shown (base pay, achievement%, commission, absence penalty, net payable) is a real stored/derived field. */
fun exportPayslipPdf(context: Context, line: com.abm.erp.data.PayrollLine): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("PAYSLIP")
    val canvas = page.canvas
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Employee: ${line.employeeName}", 40f, y, bodyPaint)
    canvas.drawText("ID: ${line.employeeId}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Pay Period: Data unavailable (not tracked per-line yet)", 40f, y, bodyPaint); y += 28f

    canvas.drawText("Base Pay:", 40f, y, bodyPaint)
    canvas.drawText("৳${"%.2f".format(line.basePay)}", 300f, y, bodyPaint); y += 18f
    canvas.drawText("Target vs Achieved:", 40f, y, bodyPaint)
    canvas.drawText("৳${"%.2f".format(line.targetAmount)} / ৳${"%.2f".format(line.achievedAmount)} (${"%.0f".format(line.achievementPct)}%)", 300f, y, bodyPaint); y += 18f
    canvas.drawText("Commission:", 40f, y, bodyPaint)
    canvas.drawText("৳${"%.2f".format(line.commission)}", 300f, y, bodyPaint); y += 18f
    canvas.drawText("Unapproved Absence Days:", 40f, y, bodyPaint)
    canvas.drawText("${line.unapprovedAbsenceDays} (−৳${"%.2f".format(line.absencePenalty)})", 300f, y, bodyPaint); y += 24f
    canvas.drawLine(40f, y, 555f, y, bodyPaint); y += 20f
    canvas.drawText("Net Payable:", 40f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(line.netPayable)}", 300f, y, totalPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "payslip_${line.employeeId}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}
