package com.abm.erp.ui.sales

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.*
import com.abm.erp.data.EMPLOYEE_DIRECTORY
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.MockRepository
import com.abm.erp.data.OrderStage
import com.abm.erp.data.PermissionAction
import com.abm.erp.data.PermissionManager
import com.abm.erp.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Draft state for the new-order dual-control form: fields the AI agent can pre-fill, human can overwrite. */
data class NewOrderDraft(
    val retailerName: DualControlValue<String> = DualControlValue(""),
    val items: DualControlValue<String> = DualControlValue(""),
    val amount: DualControlValue<String> = DualControlValue(""),
)

class SalesChainViewModel : ViewModel() {
    private val _draft = MutableStateFlow(NewOrderDraft())
    val draft: StateFlow<NewOrderDraft> = _draft.asStateFlow()

    private val _lastAgentAction = MutableStateFlow<String?>(
        "Pre-filled order for \"Green Valley Store\" from field SO voice note."
    )
    val lastAgentAction: StateFlow<String?> = _lastAgentAction.asStateFlow()

    // গ্রাউন্ড-লেভেল ডাটা কালেকশন: দোকানের ছবি + GPS ট্যাগ, submit-এর আগে ধরে রাখা।
    private val _photoUri = MutableStateFlow<android.net.Uri?>(null)
    val photoUri: StateFlow<android.net.Uri?> = _photoUri.asStateFlow()
    private val _gpsTag = MutableStateFlow<Pair<Double, Double>?>(null)
    val gpsTag: StateFlow<Pair<Double, Double>?> = _gpsTag.asStateFlow()

    fun setPhoto(uri: android.net.Uri?) { _photoUri.value = uri }
    fun setGps(lat: Double, lng: Double) { _gpsTag.value = lat to lng }

    fun updateRetailer(v: String) = _draft.update { it.copy(retailerName = DualControlValue(v, FieldSource.HUMAN)) }
    fun updateItems(v: String) = _draft.update { it.copy(items = DualControlValue(v, FieldSource.HUMAN)) }
    fun updateAmount(v: String) = _draft.update { it.copy(amount = DualControlValue(v, FieldSource.HUMAN)) }

    // ---- Cart (v113-59) — structured lines for the memo-style order page. ----
    // Empty by default, and when it IS empty submitOrder behaves exactly as it always has,
    // so the original free-text order entry keeps working untouched.
    private val _cart = MutableStateFlow<List<com.abm.erp.data.SalesInvoiceLineItem>>(emptyList())
    val cart: StateFlow<List<com.abm.erp.data.SalesInvoiceLineItem>> = _cart.asStateFlow()

    fun addToCart(line: com.abm.erp.data.SalesInvoiceLineItem) {
        _cart.update { current ->
            // Same product twice adds quantity rather than creating a duplicate row —
            // otherwise a memo shows the same item on two lines and the shopkeeper queries it.
            val existing = current.firstOrNull { it.productId == line.productId }
            if (existing == null) current + line
            else current.map { if (it.productId == line.productId) it.copy(qty = it.qty + line.qty) else it }
        }
    }

    fun updateCartQty(productId: String, qty: Int) {
        _cart.update { current ->
            if (qty <= 0) current.filterNot { it.productId == productId }
            else current.map { if (it.productId == productId) it.copy(qty = qty) else it }
        }
    }

    fun removeFromCart(productId: String) {
        _cart.update { current -> current.filterNot { it.productId == productId } }
    }

    fun clearCart() { _cart.value = emptyList() }

    val cartTotal: Double get() = _cart.value.sumOf { it.lineTotal }

    /** Human summary written to the legacy `items` field so existing consumers keep working. */
    private fun cartSummary(): String =
        _cart.value.joinToString(", ") { "${it.name} x${it.qty}" }

    fun submitOrder(context: android.content.Context, zone: String, anonymous: Boolean = false, photoPurpose: String? = null, onRejected: (String) -> Unit = {}) {
        val d = _draft.value
        if (!anonymous && d.retailerName.value.isBlank()) return

        // When the cart has lines, they are the source of truth for both the summary string
        // and the amount — so the memo total can never disagree with the lines printed on it.
        // With an empty cart nothing changes: the typed text and typed amount are used exactly
        // as before.
        val lines = _cart.value
        val itemsText = if (lines.isEmpty()) d.items.value else cartSummary()
        val amountValue = if (lines.isEmpty()) (d.amount.value.toDoubleOrNull() ?: 0.0) else cartTotal
        // v113-228 — was passing the raw local photoUri (a content:// uri)
        // straight into logNewOrder, which would only ever load on the
        // device that took it — the exact same anti-pattern already fixed
        // once for product photos this session, found here the same way:
        // checking uploadOrderPhoto's own zero call sites led straight to
        // this. Now: create the order first (photoUri = null), then
        // upload the local photo through the real Storage path and let it
        // self-attach via the new onCreated id, matching the established
        // create-then-upload pattern used everywhere else in this app.
        val localPhotoUri = if (anonymous) null else _photoUri.value
        // v113-240 — this whole retailer field was a free-text name with
        // suggestions drawn from past ORDER names, not real Retailer
        // records — retailerId was never resolved here at all, which is
        // exactly why canRetailerOrder's own real credit-hold/status/
        // credit-limit check (just wired into logNewOrder itself) could
        // never actually have fired for this, the main daily field-sales
        // flow. Deliberately not rebuilding the suggestion UI itself —
        // real regression risk on this app's highest-traffic screen for
        // a change with a smaller, safer form: resolve a real retailerId
        // by an exact, unambiguous name match at the moment of
        // submission, so the credit check can actually run whenever the
        // typed name matches one real retailer — same silent pass-through
        // as today (retailerId stays null) whenever it doesn't.
        val matchedRetailerId = if (anonymous) null else {
            com.abm.erp.data.MockRepository.retailers.value
                .filter { !it.isDeleted && it.name.equals(d.retailerName.value.trim(), ignoreCase = true) }
                .singleOrNull()?.id
        }

        val ok = MockRepository.logNewOrder(
            if (anonymous) "Anonymous sale" else d.retailerName.value, itemsText, amountValue, zone,
            photoUri = null, lat = if (anonymous) null else _gpsTag.value?.first, lng = if (anonymous) null else _gpsTag.value?.second,
            anonymous = anonymous, photoPurpose = photoPurpose,
            lineItems = lines,
            retailerId = matchedRetailerId,
            onRejected = onRejected,
            onCreated = { newOrderId ->
                if (localPhotoUri != null) {
                    MockRepository.uploadOrderPhoto(context, newOrderId, localPhotoUri.toString()) { }
                }
                // v113-243 — linkVisitToOrder already existed, fully real
                // (ties an order to whatever active check-in visit the SR
                // is currently on, feeding real fraud/suspicious-location
                // detection for orders taken outside a visit's own
                // verified radius), zero callers. A harmless no-op
                // whenever there's no active visit (the function's own
                // first line returns false if none exists) — real
                // whenever one does.
                viewModelScope.launch { MockRepository.linkVisitToOrder(newOrderId) }
            },
        )
        // v113-240 — was resetting the draft unconditionally, regardless of
        // whether logNewOrder actually succeeded. With canRetailerOrder's
        // check now able to genuinely reject an order (credit hold, over
        // limit, not yet approved), silently clearing the form on a
        // rejection would have shown the SR a "successful-looking" blank
        // form for an order that was never actually created — worse than
        // no feedback at all. Only resets on a real, confirmed success.
        if (!ok) return
        _draft.value = NewOrderDraft()
        _cart.value = emptyList()
        _photoUri.value = null
        _gpsTag.value = null
        _lastAgentAction.value = null
    }

    // ---- Invoice-module permission enforcement (PermissionManager example) ----
    val currentUser get() = MockRepository.currentUser
    fun canApproveInvoice() = PermissionManager.can(currentUser.role, "bill", PermissionAction.APPROVE)
    fun canDeleteInvoice() = PermissionManager.can(currentUser.role, "bill", PermissionAction.DELETE)
    fun approveInvoice(invoiceId: String, onRejected: (String) -> Unit = {}) = MockRepository.approveSalesInvoice(invoiceId, onRejected)
    fun deleteInvoice(invoiceId: String, onRejected: (String) -> Unit = {}) = MockRepository.deleteSalesInvoice(invoiceId, onRejected)
    suspend fun restoreInvoice(invoiceId: String) = MockRepository.restoreSalesInvoice(invoiceId)
}

@Composable
fun SalesChainScreen(startTab: Int? = null, onBack: () -> Unit = {}, onNavigate: (String) -> Unit = {}, vm: SalesChainViewModel = viewModel()) {
    val orders by MockRepository.orders.collectAsState()
    // Decision 4 (v113-73) — was the raw unscoped list. This `dealers` is what the old
    // DealerInvoiceTab's dealer chooser renders, so an SR could invoice outside his
    // territory from here too. Now routed through the single cascade accessor.
    val dealers = com.abm.erp.core.rememberVisibleDealers()
    val draft by vm.draft.collectAsState()
    val lastAgentAction by vm.lastAgentAction.collectAsState()
    var tab by remember { mutableStateOf<Int?>(startTab) }

    // ---- Mini-dashboard data (Enterprise Workspace redesign) ----
    val invoicesForMini by MockRepository.salesInvoices.collectAsState()
    val collectionsForMini by MockRepository.partyCollections.collectAsState()
    val retailersForMini by MockRepository.retailers.collectAsState()
    val visitsForMini by MockRepository.visitLogs.collectAsState()
    val today = java.time.LocalDate.now()
    val todaySales = invoicesForMini.filter { !it.isDeleted && it.createdAt.toLocalDate() == today }.sumOf { it.total }
    val todayCollection = collectionsForMini.filter { it.createdAt.toLocalDate() == today }.sumOf { it.amount }
    val totalDue = dealers.sumOf { it.dueBalance } + retailersForMini.sumOf { it.dueBalance }
    val todayVisits = visitsForMini.filter { it.checkInAt.toLocalDate() == today }
    val retailersCovered = todayVisits.filter { it.partyType == com.abm.erp.data.PartyType.RETAILER }.map { it.partyId }.distinct().size

    val subItems = buildList {
        add(SubModuleItem("retailer", "Retailer", "🏪", 0xFFFF7A45, 0xFFE0521E, Icons.Filled.Store))
        add(SubModuleItem("wholesale", "Wholesale", "📦", 0xFF4E9CFF, 0xFF2E6FE0, Icons.Filled.Inventory2))
        if (MockRepository.canInvoice(MockRepository.currentUser.role)) {
            add(SubModuleItem("dealerInvoice", "Dealer Invoice", "🧾", 0xFFB45CFF, 0xFF7A2EE0, Icons.Filled.ReceiptLong))
            add(SubModuleItem("salesOrder", "Sales Order", "📃", 0xFF6EC6FF, 0xFF2E8FE0, Icons.Filled.Description))
        }
        add(SubModuleItem("verify", "Verify Orders", "✅", 0xFF3DDC97, 0xFF1FA972, Icons.Filled.FactCheck))
    }

    Column(Modifier.fillMaxSize()) {
        if (startTab == null) {
        com.abm.erp.core.ModuleWorkspaceHeader("Sales / CRM Workspace", "📈", 0xFF2563EB, 0xFF1E3A8A, iconVector = Icons.Filled.TrendingUp, miniDashboard = {
            com.abm.erp.core.ModuleStat("Today's Sales", "৳${"%,.0f".format(todaySales)}", ElectricCyan)
            com.abm.erp.core.ModuleStat("Collection", "৳${"%,.0f".format(todayCollection)}", SuccessGreen)
            com.abm.erp.core.ModuleStat("Due", "৳${"%,.0f".format(totalDue)}", if (totalDue > 0) WarningAmber else SuccessGreen)
            com.abm.erp.core.ModuleStat("Visits", "${todayVisits.size}", TextPrimary)
            com.abm.erp.core.ModuleStat("Retailers Covered", "$retailersCovered", TextPrimary)
        }, quickActions = {
            AssistChip(onClick = { tab = 0 }, label = { Text("+ New Order") })
            if (MockRepository.canInvoice(MockRepository.currentUser.role)) {
                AssistChip(onClick = { tab = 2 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.ReceiptLong, null, Modifier.size(16.dp)) }, label = { Text("Invoice") })
            }
            AssistChip(onClick = { onNavigate("dealers") }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.Payments, null, Modifier.size(16.dp)) }, label = { Text("Collection") })
            AssistChip(onClick = { tab = 0 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.LocationOn, null, Modifier.size(16.dp)) }, label = { Text("Retailer Visit") })
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("SalesInvoice", "RetailOrder", "PartyCollection", "SalesOrder"))
        })
        } else {
            // Blueprint fix — arrived via a Suite's specific function, so this shows only the
            // task's own header (with a real back arrow) instead of the whole module's
            // dashboard. See TaskHeader's doc comment for the full reasoning.
            val taskTitle = when (tab) { 0 -> "Retailer Order"; 1 -> "Wholesale Order"; 2 -> "Dealer Invoice"; 4 -> "Sales Order"; else -> "Verify Orders" }
            com.abm.erp.core.TaskHeader(taskTitle, 0xFF2563EB, 0xFF1E3A8A, onBack = onBack, iconVector = Icons.Filled.TrendingUp)
        }
        Column(Modifier.fillMaxSize().padding(16.dp)) {

        if (tab == null) {
            SubModuleGrid(subItems) { key ->
                tab = when (key) { "retailer" -> 0; "wholesale" -> 1; "dealerInvoice" -> 2; "salesOrder" -> 4; else -> 3 }
            }
        } else {
            if (startTab == null) BackToSubMenuLink(onClick = { tab = null })
            when (tab) {
                0 -> RetailerTab(vm, draft, lastAgentAction, orders)
                1 -> WholesaleTab(orders)
                2 -> if (MockRepository.canInvoice(MockRepository.currentUser.role)) DealerInvoiceTab(dealers, vm, onNavigate) else Text("এই ফিচারটা আপনার পদের জন্য না।", color = TextSecondary)
                4 -> if (MockRepository.canInvoice(MockRepository.currentUser.role)) SalesOrderTab(dealers) else Text("এই ফিচারটা আপনার পদের জন্য না।", color = TextSecondary)
                else -> AsmVerifyTab(orders, dealers)
            }
        }
        }
    }
}

@Composable
internal fun RetailerTab(vm: SalesChainViewModel, draft: NewOrderDraft, lastAgentAction: String?, orders: List<com.abm.erp.data.RetailOrder>) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val photoUri by vm.photoUri.collectAsState()
    val gpsTag by vm.gpsTag.collectAsState()
    var gpsError by remember { mutableStateOf<String?>(null) }
    var anonymous by remember { mutableStateOf(false) }
    var photoPurpose by remember { mutableStateOf("Shop photo") }
    var selectedVerified by remember { mutableStateOf(false) }
    var duplicateAlert by remember { mutableStateOf(false) }
    var confirmedDuplicate by remember { mutableStateOf(false) }

    val myDivision = EMPLOYEE_DIRECTORY.firstOrNull { it.id == MockRepository.currentUser.employeeId }?.geo?.division
    val knownRetailers = remember(orders, myDivision) {
        orders.filter { !it.anonymous && it.channel == "retail" }
            .distinctBy { it.retailerName }
            .map { it.retailerName }
            .take(25)
    }
    val suggestions = if (draft.retailerName.value.isBlank()) knownRetailers
        else knownRetailers.filter { it.contains(draft.retailerName.value, ignoreCase = true) }

    val photoLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent(),
    ) { uri -> vm.setPhoto(uri) }

    fun hasLocationPermission() = androidx.core.content.ContextCompat.checkSelfPermission(
        context, android.Manifest.permission.ACCESS_FINE_LOCATION,
    ) == android.content.pm.PackageManager.PERMISSION_GRANTED

    fun tagLocationNow() {
        val client = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(context)
        try {
            @Suppress("MissingPermission")
            client.lastLocation.addOnSuccessListener { loc ->
                if (loc != null) { vm.setGps(loc.latitude, loc.longitude); gpsError = null }
                else gpsError = "No recent GPS fix — move to an open area and try again."
            }.addOnFailureListener { gpsError = it.message ?: "Couldn't fetch location." }
        } catch (e: SecurityException) {
            gpsError = "Location permission needed."
        }
    }

    val locationPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
    ) { granted -> if (granted) tagLocationNow() else gpsError = "Location permission was denied." }

    Box(Modifier.fillMaxSize()) {
    com.abm.erp.core.NatureLandscapeBackground()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { AgentActivityBanner(lastAgentAction) { } }
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Log retail order", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = anonymous, onCheckedChange = { anonymous = it })
                    Text("Anonymous sale (shopkeeper declined details)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                if (!anonymous) {
                    DualControlTextField("Retailer name — search your area", draft.retailerName, vm::updateRetailer)
                    if (suggestions.isNotEmpty() && !selectedVerified) {
                        Column(Modifier.heightIn(max = 160.dp).verticalScroll(rememberScrollState())) {
                            suggestions.forEach { name ->
                                val theirOrders = orders.filter { it.retailerName == name }
                                val last = theirOrders.maxByOrNull { it.loggedAt }?.amount ?: 0.0
                                val prevAvg = theirOrders.sortedByDescending { it.loggedAt }.drop(1).take(2)
                                    .let { if (it.isEmpty()) 0.0 else it.sumOf { o -> o.amount } / it.size }
                                val growthPct = if (prevAvg > 0) ((last - prevAvg) / prevAvg * 100) else 0.0
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth().clickable { vm.updateRetailer(name); selectedVerified = true }.padding(vertical = 6.dp),
                                ) {
                                    Text(name, style = MaterialTheme.typography.bodySmall, color = TextPrimary, modifier = Modifier.weight(1f))
                                    GrowthRing(growthPct)
                                    Spacer(Modifier.width(6.dp))
                                    Text("৳${last.toInt()}", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                                }
                            }
                        }
                    }
                    if (selectedVerified) {
                        val theirTotal = orders.filter { it.retailerName == draft.retailerName.value }.sumOf { it.amount }
                        Text("✓ Verified shop — total value so far: ৳${"%,.0f".format(theirTotal)}", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                    }
                }
                Spacer(Modifier.height(10.dp))
                DualControlTextField("Items", draft.items, vm::updateItems)
                Spacer(Modifier.height(10.dp))
                DualControlTextField("Amount (৳)", draft.amount, vm::updateAmount)
                Spacer(Modifier.height(12.dp))

                if (!anonymous && !selectedVerified) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Shop photo", "Product damaged", "Other issue").forEach { tag ->
                            FilterChip(selected = photoPurpose == tag, onClick = { photoPurpose = tag }, label = { Text(tag, style = MaterialTheme.typography.labelSmall) })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { photoLauncher.launch("image/*") }, modifier = Modifier.weight(1f)) {
                            Text(if (photoUri != null) "📷 Photo added ✓" else "📷 Capture photo", style = MaterialTheme.typography.labelSmall)
                        }
                        OutlinedButton(
                            onClick = { if (hasLocationPermission()) tagLocationNow() else locationPermissionLauncher.launch(android.Manifest.permission.ACCESS_FINE_LOCATION) },
                            modifier = Modifier.weight(1f),
                        ) {
                            Text(gpsTag?.let { "📍 ${"%.3f".format(it.first)}, ${"%.3f".format(it.second)}" } ?: "📍 Tag location", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    gpsError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                }

                if (duplicateAlert) {
                    Surface(color = DangerRed.copy(alpha = 0.12f), shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        Column(Modifier.padding(10.dp)) {
                            Text("⚠ একই নামে অন্য একটা অবস্থানে আগেই এন্ট্রি আছে", color = DangerRed, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            Text("এটা duplicate entry হতে পারে, অথবা সত্যিই একই নামে ভিন্ন দোকান — নিশ্চিত করুন।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Spacer(Modifier.height(6.dp))
                            Button(onClick = { confirmedDuplicate = true; duplicateAlert = false }, colors = ButtonDefaults.buttonColors(containerColor = DangerRed)) {
                                Text("হ্যাঁ, ভিন্ন দোকান — চালিয়ে যান", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                var submitError by remember { mutableStateOf<String?>(null) }
                submitError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(bottom = 6.dp)) }
                ManualSubmitBar("Submit Order → notifies Area Manager") {
                    if (!anonymous && gpsTag != null) {
                        val priorDifferentLocation = orders.any { o ->
                            o.retailerName == draft.retailerName.value && o.retailerLat != null && o.retailerLng != null &&
                                (kotlin.math.abs(o.retailerLat - gpsTag!!.first) > 0.01 || kotlin.math.abs(o.retailerLng - gpsTag!!.second) > 0.01)
                        }
                        if (priorDifferentLocation && !confirmedDuplicate) {
                            duplicateAlert = true
                            return@ManualSubmitBar
                        }
                    }
                    submitError = null
                    vm.submitOrder(context, myDivision ?: "Barishal", anonymous = anonymous, photoPurpose = if (anonymous) null else photoPurpose, onRejected = { r -> submitError = r })
                    selectedVerified = false; duplicateAlert = false; confirmedDuplicate = false
                }
            }
        }
    }
    }
}

@Composable
private fun GrowthRing(growthPct: Double) {
    val color = if (growthPct >= 0) SuccessGreen else DangerRed
    val sweep = (minOf(kotlin.math.abs(growthPct), 100.0) * 3.6).toFloat()
    androidx.compose.foundation.Canvas(modifier = Modifier.size(20.dp)) {
        drawArc(color = Color(0xFFEDEFF3), startAngle = -90f, sweepAngle = 360f, useCenter = false, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f))
        drawArc(color = color, startAngle = -90f, sweepAngle = sweep, useCenter = false, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
    }
}

@Composable
private fun WholesaleTab(orders: List<com.abm.erp.data.RetailOrder>) {
    var buyer by remember { mutableStateOf("") }
    var items by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    val known = remember(orders) { orders.filter { it.channel == "wholesale" }.distinctBy { it.retailerName }.map { it.retailerName } }
    val suggestions = if (buyer.isBlank()) known else known.filter { it.contains(buyer, ignoreCase = true) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Log wholesale order", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = buyer, onValueChange = { buyer = it }, label = { Text("Wholesale buyer — search") }, modifier = Modifier.fillMaxWidth())
                if (suggestions.isNotEmpty()) {
                    Column(Modifier.heightIn(max = 140.dp).verticalScroll(rememberScrollState())) {
                        suggestions.forEach { name -> Text(name, modifier = Modifier.fillMaxWidth().clickable { buyer = name }.padding(vertical = 6.dp), style = MaterialTheme.typography.bodySmall) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = items, onValueChange = { items = it }, label = { Text("Items") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("Amount (৳)") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val amt = amount.toDoubleOrNull() ?: return@Button
                        if (buyer.isBlank() || amt <= 0) return@Button
                        MockRepository.logNewOrder(buyer, items, amt, "Wholesale", channel = "wholesale")
                        buyer = ""; items = ""; amount = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Log wholesale order") }
            }
        }
    }
}

@Composable
internal fun AsmVerifyTab(orders: List<com.abm.erp.data.RetailOrder>, dealers: List<com.abm.erp.data.Dealer>) {
    val pending = orders.filter { it.stage == OrderStage.SO_LOGGED }
    val routed = orders.filter { it.stage != OrderStage.SO_LOGGED }
    var qrOpenFor by remember { mutableStateOf<String?>(null) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Awaiting verification (${pending.size})", style = MaterialTheme.typography.titleMedium) }
        if (pending.isEmpty()) {
            item { com.abm.erp.core.WorkspaceEmptyState("যাচাইয়ের জন্য কোনো অর্ডার নেই।", "✅") }
        }
        items(pending) { order ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${order.retailerName} · ${order.zone}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    com.abm.erp.core.UniversalActionMenu(
                        moduleReference = "RetailOrder", entityId = order.id, entityLabel = order.orderNo,
                        shareText = "Order ${order.orderNo} — ${order.retailerName}\n${order.items}\n৳${order.amount}",
                        csvHeader = "OrderNo,Retailer,Zone,Items,Amount,Stage",
                        csvRow = com.abm.erp.core.toCsvRow(order.orderNo, order.retailerName, order.zone, order.items, order.amount, order.stage),
                    )
                }
                Text(order.items, style = MaterialTheme.typography.bodyMedium)
                Text("৳${"%,.0f".format(order.amount)}", color = ElectricCyan, fontWeight = FontWeight.Bold)
                if (order.retailerPhotoUri != null || order.retailerLat != null) {
                    Text(
                        buildString {
                            if (order.retailerPhotoUri != null) append("📷 photo on file  ")
                            if (order.retailerLat != null) append("📍 ${"%.3f".format(order.retailerLat)}, ${"%.3f".format(order.retailerLng)}")
                        },
                        style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                    )
                }
                order.retailerQrCode?.let { code ->
                    Spacer(Modifier.height(6.dp))
                    TextButton(onClick = { qrOpenFor = if (qrOpenFor == order.id) null else order.id }) {
                        Text(if (qrOpenFor == order.id) "Hide QR" else "🔳 View shop QR code")
                    }
                    if (qrOpenFor == order.id) {
                        val bitmap = remember(code) { com.abm.erp.util.QrCodeGenerator.generate(code, 300) }
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "QR code for $code",
                            modifier = Modifier.size(140.dp),
                        )
                        Text(code, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("Print this and stick it at the shop; scanning it later pulls up ${order.retailerName}'s data instantly.", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // v113-73 — this was `?: dealers.first()`, which threw on an empty list.
                    // It was already latent; cascade-scoping the list (Decision 4) makes an
                    // empty list genuinely reachable, so it is guarded properly now.
                    val nearestDealer = dealers.firstOrNull { it.zone == order.zone } ?: dealers.firstOrNull()
                    if (nearestDealer == null) {
                        Text("আপনার এলাকায় কোনো dealer নেই — route করা যাচ্ছে না।", color = WarningAmber, style = MaterialTheme.typography.labelSmall)
                    } else {
                        Button(
                            onClick = { MockRepository.advanceOrder(order.id, OrderStage.DEALER_ROUTED, nearestDealer.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
                        ) { Text("Verify → route to ${nearestDealer.name}") }
                    }
                    OutlinedButton(onClick = { MockRepository.advanceOrder(order.id, OrderStage.REJECTED) }) {
                        Text("Reject", color = DangerRed)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)); Text("In pipeline / fulfilled", style = MaterialTheme.typography.titleMedium) }
        if (routed.isEmpty()) {
            item { com.abm.erp.core.WorkspaceEmptyState("পাইপলাইনে কোনো অর্ডার নেই।", "📦") }
        }
        items(routed) { order ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("${order.retailerName}", color = TextPrimary)
                    com.abm.erp.core.StatusPill(order.stage.name)
                }
                // Blueprint §28 — Order's signature moment: the stage rail. Progress reads as a
                // position on a track rather than a word to parse.
                Spacer(Modifier.height(8.dp))
                com.abm.erp.core.StageRail(
                    stages = listOf("Logged", "Verified", "Routed", "Fulfilled"),
                    currentIndex = when (order.stage) {
                        OrderStage.SO_LOGGED -> 0
                        OrderStage.ASM_VERIFIED -> 1
                        OrderStage.DEALER_ROUTED -> 2
                        OrderStage.FULFILLED -> 3
                        OrderStage.REJECTED -> -1
                    },
                )
                if (order.stage == OrderStage.DEALER_ROUTED) {
                    Spacer(Modifier.height(6.dp))
                    Button(onClick = { MockRepository.advanceOrder(order.id, OrderStage.FULFILLED) }) {
                        Text("Mark fulfilled → Owner panel")
                    }
                }
            }
        }
    }
}

@Composable
internal fun DealerInvoiceTab(dealers: List<com.abm.erp.data.Dealer>, vm: SalesChainViewModel, onNavigate: (String) -> Unit = {}) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val invoices by MockRepository.salesInvoices.collectAsState()
    val myGeo = EMPLOYEE_DIRECTORY.firstOrNull { it.id == MockRepository.currentUser.employeeId }?.geo

    var selectedDealerId by remember { mutableStateOf<String?>(null) }
    var dateFilter by remember { mutableStateOf(0) } // 0=All, 1=Today, 2=Week, 3=Month
    var areaFilter by remember { mutableStateOf<String?>(null) }
    var statusFilter by remember { mutableStateOf<String?>(null) }
    var officerFilter by remember { mutableStateOf<String?>(null) }
    val cutoffDate = when (dateFilter) {
        1 -> java.time.LocalDate.now().atStartOfDay()
        2 -> java.time.LocalDate.now().minusDays(7).atStartOfDay()
        3 -> java.time.LocalDate.now().minusDays(30).atStartOfDay()
        else -> null
    }
    val visibleInvoices = invoices.filter { inv ->
        (selectedDealerId == null || inv.dealerId == selectedDealerId) &&
            (cutoffDate == null || inv.createdAt.isAfter(cutoffDate)) &&
            (areaFilter == null || inv.dealerZone == areaFilter) &&
            (statusFilter == null || inv.status == statusFilter) &&
            (officerFilter == null || inv.createdBy == officerFilter)
    }
    var cart by remember { mutableStateOf(listOf<com.abm.erp.data.SalesInvoiceLineItem>()) }
    var courier by remember { mutableStateOf("") }
    var dealerDiscount by remember { mutableStateOf("") }
    var commission by remember { mutableStateOf("") }
    var withSignature by remember { mutableStateOf(false) }

    var editingInvoiceId by remember { mutableStateOf<String?>(null) }
    var editRejectedError by remember { mutableStateOf<String?>(null) }
    // Section 10 — double-tap/retry protection. The button below used to
    // have no guard at all: two fast taps (slow device, network lag)
    // could create two invoices for the same cart before the first
    // response even updated the UI. This flag disables the button for
    // the duration of one submit attempt.
    var isSubmitting by remember { mutableStateOf(false) }
    var showBuilder by remember { mutableStateOf(false) }
    val submitScope = rememberCoroutineScope()

    val COURIERS = listOf("পাঠাও কুরিয়ার", "Steadfast Courier", "সুমন কুরিয়ার", "SA পরিবহন", "সুন্দরবন কুরিয়ার")
    var courierNote by remember { mutableStateOf("") }
    var showCourierOther by remember { mutableStateOf(false) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            // Decision 2 (v113-72) — discount and over-limit approvals raised against a
            // SalesInvoice are actioned here, beside the invoice list itself. The invoice's
            // own ✓ Approve button (further down this tab) was already correct; this adds
            // the ApprovalRequest rows that used to sit in the central inbox.
            com.abm.erp.core.ModuleApprovalSection(
                title = "Discount / limit অনুমোদনের অপেক্ষায়",
                entityTypes = setOf("SalesInvoice"),
            )
            Button(onClick = { showBuilder = true }, modifier = Modifier.fillMaxWidth()) {
                Text(if (editingInvoiceId != null) "✏️ Continue editing invoice" else "+ Create Dealer Invoice")
            }
            if (showBuilder) {
            Dialog(onDismissRequest = { showBuilder = false }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(modifier = Modifier.fillMaxSize(), color = com.abm.erp.theme.DashBg) {
            Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(if (editingInvoiceId != null) "Edit dealer invoice" else "Create dealer invoice", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    TextButton(onClick = { showBuilder = false }) { Text("✕ Close") }
                }
                Spacer(Modifier.height(10.dp))
                Text("Dealer — your area", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Column(Modifier.heightIn(max = 140.dp).verticalScroll(rememberScrollState())) {
                    dealers.forEach { d ->
                        val selected = selectedDealerId == d.id
                        Column(
                            modifier = Modifier.fillMaxWidth().clickable { selectedDealerId = d.id }.padding(vertical = 4.dp),
                        ) {
                            Text(
                                d.name, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                color = if (selected) Sky else TextPrimary,
                            )
                            if (selected) {
                                Text(
                                    "Due: ৳${"%,.0f".format(d.dueBalance)}" + if (d.creditLimit > 0) " / Limit: ৳${"%,.0f".format(d.creditLimit)}" else "",
                                    style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                                )
                            }
                        }
                    }
                }
                val selectedDealer = dealers.firstOrNull { it.id == selectedDealerId }
                if (selectedDealer != null && selectedDealer.creditLimit > 0 && selectedDealer.dueBalance >= selectedDealer.creditLimit) {
                    Spacer(Modifier.height(6.dp))
                    Text("⚠ এই ডিলার credit limit-এ বা তার বেশি পৌঁছেছে — নতুন invoice আগে চেক করুন।", color = DangerRed, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(10.dp))
                var productSearch by remember { mutableStateOf("") }
                OutlinedTextField(
                    value = productSearch, onValueChange = { productSearch = it },
                    placeholder = { Text("Product খুঁজুন…") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(6.dp))
                val visibleProducts = remember(products, productSearch) {
                    if (productSearch.isBlank()) products else products.filter { it.name.contains(productSearch, ignoreCase = true) || it.sku.contains(productSearch, ignoreCase = true) }
                }
                Column(Modifier.heightIn(max = 160.dp).verticalScroll(rememberScrollState())) {
                    visibleProducts.forEach { p ->
                        val stockLevel = InventoryRepository.stockLevels.value.filter { it.productId == p.id }.sumOf { it.quantityOnHand }
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                if (cart.none { it.productId == p.id }) {
                                    cart = cart + com.abm.erp.data.SalesInvoiceLineItem(p.id, p.name, p.unit, 10, p.defaultUnitPrice, 0.0)
                                }
                            }.padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(p.name, style = MaterialTheme.typography.bodySmall)
                            Text(
                                if (stockLevel <= 0) "Out of stock" else "Stock: ${stockLevel.toInt()}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (stockLevel <= 0) DangerRed else if (stockLevel <= p.reorderThreshold) WarningAmber else SuccessGreen,
                            )
                        }
                    }
                    if (visibleProducts.isEmpty()) Text("কোনো product পাওয়া যায়নি।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(8.dp))
                cart.forEachIndexed { idx, line ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Text(line.name, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        IconButton(onClick = { cart = cart.toMutableList().also { it[idx] = it[idx].copy(qty = maxOf(1, it[idx].qty - 5)) } }) { Text("−") }
                        Text("${line.qty}", style = MaterialTheme.typography.bodySmall)
                        IconButton(onClick = { cart = cart.toMutableList().also { it[idx] = it[idx].copy(qty = it[idx].qty + 5) } }) { Text("+") }
                        Text("৳${line.lineTotal.toInt()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        IconButton(onClick = { cart = cart.filterIndexed { i, _ -> i != idx } }) { Text("✕", color = DangerRed) }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Box {
                    OutlinedButton(onClick = { showCourierOther = !showCourierOther }, modifier = Modifier.fillMaxWidth()) {
                        Text(courier.ifBlank { "কুরিয়ার বেছে নিন" })
                    }
                    DropdownMenu(expanded = showCourierOther, onDismissRequest = { showCourierOther = false }) {
                        COURIERS.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { courier = c; showCourierOther = false }) }
                        DropdownMenuItem(text = { Text("Other…") }, onClick = { courier = "Other"; showCourierOther = false })
                    }
                }
                if (courier == "Other") {
                    OutlinedTextField(value = courierNote, onValueChange = { courierNote = it }, label = { Text("কুরিয়ার/ট্রান্সপোর্টের নাম") }, modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = dealerDiscount, onValueChange = { dealerDiscount = it }, label = { Text("Dealer discount % (optional)") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = commission, onValueChange = { commission = it }, label = { Text("Commission % (optional)") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
                    Checkbox(checked = withSignature, onCheckedChange = { withSignature = it })
                    Text("Add virtual signature (${MockRepository.currentUser.role})", style = MaterialTheme.typography.labelSmall)
                }
                if (editingInvoiceId != null) {
                    Text("✏️ Invoice correction mode", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                }
                editRejectedError?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = DangerRed) }
                Button(
                    enabled = !isSubmitting,
                    onClick = {
                        if (isSubmitting) return@Button
                        isSubmitting = true
                        submitScope.launch { kotlinx.coroutines.delay(1200); isSubmitting = false }
                        val editId = editingInvoiceId
                        if (editId != null) {
                            if (cart.isEmpty()) return@Button
                            val ok = MockRepository.updateSalesInvoice(
                                invoiceId = editId, lineItems = cart,
                                dealerDiscountPct = dealerDiscount.toDoubleOrNull() ?: 0.0, commissionPct = commission.toDoubleOrNull() ?: 0.0,
                                courier = if (courier == "Other") courierNote.ifBlank { null } else courier.ifBlank { null },
                                onRejected = { r -> editRejectedError = r },
                            )
                            if (ok) editRejectedError = null
                        } else {
                            val dealer = dealers.firstOrNull { it.id == selectedDealerId } ?: return@Button
                            if (cart.isEmpty()) return@Button
                            var rejectReason: String? = null
                            val created = MockRepository.createSalesInvoice(
                                dealerId = dealer.id, dealerName = dealer.name, dealerZone = dealer.zone, lineItems = cart,
                                dealerDiscountPct = dealerDiscount.toDoubleOrNull() ?: 0.0, commissionPct = commission.toDoubleOrNull() ?: 0.0,
                                courier = if (courier == "Other") courierNote.ifBlank { null } else courier.ifBlank { null },
                                signedByRole = if (withSignature) MockRepository.currentUser.role.name else null,
                                onRejected = { reason -> rejectReason = reason },
                            )
                            if (!created) {
                                android.widget.Toast.makeText(context, rejectReason ?: "ইনভয়েস তৈরি ব্যর্থ হয়েছে — স্টক/ক্রেডিট-লিমিট/বন্ধ-পিরিয়ড চেক করুন।", android.widget.Toast.LENGTH_LONG).show()
                                return@Button
                            }
                        }
                        cart = emptyList(); courier = ""; courierNote = ""; dealerDiscount = ""; commission = ""; withSignature = false; editingInvoiceId = null
                        showBuilder = false
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (editingInvoiceId != null) "Update invoice — correction" else "Create invoice — auto-saves") }
            }
            }
            }
            }
        }

        item {
            // ---- Sales Insights: real data only — payroll target/achieved (company-wide sum) and top products from actual invoice line items ----
            val payrollForTarget by MockRepository.payroll.collectAsState()
            val totalTarget = payrollForTarget.sumOf { it.targetAmount }
            val totalAchieved = payrollForTarget.sumOf { it.achievedAmount }
            val achievementPct = if (totalTarget > 0) (totalAchieved / totalTarget * 100) else null
            val topProductsForSales = remember(invoices) {
                invoices.filter { !it.isDeleted }.flatMap { it.lineItems }.groupBy { it.name }
                    .mapValues { (_, items) -> items.sumOf { it.qty } }
                    .entries.sortedByDescending { it.value }.take(3)
            }
            val lowSellingProducts = remember(invoices) {
                invoices.filter { !it.isDeleted }.flatMap { it.lineItems }.groupBy { it.name }
                    .mapValues { (_, items) -> items.sumOf { it.qty } }
                    .entries.sortedBy { it.value }.take(3)
            }
            val totalInvoiced = remember(visibleInvoices) { visibleInvoices.filter { !it.isDeleted }.sumOf { it.total } }
            val totalOutstandingDue = remember(dealers) { dealers.sumOf { it.dueBalance } }
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Sales Insights", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                if (achievementPct != null) {
                    Text("Target Achievement: ${"%.0f".format(achievementPct)}% (৳${"%,.0f".format(totalAchieved)} / ৳${"%,.0f".format(totalTarget)})", style = MaterialTheme.typography.bodySmall, color = if (achievementPct >= 100) SuccessGreen else if (achievementPct >= 70) WarningAmber else DangerRed)
                } else {
                    Text("Sales target data unavailable.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
                Spacer(Modifier.height(6.dp))
                Text("Invoiced (filtered): ৳${"%,.0f".format(totalInvoiced)}  ·  Total Outstanding Due: ৳${"%,.0f".format(totalOutstandingDue)}", style = MaterialTheme.typography.bodySmall, color = if (totalOutstandingDue > 0) WarningAmber else SuccessGreen)
                Spacer(Modifier.height(6.dp))
                if (topProductsForSales.isNotEmpty()) {
                    Text("Top products: " + topProductsForSales.joinToString(", ") { "${it.key} (${it.value.toInt()})" }, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                if (lowSellingProducts.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text("Low-selling: " + lowSellingProducts.joinToString(", ") { "${it.key} (${it.value.toInt()})" }, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                val marginableInvoices = remember(visibleInvoices) { visibleInvoices.mapNotNull { inv -> MockRepository.invoiceMargin(inv) } }
                if (marginableInvoices.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    val totalMargin = marginableInvoices.sum()
                    Text("Margin (${marginableInvoices.size} invoice(s) with cost data): ৳${"%,.0f".format(totalMargin)}", style = MaterialTheme.typography.labelSmall, color = if (totalMargin >= 0) SuccessGreen else DangerRed)
                } else {
                    Spacer(Modifier.height(6.dp))
                    Text("Margin data unavailable — no product cost prices set yet.", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                val unpaidInvoices = remember(invoices) { invoices.filter { !it.isDeleted && it.status != "PAID" && it.status != "CANCELLED" } }
                val now = java.time.LocalDateTime.now()
                val age0to30 = unpaidInvoices.count { java.time.Duration.between(it.createdAt, now).toDays() <= 30 }
                val age31to60 = unpaidInvoices.count { java.time.Duration.between(it.createdAt, now).toDays() in 31..60 }
                val age60plus = unpaidInvoices.count { java.time.Duration.between(it.createdAt, now).toDays() > 60 }
                if (unpaidInvoices.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Text("Invoice Ageing (unpaid): 0-30d: $age0to30 · 31-60d: $age31to60 · 60d+: $age60plus", style = MaterialTheme.typography.labelSmall, color = if (age60plus > 0) DangerRed else TextSecondary)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                FilterChip(selected = dateFilter == 0, onClick = { dateFilter = 0 }, label = { Text("All") })
                FilterChip(selected = dateFilter == 1, onClick = { dateFilter = 1 }, label = { Text("Today") })
                FilterChip(selected = dateFilter == 2, onClick = { dateFilter = 2 }, label = { Text("This Week") })
                FilterChip(selected = dateFilter == 3, onClick = { dateFilter = 3 }, label = { Text("This Month") })
            }
            Spacer(Modifier.height(6.dp))
            val areas = remember(invoices) { invoices.map { it.dealerZone }.distinct().sorted() }
            val statuses = remember(invoices) { invoices.map { it.status }.distinct().sorted() }
            val officers = remember(invoices) { invoices.map { it.createdBy }.distinct().sorted() }
            if (areas.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                    FilterChip(selected = areaFilter == null, onClick = { areaFilter = null }, label = { Text("All Areas") })
                    areas.forEach { a -> FilterChip(selected = areaFilter == a, onClick = { areaFilter = a }, label = { Text(a) }) }
                }
                Spacer(Modifier.height(6.dp))
            }
            if (statuses.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                    FilterChip(selected = statusFilter == null, onClick = { statusFilter = null }, label = { Text("All Status") })
                    statuses.forEach { s -> FilterChip(selected = statusFilter == s, onClick = { statusFilter = s }, label = { Text(s) }) }
                }
                Spacer(Modifier.height(6.dp))
            }
            if (officers.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                    FilterChip(selected = officerFilter == null, onClick = { officerFilter = null }, label = { Text("All Officers") })
                    officers.forEach { o -> FilterChip(selected = officerFilter == o, onClick = { officerFilter = o }, label = { Text(o) }) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Invoices (${visibleInvoices.size})", style = MaterialTheme.typography.titleMedium)
                val context = androidx.compose.ui.platform.LocalContext.current
                com.abm.erp.core.ModuleActionBar(
                    onExport = {
                        try {
                            val header = "InvoiceNo,Dealer,Zone,Total,Status\n"
                            val rows = visibleInvoices.joinToString("\n") { i -> com.abm.erp.core.toCsvRow(i.invoiceNo, i.dealerName, i.dealerZone, i.total, i.status) }
                            val dir = context.getExternalFilesDir(null)
                            if (dir == null) {
                                Toast.makeText(context, "Storage সহজলভ্য নেই — export সম্ভব হলো না।", Toast.LENGTH_LONG).show()
                            } else {
                                val file = java.io.File(dir, "sales_invoices_${System.currentTimeMillis()}.csv")
                                file.writeText(header + rows)
                                Toast.makeText(context, "Saved: ${file.name}", Toast.LENGTH_LONG).show()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(context, "Export ব্যর্থ হয়েছে: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    },
                    onShare = {
                        try {
                            val summary = "Sales Invoices (${visibleInvoices.size})\n" + visibleInvoices.take(20).joinToString("\n") { "${it.invoiceNo} — ${it.dealerName} ৳${it.total} (${it.status})" }
                            val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, summary) }
                            context.startActivity(Intent.createChooser(intent, "Sales Invoices"))
                        } catch (e: Exception) {
                            Toast.makeText(context, "Share করার মতো কোনো app পাওয়া যায়নি।", Toast.LENGTH_LONG).show()
                        }
                    },
                )
            }
        }
        if (visibleInvoices.isEmpty()) {
            item { com.abm.erp.core.WorkspaceEmptyState("কোনো Invoice পাওয়া যায়নি — ফিল্টার পরিবর্তন করে দেখুন।", "🧾") }
        }
        items(visibleInvoices) { inv ->
            InvoiceCard(inv, vm, onOpenDoc = { onNavigate("invoice_doc/${inv.id}") }, onEdit = {
                editingInvoiceId = inv.id
                selectedDealerId = inv.dealerId
                cart = inv.lineItems
                dealerDiscount = if (inv.dealerDiscountPct > 0) inv.dealerDiscountPct.toString() else ""
                commission = if (inv.commissionPct > 0) inv.commissionPct.toString() else ""
                courier = inv.courier ?: ""
                showBuilder = true
            }, onReorder = {
                editingInvoiceId = null
                selectedDealerId = inv.dealerId
                cart = inv.lineItems.map { it.copy() }
                dealerDiscount = if (inv.dealerDiscountPct > 0) inv.dealerDiscountPct.toString() else ""
                commission = if (inv.commissionPct > 0) inv.commissionPct.toString() else ""
                courier = ""
                showBuilder = true
            })
        }
    }
}

@Composable
private fun InvoiceCard(inv: com.abm.erp.data.SalesInvoice, vm: SalesChainViewModel, onEdit: () -> Unit, onReorder: () -> Unit, onOpenDoc: () -> Unit = {}) {
    val navy = Color(0xFF123A4B)
    val gold = Color(0xFFF5C842)
    var justDenied by remember { mutableStateOf<String?>(null) }
    val allInvoices by MockRepository.salesInvoices.collectAsState()
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                // Tapping the number opens the printable document page — the same
                // bill the PDF produces, viewable before printing.
                Text(
                    inv.invoiceNo,
                    fontWeight = FontWeight.Bold,
                    color = com.abm.erp.theme.DarazOrange,
                    modifier = Modifier.clickable { onOpenDoc() },
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(inv.createdAt.toLocalDate().toString(), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = onEdit, contentPadding = PaddingValues(0.dp)) { Text("✏️ Edit", style = MaterialTheme.typography.labelSmall) }
                    TextButton(onClick = onReorder, contentPadding = PaddingValues(0.dp)) { Text("🔁 Reorder", style = MaterialTheme.typography.labelSmall) }
                    val context = androidx.compose.ui.platform.LocalContext.current
                    // v113-87 — PDF/print now (re)issues the invoice's registry QR first, so the
                    // paper carries a genuinely scannable code (the old "INVOICE:<id>" string was
                    // rejected by both scan paths). Issue is suspend, hence the scope.
                    val pdfScope = rememberCoroutineScope()
                    TextButton(
                        onClick = {
                            pdfScope.launch {
                                runCatching {
                                    val payload = com.abm.erp.data.QrRegistry.issue("SalesInvoice", inv.id)
                                    val file = com.abm.erp.core.exportSalesInvoicePdf(context, inv, payload)
                                    val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                                    context.startActivity(Intent.createChooser(shareIntent, "Invoice ${inv.invoiceNo}"))
                                }.onFailure { e ->
                                    Toast.makeText(context, "Invoice PDF তৈরি ব্যর্থ হয়েছে: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        contentPadding = PaddingValues(0.dp),
                    ) { Text("📄 Invoice PDF", style = MaterialTheme.typography.labelSmall) }
                    TextButton(
                        onClick = {
                            pdfScope.launch {
                                runCatching {
                                val payload = com.abm.erp.data.QrRegistry.issue("SalesInvoice", inv.id)
                                val file = com.abm.erp.core.exportSalesInvoicePdf(context, inv, payload)
                                val printManager = context.getSystemService(android.content.Context.PRINT_SERVICE) as android.print.PrintManager
                                val pdfAdapter = object : android.print.PrintDocumentAdapter() {
                                    override fun onLayout(oldAttrs: android.print.PrintAttributes?, newAttrs: android.print.PrintAttributes, cancellationSignal: android.os.CancellationSignal?, callback: LayoutResultCallback, extras: android.os.Bundle?) {
                                        if (cancellationSignal?.isCanceled == true) { callback.onLayoutCancelled(); return }
                                        val info = android.print.PrintDocumentInfo.Builder("Invoice_${inv.invoiceNo}.pdf").setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build()
                                        callback.onLayoutFinished(info, true)
                                    }
                                    override fun onWrite(pages: Array<out android.print.PageRange>?, destination: android.os.ParcelFileDescriptor, cancellationSignal: android.os.CancellationSignal?, callback: WriteResultCallback) {
                                        file.inputStream().use { input -> java.io.FileOutputStream(destination.fileDescriptor).use { output -> input.copyTo(output) } }
                                        callback.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                                    }
                                }
                                printManager.print("Invoice ${inv.invoiceNo}", pdfAdapter, android.print.PrintAttributes.Builder().build())
                                MockRepository.logAudit("SalesInvoice", inv.id, "PRINT", newValue = "printed by ${MockRepository.currentUser.name}")
                                }.onFailure { e ->
                                    Toast.makeText(context, "Print শুরু করা যায়নি: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        contentPadding = PaddingValues(0.dp),
                    ) { Text("🖨️ Print", style = MaterialTheme.typography.labelSmall) }
                    com.abm.erp.core.UniversalActionMenu(
                        moduleReference = "SalesInvoice", entityId = inv.id, entityLabel = inv.invoiceNo,
                        shareText = "Invoice ${inv.invoiceNo} — ${inv.dealerName}\nTotal: ৳${inv.total}\nStatus: ${inv.status}",
                        isDeleted = inv.isDeleted,
                        recordStatus = inv.status,
                        onArchive = { onError -> vm.deleteInvoice(inv.id, onRejected = onError) },
                        canArchive = vm.canDeleteInvoice(),
                        onRestore = { pdfScope.launch { vm.restoreInvoice(inv.id) } },
                        csvHeader = "InvoiceNo,Dealer,Zone,Total,Status",
                        csvRow = com.abm.erp.core.toCsvRow(inv.invoiceNo, inv.dealerName, inv.dealerZone, inv.total, inv.status),
                        historyLabel = "Sales History",
                        historyItems = allInvoices.filter { it.dealerId == inv.dealerId }.map { "${it.invoiceNo}: ৳${"%,.0f".format(it.total)} — ${it.createdAt.toLocalDate()} (${it.status})" },
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(inv.dealerName, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(inv.dealerZone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Spacer(Modifier.height(8.dp))
            inv.lineItems.forEach { li ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${li.name} × ${li.qty} ${li.unit}", style = MaterialTheme.typography.bodySmall)
                    Text("৳${li.lineTotal.toInt()}", style = MaterialTheme.typography.bodySmall)
                }
            }
            if (inv.courier != null) Text("🚚 ${inv.courier}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            if (inv.dealerDiscountAmt > 0) Text("Discount: −৳${inv.dealerDiscountAmt.toInt()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            if (inv.commissionAmt > 0) Text("Commission: ৳${inv.commissionAmt.toInt()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().background(navy, shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp)).padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Total", color = gold, fontWeight = FontWeight.Bold)
                Text("৳${inv.total.toInt()}", color = Color.White, fontWeight = FontWeight.Bold)
            }
            if (inv.signedByRole != null) Text("✒ Authorized — ${inv.signedByRole}", style = MaterialTheme.typography.labelSmall, color = TextSecondary, modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(6.dp))
            var showTimeline by remember { mutableStateOf(false) }
            TextButton(onClick = { showTimeline = !showTimeline }, contentPadding = PaddingValues(0.dp)) {
                Text(if (showTimeline) "▲ Hide Timeline" else "▼ Timeline", style = MaterialTheme.typography.labelSmall)
            }
            if (showTimeline) {
                val timelineEntries by MockRepository.activityLogFor("SalesInvoice", inv.id).collectAsState(initial = emptyList())
                Column(Modifier.padding(start = 8.dp, top = 4.dp)) {
                    if (timelineEntries.isEmpty()) {
                        Text("এই invoice-এর জন্য কোনো activity history পাওয়া যায়নি।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    } else {
                        timelineEntries.sortedByDescending { it.timestamp }.forEach { entry ->
                            Text("• ${entry.action} — ${entry.performedBy} · ${entry.timestamp}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                }
            }

            // ---- Action-Level Permission Matrix example: Approve/Delete only
            // render at all when this role's RoleDefinition allows it — an SR
            // never even sees these buttons; ASM+ do. Even if someone forced
            // them visible, MockRepository.approveSalesInvoice/deleteSalesInvoice
            // re-check the same permission server-side-equivalent (Room/Firestore
            // write layer) and refuse, so a bypassed UI still can't act. ----
            if (inv.status == "PENDING" && (vm.canApproveInvoice() || vm.canDeleteInvoice())) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (vm.canApproveInvoice()) {
                        Button(onClick = { vm.approveInvoice(inv.id, onRejected = { reason -> justDenied = reason }) }) { Text("✓ Approve") }
                    }
                    if (vm.canDeleteInvoice()) {
                        OutlinedButton(onClick = { vm.deleteInvoice(inv.id, onRejected = { reason -> justDenied = reason }) }) { Text("🗑 Delete", color = com.abm.erp.theme.DangerRed) }
                    }
                }
            } else if (inv.status == "APPROVED") {
                Spacer(Modifier.height(6.dp))
                Text("✓ Approved", color = com.abm.erp.theme.SuccessGreen, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
            justDenied?.let {
                Spacer(Modifier.height(4.dp))
                Text("⚠ $it", color = com.abm.erp.theme.DangerRed, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}


/** v86, Module 4 — Sales Order stage UI: create/submit/approve/deliver/convert-to-invoice. */
@Composable
internal fun SalesOrderTab(dealers: List<com.abm.erp.data.Dealer>) {
    val salesOrders by MockRepository.salesOrders.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    var statusFilter by remember { mutableStateOf<String?>(null) }
    val filteredSalesOrders = salesOrders.filter { statusFilter == null || it.status == statusFilter }

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Sales Order") }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = statusFilter == null, onClick = { statusFilter = null }, label = { Text("সব") })
            listOf("PENDING", "INVOICED", "DELIVERED", "CANCELLED").forEach { s ->
                FilterChip(selected = statusFilter == s, onClick = { statusFilter = s }, label = { Text(s) })
            }
        }
        Spacer(Modifier.height(10.dp))
        if (filteredSalesOrders.isEmpty()) {
            com.abm.erp.core.WorkspaceEmptyState("কোনো Sales Order পাওয়া যায়নি।", "📃")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filteredSalesOrders, key = { it.id }) { o ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("${o.orderNo} — ${o.dealerName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                Text("৳${"%,.0f".format(o.netAfterDiscount)}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            }
                            Text(
                                o.status,
                                color = when (o.status) { "INVOICED" -> SuccessGreen; "CANCELLED" -> DangerRed; "DELIVERED" -> Sky; else -> WarningAmber },
                                fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall,
                            )
                            com.abm.erp.core.UniversalActionMenu(
                                moduleReference = "SalesOrder", entityId = o.id, entityLabel = o.orderNo,
                                shareText = "${o.orderNo} — ${o.dealerName}\n৳${o.netAfterDiscount} · ${o.status}",
                                csvHeader = "OrderNo,Dealer,Total,Status", csvRow = com.abm.erp.core.toCsvRow(o.orderNo, o.dealerName, o.netAfterDiscount, o.status),
                            )
                        }
                        if (o.deliveredQtyByProduct.isNotEmpty()) {
                            Spacer(Modifier.height(4.dp))
                            o.lineItems.forEach { li ->
                                val delivered = o.deliveredQtyByProduct[li.productId] ?: 0
                                Text("${li.name}: $delivered / ${li.qty} delivered", style = MaterialTheme.typography.labelSmall, color = if (delivered < li.qty) WarningAmber else SuccessGreen)
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (o.status == "DRAFT") TextButton(onClick = { MockRepository.submitSalesOrder(o.id) }) { Text("Submit") }
                            val orderActionContext = androidx.compose.ui.platform.LocalContext.current
                            if (o.status == "SUBMITTED") Button(onClick = { MockRepository.approveSalesOrder(o.id, onRejected = { r -> android.widget.Toast.makeText(orderActionContext, r, android.widget.Toast.LENGTH_LONG).show() }) }) { Text("Approve") }
                            if (o.status !in setOf("INVOICED", "CANCELLED")) {
                                var showCancel by remember { mutableStateOf(false) }
                                TextButton(onClick = { showCancel = true }) { Text("Cancel", color = DangerRed) }
                                if (showCancel) {
                                    var cancelReason by remember { mutableStateOf("") }
                                    Dialog(onDismissRequest = { showCancel = false }) {
                                        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                            Column(Modifier.padding(16.dp)) {
                                                Text("Cancel Order ${o.orderNo}?", style = MaterialTheme.typography.titleMedium)
                                                Spacer(Modifier.height(8.dp))
                                                OutlinedTextField(value = cancelReason, onValueChange = { cancelReason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
                                                Spacer(Modifier.height(10.dp))
                                                var cancelError by remember { mutableStateOf<String?>(null) }
                                                cancelError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                                Button(onClick = { val ok = MockRepository.cancelSalesOrder(o.id, cancelReason, onRejected = { r -> cancelError = r }); if (ok) showCancel = false }, modifier = Modifier.fillMaxWidth()) { Text("Confirm Cancel") }
                                            }
                                        }
                                    }
                                }
                            }
                            if (o.status == "APPROVED" || o.status == "PARTIALLY_DELIVERED") {
                                var showDeliver by remember { mutableStateOf(false) }
                                TextButton(onClick = { showDeliver = true }) { Text("Record Delivery") }
                                if (showDeliver) {
                                    val deliverAmounts = remember { mutableStateMapOf<String, String>() }
                                    Dialog(onDismissRequest = { showDeliver = false }) {
                                        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                            Column(Modifier.padding(16.dp)) {
                                                Text("Record Delivery — ${o.orderNo}", style = MaterialTheme.typography.titleMedium)
                                                Spacer(Modifier.height(8.dp))
                                                o.lineItems.forEach { li ->
                                                    val remaining = li.qty - (o.deliveredQtyByProduct[li.productId] ?: 0)
                                                    OutlinedTextField(
                                                        value = deliverAmounts[li.productId] ?: "", onValueChange = { deliverAmounts[li.productId] = it },
                                                        label = { Text("${li.name} (max $remaining)") }, modifier = Modifier.fillMaxWidth(),
                                                    )
                                                }
                                                Spacer(Modifier.height(10.dp))
                                                Button(
                                                    onClick = {
                                                        val map = deliverAmounts.mapNotNull { (pid, v) -> v.toIntOrNull()?.let { pid to it } }.toMap()
                                                        if (map.isNotEmpty()) { MockRepository.recordDelivery(o.id, map); showDeliver = false }
                                                    },
                                                    modifier = Modifier.fillMaxWidth(),
                                                ) { Text("Save Delivery") }
                                            }
                                        }
                                    }
                                }
                            }
                            if (o.status == "APPROVED" || o.status == "DELIVERED" || o.status == "PARTIALLY_DELIVERED") {
                                Button(onClick = { MockRepository.convertSalesOrderToInvoice(o.id) }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) { Text("Convert to Invoice") }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNew) {
        var selectedDealerId by remember { mutableStateOf<String?>(null) }
        var productName by remember { mutableStateOf("") }
        var qty by remember { mutableStateOf("") }
        var cart by remember { mutableStateOf(listOf<com.abm.erp.data.SalesInvoiceLineItem>()) }
        Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                    Text("New Sales Order", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Column(Modifier.heightIn(max = 140.dp).verticalScroll(rememberScrollState())) {
                        dealers.forEach { d ->
                            Text(d.name, fontWeight = if (selectedDealerId == d.id) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.fillMaxWidth().clickable { selectedDealerId = d.id }.padding(vertical = 6.dp))
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    cart.forEach { li -> Text("• ${li.name} × ${li.qty}", style = MaterialTheme.typography.bodySmall) }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = productName, onValueChange = { productName = it }, label = { Text("Product") }, modifier = Modifier.weight(2f))
                        OutlinedTextField(value = qty, onValueChange = { qty = it }, label = { Text("Qty") }, modifier = Modifier.weight(1f))
                    }
                    TextButton(onClick = {
                        val q = qty.toIntOrNull()
                        if (productName.isNotBlank() && q != null && q > 0) {
                            cart = cart + com.abm.erp.data.SalesInvoiceLineItem(productId = "", name = productName, unit = "pcs", qty = q, unitPrice = 0.0)
                            productName = ""; qty = ""
                        }
                    }) { Text("+ Add Item") }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val d = dealers.firstOrNull { it.id == selectedDealerId }
                            if (d != null && cart.isNotEmpty()) { MockRepository.createSalesOrder(d.id, d.name, d.zone, cart); showNew = false }
                        },
                        enabled = selectedDealerId != null && cart.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Save Draft") }
                }
            }
        }
    }
}
