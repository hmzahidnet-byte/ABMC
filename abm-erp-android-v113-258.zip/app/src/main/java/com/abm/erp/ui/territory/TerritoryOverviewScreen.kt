package com.abm.erp.ui.territory

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.Space
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.*
import java.time.LocalDate

/**
 * Territory / Area Overview — everything about one area, in the same design
 * language as Dealer/Retailer/Employee/Product's own click-in detail view.
 *
 * v113-249 — full rebuild, the person's own direct, repeated request: this
 * screen previously had its own bespoke blue-gradient header and a single
 * long scrolling page of stacked sections — visually disconnected from the
 * rest of the app (confirmed directly: "ভিজুয়ালটার তো কোনো মিলই নেই").
 * Rebuilt around the exact same BrowseTopBar + tab structure
 * ModuleBrowseDetail already uses for Dealer/Retailer/Employee/Product —
 * same purple header, same Info card shape, same tab pattern — so a
 * location reached from Universal Search finally looks like it belongs to
 * the same app as everything else. All the real data this screen already
 * had (KPIs, product-wise sales, dealer/retailer/employee lists) is kept,
 * reorganized into tabs instead of one long scroll. One genuinely new
 * capability added at the person's own explicit request: a real custom
 * date-range filter for the sales figures (previously a fixed 7 days),
 * reusing the exact rangeMode/customFrom/customTo/pickerFor pattern
 * PartyStatementScreen already established and proved, rather than a
 * second, parallel date-picker implementation.
 *
 * **Cascade visibility is applied to the underlying lists, not just the
 * header.** Dealers and retailers are filtered through the same
 * `visibleDealerIds`/`visibleRetailerIds` the rest of the app uses, so an
 * SR opening an area sees it *as far as their own scope reaches*, never
 * the whole company's data for it.
 *
 * All figures come from existing repository data. Nothing is generated or
 * sampled.
 */
@Composable
fun TerritoryOverviewScreen(zoneRaw: String, adminLocationId: String? = null, onNavigate: (String) -> Unit, onBack: () -> Unit) {
    val zone = remember(zoneRaw) { runCatching { java.net.URLDecoder.decode(zoneRaw, "UTF-8") }.getOrDefault(zoneRaw) }

    val allDealers by MockRepository.dealers.collectAsState()
    val allRetailers by MockRepository.retailers.collectAsState()
    val invoices by MockRepository.salesInvoices.collectAsState()
    val collections by MockRepository.partyCollections.collectAsState()
    val profiles by MockRepository.employeeProfiles.collectAsState()

    val myProfileId = remember(profiles) {
        profiles.firstOrNull { it.userAccountId == MockRepository.currentUser.id }?.id
    }
    // Cascade scope. When the viewer has no profile mapping (e.g. the Chairman demo account)
    // the module permission that let them reach this screen is the governing check.
    val visibleDealerIds = remember(myProfileId) {
        myProfileId?.let { MockRepository.visibleDealerIds(it) }
    }
    val visibleRetailerIds = remember(myProfileId) {
        myProfileId?.let { MockRepository.visibleRetailerIds(it) }
    }

    // v113-247 — two ways to arrive here: a zone string (Universal Search's
    // original path, derived from existing Dealer.zone/Retailer.market) or
    // a real Bangladesh administrative-location id (District/Upazila/
    // Union — Universal Search's extended path, and Location Master's own
    // now-redundant-and-removed search before it). Same screen, same
    // content, two matching strategies underneath.
    val allAdminLocations by MockRepository.administrativeLocations.collectAsState()
    val adminLocation = remember(adminLocationId, allAdminLocations) {
        adminLocationId?.let { id -> allAdminLocations.firstOrNull { it.id == id } }
    }
    val displayTitle = adminLocation?.let { it.nameBn.ifBlank { it.nameEn } } ?: zone
    val hierarchyPath = remember(adminLocation) { adminLocation?.let { MockRepository.adminHierarchyPath(it.id) } }

    val dealers = remember(allDealers, zone, adminLocation, visibleDealerIds) {
        val matched = if (adminLocation != null) MockRepository.dealersForAdminLocation(adminLocation, allDealers)
            else allDealers.filter { !it.isDeleted && it.zone == zone }
        matched.filter { visibleDealerIds == null || it.id in visibleDealerIds }
    }
    val retailers = remember(allRetailers, zone, adminLocation, visibleRetailerIds) {
        val matched = if (adminLocation != null) MockRepository.retailersForAdminLocation(adminLocation, allRetailers)
            else allRetailers.filter { !it.isDeleted && it.market == zone }
        matched.filter { visibleRetailerIds == null || it.id in visibleRetailerIds }
    }
    val dealerIds = remember(dealers) { dealers.map { it.id }.toSet() }
    val areaEmployees = remember(displayTitle, profiles) {
        profiles.filter { e ->
            !e.isDeleted && listOf(e.region, e.area, e.branch).any { it.isNotBlank() && it.contains(displayTitle, ignoreCase = true) }
        }
    }

    val zoneInvoicesAllTime = remember(invoices, dealerIds) {
        invoices.filter { !it.isDeleted && it.dealerId in dealerIds }
    }
    val zoneCollectionsAllTime = remember(collections, dealerIds) {
        collections.filter { it.partyId in dealerIds }
    }

    val totalDue = dealers.sumOf { it.dueBalance } + retailers.sumOf { it.dueBalance }
    val overLimit = dealers.count { it.creditLimit > 0 && it.dueBalance > it.creditLimit }

    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("Overview", "Dealers", "Retailers", "Employees", "Sales Report")

    Column(Modifier.fillMaxSize().background(DashBg)) {
        com.abm.erp.core.BrowseTopBar(displayTitle, hierarchyPath, 0xFFB45CFF, 0xFF7A2EE0, onBack)

        Column(Modifier.background(Color.White).padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                com.abm.erp.core.BrowseStatCell("Dealers", "${dealers.size}", TextPrimary)
                com.abm.erp.core.BrowseStatCell("Retailers", "${retailers.size}", TextPrimary)
                com.abm.erp.core.BrowseStatCell("Employees", "${areaEmployees.size}", TextPrimary)
                com.abm.erp.core.BrowseStatCell("Total Due", "৳${"%,.0f".format(totalDue)}", if (totalDue > 0) WarningAmber else SuccessGreen)
            }
        }

        if (tabs.size > 1) {
            TabRow(selectedTabIndex = tab, containerColor = Color.White) {
                tabs.forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, fontSize = 12.sp) })
                }
            }
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp)) {
            when (tab) {
                0 -> OverviewSubTab(dealers.size, retailers.size, areaEmployees.size, totalDue, overLimit, zoneInvoicesAllTime.size, zoneCollectionsAllTime.sumOf { it.amount })
                1 -> PartyListSubTab(
                    isEmpty = dealers.isEmpty(), empty = "এই এলাকায় আপনার আওতায় কোনো ডিলার নেই।", emptyIcon = Icons.Filled.Business,
                ) {
                    dealers.forEach { d ->
                        com.abm.erp.core.EnterpriseListRow(
                            title = d.name,
                            subtitle = "Due ৳${"%,.0f".format(d.dueBalance)}",
                            meta = if (d.creditLimit > 0) "Limit ৳${"%,.0f".format(d.creditLimit)}" else null,
                            icon = Icons.Filled.Business,
                            accent = if (d.creditLimit > 0 && d.dueBalance > d.creditLimit) StatusRed else Color(0xFF2563EB),
                            onClick = { onNavigate("rich_dealer_detail/${d.id}") },
                        )
                    }
                }
                2 -> PartyListSubTab(
                    isEmpty = retailers.isEmpty(), empty = "এই এলাকায় আপনার আওতায় কোনো রিটেইলার নেই।", emptyIcon = Icons.Filled.Store,
                ) {
                    retailers.forEach { r ->
                        com.abm.erp.core.EnterpriseListRow(
                            title = r.name,
                            subtitle = "${r.retailerCode} · ${r.outletCategory}",
                            meta = "Due ৳${"%,.0f".format(r.dueBalance)}",
                            icon = Icons.Filled.Store,
                            accent = Color(0xFF12C2A9),
                            onClick = { onNavigate("rich_retailer_detail/${r.id}") },
                        )
                    }
                }
                3 -> PartyListSubTab(
                    isEmpty = areaEmployees.isEmpty(), empty = "এই এলাকায় assign করা কোনো কর্মী পাওয়া যায়নি।", emptyIcon = Icons.Filled.Person,
                ) {
                    areaEmployees.forEach { e ->
                        com.abm.erp.core.EnterpriseListRow(
                            title = e.fullName,
                            subtitle = "${e.designation.ifBlank { e.role.name }} · ${e.department.ifBlank { "—" }}",
                            meta = if (e.hasActiveAccess) "Active" else "Inactive",
                            icon = Icons.Filled.Person,
                            accent = Color(0xFFDB2777),
                            onClick = { onNavigate("rich_employee_detail/${e.id}") },
                        )
                    }
                }
                else -> SalesReportSubTab(zoneInvoicesAllTime, zoneCollectionsAllTime, invoices)
            }
            Spacer(Modifier.height(Space.xxl))
        }
    }
}

@Composable
private fun OverviewSubTab(dealerCount: Int, retailerCount: Int, employeeCount: Int, totalDue: Double, overLimit: Int, invoiceCount: Int, collectedAllTime: Double) {
    com.abm.erp.core.PremiumCard(padding = Space.md) {
        Text("এক নজরে", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(8.dp))
        listOf(
            "Dealers" to "$dealerCount",
            "Retailers" to "$retailerCount",
            "Employees (assigned)" to "$employeeCount",
            "Total Due" to "৳${"%,.0f".format(totalDue)}",
            "Credit Limit ছাড়িয়ে গেছে" to "$overLimit",
            "মোট Invoice" to "$invoiceCount",
            "সর্বমোট Collected" to "৳${"%,.0f".format(collectedAllTime)}",
        ).forEach { (label, value) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(label, fontSize = 12.sp, color = TextSecondary)
                Text(value, fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun PartyListSubTab(isEmpty: Boolean, empty: String, emptyIcon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable () -> Unit) {
    if (isEmpty) {
        com.abm.erp.core.WorkspaceEmptyState(empty, iconVector = emptyIcon)
    } else {
        Column(verticalArrangement = Arrangement.spacedBy(Space.sm)) {
            content()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SalesReportSubTab(
    zoneInvoicesAllTime: List<com.abm.erp.data.SalesInvoice>,
    zoneCollectionsAllTime: List<com.abm.erp.data.PartyCollection>,
    allInvoicesCompanyWide: List<com.abm.erp.data.SalesInvoice>,
) {
    // v113-249 — the person's own explicit ask: "Today / 90-day / Custom
    // date-range" sales, all in one place, not a fixed 7-day window. Same
    // proven rangeMode/customFrom/customTo/pickerFor pattern
    // PartyStatementScreen already uses — reused directly, not a second
    // parallel date-picker implementation.
    var rangeMode by remember { mutableStateOf(1) } // 0=Today 1=7 Days 2=30 Days 3=90 Days 4=Custom
    var customFrom by remember { mutableStateOf<LocalDate?>(null) }
    var customTo by remember { mutableStateOf<LocalDate?>(null) }
    var pickerFor by remember { mutableStateOf<String?>(null) }

    val today = LocalDate.now()
    val (fromDate, toDate) = when (rangeMode) {
        0 -> today to today
        1 -> today.minusDays(6) to today
        2 -> today.minusDays(29) to today
        3 -> today.minusDays(89) to today
        else -> (customFrom ?: today.minusDays(6)) to (customTo ?: today)
    }

    val rangeInvoices = remember(zoneInvoicesAllTime, fromDate, toDate) {
        zoneInvoicesAllTime.filter { val d = it.createdAt.toLocalDate(); !d.isBefore(fromDate) && !d.isAfter(toDate) }
    }
    val rangeCollections = remember(zoneCollectionsAllTime, fromDate, toDate) {
        zoneCollectionsAllTime.filter { val d = it.createdAt.toLocalDate(); !d.isBefore(fromDate) && !d.isAfter(toDate) }
    }
    val rangeSalesTotal = rangeInvoices.sumOf { it.total }
    val rangeCollectionTotal = rangeCollections.sumOf { it.amount }

    // ── product-wise sales, within the selected range ──
    val allProducts by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val companyWideProductValue = remember(allInvoicesCompanyWide, fromDate, toDate) {
        allInvoicesCompanyWide.filter { !it.isDeleted && !it.createdAt.toLocalDate().isBefore(fromDate) && !it.createdAt.toLocalDate().isAfter(toDate) }
            .flatMap { it.lineItems }.groupBy { it.productId }.mapValues { (_, lines) -> lines.sumOf { it.lineTotal } }
    }
    data class ZoneProductRow(val productId: String, val name: String, val photoUri: String?, val qty: Int, val value: Double, val companyPct: Double?)
    val productSales = remember(rangeInvoices, allProducts, companyWideProductValue) {
        rangeInvoices.flatMap { it.lineItems }
            .groupBy { it.productId }
            .map { (pid, lines) ->
                val value = lines.sumOf { it.lineTotal }
                val companyTotal = companyWideProductValue[pid] ?: 0.0
                ZoneProductRow(
                    productId = pid, name = lines.first().name,
                    photoUri = allProducts.firstOrNull { it.id == pid }?.photoUri,
                    qty = lines.sumOf { it.qty }, value = value,
                    companyPct = if (companyTotal > 0) (value / companyTotal * 100) else null,
                )
            }
            .sortedByDescending { it.value }.take(8)
    }
    val productMax = productSales.maxOfOrNull { it.value } ?: 0.0

    // ── date range picker ──
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("Today", "7 Days", "30 Days", "90 Days", "Custom").forEachIndexed { i, label ->
            FilterChip(
                selected = rangeMode == i,
                onClick = { rangeMode = i; if (i == 4 && customFrom == null) pickerFor = "from" },
                label = { Text(label, fontSize = 11.sp) },
            )
        }
    }
    if (rangeMode == 4) {
        Spacer(Modifier.height(Space.sm))
        Row(horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
            Box(Modifier.weight(1f)) {
                com.abm.erp.core.SecondaryButton("From: ${customFrom ?: "—"}", onClick = { pickerFor = "from" }, icon = Icons.Filled.CalendarMonth)
            }
            Box(Modifier.weight(1f)) {
                com.abm.erp.core.SecondaryButton("To: ${customTo ?: "—"}", onClick = { pickerFor = "to" }, icon = Icons.Filled.CalendarMonth)
            }
        }
    }
    Spacer(Modifier.height(Space.md))

    // ── totals for the selected range ──
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Space.md)) {
        Box(Modifier.weight(1f)) { com.abm.erp.core.MetricCard("বিক্রি", "৳${"%,.0f".format(rangeSalesTotal)}", valueColor = DarazOrange) }
        Box(Modifier.weight(1f)) { com.abm.erp.core.MetricCard("Collection", "৳${"%,.0f".format(rangeCollectionTotal)}", valueColor = StatusGreen) }
    }
    Spacer(Modifier.height(Space.md))

    // ── product-wise sales ──
    com.abm.erp.core.SectionTitle("Product-wise Sales (${fromDate} — ${toDate})")
    if (productSales.isEmpty()) {
        com.abm.erp.core.PremiumCard(padding = Space.md) {
            Text("এই সময়ে এই এলাকার ইনভয়েসে কোনো পণ্যের লাইন পাওয়া যায়নি।", fontSize = 11.sp, color = TextSecondary)
        }
    } else {
        com.abm.erp.core.PremiumCard(padding = Space.md) {
            productSales.forEach { p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (p.photoUri != null) {
                        coil.compose.AsyncImage(
                            model = p.photoUri, contentDescription = p.name,
                            modifier = Modifier.size(40.dp).background(Color(0xFFF0F1F4), RoundedCornerShape(8.dp)),
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                        )
                    } else {
                        Box(
                            Modifier.size(40.dp).background(Color(0xFFF0F1F4), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center,
                        ) { Icon(Icons.Filled.Inventory2, null, tint = TextSecondary, modifier = Modifier.size(18.dp)) }
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(p.name, fontSize = 11.sp, color = TextPrimary, maxLines = 1, modifier = Modifier.weight(1f))
                            Text("${p.qty} · ৳${"%,.0f".format(p.value)}", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(Modifier.height(4.dp))
                        Box(Modifier.fillMaxWidth().height(5.dp).background(HairlineBorder, RoundedCornerShape(999.dp))) {
                            Box(
                                Modifier.fillMaxWidth(if (productMax > 0) (p.value / productMax).toFloat().coerceIn(0f, 1f) else 0f)
                                    .fillMaxHeight().background(DarazOrange, RoundedCornerShape(999.dp)),
                            )
                        }
                        if (p.companyPct != null) {
                            Spacer(Modifier.height(3.dp))
                            Text("কোম্পানির মোট ${p.name}-বিক্রির ${"%.1f".format(p.companyPct)}% এই এলাকায় (এই সময়ে)", fontSize = 9.sp, color = TextSecondary)
                        }
                    }
                }
            }
        }
    }

    // ── calendar dialog ──
    if (pickerFor != null) {
        val state = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { pickerFor = null },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { ms ->
                        val picked = java.time.Instant.ofEpochMilli(ms).atZone(java.time.ZoneOffset.UTC).toLocalDate()
                        if (pickerFor == "from") customFrom = picked else customTo = picked
                        rangeMode = 4
                    }
                    pickerFor = null
                }) { Text("ঠিক আছে") }
            },
            dismissButton = { TextButton(onClick = { pickerFor = null }) { Text("বাতিল") } },
        ) { DatePicker(state = state) }
    }
}
