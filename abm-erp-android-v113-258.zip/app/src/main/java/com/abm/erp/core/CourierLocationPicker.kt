package com.abm.erp.core

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.data.CourierApiClient
import com.abm.erp.data.CourierPartner
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * v113-255 — the person's own direct instruction: shift Pathao/RedX's
 * area codes from manual numeric entry to fully real, auto-resolved
 * selection — real city→zone→area cascading calls for Pathao, one real
 * flat area list for RedX (confirmed against each courier's own real
 * response shape before assuming symmetry between the two). One shared
 * dialog pair, used from both the Invoice Workspace's own courier
 * section and the Courier module's own manual booking form — not two
 * separate implementations of the same real network calls.
 *
 * CourierApiClient's own functions are deliberately blocking
 * (HttpURLConnection, not suspend — matches the rest of that file), so
 * every call here runs inside withContext(Dispatchers.IO) rather than on
 * whatever dispatcher the calling composable's own coroutine scope
 * happens to use — never assumed to already be off the main thread.
 */
@Composable
fun PathaoLocationPickerDialog(
    partner: CourierPartner,
    onDismiss: () -> Unit,
    onSelected: (cityId: String, cityName: String, zoneId: String, zoneName: String, areaId: String, areaName: String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var stage by remember { mutableStateOf(0) } // 0=city 1=zone 2=area
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var cities by remember { mutableStateOf<List<CourierApiClient.LocationOption>>(emptyList()) }
    var zones by remember { mutableStateOf<List<CourierApiClient.LocationOption>>(emptyList()) }
    var areas by remember { mutableStateOf<List<CourierApiClient.LocationOption>>(emptyList()) }
    var selectedCity by remember { mutableStateOf<CourierApiClient.LocationOption?>(null) }
    var selectedZone by remember { mutableStateOf<CourierApiClient.LocationOption?>(null) }
    var query by remember { mutableStateOf("") }

    fun loadCities() {
        loading = true; error = null
        scope.launch {
            val result = withContext(Dispatchers.IO) { CourierApiClient.pathaoGetCities(partner) }
            loading = false
            if (result.success) cities = result.options else error = result.error
        }
    }
    LaunchedEffect(Unit) { loadCities() }

    fun pickCity(c: CourierApiClient.LocationOption) {
        selectedCity = c; stage = 1; query = ""; loading = true; error = null
        scope.launch {
            val result = withContext(Dispatchers.IO) { CourierApiClient.pathaoGetZones(partner, c.id) }
            loading = false
            if (result.success) zones = result.options else error = result.error
        }
    }
    fun pickZone(z: CourierApiClient.LocationOption) {
        selectedZone = z; stage = 2; query = ""; loading = true; error = null
        scope.launch {
            val result = withContext(Dispatchers.IO) { CourierApiClient.pathaoGetAreas(partner, z.id) }
            loading = false
            if (result.success) areas = result.options else error = result.error
        }
    }

    val currentList = when (stage) { 0 -> cities; 1 -> zones; else -> areas }
    val filtered = remember(currentList, query) {
        if (query.isBlank()) currentList else currentList.filter { it.name.contains(query, ignoreCase = true) }
    }

    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 480.dp)) {
                Text(
                    when (stage) { 0 -> "Pathao — City বাছুন"; 1 -> "Pathao — Zone বাছুন (${selectedCity?.name})"; else -> "Pathao — Area বাছুন (${selectedZone?.name})" },
                    fontWeight = FontWeight.Bold, color = TextPrimary,
                )
                if (stage > 0) {
                    TextButton(onClick = { if (stage == 2) { stage = 1; query = "" } else { stage = 0; query = "" } }) { Text("← আগের ধাপ") }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                error?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                if (loading) {
                    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = androidx.compose.ui.Alignment.Center) { CircularProgressIndicator() }
                } else {
                    LazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 320.dp)) {
                        items(filtered, key = { it.id }) { opt ->
                            Text(
                                opt.name, color = TextPrimary,
                                modifier = Modifier.fillMaxWidth()
                                    .clickable {
                                        when (stage) {
                                            0 -> pickCity(opt)
                                            1 -> pickZone(opt)
                                            else -> { onSelected(selectedCity!!.id, selectedCity!!.name, selectedZone!!.id, selectedZone!!.name, opt.id, opt.name); onDismiss() }
                                        }
                                    }
                                    .padding(vertical = 10.dp),
                            )
                        }
                        if (filtered.isEmpty() && !loading) item { Text("কিছু পাওয়া যায়নি।", color = TextSecondary, modifier = Modifier.padding(vertical = 12.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
fun RedxAreaPickerDialog(
    partner: CourierPartner,
    onDismiss: () -> Unit,
    onSelected: (areaId: String, areaName: String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var areas by remember { mutableStateOf<List<CourierApiClient.LocationOption>>(emptyList()) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val result = withContext(Dispatchers.IO) { CourierApiClient.redxGetAreas(partner) }
        loading = false
        if (result.success) areas = result.options else error = result.error
    }

    val filtered = remember(areas, query) {
        if (query.isBlank()) areas else areas.filter { it.name.contains(query, ignoreCase = true) }
    }

    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 480.dp)) {
                Text("RedX — Delivery Area বাছুন", fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                error?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                if (loading) {
                    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = androidx.compose.ui.Alignment.Center) { CircularProgressIndicator() }
                } else {
                    LazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 320.dp)) {
                        items(filtered, key = { it.id }) { opt ->
                            Text(
                                opt.name, color = TextPrimary,
                                modifier = Modifier.fillMaxWidth()
                                    .clickable { onSelected(opt.id, opt.name); onDismiss() }
                                    .padding(vertical = 10.dp),
                            )
                        }
                        if (filtered.isEmpty() && !loading) item { Text("কিছু পাওয়া যায়নি।", color = TextSecondary, modifier = Modifier.padding(vertical = 12.dp)) }
                    }
                }
            }
        }
    }
}
