package com.abm.erp.core

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.data.CodeRegistry
import com.abm.erp.data.createCollection
import com.abm.erp.data.rejectCollection
import com.abm.erp.data.verifyCollection
import com.abm.erp.data.MockRepository
import com.abm.erp.data.PartyType
import com.abm.erp.data.PermissionAction
import com.abm.erp.data.PermissionManager
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import kotlinx.coroutines.launch

/**
 * v113-81 — COLLECTION WORKSPACE (workspace contract, third implementation).
 * Shared by DMS · Finance (dealers) and RMS · Finance (retailers) — one component,
 * two hosts, the same pattern ModuleApprovalSection set. The whole collection
 * operation in one screen: party identify (search / QR autofill with cascade
 * re-check), outstanding due + credit context, method chips (the four the model
 * documents: CASH | BANK | MOBILE_BANKING | CHEQUE), amount entry with over-payment
 * guard, create via the real `createCollection` engine (dual-control: it books
 * PENDING and only `verifyCollection` — a different person, permission-checked —
 * moves the due), and the party's collection history inline with Verify/Reject for
 * roles that hold the approval permission. Nothing navigates away.
 *
 * `parties` arrives from the host's cascade-scoped accessor
 * (rememberVisibleDealers / rememberVisibleRetailers), so this component never
 * touches a raw registry list itself.
 */
data class CollectionParty(val id: String, val name: String, val area: String, val due: Double, val lat: Double? = null, val lng: Double? = null)

@Composable
fun CollectionWorkspace(
    partyType: PartyType,
    partyLabel: String,
    parties: List<CollectionParty>,
    onNavigate: (String) -> Unit = {},
) {
    val collections by MockRepository.partyCollections.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current
    val uploadScope = rememberCoroutineScope()

    var codeInput by remember { mutableStateOf("") }
    var codeError by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var amount by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("CASH") }
    var lastResult by remember { mutableStateOf<String?>(null) }
    // v113-249 — the person's own direct, explicit request: "মৌখিক ভেরিফাই
    // তো আর হবে না" — verification needs to be based on seeing proof of
    // the transaction, not trust. proofUri already existed on the real
    // PartyCollection model and createCollection already accepted it as a
    // parameter, but nothing anywhere in the UI ever let anyone attach
    // one (confirmed by searching the whole ui/ tree first). Same
    // create-then-upload, self-attaching pattern as every other real
    // photo capability this session (product, employee, order) —
    // uploadCollectionProof built to match uploadOrderPhoto exactly.
    var proofUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var proofUploading by remember { mutableStateOf(false) }
    val proofLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent(),
    ) { uri -> proofUri = uri }

    val party = parties.firstOrNull { it.id == selectedId }
    val partyCollections = remember(collections, selectedId) {
        if (selectedId == null) emptyList()
        else collections.filter { it.partyType == partyType && it.partyId == selectedId }.sortedByDescending { it.createdAt }
    }
    val amountValue = amount.toDoubleOrNull() ?: 0.0
    val overPay = party != null && amountValue > party.due && party.due > 0
    val canVerify = PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)
    val expectedType = if (partyType == PartyType.DEALER) CodeRegistry.CodeType.DEALER else CodeRegistry.CodeType.RETAILER

    fun applyCode() {
        codeError = null
        when (val r = CodeRegistry.resolve(codeInput)) {
            is CodeRegistry.ResolveResult.Found ->
                if (r.type == expectedType) {
                    if (parties.any { it.id == r.id }) { selectedId = r.id; codeInput = "" }
                    else codeError = "এই $partyLabel আপনার এলাকার বাইরে।"
                } else codeError = "এই কোডটি ${r.type} — এখানে $partyLabel কোড লাগবে।"
            is CodeRegistry.ResolveResult.Ambiguous -> codeError = "একই কোড একাধিক রেকর্ডে — admin-কে জানান।"
            CodeRegistry.ResolveResult.NotFound -> codeError = "কোডটি মেলেনি।"
            CodeRegistry.ResolveResult.Invalid -> codeError = "কোড খালি/অবৈধ।"
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Spacer(Modifier.height(4.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = codeInput, onValueChange = { codeInput = it },
                        placeholder = { Text("$partyLabel QR বা কোড…") }, singleLine = true, modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { applyCode() }, enabled = codeInput.isNotBlank()) { Text("Fill") }
                    IconButton(onClick = { onNavigate("universal_scanner") }) {
                        Icon(Icons.Filled.QrCodeScanner, contentDescription = "Scan", tint = TextPrimary)
                    }
                }
                codeError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
            }
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(partyLabel, fontWeight = FontWeight.Bold, color = TextPrimary)
                if (party == null) {
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        placeholder = { Text("নাম/এলাকা দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                    val matches = remember(parties, query) {
                        if (query.isBlank()) parties.filter { it.due > 0 }.sortedByDescending { it.due }.take(5)
                        else parties.filter { it.name.contains(query, true) || it.area.contains(query, true) }.take(5)
                    }
                    if (query.isBlank() && matches.isNotEmpty()) {
                        Text("সবচেয়ে বেশি due:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    // v113-278 — the person's own direct request: Finance
                    // (Collection) more organized and premium, matching
                    // the same boxy-avatar treatment already applied to
                    // Dealer/Retailer List rows (v113-273) — same real
                    // per-name hash colour, not a new palette invented
                    // just for this screen.
                    matches.forEach { p ->
                        val pAccent = browseAvatarColor(p.name)
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { selectedId = p.id; query = "" }.padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    Modifier.size(36.dp).clip(RoundedCornerShape(10.dp))
                                        .background(Brush.linearGradient(listOf(pAccent.copy(alpha = 0.85f), pAccent))),
                                    contentAlignment = Alignment.Center,
                                ) { Text(browseInitials(p.name), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(p.name, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                    Text(p.area, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                }
                            }
                            Text("৳${"%,.0f".format(p.due)}", fontWeight = FontWeight.Bold, color = if (p.due > 0) WarningAmber else SuccessGreen)
                        }
                    }
                } else {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val pAccent = browseAvatarColor(party.name)
                            Box(
                                Modifier.size(40.dp).clip(RoundedCornerShape(10.dp))
                                    .background(Brush.linearGradient(listOf(pAccent.copy(alpha = 0.85f), pAccent))),
                                contentAlignment = Alignment.Center,
                            ) { Text(browseInitials(party.name), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(party.name, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text(party.area, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                        TextButton(onClick = { selectedId = null }) { Text("বদলান") }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Outstanding Due", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("৳${"%,.0f".format(party.due)}", fontWeight = FontWeight.Bold, color = if (party.due > 0) WarningAmber else SuccessGreen)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        // v113-249 — was routing to the old statement-only
                        // screen; the person's own direct complaint about
                        // Invoice Workspace's own equivalent "Ledger" link
                        // applies exactly the same way here — routes to the
                        // same rich detail (with its own real, current Ledger
                        // tab) everywhere else in the app now uses.
                        TextButton(onClick = { onNavigate(if (partyType == PartyType.DEALER) "rich_dealer_detail/${party.id}" else "rich_retailer_detail/${party.id}") }) { Text("Full Details →") }
                        // v113-278 — the person's own direct request: same
                        // real precise-pin location action Dealer/Retailer
                        // List rows now have, here too — same real
                        // captured coordinate, same shared openMapsAt.
                        if (party.lat != null && party.lng != null) {
                            IconButton(onClick = { openMapsAt(context, party.lat, party.lng) }) {
                                Icon(Icons.Filled.LocationOn, contentDescription = "লোকেশন দেখুন", tint = Color(0xFF2563EB))
                            }
                        }
                    }
                }
            }
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Collection Entry", fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(6.dp))
                // v113-278 — small icon per method, matching the same
                // "beautiful, fully functional" request — purely visual,
                // the real four method values (CASH/BANK/MOBILE_BANKING/
                // CHEQUE) createCollection already validates, unchanged.
                val methodIcons = mapOf("CASH" to "💵", "BANK" to "🏦", "MOBILE_BANKING" to "📱", "CHEQUE" to "📝")
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("CASH", "BANK", "MOBILE_BANKING", "CHEQUE").forEach { m ->
                        FilterChip(selected = method == m, onClick = { method = m }, label = { Text("${methodIcons[m]} $m") })
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = amount, onValueChange = { amount = it },
                    label = { Text("টাকার পরিমাণ") },
                    leadingIcon = { Text("৳", fontWeight = FontWeight.Bold, color = TextSecondary, modifier = Modifier.padding(start = 14.dp)) },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                if (overPay) {
                    Text(
                        "⚠ Due-এর (৳${"%,.0f".format(party!!.due)}) চেয়ে বেশি — জমা হবে, বাড়তিটা advance হিসেবে থাকবে।",
                        color = WarningAmber, style = MaterialTheme.typography.labelSmall,
                    )
                }
                Text(
                    "Dual-control: জমা PENDING হয়ে থাকবে; অন্য কেউ (approve permission-ধারী) verify করলে তবেই due কমবে।",
                    style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                )
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { proofLauncher.launch("image/*") }) {
                        Text(if (proofUri == null) "📎 টাকা লেনদেনের ছবি সংযুক্ত করুন" else "📎 ছবি বদলান")
                    }
                    if (proofUri != null) {
                        Spacer(Modifier.width(8.dp))
                        TextButton(onClick = { proofUri = null }) { Text("✕", color = DangerRed) }
                    }
                }
                if (proofUri != null) {
                    Spacer(Modifier.height(4.dp))
                    coil.compose.AsyncImage(
                        model = proofUri, contentDescription = "লেনদেনের প্রমাণ",
                        modifier = Modifier.height(120.dp).fillMaxWidth(),
                        contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                    )
                }
                Button(
                    onClick = {
                        val p = party ?: return@Button
                        lastResult = null
                        val c = MockRepository.createCollection(
                            partyType, p.id, p.name, amountValue, method,
                            onRejected = { reason -> lastResult = "✖ $reason" },
                        )
                        if (c != null) {
                            lastResult = "✔ ${c.collectionNo} জমা হয়েছে (PENDING) — verify-এর অপেক্ষায়।"
                            val pickedProof = proofUri
                            amount = ""
                            proofUri = null
                            if (pickedProof != null) {
                                proofUploading = true
                                uploadScope.launch {
                                    MockRepository.uploadCollectionProof(context, c.id, pickedProof.toString()) { proofUploading = false }
                                }
                            }
                        }
                    },
                    enabled = party != null && amountValue > 0 && !proofUploading,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (proofUploading) "ছবি upload হচ্ছে…" else "Collection জমা দিন") }
                lastResult?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = if (it.startsWith("✔")) SuccessGreen else DangerRed) }
            }
        }

        if (partyCollections.isNotEmpty()) {
            item { Text("এই $partyLabel-এর Collection (${partyCollections.size})", fontWeight = FontWeight.SemiBold, color = TextPrimary) }
            items(partyCollections.take(10), key = { it.id }) { c ->
                // v113-278 — the person's own direct request: Finance
                // more organized — a coloured left accent by real status
                // (same statusColor helper StatusPill already uses, not
                // a second colour scheme) so scanning a longer history
                // for pending/verified/rejected doesn't need reading
                // every pill individually.
                Row(Modifier.fillMaxWidth()) {
                    Box(Modifier.width(3.dp).fillMaxHeight().background(statusColor(c.status)))
                    GlassCard(modifier = Modifier.fillMaxWidth().padding(start = 6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(c.collectionNo.ifBlank { c.id.take(8) }, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            StatusPill(c.status)
                        }
                        Text("৳${"%,.0f".format(c.amount)} · ${c.method} · ${c.createdAt.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        if (c.proofUri != null) {
                            Spacer(Modifier.height(4.dp))
                            coil.compose.AsyncImage(
                                model = c.proofUri, contentDescription = "লেনদেনের প্রমাণ",
                                modifier = Modifier.height(100.dp).fillMaxWidth(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                            )
                        } else if (c.status == "PENDING") {
                            Text("⚠ কোনো প্রমাণের ছবি সংযুক্ত করা হয়নি।", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                        }
                        if (c.status == "PENDING" && canVerify) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { MockRepository.verifyCollection(c.id, onRejected = { reason -> lastResult = "✖ $reason" }) }) { Text("✓ Verify", color = SuccessGreen) }
                                TextButton(onClick = { MockRepository.rejectCollection(c.id, onRejected = { reason -> lastResult = "✖ $reason" }) }) { Text("✗ Reject", color = DangerRed) }
                            }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
