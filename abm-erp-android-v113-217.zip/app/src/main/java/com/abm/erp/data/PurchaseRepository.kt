package com.abm.erp.data

import android.content.Context
import com.abm.erp.data.room.AppDatabase
import com.abm.erp.data.room.GoodsReceivedNoteEntity
import com.abm.erp.data.room.PurchaseOrderEntity
import com.abm.erp.data.room.PurchaseReturnEntity
import com.abm.erp.data.room.RawMaterialLotEntity
import com.abm.erp.data.room.SupplierEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset

/**
 * Module 5 — Purchase Management. Its own repository object, same pattern as
 * InventoryRepository — a GRN posting is what actually moves stock in
 * (calls InventoryRepository.stockIn) and increases the Supplier's due
 * balance, matching how a Sales Invoice moves stock out and increases a
 * Dealer's due balance. Purchase Ledger reuses the same PartyLedgerEntry
 * table as Dealer/Retailer (MockRepository.postPartyLedgerEntry) with
 * PartyType.SUPPLIER, rather than inventing a third parallel ledger shape.
 */
object PurchaseRepository {

    private lateinit var db: AppDatabase
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val firestoreDb by lazy { com.google.firebase.firestore.FirebaseFirestore.getInstance() }
    private var syncCompanyId: String? = null
    private var suppliersListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var purchaseOrdersListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var grnListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var purchaseReturnsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

    private fun syncCollection(name: String) =
        firestoreDb.collection("companies").document(CompanyContext.current.value ?: "_unset").collection(name)

    fun startCrossDeviceSync(companyId: String) {
        if (!CompanyContext.validateAndRecord(companyId)) {
            android.util.Log.w("PurchaseRepository", "startCrossDeviceSync refused invalid companyId '$companyId' — sync not started")
            return
        }
        if (companyId == syncCompanyId) return
        syncCompanyId = companyId
        listenSuppliersRemote()
        listenPurchaseOrdersRemote()
        listenPurchaseRequestsRemote()
        listenGrnRemote()
        listenPurchaseReturnsRemote()
    }

    private fun listenSuppliersRemote() {
        suppliersListenerReg?.remove()
        suppliersListenerReg = syncCollection("suppliers").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("PurchaseRepository", "suppliers sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(SupplierEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.supplierDao().upsertAll(list) }
        }
    }

    private fun listenPurchaseOrdersRemote() {
        purchaseOrdersListenerReg?.remove()
        purchaseOrdersListenerReg = syncCollection("purchaseOrders").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("PurchaseRepository", "purchaseOrders sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(PurchaseOrderEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.purchaseOrderDao().upsertAll(list) }
        }
    }

    private var purchaseRequestsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private fun listenPurchaseRequestsRemote() {
        purchaseRequestsListenerReg?.remove()
        purchaseRequestsListenerReg = syncCollection("purchaseRequests").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("PurchaseRepository", "purchaseRequests sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.PurchaseRequestEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.purchaseRequestDao().upsertAll(list) }
        }
    }

    private fun listenGrnRemote() {
        grnListenerReg?.remove()
        grnListenerReg = syncCollection("goodsReceivedNotes").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("PurchaseRepository", "goodsReceivedNotes sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(GoodsReceivedNoteEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.goodsReceivedNoteDao().upsertAll(list) }
        }
    }

    private fun listenPurchaseReturnsRemote() {
        purchaseReturnsListenerReg?.remove()
        purchaseReturnsListenerReg = syncCollection("purchaseReturns").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("PurchaseRepository", "purchaseReturns sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(PurchaseReturnEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.purchaseReturnDao().upsertAll(list) }
        }
    }

    private fun pushSupplier(e: SupplierEntity) {
        syncCollection("suppliers").document(e.id).set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "pushSupplier failed", it) }
    }

    private fun pushPurchaseOrder(e: PurchaseOrderEntity) {
        syncCollection("purchaseOrders").document(e.id).set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "pushPurchaseOrder failed", it) }
    }

    private fun pushGrn(e: GoodsReceivedNoteEntity) {
        syncCollection("goodsReceivedNotes").document(e.id).set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "pushGrn failed", it) }
    }

    private fun pushPurchaseReturn(e: PurchaseReturnEntity) {
        syncCollection("purchaseReturns").document(e.id).set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "pushPurchaseReturn failed", it) }
    }

    fun init(context: Context) {
        db = AppDatabase.getInstance(context)
        seedIfEmpty()

        suppliers = db.supplierDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        purchaseOrders = db.purchaseOrderDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        purchaseRequests = db.purchaseRequestDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        goodsReceivedNotes = db.goodsReceivedNoteDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        purchaseReturns = db.purchaseReturnDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
    }

    private fun seedIfEmpty() = runBlocking(Dispatchers.IO) {
        if (db.supplierDao().getAll().let { true } && db.purchaseOrderDao().count() == 0) {
            // Nothing seeded by default — Purchase Management starts empty on
            // a fresh install, same as Retailer did before its first
            // registration; the Foundation Layer's dedup/validation guards
            // are exercised for real starting from the very first Supplier.
        }
    }

    lateinit var suppliers: StateFlow<List<Supplier>>
        private set
    lateinit var purchaseOrders: StateFlow<List<PurchaseOrder>>
        private set
    lateinit var purchaseRequests: StateFlow<List<PurchaseRequest>>
        private set
    lateinit var goodsReceivedNotes: StateFlow<List<GoodsReceivedNote>>
        private set
    lateinit var purchaseReturns: StateFlow<List<PurchaseReturn>>
        private set

    private fun dedupKeyFor(name: String, phone: String): String = (name.trim().lowercase() + "|" + phone.trim().filter { it.isDigit() })

    /** Supplier Registration — same dedup+validation+permission pattern as MockRepository.createDealer. */
    fun createSupplier(name: String, phone: String = "", address: String = "", creditLimit: Double = 0.0, onRejected: (String) -> Unit = {}): Supplier? {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.CREATE)) {
            MockRepository.logAudit("Supplier", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            onRejected("আপনার role-এ নতুন Supplier তৈরি করার অনুমতি নেই।")
            return null
        }
        if (name.isBlank()) { onRejected("নাম দিন।"); return null }
        if (creditLimit < 0) {
            com.abm.erp.config.AppLog.w("PurchaseRepository", "createSupplier rejected: negative creditLimit")
            onRejected("Credit limit ঋণাত্মক (negative) হতে পারবে না।")
            return null
        }
        val dedupKey = dedupKeyFor(name, phone)
        var created: Supplier? = null
        runBlocking(Dispatchers.IO) {
            if (db.supplierDao().countByDedupKey(dedupKey) > 0) {
                com.abm.erp.config.AppLog.w("PurchaseRepository", "createSupplier rejected: duplicate name+phone")
                onRejected("এই নাম+ফোন দিয়ে আগে থেকেই একজন Supplier আছে।")
                return@runBlocking
            }
            val supplier = Supplier(
                id = "SUP-${java.util.UUID.randomUUID().toString().take(8)}", name = name, phone = phone, address = address,
                creditLimit = creditLimit, dedupKey = dedupKey, createdBy = MockRepository.currentUser.name,
            )
            val entity = supplier.toEntity()
            db.supplierDao().upsert(entity)
            pushSupplier(entity)
            MockRepository.logAudit("Supplier", supplier.id, "CREATE", newValue = supplier)
            created = supplier
        }
        return created
    }

    /** Universal Action Menu: Duplicate. */
    fun duplicateSupplier(supplierId: String, onRejected: (String) -> Unit = {}): DuplicateResult? {
        val s = suppliers.value.firstOrNull { it.id == supplierId } ?: run { onRejected("এই Supplier খুঁজে পাওয়া যায়নি।"); return null }
        val created = createSupplier("${s.name} (copy)", s.phone, s.address, s.creditLimit, onRejected = onRejected) ?: return null
        return DuplicateResult(created.id, created.name)
    }

    fun deleteSupplier(supplierId: String, onRejected: (String) -> Unit = {}): Boolean {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.DELETE)) { onRejected("আপনার role-এ এই কাজের অনুমতি নেই।"); return false }
        scope.launch {
            val now = System.currentTimeMillis()
            db.supplierDao().softDelete(supplierId, now, MockRepository.currentUser.name)
            syncCollection("suppliers").document(supplierId)
                .update(mapOf("isDeleted" to true, "deletedAtEpochMillis" to now, "deletedBy" to MockRepository.currentUser.name))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "push supplier-delete failed", it) }
            MockRepository.logAudit("Supplier", supplierId, "DELETE")
        }
        return true
    }

    suspend fun restoreSupplier(supplierId: String, onRejected: (String) -> Unit = {}): Boolean {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.DELETE)) { onRejected("আপনার role-এ এই কাজের অনুমতি নেই।"); return false }
        db.supplierDao().restore(supplierId)
            syncCollection("suppliers").document(supplierId)
                .update(mapOf("isDeleted" to false, "deletedAtEpochMillis" to null, "deletedBy" to null))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "push supplier-restore failed", it) }
            MockRepository.logAudit("Supplier", supplierId, "RESTORE")
        return true
    }

    // ---- Purchase Requisition / Purchase Order ----
    /** v86, Module 7 — Purchase Requisition: the missing first workflow step. Request -> approve/reject -> (if approved) convert into a real PurchaseOrder, reusing createPurchaseOrder so PO numbering/audit/notification stay single-sourced. */
    fun addSupplierQuote(requestId: String, supplierId: String, supplierName: String, quotedAmount: Double, notes: String = ""): Boolean {
        val request = purchaseRequests.value.firstOrNull { it.id == requestId } ?: return false
        val updated = request.copy(supplierQuotes = request.supplierQuotes + SupplierQuote(supplierId, supplierName, quotedAmount, notes))
        scope.launch {
            val entity = updated.toEntity()
            db.purchaseRequestDao().upsert(entity)
            syncCollection("purchaseRequests").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "push supplier-quote failed", it) }
            MockRepository.logAudit("PurchaseRequest", requestId, "QUOTE_ADDED", newValue = "$supplierName: ৳$quotedAmount")
        }
        return true
    }

    fun createPurchaseRequest(lineItems: List<PurchaseLineItem>, requiredByDate: LocalDateTime?, reason: String, onRejected: (String) -> Unit = {}): PurchaseRequest? {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.CREATE)) {
            MockRepository.logAudit("PurchaseRequest", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            onRejected("আপনার role-এ Purchase Request তৈরি করার অনুমতি নেই।")
            return null
        }
        val request = PurchaseRequest(
            id = java.util.UUID.randomUUID().toString(), requestNo = "PREQ-${1000 + purchaseRequests.value.size + 1}",
            lineItems = lineItems, requiredByDate = requiredByDate, reason = reason, createdBy = MockRepository.currentUser.name,
        )
        scope.launch {
            val entity = request.toEntity()
            db.purchaseRequestDao().upsert(entity)
            syncCollection("purchaseRequests").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "push purchaseRequest failed", it) }
            MockRepository.logAudit("PurchaseRequest", request.id, "CREATE", newValue = request)
        }
        return request
    }

    fun approvePurchaseRequest(requestId: String, onRejected: (String) -> Unit = {}): Boolean {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.APPROVE)) {
            MockRepository.logAudit("PurchaseRequest", requestId, "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "APPROVE")
            onRejected("আপনার role-এ Purchase Request approve করার অনুমতি নেই।")
            return false
        }
        val existing = purchaseRequests.value.firstOrNull { it.id == requestId }
        if (existing == null || existing.status != "PENDING") { onRejected(if (existing == null) "এই Request খুঁজে পাওয়া যায়নি।" else "এটা PENDING না — বর্তমান status: ${existing.status}।"); return false }
        // Part G — self-approval prevention. Reuses the same segregation-
        // of-duties check finalizePayroll already uses (MockRepository.
        // violatesSegregationOfDuties), not a new parallel rule.
        if (MockRepository.violatesSegregationOfDuties(MockRepository.SegregatedAction.PURCHASE_APPROVE, existing.createdBy, MockRepository.currentUser.name)) {
            MockRepository.logAudit("PurchaseRequest", requestId, "DENY", oldValue = "self-approval blocked", newValue = "APPROVE")
            onRejected("নিজের তৈরি করা Request নিজে approve করা যাবে না।")
            return false
        }
        scope.launch {
            val now = System.currentTimeMillis()
            db.purchaseRequestDao().approve(requestId, "APPROVED", MockRepository.currentUser.name, now)
            syncCollection("purchaseRequests").document(requestId)
                .update(mapOf("status" to "APPROVED", "approvedBy" to MockRepository.currentUser.name, "approvedAtEpochMillis" to now))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "push request-approve failed", it) }
            MockRepository.logAudit("PurchaseRequest", requestId, "APPROVE")
        }
        return true
    }

    fun rejectPurchaseRequest(requestId: String, reason: String, onRejected: (String) -> Unit = {}): Boolean {
        if (reason.isBlank()) { onRejected("Reject করার কারণ দিন।"); return false }
        val existing = purchaseRequests.value.firstOrNull { it.id == requestId }
        if (existing == null || existing.status != "PENDING") { onRejected(if (existing == null) "এই Request খুঁজে পাওয়া যায়নি।" else "এটা PENDING না।"); return false }
        scope.launch {
            db.purchaseRequestDao().reject(requestId, "REJECTED", reason)
            syncCollection("purchaseRequests").document(requestId).update(mapOf("status" to "REJECTED", "rejectReason" to reason))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "push request-reject failed", it) }
            MockRepository.logAudit("PurchaseRequest", requestId, "REJECT", newValue = reason)
        }
        return true
    }

    /** Only an APPROVED request may be converted; the resulting PO is created via the existing createPurchaseOrder so nothing about PO creation is duplicated. */
    suspend fun convertRequestToPurchaseOrder(requestId: String, supplierId: String, supplierName: String): PurchaseOrder? {
        val request = purchaseRequests.value.firstOrNull { it.id == requestId } ?: return null
        if (request.status != "APPROVED") {
            MockRepository.logAudit("PurchaseRequest", requestId, "DENY", oldValue = request.status, newValue = "CONVERT (must be APPROVED first)")
            return null
        }
        val po = createPurchaseOrder(supplierId, supplierName, request.lineItems) ?: return null
        scope.launch {
            db.purchaseRequestDao().markConverted(requestId, "CONVERTED", po.id)
            syncCollection("purchaseRequests").document(requestId).update(mapOf("status" to "CONVERTED", "convertedToPoId" to po.id))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "push request-convert failed", it) }
            MockRepository.logAudit("PurchaseRequest", requestId, "CONVERT", newValue = po.poNo)
        }
        return po
    }

    /** v86 - Three-way matching (PO vs GRN): compares ordered qty/value against received qty/value for a PO. No separate Supplier Invoice entity exists in this codebase, so this matches PO<->GRN (the two real, persisted documents) rather than fabricating a third. */
    data class MatchResult(val productName: String, val orderedQty: Double, val receivedQty: Double, val matched: Boolean)
    fun threeWayMatch(purchaseOrderId: String): List<MatchResult> {
        val po = purchaseOrders.value.firstOrNull { it.id == purchaseOrderId } ?: return emptyList()
        val grns = goodsReceivedNotes.value.filter { it.purchaseOrderId == purchaseOrderId }
        val receivedByProduct = grns.flatMap { it.receivedItems }.groupBy { it.productId }.mapValues { (_, items) -> items.sumOf { it.qty } }
        return po.lineItems.map { line ->
            val received = receivedByProduct[line.productId] ?: 0.0
            MatchResult(line.name, line.qty, received, kotlin.math.abs(line.qty - received) < 0.01)
        }
    }

    suspend fun createPurchaseOrder(supplierId: String, supplierName: String, lineItems: List<PurchaseLineItem>, onRejected: (String) -> Unit = {}): PurchaseOrder? {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.CREATE)) {
            MockRepository.logAudit("PurchaseOrder", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            onRejected("আপনার role-এ Purchase Order তৈরি করার অনুমতি নেই।")
            return null
        }
        // Central Number Series Engine — replaces the timestamp+random ad-hoc scheme with the one shared, mutex-guarded series.
        val poNo = MockRepository.generateNumber("PURCHASE_ORDER")
        val po = PurchaseOrder(
            id = java.util.UUID.randomUUID().toString(), poNo = poNo,
            supplierId = supplierId, supplierName = supplierName, lineItems = lineItems, createdBy = MockRepository.currentUser.name,
        )
        scope.launch {
            val entity = po.toEntity()
            db.purchaseOrderDao().upsert(entity)
            pushPurchaseOrder(entity)
            MockRepository.logAudit("PurchaseOrder", po.id, "CREATE", newValue = po)
            MockRepository.createNotification(NotificationCategory.PURCHASE_ORDER, "New Purchase Order", "${po.poNo} — $supplierName")
        }
        return po
    }

    /** Universal Action Menu: Duplicate — clones line items into a brand-new DRAFT PO. */
    suspend fun duplicatePurchaseOrder(poId: String, onRejected: (String) -> Unit = {}): DuplicateResult? {
        val po = purchaseOrders.value.firstOrNull { it.id == poId } ?: run { onRejected("এই Purchase Order খুঁজে পাওয়া যায়নি।"); return null }
        val created = createPurchaseOrder(po.supplierId, po.supplierName, po.lineItems, onRejected = onRejected) ?: return null
        return DuplicateResult(created.id, created.poNo)
    }

    fun updatePurchaseOrderStatus(poId: String, status: String) {
        scope.launch {
            db.purchaseOrderDao().setStatus(poId, status)
            syncCollection("purchaseOrders").document(poId).update("status", status)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "push po-status failed", it) }
            MockRepository.logAudit("PurchaseOrder", poId, "UPDATE", newValue = status)
        }
    }

    /**
     * GRN — Goods Received Note. This is what actually moves stock and
     * money: stock-in for every received line (via InventoryRepository,
     * same as any other stock-in) and a supplier due increase + Purchase
     * Ledger DEBIT posting (money we now owe). The PO itself never touches
     * stock or ledger — only a confirmed GRN does, since what's ordered and
     * what actually arrives can differ.
     */
    fun receiveGoods(purchaseOrderId: String, supplierId: String, supplierName: String, receivedItems: List<PurchaseLineItem>, warehouseId: String, onRejected: (String) -> Unit = {}): GoodsReceivedNote? {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.CREATE)) {
            MockRepository.logAudit("GRN", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            onRejected("আপনার role-এ Goods receive করার অনুমতি নেই।")
            return null
        }
        // Part M — guard against receiving goods against a PO that's
        // already fully RECEIVED or CANCELLED (was completely unchecked —
        // more stock could be received than was ever ordered, or against
        // a cancelled order).
        val po = purchaseOrders.value.firstOrNull { it.id == purchaseOrderId }
        if (po != null && (po.status == "RECEIVED" || po.status == "CANCELLED")) {
            com.abm.erp.config.AppLog.w("PurchaseRepository", "receiveGoods rejected: PO $purchaseOrderId is already ${po.status}")
            onRejected("এই PO ইতিমধ্যে ${po.status}।")
            return null
        }
        val grn = GoodsReceivedNote(
            id = java.util.UUID.randomUUID().toString(), grnNo = "GRN-${System.currentTimeMillis().toString().takeLast(8)}${(10..99).random()}",
            purchaseOrderId = purchaseOrderId, supplierId = supplierId, supplierName = supplierName,
            receivedItems = receivedItems, warehouseId = warehouseId, receivedBy = MockRepository.currentUser.name,
        )
        scope.launch {
            val entity = grn.toEntity()
            db.goodsReceivedNoteDao().upsert(entity)
            pushGrn(entity)
            receivedItems.forEach { line ->
                InventoryRepository.stockIn(line.productId.ifBlank { line.name }, warehouseId, line.qty, "GRN ${grn.grnNo}")
            }
            // v113-209 — real gap found while completing FMS per the
            // person's "কোনো কিছু বাকি রেখো না" instruction: RawMaterialLot(
            // the constructor) was never called ANYWHERE in the whole
            // repository — confirmed by grep, not assumed. Production's own
            // "Materials" tab (moving-average cost, requirement-vs-stock
            // summary, purchase-lot list) reads exclusively from this table,
            // so all three sections were permanently empty for any real
            // company — the GRN receiving flow above already correctly
            // stocks IN to the general InventoryRepository, but never fed
            // the separate raw-material-lot table Production actually
            // reads. No `RawMaterialLot.toEntity()` extension existed
            // either (only the reverse toDomain() direction was ever
            // built) — constructed the entity directly here, matching its
            // real field names exactly (checked directly against
            // RawMaterialLotEntity's declaration, not assumed from the
            // domain class). Every received line becomes a real lot at its
            // real received cost, dated today — the moving-average cost
            // and requirement-summary calculations already built in
            // MaterialsTab start working the moment goods are ever received.
            db.rawMaterialLotDao().upsertAll(
                receivedItems.map { line ->
                    RawMaterialLotEntity(
                        id = java.util.UUID.randomUUID().toString(),
                        materialName = line.name,
                        qtyKg = line.qty,
                        costPerKg = line.unitCost,
                        purchasedOnEpochDay = java.time.LocalDate.now().toEpochDay(),
                    )
                },
            )
            db.supplierDao().adjustDueBalance(supplierId, grn.totalValue)
            syncCollection("suppliers").document(supplierId)
                .update("dueBalance", com.google.firebase.firestore.FieldValue.increment(grn.totalValue))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "push supplier-due-increment failed", it) }
            MockRepository.postPartyLedgerEntry(PartyType.SUPPLIER, supplierId, "DEBIT", grn.totalValue, "GRN ${grn.grnNo}", entity.id)
            // v86, Module 7 — Partial Receiving fix: this used to ALWAYS set
            // "RECEIVED" regardless of whether the received quantity matched
            // what was ordered. Now it checks cumulative received qty
            // (across this and any prior GRNs against the same PO) per
            // product against the original PO line items.
            val relatedPo = purchaseOrders.value.firstOrNull { it.id == purchaseOrderId }
            if (relatedPo != null) {
                val allGrnsForPo = (goodsReceivedNotes.value + grn).filter { it.purchaseOrderId == purchaseOrderId }
                val receivedByProduct = allGrnsForPo.flatMap { it.receivedItems }.groupBy { it.productId }.mapValues { (_, items) -> items.sumOf { it.qty } }
                val fullyReceived = relatedPo.lineItems.all { (receivedByProduct[it.productId] ?: 0.0) >= it.qty }
                db.purchaseOrderDao().setStatus(purchaseOrderId, if (fullyReceived) "RECEIVED" else "PARTIALLY_RECEIVED")
                syncCollection("purchaseOrders").document(purchaseOrderId).update("status", if (fullyReceived) "RECEIVED" else "PARTIALLY_RECEIVED")
                    .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "push po-status failed", it) }
            } else {
                db.purchaseOrderDao().setStatus(purchaseOrderId, "RECEIVED")
            }
            MockRepository.logAudit("GRN", grn.id, "CREATE", newValue = grn)
            MockRepository.createNotification(NotificationCategory.GOODS_RECEIPT, "Goods Received", "${grn.grnNo} — $supplierName (৳${"%,.0f".format(grn.totalValue)})")
        }
        return grn
    }

    // ---- Purchase Return ----
    suspend fun createPurchaseReturn(purchaseOrderId: String?, supplierId: String, supplierName: String, lineItems: List<PurchaseLineItem>, reason: String, onRejected: (String) -> Unit = {}): PurchaseReturn? {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.CREATE)) { onRejected("আপনার role-এ Purchase Return তৈরি করার অনুমতি নেই।"); return null }
        val refund = lineItems.sumOf { it.lineTotal }
        // Central Number Series Engine — replaces the timestamp+random ad-hoc scheme with the one shared, mutex-guarded series.
        val returnNo = MockRepository.generateNumber("PURCHASE_RETURN")
        val purchaseReturn = PurchaseReturn(
            id = java.util.UUID.randomUUID().toString(), returnNo = returnNo,
            purchaseOrderId = purchaseOrderId, supplierId = supplierId, supplierName = supplierName,
            lineItems = lineItems, reason = reason, refundAmount = refund, createdBy = MockRepository.currentUser.name,
        )
        scope.launch {
            val entity = purchaseReturn.toEntity()
            db.purchaseReturnDao().upsert(entity)
            pushPurchaseReturn(entity)
            MockRepository.logAudit("PurchaseReturn", purchaseReturn.id, "CREATE", newValue = purchaseReturn)
        }
        return purchaseReturn
    }

    fun approvePurchaseReturn(returnId: String, onRejected: (String) -> Unit = {}): Boolean {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.APPROVE)) { onRejected("আপনার role-এ Purchase Return approve করার অনুমতি নেই।"); return false }
        val purchaseReturn = purchaseReturns.value.firstOrNull { it.id == returnId } ?: run { onRejected("এই Return খুঁজে পাওয়া যায়নি।"); return false }
        // Part M — idempotency guard (same missing-guard bug pattern found
        // and fixed in MockRepository.approveSalesReturn): without this,
        // a double-tap/retry would double-adjust supplier due balance and
        // double-post the ledger credit.
        if (purchaseReturn.status == "APPROVED") {
            com.abm.erp.config.AppLog.w("PurchaseRepository", "approvePurchaseReturn rejected: return $returnId already approved (idempotency guard)")
            onRejected("এটা ইতিমধ্যে APPROVED।")
            return false
        }
        scope.launch {
            db.purchaseReturnDao().setStatus(returnId, "APPROVED")
            syncCollection("purchaseReturns").document(returnId).update("status", "APPROVED")
                .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "push purchase-return-approve failed", it) }
            db.supplierDao().adjustDueBalance(purchaseReturn.supplierId, -purchaseReturn.refundAmount)
            MockRepository.postPartyLedgerEntry(PartyType.SUPPLIER, purchaseReturn.supplierId, "CREDIT", purchaseReturn.refundAmount, "Purchase Return ${purchaseReturn.returnNo}", returnId)
            MockRepository.logAudit("PurchaseReturn", purchaseReturn.id, "APPROVE")
        }
        return true
    }

    fun rejectPurchaseReturn(returnId: String) {
        scope.launch {
            db.purchaseReturnDao().setStatus(returnId, "REJECTED")
            syncCollection("purchaseReturns").document(returnId).update("status", "REJECTED")
                .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "push purchase-return-reject failed", it) }
            MockRepository.logAudit("PurchaseReturn", returnId, "REJECT")
        }
    }

    /** Supplier Payment — outgoing money, mirrors MockRepository.createCollection's shape but posts a CREDIT (we owe them less) instead. */
    fun createSupplierPayment(supplierId: String, amount: Double, method: String = "BANK") {
        if (amount <= 0) {
            com.abm.erp.config.AppLog.w("PurchaseRepository", "createSupplierPayment rejected: non-positive amount")
            return
        }
        scope.launch {
            db.supplierDao().adjustDueBalance(supplierId, -amount)
            syncCollection("suppliers").document(supplierId)
                .update("dueBalance", com.google.firebase.firestore.FieldValue.increment(-amount))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("PurchaseRepository", "push supplier-payment failed", it) }
            MockRepository.postPartyLedgerEntry(PartyType.SUPPLIER, supplierId, "CREDIT", amount, "Supplier payment ($method)", "")
            MockRepository.logAudit("SupplierPayment", supplierId, "CREATE", newValue = "৳$amount via $method")
        }
    }
}

// ================= Purchase Repository mappers =================

private fun Supplier.toEntity() = SupplierEntity(
    id = id, name = name, phone = phone, address = address, dueBalance = dueBalance, creditLimit = creditLimit,
    dedupKey = dedupKey, isActive = isActive, isDeleted = isDeleted, createdBy = createdBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    deletedAtEpochMillis = deletedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(), deletedBy = deletedBy,
)

private fun SupplierEntity.toDomain() = Supplier(
    id = id, name = name, phone = phone, address = address, dueBalance = dueBalance, creditLimit = creditLimit,
    dedupKey = dedupKey, isActive = isActive, isDeleted = isDeleted, createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    deletedAt = deletedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) }, deletedBy = deletedBy,
)

private fun packPurchaseLineItems(items: List<PurchaseLineItem>): String =
    items.joinToString(";") { "${it.productId},${it.name},${it.unit},${it.qty},${it.unitCost}" }

private fun unpackPurchaseLineItems(raw: String): List<PurchaseLineItem> {
    if (raw.isBlank()) return emptyList()
    return raw.split(";").filter { it.isNotBlank() }.map { record ->
        val p = record.split(",")
        PurchaseLineItem(productId = p[0], name = p[1], unit = p[2], qty = p[3].toDouble(), unitCost = p[4].toDouble())
    }
}

private fun packSupplierQuotes(quotes: List<SupplierQuote>): String =
    quotes.joinToString(";") { "${it.supplierId}|${it.supplierName}|${it.quotedAmount}|${it.notes}" }

private fun unpackSupplierQuotes(raw: String): List<SupplierQuote> {
    if (raw.isBlank() || raw == "[]") return emptyList()
    return raw.split(";").filter { it.isNotBlank() }.map { record ->
        val p = record.split("|")
        SupplierQuote(supplierId = p[0], supplierName = p[1], quotedAmount = p[2].toDouble(), notes = p.getOrElse(3) { "" })
    }
}

private fun PurchaseRequest.toEntity() = com.abm.erp.data.room.PurchaseRequestEntity(
    id = id, requestNo = requestNo, lineItemsRaw = packPurchaseLineItems(lineItems),
    requiredByEpochMillis = requiredByDate?.toInstant(ZoneOffset.UTC)?.toEpochMilli(), reason = reason, status = status,
    convertedToPoId = convertedToPoId, createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    approvedBy = approvedBy, approvedAtEpochMillis = approvedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(), rejectReason = rejectReason, isDeleted = isDeleted,
    supplierQuotesRaw = packSupplierQuotes(supplierQuotes),
)

private fun com.abm.erp.data.room.PurchaseRequestEntity.toDomain() = PurchaseRequest(
    id = id, requestNo = requestNo, lineItems = unpackPurchaseLineItems(lineItemsRaw),
    requiredByDate = requiredByEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) }, reason = reason, status = status,
    convertedToPoId = convertedToPoId, createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
    approvedBy = approvedBy, approvedAt = approvedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) }, rejectReason = rejectReason, isDeleted = isDeleted,
    supplierQuotes = unpackSupplierQuotes(supplierQuotesRaw),
)

private fun PurchaseOrder.toEntity() = PurchaseOrderEntity(
    id = id, poNo = poNo, supplierId = supplierId, supplierName = supplierName,
    lineItemsRaw = packPurchaseLineItems(lineItems), status = status, createdBy = createdBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

private fun PurchaseOrderEntity.toDomain() = PurchaseOrder(
    id = id, poNo = poNo, supplierId = supplierId, supplierName = supplierName,
    lineItems = unpackPurchaseLineItems(lineItemsRaw), status = status, createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC), isDeleted = isDeleted,
)

private fun GoodsReceivedNote.toEntity() = GoodsReceivedNoteEntity(
    id = id, grnNo = grnNo, purchaseOrderId = purchaseOrderId, supplierId = supplierId, supplierName = supplierName,
    receivedItemsRaw = packPurchaseLineItems(receivedItems), warehouseId = warehouseId, receivedBy = receivedBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

private fun GoodsReceivedNoteEntity.toDomain() = GoodsReceivedNote(
    id = id, grnNo = grnNo, purchaseOrderId = purchaseOrderId, supplierId = supplierId, supplierName = supplierName,
    receivedItems = unpackPurchaseLineItems(receivedItemsRaw), warehouseId = warehouseId, receivedBy = receivedBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC), isDeleted = isDeleted,
)

private fun PurchaseReturn.toEntity() = PurchaseReturnEntity(
    id = id, returnNo = returnNo, purchaseOrderId = purchaseOrderId, supplierId = supplierId, supplierName = supplierName,
    lineItemsRaw = packPurchaseLineItems(lineItems), reason = reason, refundAmount = refundAmount, status = status,
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

private fun PurchaseReturnEntity.toDomain() = PurchaseReturn(
    id = id, returnNo = returnNo, purchaseOrderId = purchaseOrderId, supplierId = supplierId, supplierName = supplierName,
    lineItems = unpackPurchaseLineItems(lineItemsRaw), reason = reason, refundAmount = refundAmount, status = status,
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC), isDeleted = isDeleted,
)
