package com.abm.erp.data.room

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Room table definitions. These are the on-disk, flat/serializable counterparts
 * of the rich domain models in data/Models.kt. AppRepository maps between the
 * two directions so every UI Composable keeps working against the same
 * domain types (RetailOrder, Dealer, etc.) it always did.
 *
 * Complex nested fields (lists of value objects) are stored as compact
 * delimited strings via the *Raw fields and packed/unpacked in Converters.kt,
 * to avoid pulling in a JSON library for this first persistence pass.
 */

@Entity(tableName = "companies")
data class CompanyEntity(
    @PrimaryKey val id: String,
    val name: String,
    val address: String = "",
    val logoUrl: String? = null,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "app_users")
data class AppUserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val role: String,
    val companyId: String,
    val zone: String,
    val territoryId: String? = null,
    val phone: String = "",
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdAtEpochMillis: Long = 0,
)

@Entity(
    tableName = "administrative_locations",
    indices = [Index("officialCode"), Index("type"), Index("parentId"), Index("divisionId"), Index("districtId"), Index("upazilaId"), Index("nameEn"), Index("nameBn"), Index("normalizedName"), Index("active")],
)
data class AdministrativeLocationEntity(
    @PrimaryKey val id: String = "",
    val officialCode: String? = null, // null = no official BBS code available in the imported source (honestly disclosed — this dataset has none)
    val sourceCode: String = "", // stable local id from the source dataset, used as identity since officialCode is absent
    val type: String = "", // COUNTRY | DIVISION | DISTRICT | UPAZILA | THANA | UNION | CITY_CORPORATION | POURASHAVA | WARD | MARKET | BAZAAR
    val nameEn: String = "",
    val nameBn: String = "",
    val normalizedName: String = "",
    val parentId: String? = null,
    val countryCode: String = "BD",
    val divisionId: String? = null,
    val districtId: String? = null,
    val upazilaId: String? = null,
    val unionOrMunicipalityId: String? = null,
    val wardId: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val polygonRaw: String = "", // "lat1,lng1;lat2,lng2;..." packed, only populated for types with bundled boundary data (currently DISTRICT)
    val sourceName: String = "",
    val sourceUrl: String = "",
    val sourceVersion: String = "",
    val effectiveFromEpochDay: Long? = null,
    val effectiveToEpochDay: Long? = null,
    val active: Boolean = true,
    val verified: Boolean = false,
    val createdAtEpochMillis: Long = 0,
    val updatedAtEpochMillis: Long = 0,
    val syncStatus: String = "SYNCED",
)

/** Section 12 — company-created market/bazaar, explicitly distinct from official government administrative records (never mixed into administrative_locations as if authoritative). */
@Entity(
    tableName = "company_markets",
    indices = [Index("parentAdminId"), Index("verificationStatus")],
)
data class CompanyMarketEntity(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val parentAdminId: String = "", // an administrative_locations.id (typically an UPAZILA or UNION)
    val latitude: Double? = null,
    val longitude: Double? = null,
    val source: String = "COMPANY_CREATED",
    val verificationStatus: String = "UNVERIFIED", // UNVERIFIED | FIELD_VERIFIED | MANAGER_APPROVED
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(
    tableName = "user_accounts",
    indices = [Index("employeeProfileId"), Index("companyId"), Index("active")],
)
data class UserAccountEntity(
    @PrimaryKey val id: String = "",
    val employeeProfileId: String = "",
    val companyId: String = "",
    val pinHash: String = "",
    val pinSalt: String = "",
    val pinIterations: Int = 120_000,
    val pinSetAtEpochMillis: Long = 0,
    val pinExpiresAtEpochMillis: Long? = null,
    val failedAttempts: Int = 0,
    val lockedUntilEpochMillis: Long? = null,
    val active: Boolean = true,
    val locked: Boolean = false,
    val mustChangePinOnNextLogin: Boolean = false,
    val createdAtEpochMillis: Long = 0,
    val updatedAtEpochMillis: Long = 0,
)

/** Part A — real per-attempt lockout ledger, so lockout survives app restart and is auditable, unlike an in-memory counter. */
@Entity(tableName = "login_attempts", indices = [Index("userAccountId"), Index("attemptedAtEpochMillis")])
data class LoginAttemptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userAccountId: String = "",
    val success: Boolean = false,
    val deviceId: String? = null,
    val attemptedAtEpochMillis: Long = 0,
)

@Entity(tableName = "territories")
data class TerritoryEntity(
    @PrimaryKey val id: String = "",
    val division: String = "",
    val district: String? = null,
    val market: String? = null,
    val parentTerritoryId: String? = null,
    val zoneName: String? = null,
    val country: String = "Bangladesh",
    val upazila: String? = null,
    val area: String? = null,
    val beat: String? = null,
    val code: String = "",
    val polygonRaw: String = "", // "lat1,lng1;lat2,lng2;..." — packed the same way this codebase already packs other ordered lists (e.g. BomLine)
    val polygonVersion: Int = 0,
    val defaultVisitRadiusMeters: Double = 100.0,
    val isActive: Boolean = true,
    val effectiveFromEpochDay: Long? = null,
    val effectiveToEpochDay: Long? = null,
    val assignedManagerIdsRaw: String = "", // comma-separated
    val assignedOfficerIdsRaw: String = "",
)

@Entity(tableName = "transfer_requests")
data class TransferRequestEntity(
    @PrimaryKey val id: String = "",
    val employeeId: String = "",
    val employeeName: String = "",
    val transferType: String = "",
    val fromValue: String = "",
    val toValue: String = "",
    val newManagerId: String? = null,
    val effectiveDateEpochDay: Long = 0,
    val reason: String = "",
    val retailerHandoverToEmployeeId: String? = null,
    val stage: String = "DRAFT",
    val rejectReason: String? = null,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "delegations")
data class DelegationEntity(
    @PrimaryKey val id: String = "",
    val delegatorId: String = "",
    val delegatorName: String = "",
    val delegateId: String = "",
    val delegateName: String = "",
    val scope: String = "",
    val financialLimit: Double = 0.0,
    val startDateEpochDay: Long = 0,
    val endDateEpochDay: Long = 0,
    val reason: String = "",
    val isActive: Boolean = true,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(
    tableName = "security_events",
    indices = [Index("employeeId"), Index("createdAtEpochMillis")],
)
data class SecurityEventEntity(
    @PrimaryKey val id: String = "",
    val type: String = "",
    val severity: String = "WARNING",
    val employeeId: String = "",
    val employeeName: String = "",
    val territoryId: String? = null,
    val action: String = "",
    val lat: Double? = null,
    val lng: Double? = null,
    val distanceMeters: Double? = null,
    val message: String = "",
    val deviceId: String? = null,
    val isReviewed: Boolean = false,
    val reviewedBy: String? = null,
    val reviewedAtEpochMillis: Long? = null,
    val reviewAction: String? = null,
    val reviewComment: String? = null,
    val createdAtEpochMillis: Long = 0,
)

@Entity(
    tableName = "geo_overrides",
    indices = [Index("employeeId")],
)
data class GeoOverrideEntity(
    @PrimaryKey val id: String = "",
    val employeeId: String = "",
    val employeeName: String = "",
    val actionType: String = "",
    val reason: String = "",
    val approvedBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val expiresAtEpochMillis: Long = 0,
    val used: Boolean = false,
    val usedAtEpochMillis: Long? = null,
)

@Entity(
    tableName = "executive_exceptions",
    indices = [Index("type"), Index("status"), Index("createdAtEpochMillis")],
)
data class ExecutiveExceptionEntity(
    @PrimaryKey val id: String = "",
    val type: String = "",
    val severity: String = "WARNING",
    val source: String = "",
    val companyId: String = "",
    val branch: String = "",
    val territoryId: String? = null,
    val responsiblePerson: String = "",
    val message: String = "",
    val impact: String = "",
    val recommendedAction: String = "",
    val status: String = "NEW",
    val assignedReviewer: String? = null,
    val resolutionNote: String? = null,
    val dedupKey: String = "",
    val createdAtEpochMillis: Long = 0,
    val updatedAtEpochMillis: Long = 0,
)

@Entity(
    tableName = "management_actions",
    indices = [Index("assignedTo"), Index("status")],
)
data class ManagementActionEntity(
    @PrimaryKey val id: String = "",
    val title: String = "",
    val sourceExceptionId: String? = null,
    val assignedTo: String = "",
    val priority: String = "NORMAL",
    val dueDateEpochDay: Long? = null,
    val status: String = "OPEN",
    val comment: String = "",
    val evidence: String = "",
    val completionNote: String? = null,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(
    tableName = "decision_query_audit",
    indices = [Index("askedBy")],
)
data class DecisionQueryAuditEntity(
    @PrimaryKey val id: String = "",
    val question: String = "",
    val matchedIntent: String? = null,
    val askedBy: String = "",
    val resultSummary: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "production_plans")
data class ProductionPlanEntity(
    @PrimaryKey val id: String = "",
    val planNumber: String = "",
    val companyId: String = "",
    val productId: String = "",
    val variant: String? = null,
    val plannedQuantity: Double = 0.0,
    val unit: String = "kg",
    val batchNumber: String = "",
    val productionDateEpochDay: Long = 0,
    val manufacturingUnitId: String = "",
    val productionLine: String? = null,
    val shiftType: String = "GENERAL",
    val supervisorEmployeeId: String? = null,
    val status: String = "DRAFT",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "raw_material_issues")
data class RawMaterialIssueEntity(
    @PrimaryKey val id: String = "",
    val productionPlanId: String = "",
    val companyId: String = "",
    val materialProductId: String = "",
    val warehouseId: String? = null,
    val binLocation: String? = null,
    val batchCode: String? = null,
    val issuedQuantity: Double = 0.0,
    val consumedQuantity: Double = 0.0,
    val returnedQuantity: Double = 0.0,
    val wastedQuantity: Double = 0.0,
    val issuedBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "quality_inspections")
data class QualityInspectionEntity(
    @PrimaryKey val id: String = "",
    val productionPlanId: String? = null,
    val batchId: String? = null,
    val transferId: String? = null,
    val companyId: String = "",
    val inspector: String = "",
    val testParameters: String? = null,
    val result: String = "PENDING",
    val sampleQuantity: Double = 0.0,
    val rejectedQuantity: Double = 0.0,
    val comment: String? = null,
    val attachmentUri: String? = null,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "packing_records")
data class PackingRecordEntity(
    @PrimaryKey val id: String = "",
    val productionPlanId: String = "",
    val companyId: String = "",
    val bulkQuantityReceived: Double = 0.0,
    val packingSize: Double = 0.0,
    val numberOfPacks: Int = 0,
    val numberOfCartons: Int = 0,
    val looseQuantity: Double = 0.0,
    val damagedPacks: Int = 0,
    val wastageQuantity: Double = 0.0,
    val finalAcceptedQuantity: Double = 0.0,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "cartons")
data class CartonEntity(
    @PrimaryKey val id: String = "",
    val cartonCode: String = "",
    val companyId: String = "",
    val productionPlanId: String = "",
    val productId: String = "",
    val productName: String = "",
    val batchCode: String? = null,
    val quantityInside: Double = 0.0,
    val unit: String = "",
    val status: String = "PACKED",
    val packedBy: String = "",
    val packedAtEpochMillis: Long = 0,
    val warehouseId: String? = null,
    val warehouseReceivedBy: String? = null,
    val warehouseReceivedAtEpochMillis: Long? = null,
    val dispatchedTo: String? = null,
    val dispatchedBy: String? = null,
    val dispatchedAtEpochMillis: Long? = null,
    val deliveredBy: String? = null,
    val deliveredAtEpochMillis: Long? = null,
)

@Entity(tableName = "finished_goods_receipts")
data class FinishedGoodsReceiptEntity(
    @PrimaryKey val id: String = "",
    val productionPlanId: String = "",
    val companyId: String = "",
    val productId: String = "",
    val batchCode: String = "",
    val manufacturingDateEpochDay: Long = 0,
    val expiryDateEpochDay: Long? = null,
    val quantity: Double = 0.0,
    val unit: String = "kg",
    val warehouseId: String = "",
    val unitCost: Double = 0.0,
    val qcStatus: String = "PENDING",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "warehouse_transfers")
data class WarehouseTransferEntity(
    @PrimaryKey val id: String = "",
    val transferNumber: String = "",
    val companyId: String = "",
    val sourceWarehouseId: String = "",
    val destinationWarehouseId: String = "",
    val linesRaw: String = "",
    val requestedBy: String = "",
    val approvedBy: String? = null,
    val vehicle: String? = null,
    val driver: String? = null,
    val dispatchDateEpochMillis: Long? = null,
    val expectedDeliveryDateEpochDay: Long? = null,
    val notes: String? = null,
    val status: String = "DRAFT",
    val dispatchChallanNumber: String? = null,
    val dispatchedBy: String? = null,
    val dispatchedAtEpochMillis: Long? = null,
    val attachmentUri: String? = null,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "warehouse_receipts")
data class WarehouseReceiptEntity(
    @PrimaryKey val id: String = "",
    val transferId: String = "",
    val companyId: String = "",
    val receivingWarehouseId: String = "",
    val binLocation: String? = null,
    val receiver: String = "",
    val comment: String? = null,
    val proofUri: String? = null,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "employee_permission_overrides")
data class EmployeePermissionOverrideEntity(
    @PrimaryKey val id: String = "",
    val employeeId: String = "",
    val companyId: String = "",
    val moduleKey: String = "",
    val accessLevel: String = "VIEW_ONLY",
    val setBy: String = "",
    val setByName: String = "",
    val setAtEpochMillis: Long = 0,
)

@Entity(tableName = "correction_requests")
data class CorrectionRequestEntity(
    @PrimaryKey val id: String = "",
    val companyId: String = "",
    val module: String = "",
    val recordId: String = "",
    val correctionType: String = "EDIT",
    val reason: String = "",
    val proposedChangeJson: String = "",
    val originalValueJson: String = "",
    val requestedBy: String = "",
    val requestedByName: String = "",
    val managerReviewedBy: String? = null,
    val managerComment: String? = null,
    val chairmanApprovedBy: String? = null,
    val chairmanComment: String? = null,
    val status: String = "SUBMITTED",
    val reversalEntryId: String? = null,
    val correctedEntryId: String? = null,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "accounting_period_locks")
data class AccountingPeriodLockEntity(
    @PrimaryKey val id: String = "",
    val companyId: String = "",
    val scope: String = "MONTH",
    val periodStartEpochDay: Long = 0,
    val periodEndEpochDay: Long = 0,
    val lockedBy: String = "",
    val lockedByName: String = "",
    val isLocked: Boolean = true,
    val lockedAtEpochMillis: Long = 0,
    val unlockedBy: String? = null,
    val unlockedAtEpochMillis: Long? = null,
)

@Entity(tableName = "number_series_configs")
data class NumberSeriesConfigEntity(
    @PrimaryKey val id: String = "",
    val companyId: String = "",
    val companyPrefix: String = "ABM",
    val branchPrefix: String? = null,
    val useFinancialYear: Boolean = true,
    val fiscalYearStartMonth: Int = 7,
    val currentRunningNumber: Long = 0,
    val padWidth: Int = 5,
)

@Entity(tableName = "ownership_transfer_records")
data class OwnershipTransferRecordEntity(
    @PrimaryKey val id: String = "",
    val companyId: String = "",
    val scope: String = "",
    val entityId: String = "",
    val fromEmployeeId: String? = null,
    val toEmployeeId: String = "",
    val reason: String = "",
    val transferredBy: String = "",
    val transferredAtEpochMillis: Long = 0,
)

@Entity(tableName = "business_rules")
data class BusinessRuleEntity(
    @PrimaryKey val key: String = "",
    val label: String = "",
    val type: String = "PERCENTAGE",
    val value: Double = 0.0,
    val companyId: String = "",
    val updatedBy: String = "",
    val updatedByName: String = "",
    val updatedAtEpochMillis: Long = 0,
)

@Entity(tableName = "company_settings")
data class CompanySettingsEntity(
    @PrimaryKey val id: String = "",
    val companyName: String = "",
    val companyAddress: String = "",
    val companyPhone: String = "",
    val companyEmail: String = "",
    val fiscalYearStartMonth: Int = 7,
    val taxVatNumber: String = "",
    val vatPct: Double = 0.0,
    val currencyCode: String = "BDT",
    val currencySymbol: String = "৳",
    val numberFormatPattern: String = "#,##0.00",
    val workingDaysRaw: String = "SUNDAY,MONDAY,TUESDAY,WEDNESDAY,THURSDAY",
    val holidaysRaw: String = "",
    val attendancePolicyNote: String = "",
    val payrollPolicyNote: String = "",
    val invoicePolicyNote: String = "",
    val dealerPolicyNote: String = "",
    val targetPolicyNote: String = "",
    val updatedBy: String = "",
    val updatedAtEpochMillis: Long = 0,
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey val id: String = "",
    val expenseNo: String = "",
    val companyId: String = "",
    val category: String = "",
    val amount: Double = 0.0,
    val description: String = "",
    val paymentMethod: String = "CASH",
    val submittedBy: String = "",
    val submittedByEmployeeId: String = "",
    val status: String = "PENDING",
    val approvedBy: String? = null,
    val rejectReason: String? = null,
    val attachmentUri: String? = null,
    val createdAtEpochMillis: Long = 0,
    val approvedAtEpochMillis: Long? = null,
)

@Entity(tableName = "vacancies")
data class VacancyEntity(
    @PrimaryKey val id: String = "",
    val companyId: String = "",
    val designation: String = "",
    val department: String = "",
    val territoryId: String? = null,
    val requestedBy: String = "",
    val requestedByName: String = "",
    val reason: String? = null,
    val status: String = "DRAFT",
    val approvedBy: String? = null,
    val filledByEmployeeId: String? = null,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "targets")
data class TargetEntity(
    @PrimaryKey val id: String = "",
    val companyId: String = "",
    val scopeType: String = "",
    val scopeId: String = "",
    val parentTargetId: String? = null,
    val periodType: String = "",
    val periodStartEpochDay: Long = 0,
    val periodEndEpochDay: Long = 0,
    val targetType: String = "",
    val targetValue: Double = 0.0,
    val achievedValue: Double = 0.0,
    val isOverride: Boolean = false,
    val overrideReason: String? = null,
    val status: String = "ACTIVE",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "target_change_logs")
data class TargetChangeLogEntity(
    @PrimaryKey val id: String = "",
    val targetId: String = "",
    val oldValue: Double? = null,
    val newValue: Double? = null,
    val reason: String = "",
    val changedBy: String = "",
    val changedByName: String = "",
    val changedAtEpochMillis: Long = 0,
)

@Entity(tableName = "manufacturing_worker_assignments")
data class ManufacturingWorkerAssignmentEntity(
    @PrimaryKey val id: String = "",
    val employeeId: String = "",
    val companyId: String = "",
    val manufacturingUnitId: String = "",
    val productionLine: String? = null,
    val machine: String? = null,
    val section: String? = null,
    val shiftType: String = "GENERAL",
    val supervisorEmployeeId: String? = null,
    val skillsRaw: String = "",
    val startDateEpochDay: Long = 0,
    val endDateEpochDay: Long? = null,
    val isActive: Boolean = true,
    val assignedBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "employee_appraisals")
data class EmployeeAppraisalEntity(
    @PrimaryKey val id: String = "",
    val employeeId: String = "",
    val companyId: String = "",
    val periodStartEpochDay: Long = 0,
    val periodEndEpochDay: Long = 0,
    val salesTarget: Double = 0.0,
    val salesAchievement: Double = 0.0,
    val collectionTarget: Double = 0.0,
    val collectionAchievement: Double = 0.0,
    val attendancePresentDays: Int = 0,
    val attendanceTotalDays: Int = 0,
    val punctualityLateDays: Int = 0,
    val dealerVisits: Int = 0,
    val retailerVisits: Int = 0,
    val newDealerAcquisition: Int = 0,
    val newRetailerAcquisition: Int = 0,
    val returnRatePct: Double = 0.0,
    val complaintCount: Int = 0,
    val supervisorScore: Double? = null,
    val hrScore: Double? = null,
    val managerComment: String? = null,
    val employeeAcknowledged: Boolean = false,
    val employeeAcknowledgedAtEpochMillis: Long? = null,
    val finalScore: Double? = null,
    val rating: String? = null,
    val recognitionsRaw: String = "", // comma-joined RecognitionType names
    val generatedBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "employee_area_assignments")
data class EmployeeAreaAssignmentEntity(
    @PrimaryKey val id: String = "",
    val employeeId: String = "",
    val companyId: String = "",
    val divisionId: String? = null,
    val divisionName: String? = null,
    val districtId: String? = null,
    val districtName: String? = null,
    val upazilaId: String? = null,
    val upazilaName: String? = null,
    val unionId: String? = null,
    val unionName: String? = null,
    val marketName: String? = null,
    val routeId: String? = null,
    val assignmentType: String = "PRIMARY",
    val startDateEpochDay: Long = 0,
    val endDateEpochDay: Long? = null,
    val assignedBy: String = "",
    val approvalStatus: String = "APPROVED",
    val isActive: Boolean = true,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "employee_profiles")
data class EmployeeProfileEntity(
    @PrimaryKey val id: String = "",
    val employeeCode: String = "",
    val userAccountId: String? = null,
    val fullName: String = "",
    val mobile: String = "",
    val email: String = "",
    val department: String = "",
    val employeeType: String = "OFFICE", // see EmployeeProfile.employeeType
    val designation: String = "",
    val role: String = "SR",
    val grade: String = "",
    val employmentType: String = "PERMANENT",
    val joiningDateEpochDay: Long? = null,
    val status: String = "DRAFT",
    val statusReason: String? = null,
    val companyId: String = "",
    val branch: String = "",
    val region: String = "",
    val area: String = "",
    val territoryId: String? = null,
    val routeId: String? = null,
    val branchId: String? = null,
    val departmentId: String? = null,
    val divisionId: String? = null,
    val districtId: String? = null,
    val upazilaId: String? = null,
    val unionId: String? = null,
    val directManagerId: String? = null,
    val secondaryManagerId: String? = null,
    val functionalManagerId: String? = null,
    val reportingEffectiveFromEpochDay: Long? = null,
    val reportingEffectiveToEpochDay: Long? = null,
    val tempManagerId: String? = null,
    val tempAssignmentFromEpochDay: Long? = null,
    val tempAssignmentToEpochDay: Long? = null,
    val approvalAuthorityLevel: Int = 0,
    val financialApprovalLimit: Double = 0.0,
    val creditOverrideLimit: Double = 0.0,
    val discountApprovalLimitPct: Double = 0.0,
    val stockAdjustmentApprovalLimit: Double = 0.0,
    val purchaseApprovalLimit: Double = 0.0,
    val leaveApprovalAuthority: Boolean = false,
    val attendanceCorrectionAuthority: Boolean = false,
    val dataAccessScope: String = "SELF",
    val onboardingStatus: String = "DRAFT",
    val rejectReason: String? = null,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val updatedBy: String = "",
    val updatedAtEpochMillis: Long? = null,
    val isDeleted: Boolean = false,
    val deletedAtEpochMillis: Long? = null,
    val deletedBy: String? = null,
    val nationalId: String? = null,
    val dateOfBirthEpochDay: Long? = null,
    val workLocation: String? = null,
    val emergencyContactName: String? = null,
    val emergencyContactPhone: String? = null,
    val profilePhotoUri: String? = null,
    val basePayMonthly: Double = 0.0,
    val assignedTemplateKey: String? = null,
)

@Entity(
    tableName = "retailer_location_history",
    indices = [Index("retailerId"), Index("changedAtEpochMillis")],
)
data class RetailerLocationHistoryEntity(
    @PrimaryKey val id: String = "",
    val retailerId: String = "",
    val previousLat: Double? = null,
    val previousLng: Double? = null,
    val previousAccuracyMeters: Double? = null,
    val newLat: Double = 0.0,
    val newLng: Double = 0.0,
    val newAccuracyMeters: Double? = null,
    val changeReason: String = "",
    val changedBy: String = "",
    val changedAtEpochMillis: Long = 0,
    val distanceFromPreviousMeters: Double? = null,
    val revisionNumber: Int = 0,
)

@Entity(
    tableName = "employee_location_snapshots",
    indices = [Index("employeeId"), Index("capturedAtEpochMillis"), Index("visitId")],
)
data class EmployeeLocationSnapshotEntity(
    @PrimaryKey val id: String = "",
    val employeeId: String = "",
    val employeeName: String = "",
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val accuracyMeters: Float? = null,
    val provider: String? = null,
    val batteryPct: Int? = null,
    val mockSuspected: Boolean = false,
    val deviceId: String? = null,
    val visitId: String? = null,
    val routeId: String? = null,
    val capturedAtEpochMillis: Long = 0,
    val syncStatus: String = "SYNCED",
)

@Entity(
    tableName = "location_alerts",
    indices = [Index("employeeId"), Index("retailerId"), Index("type"), Index("isReviewed")],
)
data class LocationAlertEntity(
    @PrimaryKey val id: String = "",
    val type: String = "",
    val severity: String = "INFO",
    val employeeId: String? = null,
    val retailerId: String? = null,
    val visitId: String? = null,
    val message: String = "",
    val evidenceJson: String? = null,
    val isReviewed: Boolean = false,
    val reviewedBy: String? = null,
    val reviewedAtEpochMillis: Long? = null,
    val reviewAction: String? = null,
    val reviewComment: String? = null,
    val createdAtEpochMillis: Long = 0,
)

@Entity(
    tableName = "trusted_devices",
    indices = [Index("employeeId"), Index("deviceId")],
)
data class TrustedDeviceEntity(
    @PrimaryKey val id: String = "",
    val deviceId: String = "",
    val employeeId: String = "",
    val firstRegisteredAtEpochMillis: Long = 0,
    val lastActiveAtEpochMillis: Long = 0,
    val status: String = "APPROVED",
    val osVersion: String = "",
    val appVersion: String = "",
    val lastLocationAtEpochMillis: Long? = null,
    val mockSuspicionCount: Int = 0,
    val failedVerificationCount: Int = 0,
)

@Entity(tableName = "retailers")
data class RetailerEntity(
    @PrimaryKey val id: String = "",
    val retailerCode: String = "",
    val name: String = "",
    val ownerName: String = "",
    val phone: String = "",
    val altPhone: String = "",
    val email: String = "",
    val address: String = "",
    val district: String = "",
    val upazila: String = "",
    val union_: String = "",
    val market: String = "",
    val area: String = "",
    val postalCode: String = "",
    val territoryId: String? = null,
    val dealerId: String? = null,
    val lat: Double? = null,
    val lng: Double? = null,
    val gpsAccuracyMeters: Double? = null,
    val geoCapturedAtEpochMillis: Long? = null,
    val photoUri: String? = null,
    val ownerPhotoUri: String? = null,
    val tradeLicenseNo: String = "",
    val nidRef: String = "",
    val qrCode: String? = null,
    val dedupKey: String = "",
    val classification: String = "B",
    val businessStatus: String = "ACTIVE",
    val statusReason: String? = null,
    val openingDateEpochDay: Long? = null,
    val officerId: String? = null,
    val officerName: String = "",
    val paymentTermsDays: Int = 0,
    val allowedCreditDays: Int = 0,
    val lastCollectionDateEpochMillis: Long? = null,
    val lastOrderDateEpochMillis: Long? = null,
    val lastVisitDateEpochMillis: Long? = null,
    val nextPlannedVisitEpochMillis: Long? = null,
    val preferredProducts: String = "",
    val notes: String = "",
    val tags: String = "",
    // v113-203 — self-service Retailer login (mirrors Dealer's own pin/pinHash/
    // pinSalt/pinIterations exactly, same PinHashing.createHash/verify calls).
    val pinHash: String? = null,
    val pinSalt: String? = null,
    val pinIterations: Int = 120_000,
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val updatedBy: String = "",
    val updatedAtEpochMillis: Long? = null,
    val deletedAtEpochMillis: Long? = null,
    val deletedBy: String? = null,
    val dueBalance: Double = 0.0,
    val creditLimit: Double = 0.0,
    val creditHold: Boolean = false,
    val creditHoldReason: String? = null,
    val outletCategory: String = "General Store",
    val outletType: String = "Retail",
    val routeId: String? = null,
    val onboardingStatus: String = "ACTIVE",
    val rejectReason: String? = null,
    val standardDiscountPct: Double = 0.0,
    val commissionPct: Double = 0.0,
    val locationProvider: String? = null,
    val locationCapturedByEmployeeId: String? = null,
    val locationCapturedDeviceId: String? = null,
    val locationCaptureMethod: String = "GPS",
    val locationVerificationStatus: String = "NOT_CAPTURED",
    val locationVerificationScore: Int? = null,
    val locationVerifiedBy: String? = null,
    val locationVerifiedAtEpochMillis: Long? = null,
    val locationVerificationComment: String? = null,
    val geofenceRadiusMeters: Double? = null,
    val lastLocationUpdateReason: String? = null,
    val locationRevision: Int = 0,
)

@Entity(tableName = "role_definitions")
data class RoleDefinitionEntity(
    @PrimaryKey val role: String = "",
    val label: String = "",
    val modulePermissionsRaw: String = "", // packed ModulePermission list, see Converters.packModulePermissions
)

@Entity(tableName = "retail_orders")
data class RetailOrderEntity(
    @PrimaryKey val id: String = "",
    val orderNo: String = "",
    val retailerName: String = "",
    val loggedBySoId: String = "",
    val zone: String = "",
    val items: String = "",
    // Structured line items, added in v71. The free-text `items` above is deliberately kept
    // and still written, because existing logic (quantity extraction, display, exports) reads
    // it — this is additive, not a replacement.
    val lineItemsRaw: String = "",
    val amount: Double = 0.0,
    val stage: String = "SO_LOGGED",
    val routedDealerId: String? = null,
    val loggedAtEpochMillis: Long = 0,
    val retailerPhotoUri: String? = null,
    val retailerLat: Double? = null,
    val retailerLng: Double? = null,
    val retailerQrCode: String? = null,
    val channel: String = "retail",
    val anonymous: Boolean = false,
    val photoPurpose: String? = null,
    val retailerId: String? = null,
)

@Entity(tableName = "dealers")
data class DealerEntity(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val zone: String = "",
    val dueBalance: Double = 0.0,
    val salesLast90Days: Double = 0.0,
    val pin: String = "0000",
    val pinHash: String? = null,
    val pinSalt: String? = null,
    val pinIterations: Int = 120_000,
    val stockUnits: Int = 0,
    val phone: String = "",
    val address: String = "",
    val territoryId: String? = null,
    val divisionId: String? = null,
    val districtId: String? = null,
    val upazilaId: String? = null,
    val unionId: String? = null,
    val wardId: String? = null,
    val routeId: String? = null,
    val legacyAddressResolved: Boolean = false,
    val dedupKey: String = "",
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val deletedAtEpochMillis: Long? = null,
    val deletedBy: String? = null,
    val classification: String = "B",
    val creditLimit: Double = 0.0,
    // v86, Module 3 — Weekly 50% Due Rule (additive fields, Room version 24 migration below).
    val monthlyTarget: Double = 0.0, // 0 = rule not configured for this dealer yet; eligibility check is skipped rather than fabricating a target
    val weeklyPaidAmount: Double = 0.0, // running total collected against the CURRENT week only; reset when weekStartEpochDay rolls over
    val weekStartEpochDay: Long = 0, // epoch-day of the Monday this weeklyPaidAmount total belongs to
    val creditStatus: String = "ACTIVE", // ACTIVE | WARNING | SUSPENDED | TEMPORARILY_APPROVED
    val creditStatusReason: String? = null, // required comment when a manager manually overrides status
    val creditStatusChangedBy: String? = null,
    val creditStatusChangedAtEpochMillis: Long? = null,
    // v86, Module 3/5 — Promise-to-Pay / Broken Commitment tracking.
    val promiseToPayEpochMillis: Long? = null,
    val promiseToPayAmount: Double = 0.0,
    val promiseNote: String? = null,
    // Phase 1 additions
    val dealerCode: String = "",
    val proprietorName: String = "",
    val altPhone: String = "",
    val nationalId: String? = null,
    val email: String? = null,
    val marketName: String? = null,
    val lat: Double? = null,
    val lng: Double? = null,
    val assignedEmployeeId: String? = null,
    val assignedManagerId: String? = null,
    val openingBalance: Double = 0.0,
    val paymentTermsDays: Int = 0,
    val tradeLicenseNumber: String? = null,
    val notes: String? = null,
    val status: String = "DRAFT",
    val approvedBy: String? = null,
    val approvedByName: String? = null,
    val approvedAtEpochMillis: Long? = null,
    val approvalComment: String? = null,
    val previousStatus: String? = null,
    val resolvedApprovalPath: String? = null,
    // v113-147 — additive (v76→v77). Dealer was the ONLY party entity without a
    // photo slot: Retailer has photoUri + ownerPhotoUri, Product has photoUri and
    // EmployeeProfile has profilePhotoUri. Nullable so every existing dealer row
    // migrates untouched.
    val photoUri: String? = null,
)

@Entity(tableName = "bulk_dealer_requests")
data class BulkDealerRequestEntity(
    @PrimaryKey val id: String,
    val dealerId: String,
    val requestedByAsmId: String,
    val items: String,
    val warehouseAvailable: Boolean,
)

@Entity(tableName = "field_employee_routes", primaryKeys = ["employeeId", "dateEpochDay"])
data class FieldEmployeeRouteEntity(
    val employeeId: String,
    val employeeName: String,
    val dateEpochDay: Long,
    val breadcrumbsRaw: String, // packed GpsPing list, see Converters.packBreadcrumbs
)

@Entity(tableName = "engagement_campaigns")
data class EngagementCampaignEntity(
    @PrimaryKey val id: String = "",
    val channel: String = "",
    val message: String = "",
    val targetZone: String = "",
    val sentCount: Int = 0,
)

@Entity(tableName = "attendance_records")
data class AttendanceRecordEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
    val employeeId: String = "",
    val dateEpochDay: Long = 0,
    val checkedIn: Boolean = false,
    val gpsValid: Boolean = false,
    val shiftType: String = "GENERAL",
    val checkInEpochMillis: Long = 0, // Factory HR — real check-in TIME (was previously only a boolean, with no time recorded at all)
    val checkOutEpochMillis: Long = 0, // 0 = not yet checked out
    val checkOutGpsValid: Boolean = false,
    val isLate: Boolean = false, // persisted, real late-flag (previously only reflected via shiftType=="LATE", never queryable on its own)
    val isOnLeave: Boolean = false, // set when an approved Leave request covers this date — an on-leave day must never also count as an absence
    val leaveApprovalRequestId: String? = null,
    val overtimeMinutes: Int = 0, // real, computed from (checkOut - checkIn) beyond the standard shift length
)

@Entity(tableName = "payroll_lines")
data class PayrollLineEntity(
    @PrimaryKey val employeeId: String = "",
    val employeeName: String = "",
    val overtimeMinutes: Int = 0, // Factory HR — real link from attendance's overtimeMinutes total for the payroll period
    val overtimePay: Double = 0.0,
    val attendanceDaysPresent: Int = 0,
    val attendanceDaysAbsent: Int = 0,
    val basePay: Double = 0.0,
    val targetAmount: Double = 0.0,
    val achievedAmount: Double = 0.0,
    val commissionRate: Double = 0.0,
    val unapprovedAbsenceDays: Int = 0,
    val dailyWage: Double = 0.0,
)

// Unified table backing BOTH the Billing module's "Voice Billing" feature and
// the Sales Chain's dealer invoicing — one physical Invoice structure with a
// `type` discriminator, instead of two separate tables. Domain-facing shapes
// (VoiceInvoice / SalesInvoice in Models.kt) are unchanged so existing screens
// keep working exactly as before; only the persistence layer is unified.
@Entity(tableName = "sales_orders")
data class SalesOrderEntity(
    @PrimaryKey val id: String = "",
    val orderNo: String = "",
    val dealerId: String = "",
    val dealerName: String = "",
    val dealerZone: String = "",
    val lineItemsRaw: String = "",
    val dealerDiscountPct: Double = 0.0,
    val status: String = "DRAFT",
    val convertedToInvoiceId: String? = null,
    val deliveredQtyRaw: String = "",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val approvedBy: String? = null,
    val approvedAtEpochMillis: Long? = null,
    val isDeleted: Boolean = false,
)

@Entity(tableName = "invoices")
data class InvoiceEntity(
    @PrimaryKey val id: String = "",
    val invoiceNo: String = "",
    val type: String = "SALES", // "SALES" | "VOICE"
    val dealerId: String = "",
    val dealerName: String = "",
    val dealerZone: String = "",
    val lineItemsRaw: String = "", // packed line items — packInvoiceItems for VOICE, packSalesInvoiceItems for SALES
    val dealerDiscountPct: Double = 0.0,
    val commissionPct: Double = 0.0,
    val previousDue: Double = 0.0, // VOICE-type only
    // Balance snapshot for SALES invoices — see SalesInvoice.previousDueSnapshot.
    val previousDueSnapshot: Double = 0.0,
    val closingDueSnapshot: Double = 0.0,
    val courier: String? = null,
    val signedByRole: String? = null,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val status: String = "PENDING",
    val paidAmount: Double = 0.0,
    val isDeleted: Boolean = false,
    val deletedAtEpochMillis: Long? = null,
    val deletedBy: String? = null,
    val warehouseId: String = "", // Section 7 — which company warehouse this sale draws real stock from; "" = not yet assigned (legacy rows before this field existed)
    val stockReserved: Boolean = false, // real idempotency guard — true only while a reservation is genuinely held, so release-on-reject/cancel can never double-release
)

@Entity(tableName = "payment_proofs")
data class PaymentProofEntity(
    @PrimaryKey val id: String,
    val dealerId: String,
    val amount: Double,
    val proofRef: String,
    val status: String,
)

@Entity(tableName = "raw_material_lots")
data class RawMaterialLotEntity(
    @PrimaryKey val id: String,
    val materialName: String,
    val qtyKg: Double,
    val costPerKg: Double,
    val purchasedOnEpochDay: Long,
)

@Entity(tableName = "production_batches")
data class ProductionBatchEntity(
    @PrimaryKey val id: String,
    val cycleType: String,
    val inputKg: Double,
    val outputKg: Double,
    val gatepassReceived: Boolean,
)

@Entity(tableName = "factory_attendance")
data class FactoryAttendanceEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
    val laborerId: String,
    val dateEpochDay: Long,
    val withinFactoryGeofence: Boolean,
    val wifiIpLocked: Boolean,
)

@Entity(tableName = "prescription_cards")
data class PrescriptionCardEntity(
    @PrimaryKey val id: String,
    val title: String,
    val body: String,
    val severity: String,
)

@Entity(tableName = "boardroom_queries")
data class BoardroomQueryEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
    val question: String,
    val answer: String,
    val mode: String = "analysis",
    val askedAtEpochMillis: Long,
)

@Entity(tableName = "tasks")
data class TaskItemEntity(
    @PrimaryKey val id: String = "",
    val title: String = "",
    val assignee: String = "",
    val done: Boolean = false,
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
    val deletedAtEpochMillis: Long? = null,
    val deletedBy: String? = null,
    val status: String = "PENDING",
    val parentTaskId: String? = null,
)

@Entity(tableName = "approval_requests")
data class ApprovalRequestEntity(
    @PrimaryKey val id: String = "",
    val type: String = "",
    val fromEmployee: String = "",
    val detail: String = "",
    val status: String = "Pending",
    val createdAtEpochMillis: Long = 0,
    val entityType: String = "",
    val entityId: String = "",
    val level: Int = 1,
    val approvedBy: String? = null,
    val approvedAtEpochMillis: Long? = null,
    val rejectReason: String? = null,
    val assignedToEmployeeId: String? = null,
    val escalated: Boolean = false,
)

@Entity(tableName = "courier_partners")
data class CourierPartnerEntity(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val hasApi: Boolean = false,
    // v113-144 — additive only (v75→v76). The person asked for a slot they can
    // simply paste a courier's API credentials into. Stored per-courier so each
    // partner carries its own config, and left nullable so every existing row
    // migrates untouched. NOTE: this is deliberately NOT presented as "connected"
    // anywhere — pasting a key records the configuration; actually calling a
    // courier's API is still not implemented, and the UI says so plainly rather
    // than implying live tracking that doesn't exist (directive §27).
    val apiBaseUrl: String? = null,
    val apiKey: String? = null,
)

@Entity(tableName = "shipments")
data class ShipmentEntity(
    @PrimaryKey val id: String = "",
    val courierId: String = "",
    val dealerOrRetailer: String = "",
    val trackingId: String? = null,
    val status: String = "",
)

@Entity(tableName = "ledger_entries")
data class LedgerEntryEntity(
    @PrimaryKey val id: String = "",
    val type: String = "IN", // "IN" | "OUT"
    val category: String = "",
    val description: String = "",
    val amount: Double = 0.0,
    val recordedBy: String = "",
    val division: String? = null,
    val recordedAtEpochMillis: Long = 0,
)

/**
 * One shared audit trail for the whole app — every module writes into this
 * SAME table instead of each module getting its own bespoke log. entityType
 * + entityId identify what was touched (e.g. "SalesInvoice" / "INV-1044");
 * oldValueJson/newValueJson are simple JSON snapshots (nullable — a CREATE
 * has no old value, a DELETE has no new value).
 */
@Entity(tableName = "audit_log")
data class AuditLogEntity(
    @PrimaryKey val id: String = "",
    val entityType: String = "",
    val entityId: String = "",
    val action: String = "CREATE",
    val performedBy: String = "",
    val performedByRole: String = "",
    val oldValueJson: String? = null,
    val newValueJson: String? = null,
    val reason: String? = null,
    val relatedApprovalId: String? = null,
    val deviceId: String? = null,
    val gpsLat: Double? = null,
    val gpsLng: Double? = null,
    val syncStatus: String = "PENDING",
    val timestampEpochMillis: Long = 0,
)

/** Backup & Recovery — one row per export taken; fileUrl points at the Firebase Storage copy of the JSON bundle (see BackupManager). */
@Entity(tableName = "backup_metadata")
data class BackupMetadataEntity(
    @PrimaryKey val id: String = "",
    val companyId: String = "",
    val version: String = "v1",
    val collectionsIncluded: Int = 0,
    val fileUrl: String = "",
    val fileSizeBytes: Long = 0,
    val triggeredBy: String = "",
    val status: String = "COMPLETED",
    val createdAtEpochMillis: Long = 0,
    val restoredAtEpochMillis: Long? = null,
    val restoredBy: String? = null,
)

// ================= Module 4/7/8: Sales Management, DMS, Retailer/Outlet =================

@Entity(tableName = "quotations")
data class QuotationEntity(
    @PrimaryKey val id: String = "",
    val quotationNo: String = "",
    val partyType: String = "DEALER",
    val partyId: String = "",
    val partyName: String = "",
    val lineItemsRaw: String = "",
    val validUntilEpochMillis: Long = 0,
    val status: String = "DRAFT",
    val convertedInvoiceId: String? = null,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

@Entity(tableName = "delivery_challans")
data class DeliveryChallanEntity(
    @PrimaryKey val id: String = "",
    val challanNo: String = "",
    val invoiceId: String? = null,
    val partyType: String = "DEALER",
    val partyId: String = "",
    val partyName: String = "",
    val lineItemsRaw: String = "",
    val vehicleNo: String = "",
    val driverName: String = "",
    val deliveredBy: String = "",
    val status: String = "PENDING",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

@Entity(tableName = "sales_returns")
data class SalesReturnEntity(
    @PrimaryKey val id: String = "",
    val returnNo: String = "",
    val invoiceId: String? = null,
    val partyType: String = "DEALER",
    val partyId: String = "",
    val partyName: String = "",
    val lineItemsRaw: String = "",
    val reason: String = "",
    val refundAmount: Double = 0.0,
    val status: String = "PENDING",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

@Entity(tableName = "party_ledger")
data class PartyLedgerEntryEntity(
    @PrimaryKey val id: String = "",
    val partyType: String = "DEALER",
    val partyId: String = "",
    val type: String = "DEBIT",
    val amount: Double = 0.0,
    val reason: String = "",
    val referenceId: String = "",
    val balanceAfter: Double = 0.0,
    val createdAtEpochMillis: Long = 0,
)

// v86, Module 15 — Customer Complaints (separate from ComplaintRecord's
// internal employee grievance box — see the Models.kt comment on
// CustomerComplaint for why these are not merged).
@Entity(tableName = "customer_complaints")
data class CustomerComplaintEntity(
    @PrimaryKey val id: String = "",
    val complaintNo: String = "",
    val dealerId: String = "",
    val dealerName: String = "",
    val productId: String? = null,
    val productName: String? = null,
    val invoiceId: String? = null,
    val invoiceNo: String? = null,
    val category: String = "OTHER",
    val description: String = "",
    val priority: String = "NORMAL",
    val status: String = "NEW",
    val assignedEmployeeId: String? = null,
    val assignedEmployeeName: String? = null,
    val resolutionNote: String? = null,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val resolvedAtEpochMillis: Long? = null,
    val isDeleted: Boolean = false,
    // v113-75 — additive, RMS's retailer complaints. `dealerId`/`dealerName` are kept
    // exactly as-is for every existing dealer complaint; a retailer complaint carries
    // empty strings there instead and uses these three new columns. Not the cleanest
    // shape (PartyCollection/SalesReturn use one generic partyId/partyName instead of
    // parallel dealer/retailer fields) — that refactor would touch every existing
    // dealer-complaint call site for no functional gain, so it was not done unasked.
    val partyType: String = "DEALER",
    val retailerId: String? = null,
    val retailerName: String? = null,
)

@Entity(tableName = "party_collections")
data class PartyCollectionEntity(
    @PrimaryKey val id: String = "",
    val collectionNo: String = "",
    val partyType: String = "DEALER",
    val partyId: String = "",
    val partyName: String = "",
    val amount: Double = 0.0,
    val method: String = "CASH",
    val proofUri: String? = null,
    val status: String = "PENDING",
    val collectedBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val verifiedBy: String? = null,
    val verifiedAtEpochMillis: Long? = null,
    val allocatedInvoiceId: String? = null, // v86 Module 5 — which SalesInvoice this collection is allocated against, if any
)

@Entity(tableName = "discount_rules")
data class DiscountRuleEntity(
    @PrimaryKey val id: String = "",
    val label: String = "",
    val scope: String = "ALL",
    val minQty: Double = 0.0,
    val discountPct: Double = 0.0,
    val isActive: Boolean = true,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "sales_routes")
data class SalesRouteEntity(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val territoryId: String? = null,
    val assignedToEmployeeId: String = "",
    val outletIdsRaw: String = "", // comma-separated Retailer ids, visit order matters
    val isActive: Boolean = true,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "visit_logs")
data class VisitLogEntity(
    @PrimaryKey val id: String = "",
    val partyType: String = "DEALER",
    val partyId: String = "",
    val employeeId: String = "",
    val employeeName: String = "",
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val photoUri: String? = null,
    val purpose: String = "",
    val checkInAtEpochMillis: Long = 0,
    val checkOutAtEpochMillis: Long? = null,
    val routeId: String? = null,
    val checkInAccuracyMeters: Float? = null,
    val checkInProvider: String? = null,
    val checkInMockSuspected: Boolean = false,
    val checkInDistanceFromRetailerMeters: Double? = null,
    val checkOutLat: Double? = null,
    val checkOutLng: Double? = null,
    val checkOutAccuracyMeters: Float? = null,
    val checkOutMockSuspected: Boolean = false,
    val checkOutDistanceFromRetailerMeters: Double? = null,
    val deviceId: String? = null,
    val verificationResult: String = "PENDING",
    val verificationScore: Int = 0,
    val overrideReason: String? = null,
    val overrideBy: String? = null,
    val orderCreatedId: String? = null,
    val collectionCreatedId: String? = null,
    val complaintCreatedId: String? = null,
    val notes: String = "",
)

// ================= Module 5: Purchase Management =================

@Entity(tableName = "suppliers")
data class SupplierEntity(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val phone: String = "",
    val address: String = "",
    val dueBalance: Double = 0.0,
    val creditLimit: Double = 0.0,
    val dedupKey: String = "",
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val deletedAtEpochMillis: Long? = null,
    val deletedBy: String? = null,
)

@Entity(tableName = "purchase_requests")
data class PurchaseRequestEntity(
    @PrimaryKey val id: String = "",
    val requestNo: String = "",
    val lineItemsRaw: String = "",
    val requiredByEpochMillis: Long? = null,
    val reason: String = "",
    val status: String = "PENDING",
    val convertedToPoId: String? = null,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val approvedBy: String? = null,
    val approvedAtEpochMillis: Long? = null,
    val rejectReason: String? = null,
    val isDeleted: Boolean = false,
    val supplierQuotesRaw: String = "[]",
)
@Entity(tableName = "purchase_orders")
data class PurchaseOrderEntity(
    @PrimaryKey val id: String = "",
    val poNo: String = "",
    val supplierId: String = "",
    val supplierName: String = "",
    val lineItemsRaw: String = "",
    val status: String = "DRAFT",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

@Entity(tableName = "goods_received_notes")
data class GoodsReceivedNoteEntity(
    @PrimaryKey val id: String = "",
    val grnNo: String = "",
    val purchaseOrderId: String = "",
    val supplierId: String = "",
    val supplierName: String = "",
    val receivedItemsRaw: String = "",
    val warehouseId: String = "",
    val receivedBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

@Entity(tableName = "purchase_returns")
data class PurchaseReturnEntity(
    @PrimaryKey val id: String = "",
    val returnNo: String = "",
    val purchaseOrderId: String? = null,
    val supplierId: String = "",
    val supplierName: String = "",
    val lineItemsRaw: String = "",
    val reason: String = "",
    val refundAmount: Double = 0.0,
    val status: String = "PENDING",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

// ================= Module 3: Inventory extras =================

@Entity(tableName = "product_categories")
data class ProductCategoryEntity(@PrimaryKey val id: String = "", val name: String = "", val isActive: Boolean = true)

@Entity(tableName = "product_brands")
data class ProductBrandEntity(@PrimaryKey val id: String = "", val name: String = "", val isActive: Boolean = true)

@Entity(tableName = "inventory_lots")
data class InventoryLotEntity(
    @PrimaryKey val id: String = "",
    val productId: String = "",
    val warehouseId: String = "",
    val batchCode: String = "",
    val qtyRemaining: Double = 0.0,
    val expiryDateEpochMillis: Long? = null,
    val receivedAtEpochMillis: Long = 0,
)

@Entity(tableName = "damage_reports")
data class DamageReportEntity(
    @PrimaryKey val id: String = "",
    val productId: String = "",
    val productName: String = "",
    val warehouseId: String = "",
    val qty: Double = 0.0,
    val reason: String = "",
    val reportedBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "stock_transfers")
data class StockTransferEntity(
    @PrimaryKey val id: String = "",
    val productId: String = "",
    val productName: String = "",
    val fromWarehouseId: String = "",
    val toWarehouseId: String = "",
    val qty: Double = 0.0,
    val status: String = "COMPLETED",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

// ================= Module 2: Manufacturing & Production extras =================

@Entity(tableName = "bill_of_materials")
data class BillOfMaterialsEntity(
    @PrimaryKey val id: String = "",
    val finishedProductName: String = "",
    val linesRaw: String = "", // packed: name,qtyPerUnit,unit;name,qtyPerUnit,unit...
    val laborCostPerUnit: Double = 0.0,
    val overheadCostPerUnit: Double = 0.0,
    val isActive: Boolean = true,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "production_orders")
data class ProductionOrderEntity(
    @PrimaryKey val id: String = "",
    val orderNo: String = "",
    val bomId: String = "",
    val finishedProductName: String = "",
    val targetQty: Double = 0.0,
    val status: String = "PLANNED",
    val scheduledDateEpochMillis: Long = 0,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "quality_checks")
data class QualityCheckEntity(
    @PrimaryKey val id: String = "",
    val batchId: String = "",
    val result: String = "PASS",
    val notes: String = "",
    val checkedBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "production_losses")
data class ProductionLossEntity(
    @PrimaryKey val id: String = "",
    val batchId: String = "",
    val qtyLost: Double = 0.0,
    val reason: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "machine_logs")
data class MachineLogEntity(
    @PrimaryKey val id: String = "",
    val machineName: String = "",
    val batchId: String? = null,
    val hoursUsed: Double = 0.0,
    val notes: String = "",
    val recordedAtEpochMillis: Long = 0,
)

// ================= Module 11: Accounts & Finance =================

@Entity(tableName = "chart_of_accounts")
data class ChartOfAccountEntity(
    @PrimaryKey val id: String = "",
    val code: String = "",
    val name: String = "",
    val type: String = "ASSET",
    val parentId: String? = null,
    val isActive: Boolean = true,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "vouchers")
data class VoucherEntity(
    @PrimaryKey val id: String = "",
    val voucherNo: String = "",
    val type: String = "PAYMENT",
    val voucherDateEpochMillis: Long = 0,
    val narration: String = "",
    val linesRaw: String = "", // packed: accountId,accountName,debit,credit ; per line
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

// ================= Module 6: CRM =================

@Entity(tableName = "leads")
data class LeadEntity(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val phone: String = "",
    val source: String = "",
    val status: String = "NEW",
    val assignedTo: String = "",
    val notes: String = "",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

@Entity(tableName = "opportunities")
data class OpportunityEntity(
    @PrimaryKey val id: String = "",
    val leadId: String? = null,
    val title: String = "",
    val estimatedValue: Double = 0.0,
    val stage: String = "PROSPECTING",
    val assignedTo: String = "",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "customer_segments")
data class CustomerSegmentEntity(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val criteria: String = "",
)

@Entity(tableName = "call_logs")
data class CallLogEntity(
    @PrimaryKey val id: String = "",
    val leadId: String? = null,
    val partyType: String? = null,
    val partyId: String? = null,
    val contactName: String = "",
    val phone: String = "",
    val durationMinutes: Int = 0,
    val notes: String = "",
    val loggedBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "meeting_logs")
data class MeetingLogEntity(
    @PrimaryKey val id: String = "",
    val title: String = "",
    val attendees: String = "",
    val notes: String = "",
    val meetingDateEpochMillis: Long = 0,
    val loggedBy: String = "",
)

@Entity(tableName = "follow_ups")
data class FollowUpEntity(
    @PrimaryKey val id: String = "",
    val leadId: String? = null,
    val note: String = "",
    val dueDateEpochMillis: Long = 0,
    val done: Boolean = false,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

// ================= Module 12: HR & Payroll extras =================

@Entity(tableName = "leave_requests")
data class LeaveRequestEntity(
    @PrimaryKey val id: String = "",
    val employeeId: String = "",
    val employeeName: String = "",
    val type: String = "CASUAL",
    val fromDateEpochDay: Long = 0,
    val toDateEpochDay: Long = 0,
    val reason: String = "",
    val status: String = "PENDING",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "employee_lifecycle_events")
data class EmployeeLifecycleEventEntity(
    @PrimaryKey val id: String = "",
    val employeeId: String = "",
    val employeeName: String = "",
    val type: String = "INCREMENT",
    val oldValue: String = "",
    val newValue: String = "",
    val effectiveDateEpochDay: Long = 0,
    val notes: String = "",
    val recordedBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

// ================= Module 14: Communication Hub =================

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String = "",
    val channelId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val message: String = "",
    val attachmentUri: String? = null,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "announcements")
data class AnnouncementEntity(
    @PrimaryKey val id: String = "",
    val title: String = "",
    val body: String = "",
    val postedBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

@Entity(tableName = "circulars")
data class CircularEntity(
    @PrimaryKey val id: String = "",
    val title: String = "",
    val body: String = "",
    val department: String? = null,
    val postedBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

// ================= Module 13: Logistics — Vehicle Tracking =================

@Entity(tableName = "vehicles")
data class VehicleEntity(
    @PrimaryKey val id: String = "",
    val registrationNo: String = "",
    val vehicleType: String = "Truck",
    val driverName: String = "",
    val driverPhone: String = "",
    val isActive: Boolean = true,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "vehicle_location_pings")
data class VehicleLocationPingEntity(
    @PrimaryKey val id: String = "",
    val vehicleId: String = "",
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val speedKmh: Double = 0.0,
    val recordedAtEpochMillis: Long = 0,
)

// ================= Universal Attachment System =================

@Entity(tableName = "attachments")
data class AttachmentEntity(
    @PrimaryKey val id: String = "",
    val moduleReference: String = "",
    val entityId: String = "",
    val type: String = "PHOTO",
    val uri: String = "",
    val lat: Double? = null,
    val lng: Double? = null,
    val uploadedBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

/** Notification Framework — persisted in-app notification record (see Models.kt's NotificationEntry doc comment). */
@Entity(tableName = "notification_entries")
data class NotificationEntryEntity(
    @PrimaryKey val id: String = "",
    val category: String = "APPROVAL",
    val title: String = "",
    val body: String = "",
    val targetEmployeeId: String? = null,
    val isRead: Boolean = false,
    val createdAtEpochMillis: Long = 0,
)

/**
 * Product-wise stock held at a dealer.
 *
 * `Dealer.stockUnits` (an Int on DealerEntity) has existed since the original baseline and
 * stays exactly as-is — it is a trusted, complete aggregate that several existing flows
 * already depend on. This table is a NEW, additive breakdown of that same movement by
 * product, built from the structured line items that were not available when `stockUnits`
 * was first designed.
 *
 * Because it can only be populated from structured line items, and those only exist from
 * v113-59 (retail orders) and the original invoice model (invoices) onward, this table is
 * **not backfilled from history**. Backfilling only the "arrived via invoice" side while
 * having no data for older "left via retail order" fulfillments would make dealer stock
 * look higher than it really is — a wrong number with the appearance of precision is worse
 * than an honestly incomplete one. Tracking starts from the day this shipped; the UI says so.
 */
@Entity(tableName = "dealer_stock_lines", primaryKeys = ["dealerId", "productId"])
data class DealerStockLineEntity(
    val dealerId: String = "",
    val productId: String = "",
    val productName: String = "", // denormalized snapshot, refreshed on every write, so the screen needs no join
    val qty: Int = 0,
    val updatedAtEpochMillis: Long = 0,
)

/**
 * Product-wise stock held at a retailer. v113-75 — the retailer-side mirror of
 * `DealerStockLineEntity` above, added because retailer stock did not exist anywhere
 * in this codebase at all (no field on `Retailer`, no table) — confirmed by reading
 * the source before this migration was written, not assumed.
 *
 * Same honesty rule as the dealer table: this is **not backfilled**. It only tracks
 * movement from the day this shipped — retailer memo (`RetailOrder`) reaching
 * `FULFILLED` increments it, a retailer damage/return (`SalesReturn` with
 * `partyType == RETAILER`) decrements it. There is no pre-existing trusted aggregate
 * to reconcile against the way `Dealer.stockUnits` exists for dealers — `Retailer` has
 * no such field — so the UI built on this table says plainly that the product
 * breakdown is the only figure available, not a partial view of a bigger number.
 */
@Entity(tableName = "retailer_stock_lines", primaryKeys = ["retailerId", "productId"])
data class RetailerStockLineEntity(
    val retailerId: String = "",
    val productId: String = "",
    val productName: String = "",
    val qty: Int = 0,
    val updatedAtEpochMillis: Long = 0,
)
