package com.abm.erp.data

import androidx.room.withTransaction
import com.abm.erp.data.room.AppDatabase
import com.abm.erp.data.room.QrRegistryEntity
import com.abm.erp.data.room.QrScanLogEntity
import kotlinx.coroutines.flow.first
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Secure Universal QR Registry.
 *
 * ## Why this exists
 * Previously a QR encoded a business identifier — `dealerCode`, `invoiceNo`, `sku`.
 * Three problems with that: the codes are sequential and therefore guessable, so a
 * QR could be forged by anyone who knows the numbering scheme; a printed tag leaks
 * what it is and which company it belongs to; and there is no way to invalidate a
 * code once printed, because the code *is* the record's name.
 *
 * A QR now carries an opaque random reference and nothing else. Meaning lives in
 * this registry and is checked at scan time, which makes revocation, reissue and
 * expiry possible for the first time.
 *
 * ## Payload format
 * `ABMQR:1:<qrId>:<token>` — a version marker, the opaque id, and the secret.
 * No name, amount, phone number, address or any other business value is ever placed
 * in a payload.
 *
 * ## What is stored
 * Only `sha256(token)`. The token itself exists in the printed/rendered QR and is
 * never written to Room or Firestore, so a database read cannot reproduce a
 * scannable code.
 */
object QrRegistry {

    private const val PAYLOAD_PREFIX = "ABMQR"
    private const val PAYLOAD_VERSION = 1

    private val db: AppDatabase get() = MockRepository.database
    private val secureRandom = SecureRandom()

    // ---------------------------------------------------------------- results

    sealed class Resolution {
        /** Fully validated: company, status, token and permission all passed. */
        data class Allowed(
            val qrId: String,
            val entityType: String,
            val entityId: String,
            val offlineVerified: Boolean,
        ) : Resolution()

        /** Every failure carries a human reason and has already been audited. */
        data class Denied(val reason: String, val code: String) : Resolution()
    }

    enum class Status { DRAFT, ACTIVE, REVOKED, REISSUED, EXPIRED, HISTORICAL }

    // ---------------------------------------------------------------- tokens

    /** 160 bits from SecureRandom, base32-ish encoded. Not derived from any business value. */
    private fun newOpaqueId(): String {
        val bytes = ByteArray(10)
        secureRandom.nextBytes(bytes)
        return bytes.joinToString("") { "%02X".format(it) }
    }

    private fun newToken(): String {
        val bytes = ByteArray(24)
        secureRandom.nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun hashToken(token: String): String =
        MessageDigest.getInstance("SHA-256").digest(token.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun payloadFor(qrId: String, token: String): String =
        "$PAYLOAD_PREFIX:$PAYLOAD_VERSION:$qrId:$token"

    /** Splits a scanned payload. Returns null for anything that isn't one of our tokens. */
    fun parsePayload(raw: String): Pair<String, String>? {
        val parts = raw.trim().split(":")
        if (parts.size != 4) return null
        if (parts[0] != PAYLOAD_PREFIX) return null
        if (parts[1].toIntOrNull() != PAYLOAD_VERSION) return null
        if (parts[2].isBlank() || parts[3].isBlank()) return null
        return parts[2] to parts[3]
    }

    fun isSecurePayload(raw: String): Boolean = parsePayload(raw) != null

    // ---------------------------------------------------------------- lifecycle

    /**
     * Issues a new ACTIVE QR for a record and returns the payload to render.
     *
     * The payload is returned **once**, here, because the token is not persisted.
     * If the caller loses it the QR must be reissued — which is the intended
     * property, not a limitation.
     *
     * Any existing ACTIVE QR for the same record is marked REISSUED in the same
     * transaction, so a record can never have two live QRs.
     */
    suspend fun issue(
        entityType: String,
        entityId: String,
        expiresAtEpochMillis: Long? = null,
    ): String? {
        val companyId = MockRepository.currentUser.companyId
        if (companyId.isBlank() || entityId.isBlank()) return null

        val qrId = newOpaqueId()
        val token = newToken()
        val now = System.currentTimeMillis()
        var ok = false
        var replacedExisting = false

        db.withTransaction {
            val existing = db.qrRegistryDao().findActiveFor(entityType, entityId)?.takeIf { it.companyId == companyId }
            val nextVersion = (existing?.version ?: 0) + 1
            if (existing != null) {
                replacedExisting = true
                db.qrRegistryDao().upsert(
                    existing.copy(
                        status = Status.REISSUED.name,
                        revokedAtEpochMillis = now,
                        revokedBy = MockRepository.currentUser.name,
                        revokeReason = "Superseded by reissue",
                        syncStatus = "PENDING",
                    ),
                )
            }
            db.qrRegistryDao().upsert(
                QrRegistryEntity(
                    qrId = qrId,
                    tokenHash = hashToken(token),
                    // v113-326 — stored so the code can actually be drawn
                    // and printed later; see the field's own note for why
                    // this is right for a QR that exists to go on paper.
                    payload = payloadFor(qrId, token),
                    companyId = companyId,
                    entityType = entityType,
                    entityId = entityId,
                    status = Status.ACTIVE.name,
                    version = nextVersion,
                    issuedAtEpochMillis = now,
                    issuedBy = MockRepository.currentUser.name,
                    expiresAtEpochMillis = expiresAtEpochMillis,
                    previousQrId = existing?.qrId,
                    syncStatus = "PENDING",
                ),
            )
            ok = true
        }
        if (!ok) return null
        db.qrRegistryDao().findByQrId(qrId)?.let { pushRegistry(it) }

        MockRepository.logAudit(
            "QrRegistry", qrId, if (replacedExisting) "QR_REISSUE" else "QR_ISSUE",
            newValue = "$entityType/$entityId",
        )
        return payloadFor(qrId, token)
    }

    /** Returns the current ACTIVE registry row for a record, or null if it has never been issued one. */
    suspend fun activeFor(entityType: String, entityId: String): QrRegistryEntity? =
        // Canonical DAO's findActiveFor is not company-parameterised, so the company
        // check is applied here instead. Same isolation, enforced one layer up.
        db.qrRegistryDao().findActiveFor(entityType, entityId)
            ?.takeIf { it.companyId == MockRepository.currentUser.companyId }

    /** Full issue/revoke/reissue history for a record — Chairman/audit view. */
    suspend fun historyFor(entityType: String, entityId: String): List<QrRegistryEntity> =
        db.qrRegistryDao().historyFor(entityType, entityId).first()
            .filter { it.companyId == MockRepository.currentUser.companyId }

    /**
     * Revokes a QR. Conditional on the row still being ACTIVE and in this company, in
     * one atomic statement, so two concurrent revokes cannot both "succeed".
     */
    suspend fun revoke(qrId: String, reason: String): Boolean {
        if (!PermissionManager.canCurrentUser("settings", PermissionAction.EDIT)) {
            MockRepository.logAudit("QrRegistry", qrId, "QR_REVOKE_DENY", newValue = MockRepository.currentUser.role.name)
            return false
        }
        val companyId = MockRepository.currentUser.companyId
        // Atomic conditional transition: only flips a row that is still ACTIVE, so two
        // concurrent revokes cannot both report success.
        val target = db.qrRegistryDao().findByQrId(qrId)
        if (target == null || target.companyId != companyId) return false
        val changed = db.qrRegistryDao().transitionStatus(
            qrId = qrId, expectedStatus = Status.ACTIVE.name, newStatus = Status.REVOKED.name,
            atMillis = System.currentTimeMillis(), by = MockRepository.currentUser.name, reason = reason,
        )
        if (changed > 0) {
            MockRepository.logAudit("QrRegistry", qrId, "QR_REVOKE", reason = reason)
            db.qrRegistryDao().findByQrId(qrId)?.let { pushRegistry(it) }
            return true
        }
        return false
    }

    /** Revokes then issues in one call — returns the new payload, or null if revocation failed. */
    suspend fun reissue(entityType: String, entityId: String, reason: String): String? {
        val current = activeFor(entityType, entityId)
        if (current != null && !revoke(current.qrId, reason)) return null
        return issue(entityType, entityId)
    }

    // ---------------------------------------------------------------- resolution

    /**
     * The single entry point the scanner uses.
     *
     * Validates, in order: payload shape → registry presence → company isolation →
     * token match → status → expiry → permission. Every denial is audited with a
     * reason, and a denial never reveals what the QR pointed at.
     */
    suspend fun resolve(rawPayload: String, isOnline: Boolean): Resolution {
        val parsed = parsePayload(rawPayload)
            ?: return deny("UNKNOWN", "এই QR এই সিস্টেমের নয়।", qrId = "", entityType = "")

        val (qrId, token) = parsed
        val companyId = MockRepository.currentUser.companyId

        val row = db.qrRegistryDao().findByQrId(qrId)
        val scoped = row?.takeIf { it.companyId == companyId }
        if (scoped == null) {
            // Distinguish "never seen" from "belongs to another company" — the second is a
            // security event worth auditing distinctly, but the user is told the same thing.
            val anyCompany = row
            return if (anyCompany != null) {
                deny("CROSS_COMPANY", "এই QR আপনার প্রতিষ্ঠানের নয়।", qrId, anyCompany.entityType)
            } else {
                deny("UNKNOWN", "অজানা QR — এই কোডটি নিবন্ধিত নয়।", qrId, "")
            }
        }

        if (scoped.tokenHash != hashToken(token)) {
            return deny("BAD_TOKEN", "QR যাচাই ব্যর্থ — কোডটি বৈধ নয়।", qrId, scoped.entityType)
        }

        when (scoped.status) {
            Status.REVOKED.name -> return deny("REVOKED", "এই QR বাতিল করা হয়েছে।", qrId, scoped.entityType)
            Status.REISSUED.name -> return deny("REISSUED", "এই QR পুরনো — নতুন QR ব্যবহার করুন।", qrId, scoped.entityType)
            Status.EXPIRED.name -> return deny("EXPIRED", "এই QR-এর মেয়াদ শেষ।", qrId, scoped.entityType)
            Status.DRAFT.name -> return deny("INACTIVE", "এই QR এখনো সক্রিয় করা হয়নি।", qrId, scoped.entityType)
            Status.ACTIVE.name -> Unit
            else -> return deny("INACTIVE", "এই QR ব্যবহারযোগ্য নয়।", qrId, scoped.entityType)
        }

        val expiry = scoped.expiresAtEpochMillis
        if (expiry != null && expiry < System.currentTimeMillis()) {
            return deny("EXPIRED", "এই QR-এর মেয়াদ শেষ।", qrId, scoped.entityType)
        }

        if (!canViewEntityType(scoped.entityType)) {
            return deny("PERMISSION", "এই তথ্য দেখার অনুমতি আপনার নেই।", qrId, scoped.entityType)
        }

        db.qrRegistryDao().recordScan(qrId, System.currentTimeMillis())
        writeScanLog(
            qrId = qrId, entityType = scoped.entityType, entityId = scoped.entityId,
            action = "SCAN", result = "ALLOWED", reason = null, wasOffline = !isOnline,
        )
        return Resolution.Allowed(
            qrId = qrId,
            entityType = scoped.entityType,
            entityId = scoped.entityId,
            // Honest label: the row came from the local cache and no server round-trip
            // confirmed it is still ACTIVE right now.
            offlineVerified = !isOnline,
        )
    }

    /** Maps an entity type onto the permission module the rest of the app already uses. */
    private fun canViewEntityType(entityType: String): Boolean = when (entityType) {
        "Employee", "EmployeeProfile" -> PermissionManager.canCurrentUser("hr", PermissionAction.VIEW)
        "Dealer", "Retailer" -> PermissionManager.canCurrentUser("dealer", PermissionAction.VIEW)
        "SalesInvoice", "Invoice", "Collection", "PartyCollection", "Receipt" ->
            PermissionManager.canCurrentUser("bill", PermissionAction.VIEW)
        "Product", "StockCount" -> PermissionManager.canCurrentUser("inv", PermissionAction.VIEW)
        "Carton", "ProductionBatch", "ProductionPlan" -> PermissionManager.canCurrentUser("prod", PermissionAction.VIEW)
        "WarehouseTransfer", "Delivery", "DeliveryChallan", "Return" ->
            PermissionManager.canCurrentUser("stock", PermissionAction.VIEW)
        "PurchaseOrder", "Purchase" -> PermissionManager.canCurrentUser("purchase", PermissionAction.VIEW)
        "RetailOrder", "SalesOrder", "Order" -> PermissionManager.canCurrentUser("order", PermissionAction.VIEW)
        "AttendanceRecord", "Attendance" -> PermissionManager.canCurrentUser("hr", PermissionAction.VIEW)
        else -> false // unknown types are refused rather than waved through
    }

    private suspend fun deny(code: String, message: String, qrId: String, entityType: String): Resolution.Denied {
        writeScanLog(
            qrId = qrId, entityType = entityType, entityId = null,
            action = "DENY_$code", result = "DENIED", reason = message, wasOffline = false,
        )
        return Resolution.Denied(message, code)
    }

    // ---------------------------------------------------------------- sync

    /**
     * Pushes a registry row to Firestore. Best-effort and never gates the local write —
     * the app is Room-first, so a QR is usable on this device the moment it is issued and
     * becomes visible to other devices when the network allows.
     */
    internal fun pushRegistry(entry: QrRegistryEntity) {
        MockRepository.qrSyncCollection("qrRegistry").document(entry.qrId).set(entry)
            .addOnSuccessListener {
                MockRepository.launchInRepoScope { db.qrRegistryDao().upsert(entry.copy(syncStatus = "SYNCED")) }
            }
            .addOnFailureListener {
                com.abm.erp.config.AppLog.w("QrRegistry", "push qrRegistry failed", it)
                MockRepository.launchInRepoScope { db.qrRegistryDao().upsert(entry.copy(syncStatus = "FAILED")) }
            }
    }

    /** Same contract for scan logs. Append-only on both sides. */
    internal fun pushScanLog(log: QrScanLogEntity) {
        MockRepository.qrSyncCollection("qrScanLogs").document(log.id).set(log)
            .addOnSuccessListener { MockRepository.launchInRepoScope { db.qrScanLogDao().insert(log.copy(syncStatus = "SYNCED")) } }
            .addOnFailureListener { com.abm.erp.config.AppLog.w("QrRegistry", "push qrScanLog failed", it) }
    }

    /** Retries everything still marked PENDING — called after connectivity returns. */
    suspend fun syncPending() {
        runCatching {
            db.qrScanLogDao().pendingSync().forEach { pushScanLog(it) }
            db.qrRegistryDao().pendingSync().forEach { pushRegistry(it) }
        }.onFailure { com.abm.erp.config.AppLog.w("QrRegistry", "syncPending failed", it) }
    }

    private suspend fun writeScanLog(
        qrId: String, entityType: String, entityId: String?,
        action: String, result: String, reason: String?, wasOffline: Boolean,
    ) {
        val user = MockRepository.currentUser
        db.qrScanLogDao().insert(
            QrScanLogEntity(
                id = java.util.UUID.randomUUID().toString(),
                qrId = qrId,
                companyId = user.companyId,
                userId = user.id,
                employeeId = user.employeeId,
                deviceId = com.abm.erp.ABMApplication.currentDeviceId() ?: "",
                entityType = entityType,
                entityId = entityId,
                action = action,
                result = result,
                reason = reason,
                gpsLat = null,
                gpsLng = null,
                wasOffline = wasOffline,
                timestampEpochMillis = System.currentTimeMillis(),
                syncStatus = "PENDING",
            ).also { pushScanLog(it) },
        )
    }
}
