package com.abm.erp.ui.memo

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.DocLabel
import com.abm.erp.core.DocValue
import com.abm.erp.core.SignatureSlot
import com.abm.erp.core.Space
import com.abm.erp.core.ThGrid
import com.abm.erp.core.TdGrid
import com.abm.erp.core.TotalRow
import com.abm.erp.core.amountInWords
import com.abm.erp.data.MockRepository
import com.abm.erp.data.RetailOrder
import com.abm.erp.theme.*
import kotlinx.coroutines.launch

/**
 * Memo Document — the real, printable/shareable retail order (memo), rendered on
 * screen exactly like InvoiceDocumentScreen is for a dealer invoice.
 *
 * v113-153. Before this, RMS's memo workspace had zero document view — a memo was
 * only ever a list row (order number, amount, stage), never an actual document a
 * retailer could be shown, printed, or asked to sign. This is that missing piece,
 * built from RetailOrder's own real fields — no invented totals, no invented due
 * balance.
 *
 * Deliberately NOT a copy of the invoice's due-ledger section: a retail order does
 * not post to the retailer's ledger in this app (confirmed in source — no
 * `retailer.dueBalance` mutation is ever triggered by order creation, verification,
 * routing, or fulfilment; invoicing, and the ledger entry that comes with it, happens
 * at the Dealer level once the dealer is billed for stock, per the existing v113-9
 * design note in PROJECT_STATE). Showing a due breakdown here would imply a financial
 * effect this document does not have, so it is left out — the retailer's current due
 * is shown once, clearly labelled as independent of this memo, not as "previous + this
 * + total" the way the invoice's is.
 *
 * v113-162 — the branded document card itself is now `MemoDocumentBody` below,
 * extracted so `RmsMemoWorkspace` can render the identical document inline
 * (same "one workspace" fix as the Invoice side). This screen is unchanged in
 * behavior — still the standalone destination for external entry points — it
 * just calls the shared body instead of inlining it.
 */
@Composable
fun MemoDocumentScreen(orderId: String, onBack: () -> Unit) {
    val orders by MockRepository.orders.collectAsState()
    val order = orders.firstOrNull { it.id == orderId }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    // v113-161 — shared with DocumentQrControl via onQrPayloadReady, same
    // reasoning as InvoiceDocumentScreen: Print/PDF reuses the exact QR
    // shown on screen instead of minting a second, different one.
    var qrPayloadForPdf by remember(order?.id) { mutableStateOf<String?>(null) }

    if (order == null) {
        Column(Modifier.fillMaxSize().padding(Space.xl), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(80.dp))
            com.abm.erp.core.WorkspaceEmptyState("এই মেমোটি পাওয়া যায়নি।", iconVector = Icons.Filled.ReceiptLong)
            Spacer(Modifier.height(Space.lg))
            com.abm.erp.core.SecondaryButton("← ফিরে যান", onClick = onBack)
        }
        return
    }

    Column(Modifier.fillMaxSize().background(DashBg)) {

        // ── top bar ──
        Row(
            Modifier.fillMaxWidth().background(Color.White).padding(horizontal = Space.md, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back", tint = TextPrimary) }
            Column(Modifier.weight(1f)) {
                Text("Memo", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextPrimary)
                Text(order.orderNo, fontSize = 10.sp, color = TextSecondary)
            }
            com.abm.erp.core.StatusPill(order.stage.name)
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(Space.md)) {
            MemoDocumentBody(order = order, onQrPayloadReady = { qrPayloadForPdf = it })
            Spacer(Modifier.height(Space.lg))
        }

        // ── actions ──
        Row(
            Modifier.fillMaxWidth().background(Color.White).padding(Space.md),
            horizontalArrangement = Arrangement.spacedBy(Space.sm),
        ) {
            Box(Modifier.weight(1f)) {
                com.abm.erp.core.SecondaryButton("Share", onClick = {
                    runCatching {
                        val summary = "Memo ${order.orderNo}\n${order.retailerName}\nTotal: ৳${"%,.0f".format(order.amount)}\nStage: ${order.stage.name}"
                        // v113-335 — the document itself, shared as an image.
                        // This is the Share button actually tapped when sending an
                        // invoice or memo to a dealer, so it mattered most.
                        com.abm.erp.core.shareTextSummary(context, "Share memo", summary)
                    }.onFailure {
                        android.widget.Toast.makeText(context, "Share করার মতো app পাওয়া যায়নি।", android.widget.Toast.LENGTH_LONG).show()
                    }
                }, icon = Icons.Filled.Share)
            }
            Box(Modifier.weight(1.4f)) {
                com.abm.erp.core.PrimaryButton(
                    text = if (busy) "তৈরি হচ্ছে…" else "Print / PDF",
                    icon = Icons.Filled.Print,
                    loading = busy,
                    onClick = {
                        busy = true
                        scope.launch {
                            runCatching {
                                // v113-161 — reuses the on-screen QR payload if already
                                // issued this session; only auto-issues when this memo
                                // has genuinely never had a QR; otherwise points at the
                                // "Reissue QR" control above instead of silently
                                // invalidating an already-printed QR.
                                val payload = qrPayloadForPdf ?: run {
                                    val alreadyExists = com.abm.erp.data.QrRegistry.activeFor("RetailOrder", order.id) != null
                                    if (alreadyExists) null
                                    else com.abm.erp.data.QrRegistry.issue("RetailOrder", order.id)?.also { qrPayloadForPdf = it }
                                }
                                if (payload == null) {
                                    android.widget.Toast.makeText(
                                        context,
                                        "এই মেমোর QR আগেই issue করা আছে — উপরে \"Reissue QR\"-এ ট্যাপ করে নতুন QR নিন, তারপর Print করুন।",
                                        android.widget.Toast.LENGTH_LONG,
                                    ).show()
                                } else {
                                    val file = com.abm.erp.core.exportRetailOrderPdf(context, order, payload)
                                    val uri = androidx.core.content.FileProvider.getUriForFile(
                                        context, "${context.packageName}.fileprovider", file,
                                    )
                                    val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                        type = "application/pdf"
                                        putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(android.content.Intent.createChooser(i, "Memo PDF"))
                                }
                            }.onFailure { e ->
                                com.abm.erp.config.AppLog.w("MemoDocumentScreen", "PDF export/share failed", e)
                                val msg = if (com.abm.erp.config.AppEnvironment.isDebugOrStaging) "PDF তৈরি করা যায়নি: ${e.javaClass.simpleName} — ${e.message}" else "PDF তৈরি করা যায়নি।"
                                android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()
                            }
                            busy = false
                        }
                    },
                )
            }
        }
    }
}

/**
 * v113-162 — the branded document card itself, extracted out of
 * `MemoDocumentScreen` so `RmsMemoWorkspace` can render the identical
 * document inline (its "view a memo" mode). Byte-for-byte the same
 * rendering that used to live directly inside `MemoDocumentScreen` — only
 * wrapped in a function signature, nothing about the layout changed.
 */
@Composable
fun MemoDocumentBody(order: RetailOrder, onQrPayloadReady: (String) -> Unit = {}) {
    val company = remember { MockRepository.companySettings() }
    // Best-effort display names only — never gates rendering, never written back.
    val loggedByName = remember(order.loggedBySoId) {
        MockRepository.demoAccounts.values.firstOrNull { it.id == order.loggedBySoId }?.name ?: order.loggedBySoId
    }
    val retailers by MockRepository.retailers.collectAsState()
    val retailer = remember(order.retailerId, retailers) { retailers.firstOrNull { it.id == order.retailerId } }
    val dealers by MockRepository.dealers.collectAsState()
    val routedDealer = remember(order.routedDealerId, dealers) { dealers.firstOrNull { it.id == order.routedDealerId } }

    // ═══ THE DOCUMENT ═══
    // v113-200 — same restyling InvoiceDocumentBody got: plain white
    // masthead with a logo mark instead of an orange gradient banner,
    // colour spent only on the logo, the MEMO label, section bars, the
    // table header, and the total figure.
    Column(
        Modifier.fillMaxWidth()
            .background(Color.White, RoundedCornerShape(4.dp))
            .border(1.dp, HairlineBorder, RoundedCornerShape(4.dp)),
    ) {
        // ── masthead ──
        Row(
            Modifier.fillMaxWidth().padding(Space.lg),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            com.abm.erp.core.DocLogoMark()
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    company.companyName.ifBlank { "ABM Corporation" },
                    color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                )
                val sub = listOfNotNull(
                    company.companyAddress.ifBlank { null },
                    company.companyPhone.ifBlank { null },
                ).joinToString(" · ").ifBlank { "Enterprise. Control. Growth." }
                Text(sub, color = TextSecondary, fontSize = 9.sp, maxLines = 2)
            }
            Text("MEMO", color = DarazOrange, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        }

        Column(Modifier.padding(Space.lg)) {

            // ── meta + QR verification, boxed like the invoice's own meta table ──
            Row(
                Modifier.fillMaxWidth().border(1.dp, HairlineBorder),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f).padding(Space.md)) {
                    DocLabel("Memo No")
                    DocValue(order.orderNo)
                    Spacer(Modifier.height(Space.sm))
                    DocLabel("Date")
                    DocValue(order.loggedAt.toLocalDate().toString())
                }
                Box(Modifier.border(1.dp, HairlineBorder).fillMaxHeight().padding(Space.sm), contentAlignment = Alignment.Center) {
                    // v113-161 — was calling QrRegistry.issue() fresh on every tap,
                    // silently reissuing (and invalidating) an already-printed QR.
                    // DocumentQrControl checks for an existing active code first and
                    // requires an explicit confirm to reissue.
                    com.abm.erp.core.DocumentQrControl("RetailOrder", order.id, onPayloadReady = onQrPayloadReady)
                }
            }

            Spacer(Modifier.height(Space.lg))

            // ── retailer + logging context, bar + boxed like the invoice's "Dealer" ──
            com.abm.erp.core.DocBar("Retailer")
            Row(
                Modifier.fillMaxWidth().border(1.dp, HairlineBorder).padding(Space.md),
                horizontalArrangement = Arrangement.spacedBy(Space.md),
            ) {
                Column(Modifier.weight(1f)) {
                    DocValue(order.retailerName)
                    Text(order.zone, fontSize = 10.sp, color = TextSecondary)
                }
                Column(Modifier.weight(1f)) {
                    DocLabel("Logged By")
                    DocValue(loggedByName)
                    Text(
                        if (order.channel == "wholesale") "Wholesale" else "Retail",
                        fontSize = 10.sp, color = TextSecondary,
                    )
                }
            }
            if (routedDealer != null) {
                Row(Modifier.fillMaxWidth().border(1.dp, HairlineBorder).padding(Space.md)) {
                    Column {
                        DocLabel("Routed To Dealer")
                        DocValue(routedDealer.name)
                    }
                }
            }

            Spacer(Modifier.height(Space.lg))

            // ── item table — real grid, orange masthead, matching the invoice ──
            if (order.lineItems.isNotEmpty()) {
                com.abm.erp.core.DocBar("Memo Items")
                Row(Modifier.fillMaxWidth().background(DarazOrange)) {
                    ThGrid("#", 0.10f); ThGrid("Item / Product", 0.42f); ThGrid("Qty", 0.13f, TextAlign.End)
                    ThGrid("Rate", 0.17f, TextAlign.End); ThGrid("Amount", 0.18f, TextAlign.End)
                }
                order.lineItems.forEachIndexed { i, item ->
                    Row(
                        Modifier.fillMaxWidth().background(if (i % 2 == 1) Color(0xFFF7F8FA) else Color.White),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        TdGrid("%02d".format(i + 1), 0.10f)
                        Column(Modifier.weight(0.42f).border(0.5.dp, HairlineBorder).padding(horizontal = 6.dp, vertical = 7.dp)) {
                            Text(item.name, fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                            Text(item.unit, fontSize = 9.sp, color = TextSecondary)
                        }
                        TdGrid("${item.qty}", 0.13f, TextAlign.End)
                        TdGrid("৳${"%,.0f".format(item.unitPrice)}", 0.17f, TextAlign.End)
                        TdGrid("৳${"%,.0f".format(item.lineTotal)}", 0.18f, TextAlign.End, FontWeight.SemiBold)
                    }
                }
            } else {
                // Pre-structured-memo (v71) orders only ever had a free-text summary —
                // shown honestly as such rather than faked into fabricated rows.
                DocLabel("Items")
                Text(
                    order.items.ifBlank { "কোনো আইটেম বিবরণ নেই।" },
                    fontSize = 12.sp, color = TextPrimary,
                    modifier = Modifier.padding(top = 4.dp, bottom = 8.dp),
                )
            }

            Spacer(Modifier.height(Space.md))

            // ── total — boxed, ledger rule, no heavy banner. Always the
            // order's own `amount` — never re-summed here, so this can
            // never drift from what TSM verification / dealer routing
            // actually see. ──
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Column(Modifier.fillMaxWidth(0.62f).border(1.dp, HairlineBorder).padding(horizontal = Space.md, vertical = 8.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Total", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("৳${"%,.0f".format(order.amount)}", color = DarazOrange, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }

            // ── retailer's standing due (explicitly independent — see file doc comment) ──
            if (retailer != null) {
                Spacer(Modifier.height(Space.md))
                Column(
                    Modifier.fillMaxWidth()
                        .background(Color(0xFFF7F8FA), RoundedCornerShape(10.dp))
                        .padding(Space.md),
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("রিটেইলারের বর্তমান বকেয়া", fontSize = 11.sp, color = TextSecondary)
                        Text(
                            "৳${"%,.0f".format(retailer.dueBalance)}",
                            fontSize = 12.sp,
                            color = if (retailer.dueBalance > 0) StatusAmber else StatusGreen,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "* এই মেমো সরাসরি লেজারে প্রভাব ফেলে না — বিলিং হয় Dealer পর্যায়ে।",
                        fontSize = 8.sp, color = TextSecondary,
                    )
                }
            }

            Spacer(Modifier.height(Space.md))
            Text(
                "In Words: ${amountInWords(order.amount)}",
                fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.Medium,
            )

            Spacer(Modifier.height(Space.xl))

            // ── signatures — reflects the real stage chain (SO → ASM → Dealer), not
            // invoice-style Prepared/Checked/Authorized language that doesn't apply here ──
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
                SignatureSlot("Logged By (SO)", loggedByName, Modifier.weight(1f))
                SignatureSlot("Verified By (ASM)", "", Modifier.weight(1f))
                SignatureSlot("Retailer Signature", "", Modifier.weight(1f))
            }

            Spacer(Modifier.height(Space.lg))
            Text(
                "Thank you for your business!",
                fontSize = 10.sp, color = TextSecondary,
                modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(Space.sm))
        }
    }
}
