package com.abm.erp.data.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        CompanyEntity::class,
        AppUserEntity::class,
        RetailOrderEntity::class,
        DealerEntity::class,
        BulkDealerRequestEntity::class,
        FieldEmployeeRouteEntity::class,
        EngagementCampaignEntity::class,
        AttendanceRecordEntity::class,
        PayrollLineEntity::class,
        InvoiceEntity::class,
        PaymentProofEntity::class,
        RawMaterialLotEntity::class,
        ProductionBatchEntity::class,
        FactoryAttendanceEntity::class,
        PrescriptionCardEntity::class,
        BoardroomQueryEntity::class,
        ProductEntity::class,
        WarehouseEntity::class,
        StockLevelEntity::class,
        StockMovementEntity::class,
        TaskItemEntity::class,
        ApprovalRequestEntity::class,
        CourierPartnerEntity::class,
        ShipmentEntity::class,
        LedgerEntryEntity::class,
        AuditLogEntity::class,
        TerritoryEntity::class,
        RetailerEntity::class,
        RoleDefinitionEntity::class,
        BackupMetadataEntity::class,
        QuotationEntity::class,
        DeliveryChallanEntity::class,
        SalesReturnEntity::class,
        PartyLedgerEntryEntity::class,
        PartyCollectionEntity::class,
        CustomerComplaintEntity::class,
        PurchaseRequestEntity::class,
        StockCountEntity::class,
        SalesOrderEntity::class,
        ClosedPeriodEntity::class,
        EmployeeProfileEntity::class,
        EmployeeAreaAssignmentEntity::class,
        EmployeeAppraisalEntity::class,
        ManufacturingWorkerAssignmentEntity::class,
        EmployeePermissionOverrideEntity::class,
        VacancyEntity::class,
        TargetEntity::class,
        TargetChangeLogEntity::class,
        CorrectionRequestEntity::class,
        AccountingPeriodLockEntity::class,
        NumberSeriesConfigEntity::class,
        OwnershipTransferRecordEntity::class,
        BusinessRuleEntity::class,
        CompanySettingsEntity::class,
        ExpenseEntity::class,
        ProductionPlanEntity::class,
        RawMaterialIssueEntity::class,
        QualityInspectionEntity::class,
        PackingRecordEntity::class,
        CartonEntity::class,
        FinishedGoodsReceiptEntity::class,
        WarehouseTransferEntity::class,
        WarehouseReceiptEntity::class,
        TransferRequestEntity::class,
        DelegationEntity::class,
        RetailerLocationHistoryEntity::class,
        EmployeeLocationSnapshotEntity::class,
        LocationAlertEntity::class,
        TrustedDeviceEntity::class,
        SecurityEventEntity::class,
        GeoOverrideEntity::class,
        ExecutiveExceptionEntity::class,
        ManagementActionEntity::class,
        DecisionQueryAuditEntity::class,
        AdministrativeLocationEntity::class,
        CompanyMarketEntity::class,
        UserAccountEntity::class,
        LoginAttemptEntity::class,
        DiscountRuleEntity::class,
        SalesRouteEntity::class,
        VisitLogEntity::class,
        SupplierEntity::class,
        PurchaseOrderEntity::class,
        GoodsReceivedNoteEntity::class,
        PurchaseReturnEntity::class,
        ProductCategoryEntity::class,
        ProductBrandEntity::class,
        InventoryLotEntity::class,
        DamageReportEntity::class,
        StockTransferEntity::class,
        BillOfMaterialsEntity::class,
        ProductionOrderEntity::class,
        QualityCheckEntity::class,
        ProductionLossEntity::class,
        MachineLogEntity::class,
        ChartOfAccountEntity::class,
        VoucherEntity::class,
        LeadEntity::class,
        OpportunityEntity::class,
        CustomerSegmentEntity::class,
        CallLogEntity::class,
        MeetingLogEntity::class,
        FollowUpEntity::class,
        LeaveRequestEntity::class,
        EmployeeLifecycleEventEntity::class,
        ChatMessageEntity::class,
        AnnouncementEntity::class,
        CircularEntity::class,
        VehicleEntity::class,
        VehicleLocationPingEntity::class,
        AttachmentEntity::class,
        NotificationEntryEntity::class,
        QrRegistryEntity::class,
        QrScanLogEntity::class,
        DealerStockLineEntity::class,
        RetailerStockLineEntity::class, // v113-75
    ],
    version = 93,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun companyDao(): CompanyDao
    abstract fun appUserDao(): AppUserDao
    abstract fun retailOrderDao(): RetailOrderDao
    abstract fun dealerDao(): DealerDao
    abstract fun fieldEmployeeRouteDao(): FieldEmployeeRouteDao
    abstract fun engagementCampaignDao(): EngagementCampaignDao
    abstract fun payrollDao(): PayrollDao
    abstract fun invoiceDao(): InvoiceDao
    abstract fun paymentProofDao(): PaymentProofDao
    abstract fun rawMaterialLotDao(): RawMaterialLotDao
    abstract fun productionBatchDao(): ProductionBatchDao
    abstract fun prescriptionCardDao(): PrescriptionCardDao
    abstract fun boardroomQueryDao(): BoardroomQueryDao
    abstract fun productDao(): ProductDao
    abstract fun warehouseDao(): WarehouseDao
    abstract fun stockDao(): StockDao
    abstract fun taskDao(): TaskDao
    abstract fun approvalDao(): ApprovalDao
    abstract fun courierDao(): CourierDao
    abstract fun shipmentDao(): ShipmentDao
    abstract fun ledgerDao(): LedgerDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun territoryDao(): TerritoryDao
    abstract fun retailerDao(): RetailerDao
    abstract fun roleDefinitionDao(): RoleDefinitionDao
    abstract fun backupDao(): BackupDao
    abstract fun quotationDao(): QuotationDao
    abstract fun deliveryChallanDao(): DeliveryChallanDao
    abstract fun salesReturnDao(): SalesReturnDao
    abstract fun partyLedgerDao(): PartyLedgerDao
    abstract fun partyCollectionDao(): PartyCollectionDao
    abstract fun customerComplaintDao(): CustomerComplaintDao
    abstract fun purchaseRequestDao(): PurchaseRequestDao
    abstract fun stockCountDao(): StockCountDao
    abstract fun salesOrderDao(): SalesOrderDao
    abstract fun closedPeriodDao(): ClosedPeriodDao
    abstract fun employeeProfileDao(): EmployeeProfileDao
    abstract fun employeeAreaAssignmentDao(): EmployeeAreaAssignmentDao
    abstract fun employeeAppraisalDao(): EmployeeAppraisalDao
    abstract fun manufacturingWorkerAssignmentDao(): ManufacturingWorkerAssignmentDao
    abstract fun employeePermissionOverrideDao(): EmployeePermissionOverrideDao
    abstract fun vacancyDao(): VacancyDao
    abstract fun targetDao(): TargetDao
    abstract fun targetChangeLogDao(): TargetChangeLogDao
    abstract fun correctionRequestDao(): CorrectionRequestDao
    abstract fun accountingPeriodLockDao(): AccountingPeriodLockDao
    abstract fun numberSeriesConfigDao(): NumberSeriesConfigDao
    abstract fun ownershipTransferRecordDao(): OwnershipTransferRecordDao
    abstract fun businessRuleDao(): BusinessRuleDao
    abstract fun companySettingsDao(): CompanySettingsDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun productionPlanDao(): ProductionPlanDao
    abstract fun rawMaterialIssueDao(): RawMaterialIssueDao
    abstract fun qualityInspectionDao(): QualityInspectionDao
    abstract fun packingRecordDao(): PackingRecordDao
    abstract fun cartonDao(): CartonDao
    abstract fun finishedGoodsReceiptDao(): FinishedGoodsReceiptDao
    abstract fun warehouseTransferDao(): WarehouseTransferDao
    abstract fun warehouseReceiptDao(): WarehouseReceiptDao
    abstract fun transferRequestDao(): TransferRequestDao
    abstract fun delegationDao(): DelegationDao
    abstract fun retailerLocationHistoryDao(): RetailerLocationHistoryDao
    abstract fun employeeLocationSnapshotDao(): EmployeeLocationSnapshotDao
    abstract fun locationAlertDao(): LocationAlertDao
    abstract fun trustedDeviceDao(): TrustedDeviceDao
    abstract fun securityEventDao(): SecurityEventDao
    abstract fun geoOverrideDao(): GeoOverrideDao
    abstract fun executiveExceptionDao(): ExecutiveExceptionDao
    abstract fun managementActionDao(): ManagementActionDao
    abstract fun decisionQueryAuditDao(): DecisionQueryAuditDao
    abstract fun administrativeLocationDao(): AdministrativeLocationDao
    abstract fun companyMarketDao(): CompanyMarketDao
    abstract fun userAccountDao(): UserAccountDao
    abstract fun loginAttemptDao(): LoginAttemptDao
    abstract fun discountRuleDao(): DiscountRuleDao
    abstract fun salesRouteDao(): SalesRouteDao
    abstract fun visitLogDao(): VisitLogDao
    abstract fun supplierDao(): SupplierDao
    abstract fun purchaseOrderDao(): PurchaseOrderDao
    abstract fun goodsReceivedNoteDao(): GoodsReceivedNoteDao
    abstract fun purchaseReturnDao(): PurchaseReturnDao
    abstract fun productCategoryDao(): ProductCategoryDao
    abstract fun productBrandDao(): ProductBrandDao
    abstract fun inventoryLotDao(): InventoryLotDao
    abstract fun damageReportDao(): DamageReportDao
    abstract fun stockTransferDao(): StockTransferDao
    abstract fun billOfMaterialsDao(): BillOfMaterialsDao
    abstract fun productionOrderDao(): ProductionOrderDao
    abstract fun qualityCheckDao(): QualityCheckDao
    abstract fun productionLossDao(): ProductionLossDao
    abstract fun machineLogDao(): MachineLogDao
    abstract fun chartOfAccountDao(): ChartOfAccountDao
    abstract fun voucherDao(): VoucherDao
    abstract fun leadDao(): LeadDao
    abstract fun opportunityDao(): OpportunityDao
    abstract fun customerSegmentDao(): CustomerSegmentDao
    abstract fun callLogDao(): CallLogDao
    abstract fun meetingLogDao(): MeetingLogDao
    abstract fun followUpDao(): FollowUpDao
    abstract fun leaveRequestDao(): LeaveRequestDao
    abstract fun employeeLifecycleEventDao(): EmployeeLifecycleEventDao
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun announcementDao(): AnnouncementDao
    abstract fun circularDao(): CircularDao
    abstract fun vehicleDao(): VehicleDao
    abstract fun vehicleLocationPingDao(): VehicleLocationPingDao
    abstract fun attachmentDao(): AttachmentDao
    abstract fun notificationEntryDao(): NotificationEntryDao
    abstract fun qrRegistryDao(): QrRegistryDao
    abstract fun qrScanLogDao(): QrScanLogDao
    abstract fun dealerStockLineDao(): DealerStockLineDao
    abstract fun retailerStockLineDao(): RetailerStockLineDao // v113-75

    companion object {
        @Volatile private var instance: AppDatabase? = null

        // v86, Module 3 — real, accurate migration for the Weekly 50% Due
        // Rule fields added to `dealers` in this same change. Unlike the
        // 1-22 gap (no historical schema exists to verify against), this
        // migration IS accurate: it was written directly from the exact
        // DealerEntity fields added above, all as nullable/defaulted
        // ADD COLUMN statements — purely additive, drops nothing, and every
        // existing row gets sensible defaults (monthlyTarget=0 means the
        // rule is simply not configured yet for that dealer, not an error).
        private val MIGRATION_23_24 = object : Migration(23, 24) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE dealers ADD COLUMN monthlyTarget REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE dealers ADD COLUMN weeklyPaidAmount REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE dealers ADD COLUMN weekStartEpochDay INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE dealers ADD COLUMN creditStatus TEXT NOT NULL DEFAULT 'ACTIVE'")
                db.execSQL("ALTER TABLE dealers ADD COLUMN creditStatusReason TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN creditStatusChangedBy TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN creditStatusChangedAtEpochMillis INTEGER")
            }
        }

        // v86, Module 5 — Collection invoice allocation needs a paidAmount
        // column on invoices; same accuracy guarantee as MIGRATION_23_24
        // (written directly from this change's own field addition).
        private val MIGRATION_24_25 = object : Migration(24, 25) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE invoices ADD COLUMN paidAmount REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE party_collections ADD COLUMN allocatedInvoiceId TEXT")
            }
        }

        // v86, Module 15 — new table for Customer Complaints (CREATE TABLE
        // only; no existing table touched, so this is zero-risk to old data).
        private val MIGRATION_25_26 = object : Migration(25, 26) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `customer_complaints` (
                        `id` TEXT NOT NULL, `complaintNo` TEXT NOT NULL, `dealerId` TEXT NOT NULL,
                        `dealerName` TEXT NOT NULL, `productId` TEXT, `productName` TEXT,
                        `invoiceId` TEXT, `invoiceNo` TEXT, `category` TEXT NOT NULL,
                        `description` TEXT NOT NULL, `priority` TEXT NOT NULL, `status` TEXT NOT NULL,
                        `assignedEmployeeId` TEXT, `assignedEmployeeName` TEXT, `resolutionNote` TEXT,
                        `createdBy` TEXT NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL,
                        `resolvedAtEpochMillis` INTEGER, `isDeleted` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
            }
        }

        // v86, Module 7 — new table for Purchase Requisition (CREATE TABLE
        // only; no existing table touched).
        private val MIGRATION_26_27 = object : Migration(26, 27) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `purchase_requests` (
                        `id` TEXT NOT NULL, `requestNo` TEXT NOT NULL, `lineItemsRaw` TEXT NOT NULL,
                        `requiredByEpochMillis` INTEGER, `reason` TEXT NOT NULL, `status` TEXT NOT NULL,
                        `convertedToPoId` TEXT, `createdBy` TEXT NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL,
                        `approvedBy` TEXT, `approvedAtEpochMillis` INTEGER, `rejectReason` TEXT,
                        `isDeleted` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
            }
        }

        // v86, Module 3/5 — Promise-to-Pay / Broken Commitment fields on dealers.
        private val MIGRATION_27_28 = object : Migration(27, 28) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE dealers ADD COLUMN promiseToPayEpochMillis INTEGER")
                db.execSQL("ALTER TABLE dealers ADD COLUMN promiseToPayAmount REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE dealers ADD COLUMN promiseNote TEXT")
            }
        }

        // v86 — Stock Reservation column on stock_levels.
        private val MIGRATION_28_29 = object : Migration(28, 29) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE stock_levels ADD COLUMN reservedQty REAL NOT NULL DEFAULT 0.0")
            }
        }

        // v86 — Shift Planning column on attendance_records.
        private val MIGRATION_29_30 = object : Migration(29, 30) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE attendance_records ADD COLUMN shiftType TEXT NOT NULL DEFAULT 'GENERAL'")
            }
        }

        // v86 — RFQ supplier quotes column on purchase_requests.
        private val MIGRATION_30_31 = object : Migration(30, 31) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE purchase_requests ADD COLUMN supplierQuotesRaw TEXT NOT NULL DEFAULT '[]'")
            }
        }

        // v86, Module 6 — new table for Stock-Count workflow (CREATE TABLE only).
        private val MIGRATION_31_32 = object : Migration(31, 32) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `stock_counts` (
                        `id` TEXT NOT NULL, `countNo` TEXT NOT NULL, `warehouseId` TEXT NOT NULL,
                        `warehouseName` TEXT NOT NULL, `linesRaw` TEXT NOT NULL, `status` TEXT NOT NULL,
                        `createdBy` TEXT NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL,
                        `approvedBy` TEXT, `approvedAtEpochMillis` INTEGER, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
            }
        }

        // v86, Module 4 — new table for Sales Order stage (CREATE TABLE only).
        private val MIGRATION_32_33 = object : Migration(32, 33) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `sales_orders` (
                        `id` TEXT NOT NULL, `orderNo` TEXT NOT NULL, `dealerId` TEXT NOT NULL,
                        `dealerName` TEXT NOT NULL, `dealerZone` TEXT NOT NULL, `lineItemsRaw` TEXT NOT NULL,
                        `dealerDiscountPct` REAL NOT NULL, `status` TEXT NOT NULL, `convertedToInvoiceId` TEXT,
                        `deliveredQtyRaw` TEXT NOT NULL, `createdBy` TEXT NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL,
                        `approvedBy` TEXT, `approvedAtEpochMillis` INTEGER, `isDeleted` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
            }
        }

        // v86, Module 4 — cost basis for real Margin/Profit Analysis.
        private val MIGRATION_33_34 = object : Migration(33, 34) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE products ADD COLUMN costPrice REAL NOT NULL DEFAULT 0.0")
            }
        }

        // v86, Module 9 — new table for Financial Closing (CREATE TABLE only).
        private val MIGRATION_34_35 = object : Migration(34, 35) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `closed_periods` (
                        `yearMonth` TEXT NOT NULL, `closedBy` TEXT NOT NULL, `closedAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`yearMonth`)
                    )
                    """.trimIndent(),
                )
            }
        }

        // v87, Retailer Management Excellence Foundation 1 — Master Profile fields.
        private val MIGRATION_35_36 = object : Migration(35, 36) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE retailers ADD COLUMN retailerCode TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN ownerName TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN altPhone TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN email TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN district TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN upazila TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN union_ TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN market TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN area TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN postalCode TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN gpsAccuracyMeters REAL")
                db.execSQL("ALTER TABLE retailers ADD COLUMN geoCapturedAtEpochMillis INTEGER")
                db.execSQL("ALTER TABLE retailers ADD COLUMN ownerPhotoUri TEXT")
                db.execSQL("ALTER TABLE retailers ADD COLUMN tradeLicenseNo TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN nidRef TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN classification TEXT NOT NULL DEFAULT 'B'")
                db.execSQL("ALTER TABLE retailers ADD COLUMN businessStatus TEXT NOT NULL DEFAULT 'ACTIVE'")
                db.execSQL("ALTER TABLE retailers ADD COLUMN statusReason TEXT")
                db.execSQL("ALTER TABLE retailers ADD COLUMN openingDateEpochDay INTEGER")
                db.execSQL("ALTER TABLE retailers ADD COLUMN officerId TEXT")
                db.execSQL("ALTER TABLE retailers ADD COLUMN officerName TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN paymentTermsDays INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE retailers ADD COLUMN allowedCreditDays INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE retailers ADD COLUMN lastCollectionDateEpochMillis INTEGER")
                db.execSQL("ALTER TABLE retailers ADD COLUMN lastOrderDateEpochMillis INTEGER")
                db.execSQL("ALTER TABLE retailers ADD COLUMN lastVisitDateEpochMillis INTEGER")
                db.execSQL("ALTER TABLE retailers ADD COLUMN nextPlannedVisitEpochMillis INTEGER")
                db.execSQL("ALTER TABLE retailers ADD COLUMN preferredProducts TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN notes TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN tags TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN updatedBy TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE retailers ADD COLUMN updatedAtEpochMillis INTEGER")
                db.execSQL("ALTER TABLE retailers ADD COLUMN creditHold INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE retailers ADD COLUMN creditHoldReason TEXT")
                // Existing retailers predate the onboarding workflow — they were
                // already operating, so they default straight to ACTIVE rather
                // than being retroactively forced through Draft/Approval.
                db.execSQL("ALTER TABLE retailers ADD COLUMN onboardingStatus TEXT NOT NULL DEFAULT 'ACTIVE'")
                db.execSQL("ALTER TABLE retailers ADD COLUMN rejectReason TEXT")
            }
        }

        // v87 fix — standardDiscountPct/commissionPct existed on the domain
        // Retailer model but had no matching Entity column at all; any
        // value set on them was silently lost on every save/load. This is
        // the migration that was missing.
        private val MIGRATION_36_37 = object : Migration(36, 37) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE retailers ADD COLUMN standardDiscountPct REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE retailers ADD COLUMN commissionPct REAL NOT NULL DEFAULT 0.0")
            }
        }

        // v87, Foundation 2 — new table for the real Employee Profile system.
        private val MIGRATION_37_38 = object : Migration(37, 38) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `employee_profiles` (
                        `id` TEXT NOT NULL, `employeeCode` TEXT NOT NULL, `userAccountId` TEXT,
                        `fullName` TEXT NOT NULL, `mobile` TEXT NOT NULL, `email` TEXT NOT NULL,
                        `department` TEXT NOT NULL, `designation` TEXT NOT NULL, `role` TEXT NOT NULL,
                        `grade` TEXT NOT NULL, `employmentType` TEXT NOT NULL, `joiningDateEpochDay` INTEGER,
                        `status` TEXT NOT NULL, `statusReason` TEXT, `companyId` TEXT NOT NULL,
                        `branch` TEXT NOT NULL, `region` TEXT NOT NULL, `area` TEXT NOT NULL,
                        `territoryId` TEXT, `routeId` TEXT, `directManagerId` TEXT, `secondaryManagerId` TEXT,
                        `functionalManagerId` TEXT, `reportingEffectiveFromEpochDay` INTEGER, `reportingEffectiveToEpochDay` INTEGER,
                        `tempManagerId` TEXT, `tempAssignmentFromEpochDay` INTEGER, `tempAssignmentToEpochDay` INTEGER,
                        `approvalAuthorityLevel` INTEGER NOT NULL, `financialApprovalLimit` REAL NOT NULL,
                        `creditOverrideLimit` REAL NOT NULL, `discountApprovalLimitPct` REAL NOT NULL,
                        `stockAdjustmentApprovalLimit` REAL NOT NULL, `purchaseApprovalLimit` REAL NOT NULL,
                        `leaveApprovalAuthority` INTEGER NOT NULL, `attendanceCorrectionAuthority` INTEGER NOT NULL,
                        `dataAccessScope` TEXT NOT NULL, `onboardingStatus` TEXT NOT NULL, `rejectReason` TEXT,
                        `createdBy` TEXT NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL,
                        `updatedBy` TEXT NOT NULL, `updatedAtEpochMillis` INTEGER,
                        `isDeleted` INTEGER NOT NULL, `deletedAtEpochMillis` INTEGER, `deletedBy` TEXT,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_profiles_directManagerId ON employee_profiles(directManagerId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_profiles_territoryId ON employee_profiles(territoryId)")
            }
        }

        // v87, Foundation 2, Sections 10+12 — new tables for Transfer and Delegation.
        private val MIGRATION_38_39 = object : Migration(38, 39) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `transfer_requests` (
                        `id` TEXT NOT NULL, `employeeId` TEXT NOT NULL, `employeeName` TEXT NOT NULL,
                        `transferType` TEXT NOT NULL, `fromValue` TEXT NOT NULL, `toValue` TEXT NOT NULL,
                        `newManagerId` TEXT, `effectiveDateEpochDay` INTEGER NOT NULL, `reason` TEXT NOT NULL,
                        `retailerHandoverToEmployeeId` TEXT, `stage` TEXT NOT NULL, `rejectReason` TEXT,
                        `createdBy` TEXT NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `delegations` (
                        `id` TEXT NOT NULL, `delegatorId` TEXT NOT NULL, `delegatorName` TEXT NOT NULL,
                        `delegateId` TEXT NOT NULL, `delegateName` TEXT NOT NULL, `scope` TEXT NOT NULL,
                        `financialLimit` REAL NOT NULL, `startDateEpochDay` INTEGER NOT NULL, `endDateEpochDay` INTEGER NOT NULL,
                        `reason` TEXT NOT NULL, `isActive` INTEGER NOT NULL, `createdBy` TEXT NOT NULL,
                        `createdAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
            }
        }

        // v88 fix, Foundation 2 Section 18 — real dedicated reason/approval-reference columns on audit_log (previously only embedded as free text inside newValueJson).
        private val MIGRATION_39_40 = object : Migration(39, 40) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE audit_log ADD COLUMN reason TEXT")
                db.execSQL("ALTER TABLE audit_log ADD COLUMN relatedApprovalId TEXT")
            }
        }

        // v89, Foundation 3 — real check-in/check-out verification columns on visit_logs (was only lat/lng/photo/purpose/checkin/checkout).
        private val MIGRATION_40_41 = object : Migration(40, 41) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN routeId TEXT")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN checkInAccuracyMeters REAL")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN checkInProvider TEXT")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN checkInMockSuspected INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN checkInDistanceFromRetailerMeters REAL")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN checkOutLat REAL")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN checkOutLng REAL")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN checkOutAccuracyMeters REAL")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN checkOutMockSuspected INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN checkOutDistanceFromRetailerMeters REAL")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN deviceId TEXT")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN verificationResult TEXT NOT NULL DEFAULT 'PENDING'")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN verificationScore INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN overrideReason TEXT")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN overrideBy TEXT")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN orderCreatedId TEXT")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN collectionCreatedId TEXT")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN complaintCreatedId TEXT")
                db.execSQL("ALTER TABLE visit_logs ADD COLUMN notes TEXT NOT NULL DEFAULT ''")
            }
        }

        // v89, Foundation 3 — Retailer Location Master fields + 4 new tables.
        private val MIGRATION_41_42 = object : Migration(41, 42) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE retailers ADD COLUMN locationProvider TEXT")
                db.execSQL("ALTER TABLE retailers ADD COLUMN locationCapturedByEmployeeId TEXT")
                db.execSQL("ALTER TABLE retailers ADD COLUMN locationCapturedDeviceId TEXT")
                db.execSQL("ALTER TABLE retailers ADD COLUMN locationCaptureMethod TEXT NOT NULL DEFAULT 'GPS'")
                db.execSQL("ALTER TABLE retailers ADD COLUMN locationVerificationStatus TEXT NOT NULL DEFAULT 'NOT_CAPTURED'")
                db.execSQL("ALTER TABLE retailers ADD COLUMN locationVerificationScore INTEGER")
                db.execSQL("ALTER TABLE retailers ADD COLUMN locationVerifiedBy TEXT")
                db.execSQL("ALTER TABLE retailers ADD COLUMN locationVerifiedAtEpochMillis INTEGER")
                db.execSQL("ALTER TABLE retailers ADD COLUMN locationVerificationComment TEXT")
                db.execSQL("ALTER TABLE retailers ADD COLUMN geofenceRadiusMeters REAL")
                db.execSQL("ALTER TABLE retailers ADD COLUMN lastLocationUpdateReason TEXT")
                db.execSQL("ALTER TABLE retailers ADD COLUMN locationRevision INTEGER NOT NULL DEFAULT 0")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `retailer_location_history` (
                        `id` TEXT NOT NULL, `retailerId` TEXT NOT NULL, `previousLat` REAL, `previousLng` REAL,
                        `previousAccuracyMeters` REAL, `newLat` REAL NOT NULL, `newLng` REAL NOT NULL, `newAccuracyMeters` REAL,
                        `changeReason` TEXT NOT NULL, `changedBy` TEXT NOT NULL, `changedAtEpochMillis` INTEGER NOT NULL,
                        `distanceFromPreviousMeters` REAL, `revisionNumber` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_retailer_location_history_retailerId ON retailer_location_history(retailerId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_retailer_location_history_changedAtEpochMillis ON retailer_location_history(changedAtEpochMillis)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `employee_location_snapshots` (
                        `id` TEXT NOT NULL, `employeeId` TEXT NOT NULL, `employeeName` TEXT NOT NULL,
                        `lat` REAL NOT NULL, `lng` REAL NOT NULL, `accuracyMeters` REAL, `provider` TEXT,
                        `batteryPct` INTEGER, `mockSuspected` INTEGER NOT NULL, `deviceId` TEXT, `visitId` TEXT,
                        `routeId` TEXT, `capturedAtEpochMillis` INTEGER NOT NULL, `syncStatus` TEXT NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_location_snapshots_employeeId ON employee_location_snapshots(employeeId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_location_snapshots_capturedAtEpochMillis ON employee_location_snapshots(capturedAtEpochMillis)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_location_snapshots_visitId ON employee_location_snapshots(visitId)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `location_alerts` (
                        `id` TEXT NOT NULL, `type` TEXT NOT NULL, `severity` TEXT NOT NULL, `employeeId` TEXT,
                        `retailerId` TEXT, `visitId` TEXT, `message` TEXT NOT NULL, `evidenceJson` TEXT,
                        `isReviewed` INTEGER NOT NULL, `reviewedBy` TEXT, `reviewedAtEpochMillis` INTEGER,
                        `reviewAction` TEXT, `reviewComment` TEXT, `createdAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_location_alerts_employeeId ON location_alerts(employeeId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_location_alerts_retailerId ON location_alerts(retailerId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_location_alerts_type ON location_alerts(type)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_location_alerts_isReviewed ON location_alerts(isReviewed)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `trusted_devices` (
                        `id` TEXT NOT NULL, `deviceId` TEXT NOT NULL, `employeeId` TEXT NOT NULL,
                        `firstRegisteredAtEpochMillis` INTEGER NOT NULL, `lastActiveAtEpochMillis` INTEGER NOT NULL,
                        `status` TEXT NOT NULL, `osVersion` TEXT NOT NULL, `appVersion` TEXT NOT NULL,
                        `lastLocationAtEpochMillis` INTEGER, `mockSuspicionCount` INTEGER NOT NULL,
                        `failedVerificationCount` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_trusted_devices_employeeId ON trusted_devices(employeeId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_trusted_devices_deviceId ON trusted_devices(deviceId)")
            }
        }

        // v90, Foundation 4 — Territory Master + Polygon Geofence columns.
        private val MIGRATION_42_43 = object : Migration(42, 43) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE territories ADD COLUMN code TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE territories ADD COLUMN polygonRaw TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE territories ADD COLUMN polygonVersion INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE territories ADD COLUMN defaultVisitRadiusMeters REAL NOT NULL DEFAULT 100.0")
                db.execSQL("ALTER TABLE territories ADD COLUMN isActive INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE territories ADD COLUMN effectiveFromEpochDay INTEGER")
                db.execSQL("ALTER TABLE territories ADD COLUMN effectiveToEpochDay INTEGER")
                db.execSQL("ALTER TABLE territories ADD COLUMN assignedManagerIdsRaw TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE territories ADD COLUMN assignedOfficerIdsRaw TEXT NOT NULL DEFAULT ''")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `security_events` (
                        `id` TEXT NOT NULL, `type` TEXT NOT NULL, `severity` TEXT NOT NULL, `employeeId` TEXT NOT NULL,
                        `employeeName` TEXT NOT NULL, `territoryId` TEXT, `action` TEXT NOT NULL, `lat` REAL, `lng` REAL,
                        `distanceMeters` REAL, `message` TEXT NOT NULL, `deviceId` TEXT, `isReviewed` INTEGER NOT NULL,
                        `reviewedBy` TEXT, `reviewedAtEpochMillis` INTEGER, `reviewAction` TEXT, `reviewComment` TEXT,
                        `createdAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_security_events_employeeId ON security_events(employeeId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_security_events_createdAtEpochMillis ON security_events(createdAtEpochMillis)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `geo_overrides` (
                        `id` TEXT NOT NULL, `employeeId` TEXT NOT NULL, `employeeName` TEXT NOT NULL,
                        `actionType` TEXT NOT NULL, `reason` TEXT NOT NULL, `approvedBy` TEXT NOT NULL,
                        `createdAtEpochMillis` INTEGER NOT NULL, `expiresAtEpochMillis` INTEGER NOT NULL,
                        `used` INTEGER NOT NULL, `usedAtEpochMillis` INTEGER, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_geo_overrides_employeeId ON geo_overrides(employeeId)")
            }
        }

        // v92, Foundation 6 — Executive Command Center tables.
        private val MIGRATION_43_44 = object : Migration(43, 44) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `executive_exceptions` (
                        `id` TEXT NOT NULL, `type` TEXT NOT NULL, `severity` TEXT NOT NULL, `source` TEXT NOT NULL,
                        `companyId` TEXT NOT NULL, `branch` TEXT NOT NULL, `territoryId` TEXT, `responsiblePerson` TEXT NOT NULL,
                        `message` TEXT NOT NULL, `impact` TEXT NOT NULL, `recommendedAction` TEXT NOT NULL, `status` TEXT NOT NULL,
                        `assignedReviewer` TEXT, `resolutionNote` TEXT, `dedupKey` TEXT NOT NULL,
                        `createdAtEpochMillis` INTEGER NOT NULL, `updatedAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_executive_exceptions_type ON executive_exceptions(type)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_executive_exceptions_status ON executive_exceptions(status)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_executive_exceptions_createdAtEpochMillis ON executive_exceptions(createdAtEpochMillis)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `management_actions` (
                        `id` TEXT NOT NULL, `title` TEXT NOT NULL, `sourceExceptionId` TEXT, `assignedTo` TEXT NOT NULL,
                        `priority` TEXT NOT NULL, `dueDateEpochDay` INTEGER, `status` TEXT NOT NULL, `comment` TEXT NOT NULL,
                        `evidence` TEXT NOT NULL, `completionNote` TEXT, `createdBy` TEXT NOT NULL,
                        `createdAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_management_actions_assignedTo ON management_actions(assignedTo)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_management_actions_status ON management_actions(status)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `decision_query_audit` (
                        `id` TEXT NOT NULL, `question` TEXT NOT NULL, `matchedIntent` TEXT, `askedBy` TEXT NOT NULL,
                        `resultSummary` TEXT NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_decision_query_audit_askedBy ON decision_query_audit(askedBy)")
            }
        }

        // v93 — Bangladesh Offline Administrative Location Master.
        private val MIGRATION_44_45 = object : Migration(44, 45) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `administrative_locations` (
                        `id` TEXT NOT NULL, `officialCode` TEXT, `sourceCode` TEXT NOT NULL, `type` TEXT NOT NULL,
                        `nameEn` TEXT NOT NULL, `nameBn` TEXT NOT NULL, `normalizedName` TEXT NOT NULL, `parentId` TEXT,
                        `countryCode` TEXT NOT NULL, `divisionId` TEXT, `districtId` TEXT, `upazilaId` TEXT,
                        `unionOrMunicipalityId` TEXT, `wardId` TEXT, `latitude` REAL, `longitude` REAL, `polygonRaw` TEXT NOT NULL,
                        `sourceName` TEXT NOT NULL, `sourceUrl` TEXT NOT NULL, `sourceVersion` TEXT NOT NULL,
                        `effectiveFromEpochDay` INTEGER, `effectiveToEpochDay` INTEGER, `active` INTEGER NOT NULL,
                        `verified` INTEGER NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL, `updatedAtEpochMillis` INTEGER NOT NULL,
                        `syncStatus` TEXT NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_administrative_locations_officialCode ON administrative_locations(officialCode)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_administrative_locations_type ON administrative_locations(type)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_administrative_locations_parentId ON administrative_locations(parentId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_administrative_locations_divisionId ON administrative_locations(divisionId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_administrative_locations_districtId ON administrative_locations(districtId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_administrative_locations_upazilaId ON administrative_locations(upazilaId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_administrative_locations_nameEn ON administrative_locations(nameEn)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_administrative_locations_nameBn ON administrative_locations(nameBn)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_administrative_locations_normalizedName ON administrative_locations(normalizedName)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_administrative_locations_active ON administrative_locations(active)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `company_markets` (
                        `id` TEXT NOT NULL, `name` TEXT NOT NULL, `parentAdminId` TEXT NOT NULL, `latitude` REAL, `longitude` REAL,
                        `source` TEXT NOT NULL, `verificationStatus` TEXT NOT NULL, `createdBy` TEXT NOT NULL,
                        `createdAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_company_markets_parentAdminId ON company_markets(parentAdminId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_company_markets_verificationStatus ON company_markets(verificationStatus)")
            }
        }

        // v94 — Part A: real UserAccount/PBKDF2 credential storage.
        private val MIGRATION_45_46 = object : Migration(45, 46) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `user_accounts` (
                        `id` TEXT NOT NULL, `employeeProfileId` TEXT NOT NULL, `companyId` TEXT NOT NULL,
                        `pinHash` TEXT NOT NULL, `pinSalt` TEXT NOT NULL, `pinIterations` INTEGER NOT NULL,
                        `pinSetAtEpochMillis` INTEGER NOT NULL, `pinExpiresAtEpochMillis` INTEGER,
                        `failedAttempts` INTEGER NOT NULL, `lockedUntilEpochMillis` INTEGER, `active` INTEGER NOT NULL,
                        `locked` INTEGER NOT NULL, `mustChangePinOnNextLogin` INTEGER NOT NULL,
                        `createdAtEpochMillis` INTEGER NOT NULL, `updatedAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_user_accounts_employeeProfileId ON user_accounts(employeeProfileId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_user_accounts_companyId ON user_accounts(companyId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_user_accounts_active ON user_accounts(active)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `login_attempts` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `userAccountId` TEXT NOT NULL,
                        `success` INTEGER NOT NULL, `deviceId` TEXT, `attemptedAtEpochMillis` INTEGER NOT NULL
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_login_attempts_userAccountId ON login_attempts(userAccountId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_login_attempts_attemptedAtEpochMillis ON login_attempts(attemptedAtEpochMillis)")
            }
        }

        // v95 — Part J: Dealer administrative master references.
        private val MIGRATION_46_47 = object : Migration(46, 47) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE dealers ADD COLUMN divisionId TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN districtId TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN upazilaId TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN unionId TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN wardId TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN routeId TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN legacyAddressResolved INTEGER NOT NULL DEFAULT 0")
            }
        }

        // v95, Part K — Employee posting authoritative reference IDs.
        private val MIGRATION_47_48 = object : Migration(47, 48) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE employee_profiles ADD COLUMN branchId TEXT")
                db.execSQL("ALTER TABLE employee_profiles ADD COLUMN departmentId TEXT")
                db.execSQL("ALTER TABLE employee_profiles ADD COLUMN divisionId TEXT")
                db.execSQL("ALTER TABLE employee_profiles ADD COLUMN districtId TEXT")
                db.execSQL("ALTER TABLE employee_profiles ADD COLUMN upazilaId TEXT")
                db.execSQL("ALTER TABLE employee_profiles ADD COLUMN unionId TEXT")
            }
        }

        // v96, RC-1 audit — Dealer PIN hashing (real vulnerability found:
        // DealerLoginScreen compared plaintext PIN against a "0000"-default
        // field, same class of bug already fixed for employee login).
        private val MIGRATION_48_49 = object : Migration(48, 49) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE dealers ADD COLUMN pinHash TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN pinSalt TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN pinIterations INTEGER NOT NULL DEFAULT 120000")
            }
        }

        // Phase 1 — Dealer Add/Approval practical fields.
        private val MIGRATION_49_50 = object : Migration(49, 50) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE dealers ADD COLUMN dealerCode TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE dealers ADD COLUMN proprietorName TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE dealers ADD COLUMN altPhone TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE dealers ADD COLUMN nationalId TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN email TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN marketName TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN lat REAL")
                db.execSQL("ALTER TABLE dealers ADD COLUMN lng REAL")
                db.execSQL("ALTER TABLE dealers ADD COLUMN assignedEmployeeId TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN assignedManagerId TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN openingBalance REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE dealers ADD COLUMN paymentTermsDays INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE dealers ADD COLUMN tradeLicenseNumber TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN notes TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN status TEXT NOT NULL DEFAULT 'DRAFT'")
                db.execSQL("UPDATE dealers SET status = 'ACTIVE' WHERE isActive = 1")
                db.execSQL("UPDATE dealers SET status = 'PENDING_APPROVAL' WHERE isActive = 0 AND isDeleted = 0")
                db.execSQL("ALTER TABLE dealers ADD COLUMN approvedBy TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN approvedByName TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN approvedAtEpochMillis INTEGER")
                db.execSQL("ALTER TABLE dealers ADD COLUMN approvalComment TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN previousStatus TEXT")
                db.execSQL("ALTER TABLE dealers ADD COLUMN resolvedApprovalPath TEXT")
                db.execSQL("UPDATE dealers SET dealerCode = 'ABM-DLR-LEGACY-' || substr(id, 1, 8) WHERE dealerCode = ''")
            }
        }

        // Phase 2 — Employee Add practical fields.
        private val MIGRATION_50_51 = object : Migration(50, 51) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE employee_profiles ADD COLUMN nationalId TEXT")
                db.execSQL("ALTER TABLE employee_profiles ADD COLUMN dateOfBirthEpochDay INTEGER")
                db.execSQL("ALTER TABLE employee_profiles ADD COLUMN workLocation TEXT")
                db.execSQL("ALTER TABLE employee_profiles ADD COLUMN emergencyContactName TEXT")
                db.execSQL("ALTER TABLE employee_profiles ADD COLUMN emergencyContactPhone TEXT")
                db.execSQL("ALTER TABLE employee_profiles ADD COLUMN profilePhotoUri TEXT")
                db.execSQL("ALTER TABLE employee_profiles ADD COLUMN basePayMonthly REAL NOT NULL DEFAULT 0.0")
            }
        }

        // Phase 3 — Employee Area/Territory Selection, new table.
        private val MIGRATION_51_52 = object : Migration(51, 52) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `employee_area_assignments` (
                        `id` TEXT NOT NULL, `employeeId` TEXT NOT NULL, `companyId` TEXT NOT NULL,
                        `divisionId` TEXT, `divisionName` TEXT, `districtId` TEXT, `districtName` TEXT,
                        `upazilaId` TEXT, `upazilaName` TEXT, `unionId` TEXT, `unionName` TEXT,
                        `marketName` TEXT, `routeId` TEXT, `assignmentType` TEXT NOT NULL,
                        `startDateEpochDay` INTEGER NOT NULL, `endDateEpochDay` INTEGER, `assignedBy` TEXT NOT NULL,
                        `approvalStatus` TEXT NOT NULL, `isActive` INTEGER NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_area_assignments_employeeId ON employee_area_assignments(employeeId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_area_assignments_isActive ON employee_area_assignments(isActive)")
            }
        }

        // Phase 4 — Performance Appraisal, new table.
        private val MIGRATION_52_53 = object : Migration(52, 53) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `employee_appraisals` (
                        `id` TEXT NOT NULL, `employeeId` TEXT NOT NULL, `companyId` TEXT NOT NULL,
                        `periodStartEpochDay` INTEGER NOT NULL, `periodEndEpochDay` INTEGER NOT NULL,
                        `salesTarget` REAL NOT NULL, `salesAchievement` REAL NOT NULL,
                        `collectionTarget` REAL NOT NULL, `collectionAchievement` REAL NOT NULL,
                        `attendancePresentDays` INTEGER NOT NULL, `attendanceTotalDays` INTEGER NOT NULL, `punctualityLateDays` INTEGER NOT NULL,
                        `dealerVisits` INTEGER NOT NULL, `retailerVisits` INTEGER NOT NULL,
                        `newDealerAcquisition` INTEGER NOT NULL, `newRetailerAcquisition` INTEGER NOT NULL,
                        `returnRatePct` REAL NOT NULL, `complaintCount` INTEGER NOT NULL,
                        `supervisorScore` REAL, `hrScore` REAL, `managerComment` TEXT,
                        `employeeAcknowledged` INTEGER NOT NULL, `employeeAcknowledgedAtEpochMillis` INTEGER,
                        `finalScore` REAL, `rating` TEXT, `recognitionsRaw` TEXT NOT NULL,
                        `generatedBy` TEXT NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_appraisals_employeeId ON employee_appraisals(employeeId)")
            }
        }

        // Phase 6 — Manufacturing HR, new table.
        private val MIGRATION_53_54 = object : Migration(53, 54) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `manufacturing_worker_assignments` (
                        `id` TEXT NOT NULL, `employeeId` TEXT NOT NULL, `companyId` TEXT NOT NULL,
                        `manufacturingUnitId` TEXT NOT NULL, `productionLine` TEXT, `machine` TEXT, `section` TEXT,
                        `shiftType` TEXT NOT NULL, `supervisorEmployeeId` TEXT, `skillsRaw` TEXT NOT NULL,
                        `startDateEpochDay` INTEGER NOT NULL, `endDateEpochDay` INTEGER, `isActive` INTEGER NOT NULL,
                        `assignedBy` TEXT NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_manufacturing_worker_assignments_employeeId ON manufacturing_worker_assignments(employeeId)")
            }
        }

        // Phase 7 — Production-to-Warehouse workflow, new tables.
        private val MIGRATION_54_55 = object : Migration(54, 55) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `production_plans` (
                        `id` TEXT NOT NULL, `planNumber` TEXT NOT NULL, `companyId` TEXT NOT NULL,
                        `productId` TEXT NOT NULL, `variant` TEXT, `plannedQuantity` REAL NOT NULL, `unit` TEXT NOT NULL,
                        `batchNumber` TEXT NOT NULL, `productionDateEpochDay` INTEGER NOT NULL, `manufacturingUnitId` TEXT NOT NULL,
                        `productionLine` TEXT, `shiftType` TEXT NOT NULL, `supervisorEmployeeId` TEXT, `status` TEXT NOT NULL,
                        `createdBy` TEXT NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `raw_material_issues` (
                        `id` TEXT NOT NULL, `productionPlanId` TEXT NOT NULL, `companyId` TEXT NOT NULL,
                        `materialProductId` TEXT NOT NULL, `warehouseId` TEXT, `binLocation` TEXT, `batchCode` TEXT,
                        `issuedQuantity` REAL NOT NULL, `consumedQuantity` REAL NOT NULL, `returnedQuantity` REAL NOT NULL,
                        `wastedQuantity` REAL NOT NULL, `issuedBy` TEXT NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `quality_inspections` (
                        `id` TEXT NOT NULL, `productionPlanId` TEXT, `batchId` TEXT, `transferId` TEXT, `companyId` TEXT NOT NULL,
                        `inspector` TEXT NOT NULL, `testParameters` TEXT, `result` TEXT NOT NULL, `sampleQuantity` REAL NOT NULL,
                        `rejectedQuantity` REAL NOT NULL, `comment` TEXT, `attachmentUri` TEXT, `createdAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `packing_records` (
                        `id` TEXT NOT NULL, `productionPlanId` TEXT NOT NULL, `companyId` TEXT NOT NULL,
                        `bulkQuantityReceived` REAL NOT NULL, `packingSize` REAL NOT NULL, `numberOfPacks` INTEGER NOT NULL,
                        `numberOfCartons` INTEGER NOT NULL, `looseQuantity` REAL NOT NULL, `damagedPacks` INTEGER NOT NULL,
                        `wastageQuantity` REAL NOT NULL, `finalAcceptedQuantity` REAL NOT NULL, `createdBy` TEXT NOT NULL,
                        `createdAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `finished_goods_receipts` (
                        `id` TEXT NOT NULL, `productionPlanId` TEXT NOT NULL, `companyId` TEXT NOT NULL, `productId` TEXT NOT NULL,
                        `batchCode` TEXT NOT NULL, `manufacturingDateEpochDay` INTEGER NOT NULL, `expiryDateEpochDay` INTEGER,
                        `quantity` REAL NOT NULL, `unit` TEXT NOT NULL, `warehouseId` TEXT NOT NULL, `unitCost` REAL NOT NULL,
                        `qcStatus` TEXT NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `warehouse_transfers` (
                        `id` TEXT NOT NULL, `transferNumber` TEXT NOT NULL, `companyId` TEXT NOT NULL,
                        `sourceWarehouseId` TEXT NOT NULL, `destinationWarehouseId` TEXT NOT NULL, `linesRaw` TEXT NOT NULL,
                        `requestedBy` TEXT NOT NULL, `approvedBy` TEXT, `vehicle` TEXT, `driver` TEXT,
                        `dispatchDateEpochMillis` INTEGER, `expectedDeliveryDateEpochDay` INTEGER, `notes` TEXT,
                        `status` TEXT NOT NULL, `dispatchChallanNumber` TEXT, `dispatchedBy` TEXT, `dispatchedAtEpochMillis` INTEGER,
                        `attachmentUri` TEXT, `createdAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `warehouse_receipts` (
                        `id` TEXT NOT NULL, `transferId` TEXT NOT NULL, `companyId` TEXT NOT NULL, `receivingWarehouseId` TEXT NOT NULL,
                        `binLocation` TEXT, `receiver` TEXT NOT NULL, `comment` TEXT, `proofUri` TEXT, `createdAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_production_plans_status ON production_plans(status)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_raw_material_issues_productionPlanId ON raw_material_issues(productionPlanId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_warehouse_transfers_status ON warehouse_transfers(status)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_warehouse_receipts_transferId ON warehouse_receipts(transferId)")
            }
        }

        // Permission Control Center — Template assignment field on Employee, and per-employee overrides table.
        private val MIGRATION_55_56 = object : Migration(55, 56) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE employee_profiles ADD COLUMN assignedTemplateKey TEXT")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `employee_permission_overrides` (
                        `id` TEXT NOT NULL, `employeeId` TEXT NOT NULL, `companyId` TEXT NOT NULL,
                        `moduleKey` TEXT NOT NULL, `accessLevel` TEXT NOT NULL, `setBy` TEXT NOT NULL,
                        `setByName` TEXT NOT NULL, `setAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_permission_overrides_employeeId ON employee_permission_overrides(employeeId)")
            }
        }

        // Chairman-Controlled Vacancy & Target Management, new tables.
        private val MIGRATION_56_57 = object : Migration(56, 57) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `vacancies` (
                        `id` TEXT NOT NULL, `companyId` TEXT NOT NULL, `designation` TEXT NOT NULL, `department` TEXT NOT NULL,
                        `territoryId` TEXT, `requestedBy` TEXT NOT NULL, `requestedByName` TEXT NOT NULL, `reason` TEXT,
                        `status` TEXT NOT NULL, `approvedBy` TEXT, `filledByEmployeeId` TEXT, `createdAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `targets` (
                        `id` TEXT NOT NULL, `companyId` TEXT NOT NULL, `scopeType` TEXT NOT NULL, `scopeId` TEXT NOT NULL,
                        `parentTargetId` TEXT, `periodType` TEXT NOT NULL, `periodStartEpochDay` INTEGER NOT NULL,
                        `periodEndEpochDay` INTEGER NOT NULL, `targetType` TEXT NOT NULL, `targetValue` REAL NOT NULL,
                        `achievedValue` REAL NOT NULL, `isOverride` INTEGER NOT NULL, `overrideReason` TEXT, `status` TEXT NOT NULL,
                        `createdBy` TEXT NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `target_change_logs` (
                        `id` TEXT NOT NULL, `targetId` TEXT NOT NULL, `oldValue` REAL, `newValue` REAL, `reason` TEXT NOT NULL,
                        `changedBy` TEXT NOT NULL, `changedByName` TEXT NOT NULL, `changedAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_vacancies_status ON vacancies(status)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_targets_scopeId ON targets(scopeId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_target_change_logs_targetId ON target_change_logs(targetId)")
            }
        }

        // Extended Business Features batch 1 — Correction/Reversal, Period Lock, Number Series, Ownership Transfer.
        private val MIGRATION_57_58 = object : Migration(57, 58) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `correction_requests` (
                        `id` TEXT NOT NULL, `companyId` TEXT NOT NULL, `module` TEXT NOT NULL, `recordId` TEXT NOT NULL,
                        `correctionType` TEXT NOT NULL, `reason` TEXT NOT NULL, `proposedChangeJson` TEXT NOT NULL, `originalValueJson` TEXT NOT NULL,
                        `requestedBy` TEXT NOT NULL, `requestedByName` TEXT NOT NULL, `managerReviewedBy` TEXT, `managerComment` TEXT,
                        `chairmanApprovedBy` TEXT, `chairmanComment` TEXT, `status` TEXT NOT NULL, `reversalEntryId` TEXT,
                        `correctedEntryId` TEXT, `createdAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `accounting_period_locks` (
                        `id` TEXT NOT NULL, `companyId` TEXT NOT NULL, `scope` TEXT NOT NULL, `periodStartEpochDay` INTEGER NOT NULL,
                        `periodEndEpochDay` INTEGER NOT NULL, `lockedBy` TEXT NOT NULL, `lockedByName` TEXT NOT NULL,
                        `isLocked` INTEGER NOT NULL, `lockedAtEpochMillis` INTEGER NOT NULL, `unlockedBy` TEXT,
                        `unlockedAtEpochMillis` INTEGER, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `number_series_configs` (
                        `id` TEXT NOT NULL, `companyId` TEXT NOT NULL, `companyPrefix` TEXT NOT NULL, `branchPrefix` TEXT,
                        `useFinancialYear` INTEGER NOT NULL, `currentRunningNumber` INTEGER NOT NULL, `padWidth` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `ownership_transfer_records` (
                        `id` TEXT NOT NULL, `companyId` TEXT NOT NULL, `scope` TEXT NOT NULL, `entityId` TEXT NOT NULL,
                        `fromEmployeeId` TEXT, `toEmployeeId` TEXT NOT NULL, `reason` TEXT NOT NULL, `transferredBy` TEXT NOT NULL,
                        `transferredAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_correction_requests_status ON correction_requests(status)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ownership_transfer_records_entityId ON ownership_transfer_records(entityId)")
            }
        }

        // Section 3 — Number Series Engine: real collectionNo column added.
        private val MIGRATION_58_59 = object : Migration(58, 59) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE party_collections ADD COLUMN collectionNo TEXT NOT NULL DEFAULT ''")
            }
        }

        // Section 3 — real fiscal-year-start-month column (was implicitly calendar-year only).
        private val MIGRATION_59_60 = object : Migration(59, 60) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE number_series_configs ADD COLUMN fiscalYearStartMonth INTEGER NOT NULL DEFAULT 7")
            }
        }

        // Section 9 — Business Rule Engine.
        private val MIGRATION_60_61 = object : Migration(60, 61) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `business_rules` (
                        `key` TEXT NOT NULL, `label` TEXT NOT NULL, `type` TEXT NOT NULL, `value` REAL NOT NULL,
                        `companyId` TEXT NOT NULL, `updatedBy` TEXT NOT NULL, `updatedByName` TEXT NOT NULL,
                        `updatedAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`key`)
                    )
                    """.trimIndent(),
                )
            }
        }

        // Section 10 — Company Settings Center.
        private val MIGRATION_61_62 = object : Migration(61, 62) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `company_settings` (
                        `id` TEXT NOT NULL, `companyName` TEXT NOT NULL, `companyAddress` TEXT NOT NULL,
                        `companyPhone` TEXT NOT NULL, `companyEmail` TEXT NOT NULL, `taxVatNumber` TEXT NOT NULL,
                        `vatPct` REAL NOT NULL, `currencyCode` TEXT NOT NULL, `currencySymbol` TEXT NOT NULL,
                        `numberFormatPattern` TEXT NOT NULL, `workingDaysRaw` TEXT NOT NULL, `holidaysRaw` TEXT NOT NULL,
                        `attendancePolicyNote` TEXT NOT NULL, `payrollPolicyNote` TEXT NOT NULL, `invoicePolicyNote` TEXT NOT NULL,
                        `dealerPolicyNote` TEXT NOT NULL, `targetPolicyNote` TEXT NOT NULL, `updatedBy` TEXT NOT NULL,
                        `updatedAtEpochMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
            }
        }

        // Section 11 — Enterprise Audit Center: Device, GPS, Sync Status columns (real ALTER TABLE — audit_log has existed since a much earlier migration).
        private val MIGRATION_62_63 = object : Migration(62, 63) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE audit_log ADD COLUMN deviceId TEXT")
                db.execSQL("ALTER TABLE audit_log ADD COLUMN gpsLat REAL")
                db.execSQL("ALTER TABLE audit_log ADD COLUMN gpsLng REAL")
                db.execSQL("ALTER TABLE audit_log ADD COLUMN syncStatus TEXT NOT NULL DEFAULT 'PENDING'")
            }
        }

        // Section 10 — Financial Year single-source-of-truth on CompanySettings.
        private val MIGRATION_63_64 = object : Migration(63, 64) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE company_settings ADD COLUMN fiscalYearStartMonth INTEGER NOT NULL DEFAULT 7")
            }
        }

        // Section: Factory HR and Attendance — real check-out time, overtime, and leave-linkage.
        private val MIGRATION_64_65 = object : Migration(64, 65) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE attendance_records ADD COLUMN checkInEpochMillis INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE attendance_records ADD COLUMN checkOutEpochMillis INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE attendance_records ADD COLUMN checkOutGpsValid INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE attendance_records ADD COLUMN isLate INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE attendance_records ADD COLUMN isOnLeave INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE attendance_records ADD COLUMN leaveApprovalRequestId TEXT")
                db.execSQL("ALTER TABLE attendance_records ADD COLUMN overtimeMinutes INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE payroll_lines ADD COLUMN overtimeMinutes INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE payroll_lines ADD COLUMN overtimePay REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE payroll_lines ADD COLUMN attendanceDaysPresent INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE payroll_lines ADD COLUMN attendanceDaysAbsent INTEGER NOT NULL DEFAULT 0")
            }
        }
        // Section 6 — Production and Warehouse Stock: real batch/cost tracking on movement history.
        private val MIGRATION_65_66 = object : Migration(65, 66) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE stock_movements ADD COLUMN batchCode TEXT")
                db.execSQL("ALTER TABLE stock_movements ADD COLUMN unitCost REAL NOT NULL DEFAULT 0.0")
            }
        }

        // Section 7 — Invoice and Stock Approval: real stock linkage columns.
        private val MIGRATION_66_67 = object : Migration(66, 67) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE invoices ADD COLUMN warehouseId TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE invoices ADD COLUMN stockReserved INTEGER NOT NULL DEFAULT 0")
            }
        }
        // Section 8 — Expense workflow: new table (was completely missing).
        /**
         * v69 — Secure QR Registry. Purely additive: two new tables, no existing table
         * altered and no row rewritten, so an upgrade cannot lose data. Indices are on
         * the columns resolution actually queries (company-scoped lookup, and the
         * entityType+entityId pair used to find a record's current active QR).
         */
        /**
         * v70 — invoice balance snapshot. Two nullable-free columns with a 0.0 default, so
         * every existing invoice row keeps its data and simply reports 0 for a snapshot that
         * was never taken. Purely additive: no table rebuilt, no row rewritten.
         */
        /** v71 — structured line items on retail orders. One additive column; the existing
         *  free-text `items` column is untouched and still written, so nothing that reads it breaks. */
        /** v72 — explicit office/factory split on employees. One additive column defaulting to
         *  OFFICE, so every existing employee keeps its current behaviour until someone
         *  deliberately marks them as factory staff. */
        /** v73 — product-wise dealer stock. One new, empty-at-first table; nothing existing
         *  is touched, and `Dealer.stockUnits` (the trusted aggregate) is completely unaffected. */
        /** v113-75 — product-wise retailer stock. Same shape as MIGRATION_72_73's dealer
         *  version: one new, empty-at-first table, nothing existing touched. */
        private val MIGRATION_73_74 = object : Migration(73, 74) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `retailer_stock_lines` (
                        `retailerId` TEXT NOT NULL, `productId` TEXT NOT NULL, `productName` TEXT NOT NULL,
                        `qty` INTEGER NOT NULL, `updatedAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`retailerId`, `productId`)
                    )
                    """.trimIndent(),
                )
            }
        }

        /** v113-75 — retailer complaints. Three additive columns on the existing table;
         *  every pre-existing row gets partyType='DEALER' and a null retailerId/Name,
         *  which is exactly what it already was, so no existing complaint changes shape. */
        /**
         * v113-144 — courier API configuration slot. Additive only: two nullable
         * TEXT columns, no existing column touched, no data rewritten, so every
         * existing courier row survives untouched. Column names/types match
         * CourierPartnerEntity's new fields exactly (apiBaseUrl, apiKey) — Room
         * validates this at open time and would crash on any mismatch.
         */
        /**
         * v113-147 — dealer photo slot. Additive only: one nullable TEXT column,
         * nothing existing touched. Column name/type matches DealerEntity.photoUri
         * exactly — Room validates this at open time and crashes on any mismatch.
         */
        private val MIGRATION_92_93 = object : Migration(92, 93) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v113-326 — the QR payload, so an issued code can actually
                // be drawn and printed instead of only reported as
                // existing. Purely additive; rows issued before this stay
                // null and are shown honestly as "code not stored".
                db.execSQL("ALTER TABLE qr_registry ADD COLUMN payload TEXT")
            }
        }

        private val MIGRATION_91_92 = object : Migration(91, 92) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v113-309 — the person's own settled decision: a dealer
                // logs in with a separate Chairman-assigned login ID, not
                // their phone number. Purely additive; existing dealers
                // stay null (no login yet) rather than being given a
                // fabricated one.
                db.execSQL("ALTER TABLE dealers ADD COLUMN loginId TEXT")
            }
        }

        private val MIGRATION_90_91 = object : Migration(90, 91) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v113-290 — the person's own direct request: 2 real
                // notice-image slots on DMS's own Dashboard, settable
                // from DMS's Chairman panel. Purely additive.
                db.execSQL("ALTER TABLE company_settings ADD COLUMN dmsNoticeSlot1Uri TEXT")
                db.execSQL("ALTER TABLE company_settings ADD COLUMN dmsNoticeSlot2Uri TEXT")
            }
        }

        private val MIGRATION_89_90 = object : Migration(89, 90) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v113-284 — the person's own direct instruction: Sales
                // Rules should be Dealer-wise specific. Purely additive —
                // null means "use the company-wide default" everywhere
                // these are read.
                db.execSQL("ALTER TABLE dealers ADD COLUMN customMaxDiscountPct REAL")
                db.execSQL("ALTER TABLE dealers ADD COLUMN customInvoiceLimit REAL")
                db.execSQL("ALTER TABLE dealers ADD COLUMN customWeeklyDuePct REAL")
            }
        }

        private val MIGRATION_88_89 = object : Migration(88, 89) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v113-269 — the person's own direct request: live employee
                // attendance needs real, precise location too — matching
                // Dealer/Retailer's own GPS capture, purely additive.
                db.execSQL("ALTER TABLE attendance_records ADD COLUMN checkInLat REAL")
                db.execSQL("ALTER TABLE attendance_records ADD COLUMN checkInLng REAL")
                db.execSQL("ALTER TABLE attendance_records ADD COLUMN checkInAccuracyMeters REAL")
            }
        }

        private val MIGRATION_87_88 = object : Migration(87, 88) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v113-268 — the person's own direct request: Dealer needs
                // real GPS accuracy/capture-time, matching Retailer's own
                // existing columns exactly. lat/lng already existed on
                // dealers (confirmed directly before writing this) — only
                // these two are new, purely additive.
                db.execSQL("ALTER TABLE dealers ADD COLUMN gpsAccuracyMeters REAL")
                db.execSQL("ALTER TABLE dealers ADD COLUMN geoCapturedAtEpochMillis INTEGER")
            }
        }

        private val MIGRATION_86_87 = object : Migration(86, 87) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v113-264 — the person's own confirmed scope: Gift is a
                // plain text note on the invoice, nothing financial — a
                // single nullable column, purely additive, matching every
                // other migration here.
                db.execSQL("ALTER TABLE invoices ADD COLUMN giftNote TEXT")
            }
        }

        private val MIGRATION_85_86 = object : Migration(85, 86) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v113-255 — real Pathao/RedX area-code resolution
                // (city→zone→area, area), captured on the invoice
                // itself alongside the existing weight/condition,
                // purely additive matching every other migration here.
                db.execSQL("ALTER TABLE invoices ADD COLUMN pathaoCityId TEXT")
                db.execSQL("ALTER TABLE invoices ADD COLUMN pathaoZoneId TEXT")
                db.execSQL("ALTER TABLE invoices ADD COLUMN pathaoAreaId TEXT")
                db.execSQL("ALTER TABLE invoices ADD COLUMN redxAreaId TEXT")
            }
        }

        private val MIGRATION_84_85 = object : Migration(84, 85) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v113-249 — the person's own direct confirmation they're
                // a real merchant at Pathao/RedX/Steadfast, wanting the
                // stored key to actually call the real API. courierType
                // plus the union of auth fields each of the three real
                // integrations needs.
                db.execSQL("ALTER TABLE courier_partners ADD COLUMN courierType TEXT NOT NULL DEFAULT 'OTHER'")
                db.execSQL("ALTER TABLE courier_partners ADD COLUMN apiSecretKey TEXT")
                db.execSQL("ALTER TABLE courier_partners ADD COLUMN apiUsername TEXT")
                db.execSQL("ALTER TABLE courier_partners ADD COLUMN apiPassword TEXT")
                db.execSQL("ALTER TABLE courier_partners ADD COLUMN apiStoreId TEXT")
            }
        }

        private val MIGRATION_83_84 = object : Migration(83, 84) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v113-249 — parcel weight/condition captured at invoice
                // creation time, alongside courier/vehicle selection, so
                // the real auto-booking at approval has real values to
                // pass through rather than inventing them later.
                db.execSQL("ALTER TABLE invoices ADD COLUMN courierWeightKg REAL")
                db.execSQL("ALTER TABLE invoices ADD COLUMN courierCondition TEXT")
            }
        }

        private val MIGRATION_82_83 = object : Migration(82, 83) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v113-249 — the person's own direct follow-up: real
                // delivery address (not just a dealer name) plus weight/
                // condition, both needed for real courier API request
                // bodies and useful for manual couriers too. Purely
                // additive, matching every other migration here.
                db.execSQL("ALTER TABLE shipments ADD COLUMN deliveryAddress TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE shipments ADD COLUMN weightKg REAL")
                db.execSQL("ALTER TABLE shipments ADD COLUMN condition TEXT")
            }
        }

        private val MIGRATION_81_82 = object : Migration(81, 82) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v113-249 — the person's own direct, confirmed complaint:
                // a lot of delivery happens via the company's own vehicle,
                // not a third-party courier — Shipment had no way to
                // reference one. Purely additive, matching every other
                // migration here — courierId itself stays as-is (see the
                // model's own comment on why it isn't being made
                // nullable).
                db.execSQL("ALTER TABLE shipments ADD COLUMN vehicleId TEXT")
            }
        }

        private val MIGRATION_80_81 = object : Migration(80, 81) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v113-249 — the person's own direct, confirmed complaint:
                // a courier booking had no way to connect to the invoice
                // it's actually delivering — Shipment only ever had a
                // free-text dealerOrRetailer name.
                db.execSQL("ALTER TABLE shipments ADD COLUMN invoiceId TEXT")
                db.execSQL("ALTER TABLE shipments ADD COLUMN invoiceNo TEXT")
            }
        }

        private val MIGRATION_79_80 = object : Migration(79, 80) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v113-224 — the Notice board's own real gap: text-only, no
                // photo, though the person specifically asked for both.
                db.execSQL("ALTER TABLE notification_entries ADD COLUMN imageUri TEXT")
            }
        }

        private val MIGRATION_78_79 = object : Migration(78, 79) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v113-221 — real company logo, the person's own explicit
                // request: simplifying Company Info down to Name/Address/
                // Photo, and having that photo actually reflect app-wide.
                db.execSQL("ALTER TABLE company_settings ADD COLUMN companyLogoUri TEXT")
            }
        }

        private val MIGRATION_77_78 = object : Migration(77, 78) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `cartons` (
                        `id` TEXT NOT NULL, `cartonCode` TEXT NOT NULL, `companyId` TEXT NOT NULL,
                        `productionPlanId` TEXT NOT NULL, `productId` TEXT NOT NULL, `productName` TEXT NOT NULL,
                        `batchCode` TEXT, `quantityInside` REAL NOT NULL, `unit` TEXT NOT NULL,
                        `status` TEXT NOT NULL, `packedBy` TEXT NOT NULL, `packedAtEpochMillis` INTEGER NOT NULL,
                        `warehouseId` TEXT, `warehouseReceivedBy` TEXT, `warehouseReceivedAtEpochMillis` INTEGER,
                        `dispatchedTo` TEXT, `dispatchedBy` TEXT, `dispatchedAtEpochMillis` INTEGER,
                        `deliveredBy` TEXT, `deliveredAtEpochMillis` INTEGER,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
            }
        }

        private val MIGRATION_76_77 = object : Migration(76, 77) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE dealers ADD COLUMN photoUri TEXT")
            }
        }

        private val MIGRATION_75_76 = object : Migration(75, 76) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE courier_partners ADD COLUMN apiBaseUrl TEXT")
                db.execSQL("ALTER TABLE courier_partners ADD COLUMN apiKey TEXT")
            }
        }

        private val MIGRATION_74_75 = object : Migration(74, 75) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE customer_complaints ADD COLUMN partyType TEXT NOT NULL DEFAULT 'DEALER'")
                db.execSQL("ALTER TABLE customer_complaints ADD COLUMN retailerId TEXT")
                db.execSQL("ALTER TABLE customer_complaints ADD COLUMN retailerName TEXT")
            }
        }

        private val MIGRATION_72_73 = object : Migration(72, 73) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `dealer_stock_lines` (
                        `dealerId` TEXT NOT NULL, `productId` TEXT NOT NULL, `productName` TEXT NOT NULL,
                        `qty` INTEGER NOT NULL, `updatedAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`dealerId`, `productId`)
                    )
                    """.trimIndent(),
                )
            }
        }

        private val MIGRATION_71_72 = object : Migration(71, 72) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE employee_profiles ADD COLUMN employeeType TEXT NOT NULL DEFAULT 'OFFICE'")
            }
        }

        private val MIGRATION_70_71 = object : Migration(70, 71) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE retail_orders ADD COLUMN lineItemsRaw TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_69_70 = object : Migration(69, 70) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE invoices ADD COLUMN previousDueSnapshot REAL NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE invoices ADD COLUMN closingDueSnapshot REAL NOT NULL DEFAULT 0")
            }
        }

        private val MIGRATION_68_69 = object : Migration(68, 69) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `qr_registry` (
                        `qrId` TEXT NOT NULL, `tokenHash` TEXT NOT NULL, `companyId` TEXT NOT NULL,
                        `entityType` TEXT NOT NULL, `entityId` TEXT NOT NULL, `status` TEXT NOT NULL,
                        `version` INTEGER NOT NULL, `issuedAtEpochMillis` INTEGER NOT NULL,
                        `issuedBy` TEXT NOT NULL, `revokedAtEpochMillis` INTEGER,
                        `revokedBy` TEXT, `revokeReason` TEXT, `expiresAtEpochMillis` INTEGER,
                        `previousQrId` TEXT, `metadataVersion` INTEGER NOT NULL,
                        `lastScannedAtEpochMillis` INTEGER, `scanCount` INTEGER NOT NULL,
                        `syncStatus` TEXT NOT NULL,
                        PRIMARY KEY(`qrId`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_qr_registry_companyId` ON `qr_registry` (`companyId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_qr_registry_entityType_entityId` ON `qr_registry` (`entityType`, `entityId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_qr_registry_status` ON `qr_registry` (`status`)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `qr_scan_logs` (
                        `id` TEXT NOT NULL, `qrId` TEXT NOT NULL, `companyId` TEXT NOT NULL,
                        `userId` TEXT NOT NULL, `employeeId` TEXT NOT NULL, `deviceId` TEXT NOT NULL,
                        `entityType` TEXT NOT NULL, `entityId` TEXT, `action` TEXT NOT NULL,
                        `result` TEXT NOT NULL, `reason` TEXT, `gpsLat` REAL, `gpsLng` REAL,
                        `wasOffline` INTEGER NOT NULL, `timestampEpochMillis` INTEGER NOT NULL,
                        `syncStatus` TEXT NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_qr_scan_logs_qrId` ON `qr_scan_logs` (`qrId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_qr_scan_logs_companyId` ON `qr_scan_logs` (`companyId`)")
            }
        }

        private val MIGRATION_67_68 = object : Migration(67, 68) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `expenses` (
                        `id` TEXT NOT NULL, `expenseNo` TEXT NOT NULL, `companyId` TEXT NOT NULL,
                        `category` TEXT NOT NULL, `amount` REAL NOT NULL, `description` TEXT NOT NULL,
                        `paymentMethod` TEXT NOT NULL, `submittedBy` TEXT NOT NULL, `submittedByEmployeeId` TEXT NOT NULL,
                        `status` TEXT NOT NULL, `approvedBy` TEXT, `rejectReason` TEXT, `attachmentUri` TEXT,
                        `createdAtEpochMillis` INTEGER NOT NULL, `approvedAtEpochMillis` INTEGER, PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
            }
        }



        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "abm_erp.db",
                )
                    .addMigrations(MIGRATION_92_93, MIGRATION_91_92, MIGRATION_90_91, MIGRATION_89_90, MIGRATION_88_89, MIGRATION_87_88, MIGRATION_86_87, MIGRATION_85_86, MIGRATION_84_85, MIGRATION_83_84, MIGRATION_82_83, MIGRATION_81_82, MIGRATION_80_81, MIGRATION_79_80, MIGRATION_78_79, MIGRATION_77_78, MIGRATION_76_77, MIGRATION_75_76, MIGRATION_74_75, MIGRATION_73_74, MIGRATION_72_73, MIGRATION_71_72, MIGRATION_70_71, MIGRATION_69_70, MIGRATION_68_69, MIGRATION_23_24, MIGRATION_24_25, MIGRATION_25_26, MIGRATION_26_27, MIGRATION_27_28, MIGRATION_28_29, MIGRATION_29_30, MIGRATION_30_31, MIGRATION_31_32, MIGRATION_32_33, MIGRATION_33_34, MIGRATION_34_35, MIGRATION_35_36, MIGRATION_36_37, MIGRATION_37_38, MIGRATION_38_39, MIGRATION_39_40, MIGRATION_40_41, MIGRATION_41_42, MIGRATION_42_43, MIGRATION_43_44, MIGRATION_44_45, MIGRATION_45_46, MIGRATION_46_47, MIGRATION_47_48, MIGRATION_48_49, MIGRATION_49_50, MIGRATION_50_51, MIGRATION_51_52, MIGRATION_52_53, MIGRATION_53_54, MIGRATION_54_55, MIGRATION_55_56, MIGRATION_56_57, MIGRATION_57_58, MIGRATION_58_59, MIGRATION_59_60, MIGRATION_60_61, MIGRATION_61_62, MIGRATION_62_63, MIGRATION_63_64, MIGRATION_64_65, MIGRATION_65_66, MIGRATION_66_67, MIGRATION_67_68)
                    // No destructive-migration fallback of any kind (not
                    // fallbackToDestructiveMigration/-From/-OnDowngrade) —
                    // all can delete on-device data, so none are used.
                    // MIGRATION_23_24 above IS real and accurate (written
                    // directly from this same change's field additions).
                    // What is STILL unresolved: versions 1-22 have no real
                    // Migration objects, because exportSchema was false for
                    // all of them — there's no historical schema to verify
                    // against, and inventing one would be fabricating it.
                    // Practical effect: a device with a local DB below
                    // version 23 will hit a Room IllegalStateException on
                    // open, not silent data loss. No production installs are
                    // known to exist at this time, but that isn't verified.
                    // exportSchema=true is kept so every future bump beyond
                    // 24 can also have a real, schema-verified migration.
                    .build().also { instance = it }
            }
    }
}
