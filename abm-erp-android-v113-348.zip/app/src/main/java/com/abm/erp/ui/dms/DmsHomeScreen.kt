package com.abm.erp.ui.dms

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.core.ModuleDrawerItem
import com.abm.erp.core.ModuleDrawerScaffold
import com.abm.erp.core.ModuleDrillRow
import com.abm.erp.core.Space
import com.abm.erp.core.rememberVisibleDealers
import com.abm.erp.data.MockRepository
import com.abm.erp.data.rejectCollection // v113-190: missing import — real CI compile error
import com.abm.erp.data.verifyCollection // v113-190: missing import — real CI compile error
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import kotlinx.coroutines.launch

/**
 * DMS — Dealer Management System. One of the six mother modules.
 *
 * Built to the person's hand-drawn DMS draft: a left drawer with the module's own
 * options, and everything about a dealer living *inside* here — nothing pulled out
 * into a cross-cutting screen, and no other mother module visible from in here.
 *
 * Where an option already exists as working code elsewhere, this hosts that exact
 * composable rather than writing a second copy. That is deliberate: duplicating the
 * dealer invoice UI would mean two places to fix every future bug, and the person's
 * standing rule is one home per feature.
 */
private val DMS_COLOR_START = 0xFF2563EB
private val DMS_COLOR_END = 0xFF1E3A8A

private val DMS_ITEMS_BASE = listOf(
    ModuleDrawerItem("dashboard", "DMS Dashboard", Icons.Filled.Home, "সারসংক্ষেপ"),
    ModuleDrawerItem("invoice", "Invoice", Icons.Filled.Description, "Direct Invoice + Auto Data"),
    ModuleDrawerItem("message", "Message / CRM", Icons.Filled.Forum, "Offer / Due / Custom SMS"),
    ModuleDrawerItem("list", "List", Icons.Filled.ListAlt, "Dealer Info & Full History"),
    // v113-265 — the person's own direct instruction: RMS as a separate
    // mother module removed entirely — genuinely duplicate weight (its
    // own Dashboard/Report/Chairman tab, mostly repeating DMS's own
    // shape) folded away, and Retailer Stock dropped outright (never
    // asked for again once named). What's kept — Memo/List/Finance, the
    // 3 things actually used day to day — lives here as one drawer item
    // with its own internal tabs, the same "one drawer key, its own
    // ScrollableTabRow" shape "chairman" below already uses, not a
    // second full module shell for 3 screens.
    ModuleDrawerItem("rms", "RMS", Icons.Filled.Store, "Retailer Memo · List · Finance"),
    ModuleDrawerItem("approve", "Approve", Icons.Filled.FactCheck, "Approvals & Permissions"),
    ModuleDrawerItem("alerts", "Alerts", Icons.Filled.Warning, "Stock Shortage · Due Over Limit"),
    // v113-338 — the person's own decision, after I clarified that adding a
    // courier API does NOT give live server data (no webhook endpoint is
    // possible without a backend, so status only ever updated when someone
    // pressed refresh): remove the Logistic drawer item and the Courier API
    // config entirely. Courier now survives only as a NAME recorded on the
    // invoice — "sudu invoice e mention thakbe" — with no integration
    // behind it, rather than a half-working feature implying more than it
    // delivered.
    ModuleDrawerItem("finance", "Finance", Icons.Filled.Payments, "Finance & Cash Management"),
    ModuleDrawerItem("complain", "Complain", Icons.Filled.ReportProblem, "Dealer Complaints"),
)

// v113-167 — same pattern as HR: one drawer item, always last, Chairman-only,
// hosting every Chairman-only-gated action for this module. Dealer/Retailer
// approve uses the broader GM/MD/AGM/Chairman tier (same as Invoice) so it
// stays in "approve" as-is. (This comment used to cite setCourierApiConfig
// as the one genuinely Chairman-only-gated action here; that function was
// deleted in v113-338 — the Chairman-only actions now are Dealer/Retailer
// profile, PIN, transfer, closing, permanent delete and the notice slots.)
// v113-348 — subtitle corrected. It still advertised "Courier API", which
// v113-338 deleted outright, and it never named the Retailer Control and
// Notice tabs that are actually there. Now it lists the four real tabs.
private val DMS_CHAIRMAN_ITEM = ModuleDrawerItem("chairman", "Chairman", Icons.Filled.Star, "Dealer Control · Retailer Control · Recycle · Notice")

@Composable
fun DmsHomeScreen(
    startKey: String? = null,
    onBackToHome: () -> Unit = {},
    onNavigate: (String) -> Unit = {},
) {
    // v113-249 — the person's own direct instruction from the diagnostic-
    // center discussion: entering a module should land directly on the
    // real work (the dealer list), not require an extra tap through a
    // summary screen first. Dashboard stays reachable — just not default.
    var selected by remember { mutableStateOf(startKey ?: "list") }
    // v113-325 — the person's own report: "Deler list e Deler add button
    // kaj kortce na."
    //
    // Root cause: the Add FAB navigates to its config's own `addRoute` —
    // "dms?key=newdealer" — but that was handed to the app-level
    // navigator, asking the graph to open DMS while DMS was already open.
    // `selected` is initialised from `startKey` inside a `remember`, so it
    // only reads it on FIRST composition; re-entering the same destination
    // left the drawer sitting on "list" and nothing visibly happened.
    //
    // Defined once here and passed to every child instead of the raw
    // `onNavigate`, so a route pointing at THIS screen switches the drawer
    // item directly — which is what it always meant — while anything
    // genuinely external still goes out to the real navigator. Doing it at
    // this level rather than per-list means the Retailer Add FAB
    // ("dms?key=newretailer", identical bug, confirmed by checking) and any
    // future internal route are covered by the same fix.
    val navigateInternalAware: (String) -> Unit = { route ->
        if (route.startsWith("dms?key=")) selected = route.substringAfter("dms?key=")
        else onNavigate(route)
    }
    val salesVm: com.abm.erp.ui.sales.SalesChainViewModel = viewModel()
    val dealersVm: com.abm.erp.ui.dealer.DealersScreenViewModel = viewModel()
    val dealers = rememberVisibleDealers()
    // v113-265 — RMS's own retailers, now read here directly (same real
    // geo-scoped accessor RMS itself always used — confirmed Retailer
    // already follows the identical hierarchy-based territory rule as
    // Dealer, via visibleRetailerIds/visibleDealerIds, before relying on
    // this being "already correct" rather than assumed).
    val retailers = com.abm.erp.core.rememberVisibleRetailers()
    val isChairman = MockRepository.currentUser.role == com.abm.erp.data.UserRole.CHAIRMAN
    val items = if (isChairman) DMS_ITEMS_BASE + DMS_CHAIRMAN_ITEM else DMS_ITEMS_BASE
    // v113-211 — the person's own request: viewing a completed invoice
    // should fill the whole screen. DmsInvoiceWorkspace owns the actual
    // "am I viewing a finished document" state internally, so it reports
    // changes up through this callback rather than that state being
    // duplicated or lifted here.
    var fullScreenDocument by remember { mutableStateOf(false) }

    ModuleDrawerScaffold(
        moduleName = "DMS",
        moduleSubtitle = "Dealer Management System",
        colorStart = DMS_COLOR_START,
        colorEnd = DMS_COLOR_END,
        moduleIcon = Icons.Filled.Business,
        items = items,
        selectedKey = selected,
        onSelect = { selected = it },
        onBackToHome = onBackToHome,
        // v113-265 — the new "rms" section's own Memo tab (RmsMemoWorkspace)
        // has the identical "viewing a finished document" full-screen need
        // Invoice already had — same mechanism, same reasoning.
        hideTopBar = fullScreenDocument && (selected == "invoice" || selected == "rms"),
        // v113-260 — DMS's own real landing key is "list" (v113-249), not
        // "dashboard" — the module-level back-to-home mechanism needs to
        // know that to return to the right place.
        homeKey = "list",
    ) { key ->
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            when (key) {
                "dashboard" -> DmsDashboard(dealers)
                // v113-80 — the workspace contract's reference implementation: the whole
                // invoice operation in ONE screen (dealer QR/search/add + financial
                // context + product + offer/discount + return + summary + approve +
                // history). Old DealerInvoiceTab remains for legacy Sales suite until
                // the final strip-down.
                "invoice" -> DmsInvoiceWorkspace(onNavigate, onViewingDocumentChange = { fullScreenDocument = it })
                // v113-249 — ledger/stock/newdealer drawer items removed
                // (the person's own direct instruction, from the earlier
                // diagnostic-center discussion): each was just "pick a
                // dealer, then see ONE thing about them" — a real,
                // confirmed duplicate of what "list" → a dealer's own rich
                // detail already shows in full (Ledger + Graph + 90-Day
                // sub, the Stock extraTab, and the same detail's own
                // +Add-Dealer button). "list" is the single, complete home
                // for all three now; the underlying dealer_stock/{id} and
                // statement/DEALER/{id} routes are untouched for anything
                // else that might still reference them directly.
                "list" -> com.abm.erp.core.ModuleBrowseList(
                    config = com.abm.erp.core.rememberDealerBrowseConfig(
                        zones = remember(dealers) { dealers.map { it.zone }.filter { it.isNotBlank() }.distinct().sorted() },
                    ),
                    // v113-253 — audit catch, the most visible place this
                    // gap could show up: ModuleBrowseList itself doesn't
                    // filter isDeleted (confirmed directly against its
                    // own implementation — it only filters by search/
                    // facets, the caller owns what "records" it's given),
                    // and dealers here wasn't guaranteed clean on every
                    // visibleDealersFor role path. Without this, a soft-
                    // deleted dealer could appear in the primary Dealer
                    // List itself and be clicked into.
                    records = remember(dealers) { dealers.filter { !it.isDeleted } },
                    onBack = { selected = "dashboard" },
                    onNavigate = navigateInternalAware,
                )
                "approve" -> DmsApprove(dealers, salesVm, onNavigate)
                "alerts" -> DmsAlertsTab(dealers, onNavigate)
                "newdealer" -> com.abm.erp.ui.dealer.AddDealerForm(dealersVm) { selected = "list" }
                // v113-265 — the new home for what used to be the standalone
                // RMS mother module's Memo/List/Finance (the only 3 the
                // person confirmed were still genuinely needed day to day).
                "rms" -> DmsRmsSection(
                    // v113-325 — passes the internal-aware navigator so the
                    // Retailer Add FAB ("dms?key=newretailer") switches the
                    // drawer item instead of re-navigating to DMS from
                    // inside DMS — the same bug the Dealer Add FAB had.
                    retailers = retailers, onNavigate = navigateInternalAware,
                    onViewingDocumentChange = { fullScreenDocument = it },
                )
                "newretailer" -> com.abm.erp.ui.dealer.AddRetailerForm(dealersVm, dealers) { selected = "rms" }
                // v113-81 — workspace contract: whole collection operation in one screen
                // (party QR/search + due context + entry + dual-control verify history).
                "finance" -> com.abm.erp.core.CollectionWorkspace(
                    partyType = com.abm.erp.data.PartyType.DEALER, partyLabel = "Dealer",
                    // v113-253 — a real audit catch, checking every drawer
                    // item's own logic directly: visibleDealersFor doesn't
                    // filter isDeleted on every one of its own branches
                    // (confirmed directly — only the profile-linked path
                    // does), and "message" right below already added its
                    // own defensive !isDeleted filter for exactly that
                    // reason — this one hadn't, meaning a soft-deleted
                    // (cancelled) dealer could still appear as a valid
                    // target to record a brand new collection against.
                    parties = remember(dealers) { dealers.filter { !it.isDeleted }.map { com.abm.erp.core.CollectionParty(it.id, it.name, it.zone, it.dueBalance, it.lat, it.lng) } },
                    onNavigate = onNavigate,
                )
                "message" -> com.abm.erp.core.PartyCampaignSection(
                    audienceLabel = "Dealer/Retailer",
                    // v113-265 — the person's own confirmed decision: DMS's
                    // Message/CRM now reaches both Dealer and Retailer
                    // contacts (RMS's own separate "Relation" removed) —
                    // same real per-party phone/due data either way, just
                    // combined into one list.
                    parties = remember(dealers, retailers) {
                        dealers.filter { !it.isDeleted }.map { com.abm.erp.core.CampaignParty(it.id, it.name, it.phone, it.zone, it.dueBalance) } +
                            retailers.filter { !it.isDeleted }.map { com.abm.erp.core.CampaignParty(it.id, it.name, it.phone, it.market, it.dueBalance) }
                    },
                    // v113-266 — the person's own request: QR-scan next to
                    // the party picker in the new "বাকি তাগাদা" tab.
                    onNavigate = onNavigate,
                )
                // v113-77 — hosted from GeoCrmScreen (made internal); CRM's own tab now
                // points here. One implementation, one home.
                // v113-265 — now also carries retailers, RMS's own separate
                // "Complaint" drawer item removed (see CustomerComplaintsTab
                // itself for the Dealer/Retailer toggle).
                "complain" -> com.abm.erp.ui.crm.CustomerComplaintsTab(dealers, retailers)
                "chairman" -> if (isChairman) DmsChairmanPanel(onNavigate) else DmsDashboard(dealers)
                else -> DmsDashboard(dealers)
            }
        }
    }
}

/**
 * v113-265 — the person's own direct instruction: RMS's own real-world-used
 * features (Memo/List/Finance — everything else either duplicated DMS's own
 * shape or was Retailer Stock, which was cut outright) live here now, one
 * drawer key with its own internal tabs — the same "chairman"/DmsChairmanPanel
 * shape immediately below, not a second full module shell for 3 screens.
 * Every composable here is the exact same one RMS itself used
 * (RmsMemoWorkspace, ModuleBrowseList+rememberRetailerBrowseConfig,
 * CollectionWorkspace) — relocated, not reimplemented.
 */
@Composable
private fun DmsRmsSection(
    retailers: List<com.abm.erp.data.Retailer>,
    onNavigate: (String) -> Unit,
    onViewingDocumentChange: (Boolean) -> Unit,
) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        androidx.compose.material3.ScrollableTabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Memo") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("List") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Finance") })
        }
        when (tab) {
            0 -> com.abm.erp.ui.rms.RmsMemoWorkspace(onNavigate, onViewingDocumentChange = onViewingDocumentChange)
            1 -> com.abm.erp.core.ModuleBrowseList(
                config = com.abm.erp.core.rememberRetailerBrowseConfig(
                    markets = remember(retailers) { retailers.map { it.market }.filter { it.isNotBlank() }.distinct().sorted() },
                ),
                records = remember(retailers) { retailers.filter { !it.isDeleted } },
                onBack = {},
                onNavigate = onNavigate,
            )
            else -> com.abm.erp.core.CollectionWorkspace(
                partyType = com.abm.erp.data.PartyType.RETAILER, partyLabel = "Retailer",
                parties = remember(retailers) { retailers.filter { !it.isDeleted }.map { com.abm.erp.core.CollectionParty(it.id, it.name, it.market.orEmpty(), it.dueBalance, it.lat, it.lng) } },
                onNavigate = onNavigate,
            )
        }
    }
}

/**
 * v113-175 — person's specific request for DMS's Chairman panel: a clean
 * approval-only view, not a full browse. If someone wants to add a dealer,
 * that shows here for Chairman to approve — plus Dealer Cancellation and
 * Collection verification (anyone can log a collection; Chairman verifies
 * it). All three already exist as real repository functions
 * (approveDealer/rejectDealer, deleteDealer, verifyCollection/
 * rejectCollection) — this is their first home inside the new DMS module
 * (previously only reachable via the legacy DealersScreen).
 */
// v113-249 — the person's own direct, confirmed finding: DMS had two
// separate implementations of the same "approve pending things" idea —
// Chairman's own panel had a real, complete one (Dealer Add + Invoice +
// Collection, each with real action buttons), while the regular "Approve"
// drawer item (meant for any ASM+ role with real approve permission, per
// PermissionManager's own canApprove = role.ordinal >= ASM.ordinal) had
// only a passive count pointing elsewhere. Extracted the real, working
// content into one shared composable so both call sites show the exact
// same thing — not a second, parallel reimplementation. Dealer
// Cancellation (a more sensitive, destructive delete, not an approval)
// deliberately stays Chairman-panel-only, not pulled into this shared
// piece.
@Composable
private fun DealerApprovalsShared() {
    // v113-271 — the real, confirmed cascade gap: this used to read raw,
    // unscoped MockRepository.dealers/retailers directly — meaning any
    // user reaching either the regular "Approve" key or the Chairman
    // panel's own Approvals tab (this same shared component) could see,
    // and act on, a pending Dealer/Retailer/Invoice/Collection/Memo from
    // a completely different territory. Same real scoped accessor
    // "List" already uses (rememberVisibleDealers/rememberVisibleRetailers,
    // company-wide for Chairman/MD/GM/AGM built into that function
    // already), now the actual source for every pending-list filter
    // below — not a second, parallel scoping mechanism.
    val dealers = com.abm.erp.core.rememberVisibleDealers()
    val collections by MockRepository.partyCollections.collectAsState()
    val invoices by MockRepository.salesInvoices.collectAsState()
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    val visibleDealerIds = remember(dealers) { dealers.map { it.id }.toSet() }
    val pendingDealers = remember(dealers) { dealers.filter { !it.isDeleted && !it.isActive && it.status == "PENDING_APPROVAL" } }
    // v113-265 — a real catch made while folding Retailer Collections in as
    // its own section below: this filter never excluded partyType at all,
    // so once Retailer collections started sharing the same
    // partyCollections table (RMS's own CollectionWorkspace call), a
    // retailer's pending collection could already have been silently
    // showing up in a section labelled "Dealer Collections". Scoped
    // properly to DEALER now that Retailer gets its own real section
    // instead of leaking into this one.
    // v113-271 — also now scoped to visibleDealerIds, same real gap fix.
    val pendingCollections = remember(collections, visibleDealerIds) {
        collections.filter { it.status == "PENDING" && it.partyType == com.abm.erp.data.PartyType.DEALER && it.partyId in visibleDealerIds }
    }
    val pendingInvoices = remember(invoices, visibleDealerIds) {
        invoices.filter { !it.isDeleted && it.status == "PENDING" && it.dealerId in visibleDealerIds }
    }

    // v113-265 — the person's own confirmed decision: Retailer Add
    // approval, Retailer Collections, and Memo Verification (all formerly
    // RMS's own separate "Approvals" panel) now live here, right beside
    // Dealer's equivalents — one Approve panel for both party types,
    // reusing the exact same approveRetailer/rejectRetailer/
    // verifyCollection/rejectCollection/advanceOrder engines RMS itself
    // called, not a second implementation.
    val retailers = com.abm.erp.core.rememberVisibleRetailers()
    val orders by MockRepository.orders.collectAsState()
    val rmsDealers = dealers
    val visibleRetailerIds = remember(retailers) { retailers.map { it.id }.toSet() }
    val pendingRetailers = remember(retailers) { retailers.filter { !it.isDeleted && !it.isActive && it.onboardingStatus == "PENDING_APPROVAL" } }
    val pendingRetailerCollections = remember(collections, visibleRetailerIds) {
        collections.filter { it.status == "PENDING" && it.partyType == com.abm.erp.data.PartyType.RETAILER && it.partyId in visibleRetailerIds }
    }
    // v113-271 — Memo scoping is a little different: an anonymous memo
    // (no linked retailerId — confirmed a real, existing case directly in
    // logNewOrder's own signature) has no party to check territory
    // against, so it's shown to everyone with Approve access rather than
    // hidden from all of them, matching how advanceOrder's own new
    // territory gate treats the same null case.
    val pendingMemos = remember(orders, visibleRetailerIds) {
        orders.filter { it.stage == com.abm.erp.data.OrderStage.SO_LOGGED && (it.retailerId == null || it.retailerId in visibleRetailerIds) }
    }

    fun toast(msg: String) = android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()

    // v113-267 — the person's own confirmed decision: submitting a NEW
    // dealer/retailer no longer starts from the List screen's own "+ Add"
    // (removed there, see rememberDealerBrowseConfig/
    // rememberRetailerBrowseConfig's own addRoute) — it lives here now,
    // right beside the pending list it feeds, in the one screen (this
    // component, shared by both the regular "Approve" key and the
    // Chairman panel's own Approvals tab) that already shows "Dealer Add
    // (pending count)"/"Retailer Add (pending count)".
    val dealersVm: com.abm.erp.ui.dealer.DealersScreenViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    // v113-310 — showAddDealer/showAddRetailer removed along with the
    // "জমা দিন" buttons and their dialogs: adding is no longer started
    // from the Approvals panel at all.

    // v113-264 — the person's own direct instruction, stated as a GENERAL
    // rule for every approval segment in the whole app, not just this one:
    // "সে ওটা ক্লিক করবে, দেখতে পারবে, then ওটা সে approve করবে" — Approve/
    // Reject without ever being able to see what's actually being approved
    // has no basis to decide on. The row's own quick Approve/Reject buttons
    // stay (unchanged, for when a quick decision is genuinely enough), but
    // tapping the row itself now opens the real, full content first.
    var viewingDealerAppId by remember { mutableStateOf<String?>(null) }
    var viewingInvoiceAppId by remember { mutableStateOf<String?>(null) }
    var viewingCollectionAppId by remember { mutableStateOf<String?>(null) }
    var viewingRetailerAppId by remember { mutableStateOf<String?>(null) }
    var viewingRetailerCollectionAppId by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxWidth()) {
        // v113-310 — the person's own direct correction: "অ্যাপ্রুভাল
        // অপশনের মধ্যে তো কোনো ডিলার বা রিটেইলার বাটন থাকবে না" — the
        // Approvals panel is for approving what's pending, not for
        // starting new submissions. Both "জমা দিন" buttons removed from
        // here; adding now lives as a small icon in the bottom corner of
        // the Dealer/Retailer List (see ModuleBrowseList), which is where
        // they asked for it.
        Text("Dealer Approval (${pendingDealers.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingDealers.isEmpty()) Text("কোনো pending dealer নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingDealers.forEach { d ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { viewingDealerAppId = d.id }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(d.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(d.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { scope.launch { MockRepository.approveDealer(d.id, onRejected = { r -> toast(r) }) } }) { Text("Approve") }
                    TextButton(onClick = { scope.launch { MockRepository.rejectDealer(d.id, "Rejected", onRejected = { r -> toast(r) }) } }) { Text("Reject", color = DangerRed) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Invoice Approvals (${pendingInvoices.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingInvoices.isEmpty()) Text("কোনো pending invoice নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingInvoices.take(30).forEach { inv ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { viewingInvoiceAppId = inv.id }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${inv.invoiceNo} — ${inv.dealerName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("৳${"%,.0f".format(inv.total)} · ${inv.createdAt.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { MockRepository.approveSalesInvoice(inv.id, onRejected = { r -> toast(r) }) }) { Text("Approve") }
                    TextButton(onClick = { if (!MockRepository.rejectSalesInvoice(inv.id, "Rejected")) toast("Reject করা যায়নি।") }) { Text("Reject", color = DangerRed) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Dealer Collections (${pendingCollections.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingCollections.isEmpty()) Text("কোনো pending collection নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingCollections.forEach { c ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { viewingCollectionAppId = c.id }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.partyName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("৳${"%,.0f".format(c.amount)} · ${c.method}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { scope.launch { MockRepository.verifyCollection(c.id, onRejected = { r -> toast(r) }) } }) { Text("Verify") }
                    TextButton(onClick = { scope.launch { MockRepository.rejectCollection(c.id, onRejected = { r -> toast(r) }) } }) { Text("Reject", color = DangerRed) }
                }
                if (c.proofUri != null) {
                    Spacer(Modifier.height(6.dp))
                    coil.compose.AsyncImage(
                        model = c.proofUri, contentDescription = "লেনদেনের প্রমাণ",
                        modifier = Modifier.height(110.dp).fillMaxWidth(),
                        contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                    )
                } else {
                    Spacer(Modifier.height(4.dp))
                    Text("⚠ কোনো প্রমাণের ছবি সংযুক্ত করা হয়নি।", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                }
            }
        }

        // v113-265 — Retailer Add / Memo Verification / Retailer
        // Collections, RMS's own former "Approvals" panel, now here beside
        // Dealer's equivalents. Same engines, same real logic — relocated.
        Spacer(Modifier.height(16.dp))
        Text("Retailer Approval (${pendingRetailers.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingRetailers.isEmpty()) Text("কোনো pending retailer নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingRetailers.forEach { r ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { viewingRetailerAppId = r.id }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(r.market.orEmpty(), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { scope.launch { MockRepository.approveRetailer(r.id, onRejected = { reason -> toast(reason) }) } }) { Text("Approve") }
                    TextButton(onClick = { scope.launch { MockRepository.rejectRetailer(r.id, "Rejected by Chairman", onRejected = { reason -> toast(reason) }) } }) { Text("Reject", color = DangerRed) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Memo Verification (${pendingMemos.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingMemos.isEmpty()) Text("কোনো pending memo নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingMemos.take(30).forEach { order ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Text("${order.retailerName} · ${order.zone}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text(order.items, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                Text("৳${"%,.0f".format(order.amount)}", color = TextPrimary, fontWeight = FontWeight.Bold)
                // v113-281 — the person's own instruction to "finish
                // Memo": this section (DMS's own Memo Verification,
                // v113-265) and a separate, older, still-live
                // AsmVerifyTab (SalesChainScreen.kt) both call the exact
                // same real MockRepository.advanceOrder — same real
                // backend, so never a safety gap — but AsmVerifyTab had
                // real display richness this section didn't: the
                // retailer's own shop photo/GPS and a scannable shop QR
                // code, checked directly against RetailOrder's own real
                // fields before porting rather than inventing new ones.
                // Brought here so this — the one place Memo verification
                // now actually lives, per this whole session's own
                // "everything folds into DMS" pattern — doesn't lose
                // anything a verifier used to rely on.
                if (order.retailerPhotoUri != null || order.retailerLat != null) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        buildString {
                            if (order.retailerPhotoUri != null) append("📷 দোকানের ছবি আছে  ")
                            if (order.retailerLat != null) append("📍 ${"%.3f".format(order.retailerLat)}, ${"%.3f".format(order.retailerLng)}")
                        },
                        style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                    )
                }
                var qrOpenForOrder by remember(order.id) { mutableStateOf(false) }
                order.retailerQrCode?.let { code ->
                    Spacer(Modifier.height(4.dp))
                    TextButton(onClick = { qrOpenForOrder = !qrOpenForOrder }) {
                        Text(if (qrOpenForOrder) "QR লুকান" else "🔳 দোকানের QR দেখুন")
                    }
                    if (qrOpenForOrder) {
                        val bitmap = remember(code) { com.abm.erp.util.QrCodeGenerator.generate(code, 300) }
                        androidx.compose.foundation.Image(
                            bitmap = bitmap.asImageBitmap(), contentDescription = "QR code for $code",
                            modifier = Modifier.size(140.dp),
                        )
                        Text(code, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }
                Spacer(Modifier.height(6.dp))
                val nearestDealer = remember(rmsDealers, order.zone) { rmsDealers.firstOrNull { it.zone == order.zone } ?: rmsDealers.firstOrNull() }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (nearestDealer == null) {
                        Text("কোনো dealer নেই — route করা যাচ্ছে না।", color = WarningAmber, style = MaterialTheme.typography.labelSmall)
                    } else {
                        TextButton(onClick = { MockRepository.advanceOrder(order.id, com.abm.erp.data.OrderStage.DEALER_ROUTED, nearestDealer.id) }) {
                            Text("Verify → ${nearestDealer.name}")
                        }
                    }
                    TextButton(onClick = { MockRepository.advanceOrder(order.id, com.abm.erp.data.OrderStage.REJECTED) }) { Text("Reject", color = DangerRed) }
                }
            }
        }
        // v113-312 — the person's own direct instruction: "অ্যাপ্রুভ
        // ড্রয়ারের মধ্যে শুধু অ্যাপ্রুভালের বিষয়বস্তুগুলোই থাকবে।
        // কিন্তু নিচে দেখলাম বিভিন্ন আরও অনেক অপশনগুলো দেওয়া। ওগুলোর
        // কোনো প্রয়োজন নেই।" The "Memo — Pipeline / Fulfilled" section
        // that used to sit here listed memos that had ALREADY been
        // approved and routed, with a "mark fulfilled" action — real
        // post-approval tracking, but genuinely not an approval, so it
        // does not belong in this drawer. Removed. Nothing was lost from
        // the approval flow itself: every one of the six remaining
        // sections (Dealer, Invoice, Dealer Collections, Retailer, Memo
        // Verification, Retailer Collections) is a real pending-decision
        // queue.

        Spacer(Modifier.height(16.dp))
        Text("Retailer Collections (${pendingRetailerCollections.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingRetailerCollections.isEmpty()) Text("কোনো pending collection নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingRetailerCollections.forEach { c ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { viewingRetailerCollectionAppId = c.id }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.partyName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("৳${"%,.0f".format(c.amount)} · ${c.method}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { scope.launch { MockRepository.verifyCollection(c.id, onRejected = { r -> toast(r) }) } }) { Text("Verify") }
                    TextButton(onClick = { scope.launch { MockRepository.rejectCollection(c.id, onRejected = { r -> toast(r) }) } }) { Text("Reject", color = DangerRed) }
                }
                if (c.proofUri != null) {
                    Spacer(Modifier.height(6.dp))
                    coil.compose.AsyncImage(
                        model = c.proofUri, contentDescription = "লেনদেনের প্রমাণ",
                        modifier = Modifier.height(110.dp).fillMaxWidth(),
                        contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                    )
                } else {
                    Spacer(Modifier.height(4.dp))
                    Text("⚠ কোনো প্রমাণের ছবি সংযুক্ত করা হয়নি।", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                }
            }
        }
    }

    // v113-264 — the real "view before approve" dialogs. Each shows the
    // actual full record (every real field, or the real branded invoice
    // document via the same InvoiceDocumentBody used everywhere else in
    // the app — not a second, different-looking preview), with the same
    // Approve/Reject actions available right there too, so seeing and
    // deciding can happen in one place without needing the row's own
    // buttons as a separate step.
    viewingDealerAppId?.let { id ->
        val d = pendingDealers.firstOrNull { it.id == id }
        androidx.compose.ui.window.Dialog(onDismissRequest = { viewingDealerAppId = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                if (d == null) {
                    Column(Modifier.padding(16.dp)) { Text("এই আবেদনটি আর নেই।", color = TextSecondary) }
                } else {
                    // v113-279 — the person's own direct request: these
                    // "view before decide" dialogs (v113-264/265) should
                    // be more "qualityful" — a real header (avatar +
                    // name, matching the same boxy-gradient treatment
                    // Dealer List rows already established, v113-273),
                    // key facts grouped into a bordered card instead of a
                    // flat label:value list, and clearer, icon-labelled
                    // action buttons — same real approve/reject calls
                    // underneath, purely a visual upgrade.
                    val dAccent = com.abm.erp.core.browseAvatarColor(d.name)
                    Column(Modifier.heightIn(max = 600.dp).verticalScroll(rememberScrollState())) {
                        Row(
                            Modifier.fillMaxWidth().background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(dAccent, dAccent.copy(alpha = 0.75f))))
                                .padding(16.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.25f)),
                                contentAlignment = androidx.compose.ui.Alignment.Center,
                            ) { Text(d.name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Dealer Add Application", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                                Text(d.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            }
                        }
                        Column(Modifier.padding(16.dp)) {
                            Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFF7F8FA), border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder)) {
                                Column(Modifier.padding(12.dp)) {
                                    listOf(
                                        "Zone" to d.zone, "Phone" to d.phone.ifBlank { "—" },
                                        "Address" to d.address.ifBlank { "—" }, "Classification" to d.classification,
                                        "Credit Limit" to "৳${"%,.0f".format(d.creditLimit)}",
                                        "Monthly Target" to "৳${"%,.0f".format(d.monthlyTarget)}",
                                        "Created By" to d.createdBy.ifBlank { "—" }, "Created At" to "${d.createdAt}",
                                    ).forEach { (label, value) ->
                                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                            Text(value, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Medium, textAlign = TextAlign.End)
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { scope.launch { MockRepository.approveDealer(d.id, onRejected = { r -> toast(r) }) }; viewingDealerAppId = null },
                                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                ) { Icon(Icons.Filled.Check, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Approve") }
                                OutlinedButton(onClick = { scope.launch { MockRepository.rejectDealer(d.id, "Rejected", onRejected = { r -> toast(r) }) }; viewingDealerAppId = null }) {
                                    Icon(Icons.Filled.Close, null, tint = DangerRed, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Reject", color = DangerRed)
                                }
                                TextButton(onClick = { viewingDealerAppId = null }) { Text("Close") }
                            }
                        }
                    }
                }
            }
        }
    }

    viewingInvoiceAppId?.let { id ->
        val inv = pendingInvoices.firstOrNull { it.id == id }
        androidx.compose.ui.window.Dialog(onDismissRequest = { viewingInvoiceAppId = null }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(modifier = Modifier.fillMaxSize(), color = com.abm.erp.theme.DashBg) {
                if (inv == null) {
                    Column(Modifier.padding(16.dp)) { Text("এই ইনভয়েসটি আর নেই।", color = TextSecondary) }
                } else {
                    Column(Modifier.fillMaxSize()) {
                        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(Space.md)) {
                            com.abm.erp.ui.invoice.InvoiceDocumentBody(invoice = inv, onQrPayloadReady = {})
                        }
                        Row(Modifier.fillMaxWidth().padding(Space.md), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { MockRepository.approveSalesInvoice(inv.id, onRejected = { r -> toast(r) }); viewingInvoiceAppId = null },
                                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen), modifier = Modifier.weight(1f),
                            ) { Text("Approve") }
                            OutlinedButton(
                                onClick = { if (!MockRepository.rejectSalesInvoice(inv.id, "Rejected")) toast("Reject করা যায়নি।"); viewingInvoiceAppId = null },
                                modifier = Modifier.weight(1f),
                            ) { Text("Reject", color = DangerRed) }
                        }
                        TextButton(onClick = { viewingInvoiceAppId = null }, modifier = Modifier.fillMaxWidth()) { Text("← ফিরে যান") }
                    }
                }
            }
        }
    }

    viewingCollectionAppId?.let { id ->
        val c = pendingCollections.firstOrNull { it.id == id }
        androidx.compose.ui.window.Dialog(onDismissRequest = { viewingCollectionAppId = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                if (c == null) {
                    Column(Modifier.padding(16.dp)) { Text("এই collection-টি আর নেই।", color = TextSecondary) }
                } else {
                    val cAccent = com.abm.erp.core.browseAvatarColor(c.partyName)
                    Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState())) {
                        Row(
                            Modifier.fillMaxWidth().background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(cAccent, cAccent.copy(alpha = 0.75f))))
                                .padding(16.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.25f)),
                                contentAlignment = androidx.compose.ui.Alignment.Center,
                            ) { Icon(Icons.Filled.Payments, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp)) }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Collection Verification", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                                Text(c.partyName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            }
                        }
                        Column(Modifier.padding(16.dp)) {
                            Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFF7F8FA), border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder)) {
                                Column(Modifier.padding(12.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Amount", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                        Text("৳${"%,.0f".format(c.amount)}", style = MaterialTheme.typography.titleMedium, color = SuccessGreen, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    listOf("Method" to c.method, "Date" to "${c.createdAt}").forEach { (label, value) ->
                                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                            Text(value, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Medium)
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            if (c.proofUri != null) {
                                coil.compose.AsyncImage(
                                    model = c.proofUri, contentDescription = "লেনদেনের প্রমাণ",
                                    modifier = Modifier.height(220.dp).fillMaxWidth().clip(RoundedCornerShape(10.dp)),
                                    contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                                )
                            } else {
                                Surface(shape = RoundedCornerShape(10.dp), color = WarningAmber.copy(alpha = 0.1f)) {
                                    Text("⚠ কোনো প্রমাণের ছবি সংযুক্ত করা হয়নি।", style = MaterialTheme.typography.labelSmall, color = WarningAmber, modifier = Modifier.padding(10.dp))
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { scope.launch { MockRepository.verifyCollection(c.id, onRejected = { r -> toast(r) }) }; viewingCollectionAppId = null },
                                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                ) { Icon(Icons.Filled.Check, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Verify") }
                                OutlinedButton(onClick = { scope.launch { MockRepository.rejectCollection(c.id, onRejected = { r -> toast(r) }) }; viewingCollectionAppId = null }) {
                                    Icon(Icons.Filled.Close, null, tint = DangerRed, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Reject", color = DangerRed)
                                }
                                TextButton(onClick = { viewingCollectionAppId = null }) { Text("Close") }
                            }
                        }
                    }
                }
            }
        }
    }

    viewingRetailerAppId?.let { id ->
        val r = pendingRetailers.firstOrNull { it.id == id }
        androidx.compose.ui.window.Dialog(onDismissRequest = { viewingRetailerAppId = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                if (r == null) {
                    Column(Modifier.padding(16.dp)) { Text("এই আবেদনটি আর নেই।", color = TextSecondary) }
                } else {
                    // v113-281 — same real header+card template as Dealer
                    // Add/Collection (v113-279) — a real photo, when the
                    // retailer submitted one, replaces the plain initials
                    // chip Dealer's own header falls back to, otherwise
                    // the same gradient+initials shape.
                    val rAccent = com.abm.erp.core.browseAvatarColor(r.name)
                    Column(Modifier.heightIn(max = 640.dp).verticalScroll(rememberScrollState())) {
                        Row(
                            Modifier.fillMaxWidth().background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(rAccent, rAccent.copy(alpha = 0.75f))))
                                .padding(16.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                        ) {
                            if (!r.photoUri.isNullOrBlank()) {
                                coil.compose.AsyncImage(
                                    model = r.photoUri, contentDescription = "দোকানের ছবি",
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).border(1.5.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(12.dp)),
                                )
                            } else {
                                Box(
                                    Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.25f)),
                                    contentAlignment = androidx.compose.ui.Alignment.Center,
                                ) { Text(r.name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Retailer Add Application", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                                Text(r.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            }
                        }
                        Column(Modifier.padding(16.dp)) {
                            Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFF7F8FA), border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder)) {
                                Column(Modifier.padding(12.dp)) {
                                    listOf(
                                        "Owner" to r.ownerName.ifBlank { "—" }, "Phone" to r.phone.ifBlank { "—" },
                                        "Market" to r.market.ifBlank { "—" }, "Area" to r.area.ifBlank { "—" },
                                        "Address" to r.address.ifBlank { "—" }, "Trade License" to r.tradeLicenseNo.ifBlank { "—" },
                                    ).forEach { (label, value) ->
                                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                            Text(value, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Medium, textAlign = TextAlign.End)
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { scope.launch { MockRepository.approveRetailer(r.id, onRejected = { reason -> toast(reason) }) }; viewingRetailerAppId = null },
                                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                ) { Icon(Icons.Filled.Check, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Approve") }
                                OutlinedButton(onClick = { scope.launch { MockRepository.rejectRetailer(r.id, "Rejected by Chairman", onRejected = { reason -> toast(reason) }) }; viewingRetailerAppId = null }) {
                                    Icon(Icons.Filled.Close, null, tint = DangerRed, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Reject", color = DangerRed)
                                }
                                TextButton(onClick = { viewingRetailerAppId = null }) { Text("Close") }
                            }
                        }
                    }
                }
            }
        }
    }

    viewingRetailerCollectionAppId?.let { id ->
        val c = pendingRetailerCollections.firstOrNull { it.id == id }
        androidx.compose.ui.window.Dialog(onDismissRequest = { viewingRetailerCollectionAppId = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                if (c == null) {
                    Column(Modifier.padding(16.dp)) { Text("এই collection-টি আর নেই।", color = TextSecondary) }
                } else {
                    // v113-281 — same real header+card template as Dealer
                    // Collection (v113-279).
                    val cAccent = com.abm.erp.core.browseAvatarColor(c.partyName)
                    Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState())) {
                        Row(
                            Modifier.fillMaxWidth().background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(cAccent, cAccent.copy(alpha = 0.75f))))
                                .padding(16.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.25f)),
                                contentAlignment = androidx.compose.ui.Alignment.Center,
                            ) { Icon(Icons.Filled.Payments, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp)) }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Collection Verification", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                                Text(c.partyName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            }
                        }
                        Column(Modifier.padding(16.dp)) {
                            Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFF7F8FA), border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder)) {
                                Column(Modifier.padding(12.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Amount", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                        Text("৳${"%,.0f".format(c.amount)}", style = MaterialTheme.typography.titleMedium, color = SuccessGreen, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    listOf("Method" to c.method, "Date" to "${c.createdAt}").forEach { (label, value) ->
                                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                            Text(value, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Medium)
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            if (c.proofUri != null) {
                                coil.compose.AsyncImage(
                                    model = c.proofUri, contentDescription = "লেনদেনের প্রমাণ",
                                    modifier = Modifier.height(220.dp).fillMaxWidth().clip(RoundedCornerShape(10.dp)),
                                    contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                                )
                            } else {
                                Surface(shape = RoundedCornerShape(10.dp), color = WarningAmber.copy(alpha = 0.1f)) {
                                    Text("⚠ কোনো প্রমাণের ছবি সংযুক্ত করা হয়নি।", style = MaterialTheme.typography.labelSmall, color = WarningAmber, modifier = Modifier.padding(10.dp))
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { scope.launch { MockRepository.verifyCollection(c.id, onRejected = { r -> toast(r) }) }; viewingRetailerCollectionAppId = null },
                                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                ) { Icon(Icons.Filled.Check, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Verify") }
                                OutlinedButton(onClick = { scope.launch { MockRepository.rejectCollection(c.id, onRejected = { r -> toast(r) }) }; viewingRetailerCollectionAppId = null }) {
                                    Icon(Icons.Filled.Close, null, tint = DangerRed, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Reject", color = DangerRed)
                                }
                                TextButton(onClick = { viewingRetailerCollectionAppId = null }) { Text("Close") }
                            }
                        }
                    }
                }
            }
        }
    }

}

@Composable
private fun DmsChairmanPanel(onNavigate: (String) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        androidx.compose.material3.ScrollableTabRow(selectedTabIndex = tab) {
            // v113-282 — the person's own direct instruction: DMS already
            // has its own dedicated "Approve" drawer key
            // (DmsApprove) — a second "Approvals" tab here, showing the
            // exact same DealerApprovalsShared content, was genuinely
            // redundant. Removed outright — its own real Dealer/Retailer
            // Cancellation sections (Chairman-exclusive, not duplicated
            // elsewhere) moved into the rebuilt "Dealer Control" tab
            // below instead of being lost.
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Dealer Control") })
            // v113-308 — the Retailer half of the same administration
            // scope. RetailerPinControlTab (login PIN) and
            // RetailerActionsTab (merge / credit-limit override / route
            // transfer) were removed from the Retailer browse list in
            // v113-300 as administration controls that don't belong in a
            // browse screen — this is the real home they were removed in
            // favour of, closing that loose end rather than leaving them
            // unused.
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Retailer Control") })
            // v113-295 — the person's own direct instruction: Sales Rules
            // and Security Events should not exist at all in this panel
            // — removed outright, not just their content. "Restore"
            // renamed to "Recycle" per the same message.
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Recycle") })
            // v113-338 — "Courier API" tab removed with the rest of the
            // courier integration; remaining tabs renumbered.
            // v113-342 — the person's own instruction: "chairman panel e
            // theke delete hbe seta Holo location control ata ojihotha ata
            // amr jnno kno kajer na." Removed; remaining tabs renumbered.
            // v113-290 — the person's own direct request: 2 notice slots
            // (image/GIF) on DMS's own Dashboard, settable right here.
            Tab(selected = tab == 3, onClick = { tab = 3 }, text = { Text("Notice") })
        }
        when (tab) {
            0 -> DmsDealerControlPanel()
            1 -> DmsRetailerControlPanel()
            2 -> Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
                Text("Recycle", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("Soft-deleted রেকর্ড দেখা ও restore — hard delete এই অ্যাপে নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Spacer(Modifier.height(14.dp))
                // v113-286 — the person's own direct instruction: Restore
                // should be more beautifully organized — each real
                // category now sits in its own clearly-bordered card
                // (matching the same white-surface-on-DashBg treatment
                // this whole Chairman panel already uses), rather than
                // four sections just stacked with a plain 8dp gap and no
                // visual separation between them.
                Surface(shape = RoundedCornerShape(12.dp), color = Color.White, border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder)) {
                    Column(Modifier.padding(12.dp)) { com.abm.erp.ui.chairmanmodule.DmsInvoiceRestoreSection() }
                }
                Spacer(Modifier.height(10.dp))
                Surface(shape = RoundedCornerShape(12.dp), color = Color.White, border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder)) {
                    Column(Modifier.padding(12.dp)) { com.abm.erp.ui.chairmanmodule.DmsDealerRestoreSection() }
                }
                Spacer(Modifier.height(10.dp))
                Surface(shape = RoundedCornerShape(12.dp), color = Color.White, border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder)) {
                    Column(Modifier.padding(12.dp)) { com.abm.erp.ui.chairmanmodule.DmsProductRestoreSection() }
                }
                // v113-265 — Retailer Restore, RMS's own former separate
                // Chairman-tab section, now here — same real function
                // (RmsRetailerRestoreSection), just relocated alongside
                // Invoice/Dealer/Product Restore instead of a second
                // standalone Restore tab.
                Spacer(Modifier.height(10.dp))
                Surface(shape = RoundedCornerShape(12.dp), color = Color.White, border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder)) {
                    Column(Modifier.padding(12.dp)) { com.abm.erp.ui.chairmanmodule.RmsRetailerRestoreSection() }
                }
                Spacer(Modifier.height(20.dp))
            }
            else -> DmsNoticeSlotsPanel()
        }
    }
}

/**
 * v113-290 — the person's own direct request: 2 real notice-image slots
 * on DMS's own Dashboard, managed from this new Chairman tab. Reuses
 * the exact same real `ActivityResultContracts.GetContent()` +
 * the real image MIME-wildcard picker pattern `CompanySettingsCenterScreen`'s
 * own real company-logo upload already proves, not a new picker mechanism.
 */
@Composable
private fun DmsNoticeSlotsPanel() {
    val settingsList by MockRepository.companySettingsList.collectAsState()
    val settings = remember(settingsList) { MockRepository.companySettings() }
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Text("Notice Slots", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
        Text(
            "এখানে যা সেট করবেন তা DMS Dashboard-এর একদম উপরে সবার জন্য দেখাবে — image বা GIF (সর্বোচ্চ 15MB)।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(14.dp))
        DmsNoticeSlotEditor(slot = 1, currentUri = settings.dmsNoticeSlot1Uri)
        Spacer(Modifier.height(16.dp))
        androidx.compose.material3.Divider()
        Spacer(Modifier.height(16.dp))
        DmsNoticeSlotEditor(slot = 2, currentUri = settings.dmsNoticeSlot2Uri)
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun DmsNoticeSlotEditor(slot: Int, currentUri: String?) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var uploading by remember(slot) { mutableStateOf(false) }
    var resultMsg by remember(slot) { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            uploading = true; resultMsg = null
            MockRepository.uploadDmsNoticeSlot(context, slot, uri.toString()) { savedUri ->
                uploading = false
                // v113-302 — a non-null result now means the notice is
                // genuinely saved and live on the Dashboard (saved
                // locally first; the cloud copy syncs after, if it can).
                resultMsg = if (savedUri != null) "✔ Notice $slot সেট হয়েছে — Dashboard-এ দেখা যাচ্ছে।"
                else "✖ সেট করা যায়নি — ফাইলটি image/GIF কিনা ও সাইজ (সর্বোচ্চ 15MB) দেখুন।"
            }
        }
    }
    Column {
        Text("Notice $slot", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(8.dp))
        if (!currentUri.isNullOrBlank()) {
            Surface(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                com.abm.erp.core.AnimatedImage(
                    model = currentUri, contentDescription = "Notice $slot",
                    modifier = Modifier.fillMaxWidth().heightIn(max = 160.dp),
                )
            }
            Spacer(Modifier.height(8.dp))
        } else {
            Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFF7F8FA), border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder), modifier = Modifier.fillMaxWidth()) {
                Box(Modifier.fillMaxWidth().height(90.dp), contentAlignment = androidx.compose.ui.Alignment.Center) {
                    Text("কোনো notice সেট করা নেই।", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { picker.launch("image/*") }, enabled = !uploading) {
                Text(if (uploading) "আপলোড হচ্ছে…" else if (currentUri.isNullOrBlank()) "Image/GIF যোগ করুন" else "বদলান")
            }
            if (!currentUri.isNullOrBlank()) {
                OutlinedButton(onClick = { scope.launch { MockRepository.clearDmsNoticeSlot(slot); resultMsg = "মুছে ফেলা হয়েছে।" } }) { Text("মুছুন", color = DangerRed) }
            }
        }
        resultMsg?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, style = MaterialTheme.typography.labelSmall, color = if (it.startsWith("✔") || it == "মুছে ফেলা হয়েছে।") SuccessGreen else DangerRed)
        }
    }
}

// v113-282 — the person's own direct, complete redesign of Dealer
// Control: not the regular clickable Dealer List anymore (that
// belongs to the regular "List" drawer key, not here), and not the old
// "Approvals" tab's Cancellation sections either — one consolidated,
// search-then-act panel. Search reuses DmsDealerPickerList (already
// proven for Ledger/Stock, not a new picker built for this). Once a
// dealer is picked, every section reuses a real, already-existing
// composable rather than re-implementing the same logic a third time:
// Status Control (DealerLifecycleControlTab, now 4-way per this same
// message), Transfer (DealerMergeTransferTab, unchanged), Account
// (DealerAccountControlTab — already PIN+phone-only, Chairman-scoped,
// since v113-274's own split). QR Code issue is new here specifically
// (a compact version of ModuleBrowseQrCard's own real issue/reissue
// mechanism — same real QrRegistry calls, not a second implementation)
// since the regular Dealer List/Detail's own QR action is being retired
// in favour of a real, larger QR shown directly there (a separate,
// still-open piece of this same request). Cancellation (soft-delete,
// `deleteDealer`) — the old "Approvals" tab's own real Dealer
// Cancellation section — ported here as its own clearly-separated,
// dangerous-looking action, distinct from the reversible Status Control
// toggle above it.
/**
 * v113-308 — the Retailer half of Chairman administration, closing the
 * loose end left by v113-300. `RetailerPinControlTab` (login PIN) and
 * `RetailerActionsTab` (merge duplicate / credit-limit override / route
 * transfer) were removed from the Retailer browse list then, on the
 * person's own instruction that administration controls don't belong in
 * a browse screen — but their real new home hadn't been built yet, so
 * they sat unused. This is that home.
 *
 * Deliberately mirrors `DmsDealerControlPanel`'s own shape (search →
 * pick → sectioned admin actions → confirm-gated cancel) rather than
 * inventing a second layout, so both halves of the Chairman panel read
 * the same way. Every section reuses a real, already-existing composable
 * or repository function — nothing here is a second implementation.
 */
@Composable
private fun DmsRetailerControlPanel() {
    val retailers = com.abm.erp.core.rememberVisibleRetailers()
    var selectedRetailerId by remember { mutableStateOf<String?>(null) }
    val selected = retailers.firstOrNull { it.id == selectedRetailerId && !it.isDeleted }
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    fun toast(msg: String) = android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()

    if (selected == null) {
        var query by remember { mutableStateOf("") }
        val live = remember(retailers) { retailers.filter { !it.isDeleted } }
        val filtered = remember(live, query) {
            if (query.isBlank()) live
            else live.filter { it.name.contains(query, true) || it.market.contains(query, true) || it.phone.contains(query, true) }
        }
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Text("Retailer Control", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text("নিয়ন্ত্রণ করতে একজন Retailer বাছুন।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text("নাম, ফোন বা বাজার…") },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(10.dp))
            if (filtered.isEmpty()) Text("কোনো Retailer নেই।", color = TextSecondary)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filtered, key = { it.id }) { r ->
                    com.abm.erp.core.ModuleDrillRow(r.name, "${r.market.ifBlank { "বাজার নেই" }} · ${r.onboardingStatus}") {
                        selectedRetailerId = r.id
                    }
                }
            }
        }
        return
    }

    val r = selected
    val rAccent = com.abm.erp.core.browseAvatarColor(r.name)
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            if (!r.photoUri.isNullOrBlank()) {
                coil.compose.AsyncImage(
                    model = r.photoUri, contentDescription = r.name,
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).border(1.5.dp, rAccent, RoundedCornerShape(14.dp)),
                )
            } else {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(14.dp))
                        .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(rAccent.copy(alpha = 0.85f), rAccent))),
                    contentAlignment = androidx.compose.ui.Alignment.Center,
                ) { Text(r.name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp) }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(r.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = TextPrimary)
                Text(r.market.ifBlank { "বাজার নেই" }, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            TextButton(onClick = { selectedRetailerId = null }) { Text("বদলান") }
        }

        Spacer(Modifier.height(18.dp))
        androidx.compose.material3.Divider()
        Spacer(Modifier.height(14.dp))
        Text("Account — Login PIN", fontWeight = FontWeight.Bold, color = TextPrimary)
        com.abm.erp.core.RetailerPinControlTab(r)

        Spacer(Modifier.height(18.dp))
        androidx.compose.material3.Divider()
        Spacer(Modifier.height(14.dp))
        Text("Merge / Credit / Route Transfer", fontWeight = FontWeight.Bold, color = TextPrimary)
        com.abm.erp.core.RetailerActionsTab(r)

        Spacer(Modifier.height(18.dp))
        androidx.compose.material3.Divider()
        Spacer(Modifier.height(14.dp))
        Text("QR Code", fontWeight = FontWeight.Bold, color = TextPrimary)
        DmsRetailerControlQrStatus(r.id)

        Spacer(Modifier.height(18.dp))
        androidx.compose.material3.Divider()
        Spacer(Modifier.height(14.dp))
        Text("Cancel Retailer", fontWeight = FontWeight.Bold, color = com.abm.erp.theme.DangerRed)
        Text(
            "সম্পূর্ণ soft-delete — Recycle tab থেকে পুনরুদ্ধার সম্ভব।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(8.dp))
        var confirmCancel by remember(r.id) { mutableStateOf(false) }
        if (!confirmCancel) {
            OutlinedButton(onClick = { confirmCancel = true }) { Text("এই Retailer বাতিল করুন", color = com.abm.erp.theme.DangerRed) }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { scope.launch { MockRepository.deleteRetailer(r.id, onRejected = { m -> toast(m) }) }; selectedRetailerId = null },
                    colors = ButtonDefaults.buttonColors(containerColor = com.abm.erp.theme.DangerRed),
                ) { Text("নিশ্চিত — বাতিল করুন") }
                TextButton(onClick = { confirmCancel = false }) { Text("না, থাক") }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** v113-308 — status-only, same rule as every other QR surface (v113-306). */
@Composable
private fun DmsRetailerControlQrStatus(retailerId: String) {
    var checked by remember(retailerId) { mutableStateOf(false) }
    var activeRow by remember(retailerId) { mutableStateOf<com.abm.erp.data.room.QrRegistryEntity?>(null) }
    LaunchedEffect(retailerId) {
        activeRow = com.abm.erp.data.QrRegistry.activeFor("Retailer", retailerId)
        checked = true
    }
    Column {
        when {
            !checked -> Text("QR স্ট্যাটাস দেখা হচ্ছে…", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            activeRow != null -> Text(
                "✓ QR ইস্যু করা আছে (${activeRow!!.status})",
                style = MaterialTheme.typography.labelSmall, color = SuccessGreen, fontWeight = FontWeight.SemiBold,
            )
            else -> Text(
                "এখনো QR ইস্যু হয়নি — approve হলে backend থেকে নিজে থেকেই তৈরি হবে।",
                style = MaterialTheme.typography.labelSmall, color = WarningAmber,
            )
        }
    }
}

@Composable
private fun DmsDealerControlPanel() {
    val dealers = com.abm.erp.core.rememberVisibleDealers()
    var selectedDealerId by remember { mutableStateOf<String?>(null) }
    val selectedDealer = dealers.firstOrNull { it.id == selectedDealerId && !it.isDeleted }
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    fun toast(msg: String) = android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()

    if (selectedDealer == null) {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Text("Dealer Control", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text("নিয়ন্ত্রণ করতে একজন Dealer বাছুন।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Spacer(Modifier.height(10.dp))
            DmsDealerPickerList(
                dealers = dealers.filter { !it.isDeleted },
                emptyText = "কোনো Dealer নেই।",
                subtitleFor = { "${it.zone} · ${it.status}" },
                onPick = { selectedDealerId = it.id },
            )
        }
        return
    }

    val d = selectedDealer
    val dAccent = com.abm.erp.core.browseAvatarColor(d.name)
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        // Header — real photo when the dealer has one, matching the same
        // boxy-gradient identity treatment established across the app.
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            if (!d.photoUri.isNullOrBlank()) {
                coil.compose.AsyncImage(
                    model = d.photoUri, contentDescription = d.name,
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).border(1.5.dp, dAccent, RoundedCornerShape(14.dp)),
                )
            } else {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(14.dp))
                        .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(dAccent.copy(alpha = 0.85f), dAccent))),
                    contentAlignment = androidx.compose.ui.Alignment.Center,
                ) { Text(d.name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp) }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(d.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = TextPrimary)
                Text(d.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            TextButton(onClick = { selectedDealerId = null }) { Text("বদলান") }
        }

        // v113-344 — the person's own instruction, and they were blunt
        // about why: "ai je Tumi je numner+pin er bisal jayga jure khali ai
        // box duita deco aita dakce ottonto baje Lage aita aro proffesonal
        // hoa ucit like akta icon er mto choto click korle option gula
        // asbe. Abr Deler er I'd Jodi eidt Kori setao aivabe mele rakco
        // jetao dakte ottonto unprofessional lgce... kintu sob airkm na sob
        // option ei icon akare thake click korle show korbe."
        //
        // Six full sections were stacked down the page — Status, Transfer,
        // Profile, Account, QR, Cancel — each fully expanded whether or not
        // anyone needed it, so reaching Cancel meant scrolling past four
        // forms. Now every one is a small labelled icon in a grid; tapping
        // one opens just that section beneath. One open at a time, so the
        // page never grows longer than a phone screen plus the one thing
        // being worked on.
        //
        // Status Control is the exception they explicitly approved
        // ("stutus button er syestemta jeivabe rakco thik ase") — it stays
        // exactly as it is, a pill toggle shown inline.
        Spacer(Modifier.height(18.dp))
        Text("Status Control", fontWeight = FontWeight.Bold, color = TextPrimary)
        com.abm.erp.core.DealerLifecycleControlTab(d)

        Spacer(Modifier.height(18.dp))
        androidx.compose.material3.Divider()
        Spacer(Modifier.height(14.dp))

        var openSection by remember(d.id) { mutableStateOf<String?>(null) }
        val tiles = listOf(
            Triple("profile", "Profile", Icons.Filled.Edit),
            Triple("account", "Login/PIN", Icons.Filled.Password),
            Triple("transfer", "Transfer/Officer", Icons.Filled.SwapHoriz),
            Triple("qr", "QR Code", Icons.Filled.QrCode2),
            // v113-347 — point 5: a dealer leaving is its own real event,
            // distinct from cancelling one. Given its own tile so it can't
            // be confused with Cancel, which simply removes a record.
            Triple("closing", "Closing", Icons.Filled.AssignmentReturn),
            Triple("cancel", "Cancel", Icons.Filled.DeleteOutline),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            tiles.forEach { (key, label, icon) ->
                val active = openSection == key
                val tint = if (key == "cancel") com.abm.erp.theme.DangerRed else Color(0xFF2563EB)
                Column(
                    Modifier.weight(1f).clickable { openSection = if (active) null else key }.padding(vertical = 6.dp),
                    horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (active) tint.copy(alpha = 0.18f) else tint.copy(alpha = 0.07f))
                            .border(1.dp, if (active) tint else Color.Transparent, RoundedCornerShape(12.dp)),
                        contentAlignment = androidx.compose.ui.Alignment.Center,
                    ) { Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp)) }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        label, fontSize = 10.sp, maxLines = 1,
                        color = if (active) tint else TextSecondary,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                    )
                }
            }
        }

        if (openSection != null) {
            Spacer(Modifier.height(14.dp))
            androidx.compose.material3.Divider()
            Spacer(Modifier.height(14.dp))
        }

        when (openSection) {
            "profile" -> {
                Text("Profile — নাম, ফোন, ঠিকানা, ছবি, Location", fontWeight = FontWeight.Bold, color = TextPrimary)
                DmsDealerProfileEditSection(d)
            }
            "account" -> {
                Text("Account — Login ID ও PIN", fontWeight = FontWeight.Bold, color = TextPrimary)
                com.abm.erp.core.DealerAccountControlTab(d)
            }
            "transfer" -> {
                Text("Transfer ও দায়িত্বপ্রাপ্ত Officer", fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(
                    "এলাকা বদলালে সাধারণত officer-ও বদলায় — দুটোই এখানে একসাথে করা যায়।",
                    style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                )
                Spacer(Modifier.height(8.dp))
                DmsDealerOfficerAssignSection(d)
                Spacer(Modifier.height(6.dp))
                com.abm.erp.core.DealerMergeTransferTab(d)
            }
            "closing" -> DmsDealerClosingSection(d) { selectedDealerId = null }
            "qr" -> {
                Text("QR Code", fontWeight = FontWeight.Bold, color = TextPrimary)
                DmsDealerControlQrStatus(d.id)
            }
            "cancel" -> {
                Text("Cancel Dealer", fontWeight = FontWeight.Bold, color = com.abm.erp.theme.DangerRed)
                Text(
                    "সম্পূর্ণ soft-delete — Recycle tab থেকে পুনরুদ্ধার সম্ভব।",
                    style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                )
                Spacer(Modifier.height(8.dp))
                var confirmCancel by remember(d.id) { mutableStateOf(false) }
                if (!confirmCancel) {
                    OutlinedButton(onClick = { confirmCancel = true }) { Text("এই Dealer বাতিল করুন", color = com.abm.erp.theme.DangerRed) }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { scope.launch { MockRepository.deleteDealer(d.id, onRejected = { m -> toast(m) }) }; selectedDealerId = null },
                            colors = ButtonDefaults.buttonColors(containerColor = com.abm.erp.theme.DangerRed),
                        ) { Text("নিশ্চিত — বাতিল করুন") }
                        TextButton(onClick = { confirmCancel = false }) { Text("না, থাক") }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

/**
 * v113-306 — item 14: status-only. The previous version of this
 * section could issue and reissue a Dealer QR by hand; the person's own
 * instruction is that QR generation happens in the backend at approval
 * and nowhere else, so both buttons are gone. Reissue in particular was
 * genuinely destructive — it revoked an already-printed, possibly
 * already-distributed code — which is exactly the kind of manual
 * override being removed. Reads the same real QrRegistry.activeFor this
 * panel always used; it simply no longer offers to change anything.
 */
/**
 * v113-347 — Dealer Closing, the person's own point 5: "abr deler Jodi
 * Deler chere dey se kherte tar hisab closing ba tar ledger onno Deler
 * pointe e transfer korar biosy gulao thaka ucit."
 *
 * Kept separate from Cancel on purpose. Cancel removes a record that
 * shouldn't exist; Closing handles a real dealer who traded, still owes
 * money, and is leaving. Confusing the two would either lose a real
 * receivable or terminate someone who simply had a typo.
 */
@Composable
private fun DmsDealerClosingSection(dealer: com.abm.erp.data.Dealer, onDone: () -> Unit) {
    val dealers = com.abm.erp.core.rememberVisibleDealers()
    val candidates = remember(dealers, dealer.id) {
        dealers.filter { !it.isDeleted && it.id != dealer.id }
    }
    var targetId by remember(dealer.id) { mutableStateOf<String?>(null) }
    var reason by remember(dealer.id) { mutableStateOf("") }
    var confirming by remember(dealer.id) { mutableStateOf(false) }
    var result by remember(dealer.id) { mutableStateOf<String?>(null) }
    val target = candidates.firstOrNull { it.id == targetId }

    Column {
        Text("Dealer Closing", fontWeight = FontWeight.Bold, color = TextPrimary)
        Text(
            "Dealer ব্যবসা ছেড়ে দিলে — তার বকেয়া ও stock অন্য একটি dealer point-এ স্থানান্তর করে হিসাব বন্ধ করা হয়।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(10.dp))

        // Shown up front, because this is the number that decides whether
        // closing is even the right action today.
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (dealer.dueBalance > 0) WarningAmber.copy(alpha = 0.08f) else SuccessGreen.copy(alpha = 0.08f),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                (if (dealer.dueBalance > 0) WarningAmber else SuccessGreen).copy(alpha = 0.35f),
            ),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("বর্তমান বকেয়া", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text(
                    "৳${"%,.2f".format(dealer.dueBalance)}",
                    fontWeight = FontWeight.Bold,
                    color = if (dealer.dueBalance > 0) WarningAmber else SuccessGreen,
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Text("কোন dealer point-এ যাবে?", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(6.dp))
        com.abm.erp.core.DealerSearchIcon(
            dealers = candidates,
            onPick = { picked -> targetId = picked.id },
            selectedLabel = target?.name,
            emptyText = "অন্য কোনো dealer পাওয়া যায়নি।",
        )

        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = reason, onValueChange = { reason = it },
            label = { Text("কারণ (কেন ছাড়ছে)") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
        )

        result?.let {
            Spacer(Modifier.height(8.dp))
            Text(
                it, style = MaterialTheme.typography.labelSmall,
                color = if (it.startsWith("✔")) SuccessGreen else DangerRed,
            )
        }

        Spacer(Modifier.height(12.dp))
        if (!confirming) {
            Button(
                onClick = { confirming = true },
                enabled = target != null && reason.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("হিসাব বন্ধ করে স্থানান্তর করুন") }
            if (target == null || reason.isBlank()) {
                Text(
                    "গ্রহণকারী dealer ও কারণ — দুটোই দিতে হবে।",
                    style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        } else {
            // Spelled out in full before it happens: this moves real money
            // between two parties and terminates one of them.
            Text(
                "নিশ্চিত? ${dealer.name}-এর ৳${"%,.2f".format(dealer.dueBalance)} বকেয়া ও সব stock ${target?.name}-এ যাবে, " +
                    "এবং ${dealer.name} Terminated হয়ে যাবে।",
                style = MaterialTheme.typography.labelSmall, color = DangerRed,
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        confirming = false
                        val to = target ?: return@Button
                        MockRepository.closeDealerAndTransfer(dealer.id, to.id, reason.trim()) { msg ->
                            result = msg
                            if (msg.startsWith("✔")) onDone()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = com.abm.erp.theme.DangerRed),
                ) { Text("হ্যাঁ, বন্ধ করুন") }
                TextButton(onClick = { confirming = false }) { Text("না, থাক") }
            }
        }
    }
}

@Composable
private fun DmsDealerControlQrStatus(dealerId: String) {
    var checked by remember(dealerId) { mutableStateOf(false) }
    var activeRow by remember(dealerId) { mutableStateOf<com.abm.erp.data.room.QrRegistryEntity?>(null) }

    LaunchedEffect(dealerId) {
        activeRow = com.abm.erp.data.QrRegistry.activeFor("Dealer", dealerId)
        checked = true
    }

    val payload = activeRow?.payload?.takeIf { it.isNotBlank() }
    val scope = rememberCoroutineScope()
    var working by remember(dealerId) { mutableStateOf(false) }
    var result by remember(dealerId) { mutableStateOf<String?>(null) }

    Column {
        when {
            !checked -> Text("QR স্ট্যাটাস দেখা হচ্ছে…", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            payload != null -> Text(
                "✓ QR ইস্যু করা আছে — Dealer profile-এ ছবি হিসেবে দেখা যাচ্ছে।",
                style = MaterialTheme.typography.labelSmall, color = SuccessGreen, fontWeight = FontWeight.SemiBold,
            )
            activeRow != null -> {
                // v113-340 — the real gap this closes. A Dealer QR is issued
                // at approval only, and before v113-326 the payload was not
                // stored — so every dealer approved before then has a
                // registry row whose code can never be redrawn. With no way
                // out, those dealers would stay permanently un-scannable
                // through nobody's fault.
                //
                // This is the ONE remaining place a QR can be issued by
                // hand, and deliberately only for that case: it does not
                // appear when a working QR already exists, so it cannot be
                // used to casually revoke a code already printed and out in
                // the field — which is exactly what the person asked to
                // prevent when they had manual reissue removed.
                Text(
                    "⚠ এই dealer-এর QR পুরনো নিয়মে তৈরি — code সংরক্ষিত নেই, তাই আবার আঁকা যায় না।",
                    style = MaterialTheme.typography.labelSmall, color = WarningAmber,
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        working = true; result = null
                        scope.launch {
                            val newPayload = com.abm.erp.data.QrRegistry.reissue(
                                "Dealer", dealerId, reason = "পুরনো QR-এ code সংরক্ষিত ছিল না",
                            )
                            working = false
                            if (newPayload != null) {
                                activeRow = com.abm.erp.data.QrRegistry.activeFor("Dealer", dealerId)
                                result = "✔ নতুন QR তৈরি হয়েছে — Dealer profile-এ ছবি দেখা যাবে।"
                            } else {
                                result = "✖ তৈরি করা যায়নি — আবার চেষ্টা করুন।"
                            }
                        }
                    },
                    enabled = !working,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (working) "তৈরি হচ্ছে…" else "এই dealer-এর জন্য নতুন QR তৈরি করুন") }
                Text(
                    "পুরনো কোনো প্রিন্ট করা QR থাকলে সেটা আর কাজ করবে না।",
                    style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
            else -> {
                // v113-345 — the person's own point 6: "deller jkn apporve
                // hbe tkn to auto qr genaret hbe. Jodi existing Deler er qr
                // na thake se khtre oi Deler er jnno tkni qr issue option
                // chairman panel e show korbe jate qr issue kora jay."
                //
                // Approval-time generation (v113-306) is unchanged and is
                // still the only automatic path. But it fires only at the
                // moment of approval — so a dealer approved before that
                // existed, or one whose activation failed while offline,
                // has no QR and no way to ever get one. That is the gap
                // this closes.
                //
                // Deliberately shown ONLY when there is genuinely no QR at
                // all. Where a working one exists this branch is never
                // reached, so this can never revoke a code already printed
                // and handed out — the thing they asked to prevent when
                // manual reissue was removed.
                Text(
                    "এই dealer-এর কোনো QR নেই — approve হয়ে গেছে বলে নিজে থেকে আর তৈরি হবে না।",
                    style = MaterialTheme.typography.labelSmall, color = WarningAmber,
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        working = true; result = null
                        scope.launch {
                            val issued = com.abm.erp.data.QrRegistry.issue("Dealer", dealerId)
                            working = false
                            if (issued != null) {
                                activeRow = com.abm.erp.data.QrRegistry.activeFor("Dealer", dealerId)
                                result = "✔ QR তৈরি হয়েছে — Dealer profile-এ ছবি দেখা যাবে।"
                            } else {
                                result = "✖ তৈরি করা যায়নি — আবার চেষ্টা করুন।"
                            }
                        }
                    },
                    enabled = !working,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (working) "তৈরি হচ্ছে…" else "এই dealer-এর জন্য QR ইস্যু করুন") }
            }
        }
        result?.let {
            Spacer(Modifier.height(6.dp))
            Text(
                it, style = MaterialTheme.typography.labelSmall,
                color = if (it.startsWith("✔")) SuccessGreen else DangerRed,
            )
        }
    }
}

/**
 * v113-285 — the person's own direct new request: officer assignment
 * (who's responsible for this dealer) should be settable from the
 * Chairman panel itself — role- and geo-wise. Read side reuses the same
 * real chain-walk `dealerOfficerChainRows` already established
 * (v113-274 — SO up through `directManagerId`, labelled by each
 * employee's own real role, not a hardcoded SO/ASM/TSM/RSM list). Write
 * side is new: a picker filtered to `role == SR` (matching
 * `Dealer.assignedEmployeeId`'s own doc comment — "assigned SR/
 * employee" — the actual field this sets), sorted so employees sharing
 * the dealer's own real `territoryId` surface first — geo-relevance as
 * ordering, not a hard block, since the Chairman's own company-wide
 * authority should still allow a deliberate out-of-territory exception
 * when genuinely needed.
 */
/**
 * v113-332 — Chairman-only Dealer profile editing.
 *
 * Fields start pre-filled with what is stored, so this reads as
 * "correct what's wrong" rather than "fill this in again" — and an
 * untouched field saves back its own current value unchanged.
 *
 * Location is deliberately re-captured by GPS rather than typed: the
 * whole point of moving a dealer's pin is that the old coordinates were
 * wrong, and letting someone hand-type latitude would just produce a
 * different kind of wrong. Same reverse-geocode fill as the registration
 * form (v113-327), so re-capturing also offers the new address.
 */
@Composable
private fun DmsDealerProfileEditSection(dealer: com.abm.erp.data.Dealer) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember(dealer.id) { mutableStateOf(dealer.name) }
    var phone by remember(dealer.id) { mutableStateOf(dealer.phone) }
    var address by remember(dealer.id) { mutableStateOf(dealer.address) }
    var zone by remember(dealer.id) { mutableStateOf(dealer.zone) }
    var newLat by remember(dealer.id) { mutableStateOf(dealer.lat) }
    var newLng by remember(dealer.id) { mutableStateOf(dealer.lng) }
    var message by remember(dealer.id) { mutableStateOf<String?>(null) }

    val photoLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent(),
    ) { uri ->
        if (uri != null) {
            MockRepository.uploadDealerPhoto(context, dealer.id, uri.toString()) { url ->
                message = if (url != null) "✔ ছবি হালনাগাদ হয়েছে।" else "✖ ছবি আপলোড ব্যর্থ — ফাইল ও সাইজ দেখুন।"
            }
        }
    }

    fun recaptureLocation() {
        val granted = androidx.core.content.ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.ACCESS_FINE_LOCATION,
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!granted) { message = "Location permission নেই।"; return }
        try {
            val client = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(context)
            @Suppress("MissingPermission")
            client.lastLocation.addOnSuccessListener { loc ->
                if (loc == null) { message = "GPS পাওয়া যায়নি — খোলা জায়গায় গিয়ে আবার দিন।"; return@addOnSuccessListener }
                newLat = loc.latitude; newLng = loc.longitude
                message = "📍 নতুন location নেওয়া হয়েছে — সংরক্ষণ করুন।"
                scope.launch {
                    val resolved = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        com.abm.erp.location.ReverseGeocoder.resolve(context, loc.latitude, loc.longitude)
                    } ?: return@launch
                    if (address.isBlank()) address = resolved.addressLine
                }
            }.addOnFailureListener { message = it.message ?: "Location নেওয়া যায়নি।" }
        } catch (e: SecurityException) { message = "Location permission নেই।" }
    }

    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("ফোন") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("ঠিকানা") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = zone, onValueChange = { zone = it }, label = { Text("এলাকা / Zone") }, singleLine = true, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { photoLauncher.launch("image/*") }, modifier = Modifier.weight(1f)) {
                Text(if (dealer.photoUri.isNullOrBlank()) "ছবি দিন" else "ছবি বদলান", fontSize = 12.sp)
            }
            OutlinedButton(onClick = { recaptureLocation() }, modifier = Modifier.weight(1f)) {
                Text("📍 Location নিন", fontSize = 12.sp)
            }
        }
        Text(
            if (newLat != null && newLng != null) "বর্তমান: ${"%.5f".format(newLat)}, ${"%.5f".format(newLng)}"
            else "কোনো location সংরক্ষিত নেই",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
            modifier = Modifier.padding(top = 4.dp),
        )

        message?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, style = MaterialTheme.typography.labelSmall, color = if (it.startsWith("✖")) DangerRed else SuccessGreen)
        }

        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                val ok = MockRepository.updateDealerProfile(
                    dealerId = dealer.id, name = name, phone = phone, address = address,
                    zone = zone, lat = newLat, lng = newLng,
                    onRejected = { r -> message = "✖ $r" },
                )
                if (ok) message = "✔ Profile হালনাগাদ হয়েছে।"
            },
            enabled = name.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Profile সংরক্ষণ করুন") }
    }
}

@Composable
private fun DmsDealerOfficerAssignSection(dealer: com.abm.erp.data.Dealer) {
    val employees by MockRepository.employeeProfiles.collectAsState()
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    fun toast(msg: String) = android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()

    val chain = remember(dealer.assignedEmployeeId, employees) {
        val list = mutableListOf<com.abm.erp.data.EmployeeProfile>()
        var currentId = dealer.assignedEmployeeId
        val visited = mutableSetOf<String>()
        while (currentId != null && visited.add(currentId)) {
            val emp = employees.firstOrNull { it.id == currentId } ?: break
            list.add(emp)
            currentId = emp.directManagerId
        }
        list
    }
    var pickerOpen by remember(dealer.id) { mutableStateOf(false) }
    var query by remember(dealer.id) { mutableStateOf("") }

    // v113-345 — the person's own point 4: "sathe delr er jonno asign kora
    // employee er chain eito nai jemin Sr/tsm/asm/RSM/dsm/Nsm/agm/gm etc."
    //
    // The chain-walk itself already existed, but it only ever rendered the
    // levels that happen to be LINKED — so if an SR has no directManagerId
    // set, the "chain" is one name and the hierarchy above is invisible.
    // Nothing told anyone whether that meant "no manager exists" or "the
    // link was never recorded", which is exactly why it read as missing.
    //
    // Now the full ladder is always shown, SR at the bottom up to GM, with
    // each level either naming its real person or marked as a gap. A
    // missing link is a real data problem worth seeing, not something to
    // hide by only drawing what happens to be there.
    val ladder = listOf(
        com.abm.erp.data.UserRole.SR, com.abm.erp.data.UserRole.TSM,
        com.abm.erp.data.UserRole.ASM, com.abm.erp.data.UserRole.RSM,
        com.abm.erp.data.UserRole.DSM, com.abm.erp.data.UserRole.NSM,
        com.abm.erp.data.UserRole.AGM, com.abm.erp.data.UserRole.GM,
    )
    val byRole = remember(chain) { chain.associateBy { it.role } }
    // Only draw up to the highest level actually reached, so a dealer whose
    // chain genuinely stops at ASM isn't shown four empty rows implying
    // people who were never meant to be there.
    val topIndex = remember(byRole) {
        ladder.indexOfLast { byRole.containsKey(it) }.let { if (it < 0) 0 else it }
    }

    Column {
        if (chain.isEmpty()) {
            Text("কোনো officer নির্ধারিত নেই।", color = WarningAmber, style = MaterialTheme.typography.bodySmall)
        } else {
            ladder.take(topIndex + 1).reversed().forEach { role ->
                val emp = byRole[role]
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                ) {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Box(
                            Modifier.size(6.dp).clip(RoundedCornerShape(999.dp))
                                .background(if (emp != null) SuccessGreen else WarningAmber),
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(role.name, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Text(
                        emp?.fullName ?: "— যুক্ত করা হয়নি",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (emp != null) TextPrimary else WarningAmber,
                        fontWeight = if (emp != null) FontWeight.Medium else FontWeight.Normal,
                    )
                }
            }
            // Anyone whose role isn't on the standard ladder still belongs
            // in the chain — showing them separately is more honest than
            // silently dropping them because they don't fit the model.
            chain.filter { it.role !in ladder }.forEach { emp ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(emp.role.name, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(emp.fullName, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Medium)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        if (!pickerOpen) {
            OutlinedButton(onClick = { pickerOpen = true }) { Text(if (chain.isEmpty()) "Officer নির্ধারণ করুন" else "Officer বদলান") }
        } else {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text("SR-এর নাম খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(6.dp))
            val candidates = remember(employees, dealer.territoryId, query) {
                employees.filter { it.role == com.abm.erp.data.UserRole.SR && (query.isBlank() || it.fullName.contains(query, true)) }
                    .sortedByDescending { it.territoryId != null && it.territoryId == dealer.territoryId }
            }
            if (candidates.isEmpty()) {
                Text("কোনো SR পাওয়া যায়নি।", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
            }
            candidates.take(15).forEach { emp ->
                val sameTerritory = emp.territoryId != null && emp.territoryId == dealer.territoryId
                Row(
                    Modifier.fillMaxWidth().clickable {
                        scope.launch {
                            val ok = MockRepository.setDealerAssignedEmployee(dealer.id, emp.id, onRejected = { r -> toast(r) })
                            if (ok) { toast("✔ ${emp.fullName}-কে দায়িত্ব দেওয়া হয়েছে।"); pickerOpen = false; query = "" }
                        }
                    }.padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(emp.fullName, color = TextPrimary)
                    if (sameTerritory) Text("একই এলাকা", style = MaterialTheme.typography.labelSmall, color = SuccessGreen, fontWeight = FontWeight.Bold)
                }
            }
            TextButton(onClick = { pickerOpen = false; query = "" }) { Text("বাতিল") }
        }
    }
}

/**
 * v113-290 — the person's own direct request. Shows each real, set
 * notice slot as a full-width tappable image/GIF card (tap opens a
 * bigger view — a small "notice" image is otherwise easy to miss).
 * Nothing renders when a slot is empty — CompanySettings' own default
 * (both null) means a brand-new company sees no placeholder clutter.
 */
@Composable
private fun DmsNoticeSlotsDisplay() {
    val settings by MockRepository.companySettingsList.collectAsState()
    val current = settings.firstOrNull { it.id == MockRepository.currentUser.companyId }
    val slot1 = current?.dmsNoticeSlot1Uri
    val slot2 = current?.dmsNoticeSlot2Uri
    if (slot1.isNullOrBlank() && slot2.isNullOrBlank()) return

    var viewingUri by remember { mutableStateOf<String?>(null) }
    Column {
        listOfNotNull(slot1, slot2).forEach { uri ->
            Surface(
                shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                    .clickable { viewingUri = uri },
            ) {
                com.abm.erp.core.AnimatedImage(
                    model = uri, contentDescription = "Notice",
                    modifier = Modifier.fillMaxWidth().heightIn(max = 160.dp),
                )
            }
        }
    }
    viewingUri?.let { uri ->
        androidx.compose.ui.window.Dialog(onDismissRequest = { viewingUri = null }) {
            Surface(shape = RoundedCornerShape(16.dp), color = Color.Black) {
                com.abm.erp.core.AnimatedImage(
                    model = uri, contentDescription = "Notice", contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth().heightIn(max = 500.dp).clickable { viewingUri = null },
                )
            }
        }
    }
}

@Composable
private fun DmsDashboard(dealers: List<com.abm.erp.data.Dealer>) {
    // v113-253 — a real audit catch: dealers (as passed into this whole
    // screen) isn't reliably isDeleted-filtered on every role path
    // visibleDealersFor takes (confirmed directly — only the profile-
    // linked branch filters it), so a soft-deleted dealer could inflate
    // this Dashboard's own real business numbers — the dealer count, the
    // total due, and both of the newly-added graphs below, all of which
    // read from dealers directly. Filtered once, here, rather than
    // scattering the same guard across every individual stat.
    val activeDealers = remember(dealers) { dealers.filter { !it.isDeleted } }
    val invoices by MockRepository.salesInvoices.collectAsState()
    val approvals by MockRepository.approvals.collectAsState()
    // v113-267 — real product photos for the Top Products KPI ring below,
    // the same real InventoryRepository.products list DmsAlertsTab already
    // reads, not a second/fabricated source.
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val totalDue = remember(activeDealers) { activeDealers.sumOf { it.dueBalance } }
    val pendingInvoices = remember(invoices) { invoices.count { it.status == "PENDING" && !it.isDeleted } }
    val pendingApprovals = remember(approvals) {
        approvals.count { it.status == com.abm.erp.data.ApprovalStatus.PENDING && it.entityType == "SalesInvoice" }
    }
    // v113-265 — the person's own confirmed decision: RMS's own separate
    // Dashboard removed, DMS's own gets Retailer numbers folded in
    // instead. Same real accessor RMS itself used.
    val activeRetailers = com.abm.erp.core.rememberVisibleRetailers()
    val retailerTotalDue = remember(activeRetailers) { activeRetailers.filter { !it.isDeleted }.sumOf { it.dueBalance } }

    // v113-263 — same real Export/Share/Print registration as Ledger, for
    // the module's own Dashboard (a summary screen, no per-row record) —
    // the exact same real numbers the cards below already show.
    com.abm.erp.core.RegisterModuleMenuContent(
        title = "DMS Overview",
        rows = listOf(
            "Dealer" to "${activeDealers.size}",
            "Total Due" to "৳${"%,.0f".format(totalDue)}",
            "Pending Invoice" to "$pendingInvoices",
            "Pending Approval" to "$pendingApprovals",
            "Retailer" to "${activeRetailers.count { !it.isDeleted }}",
            "Retailer Total Due" to "৳${"%,.0f".format(retailerTotalDue)}",
        ),
    )

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("DMS Overview", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(4.dp))
        Text(
            "আপনার cascade scope অনুযায়ী — অন্য এলাকার dealer/retailer এখানে গোনা হয় না।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(12.dp))
        // v113-290 — the person's own direct request: 2 real notice slots
        // right on DMS's own Dashboard, settable from DMS's Chairman
        // panel (see the new "Notice" tab there). Each slot renders only
        // when a real image/GIF is actually set — no empty placeholder
        // boxes cluttering the Dashboard when the Chairman hasn't posted
        // anything.
        DmsNoticeSlotsDisplay()
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            DmsStatRow("Dealer", "${activeDealers.size}", TextPrimary)
            DmsStatRow("Total Due", "৳${"%,.0f".format(totalDue)}", if (totalDue > 0) WarningAmber else SuccessGreen)
            DmsStatRow("Pending Invoice", "$pendingInvoices", if (pendingInvoices > 0) WarningAmber else SuccessGreen)
            DmsStatRow("Pending Approval", "$pendingApprovals", if (pendingApprovals > 0) WarningAmber else SuccessGreen)
        }
        Spacer(Modifier.height(12.dp))
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            DmsStatRow("Retailer", "${activeRetailers.count { !it.isDeleted }}", TextPrimary)
            DmsStatRow("Retailer Total Due", "৳${"%,.0f".format(retailerTotalDue)}", if (retailerTotalDue > 0) WarningAmber else SuccessGreen)
        }
        // v113-139 — person asked every mother-module dashboard to carry a KPI
        // graphic. Uses the SHARED DualSeriesBarChart and real invoice/collection
        // rows for the dealers in this user's own cascade scope — no sample data,
        // and no second charting implementation.
        val collections by MockRepository.partyCollections.collectAsState()
        val myDealerIds = remember(activeDealers) { activeDealers.map { it.id }.toSet() }
        val weekly = remember(invoices, collections, myDealerIds) {
            val today = java.time.LocalDate.now()
            val thisMonday = today.minusDays((today.dayOfWeek.value - 1).toLong())
            (4 downTo 0).map { w ->
                val start = thisMonday.minusWeeks(w.toLong())
                val end = start.plusDays(7)
                val sales = invoices.filter { !it.isDeleted && it.dealerId in myDealerIds && !it.createdAt.toLocalDate().isBefore(start) && it.createdAt.toLocalDate().isBefore(end) }
                    .sumOf { inv -> inv.lineItems.sumOf { it.lineTotal } }
                val col = collections.filter { it.status == "VERIFIED" && it.partyId in myDealerIds && !it.createdAt.toLocalDate().isBefore(start) && it.createdAt.toLocalDate().isBefore(end) }
                    .sumOf { it.amount }
                Triple("${start.dayOfMonth}/${start.monthValue}", sales, col)
            }
        }
        if (weekly.any { it.second > 0.0 || it.third > 0.0 }) {
            Spacer(Modifier.height(12.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Sales vs Collection — Last 5 Weeks", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                com.abm.erp.core.DualSeriesBarChart(weekly, "Sales", "Collection")
            }
        }

        // v113-251 — the person's own direct instruction: entering DMS
        // should show real graphical reports right on the Dashboard, not
        // just stat numbers and one chart. Reuses the exact bar-progress
        // visual already proven in TerritoryOverviewScreen's own Sales
        // Report tab and DealerSalesReportTab — same pattern, company-
        // wide scope here, not a new visual language invented for this
        // one screen.
        val myDealerIds30 = remember(activeDealers) { activeDealers.map { it.id }.toSet() }
        val last30Invoices = remember(invoices, myDealerIds30) {
            val cutoff = java.time.LocalDate.now().minusDays(29)
            invoices.filter { !it.isDeleted && it.dealerId in myDealerIds30 && !it.createdAt.toLocalDate().isBefore(cutoff) }
        }
        data class TopProduct(val productId: String, val name: String, val qty: Int, val value: Double, val photoUri: String?)
        val topProducts = remember(last30Invoices, products) {
            last30Invoices.flatMap { it.lineItems }
                .groupBy { it.productId }
                .map { (productId, lines) ->
                    val realProduct = products.firstOrNull { it.id == productId }
                    TopProduct(
                        productId = productId,
                        name = realProduct?.name ?: lines.first().name,
                        qty = lines.sumOf { it.qty },
                        value = lines.sumOf { it.lineTotal },
                        photoUri = realProduct?.photoUri,
                    )
                }
                .sortedByDescending { it.value }.take(6)
        }
        if (topProducts.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Top Products — Last 30 Days", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(12.dp))
                val maxVal = topProducts.maxOf { it.value }
                // v113-267 — the person's own direct request: a more
                // "professional" KPI look for product growth — real photo
                // + a colourful circular sales-share ring, not a thin bar.
                val ringColors = listOf(0xFFE85D4A, 0xFF2563EB, 0xFF1FA972, 0xFF9C6EFF, 0xFFDB2777, 0xFF0EA5A4)
                topProducts.forEachIndexed { idx, p ->
                    val pct = (p.value / maxVal).toFloat().coerceIn(0f, 1f)
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        ProductGrowthRing(
                            photoUri = p.photoUri,
                            percent = pct,
                            ringColor = Color(ringColors[idx % ringColors.size]),
                            size = 46.dp,
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, maxLines = 1)
                            Text("${p.qty} pcs · ৳${"%,.0f".format(p.value)}", fontSize = 11.sp, color = TextSecondary)
                        }
                        Text("${"%.0f".format(pct * 100)}%", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(ringColors[idx % ringColors.size]))
                    }
                }
            }
        }

        // Zone-wise due — where the risk actually concentrates, at a glance.
        val zoneDue = remember(activeDealers) {
            activeDealers.filter { it.zone.isNotBlank() }
                .groupBy { it.zone }
                .map { (zone, ds) -> zone to ds.sumOf { it.dueBalance } }
                .sortedByDescending { it.second }.take(6)
        }
        if (zoneDue.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Zone-wise Due", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                val maxDue = zoneDue.maxOf { it.second }.coerceAtLeast(1.0)
                zoneDue.forEach { (zone, due) ->
                    Column(Modifier.padding(vertical = 4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(zone, fontSize = 11.sp, color = TextPrimary, maxLines = 1, modifier = Modifier.weight(1f))
                            Text("৳${"%,.0f".format(due)}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = if (due > 0) WarningAmber else SuccessGreen)
                        }
                        Spacer(Modifier.height(3.dp))
                        Box(Modifier.fillMaxWidth().height(5.dp).background(com.abm.erp.theme.HairlineBorder, androidx.compose.foundation.shape.RoundedCornerShape(999.dp))) {
                            Box(
                                Modifier.fillMaxWidth((due / maxDue).toFloat().coerceIn(0f, 1f))
                                    .fillMaxHeight().background(if (due > 0) WarningAmber else SuccessGreen, androidx.compose.foundation.shape.RoundedCornerShape(999.dp)),
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun DmsStatRow(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Text(value, fontWeight = FontWeight.Bold, color = color)
    }
}

/**
 * v113-267 — the person's own direct request: a "professional" KPI look
 * for product growth — the real product photo (or a neutral placeholder
 * when none is set) with a colourful circular sales-share ring drawn
 * around it, `percent` full. Pure presentation — takes real numbers in,
 * doesn't compute anything itself.
 */
@Composable
private fun ProductGrowthRing(photoUri: String?, percent: Float, ringColor: androidx.compose.ui.graphics.Color, size: androidx.compose.ui.unit.Dp) {
    Box(Modifier.size(size), contentAlignment = androidx.compose.ui.Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            val strokeWidth = 3.5.dp.toPx()
            drawArc(
                color = ringColor.copy(alpha = 0.18f),
                startAngle = -90f, sweepAngle = 360f, useCenter = false,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth, cap = androidx.compose.ui.graphics.StrokeCap.Round),
            )
            drawArc(
                color = ringColor,
                startAngle = -90f, sweepAngle = 360f * percent.coerceIn(0f, 1f), useCenter = false,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth, cap = androidx.compose.ui.graphics.StrokeCap.Round),
            )
        }
        val innerSize = size - 12.dp
        if (!photoUri.isNullOrBlank()) {
            coil.compose.AsyncImage(
                model = photoUri, contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.size(innerSize).clip(androidx.compose.foundation.shape.CircleShape),
            )
        } else {
            Box(
                Modifier.size(innerSize).clip(androidx.compose.foundation.shape.CircleShape).background(ringColor.copy(alpha = 0.15f)),
                contentAlignment = androidx.compose.ui.Alignment.Center,
            ) { Icon(Icons.Filled.Inventory2, contentDescription = null, tint = ringColor, modifier = Modifier.size(innerSize * 0.5f)) }
        }
    }
}

/** Shared "pick a dealer, then drill in" list — used by Ledger and Stock. */
@Composable
private fun DmsDealerPickerList(
    dealers: List<com.abm.erp.data.Dealer>,
    emptyText: String,
    subtitleFor: (com.abm.erp.data.Dealer) -> String,
    onPick: (com.abm.erp.data.Dealer) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(dealers, query) {
        if (query.isBlank()) dealers
        else dealers.filter { it.name.contains(query, true) || it.zone.contains(query, true) }
    }
    Column(Modifier.fillMaxSize()) {
        // v113-305 — item 11: the always-open search field here is
        // replaced by the same shared icon trigger used across DMS. The
        // full browsable list stays below it (this screen's own real
        // purpose is browsing dealers, not only searching one), so the
        // icon adds a fast search path without the field permanently
        // consuming a row.
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            com.abm.erp.core.DealerSearchIcon(
                dealers = dealers,
                onPick = onPick,
                emptyText = emptyText,
            )
            Spacer(Modifier.width(8.dp))
            Text("খুঁজে বের করুন", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(10.dp))
        if (filtered.isEmpty()) Text(emptyText, color = TextSecondary)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { d ->
                ModuleDrillRow(d.name, subtitleFor(d)) { onPick(d) }
            }
        }
    }
}

/**
 * Approve — invoice/discount approvals for dealers, inside DMS where they belong
 * (Decision 2). ApprovalRequest rows (discount/over-limit) are actioned here; the
 * invoice's own ✓ Approve lives inline in the Invoice Workspace's history list
 * (v113-80), so this section points there rather than hosting a second copy.
 */
@Composable
private fun DmsApprove(
    dealers: List<com.abm.erp.data.Dealer>,
    salesVm: com.abm.erp.ui.sales.SalesChainViewModel,
    onNavigate: (String) -> Unit,
) {
    // v113-249 — the person's own direct, confirmed finding: this drawer
    // item — reachable by any role with real approve permission
    // (PermissionManager's own canApprove = role.ordinal >= ASM.ordinal,
    // not Chairman-only) — used to show only a passive count with a note
    // pointing elsewhere, while Chairman's own separate panel had the
    // real, actionable version of the exact same thing. Now calls the
    // same shared component Chairman's panel calls — one real
    // implementation, not two.
    Column(Modifier.fillMaxSize().padding(bottom = 12.dp).verticalScroll(rememberScrollState())) {
        com.abm.erp.core.ModuleApprovalSection(
            title = "Discount / limit অনুমোদনের অপেক্ষায়",
            entityTypes = setOf("SalesInvoice"),
        )
        Spacer(Modifier.height(12.dp))
        DealerApprovalsShared()
    }
}

// v113-249 — the person's own direct request: a real, live alerts view
// inside DMS — stock shortage (against Product's own reorderThreshold,
// now finally settable via Chairman's Product dialog) and due-over-limit
// dealers, in one place. Deliberately a live, always-current computed
// list rather than a persisted notification log — this app has no
// background/scheduled job infrastructure to reliably trigger periodic
// notification-creation, so a live view can never go stale or miss an
// event the way a notification-log approach could.
@Composable
private fun DmsAlertsTab(dealers: List<com.abm.erp.data.Dealer>, onNavigate: (String) -> Unit) {
    // v113-329 — dealerId to productId for the full-screen shortage page.
    // Held here rather than routed through the nav graph so the alert list
    // stays exactly where it was on returning — the person is usually
    // working through several shortages in a row, and losing their place
    // after each one would be worse than the extra state.
    var shortageDetail by remember { mutableStateOf<Pair<String, String>?>(null) }
    shortageDetail?.let { (dId, pId) ->
        DealerStockShortageDetail(
            dealerId = dId, productId = pId,
            onBack = { shortageDetail = null },
            onNavigate = onNavigate,
        )
        return
    }
    val allStockLines by MockRepository.allDealerStockLines().collectAsState(initial = emptyList())
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val reorderByProductId = remember(products) { products.filter { it.reorderThreshold > 0 }.associate { it.id to it.reorderThreshold } }
    // v113-253 — audit catch: overLimitDealers below already correctly
    // filters !isDeleted, but this one didn't — meaning a soft-deleted
    // (cancelled) dealer's leftover stock lines could still surface a
    // "shortage" alert with their name resolving fine, noise nobody
    // needs to act on since that dealer isn't actively supplied anymore.
    val dealerNameById = remember(dealers) { dealers.filter { !it.isDeleted }.associate { it.id to it.name } }

    // v113-329 — productId added so a tapped shortage can open the real
    // per-product detail page rather than the dealer's general profile.
    data class ShortageRow(val dealerName: String, val dealerId: String, val productId: String, val productName: String, val qty: Int, val threshold: Double)
    val shortages = remember(allStockLines, reorderByProductId, dealerNameById) {
        allStockLines.mapNotNull { line ->
            val threshold = reorderByProductId[line.productId] ?: return@mapNotNull null
            if (line.qty >= threshold) return@mapNotNull null
            val dealerName = dealerNameById[line.dealerId] ?: return@mapNotNull null
            ShortageRow(dealerName, line.dealerId, line.productId, line.productName, line.qty, threshold)
        }.sortedBy { it.qty }
    }

    val overLimitDealers = remember(dealers) {
        dealers.filter { !it.isDeleted && it.creditLimit > 0 && it.dueBalance > it.creditLimit }
            .sortedByDescending { it.dueBalance - it.creditLimit }
    }

    Column(Modifier.fillMaxSize().padding(bottom = 12.dp).verticalScroll(rememberScrollState())) {
        Text("Stock Shortage (${shortages.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        Text(
            "Product-এর Reorder Threshold-এর নিচে নেমে যাওয়া dealer stock — Chairman-এর Product সেটিংসে threshold নির্ধারণ করুন।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(6.dp))
        if (shortages.isEmpty()) {
            Text("কোনো shortage নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        } else {
            shortages.forEach { s ->
                // v113-329 — the person's own instruction: tapping a
                // shortage should open a full page showing that product's
                // photo, what should be in stock, what is, and what moved
                // — "যেরকমটা আমরা এপ্রুভালের ক্ষেত্রে করছি". It used to
                // open rich_dealer_detail, which answers "who is this
                // dealer" rather than "what is short and what do I do".
                GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { shortageDetail = s.dealerId to s.productId }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(s.productName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(s.dealerName, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text("${s.qty} / ${s.threshold.toInt()}", color = DangerRed, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("Due Over Limit (${overLimitDealers.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        if (overLimitDealers.isEmpty()) {
            Text("কোনো dealer limit ছাড়ায়নি।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        } else {
            overLimitDealers.forEach { d ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { onNavigate("rich_dealer_detail/${d.id}") }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(d.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(d.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                            Text("Due ৳${"%,.0f".format(d.dueBalance)}", color = DangerRed, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            Text("Limit ৳${"%,.0f".format(d.creditLimit)}", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}
