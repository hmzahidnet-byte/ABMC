package com.abm.erp.ui.rms

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.GlassCard
import com.abm.erp.core.Space
import com.abm.erp.core.TdGrid
import com.abm.erp.core.ThGrid
import com.abm.erp.core.rememberVisibleRetailers
import com.abm.erp.data.MockRepository
import com.abm.erp.data.SalesInvoiceLineItem
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import kotlinx.coroutines.launch

/**
 * v113-80 — RMS ORDER (MEMO) WORKSPACE. Second application of the workspace contract,
 * built from the DMS Invoice Workspace reference: retailer identify (search OR QR/code
 * autofill, cascade re-checked), retailer financial context (due / credit limit /
 * memo history), product add with live stock, memo summary, create, and the
 * retailer's memo history inline. Helper actions stay dialogs; nothing navigates away.
 *
 * Engines reused untouched: `logNewOrder` (now carrying the real retailerId — see
 * MockRepository v113-80 note), `CodeRegistry.resolve`, `rememberVisibleRetailers`.
 * The old free-text RetailerTab keeps serving the legacy Sales suite; this workspace
 * is the RMS-native path where the memo is linked to a real Retailer record, which is
 * also what makes the v113-75 retailer-stock pipeline actually run.
 */
@Composable
fun RmsMemoWorkspace(onNavigate: (String) -> Unit = {}, onViewingDocumentChange: (Boolean) -> Unit = {}) {
    val retailers = rememberVisibleRetailers()
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val stockLevels by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
    val orders by MockRepository.orders.collectAsState()

    var retailerQuery by remember { mutableStateOf("") }
    var selectedRetailerId by remember { mutableStateOf<String?>(null) }
    var showAddProduct by remember { mutableStateOf(false) }
    var productQuery by remember { mutableStateOf("") }
    var cart by remember { mutableStateOf(listOf<SalesInvoiceLineItem>()) }
    var lastResult by remember { mutableStateOf<String?>(null) }
    // v113-200 — replaces the old shared top-of-page "Retailer/Product QR বা
    // কোড…" code box: same rearrangement as the Invoice workspace (v113-199)
    // — Retailer and Product add as two separate, dedicated affordances.
    var retailerPickerOpen by remember { mutableStateOf(false) }
    var productPickerOpen by remember { mutableStateOf(false) }
    // v113-162 — same "one workspace" fix as the Invoice side: Print/Share now
    // shows the same branded MemoDocumentBody inline instead of navigating away.
    var viewingOrderId by remember { mutableStateOf<String?>(null) }
    // v113-211 — same full-screen-document notification as DMS's Invoice
    // workspace (see that file's v113-211 note for the full reasoning).
    LaunchedEffect(viewingOrderId) { onViewingDocumentChange(viewingOrderId != null) }
    DisposableEffect(Unit) { onDispose { onViewingDocumentChange(false) } }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var docBusy by remember { mutableStateOf(false) }
    var qrPayloadForPdf by remember(viewingOrderId) { mutableStateOf<String?>(null) }

    val retailer = retailers.firstOrNull { it.id == selectedRetailerId }
    val retailerOrders = remember(orders, selectedRetailerId, retailer) {
        if (retailer == null) emptyList()
        // Matches by linked id where present, by name for pre-v113-80 memos that have no link.
        else orders.filter { it.retailerId == retailer.id || (it.retailerId == null && it.retailerName == retailer.name) }
            .sortedByDescending { it.loggedAt }
    }
    val total = remember(cart) { cart.sumOf { it.lineTotal } }
    val overCredit = retailer != null && retailer.creditLimit > 0 && (retailer.dueBalance + total) > retailer.creditLimit

    // v113-270 — the person's own direct instruction: Memo needs the same
    // "editable while pending, findable, resumable" shape Invoice already
    // has (v113-264). `editingOrderId` is which memo (if any) the form is
    // currently editing — non-null means the submit button below calls
    // the new real `updateRetailOrder` instead of `logNewOrder`.
    var editingOrderId by remember { mutableStateOf<String?>(null) }
    var pendingMemosExpanded by remember { mutableStateOf(false) }
    val myPendingMemos = remember(orders, retailers) {
        val visibleIds = retailers.map { it.id }.toSet()
        orders.filter { it.stage == com.abm.erp.data.OrderStage.SO_LOGGED && (it.retailerId == null || it.retailerId in visibleIds) }
            .sortedByDescending { it.loggedAt }
    }
    fun startEditing(o: com.abm.erp.data.RetailOrder) {
        editingOrderId = o.id
        selectedRetailerId = o.retailerId ?: retailers.firstOrNull { it.name == o.retailerName }?.id
        cart = o.lineItems
        lastResult = null
    }

    // v113-200 — masthead restyled to match the Invoice workspace's same
    // treatment (v113-199): plain white header with a logo mark instead of
    // an orange gradient banner.
    val memoWsCompany = remember { MockRepository.companySettings() }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().background(Color.White).padding(horizontal = Space.lg, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            com.abm.erp.core.DocLogoMark(size = 30.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(memoWsCompany.companyName.ifBlank { "ABM Corporation" }, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(if (viewingOrderId == null) "New Memo" else "Memo", color = TextSecondary, fontSize = 10.sp)
            }
            Text("MEMO", color = DarazOrange, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(HairlineBorder))

        if (viewingOrderId == null) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Spacer(Modifier.height(4.dp)) }

        // ── meta block: Memo#/Date boxed, matching the invoice workspace ──
        item {
            Row(Modifier.fillMaxWidth().background(Color.White).border(1.dp, HairlineBorder)) {
                Column(Modifier.weight(1f).padding(Space.md)) {
                    com.abm.erp.core.DocLabel("Memo No")
                    com.abm.erp.core.DocValue("Draft")
                    Spacer(Modifier.height(Space.sm))
                    com.abm.erp.core.DocLabel("Date")
                    com.abm.erp.core.DocValue(java.time.LocalDate.now().toString())
                }
            }
        }

        // ── Pending Memos — same fix as Invoice's v113-264 "Pending
        // Invoices": every SO_LOGGED memo the current user can see, right
        // here, no retailer selection needed first. Collapsed to a count
        // by default. ──
        if (myPendingMemos.isNotEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().background(Color(0xFFFFF8E8), RoundedCornerShape(8.dp)).border(1.dp, WarningAmber.copy(alpha = 0.4f), RoundedCornerShape(8.dp))) {
                    Row(
                        Modifier.fillMaxWidth().clickable { pendingMemosExpanded = !pendingMemosExpanded }.padding(Space.md),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("⏳ আপনার Pending Memo (${myPendingMemos.size}টি)", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Icon(if (pendingMemosExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, contentDescription = null, tint = TextSecondary)
                    }
                    if (pendingMemosExpanded) {
                        Column(Modifier.fillMaxWidth().padding(horizontal = Space.md)) {
                            myPendingMemos.take(20).forEach { o ->
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text("${o.orderNo} — ${o.retailerName}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, maxLines = 1)
                                        Text("৳${"%,.0f".format(o.amount)} · ${o.loggedAt.toLocalDate()}", fontSize = 10.sp, color = TextSecondary)
                                    }
                                    TextButton(onClick = { startEditing(o) }) { Text("✏ Edit", fontSize = 12.sp) }
                                    TextButton(onClick = { viewingOrderId = o.id }) { Text("দেখুন", fontSize = 12.sp) }
                                }
                                if (o.id != myPendingMemos.take(20).last().id) Divider()
                            }
                        }
                    }
                }
            }
        }

        // ── Retailer — bar + boxed content, dedicated Add + Scan buttons ──
        item {
            Column(Modifier.fillMaxWidth()) {
                com.abm.erp.core.DocBar("Retailer")
                Column(Modifier.fillMaxWidth().background(Color.White).border(1.dp, HairlineBorder).padding(Space.md)) {
                    if (retailer == null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(onClick = { retailerPickerOpen = !retailerPickerOpen }) {
                                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Retailer Add")
                            }
                            Spacer(Modifier.width(8.dp))
                            IconButton(onClick = { onNavigate("universal_scanner") }) {
                                Icon(Icons.Filled.QrCodeScanner, contentDescription = "Scan", tint = TextPrimary)
                            }
                        }
                        if (retailerPickerOpen) {
                            Spacer(Modifier.height(Space.sm))
                            OutlinedTextField(
                                value = retailerQuery, onValueChange = { retailerQuery = it },
                                placeholder = { Text("নাম/market দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                            )
                            val matches = remember(retailers, retailerQuery) {
                                if (retailerQuery.isBlank()) emptyList()
                                else retailers.filter { it.name.contains(retailerQuery, true) || it.market.orEmpty().contains(retailerQuery, true) }.take(5)
                            }
                            matches.forEach { rt ->
                                Text(
                                    "${rt.name} — ${rt.market.orEmpty()}",
                                    modifier = Modifier.fillMaxWidth().clickable { selectedRetailerId = rt.id; retailerQuery = ""; retailerPickerOpen = false }.padding(vertical = 8.dp),
                                    color = TextPrimary,
                                )
                            }
                            if (retailerQuery.isNotBlank() && matches.isEmpty()) {
                                Text("আপনার এলাকায় মেলেনি।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                com.abm.erp.core.DocValue(retailer.name)
                                Text(retailer.market.orEmpty(), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                            TextButton(onClick = { selectedRetailerId = null }) { Text("বদলান") }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Outstanding Due", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("৳${"%,.0f".format(retailer.dueBalance)}", fontWeight = FontWeight.Bold, color = if (retailer.dueBalance > 0) WarningAmber else SuccessGreen)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Credit Limit", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("৳${"%,.0f".format(retailer.creditLimit)}", color = TextPrimary)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Memo history", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${retailerOrders.size} টি · ৳${"%,.0f".format(retailerOrders.sumOf { it.amount })}", color = TextPrimary)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { onNavigate("statement/RETAILER/${retailer.id}") }) { Text("Full Ledger →") }
                            TextButton(onClick = { onNavigate("retailer_stock/${retailer.id}") }) { Text("Stock →") }
                        }
                        // v113-142 — retailer location inside the memo workspace. Unlike
                        // Dealer, Retailer genuinely HAS lat/lng, so this gives real
                        // turn-by-turn navigation when a GPS fix was captured, and falls
                        // back to an address search when it wasn't. Same proven intent
                        // chain as DealersScreen (Maps → geo: → honest Toast).
                        val memoNavContext = androidx.compose.ui.platform.LocalContext.current
                        val hasGps = retailer.lat != null && retailer.lng != null
                        if (hasGps || retailer.address.isNotBlank()) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Text(
                                    "📍 " + if (hasGps) "GPS tagged · ${retailer.address.ifBlank { retailer.market.orEmpty() }}" else retailer.address,
                                    style = MaterialTheme.typography.labelSmall, color = TextSecondary, modifier = Modifier.weight(1f),
                                )
                                // v113-321 — one shared location helper app-wide.
                                TextButton(onClick = {
                                    com.abm.erp.core.openMapsFor(memoNavContext, retailer.lat, retailer.lng, retailer.address)
                                }) { Text(if (hasGps) "Navigate" else "Map") }
                            }
                        }
                    }
                }
            }
        }

        // ── item table — bar + real bordered grid; "+ Add Product" is the
        // table's own last row (same pattern as the Invoice workspace). ──
        item {
            Column(Modifier.fillMaxWidth()) {
                com.abm.erp.core.DocBar("Memo Items")
                Column(Modifier.fillMaxWidth().border(1.dp, HairlineBorder)) {
                    Row(Modifier.fillMaxWidth().background(DarazOrange)) {
                        ThGrid("#", 0.08f); ThGrid("Item", 0.34f); ThGrid("Qty", 0.20f, androidx.compose.ui.text.style.TextAlign.End)
                        ThGrid("Rate", 0.19f, androidx.compose.ui.text.style.TextAlign.End); ThGrid("Amount", 0.19f, androidx.compose.ui.text.style.TextAlign.End)
                    }
                    cart.forEachIndexed { idx, line ->
                        Row(
                            Modifier.fillMaxWidth().background(if (idx % 2 == 1) Color(0xFFF7F8FA) else Color.White),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            TdGrid("%02d".format(idx + 1), 0.08f)
                            Column(Modifier.weight(0.34f).border(0.5.dp, HairlineBorder).padding(horizontal = 6.dp, vertical = 7.dp)) {
                                Text(line.name, color = TextPrimary, fontSize = 11.sp, maxLines = 1)
                            }
                            Row(Modifier.weight(0.20f).border(0.5.dp, HairlineBorder).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                                IconButton(onClick = { if (line.qty > 1) cart = cart.toMutableList().also { it[idx] = line.copy(qty = line.qty - 1) } }, modifier = Modifier.size(20.dp)) { Icon(Icons.Filled.RemoveCircleOutline, null, tint = TextSecondary, modifier = Modifier.size(14.dp)) }
                                Text("${line.qty}", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                                IconButton(onClick = { cart = cart.toMutableList().also { it[idx] = line.copy(qty = line.qty + 1) } }, modifier = Modifier.size(20.dp)) { Icon(Icons.Filled.AddCircleOutline, null, tint = TextSecondary, modifier = Modifier.size(14.dp)) }
                            }
                            TdGrid("৳${"%,.0f".format(line.unitPrice)}", 0.19f, androidx.compose.ui.text.style.TextAlign.End)
                            Row(Modifier.weight(0.19f).border(0.5.dp, HairlineBorder).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                                Text("৳${"%,.0f".format(line.lineTotal)}", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                IconButton(onClick = { cart = cart.filterIndexed { i, _ -> i != idx } }, modifier = Modifier.size(18.dp)) { Icon(Icons.Filled.Close, null, tint = DangerRed, modifier = Modifier.size(12.dp)) }
                            }
                        }
                    }
                    if (!productPickerOpen) {
                        TextButton(onClick = { productPickerOpen = true }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Add Product")
                        }
                    } else {
                        Column(Modifier.fillMaxWidth().background(Color(0xFFF7F8FA)).padding(Space.sm)) {
                            OutlinedTextField(
                                value = productQuery, onValueChange = { productQuery = it },
                                placeholder = { Text("Product নাম/SKU…") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                            )
                            val productMatches = remember(products, productQuery) {
                                products.filter {
                                    !it.isDeleted && it.isActive &&
                                        (productQuery.isBlank() || it.name.contains(productQuery, true) || it.sku.contains(productQuery, true))
                                }.take(6)
                            }
                            productMatches.forEach { p ->
                                val onHand = stockLevels.filter { it.productId == p.id }.sumOf { it.quantityOnHand }
                                Row(
                                    Modifier.fillMaxWidth().clickable {
                                        cart = cart + SalesInvoiceLineItem(p.id, p.name, p.unit, 1, p.defaultUnitPrice)
                                        productPickerOpen = false; productQuery = ""
                                    }.padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Column {
                                        Text(p.name, color = TextPrimary)
                                        Text("৳${"%,.0f".format(p.defaultUnitPrice)}/${p.unit} · stock ${"%,.0f".format(onHand)}", style = MaterialTheme.typography.labelSmall, color = if (onHand <= 0) DangerRed else TextSecondary)
                                    }
                                    Icon(Icons.Filled.AddCircleOutline, contentDescription = "Add", tint = TextSecondary)
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                // v113-143 — shown only if they genuinely hold inv-CREATE rights, unchanged from before.
                                if (com.abm.erp.data.PermissionManager.canCurrentUser("inv", com.abm.erp.data.PermissionAction.CREATE)) {
                                    TextButton(onClick = { showAddProduct = true }) { Text("+ New Product") }
                                }
                                TextButton(onClick = { productPickerOpen = false; productQuery = "" }) { Text("বন্ধ করুন") }
                            }
                        }
                    }
                }
            }
        }

        // ── summary — boxed rows + ledger rule above Total (no tax/discount
        // field — memo's own `total` is a plain sum, matching the real
        // `logNewOrder` scope, unchanged) ──
        item {
            Column(Modifier.fillMaxWidth().background(Color.White).border(1.dp, HairlineBorder).padding(Space.md)) {
                Text("Memo Summary", fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(Space.sm))
                Box(Modifier.fillMaxWidth().height(1.dp).background(TextSecondary))
                Spacer(Modifier.height(Space.xs))
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Total", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("৳${"%,.0f".format(total)}", color = DarazOrange, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                }
                if (overCredit) {
                    Text(
                        "⚠ Credit limit ছাড়িয়ে যাবে — TSM verify ধাপে এটি দেখা যাবে।",
                        color = WarningAmber, style = MaterialTheme.typography.labelSmall,
                    )
                }
                Spacer(Modifier.height(Space.sm))
                if (editingOrderId != null) {
                    Text("✏ সম্পাদনা করছেন — Memo জমা দিলে আগের তথ্য বদলে যাবে", style = MaterialTheme.typography.labelSmall, color = WarningAmber, modifier = Modifier.padding(bottom = 4.dp))
                }
                Button(
                    onClick = {
                        val rt = retailer ?: return@Button
                        lastResult = null
                        val editing = editingOrderId
                        val ok = if (editing != null) {
                            MockRepository.updateRetailOrder(
                                orderId = editing, retailerName = rt.name, items = cart.joinToString(", ") { "${it.name} x${it.qty}" },
                                amount = total, zone = rt.market.orEmpty().ifBlank { "N/A" }, lineItems = cart,
                                onRejected = { reason -> lastResult = "✖ $reason" },
                            )
                        } else {
                            MockRepository.logNewOrder(
                                retailerName = rt.name, items = cart.joinToString(", ") { "${it.name} x${it.qty}" },
                                amount = total, zone = rt.market.orEmpty().ifBlank { "N/A" },
                                lineItems = cart, retailerId = rt.id,
                                onRejected = { reason -> lastResult = "✖ $reason" },
                            )
                        }
                        if (ok) {
                            lastResult = if (editing != null) "✔ Memo আপডেট হয়েছে — TSM verify করলে dealer-এ route হবে।" else "✔ Memo তৈরি হয়েছে — TSM verify করলে dealer-এ route হবে।"
                            cart = emptyList()
                            editingOrderId = null
                        } else if (lastResult == null) {
                            lastResult = "✖ Memo তৈরি/আপডেট হয়নি — আবার চেষ্টা করুন।"
                        }
                    },
                    enabled = retailer != null && cart.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (editingOrderId != null) "Memo আপডেট করুন" else "Memo তৈরি করুন") }
                if (editingOrderId != null) {
                    TextButton(onClick = { editingOrderId = null; cart = emptyList() }, modifier = Modifier.fillMaxWidth()) { Text("সম্পাদনা বাতিল করুন") }
                }
                lastResult?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = if (it.startsWith("✔")) SuccessGreen else DangerRed) }
            }
        }

        if (retailerOrders.isNotEmpty()) {
            item { Text("এই retailer-এর Memo (${retailerOrders.size})", fontWeight = FontWeight.SemiBold, color = TextPrimary) }
            items(retailerOrders.take(10), key = { it.id }) { o ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(o.orderNo, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        com.abm.erp.core.StatusPill(o.stage.name)
                    }
                    Text("৳${"%,.0f".format(o.amount)} · ${o.loggedAt.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(o.items, style = MaterialTheme.typography.labelSmall, color = TextSecondary, maxLines = 2)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        // v113-270 — same real Edit path as the Pending
                        // Memos section above, shown here too for a memo
                        // reached this way (already had a retailer
                        // selected) — only while still SO_LOGGED, matching
                        // updateRetailOrder's own real one-way-door check.
                        if (o.stage == com.abm.erp.data.OrderStage.SO_LOGGED) {
                            TextButton(onClick = { startEditing(o) }) { Text("✏ Edit") }
                        }
                        TextButton(onClick = { viewingOrderId = o.id }) { Text("Print/Share") }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
        } else {
            // ── view mode: same branded document MemoDocumentScreen uses,
            // rendered inline — no navigation, no separate screen. ──
            val viewedOrder = orders.firstOrNull { it.id == viewingOrderId }
            if (viewedOrder == null) {
                Column(Modifier.weight(1f).fillMaxWidth().padding(Space.lg)) {
                    Text("এই মেমোটি পাওয়া যায়নি।", color = TextSecondary)
                    TextButton(onClick = { viewingOrderId = null }) { Text("← ফিরে যান") }
                }
            } else {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(Space.md)) {
                    com.abm.erp.ui.memo.MemoDocumentBody(order = viewedOrder, onQrPayloadReady = { qrPayloadForPdf = it })
                    Spacer(Modifier.height(Space.lg))
                }
                Row(
                    Modifier.fillMaxWidth().padding(Space.md),
                    horizontalArrangement = Arrangement.spacedBy(Space.sm),
                ) {
                    Box(Modifier.weight(1f)) {
                        com.abm.erp.core.SecondaryButton("← New Memo", onClick = { viewingOrderId = null })
                    }
                    Box(Modifier.weight(1f)) {
                        com.abm.erp.core.SecondaryButton("Share", onClick = {
                            runCatching {
                                val summary = "Memo ${viewedOrder.orderNo}\n${viewedOrder.retailerName}\nTotal: ৳${"%,.0f".format(viewedOrder.amount)}\nStage: ${viewedOrder.stage.name}"
                                // v113-335 — the document itself, shared as an image.
                                // This is the Share button actually tapped when sending an
                                // invoice or memo to a dealer, so it mattered most.
                                com.abm.erp.core.shareTextSummary(context, "Share memo", summary)
                            }.onFailure {
                                android.widget.Toast.makeText(context, "Share করার মতো app পাওয়া যায়নি।", android.widget.Toast.LENGTH_LONG).show()
                            }
                        }, icon = Icons.Filled.Share)
                    }
                    Box(Modifier.weight(1.2f)) {
                        com.abm.erp.core.PrimaryButton(
                            text = if (docBusy) "…" else "Print / PDF",
                            icon = Icons.Filled.Print,
                            loading = docBusy,
                            onClick = {
                                docBusy = true
                                scope.launch {
                                    runCatching {
                                        // Same reuse-or-warn QR logic as MemoDocumentScreen — see v113-161.
                                        val payload = qrPayloadForPdf ?: run {
                                            val alreadyExists = com.abm.erp.data.QrRegistry.activeFor("RetailOrder", viewedOrder.id) != null
                                            if (alreadyExists) null
                                            else com.abm.erp.data.QrRegistry.issue("RetailOrder", viewedOrder.id)?.also { qrPayloadForPdf = it }
                                        }
                                        if (payload == null) {
                                            android.widget.Toast.makeText(
                                                context,
                                                "এই মেমোর QR আগেই issue করা আছে — উপরে \"Reissue QR\"-এ ট্যাপ করে নতুন QR নিন, তারপর Print করুন।",
                                                android.widget.Toast.LENGTH_LONG,
                                            ).show()
                                        } else {
                                            val file = com.abm.erp.core.exportRetailOrderPdf(context, viewedOrder, payload)
                                            val uri = androidx.core.content.FileProvider.getUriForFile(
                                                context, "${context.packageName}.fileprovider", file,
                                            )
                                            val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                                type = "application/pdf"
                                                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(android.content.Intent.createChooser(i, "Memo PDF"))
                                        }
                                    }.onFailure { e ->
                                        com.abm.erp.config.AppLog.w("RmsMemoWorkspace", "PDF export/share failed", e)
                                        val msg = if (com.abm.erp.config.AppEnvironment.isDebugOrStaging) "PDF তৈরি করা যায়নি: ${e.javaClass.simpleName} — ${e.message}" else "PDF তৈরি করা যায়নি।"
                                        android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()
                                    }
                                    docBusy = false
                                }
                            },
                        )
                    }
                }
            }
        }
    }

    // v113-143 — real add-product dialog, same engine and same real rejection
    // surfacing as the invoice workspace's version. Placed after the LazyColumn
    // (a dialog, never a navigation step — workspace contract).
    if (showAddProduct) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showAddProduct = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var pName by remember { mutableStateOf("") }
                var pSku by remember { mutableStateOf("") }
                var pUnit by remember { mutableStateOf("pcs") }
                var pCategory by remember { mutableStateOf("") }
                var pPrice by remember { mutableStateOf("") }
                var pError by remember { mutableStateOf<String?>(null) }
                Column(Modifier.padding(16.dp)) {
                    Text("নতুন Product", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("যোগ করার সাথে সাথেই এই memo-তে ব্যবহার করা যাবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    pError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = pName, onValueChange = { pName = it }, label = { Text("নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = pSku, onValueChange = { pSku = it }, label = { Text("SKU") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = pUnit, onValueChange = { pUnit = it }, label = { Text("Unit") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = pPrice, onValueChange = { pPrice = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("দাম") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = pCategory, onValueChange = { pCategory = it }, label = { Text("Category") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            pError = null
                            com.abm.erp.data.InventoryRepository.addProduct(
                                sku = pSku.trim(), name = pName.trim(), unit = pUnit.trim().ifBlank { "pcs" },
                                category = pCategory.trim(), reorderThreshold = 0.0,
                                defaultUnitPrice = pPrice.toDoubleOrNull() ?: 0.0,
                                onRejected = { r -> pError = r },
                                onCreated = { showAddProduct = false },
                            )
                        },
                        enabled = pName.isNotBlank() && pSku.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("যোগ করুন") }
                }
            }
        }
    }
}
