package com.abm.erp.ui.dms

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * v113-329 — the person's own description of what a stock-shortage alert
 * should do: "ওইখানে যখন ক্লিক করবো তখন তার স্টক বাড়াতে তো আমার শো
 * করতে হবে। এটার জন্য তো আলাদা একটা পেজ আসবে। সেই ডিলারের কোন
 * প্রোডাক্টটা শর্টেজ আছে, ওই প্রোডাক্টের ছবি, পাশে ওই প্রোডাক্ট কত
 * পিস থাকার কথা, কত পিস আছে, কত পিস গেল এরকম তো পুরো স্ক্রিন জুড়ে একটা
 * ইউআই আসবে তাই না? যেরকমটা আমরা এপ্রুভালের ক্ষেত্রে করছি।"
 *
 * Tapping a shortage previously opened `rich_dealer_detail` — the
 * dealer's general profile. That answers "who is this dealer", not "what
 * is short and what do I do about it", so the person still had to go
 * hunting for the actual numbers. This is the dedicated page: the one
 * product, its real photo, what should be there, what is there, what
 * moved, and the two real actions that resolve it.
 *
 * Every figure here is read from the same sources the alert itself uses
 * — the dealer's own stock line, the product's own reorder threshold,
 * and real invoices/orders for movement. Nothing is estimated.
 */
@Composable
fun DealerStockShortageDetail(
    dealerId: String,
    productId: String,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit = {},
) {
    val dealers by MockRepository.dealers.collectAsState()
    val products by InventoryRepository.products.collectAsState()
    val stockLines by MockRepository.dealerStockLinesFor(dealerId).collectAsState(initial = emptyList())
    val allInvoices by MockRepository.salesInvoices.collectAsState()
    val allOrders by MockRepository.orders.collectAsState()

    val dealer = dealers.firstOrNull { it.id == dealerId }
    val product = products.firstOrNull { it.id == productId }
    val line = stockLines.firstOrNull { it.productId == productId }
    var countOpen by remember { mutableStateOf(false) }

    if (dealer == null || product == null) {
        // Honest, not a blank screen: a cancelled dealer or a deleted
        // product can genuinely leave an alert pointing at nothing.
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(60.dp))
            Text("এই তথ্যটি আর নেই — dealer বা product সরিয়ে ফেলা হয়েছে।", color = TextSecondary)
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onBack) { Text("← ফিরে যান") }
        }
        return
    }

    val onHand = line?.qty ?: 0
    val shouldHave = product.reorderThreshold.toInt()
    val gap = (shouldHave - onHand).coerceAtLeast(0)

    // "কত পিস গেল" — real movement over the last 90 days, from the same
    // invoice/order records the rest of the app posts against.
    val cutoff = java.time.LocalDate.now().minusDays(90)
    val received = remember(allInvoices, dealerId, productId) {
        allInvoices.filter { !it.isDeleted && it.dealerId == dealerId && it.createdAt.toLocalDate().isAfter(cutoff) }
            .flatMap { it.lineItems }.filter { it.productId == productId }.sumOf { it.qty }
    }
    // RetailOrder identifies its dealer by `routedDealerId` (set when the
    // memo is routed) and timestamps with `loggedAt` — checked against the
    // real model rather than assumed, since the invoice side uses
    // different field names for the same two ideas.
    val sold = remember(allOrders, dealerId, productId) {
        allOrders.filter { it.routedDealerId == dealerId && it.loggedAt.toLocalDate().isAfter(cutoff) }
            .flatMap { it.lineItems }.filter { it.productId == productId }.sumOf { it.qty }
    }

    if (countOpen) {
        com.abm.erp.core.DealerStockDeclarationSheet(
            dealerId = dealerId, dealerName = dealer.name,
            reasonNote = "Shortage alert থেকে গণনা",
            onDismiss = { countOpen = false },
        )
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        TextButton(onClick = onBack) { Text("← ফিরে যান") }
        Spacer(Modifier.height(4.dp))

        // ── the product itself, with its real photo ──
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (!product.photoUri.isNullOrBlank()) {
                coil.compose.AsyncImage(
                    model = product.photoUri, contentDescription = product.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(84.dp).clip(RoundedCornerShape(14.dp))
                        .border(1.dp, HairlineBorder, RoundedCornerShape(14.dp)),
                )
            } else {
                Box(
                    Modifier.size(84.dp).clip(RoundedCornerShape(14.dp))
                        .background(Brush.linearGradient(listOf(WarningAmber.copy(alpha = 0.25f), WarningAmber.copy(alpha = 0.08f)))),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Inventory2, null, tint = WarningAmber, modifier = Modifier.size(34.dp)) }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(product.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimary)
                Text("${product.sku} · ${product.unit}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Spacer(Modifier.height(4.dp))
                Text(dealer.name, fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 13.sp)
                Text(dealer.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
        }

        Spacer(Modifier.height(18.dp))

        // ── the three numbers, side by side, biggest first ──
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ShortageStat("কত পিস আছে", onHand.toString(), DangerRed, Modifier.weight(1f))
            ShortageStat("কত থাকার কথা", shouldHave.toString(), TextPrimary, Modifier.weight(1f))
            ShortageStat("ঘাটতি", gap.toString(), WarningAmber, Modifier.weight(1f))
        }

        Spacer(Modifier.height(14.dp))
        Surface(
            shape = RoundedCornerShape(12.dp), color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(14.dp)) {
                Text("গত ৯০ দিনের চলাচল", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("এসেছে (invoice)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text("$received ${product.unit}", color = SuccessGreen, fontWeight = FontWeight.Bold)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("গেছে (retailer memo)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text("$sold ${product.unit}", color = WarningAmber, fontWeight = FontWeight.Bold)
                }
                // Named plainly rather than hidden: where no Sales Officer
                // records memos, "গেছে" will read 0 even though stock really
                // moved. Saying so is what makes the count button below the
                // obvious next step instead of a mystery.
                if (sold == 0 && onHand < received) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "⚠ memo-তে কোনো বিক্রি নেই অথচ stock কমেছে — Sales Officer না থাকলে নিচে গুনে হিসাব দিন।",
                        style = MaterialTheme.typography.labelSmall, color = WarningAmber,
                    )
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        // ── the two things you can actually do about it ──
        Button(
            onClick = { onNavigate("dms?key=invoice") },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("🧾 এই dealer-কে নতুন invoice করুন") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = { countOpen = true },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("📦 গুনে হিসাব হালনাগাদ করুন") }
        Spacer(Modifier.height(8.dp))
        TextButton(
            onClick = { onNavigate("rich_dealer_detail/$dealerId") },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("এই dealer-এর পুরো প্রোফাইল →", fontSize = 12.sp) }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ShortageStat(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(12.dp), color = accent.copy(alpha = 0.07f),
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = 0.35f)),
        modifier = modifier,
    ) {
        Column(Modifier.padding(vertical = 12.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = accent)
            Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
    }
}
