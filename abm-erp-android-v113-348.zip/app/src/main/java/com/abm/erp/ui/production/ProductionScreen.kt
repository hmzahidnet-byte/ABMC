package com.abm.erp.ui.production

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.ui.window.Dialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.GlassCard
import com.abm.erp.core.SubModuleGrid
import com.abm.erp.core.SubModuleItem
import com.abm.erp.core.BackToSubMenuLink
import kotlinx.coroutines.launch
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

class ProductionViewModel : ViewModel() {
    val lots = MockRepository.lots
    val batches = MockRepository.batches
    fun movingAverageCost(material: String) = MockRepository.movingAverageCost(material)
    suspend fun receiveGatepass(batchId: String) = MockRepository.receiveGatepass(batchId)

    // ---- Module 2: Manufacturing & Production ----
    val boms = MockRepository.billOfMaterials
    val productionOrders = MockRepository.productionOrders
    val qualityChecks = MockRepository.qualityChecks
    val productionLosses = MockRepository.productionLosses
    val machineLogs = MockRepository.machineLogs
    suspend fun createBom(name: String, lines: List<com.abm.erp.data.BomLine>, laborCost: Double, overheadCost: Double) =
        MockRepository.createBom(name, lines, laborCost, overheadCost)
    fun estimatedUnitCost(bom: com.abm.erp.data.BillOfMaterials) = MockRepository.estimatedUnitCost(bom)
    suspend fun createProductionOrder(bomId: String, productName: String, targetQty: Double, scheduledDate: java.time.LocalDateTime) =
        MockRepository.createProductionOrder(bomId, productName, targetQty, scheduledDate)
    suspend fun updateProductionOrderStatus(id: String, status: String) = MockRepository.updateProductionOrderStatus(id, status)
    suspend fun recordQualityCheck(batchId: String, result: String, notes: String) = MockRepository.recordQualityCheck(batchId, result, notes)
    suspend fun recordProductionLoss(batchId: String, qtyLost: Double, reason: String) = MockRepository.recordProductionLoss(batchId, qtyLost, reason)
    fun recordMachineLog(machineName: String, batchId: String?, hours: Double, notes: String) = MockRepository.recordMachineLog(machineName, batchId, hours, notes)
}

@Composable
fun ProductionScreen(startTab: Int? = null, onBack: () -> Unit = {}, onNavigate: (String) -> Unit = {}, vm: ProductionViewModel = viewModel()) {
    var tab by remember { mutableStateOf<Int?>(startTab) }
    val subItems = listOf(
        SubModuleItem("materials", "Materials", "🧱", 0xFFFFB020, 0xFFE08A00, Icons.Filled.Layers),
        SubModuleItem("batches", "Batches", "⚙️", 0xFF4E9CFF, 0xFF2E6FE0, Icons.Filled.Settings),
        SubModuleItem("hrm", "Factory HRM", "👷", 0xFF3DDC97, 0xFF1FA972, Icons.Filled.Engineering),
        SubModuleItem("bom", "Bill of Materials", "📐", 0xFF8A6DFF, 0xFF5B3FE0, Icons.Filled.Architecture),
        SubModuleItem("porder", "Production Orders", "🏭", 0xFF3FA9F5, 0xFF1D78C7, Icons.Filled.Factory),
        SubModuleItem("qc", "Quality Control", "✅", 0xFF3DDC97, 0xFF1FA972, Icons.Filled.VerifiedUser),
        SubModuleItem("ploss", "Production Loss", "📉", 0xFFFF5252, 0xFFC62828, Icons.Filled.TrendingDown),
        SubModuleItem("machine", "Machine Utilization", "🛠️", 0xFFFFB300, 0xFFE08600, Icons.Filled.Build),
        // v113-216 — Chairman/office observation view for the person's own
        // confirmed carton-QR decision: real per-carton tracking through
        // manufacturing -> warehouse -> dispatch -> delivery. Field staff
        // update status by scanning (UniversalScannerScreen's
        // CartonScanDetail); this tab is the read-side, "which batch/lot
        // is where right now" — matching the person's explicit "only the
        // office/Chairman panel observes this" framing.
        SubModuleItem("cartons", "Cartons", "📦", 0xFF6B8AFA, 0xFF3E5FD8, Icons.Filled.Inventory),
    )
    // ---- Mini-dashboard data (Enterprise Workspace redesign) ----
    val ordersForMini by vm.productionOrders.collectAsState()
    val qcForMini by vm.qualityChecks.collectAsState()
    val machineLogsForMini by vm.machineLogs.collectAsState()
    val today = java.time.LocalDate.now()
    val todaysBatches = ordersForMini.count { it.scheduledDate.toLocalDate() == today }
    val runningBatches = ordersForMini.count { it.status == "IN_PROGRESS" }
    val checkedBatchIds = qcForMini.map { it.batchId }.toSet()
    val qcPending = ordersForMini.count { (it.status == "IN_PROGRESS" || it.status == "COMPLETED") && it.id !in checkedBatchIds }
    val finishedGoods = ordersForMini.count { it.status == "COMPLETED" }
    val activeMachines = machineLogsForMini.filter { it.recordedAt.toLocalDate() == today }.map { it.machineName }.distinct().size

    Column(Modifier.fillMaxSize()) {
        if (startTab == null) {
        com.abm.erp.core.ModuleWorkspaceHeader("Factory Production Wing", "⚙️", 0xFFE85D4A, 0xFFC03A2B, iconVector = Icons.Filled.Factory, miniDashboard = {
            com.abm.erp.core.ModuleStat("Today's Batch", "$todaysBatches", TextPrimary)
            com.abm.erp.core.ModuleStat("Running Batch", "$runningBatches", ElectricCyan)
            com.abm.erp.core.ModuleStat("QC Pending", "$qcPending", if (qcPending > 0) WarningAmber else SuccessGreen) { tab = 5 }
            com.abm.erp.core.ModuleStat("Finished Goods", "$finishedGoods", SuccessGreen)
            com.abm.erp.core.ModuleStat("Machine Status", "$activeMachines active", TextPrimary)
        }, quickActions = {
            AssistChip(onClick = { tab = 4 }, label = { Text("+ New Plan") })
            AssistChip(onClick = { tab = 1 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.PlayArrow, null, Modifier.size(16.dp)) }, label = { Text("Start Batch") })
            AssistChip(onClick = { tab = 5 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.FactCheck, null, Modifier.size(16.dp)) }, label = { Text("QC") })
            AssistChip(onClick = { onNavigate("production_warehouse") }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.LocalShipping, null, Modifier.size(16.dp)) }, label = { Text("Transfer") })
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("ProductionOrder", "QualityCheck", "ProductionLoss", "MachineLog"))
        })
        } else {
            val taskTitle = subItems.firstOrNull { it.key == when (tab) { 0 -> "materials"; 1 -> "batches"; 2 -> "hrm"; 3 -> "bom"; 4 -> "porder"; 5 -> "qc"; 6 -> "ploss"; 7 -> "machine"; else -> "cartons" } }?.label ?: "Production"
            com.abm.erp.core.TaskHeader(taskTitle, 0xFFE85D4A, 0xFFC03A2B, onBack = onBack, iconVector = Icons.Filled.Factory)
        }
        Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Isolated from marketing operations", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        if (tab == null) {
            SubModuleGrid(subItems) { key -> tab = when (key) { "materials" -> 0; "batches" -> 1; "hrm" -> 2; "bom" -> 3; "porder" -> 4; "qc" -> 5; "ploss" -> 6; "machine" -> 7; else -> 8 } }
        } else {
            if (startTab == null) BackToSubMenuLink(onClick = { tab = null })
            when (tab) {
                0 -> MaterialsTab(vm)
                1 -> BatchesTab(vm)
                2 -> FactoryHrmTab()
                3 -> BomTab(vm)
                4 -> ProductionOrdersTab(vm)
                5 -> QualityControlTab(vm)
                6 -> ProductionLossTab(vm)
                7 -> MachineUtilizationTab(vm)
                else -> CartonsTrackingTab()
            }
        }
        }
    }
}

@Composable
private fun MaterialsTab(vm: ProductionViewModel) {
    val lots by vm.lots.collectAsState()
    val materials = lots.map { it.materialName }.distinct()
    val boms by vm.boms.collectAsState()
    val orders by vm.productionOrders.collectAsState()
    var lotQuery by remember { mutableStateOf("") }
    val filteredLots = remember(lots, lotQuery) { if (lotQuery.isBlank()) lots else lots.filter { it.materialName.contains(lotQuery, ignoreCase = true) } }
    val pendingOrders = orders.filter { it.status == "PLANNED" || it.status == "IN_PROGRESS" || it.status == "PAUSED" || it.status == "QUALITY_HOLD" }
    val requirementSummary = remember(boms, pendingOrders) {
        pendingOrders.mapNotNull { order -> boms.firstOrNull { it.id == order.bomId }?.let { order to it } }
            .flatMap { (order, bom) -> bom.lines.map { line -> line.rawMaterialName to (line.qtyPerUnit * order.targetQty) } }
            .groupBy { it.first }
            .mapValues { (_, list) -> list.sumOf { it.second } }
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (requirementSummary.isNotEmpty()) {
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Material Requirement Summary (pending/running orders)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    requirementSummary.forEach { (material, qty) ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(material, style = MaterialTheme.typography.bodySmall)
                            Text("${"%.1f".format(qty)}", style = MaterialTheme.typography.bodySmall, color = WarningAmber)
                        }
                    }
                }
            }
        }
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Moving average cost", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                materials.forEach { m ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(m, style = MaterialTheme.typography.bodyLarge)
                        Text("৳${"%.2f".format(vm.movingAverageCost(m))}/kg", color = ElectricCyan, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        item { Text("Purchase lots", style = MaterialTheme.typography.titleMedium) }
        item {
            OutlinedTextField(value = lotQuery, onValueChange = { lotQuery = it }, placeholder = { Text("Material নাম দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        if (filteredLots.isEmpty()) {
            item { com.abm.erp.core.WorkspaceEmptyState("কোনো Purchase Lot পাওয়া যায়নি।", "🧱") }
        }
        items(filteredLots) { lot ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("${lot.materialName} — ${lot.qtyKg}kg", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text("Cost ৳${lot.costPerKg}/kg · purchased ${lot.purchasedOn}", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun BatchesTab(vm: ProductionViewModel) {
    val batches by vm.batches.collectAsState()
    var cycleFilter by remember { mutableStateOf<String?>(null) }
    val cycleTypes = remember(batches) { batches.map { it.cycleType }.distinct() }
    val filteredBatches = batches.filter { cycleFilter == null || it.cycleType == cycleFilter }
    val gatepassScope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        if (cycleTypes.size > 1) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = cycleFilter == null, onClick = { cycleFilter = null }, label = { Text("সব") })
                cycleTypes.forEach { c -> FilterChip(selected = cycleFilter == c, onClick = { cycleFilter = c }, label = { Text(c) }) }
            }
            Spacer(Modifier.height(8.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (filteredBatches.isEmpty()) {
                item { com.abm.erp.core.WorkspaceEmptyState("কোনো Batch পাওয়া যায়নি।", "⚙️") }
            }
            items(filteredBatches) { b ->
                val yieldPct = (b.outputKg / b.inputKg) * 100
                val yieldColor = if (yieldPct >= 85) SuccessGreen else if (yieldPct >= 70) WarningAmber else DangerRed
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${b.id} · ${b.cycleType}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${"%.0f".format(yieldPct)}%", fontWeight = FontWeight.Bold, color = yieldColor)
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "ProductionBatch", entityId = b.id, entityLabel = "${b.id} — ${b.cycleType}",
                            shareText = "Batch ${b.id} (${b.cycleType})\nInput: ${b.inputKg}kg → Output: ${b.outputKg}kg\nYield: ${"%.0f".format(yieldPct)}%",
                            csvHeader = "BatchId,CycleType,InputKg,OutputKg,YieldPct", csvRow = com.abm.erp.core.toCsvRow(b.id, b.cycleType, b.inputKg, b.outputKg, "%.0f".format(yieldPct)),
                        )
                    }
                }
                Text("Input ${b.inputKg}kg → Output ${b.outputKg}kg", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(6.dp))
                com.abm.erp.core.YieldBar(yieldPct)
                Spacer(Modifier.height(8.dp))
                if (b.gatepassReceived) {
                    Text("✓ Gatepass received by Central Warehouse Incharge", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                } else {
                    Button(onClick = { gatepassScope.launch { vm.receiveGatepass(b.id) } }, colors = ButtonDefaults.buttonColors(containerColor = DeepIndigo)) {
                        Text("Tap \"Receive\" — release from production")
                    }
                }
            }
        }
    }
    }
}

@Composable
private fun FactoryHrmTab() {
    // Previously this tab displayed three hardcoded rows ("Laborer 12/27/33") with fixed
    // pass/fail flags. It read no repository data at all, so it looked like a working
    // attendance screen while reporting nothing real — worse than showing nothing, because
    // it invites trust it cannot support. Replaced with the actual factory workforce.
    val profiles by MockRepository.employeeProfiles.collectAsState()
    val factoryStaff = remember(profiles) {
        profiles.filter { it.employeeType == com.abm.erp.data.EmployeeType.FACTORY && !it.isDeleted }
    }
    // v113-176 — person's request: Factory HR should be as functional as main
    // HR (payroll, leave), not just a read-only attendance viewer. Reuses the
    // exact same data/composables main HR uses — PayrollLine already had
    // overtimeMinutes/overtimePay fields built specifically for factory
    // shifts, just never surfaced here before.
    val payroll by MockRepository.payroll.collectAsState()
    val factoryPayroll = remember(payroll, factoryStaff) {
        val ids = factoryStaff.map { it.id }.toSet()
        payroll.filter { it.employeeId in ids }
    }
    val leaveRequests by MockRepository.leaveRequests.collectAsState()
    val factoryPendingLeave = remember(leaveRequests, factoryStaff) {
        val ids = factoryStaff.map { it.id }.toSet()
        leaveRequests.filter { it.employeeId in ids && it.status == com.abm.erp.data.LeaveStatus.PENDING }
    }
    var subTab by remember { mutableStateOf(0) }
    var expandedPayrollId by remember { mutableStateOf<String?>(null) }
    val leaveScope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = subTab) {
            Tab(selected = subTab == 0, onClick = { subTab = 0 }, text = { Text("Attendance") })
            Tab(selected = subTab == 1, onClick = { subTab = 1 }, text = { Text("Payroll") })
            Tab(selected = subTab == 2, onClick = { subTab = 2 }, text = { Text("Leave") })
            Tab(selected = subTab == 3, onClick = { subTab = 3 }, text = { Text("Live Tracking") })
            Tab(selected = subTab == 4, onClick = { subTab = 4 }, text = { Text("Assign Worker") })
        }
        when (subTab) {
            1 -> LazyColumn(Modifier.fillMaxSize().padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text("Overtime সহ dynamic payroll — main HR-এর মতোই একই হিসাব।", style = MaterialTheme.typography.bodySmall, color = TextSecondary) }
                if (factoryPayroll.isEmpty()) {
                    item { com.abm.erp.core.WorkspaceEmptyState("এই মাসে কোনো payroll লাইন তৈরি হয়নি।") }
                }
                items(factoryPayroll) { line ->
                    com.abm.erp.ui.hrm.PayrollCard(line, expanded = expandedPayrollId == line.employeeId, onToggle = {
                        expandedPayrollId = if (expandedPayrollId == line.employeeId) null else line.employeeId
                    })
                }
            }
            2 -> LazyColumn(Modifier.fillMaxSize().padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text("Pending Leave (${factoryPendingLeave.size})", fontWeight = FontWeight.Bold, color = TextPrimary) }
                if (factoryPendingLeave.isEmpty()) {
                    item { Text("কোনো pending leave নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall) }
                }
                items(factoryPendingLeave) { l ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(l.employeeName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("${l.type} · ${l.fromDate} → ${l.toDate}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        var leaveError by remember(l.id) { mutableStateOf<String?>(null) }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { leaveScope.launch { MockRepository.setLeaveStatus(l.id, com.abm.erp.data.LeaveStatus.APPROVED, onRejected = { r -> leaveError = r }) } }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) { Text("Approve") }
                            OutlinedButton(onClick = { leaveScope.launch { MockRepository.setLeaveStatus(l.id, com.abm.erp.data.LeaveStatus.REJECTED, onRejected = { r -> leaveError = r }) } }) { Text("Reject", color = DangerRed) }
                        }
                        leaveError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    }
                }
            }
            3 -> FactoryLiveTrackingTab(factoryStaff)
            4 -> AssignManufacturingWorkerTab(factoryStaff)
            else -> FactoryAttendanceList(factoryStaff)
        }
    }
}

// v113-239 — a real, significant gap found in the same proactive sweep:
// assignManufacturingWorker was fully real and working, with zero UI
// callers anywhere — meaning no worker could ever actually be assigned
// to a manufacturing unit/line/machine/shift. This matters beyond just
// "missing a button": computeFactoryAttendanceReport (the unit/section/
// line/machine/shift-filtered factory attendance view) depends entirely
// on manufacturingWorkerAssignments having real rows — without this,
// that report could never have shown anything, no matter how correct
// its own logic was.
@Composable
private fun AssignManufacturingWorkerTab(factoryStaff: List<com.abm.erp.data.EmployeeProfile>) {
    val assignments by MockRepository.manufacturingWorkerAssignments.collectAsState()
    var selectedEmployeeId by remember { mutableStateOf<String?>(null) }
    var manufacturingUnitId by remember { mutableStateOf("") }
    var productionLine by remember { mutableStateOf("") }
    var machine by remember { mutableStateOf("") }
    var section by remember { mutableStateOf("") }
    var shiftType by remember { mutableStateOf(com.abm.erp.data.ShiftType.GENERAL) }
    var selectedSkills by remember { mutableStateOf(setOf<com.abm.erp.data.ManufacturingSkill>()) }
    var assignError by remember { mutableStateOf<String?>(null) }
    var assignMsg by remember { mutableStateOf<String?>(null) }

    LazyColumn(Modifier.fillMaxSize().padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Active Assignments (${assignments.count { it.isActive }})", fontWeight = FontWeight.Bold, color = TextPrimary)
        }
        items(assignments.filter { it.isActive }) { a ->
            val emp = factoryStaff.firstOrNull { it.id == a.employeeId }
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(emp?.fullName ?: a.employeeId, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text(
                    listOfNotNull(a.manufacturingUnitId, a.productionLine, a.machine, a.section).joinToString(" · ") + " · ${a.shiftType}",
                    style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                )
            }
        }
        item {
            Spacer(Modifier.height(6.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("নতুন Assignment", fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(8.dp))
                Text("Employee", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    factoryStaff.forEach { e ->
                        FilterChip(selected = selectedEmployeeId == e.id, onClick = { selectedEmployeeId = e.id }, label = { Text(e.fullName, style = MaterialTheme.typography.labelSmall) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = manufacturingUnitId, onValueChange = { manufacturingUnitId = it }, label = { Text("Manufacturing Unit") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = productionLine, onValueChange = { productionLine = it }, label = { Text("Line") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = machine, onValueChange = { machine = it }, label = { Text("Machine") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(value = section, onValueChange = { section = it }, label = { Text("Section") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text("Shift", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    com.abm.erp.data.ShiftType.values().forEach { s ->
                        FilterChip(selected = shiftType == s, onClick = { shiftType = s }, label = { Text(s.name, style = MaterialTheme.typography.labelSmall) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Skills", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    com.abm.erp.data.ManufacturingSkill.values().forEach { sk ->
                        FilterChip(
                            selected = sk in selectedSkills,
                            onClick = { selectedSkills = if (sk in selectedSkills) selectedSkills - sk else selectedSkills + sk },
                            label = { Text(sk.name, style = MaterialTheme.typography.labelSmall) },
                        )
                    }
                }
                assignError?.let { Spacer(Modifier.height(6.dp)); Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                assignMsg?.let { Spacer(Modifier.height(6.dp)); Text(it, color = SuccessGreen, style = MaterialTheme.typography.labelSmall) }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val empId = selectedEmployeeId
                        assignError = null; assignMsg = null
                        if (empId == null || manufacturingUnitId.isBlank()) {
                            assignError = "Employee আর Manufacturing Unit দিন।"
                        } else {
                            val ok = MockRepository.assignManufacturingWorker(
                                empId, manufacturingUnitId.trim(), productionLine.trim().ifBlank { null }, machine.trim().ifBlank { null },
                                section.trim().ifBlank { null }, shiftType, null, selectedSkills.toList(),
                            )
                            if (ok) {
                                assignMsg = "✓ Assignment সংরক্ষিত হয়েছে।"
                                selectedEmployeeId = null; manufacturingUnitId = ""; productionLine = ""; machine = ""; section = ""; selectedSkills = emptySet()
                            } else {
                                assignError = "সংরক্ষণ করা যায়নি — অনুমতি নেই।"
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Assign") }
            }
        }
    }
}

@Composable
private fun FactoryLiveTrackingTab(factoryStaff: List<com.abm.erp.data.EmployeeProfile>) {
    val ids = remember(factoryStaff) { factoryStaff.map { it.id }.toSet() }
    com.abm.erp.ui.crm.LiveTrackingTab(filterEmployeeIds = ids)
}

@Composable
private fun FactoryAttendanceList(factoryStaff: List<com.abm.erp.data.EmployeeProfile>) {

    Column(Modifier.fillMaxSize()) {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Factory attendance rule", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "Laborer check-in is accepted only when the device is on the factory WiFi allowlist " +
                    "and GPS falls inside the factory geofence. Either failing marks the day unapproved for payroll.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
            )
        }

        Spacer(Modifier.height(12.dp))
        Text(
            "Factory Workforce (${factoryStaff.size})",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
        )
        Spacer(Modifier.height(8.dp))

        if (factoryStaff.isEmpty()) {
            com.abm.erp.core.WorkspaceEmptyState(
                "কোনো কর্মীকে এখনো Factory হিসেবে চিহ্নিত করা হয়নি।\n" +
                    "Chairman → Employee Setup থেকে কর্মীর ধরন Factory করলে তারা এখানে দেখাবে।",
                iconVector = Icons.Filled.Engineering,
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(factoryStaff) { emp ->
                    val present by MockRepository.isPresentTodayFlow(emp.id).collectAsState(initial = false)
                    val late by MockRepository.isLateTodayFlow(emp.id).collectAsState(initial = false)
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            com.abm.erp.core.PresenceDot(present = present, late = late)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(emp.fullName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                Text(
                                    listOfNotNull(emp.employeeCode.ifBlank { null }, emp.designation.ifBlank { null })
                                        .joinToString(" · "),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                )
                            }
                            Text(
                                if (!present) "Absent" else if (late) "Late" else "Present",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (!present) DangerRed else if (late) WarningAmber else SuccessGreen,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BomLineBuilder(lines: MutableList<com.abm.erp.data.BomLine>) {
    var material by remember { mutableStateOf("") }
    var qtyText by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("kg") }

    Column {
        lines.forEachIndexed { idx, l ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${l.rawMaterialName}: ${l.qtyPerUnit} ${l.unit}/unit", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { lines.removeAt(idx) }) { Text("✕", color = DangerRed) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(value = material, onValueChange = { material = it }, label = { Text("Raw material") }, modifier = Modifier.weight(2f))
            OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Qty/unit") }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Button(
            onClick = {
                val qty = qtyText.toDoubleOrNull() ?: return@Button
                if (material.isBlank()) return@Button
                lines.add(com.abm.erp.data.BomLine(material, qty, unit))
                material = ""; qtyText = ""
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("+ Add material line") }
    }
}

@Composable
private fun BomTab(vm: ProductionViewModel) {
    val boms by vm.boms.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val filteredBoms = remember(boms, query) { if (query.isBlank()) boms else boms.filter { it.finishedProductName.contains(query, ignoreCase = true) } }
    val bomScope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New BOM") }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("Product নাম দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (filteredBoms.isEmpty()) {
                item { com.abm.erp.core.WorkspaceEmptyState("কোনো Bill of Materials পাওয়া যায়নি।", "📐") }
            }
            items(filteredBoms) { b ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(b.finishedProductName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    b.lines.forEach { l -> Text("  ${l.rawMaterialName}: ${l.qtyPerUnit} ${l.unit}/unit", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                    Spacer(Modifier.height(4.dp))
                    Text("Estimated unit cost: ৳${"%.2f".format(vm.estimatedUnitCost(b))}", color = ElectricCyan, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelSmall)
                }
            }
            if (boms.isEmpty()) item { Text("এখনো কোনো BOM নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(modifier = Modifier.fillMaxSize(), color = com.abm.erp.theme.DashBg) {
                var name by remember { mutableStateOf("") }
                var labor by remember { mutableStateOf("") }
                var overhead by remember { mutableStateOf("") }
                val lines = remember { mutableStateListOf<com.abm.erp.data.BomLine>() }
                Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("New Bill of Materials", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { showNew = false }) { Text("✕ Close") }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Finished product name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    BomLineBuilder(lines)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = labor, onValueChange = { labor = it }, label = { Text("Labor cost/unit (৳)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = overhead, onValueChange = { overhead = it }, label = { Text("Overhead cost/unit (৳)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            bomScope.launch {
                                vm.createBom(name, lines.toList(), labor.toDoubleOrNull() ?: 0.0, overhead.toDoubleOrNull() ?: 0.0)
                                showNew = false
                            }
                        },
                        enabled = name.isNotBlank() && lines.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Create BOM") }
                }
            }
        }
    }
}

@Composable
private fun ProductionOrdersTab(vm: ProductionViewModel) {
    val orders by vm.productionOrders.collectAsState()
    val boms by vm.boms.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    var completionErrors by remember { mutableStateOf<List<String>?>(null) }
    val orderScope = rememberCoroutineScope()

    val today = java.time.LocalDate.now()
    val todaysOrders = orders.count { it.scheduledDate.toLocalDate() == today }
    val pendingCount = orders.count { it.status == "PLANNED" }
    val runningCount = orders.count { it.status == "IN_PROGRESS" }
    val completedCount = orders.count { it.status == "COMPLETED" }
    val delayedCount = orders.count { it.scheduledDate.toLocalDate().isBefore(today) && it.status != "COMPLETED" && it.status != "CANCELLED" }
    val efficiencyPct = remember(orders) {
        val completed = orders.filter { it.status == "COMPLETED" }
        if (completed.isEmpty()) null else (completed.size.toDouble() / orders.filter { it.status != "CANCELLED" }.size.coerceAtLeast(1) * 100)
    }

    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf<String?>(null) }
    var productFilter by remember { mutableStateOf<String?>(null) }
    var dateFilter by remember { mutableStateOf(0) }
    var showDelayed by remember { mutableStateOf(false) }
    val prodCutoff = when (dateFilter) {
        1 -> java.time.LocalDate.now().atStartOfDay()
        2 -> java.time.LocalDate.now().minusDays(7).atStartOfDay()
        3 -> java.time.LocalDate.now().minusDays(30).atStartOfDay()
        else -> null
    }
    val productNames = remember(orders) { orders.map { it.finishedProductName }.distinct().sorted() }
    val delayedOrders = orders.filter { it.scheduledDate.toLocalDate().isBefore(today) && it.status != "COMPLETED" && it.status != "CANCELLED" }
    val filteredOrders = remember(orders, searchQuery, statusFilter, productFilter, dateFilter) {
        orders.filter { o ->
            (searchQuery.isBlank() || o.orderNo.contains(searchQuery, ignoreCase = true) || o.finishedProductName.contains(searchQuery, ignoreCase = true)) &&
                (statusFilter == null || o.status == statusFilter) &&
                (productFilter == null || o.finishedProductName == productFilter) &&
                (prodCutoff == null || o.scheduledDate.isAfter(prodCutoff))
        }
    }

    Column(Modifier.fillMaxSize()) {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Production Dashboard", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Column { Text("Today", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("$todaysOrders", fontWeight = FontWeight.Bold) }
                Column { Text("Pending", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("$pendingCount", fontWeight = FontWeight.Bold, color = WarningAmber) }
                Column { Text("Running", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("$runningCount", fontWeight = FontWeight.Bold, color = Sky) }
                Column { Text("Completed", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("$completedCount", fontWeight = FontWeight.Bold, color = SuccessGreen) }
                Column(Modifier.clickable { showDelayed = !showDelayed }) { Text("Delayed", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("$delayedCount", fontWeight = FontWeight.Bold, color = DangerRed) }
            }
            if (efficiencyPct != null) {
                Spacer(Modifier.height(6.dp))
                Text("Completion Rate: ${"%.0f".format(efficiencyPct)}%", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Spacer(Modifier.height(4.dp))
            Text("Capacity data unavailable", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
        if (showDelayed && delayedOrders.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Delayed Orders", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                delayedOrders.forEach { o -> Text("${o.orderNo} — ${o.finishedProductName} (scheduled ${o.scheduledDate.toLocalDate()})", style = MaterialTheme.typography.bodySmall, color = DangerRed) }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "OrderNo,Product,Target,Status\n"
                    val rows = filteredOrders.joinToString("\n") { o -> com.abm.erp.core.toCsvRow(o.orderNo, o.finishedProductName, o.targetQty, o.status) }
                    val file = java.io.File(context.getExternalFilesDir(null), "production_orders_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Production Orders (${filteredOrders.size})\n" + filteredOrders.joinToString("\n") { "${it.orderNo} — ${it.finishedProductName} (${it.status})" }
                    // v113-335 — was a hand-rolled text/plain share. Now routed
                    // through the one shared helper so every screen sends the
                    // rendered image, per the person's own requirement.
                    com.abm.erp.core.shareTextSummary(context, "Production Orders", summary)
                },
            )
        }
        OutlinedTextField(value = searchQuery, onValueChange = { searchQuery = it }, placeholder = { Text("Order/product খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            FilterChip(selected = statusFilter == null, onClick = { statusFilter = null }, label = { Text("All") })
            listOf("PLANNED", "IN_PROGRESS", "PAUSED", "QUALITY_HOLD", "RELEASED", "COMPLETED", "CANCELLED").forEach { s -> FilterChip(selected = statusFilter == s, onClick = { statusFilter = s }, label = { Text(s) }) }
        }
        if (productNames.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                FilterChip(selected = productFilter == null, onClick = { productFilter = null }, label = { Text("All Products") })
                productNames.forEach { p -> FilterChip(selected = productFilter == p, onClick = { productFilter = p }, label = { Text(p) }) }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            FilterChip(selected = dateFilter == 0, onClick = { dateFilter = 0 }, label = { Text("All") })
            FilterChip(selected = dateFilter == 1, onClick = { dateFilter = 1 }, label = { Text("Today") })
            FilterChip(selected = dateFilter == 2, onClick = { dateFilter = 2 }, label = { Text("Week") })
            FilterChip(selected = dateFilter == 3, onClick = { dateFilter = 3 }, label = { Text("Month") })
        }
        Spacer(Modifier.height(10.dp))
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth(), enabled = boms.isNotEmpty()) { Text("+ New Production Order") }
        Spacer(Modifier.height(10.dp))
        if (filteredOrders.isEmpty()) {
            com.abm.erp.core.WorkspaceEmptyState("কোনো Production Order পাওয়া যায়নি — ফিল্টার পরিবর্তন করে দেখুন।", "🏭")
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filteredOrders) { o ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${o.orderNo} — ${o.finishedProductName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("Target: ${o.targetQty} · scheduled ${o.scheduledDate.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            com.abm.erp.core.StatusPill(o.status)
                            val context = androidx.compose.ui.platform.LocalContext.current
                            TextButton(onClick = {
                                try {
                                    val file = com.abm.erp.core.exportProductionOrderPdf(context, o)
                                    com.abm.erp.core.shareStructuredPdf(context, file, "Production ${o.orderNo}")
                                } catch (e: Exception) {
                                    android.widget.Toast.makeText(context, "Production Sheet PDF তৈরি ব্যর্থ হয়েছে: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                                }
                            }) { Text("📄", style = MaterialTheme.typography.labelSmall) }
                            val prodAuditLog by MockRepository.activityLogFor("ProductionOrder", o.id).collectAsState(initial = emptyList())
                            com.abm.erp.core.UniversalActionMenu(
                                moduleReference = "ProductionOrder", entityId = o.id, entityLabel = o.orderNo,
                                shareText = "Production Order ${o.orderNo} — ${o.finishedProductName}\nTarget: ${o.targetQty}\nScheduled: ${o.scheduledDate.toLocalDate()}\nStatus: ${o.status}",
                                csvHeader = "OrderNo,Product,Target,Scheduled,Status", csvRow = com.abm.erp.core.toCsvRow(o.orderNo, o.finishedProductName, o.targetQty, o.scheduledDate.toLocalDate(), o.status),
                                historyLabel = "Order Timeline",
                                historyItems = prodAuditLog.sortedByDescending { it.timestamp }.map { "${it.action} — ${it.performedBy} (${it.timestamp.toLocalDate()})" },
                            )
                        }
                    }
                    if (o.status in setOf("PLANNED", "IN_PROGRESS")) {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (o.status == "PLANNED") Button(onClick = { orderScope.launch { completionErrors = vm.updateProductionOrderStatus(o.id, "IN_PROGRESS") } }) { Text("Start") }
                            if (o.status == "IN_PROGRESS") OutlinedButton(onClick = { orderScope.launch { completionErrors = vm.updateProductionOrderStatus(o.id, "PAUSED") } }) { Text("Pause") }
                            if (o.status == "PAUSED") Button(onClick = { orderScope.launch { completionErrors = vm.updateProductionOrderStatus(o.id, "IN_PROGRESS") } }) { Text("Resume") }
                            if (o.status == "IN_PROGRESS" || o.status == "PAUSED") OutlinedButton(onClick = { orderScope.launch { completionErrors = vm.updateProductionOrderStatus(o.id, "QUALITY_HOLD") } }) { Text("Quality Hold", color = WarningAmber) }
                            if (o.status == "QUALITY_HOLD") Button(onClick = { orderScope.launch { completionErrors = vm.updateProductionOrderStatus(o.id, "RELEASED") } }) { Text("Release") }
                            if (o.status == "RELEASED" || o.status == "IN_PROGRESS") Button(onClick = { orderScope.launch { completionErrors = vm.updateProductionOrderStatus(o.id, "COMPLETED") } }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) { Text("Complete") }
                            OutlinedButton(onClick = { orderScope.launch { completionErrors = vm.updateProductionOrderStatus(o.id, "CANCELLED") } }) { Text("Cancel", color = DangerRed) }
                        }
                        completionErrors?.let { errs ->
                            Dialog(onDismissRequest = { completionErrors = null }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text("Production cannot be completed", style = MaterialTheme.typography.titleMedium, color = DangerRed)
                                        Spacer(Modifier.height(8.dp))
                                        errs.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                                        Spacer(Modifier.height(10.dp))
                                        Button(onClick = { completionErrors = null }, modifier = Modifier.fillMaxWidth()) { Text("OK") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (filteredOrders.isEmpty()) item { Text("এই ফিল্টারে কোনো Production Order নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(modifier = Modifier.fillMaxSize(), color = com.abm.erp.theme.DashBg) {
                var selectedBom by remember { mutableStateOf<com.abm.erp.data.BillOfMaterials?>(null) }
                var expanded by remember { mutableStateOf(false) }
                var qtyText by remember { mutableStateOf("") }
                Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("New Production Order", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { showNew = false }) { Text("✕ Close") }
                    }
                    Spacer(Modifier.height(10.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedBom?.finishedProductName ?: "Select BOM") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            boms.forEach { b -> DropdownMenuItem(text = { Text(b.finishedProductName) }, onClick = { selectedBom = b; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Target quantity") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val b = selectedBom ?: return@Button
                            val qty = qtyText.toDoubleOrNull() ?: return@Button
                            orderScope.launch {
                                vm.createProductionOrder(b.id, b.finishedProductName, qty, java.time.LocalDateTime.now())
                                showNew = false
                            }
                        },
                        enabled = selectedBom != null && qtyText.toDoubleOrNull() != null,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Create Order") }
                }
            }
        }
    }
}

@Composable
private fun QualityControlTab(vm: ProductionViewModel) {
    val checks by vm.qualityChecks.collectAsState()
    val batches by vm.batches.collectAsState()
    var selectedBatch by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("PASS") }
    var notes by remember { mutableStateOf("") }
    val qcScope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Record Quality Check", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(batches.firstOrNull { it.id == selectedBatch }?.cycleType ?: "Select batch")
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    batches.forEach { b -> DropdownMenuItem(text = { Text(b.cycleType) }, onClick = { selectedBatch = b.id; expanded = false }) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = result == "PASS", onClick = { result = "PASS" }, label = { Text("PASS") })
                FilterChip(selected = result == "FAIL", onClick = { result = "FAIL" }, label = { Text("FAIL") })
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = { val b = selectedBatch ?: return@Button; qcScope.launch { vm.recordQualityCheck(b, result, notes) }; notes = "" },
                enabled = selectedBatch != null,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Save Quality Check") }
        }
        Spacer(Modifier.height(14.dp))
        var resultFilter by remember { mutableStateOf<String?>(null) }
        val filteredChecks = checks.filter { resultFilter == null || it.result == resultFilter }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = resultFilter == null, onClick = { resultFilter = null }, label = { Text("সব") })
            FilterChip(selected = resultFilter == "PASS", onClick = { resultFilter = "PASS" }, label = { Text("PASS") })
            FilterChip(selected = resultFilter == "FAIL", onClick = { resultFilter = "FAIL" }, label = { Text("FAIL") })
        }
        Spacer(Modifier.height(6.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (filteredChecks.isEmpty()) {
                item { com.abm.erp.core.WorkspaceEmptyState("কোনো Quality Check পাওয়া যায়নি।", "✅") }
            }
            items(filteredChecks) { c ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(c.notes.ifBlank { "—" }, style = MaterialTheme.typography.bodySmall)
                        Text(c.result, color = if (c.result == "PASS") SuccessGreen else DangerRed, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductionLossTab(vm: ProductionViewModel) {
    val losses by vm.productionLosses.collectAsState()
    val batches by vm.batches.collectAsState()
    var selectedBatch by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(false) }
    var qtyText by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    val lossScope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Record Production Loss / Wastage", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(batches.firstOrNull { it.id == selectedBatch }?.cycleType ?: "Select batch")
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    batches.forEach { b -> DropdownMenuItem(text = { Text(b.cycleType) }, onClick = { selectedBatch = b.id; expanded = false }) }
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Qty lost (kg)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    val b = selectedBatch ?: return@Button
                    val qty = qtyText.toDoubleOrNull() ?: return@Button
                    lossScope.launch { vm.recordProductionLoss(b, qty, reason) }
                    qtyText = ""; reason = ""
                },
                enabled = selectedBatch != null && qtyText.toDoubleOrNull() != null,
                colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Record Loss") }
        }
        Spacer(Modifier.height(14.dp))
        var lossQuery by remember { mutableStateOf("") }
        val filteredLosses = remember(losses, lossQuery) { if (lossQuery.isBlank()) losses else losses.filter { it.reason.contains(lossQuery, ignoreCase = true) } }
        OutlinedTextField(value = lossQuery, onValueChange = { lossQuery = it }, placeholder = { Text("কারণ দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (filteredLosses.isEmpty()) {
                item { com.abm.erp.core.WorkspaceEmptyState("কোনো Production Loss রেকর্ড পাওয়া যায়নি।", "📉") }
            }
            items(filteredLosses) { l ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${l.qtyLost} kg lost — ${l.reason}", style = MaterialTheme.typography.bodySmall)
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "ProductionLoss", entityId = l.id, entityLabel = "Loss — ${l.batchId}",
                            shareText = "Production Loss: ${l.qtyLost} kg\nBatch: ${l.batchId}\nReason: ${l.reason}",
                            csvHeader = "BatchId,QtyLost,Reason", csvRow = com.abm.erp.core.toCsvRow(l.batchId, l.qtyLost, l.reason),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MachineUtilizationTab(vm: ProductionViewModel) {
    val logs by vm.machineLogs.collectAsState()
    var machineName by remember { mutableStateOf("") }
    var hoursText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Log Machine Usage", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = machineName, onValueChange = { machineName = it }, label = { Text("Machine name") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = hoursText, onValueChange = { hoursText = it }, label = { Text("Hours used") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    val hours = hoursText.toDoubleOrNull() ?: return@Button
                    if (machineName.isBlank()) return@Button
                    vm.recordMachineLog(machineName, null, hours, notes)
                    machineName = ""; hoursText = ""; notes = ""
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Save Log") }
        }
        Spacer(Modifier.height(14.dp))
        var machineQuery by remember { mutableStateOf("") }
        val totalsByMachine = logs.groupBy { it.machineName }.mapValues { it.value.sumOf { l -> l.hoursUsed } }
            .filterKeys { machineQuery.isBlank() || it.contains(machineQuery, ignoreCase = true) }
        OutlinedTextField(value = machineQuery, onValueChange = { machineQuery = it }, placeholder = { Text("Machine নাম দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (totalsByMachine.isEmpty()) {
                item { com.abm.erp.core.WorkspaceEmptyState("কোনো Machine Log পাওয়া যায়নি।", "🛠️") }
            }
            items(totalsByMachine.entries.toList()) { (name, hours) ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("${"%.1f".format(hours)} hrs total", color = ElectricCyan, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// v113-216 — Chairman/office read-side view for the person's own carton-QR
// decision: "শুধুমাত্র আমরা অফিস থেকে chairman panel observation করতে
// পারব" — status changes happen by scanning at the real physical
// location (UniversalScannerScreen), this tab is purely observation: which
// carton is where right now, filterable by status, drill into one for its
// full timeline. No action buttons here on purpose — matching the
// person's own stated split between field-scan (does) and office (watches).
@Composable
private fun CartonsTrackingTab() {
    val cartons by MockRepository.cartons.collectAsState()
    var query by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf<String?>(null) }
    var selectedCartonId by remember { mutableStateOf<String?>(null) }

    val filtered = remember(cartons, query, statusFilter) {
        cartons.filter {
            (statusFilter == null || it.status == statusFilter) &&
                (query.isBlank() || it.cartonCode.contains(query, true) || it.productName.contains(query, true) || (it.batchCode?.contains(query, true) == true))
        }.sortedByDescending { it.packedAt }
    }

    if (selectedCartonId != null) {
        val c = cartons.firstOrNull { it.id == selectedCartonId }
        if (c == null) {
            selectedCartonId = null
        } else {
            Column(Modifier.fillMaxSize()) {
                TextButton(onClick = { selectedCartonId = null }) { Text("← তালিকায় ফিরুন") }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(c.cartonCode, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("${c.productName} — ${"%,.1f".format(c.quantityInside)} ${c.unit}", color = TextSecondary)
                    Text("Batch: ${c.batchCode ?: "এখনো নির্ধারিত হয়নি (QC pending)"}", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(10.dp))
                    Text("যাত্রার সম্পূর্ণ ইতিহাস", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.height(6.dp))
                    CartonTimelineRow("📦 Packed", "${c.packedBy} — ${c.packedAt.toLocalDate()}", true)
                    CartonTimelineRow("🏬 Warehouse Received", c.warehouseReceivedAt?.let { "${c.warehouseReceivedBy} — ${it.toLocalDate()}" }, c.warehouseReceivedAt != null)
                    CartonTimelineRow("🚚 Dispatched", c.dispatchedAt?.let { "→ ${c.dispatchedTo} — ${c.dispatchedBy}, ${it.toLocalDate()}" }, c.dispatchedAt != null)
                    CartonTimelineRow("✓ Delivered", c.deliveredAt?.let { "${c.deliveredBy} — ${it.toLocalDate()}" }, c.deliveredAt != null)
                }
            }
            return
        }
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text("Carton code, product, বা batch দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = statusFilter == null, onClick = { statusFilter = null }, label = { Text("সব") })
            listOf("PACKED", "WAREHOUSE_RECEIVED", "DISPATCHED", "DELIVERED").forEach { s ->
                FilterChip(selected = statusFilter == s, onClick = { statusFilter = s }, label = { Text(s) })
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (filtered.isEmpty()) {
                item { com.abm.erp.core.WorkspaceEmptyState("কোনো Carton পাওয়া যায়নি।", "📦") }
            }
            items(filtered) { c ->
                val statusColor = when (c.status) {
                    "DELIVERED" -> SuccessGreen
                    "DISPATCHED" -> WarningAmber
                    "WAREHOUSE_RECEIVED" -> ElectricCyan
                    else -> TextSecondary
                }
                GlassCard(modifier = Modifier.fillMaxWidth().clickable { selectedCartonId = c.id }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(c.cartonCode, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${c.productName} · ${"%,.1f".format(c.quantityInside)} ${c.unit}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text(c.status, color = statusColor, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun CartonTimelineRow(label: String, detail: String?, done: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = if (done) TextPrimary else TextSecondary, fontWeight = if (done) FontWeight.SemiBold else FontWeight.Normal, modifier = Modifier.weight(1f))
        Text(detail ?: "—", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
    }
}
