# ABM ERP — HANDOFF PROMPT (paste this whole file into the new chat)

## Who I am / what this is
I'm Asik. This is **ABM ERP** — a large, real, production-bound Android ERP
(Kotlin, Jetpack Compose BOM 2024.06.00 + Material3, Room, Firebase Firestore +
Storage) for an operating manufacturing + distribution company. It is **NOT a new
project and must NOT be rebuilt**. The uploaded zip is the single source of truth.

Reply to me in **Bangla-English mixed, short and direct**. Token efficiency matters.

## My setup (important)
- **I have no computer.** I compile ONLY via GitHub Actions CI by uploading the zip
  directly (`gradle/actions/setup-gradle@v4`, Gradle 8.7).
- You cannot compile in your sandbox either. Source analysis is not a build —
  say so plainly rather than claiming "compile-ready".
- Working dir: `/home/claude/proj`. Keep a pristine copy at `/home/claude/orig`
  for balance-diff after every edit.
- Ship every version as a versioned zip to `/mnt/user-data/outputs/`.

---

# ⚠️ FIRST TASK — v113-151 has compile errors

The zip I'm giving you (v113-151) **fails to compile**. I will paste the error
lines. Only the lines starting with `e:` matter — e.g.
`e: file:///.../LoginScreen.kt:820:5 Unresolved reference: xyz`. Ignore the
200-line Gradle stack trace; it says nothing useful.

**Almost certainly the errors are in `LoginScreen.kt`**, because the previous
session had just finished splitting that file (see "Where we left off" below).

---

# Where we left off — the LoginScreen split (READ THIS FIRST)

## The runtime bug being fixed
v113-148 compiled GREEN but the app **crashed instantly on my phone**, before the
login UI drew:

```
java.lang.VerifyError: Verifier rejected class com.abm.erp.ui.login.LoginScreenKt
[0x4119] copy-cat1 v14<-v313  type=Reference: MeasurePolicy
```

Register **313**. `LoginScreen` was ~1100 lines in ONE function; Compose compiles
that to a single enormous method and Android's dex verifier rejects it. **Gradle
cannot catch this — only running on a device does.**

## The fix in progress (v113-149 → v113-151)
`LoginScreen` split from ~1100 → **817 lines**, with 7 extracted composables in the
same file:

| Composable | ~lines |
|---|---|
| PinEntryPanel | 85 |
| ForgotPinFlow | 83 |
| DeviceLockedPanel | 50 |
| CompanyCodePanel | 48 |
| MobileEntryPanel | 37 |
| DeviceApprovalPanel | 29 |
| MandatoryBiometricPanel | 23 |

**State technique used (keep it):** 12 shared `MutableState` objects, with `by`
delegates in BOTH LoginScreen and each panel, so every extracted body is
byte-for-byte unchanged. Example:
```kotlin
val pinState = remember { mutableStateOf("") }
var pin by pinState                      // in LoginScreen
// and inside the panel:
private fun PinEntryPanel(pinState: MutableState<String>, ...) {
    var pin by pinState
```
**Do NOT rewrite assignments into value+setter lambdas.** I tried that by regex in
v113-149 and it produced broken code like `onForgotPhone(it },)`. MutableState
avoids touching the bodies at all.

## Still unproven
Whether 817 lines clears the verifier. Once it compiles, I install and report. If
the same VerifyError returns, the next lever is **different in kind** — split
LoginScreen across multiple FILES, or enable R8 — not more of the same.

---

# Hard-won rules (violating these has broken my builds repeatedly)

1. **Verify every symbol against source before using it.** Field names, types,
   DAO methods, icon names. Assumptions have broken the build ~5 separate times.
   - Icons: check the name exists in a previously-GREEN build before using it.
     `Sms`, `Chat`, `Email`, `UploadFile`, `CloudUpload` were all NOT available.
   - Types: `pendingDeviceApproval` is `AppUser?` (I once wrote a class name that
     doesn't exist). `geoBlockError`/`noDemoPinError` are `Boolean`, not `String?`.
2. **Imports are not inherited.** Check `background`, `Color`, `sp`, `clip`,
   theme colors (`DangerRed` etc.) are actually imported in THAT file. Several
   files use explicit named imports, not wildcards.
3. **Balance sweep after every edit**, diffing braces/parens vs `/home/claude/orig`.
   **Strip string literals BEFORE comments** — otherwise `//` inside a URL like
   `"https://wa.me/..."` eats the rest of the line and gives false alarms.
4. **Balance sweep cannot catch wrong placement.** A block pasted into the wrong
   function still balances perfectly. After moving code, **brace-match to confirm
   which function actually encloses it.** This bit me: a dialog landed inside
   `VehicleTrackingTab` instead of `CourierScreen` → 12 unresolved references.
5. **Brace-matching `} else if (...) {`:** that line both closes and opens. Start
   depth at 1 and scan from the NEXT line, or you'll mis-size the block.
6. **Assert before writing.** Verify an extracted body balances to 0 BEFORE
   writing the file. This caught two bad extractions at zero cost.
7. **After extracting code, scan the body** against the parent's local `fun`/`val`/
   `var` declarations — local functions and outer state are invisible to the new
   function and must be passed as parameters/lambdas.
8. **One home per feature.** Grep before creating anything; reuse/extend, never
   duplicate.
9. **Additive-only Room migrations.** Nullable columns, never touch existing ones.
   Verify the SQL column name/type matches the entity exactly (Room crashes at
   open time on mismatch), and re-run the chain verifier.
10. **No fabricated data ever.** No random numbers, fake QR, fake tracking, fake
    charts. If an integration isn't built, say so in the UI rather than implying
    it works.
11. **Every rejection path must report its real reason** — never "Failed" or
    "Something went wrong" when a specific reason exists.

---

# Current state of the app

## Database
**Room version 77.** 55 migrations, chain 23→77 continuous, zero gaps, all
registered. Two recent ones: `MIGRATION_75_76` (courier apiBaseUrl/apiKey),
`MIGRATION_76_77` (dealers photoUri).

## Five mother modules (DMS, RMS, HR, FMS, Chairman)
All on `core/ModuleDrawerScaffold.kt`. 59+ drawer items, all routed, no dead items.

## Verified business chains (traced through source)
- Invoice draft → no effect. **Approve** → warehouse stock OUT + dealer due +net +
  dealer stock + ledger DEBIT. **Collection verify** → due −amount + invoice
  allocation + ledger CREDIT. Loop closes.
- ONE canonical ledger function (`postPartyLedgerEntry`); `balanceAfter` read from
  the real Room row, not a cached StateFlow.
- Warehouse dispatch does NOT credit destination — goes to a real IN_TRANSIT
  bucket; only `receiveWarehouseTransfer` credits it.
- 20 real idempotency guards; all Firestore writes use `document(entity.id).set()`
  so retries overwrite instead of duplicating.
- Payroll formula hand-verified: `(basePay × achievement curve) + commission −
  absence penalty`, curve clamped 50–150%.

## Completed this session (all shipped, most compiled green at v113-148)
- "Vague rejection" backlog **fully closed** (~120 functions now report real reasons)
- Cascade approval engine wired (ASM→RSM→GM), tier-aware buttons
- **Universal Search security leak fixed** — it searched company-wide dealers/
  retailers with no cascade scope; now uses `visibleDealersFor`/`visibleRetailersFor`
- Header now only on dashboard (was eating space on every screen)
- QR: one tap, portrait-locked everywhere (was 2 taps + landscape)
- Login: fingerprint removed, remembers number → PIN-only next time
- KPI graph on all 5 module dashboards (shared `core/DualSeriesBarChart`)
- Invoice: dealer location + "+ New Product" + Edit; Memo: same + navigation
- Territory/location screen: added employee list (rest already existed)
- Courier API paste-slot (Chairman-only; **honestly labeled "config saved,
  integration not active"** — no live courier API exists)
- Chairman: Product Control (new) + Support/Helpdesk entry
- Dealer photo slot (was the only party entity without one)
- CSV Import (`core/CsvImport.kt`) with real per-row failure reasons
- Real SMS + WhatsApp handoff beside the existing Call action

## Genuinely NOT built (do not claim otherwise)
- **Live courier API integration** — no HTTP client in the project at all
  (no OkHttp/Retrofit/Ktor), and each courier (Pathao/Steadfast/RedX/Sundarban)
  has a different API. Needs me to choose one + supply docs.
- **Bulk SMS broadcast** — Android needs SEND_SMS permission which Play Store
  restricts to messaging apps. Only a multi-recipient handoff is realistic.
- **.xlsx import** — CsvImport reads CSV only; real xlsx needs Apache POI.
- `UniversalActionMenu.onDuplicate` for products (needs signature change).
- Nothing has been tested on a device beyond app launch.

---

# What I want you to do

1. **Fix the compile errors I paste.** Read the actual file before editing;
   don't guess.
2. Then let me install and report whether the VerifyError is gone.
3. Then continue hardening. Ask me before large refactors.

Full change history with rationale for every decision is in **PROJECT_STATE.md**
inside the zip (~4700 lines). Read the last ~200 lines for immediate context.
