plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
    id("com.google.gms.google-services") // reads app/google-services.json — see SETUP_FIREBASE.md
    id("com.google.firebase.crashlytics")
}

android {
    namespace = "com.abm.erp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.abm.erp"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures { compose = true; buildConfig = true }

    // v113-185 — self-generated internal signing key (app/keystore/abm-release.jks).
    // Person's request: a build with the demo-accounts map genuinely empty
    // (APP_ENVIRONMENT="PRODUCTION", set only for the `release` build type)
    // needs to actually be installable to be useful — an unsigned APK
    // generally isn't. This is a self-signed key suitable for internal/
    // self-managed distribution (installing on your own devices via your
    // own CI), NOT a Play Store production key — if this app is ever
    // published to Play Store, generate a proper upload key through Play
    // Console instead and replace this one; don't reuse an internal
    // self-signed key for a public store listing.
    signingConfigs {
        create("release") {
            storeFile = file("keystore/abm-release.jks")
            storePassword = "abm2026release"
            keyAlias = "abmrelease"
            keyPassword = "abm2026release"
        }
    }

    // Explicit debug/release build types (previously absent — no buildTypes
    // block existed at all). Release keeps minify/shrink OFF for now (see
    // the comment inside the release block) until a real, executed release
    // build has verified proguard-rules.pro against this codebase's
    // Firestore-reflection-heavy entities.
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            // v85.1 correction: minify/shrink kept OFF until a real, executed
            // release build has verified proguard-rules.pro actually works
            // with this codebase's Firestore-reflection-heavy entities.
            // Enabling this without a verified build would be an unverified
            // "R8 works" claim. proguard-rules.pro is still referenced below
            // so it's ready the moment a real build confirms it's safe.
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            buildConfigField("String", "APP_ENVIRONMENT", "\"PRODUCTION\"")
        }
        debug {
            isMinifyEnabled = false
            isDebuggable = true
            buildConfigField("String", "APP_ENVIRONMENT", "\"DEBUG\"")
        }
        create("staging") {
            initWith(getByName("release"))
            isDebuggable = true
            matchingFallbacks += listOf("release")
            buildConfigField("String", "APP_ENVIRONMENT", "\"STAGING\"")
        }
    }

    // দুটো ব্লকই থাকা লাগবে, দুটোই একই Java ভার্সনে (17) — শুধু kotlinOptions
    // থাকলে এবং compileOptions না থাকলে, Java compiler নিজে থেকে একটা পুরনো
    // ভার্সনে (সাধারণত 8) ডিফল্ট হয়ে যায়, আর তখনই KSP (Room-এর annotation
    // processor) এই "Inconsistent JVM-target compatibility" এরর দেয়।
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        // Material3 marks several commonly-needed APIs (TopAppBar, Chips, etc.)
        // as @ExperimentalMaterial3Api. Opting in project-wide here is more
        // robust than per-function @OptIn annotations scattered around —
        // this is Google's own documented recommendation for apps that use
        // these APIs throughout, rather than as a rare one-off.
        freeCompilerArgs += "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api"
    }
}

// Room now exports its schema on every build (Mission 2, v85) — this JSON
// history is what real Migration() objects get written against going
// forward. It was OFF before, which is exactly why versions 1-22's schemas
// can no longer be reliably reconstructed (see AppDatabase.kt's migration
// comment and the v85 report's Room Migration Matrix).
ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.2")
    // WorkManager: guaranteed background retry for anything that must not be
    // silently lost if the app is closed mid-sync (audit log flush, pending
    // Firestore pushes) — separate from Firestore's own offline cache, which
    // only replays while the app process is alive.
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // Backup & Recovery needs to await() several sequential Firestore/Storage
    // Tasks in a row (per-collection reads, then an upload, then a metadata
    // write) — plain callback nesting for ~25 collections would be unreadable.
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")

    // Room: on-device database that replaces the in-memory MockRepository.
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // Real GPS location capture (replaces static breadcrumb seed data).
    implementation("com.google.android.gms:play-services-location:21.3.0")
    implementation("com.google.android.gms:play-services-base:18.5.0") // GoogleApiAvailability/ConnectionResult, used by LocationTracker's defensive check
    implementation("androidx.activity:activity-ktx:1.9.0")

    // Real fingerprint/Face unlock for the PIN login screen.
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.fragment:fragment-ktx:1.8.2") // BiometricPrompt needs a FragmentActivity host
    implementation("androidx.appcompat:appcompat:1.7.0") // BiometricPrompt's internal compat dialog (API 26-27) expects an AppCompat-derived theme

    // Firebase: shared multi-device data (Complaint Box, Vacant Positions, and
    // more as each module is ported) plus anonymous Auth so writes are attributable.
    // Requires app/google-services.json from your own Firebase project — see SETUP_FIREBASE.md.
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-firestore-ktx")
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-storage-ktx") // Chairman's Notice image upload
    implementation("com.google.firebase:firebase-crashlytics-ktx") // crash + ANR reports, visible in Firebase console
    implementation("com.google.firebase:firebase-analytics-ktx") // Crashlytics breadcrumb logs need Analytics enabled to be most useful
    implementation("com.google.firebase:firebase-messaging-ktx") // push notifications (Notifications module, Chairman's Notice, etc.)
    implementation("com.google.firebase:firebase-functions-ktx") // calls the setUserRoleClaim Cloud Function for real, database-level role enforcement
    // App Check — debug provider only ever activates in debug builds (see
    // AppEnvironment/ABMApplication); Play Integrity is the release
    // provider. Enforcement itself is NOT turned on in the Firebase
    // Console by this change alone — see SETUP_FIREBASE.md for the
    // manual console step, which should only happen after confirming
    // valid traffic isn't being blocked.
    implementation("com.google.firebase:firebase-appcheck-playintegrity")
    implementation("com.google.firebase:firebase-appcheck-debug")

    // Real scannable QR generation for retailer shop tags (SR field data collection)
    implementation("com.google.zxing:core:3.5.3")
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")

    // Loads the Chairman's Notice image from its Firebase Storage download URL
    implementation("io.coil-kt:coil-compose:2.6.0")
    // v113-290 — the person's own direct request named GIF explicitly
    // for the new DMS notice slots — coil-compose alone only renders a
    // GIF's first frame (no animation) without this decoder extension.
    implementation("io.coil-kt:coil-gif:2.6.0")
}
