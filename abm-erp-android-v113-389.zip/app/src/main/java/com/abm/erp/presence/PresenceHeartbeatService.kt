package com.abm.erp.presence

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.abm.erp.MainActivity
import com.abm.erp.data.MockRepository
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel

/**
 * "Live Presence Heartbeat" — runs as a foreground service (Android requires
 * this for any background location access, plus a persistent notification
 * the person can always see and dismiss-by-stopping) and periodically pulls
 * one GPS fix, feeding it to MockRepository.recordPresenceCheckIn — which
 * both extends the existing route-breadcrumb trail (GeoCrmScreen) AND writes
 * today's attendance record, which is what "Login = Auto Attendance" and
 * payroll's absencePenalty ultimately read.
 *
 * Deliberately NOT started automatically at login — see the toggle on
 * GeoCrmScreen. Requesting background location is a heavier ask than
 * foreground-only, so it's opt-in, not forced.
 */
class PresenceHeartbeatService : Service() {
    private val fusedLocationClient by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private var locationCallback: LocationCallback? = null
    private var liveLocationCallback: LocationCallback? = null
    // Service-owned scope — SupervisorJob so one failed heartbeat upload
    // never cancels the rest of the service's lifetime; IO dispatcher
    // since this only does a DB write + Firestore push, not UI work.
    // Cancelled in onDestroy() so nothing leaks past the service's life.
    private val serviceScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        startLocationUpdates()
        return START_STICKY
    }

    @SuppressLint("MissingPermission") // caller (the toggle in GeoCrmScreen) only starts this service after confirming both location permissions are granted
    private fun startLocationUpdates() {
        val request = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, HEARTBEAT_INTERVAL_MS)
            .setMinUpdateIntervalMillis(HEARTBEAT_INTERVAL_MS)
            .build()
        // Real-time Live Tracking — a SEPARATE, much-faster interval than
        // the 30-minute attendance heartbeat above. This one only ever
        // writes ONE current-position document per employee (overwritten
        // each tick, never accumulated as history) so it doesn't flood
        // the attendance/visit-log system with excessive rows — it feeds
        // a genuinely live "where is this person right now" view instead.
        val liveRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, LIVE_TRACKING_INTERVAL_MS)
            .setMinUpdateIntervalMillis(LIVE_TRACKING_INTERVAL_MS)
            .build()
        val liveCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                val user = MockRepository.currentUser
                serviceScope.launch {
                    try {
                        // v113-359 — spoofed flag forwarded so a mock-location fix is
                        // marked in the trail too, not just at heartbeat time.
                        MockRepository.pushLiveLocation(user.employeeId, user.name, loc.latitude, loc.longitude, loc.speed, System.currentTimeMillis(), loc.isFromMockProvider)
                    } catch (e: Exception) {
                        android.util.Log.w("PresenceHeartbeatService", "live location push failed, will retry next tick", e)
                    }
                }
            }
        }
        liveLocationCallback = liveCallback
        try {
            fusedLocationClient.requestLocationUpdates(liveRequest, liveCallback, mainLooper)
        } catch (e: SecurityException) {
            // Live tracking specifically failing shouldn't kill the whole service — the 30-min attendance heartbeat below can still run.
        }
        val callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                val user = MockRepository.currentUser
                serviceScope.launch {
                    try {
                        // v113-225 — same real-id fix as LoginScreen.kt's own
                        // check-in call, same root cause (see that file's
                        // v113-225 note for the full trace).
                        val realHeartbeatEmployeeId = MockRepository.employeeProfiles.value.firstOrNull { it.userAccountId == user.id }?.id ?: user.employeeId
                        MockRepository.recordPresenceCheckIn(realHeartbeatEmployeeId, user.name, loc.latitude, loc.longitude, loc.isFromMockProvider)
                    } catch (e: Exception) {
                        android.util.Log.w("PresenceHeartbeatService", "presence heartbeat upload failed, will retry next interval", e)
                    }
                }
            }
        }
        locationCallback = callback
        try {
            fusedLocationClient.requestLocationUpdates(request, callback, mainLooper)
        } catch (e: SecurityException) {
            stopSelf() // permission wasn't actually granted — don't keep a broken foreground service alive
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(CHANNEL_ID, "Attendance tracking", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ABM ERP is tracking your location")
            .setContentText("Used for attendance and territory verification while you're on duty.")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        locationCallback?.let { fusedLocationClient.removeLocationUpdates(it) }
        liveLocationCallback?.let { fusedLocationClient.removeLocationUpdates(it) }
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val NOTIFICATION_ID = 4201
        private const val CHANNEL_ID = "presence_heartbeat"
        private const val HEARTBEAT_INTERVAL_MS = 30 * 60 * 1000L // ৩০ মিনিট
        private const val LIVE_TRACKING_INTERVAL_MS = 20 * 1000L // ২০ সেকেন্ড — real-time live tracking

        fun start(context: Context) {
            val intent = Intent(context, PresenceHeartbeatService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, PresenceHeartbeatService::class.java))
        }

        fun isBackgroundLocationGranted(context: Context): Boolean {
            val fine = androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
            val background = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_BACKGROUND_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
            } else true // pre-Android 10, foreground permission covers background too
            return fine && background
        }
    }
}
