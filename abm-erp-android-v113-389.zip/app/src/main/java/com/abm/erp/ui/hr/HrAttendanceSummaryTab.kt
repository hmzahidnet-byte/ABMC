package com.abm.erp.ui.hr

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.AttendanceEngine
import com.abm.erp.data.MockRepository
import com.abm.erp.data.UserRole
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.DarazOrangeDark
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import java.time.LocalDate

/**
 * v113-383 — হাজিরার মাসিক সারাংশ + ছুটি ঘোষণা (HRM ধাপ ৪)।
 *
 * এই পর্দার একটাই কাজ: **Wing 1 যেন এক নজরে দেখে কার কত দেরি, কত অনুপস্থিতি**
 * — আর সেখান থেকেই সিদ্ধান্ত নিতে পারে। কারণ আমাদের নিয়মে অ্যাপ নিজে কিছু
 * কাটে না, তাই দেখানোটা নিখুঁত না হলে পুরো ব্যবস্থাটাই অকেজো: তালিকা ঘেঁটে
 * বের করতে হলে বাস্তবে কেউ করবে না।
 *
 * কর্তনের বোতাম এখানে নেই — ওটা বেতনের পর্দায়, কারণ সিদ্ধান্তটা টাকার,
 * হাজিরার নয়। এখান থেকে শুধু সংখ্যাটা জানা যায়।
 */
@Composable
fun HrAttendanceSummaryTab() {
    val employees by MockRepository.employeeProfiles.collectAsState()
    val today = remember { LocalDate.now() }
    val from = remember(today) { today.withDayOfMonth(1) }
    val to = remember(today) { today.withDayOfMonth(today.lengthOfMonth()) }

    val records by MockRepository.attendanceBetween(from, to).collectAsState(initial = emptyList())
    val settings = remember(employees) { MockRepository.companySettings() }
    val holidays = remember(settings.holidaysRaw) { AttendanceEngine.parseHolidays(settings.holidaysRaw) }
    val live = remember(employees) { employees.filter { !it.isDeleted } }
    val isChairman = MockRepository.currentUser.role == UserRole.CHAIRMAN

    val summaries = remember(live, records, holidays, settings.workingDays) {
        live.map {
            AttendanceEngine.monthlySummary(it, from, to, records, settings.workingDays, holidays, today)
        }.sortedByDescending { it.late + it.absent }   // সমস্যা যাদের, তারা উপরে
    }

    Column(
        Modifier.fillMaxSize().background(com.abm.erp.theme.DashBg)
            .verticalScroll(rememberScrollState()).padding(12.dp),
    ) {
        // ── এই মাসের মোট ──
        val totalLate = summaries.sumOf { it.late }
        val totalAbsent = summaries.sumOf { it.absent }
        val totalLeave = summaries.sumOf { it.onLeave }
        val workingDays = summaries.firstOrNull()?.workingDays ?: 0

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Stat("কর্মদিবস", "$workingDays", Color(0xFF2563EB), Color(0xFFEEF4FF), Modifier.weight(1f))
            Stat("দেরি", "$totalLate", DangerRed, Color(0xFFFDECEA), Modifier.weight(1f))
            Stat("অনুপস্থিত", "$totalAbsent", WarningAmber, Color(0xFFFFF7E6), Modifier.weight(1f))
            Stat("ছুটি", "$totalLeave", SuccessGreen, Color(0xFFE8F7F0), Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))

        // ── ঘোষিত ছুটি ──
        HolidayCard(holidays, isChairman, today)
        Spacer(Modifier.height(10.dp))

        // ── কার কী অবস্থা ──
        if (summaries.isEmpty()) {
            Card { Text("কোনো employee নেই।", fontSize = 11.sp, color = TextSecondary) }
        }
        summaries.forEach { s ->
            Card(accent = if (s.hasIssue) DangerRed.copy(alpha = 0.35f) else null) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(32.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFFEEF4FF)),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.Person, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp)) }
                    Spacer(Modifier.width(8.dp))
                    Text(s.employeeName, Modifier.weight(1f), fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
                    if (s.late > 0) {
                        Box(
                            Modifier.clip(RoundedCornerShape(8.dp)).background(DangerRed).padding(horizontal = 6.dp, vertical = 1.dp),
                        ) { Text("দেরি ${s.late}", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                    }
                }
                Spacer(Modifier.height(7.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Mini("উপস্থিত", s.present, SuccessGreen, Modifier.weight(1f))
                    Mini("দেরি", s.late, DangerRed, Modifier.weight(1f))
                    Mini("অনুপস্থিত", s.absent, WarningAmber, Modifier.weight(1f))
                    Mini("ছুটি", s.onLeave, Color(0xFF2563EB), Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        Text(
            "অ্যাপ নিজে কিছু কাটে না — এখানে শুধু সত্যিটা দেখানো হয়। কর্তনের সিদ্ধান্ত " +
                "বেতনের পাতায়, কারণসহ। অনুপস্থিতির হিসাব আজ পর্যন্ত, ভবিষ্যতের দিন গোনা হয় না।",
            fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
        )
        Spacer(Modifier.height(24.dp))
    }
}

/* ── ঘোষিত ছুটি ────────────────────────────────────────────────────────── */

@Composable
private fun HolidayCard(
    holidays: List<AttendanceEngine.Holiday>,
    isChairman: Boolean,
    today: LocalDate,
) {
    var name by remember { mutableStateOf("") }
    var dayOffset by remember { mutableStateOf(0L) }
    var msg by remember { mutableStateOf<String?>(null) }
    var ok by remember { mutableStateOf(false) }
    val picked = remember(dayOffset) { today.plusDays(dayOffset) }

    Card {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Campaign, contentDescription = null, tint = DarazOrange, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(6.dp))
            Text("ঘোষিত ছুটি", Modifier.weight(1f), fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text("${holidays.size}টি", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DarazOrangeDark)
        }
        Spacer(Modifier.height(6.dp))

        if (holidays.isEmpty()) {
            Text("এখনো কোনো ছুটি ঘোষণা করা হয়নি। শুক্রবার এমনিতেই বন্ধ।", fontSize = 10.5.sp, color = TextSecondary)
        }
        holidays.filter { !it.date.isBefore(today.minusMonths(1)) }.take(8).forEach { h ->
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${h.date}", fontSize = 10.5.sp, color = TextSecondary, modifier = Modifier.width(84.dp))
                Text(h.name, Modifier.weight(1f), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
                if (isChairman) {
                    Box(
                        Modifier.size(26.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFFFDECEA))
                            .clickable {
                                AttendanceEngine.removeHoliday(h.date) { err ->
                                    ok = err.isBlank(); msg = if (err.isBlank()) "✔ ছুটি তুলে নেওয়া হয়েছে" else "✖ $err"
                                }
                            },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.Close, contentDescription = "তুলে নিন", tint = DangerRed, modifier = Modifier.size(13.dp)) }
                }
            }
        }

        if (isChairman) {
            Spacer(Modifier.height(9.dp))
            Text("নতুন ছুটি ঘোষণা", fontSize = 10.sp, color = TextSecondary)
            Spacer(Modifier.height(5.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Step(Icons.Filled.Remove) { dayOffset -= 1 }
                Text(
                    "$picked",
                    Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
                Step(Icons.Filled.Add, filled = true) { dayOffset += 1 }
            }
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("ছুটির নাম (ঈদ, পূজা…)", fontSize = 10.sp) },
                singleLine = true, textStyle = MaterialTheme.typography.bodySmall,
                modifier = Modifier.fillMaxWidth().height(56.dp),
            )
            Spacer(Modifier.height(7.dp))
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                    .background(if (name.isNotBlank()) DarazOrange else Color(0xFFCBD5E1))
                    .clickable(enabled = name.isNotBlank()) {
                        AttendanceEngine.declareHoliday(picked, name.trim()) { err ->
                            ok = err.isBlank()
                            msg = if (err.isBlank()) "✔ ঘোষিত — ওই দিন সবার ছুটি" else "✖ $err"
                            if (err.isBlank()) name = ""
                        }
                    }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) { Text("ছুটি ঘোষণা করুন", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White) }
            Spacer(Modifier.height(5.dp))
            Text(
                "ঘোষণা মাত্র ওই দিন সবার জন্য ছুটি — কেউ অনুপস্থিতও নয়। এক ক্লিকে " +
                    "গোটা কোম্পানির হাজিরার হিসাব বদলে যায়, তাই নাম বাধ্যতামূলক।",
                fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
            )
        }
        msg?.let {
            Spacer(Modifier.height(5.dp))
            Text(it, fontSize = 10.5.sp, color = if (ok) SuccessGreen else DangerRed)
        }
    }
}

/* ── ছোট সহায়ক ─────────────────────────────────────────────────────────── */

@Composable
private fun Step(icon: androidx.compose.ui.graphics.vector.ImageVector, filled: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.size(28.dp).clip(RoundedCornerShape(14.dp))
            .background(if (filled) DarazOrange else Color.White)
            .border(1.dp, if (filled) DarazOrange else HairlineBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) { Icon(icon, contentDescription = null, tint = if (filled) Color.White else TextSecondary, modifier = Modifier.size(15.dp)) }
}

@Composable
private fun Stat(label: String, value: String, ink: Color, bg: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(11.dp)).background(bg).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(label, fontSize = 8.5.sp, color = TextSecondary, maxLines = 1)
        Text(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = ink)
    }
}

@Composable
private fun Mini(label: String, value: Int, ink: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFFF7F8FA)).padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(label, fontSize = 8.5.sp, color = TextSecondary, maxLines = 1)
        Text("$value", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (value > 0) ink else Color(0xFFCBD5E1))
    }
}

@Composable
private fun Card(accent: Color? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color.White)
            .border(1.dp, accent ?: HairlineBorder, RoundedCornerShape(13.dp)).padding(11.dp),
        content = content,
    )
}
