package com.abm.erp.ui.inventory

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.GlassCard
import com.abm.erp.core.ModuleGradientHeader
import com.abm.erp.core.SubModuleGrid
import com.abm.erp.core.SubModuleItem
import com.abm.erp.core.BackToSubMenuLink
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.MockRepository
import com.abm.erp.data.MovementType
import com.abm.erp.theme.*
import kotlinx.coroutines.launch
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

class InventoryViewModel : ViewModel() {
    val stockLevels = InventoryRepository.stockLevels
    val products = InventoryRepository.products
    val warehouses = InventoryRepository.warehouses
    val movements = InventoryRepository.movements
    val categories = InventoryRepository.categories
    val brands = InventoryRepository.brands
    suspend fun stockIn(productId: String, warehouseId: String, qty: Double, reason: String) =
        InventoryRepository.stockIn(productId, warehouseId, qty, reason)
    suspend fun stockOut(productId: String, warehouseId: String, qty: Double, reason: String) =
        InventoryRepository.stockOut(productId, warehouseId, qty, reason)
    fun addProduct(
        sku: String, name: String, unit: String, category: String, reorderThreshold: Double, defaultUnitPrice: Double,
        costPrice: Double = 0.0, photoUri: String?, barcodeValue: String, categoryId: String?, brandId: String?,
        onCreated: (String) -> Unit = {},
    ) = InventoryRepository.addProduct(
            sku = sku, name = name, unit = unit, category = category, reorderThreshold = reorderThreshold,
            defaultUnitPrice = defaultUnitPrice, costPrice = costPrice, photoUri = photoUri,
            barcodeValue = barcodeValue, categoryId = categoryId, brandId = brandId, onCreated = onCreated,
        )
    suspend fun createCategory(name: String) = InventoryRepository.createCategory(name)
    suspend fun createBrand(name: String) = InventoryRepository.createBrand(name)
    suspend fun duplicateProduct(id: String, onRejected: (String) -> Unit = {}) = InventoryRepository.duplicateProduct(id, onRejected)
    suspend fun deleteProduct(id: String, onRejected: (String) -> Unit = {}) = InventoryRepository.deleteProduct(id, onRejected)
    suspend fun restoreProduct(id: String) = InventoryRepository.restoreProduct(id)
    suspend fun adjustStockToCount(productId: String, warehouseId: String, actualCount: Double, reason: String, onRejected: (String) -> Unit = {}) =
        InventoryRepository.adjustStockToCount(productId, warehouseId, actualCount, reason, onRejected)

    // ---- Module 3 gap-fill: Stock Transfer / Damage Tracking / Expiry Tracking ----
    val inventoryLots = InventoryRepository.inventoryLots
    val damageReports = InventoryRepository.damageReports
    val stockTransfers = InventoryRepository.stockTransfers
    suspend fun transferStock(productId: String, productName: String, fromWarehouseId: String, toWarehouseId: String, qty: Double) =
        InventoryRepository.transferStock(productId, productName, fromWarehouseId, toWarehouseId, qty)
    suspend fun reportDamage(productId: String, productName: String, warehouseId: String, qty: Double, reason: String, onRejected: (String) -> Unit = {}) =
        InventoryRepository.reportDamage(productId, productName, warehouseId, qty, reason, onRejected)
    suspend fun stockInWithExpiry(productId: String, warehouseId: String, qty: Double, reason: String, expiryDate: java.time.LocalDateTime?, batchCode: String) =
        InventoryRepository.stockInWithExpiry(productId, warehouseId, qty, reason, expiryDate, batchCode)
}

@Composable
fun InventoryScreen(startTab: Int? = null, onBack: () -> Unit = {}, vm: InventoryViewModel = viewModel()) {
    var tab by remember { mutableStateOf<Int?>(startTab) }
    val subItems = listOf(
        SubModuleItem("levels", "Stock Levels", "📦", 0xFF3DDC97, 0xFF1FA972, Icons.Filled.Inventory2),
        SubModuleItem("move", "Stock In/Out", "🔄", 0xFF4E9CFF, 0xFF2E6FE0, Icons.Filled.SwapHoriz),
        SubModuleItem("add", "Product Directory", "📖", 0xFFFFB020, 0xFFE08A00, Icons.Filled.AddBox),
        SubModuleItem("catbrand", "Category & Brand", "🏷️", 0xFFB45CFF, 0xFF7A2EE0, Icons.Filled.LocalOffer),
        SubModuleItem("adjust", "Stock Adjustment", "⚖️", 0xFFE85D4A, 0xFFC03A2B, Icons.Filled.Balance),
        SubModuleItem("transfer", "Stock Transfer", "🚚", 0xFF3FA9F5, 0xFF1D78C7, Icons.Filled.LocalShipping),
        SubModuleItem("damage", "Damage Tracking", "💥", 0xFFFF5252, 0xFFC62828, Icons.Filled.BrokenImage),
        SubModuleItem("expiry", "Expiry Tracking", "⏳", 0xFFFFB300, 0xFFE08600, Icons.Filled.HourglassBottom),
        SubModuleItem("count", "Stock Count", "🧮", 0xFF6EC6FF, 0xFF2E8FE0, Icons.Filled.Calculate),
        SubModuleItem("intel", "Stock Intelligence", "🧠", 0xFF8A6DFF, 0xFF5B3FE0, Icons.Filled.Psychology),
    )
    val levelsForMini by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
    val productsForMini by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val totalOnHand = levelsForMini.sumOf { it.quantityOnHand }
    val lowStockCount = levelsForMini.count { it.isLowStock }
    val reservedTotal = levelsForMini.sumOf { it.reservedQty }
    Column(Modifier.fillMaxSize()) {
        if (startTab == null) {
        com.abm.erp.core.ModuleWorkspaceHeader("Inventory & Stock Management", "📦", 0xFF12C2A9, 0xFF0E9F8B, iconVector = Icons.Filled.Inventory2, miniDashboard = {
            com.abm.erp.core.ModuleStat("Products", "${productsForMini.size}", TextPrimary)
            com.abm.erp.core.ModuleStat("On Hand", "%.0f".format(totalOnHand), SuccessGreen)
            com.abm.erp.core.ModuleStat("Reserved", "%.0f".format(reservedTotal), WarningAmber)
            com.abm.erp.core.ModuleStat("Low Stock", "$lowStockCount", if (lowStockCount > 0) DangerRed else SuccessGreen) { tab = 0 }
        }, quickActions = {
            AssistChip(onClick = { tab = 4 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.Balance, null, Modifier.size(16.dp)) }, label = { Text("Adjust") })
            AssistChip(onClick = { tab = 5 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.LocalShipping, null, Modifier.size(16.dp)) }, label = { Text("Transfer") })
            AssistChip(onClick = { tab = 8 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.Calculate, null, Modifier.size(16.dp)) }, label = { Text("Count") })
            AssistChip(onClick = { tab = 6 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.BrokenImage, null, Modifier.size(16.dp)) }, label = { Text("Damage") })
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("StockAdjustment", "StockTransfer", "DamageReport", "Product", "StockCount"))
        })
        } else {
            val taskTitle = subItems.firstOrNull { key -> when (key.key) { "levels" -> tab == 0; "move" -> tab == 1; "add" -> tab == 2; "catbrand" -> tab == 3; "adjust" -> tab == 4; "transfer" -> tab == 5; "damage" -> tab == 6; "expiry" -> tab == 7; "count" -> tab == 8; else -> tab == 9 } }?.label ?: "Inventory"
            com.abm.erp.core.TaskHeader(taskTitle, 0xFF12C2A9, 0xFF0E9F8B, onBack = onBack, iconVector = Icons.Filled.Inventory2)
        }
        Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Real-time stock across warehouses", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        if (tab == null) {
            SubModuleGrid(subItems) { key -> tab = when (key) { "levels" -> 0; "move" -> 1; "add" -> 2; "catbrand" -> 3; "adjust" -> 4; "transfer" -> 5; "damage" -> 6; "expiry" -> 7; "count" -> 8; else -> 9 } }
        } else {
            if (startTab == null) BackToSubMenuLink(onClick = { tab = null })
            when (tab) {
                0 -> StockLevelsTab(vm)
                1 -> StockMovementTab(vm)
                2 -> AddProductTab(vm)
                3 -> CategoryBrandTab(vm)
                4 -> StockAdjustmentTab(vm)
                5 -> StockTransferTab(vm)
                6 -> DamageTrackingTab(vm)
                7 -> ExpiryTrackingTab(vm)
                8 -> StockCountTab(vm)
                else -> StockIntelligenceTab()
            }
        }
        }
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun StockLevelsTab(vm: InventoryViewModel) {
    val levels by vm.stockLevels.collectAsState()
    val movements by vm.movements.collectAsState()
    val products by vm.products.collectAsState()
    val brands by com.abm.erp.data.InventoryRepository.brands.collectAsState()
    val lots by com.abm.erp.data.InventoryRepository.inventoryLots.collectAsState()
    val nearExpiryLots = remember(lots) {
        val cutoff = java.time.LocalDateTime.now().plusDays(30)
        lots.filter { it.expiryDate != null && it.expiryDate.isBefore(cutoff) && it.expiryDate.isAfter(java.time.LocalDateTime.now()) && it.qtyRemaining > 0 }
            .sortedBy { it.expiryDate }
    }
    var category by remember { mutableStateOf(com.abm.erp.data.StockCategory.STORE) }
    val filtered = levels.filter { it.stockCategory == category }
    val lowCount = filtered.count { it.isLowStock }
    val outOfStockCount = filtered.count { it.quantityOnHand <= 0.0 }
    // "Overstock" heuristic: 3x reorder threshold — no separate max-stock field exists on StockLevelView, so this is documented as a heuristic, not a stored business rule.
    val overstockCount = filtered.count { it.reorderThreshold > 0 && it.quantityOnHand > it.reorderThreshold * 3 }
    val thirtyDaysAgo = java.time.LocalDateTime.now().minusDays(30)
    val recentOutQty = remember(movements) {
        movements.filter { it.type == com.abm.erp.data.MovementType.OUT && it.timestamp.isAfter(thirtyDaysAgo) }
            .groupBy { it.productId }.mapValues { (_, m) -> m.sumOf { it.quantity } }
    }
    val fastMoving = filtered.filter { (recentOutQty[it.productId] ?: 0.0) > it.reorderThreshold }
    val slowMoving = filtered.filter { (recentOutQty[it.productId] ?: 0.0) <= 0.0 }
    val ninetyDaysAgo = java.time.LocalDateTime.now().minusDays(90)
    val movedLast90d = remember(movements) { movements.filter { it.timestamp.isAfter(ninetyDaysAgo) }.map { it.productId }.toSet() }
    val deadStock = filtered.filter { it.productId !in movedLast90d && it.quantityOnHand > 0 }
    val reorderSuggestions = filtered.filter { it.isLowStock }.map { it.productName to (it.reorderThreshold * 2 - it.quantityOnHand).coerceAtLeast(0.0) }
    var showAnalysis by remember { mutableStateOf<String?>(null) } // "abc" | "dead" | "reorder" | "warehouse" | null
    var searchQuery by remember { mutableStateOf("") }
    var warehouseFilter by remember { mutableStateOf<String?>(null) }
    var brandFilter by remember { mutableStateOf<String?>(null) }
    var statusFilter by remember { mutableStateOf<String?>(null) } // null=All, "IN"/"LOW"/"OUT"/"OVER"
    var showMovers by remember { mutableStateOf<String?>(null) } // "fast" | "slow" | null

    val warehouses = remember(filtered) { filtered.map { it.warehouseName }.distinct().sorted() }
    val productByIdMap = remember(products) { products.associateBy { it.id } }
    val brandByIdMap = remember(brands) { brands.associateBy { it.id } }
    // ABC Analysis — ranked by real stock value (qty * unit price); cumulative-value classification, standard 80/15/5 split.
    val abcRanked = remember(filtered, products) {
        val withValue = filtered.mapNotNull { level ->
            val price = productByIdMap[level.productId]?.defaultUnitPrice ?: return@mapNotNull null
            Triple(level.productName, price * level.quantityOnHand, level)
        }.sortedByDescending { it.second }
        val total = withValue.sumOf { it.second }.coerceAtLeast(0.01)
        var cumulative = 0.0
        withValue.map { (name, value, _) ->
            cumulative += value
            val pct = cumulative / total * 100
            val cls = if (pct <= 80) "A" else if (pct <= 95) "B" else "C"
            Triple(name, value, cls)
        }
    }
    val warehousePerformance = remember(filtered, products) {
        filtered.groupBy { it.warehouseName }.mapValues { (_, levels) ->
            levels.sumOf { level -> (productByIdMap[level.productId]?.defaultUnitPrice ?: 0.0) * level.quantityOnHand }
        }.entries.sortedByDescending { it.value }
    }

    Column {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Inventory Overview", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Column { Text("Total Items", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${filtered.size}", fontWeight = FontWeight.Bold) }
                Column { Text("Low Stock", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("$lowCount", fontWeight = FontWeight.Bold, color = WarningAmber) }
                Column { Text("Out of Stock", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("$outOfStockCount", fontWeight = FontWeight.Bold, color = DangerRed) }
                Column { Text("Overstock", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("$overstockCount", fontWeight = FontWeight.Bold, color = Sky) }
                Column(Modifier.clickable { showMovers = if (showMovers == "fast") null else "fast" }) { Text("Fast Moving (30d)", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${fastMoving.size}", fontWeight = FontWeight.Bold, color = SuccessGreen) }
                Column(Modifier.clickable { showMovers = if (showMovers == "slow") null else "slow" }) { Text("Slow Moving (30d)", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${slowMoving.size}", fontWeight = FontWeight.Bold, color = TextSecondary) }
            }
        }
        if (showMovers != null) {
            Spacer(Modifier.height(8.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(if (showMovers == "fast") "Fast Moving Items" else "Slow Moving Items", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                val list = if (showMovers == "fast") fastMoving else slowMoving
                if (list.isEmpty()) {
                    Text("এই মুহূর্তে কোনো আইটেম নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                } else {
                    list.forEach { l -> Text("${l.productName} — ${"%.1f".format(recentOutQty[l.productId] ?: 0.0)} ${l.unit} sold (30d)", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            FilterChip(selected = showAnalysis == "abc", onClick = { showAnalysis = if (showAnalysis == "abc") null else "abc" }, label = { Text("ABC Analysis") })
            FilterChip(selected = showAnalysis == "dead", onClick = { showAnalysis = if (showAnalysis == "dead") null else "dead" }, label = { Text("Dead Stock (${deadStock.size})") })
            FilterChip(selected = showAnalysis == "reorder", onClick = { showAnalysis = if (showAnalysis == "reorder") null else "reorder" }, label = { Text("Reorder Suggestions") })
            FilterChip(selected = showAnalysis == "warehouse", onClick = { showAnalysis = if (showAnalysis == "warehouse") null else "warehouse" }, label = { Text("Warehouse Performance") })
        }
        if (showAnalysis != null) {
            Spacer(Modifier.height(8.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                when (showAnalysis) {
                    "abc" -> {
                        Text("ABC Analysis (by stock value)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        if (abcRanked.isEmpty()) {
                            Text("Not enough data to rank by value.", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                        } else {
                            abcRanked.take(15).forEach { (name, value, cls) ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("[$cls] $name", style = MaterialTheme.typography.bodySmall)
                                    Text("৳${"%,.0f".format(value)}", style = MaterialTheme.typography.bodySmall, color = when (cls) { "A" -> SuccessGreen; "B" -> WarningAmber; else -> TextSecondary })
                                }
                            }
                        }
                    }
                    "dead" -> {
                        Text("Dead Stock", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        if (deadStock.isEmpty()) {
                            Text("No dead stock.", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                        } else {
                            deadStock.forEach { l -> Text("${l.productName} — ${l.quantityOnHand} ${l.unit} (${l.warehouseName})", style = MaterialTheme.typography.bodySmall, color = DangerRed) }
                        }
                    }
                    "reorder" -> {
                        Text("Reorder Suggestions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        if (reorderSuggestions.isEmpty()) {
                            Text("No reorder needed right now.", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                        } else {
                            reorderSuggestions.forEach { (name, qty) -> Text("$name — suggested order: ${"%.0f".format(qty)}", style = MaterialTheme.typography.bodySmall, color = WarningAmber) }
                        }
                    }
                    "warehouse" -> {
                        Text("Warehouse Performance (stock value)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        if (warehousePerformance.isEmpty()) {
                            Text("No data.", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                        } else {
                            warehousePerformance.forEach { (wh, value) ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(wh, style = MaterialTheme.typography.bodySmall)
                                    Text("৳${"%,.0f".format(value)}", style = MaterialTheme.typography.bodySmall, color = ElectricCyan)
                                }
                            }
                        }
                    }
                }
            }
        }
        OutlinedTextField(
            value = searchQuery, onValueChange = { searchQuery = it },
            placeholder = { Text("Product/warehouse খুঁজুন…") }, singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            com.abm.erp.data.StockCategory.values().forEach { c ->
                FilterChip(
                    selected = category == c,
                    onClick = { category = c },
                    label = { Text(if (c == com.abm.erp.data.StockCategory.STORE) "Store" else "Production") },
                    modifier = Modifier.weight(1f),
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            FilterChip(selected = statusFilter == null, onClick = { statusFilter = null }, label = { Text("All") })
            FilterChip(selected = statusFilter == "IN", onClick = { statusFilter = "IN" }, label = { Text("In Stock") })
            FilterChip(selected = statusFilter == "LOW", onClick = { statusFilter = "LOW" }, label = { Text("Low Stock") })
            FilterChip(selected = statusFilter == "OUT", onClick = { statusFilter = "OUT" }, label = { Text("Out of Stock") })
            FilterChip(selected = statusFilter == "OVER", onClick = { statusFilter = "OVER" }, label = { Text("Overstock") })
        }
        if (warehouses.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                FilterChip(selected = warehouseFilter == null, onClick = { warehouseFilter = null }, label = { Text("All Warehouses") })
                warehouses.forEach { w -> FilterChip(selected = warehouseFilter == w, onClick = { warehouseFilter = w }, label = { Text(w) }) }
            }
        }
        if (brands.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                FilterChip(selected = brandFilter == null, onClick = { brandFilter = null }, label = { Text("All Brands") })
                brands.forEach { b -> FilterChip(selected = brandFilter == b.id, onClick = { brandFilter = b.id }, label = { Text(b.name) }) }
            }
        }
        Spacer(Modifier.height(10.dp))
        val searched = remember(filtered, searchQuery, warehouseFilter, brandFilter, statusFilter) {
            filtered.filter { level ->
                (searchQuery.isBlank() || level.productName.contains(searchQuery, ignoreCase = true) || level.warehouseName.contains(searchQuery, ignoreCase = true)) &&
                    (warehouseFilter == null || level.warehouseName == warehouseFilter) &&
                    (brandFilter == null || productByIdMap[level.productId]?.brandId == brandFilter) &&
                    (statusFilter == null || when (statusFilter) {
                        "OUT" -> level.quantityOnHand <= 0.0
                        "LOW" -> level.isLowStock && level.quantityOnHand > 0.0
                        "OVER" -> level.reorderThreshold > 0 && level.quantityOnHand > level.reorderThreshold * 3
                        else -> !level.isLowStock && level.quantityOnHand > 0.0
                    })
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (lowCount > 0) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text("⚠ $lowCount item(s) at or below reorder level", color = WarningAmber, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            if (nearExpiryLots.isNotEmpty()) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text("⏳ ${nearExpiryLots.size} lot(s) expiring within 30 days", color = DangerRed, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        nearExpiryLots.take(5).forEach { lot ->
                            val pName = productByIdMap[lot.productId]?.name ?: lot.productId
                            Text("$pName — batch ${lot.batchCode}: ${lot.expiryDate?.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                }
            }
            items(searched) { level ->
                val product = productByIdMap[level.productId]
                // Stock value only shown when a real unit cost (Product.defaultUnitPrice) exists — never fabricated.
                val stockValue = product?.let { it.defaultUnitPrice * level.quantityOnHand }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(level.productName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(level.warehouseName, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            if (product?.brandId != null) {
                                Text(brandByIdMap[product.brandId]?.name ?: "", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(horizontalAlignment = Alignment.End) {
                                // Blueprint §29 — WMS figures line up down a column: bold value,
                                // unit carried in the secondary colour beside it.
                                com.abm.erp.core.FigureCell(
                                    value = "%.1f".format(level.quantityOnHand),
                                    unit = level.unit,
                                    color = if (level.isLowStock) DangerRed else SuccessGreen,
                                )
                                if (level.reservedQty > 0) {
                                    Text("Reserved: ${"%.1f".format(level.reservedQty)} · Available: ${"%.1f".format(level.availableQty)}", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                                }
                                if (level.isLowStock) {
                                    Text("below reorder (${"%.0f".format(level.reorderThreshold)})", style = MaterialTheme.typography.labelSmall, color = DangerRed)
                                }
                                if (stockValue != null) {
                                    Text("৳${"%,.0f".format(stockValue)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                }
                            }
                            com.abm.erp.core.UniversalActionMenu(
                                moduleReference = "StockLevel", entityId = "${level.productId}_${level.warehouseId}", entityLabel = level.productName,
                                shareText = "${level.productName} — ${level.warehouseName}\nQty: ${level.quantityOnHand} ${level.unit}" + (stockValue?.let { "\nValue: ৳${"%.0f".format(it)}" } ?: ""),
                                csvHeader = "Product,Warehouse,Qty,Unit,Value", csvRow = com.abm.erp.core.toCsvRow(level.productName, level.warehouseName, level.quantityOnHand, level.unit, stockValue ?: ""),
                                historyLabel = "Stock History",
                                historyItems = movements.filter { it.productId == level.productId && it.warehouseId == level.warehouseId }
                                    .sortedByDescending { it.timestamp }.take(20)
                                    .map { "${it.type} ${it.quantity} ${level.unit} — ${it.reason} (${it.timestamp.toLocalDate()})" },
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    val pct = if (level.reorderThreshold > 0) (level.quantityOnHand / (level.reorderThreshold * 2)).coerceIn(0.0, 1.0) else 0.5
                    val barColor = when { level.quantityOnHand <= level.reorderThreshold -> DangerRed; level.quantityOnHand <= level.reorderThreshold * 1.5 -> WarningAmber; else -> SuccessGreen }
                    Box(Modifier.fillMaxWidth().height(6.dp).background(Color(0xFFEEF1F5), androidx.compose.foundation.shape.RoundedCornerShape(999.dp))) {
                        Box(Modifier.fillMaxWidth(pct.toFloat()).fillMaxHeight().background(barColor, androidx.compose.foundation.shape.RoundedCornerShape(999.dp)))
                    }
                }
            }
            if (searched.isEmpty()) {
                item { Text("এই ফিল্টারে কোনো আইটেম পাওয়া যায়নি।", color = TextSecondary) }
            }
        }
    }
}

@Composable
private fun StockMovementTab(vm: InventoryViewModel) {
    val products by vm.products.collectAsState()
    val warehouses by vm.warehouses.collectAsState()
    val movements by vm.movements.collectAsState()
    val scope = rememberCoroutineScope()

    var selectedProduct by remember { mutableStateOf<String?>(null) }
    var selectedWarehouse by remember { mutableStateOf<String?>(null) }
    var qtyText by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Record stock movement", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))

                Text("Product", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                DropdownPicker(
                    options = products.map { it.id to it.name },
                    selectedId = selectedProduct,
                    onSelect = { selectedProduct = it },
                )
                Spacer(Modifier.height(8.dp))

                Text("Warehouse", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                DropdownPicker(
                    options = warehouses.map { it.id to it.name },
                    selectedId = selectedWarehouse,
                    onSelect = { selectedWarehouse = it },
                )
                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = qtyText, onValueChange = { qtyText = it },
                    label = { Text("Quantity") }, modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = reason, onValueChange = { reason = it },
                    label = { Text("Reason (e.g. Dealer fulfillment, Purchase)") }, modifier = Modifier.fillMaxWidth(),
                )
                errorMsg?.let {
                    Spacer(Modifier.height(4.dp))
                    Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val qty = qtyText.toDoubleOrNull()
                            if (selectedProduct == null || selectedWarehouse == null || qty == null || qty <= 0.0) {
                                errorMsg = "Select product, warehouse, and a valid quantity."
                                return@Button
                            }
                            errorMsg = null
                            scope.launch { vm.stockIn(selectedProduct!!, selectedWarehouse!!, qty, reason.ifBlank { "Stock in" }) }
                            qtyText = ""; reason = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                    ) { Text("Stock IN") }

                    Button(
                        onClick = {
                            val qty = qtyText.toDoubleOrNull()
                            if (selectedProduct == null || selectedWarehouse == null || qty == null || qty <= 0.0) {
                                errorMsg = "Select product, warehouse, and a valid quantity."
                                return@Button
                            }
                            scope.launch {
                                val ok = vm.stockOut(selectedProduct!!, selectedWarehouse!!, qty, reason.ifBlank { "Stock out" })
                                errorMsg = if (ok) null else "Not enough stock on hand for this warehouse."
                                if (ok) { qtyText = ""; reason = "" }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                    ) { Text("Stock OUT") }
                }
            }
        }
        item { Text("Movement history", style = MaterialTheme.typography.titleMedium) }
        items(movements) { m ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("${m.productName} · ${m.warehouseName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(m.reason, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    Text(
                        "${if (m.type == MovementType.IN) "+" else "−"}${"%.1f".format(m.quantity)}",
                        color = if (m.type == MovementType.IN) SuccessGreen else DangerRed,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}

@Composable
private fun AddProductTab(vm: InventoryViewModel) {
    // v113-221 — the person's own explicit reasoning: Product's base
    // identity (Add/Edit) needs to live ONLY in the Chairman module,
    // otherwise it's never actually "locked" — anyone with regular
    // Inventory access could keep changing it. This tab stays in place
    // (removing it outright would have shifted every other tab's index
    // in this same sub-module grid) but now points to where the real
    // capability lives, rather than duplicating it here.
    val products by vm.products.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        com.abm.erp.core.WorkspaceEmptyState(
            "Product Add/Edit এখন শুধু Chairman module থেকে হয় — Home → Chairman → Product-এ যান।",
            "🔒",
        )
        Spacer(Modifier.height(16.dp))
        Text("Product Directory (${products.size}) — শুধু দেখার জন্য", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(products.filter { !it.isDeleted }, key = { it.id }) { p ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (!p.photoUri.isNullOrBlank()) {
                                coil.compose.AsyncImage(
                                    model = p.photoUri, contentDescription = p.name,
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                    modifier = Modifier.size(40.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp)),
                                )
                                Spacer(Modifier.width(10.dp))
                            }
                            Column {
                                Text(p.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                Text("${p.sku} · ${p.category.ifBlank { "—" }} · ৳${"%,.0f".format(p.defaultUnitPrice)}/${p.unit}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryBrandTab(vm: InventoryViewModel) {
    val categories by vm.categories.collectAsState()
    val brands by vm.brands.collectAsState()
    var newCategory by remember { mutableStateOf("") }
    var newBrand by remember { mutableStateOf("") }
    val catBrandScope = rememberCoroutineScope()

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Categories (${categories.size})", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                categories.forEach { c ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("• ${c.name}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 2.dp))
                        com.abm.erp.core.UniversalActionMenu(moduleReference = "Category", entityId = c.id, entityLabel = c.name, shareText = "Category: ${c.name}", csvHeader = "Name", csvRow = c.name)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = newCategory, onValueChange = { newCategory = it }, label = { Text("New category") }, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { if (newCategory.isNotBlank()) { catBrandScope.launch { vm.createCategory(newCategory) }; newCategory = "" } }) { Text("+ Add") }
                }
            }
        }
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Brands (${brands.size})", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                brands.forEach { b ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("• ${b.name}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 2.dp))
                        com.abm.erp.core.UniversalActionMenu(moduleReference = "Brand", entityId = b.id, entityLabel = b.name, shareText = "Brand: ${b.name}", csvHeader = "Name", csvRow = b.name)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = newBrand, onValueChange = { newBrand = it }, label = { Text("New brand") }, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { if (newBrand.isNotBlank()) { catBrandScope.launch { vm.createBrand(newBrand) }; newBrand = "" } }) { Text("+ Add") }
                }
            }
        }
        item {
            // v113-236 — a real gap found in the same proactive sweep as
            // Payroll's own generation gap: InventoryRepository.addWarehouse
            // was fully real and working, with zero UI callers anywhere —
            // no screen let anyone actually create a new warehouse, even
            // though warehouses are referenced pervasively across
            // Inventory/Purchase/Production (stock transfers, GRN
            // receiving, carton warehouse-receive all need a real
            // warehouseId to point at). Same simple quick-add pattern as
            // Category/Brand right above, for the same reason: this is
            // reference data, not a complex entity needing its own screen.
            val warehouses by com.abm.erp.data.InventoryRepository.warehouses.collectAsState()
            var newWarehouseName by remember { mutableStateOf("") }
            var newWarehouseZone by remember { mutableStateOf("") }
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Warehouses (${warehouses.size})", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                warehouses.forEach { w ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("• ${w.name}", style = MaterialTheme.typography.bodyMedium)
                            Text(listOfNotNull(w.zone.ifBlank { null }, w.stockCategory.name).joinToString(" · "), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = newWarehouseName, onValueChange = { newWarehouseName = it }, label = { Text("নতুন Warehouse-এর নাম") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = newWarehouseZone, onValueChange = { newWarehouseZone = it }, label = { Text("Zone") }, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        if (newWarehouseName.isNotBlank()) {
                            catBrandScope.launch { com.abm.erp.data.InventoryRepository.addWarehouse(newWarehouseName.trim(), newWarehouseZone.trim()) }
                            newWarehouseName = ""; newWarehouseZone = ""
                        }
                    }) { Text("+ Add") }
                }
            }
        }
    }
}

@Composable
private fun StockAdjustmentTab(vm: InventoryViewModel) {
    val products by vm.products.collectAsState()
    val warehouses by vm.warehouses.collectAsState()
    val stockLevels by vm.stockLevels.collectAsState()
    var selectedProduct by remember { mutableStateOf<String?>(null) }
    var selectedWarehouse by remember { mutableStateOf<String?>(null) }
    var actualCountText by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var confirmMsg by remember { mutableStateOf<String?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }
    val submitScope = androidx.compose.runtime.rememberCoroutineScope()
    val currentOnHand = stockLevels.firstOrNull { it.productId == selectedProduct && it.warehouseId == selectedWarehouse }?.quantityOnHand

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Stock count reconciliation", style = MaterialTheme.typography.titleMedium)
        Text("ফিজিক্যাল গণনার সংখ্যা দিন — সিস্টেম নিজে থেকে পার্থক্যটা হিসাব করে adjust করবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(10.dp))
        Text("Product", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
        DropdownPicker(options = products.map { it.id to it.name }, selectedId = selectedProduct, onSelect = { selectedProduct = it })
        Spacer(Modifier.height(8.dp))
        Text("Warehouse", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
        DropdownPicker(options = warehouses.map { it.id to it.name }, selectedId = selectedWarehouse, onSelect = { selectedWarehouse = it })
        Spacer(Modifier.height(8.dp))
        currentOnHand?.let { Text("System-এ এখন আছে: ${"%.1f".format(it)}", style = MaterialTheme.typography.bodySmall, color = TextSecondary) }
        OutlinedTextField(value = actualCountText, onValueChange = { actualCountText = it }, label = { Text("Actual counted quantity") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason (e.g. Monthly stock-take)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        confirmMsg?.let { Text(it, color = if (it.startsWith("✓")) SuccessGreen else DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(bottom = 8.dp)) }
        Button(
            onClick = {
                if (isSubmitting) return@Button
                val actual = actualCountText.toDoubleOrNull() ?: return@Button
                val p = selectedProduct ?: return@Button
                val w = selectedWarehouse ?: return@Button
                isSubmitting = true
                submitScope.launch {
                    var rejectReason: String? = null
                    val ok = vm.adjustStockToCount(p, w, actual, reason, onRejected = { r -> rejectReason = r })
                    isSubmitting = false
                    if (ok) {
                        confirmMsg = "✓ Adjustment recorded"
                        actualCountText = ""; reason = ""
                    } else {
                        confirmMsg = "✗ " + (rejectReason ?: "Adjustment ব্যর্থ হয়েছে।")
                    }
                }
            },
            enabled = !isSubmitting && selectedProduct != null && selectedWarehouse != null && actualCountText.toDoubleOrNull() != null,
            colors = ButtonDefaults.buttonColors(containerColor = WarningAmber),
        ) { Text("Apply Adjustment") }
    }
}

@Composable
private fun DropdownPicker(options: List<Pair<String, String>>, selectedId: String?, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val label = options.firstOrNull { it.first == selectedId }?.second ?: "Select…"
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(label) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { (id, name) ->
                DropdownMenuItem(text = { Text(name) }, onClick = { onSelect(id); expanded = false })
            }
        }
    }
}

@Composable
private fun StockTransferTab(vm: InventoryViewModel) {
    val products by vm.products.collectAsState()
    val warehouses by vm.warehouses.collectAsState()
    val transfers by vm.stockTransfers.collectAsState()
    val scope = rememberCoroutineScope()
    var selectedProduct by remember { mutableStateOf<String?>(null) }
    var fromWarehouse by remember { mutableStateOf<String?>(null) }
    var toWarehouse by remember { mutableStateOf<String?>(null) }
    var qtyText by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    Column {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Transfer stock between warehouses", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            Text("Product", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            DropdownPicker(options = products.map { it.id to it.name }, selectedId = selectedProduct, onSelect = { selectedProduct = it })
            Spacer(Modifier.height(8.dp))
            Text("From warehouse", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            DropdownPicker(options = warehouses.map { it.id to it.name }, selectedId = fromWarehouse, onSelect = { fromWarehouse = it })
            Spacer(Modifier.height(8.dp))
            Text("To warehouse", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            DropdownPicker(options = warehouses.map { it.id to it.name }, selectedId = toWarehouse, onSelect = { toWarehouse = it })
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Quantity") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            message?.let { Text(it, color = if (it.startsWith("✓")) SuccessGreen else DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(bottom = 8.dp)) }
            Button(
                onClick = {
                    val qty = qtyText.toDoubleOrNull() ?: return@Button
                    val p = products.firstOrNull { it.id == selectedProduct } ?: return@Button
                    val from = fromWarehouse ?: return@Button
                    val to = toWarehouse ?: return@Button
                    if (from == to) { message = "উৎস আর গন্তব্য warehouse একই হতে পারবে না।"; return@Button }
                    scope.launch {
                        val ok = vm.transferStock(p.id, p.name, from, to, qty)
                        message = if (ok) "✓ Transfer সম্পন্ন" else "যথেষ্ট স্টক নেই উৎস warehouse-এ।"
                        if (ok) { qtyText = "" }
                    }
                },
                enabled = selectedProduct != null && fromWarehouse != null && toWarehouse != null && qtyText.toDoubleOrNull() != null,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Transfer") }
        }
        Spacer(Modifier.height(14.dp))
        Text("Recent transfers", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(transfers) { t ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${t.productName} × ${"%.1f".format(t.qty)}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${t.fromWarehouseId} → ${t.toWarehouseId} · by ${t.createdBy}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        com.abm.erp.core.UniversalActionMenu(moduleReference = "StockTransfer", entityId = t.id, entityLabel = t.productName, shareText = "Transfer: ${t.productName} × ${t.qty}\n${t.fromWarehouseId} → ${t.toWarehouseId}", csvHeader = "Product,Qty,From,To", csvRow = com.abm.erp.core.toCsvRow(t.productName, t.qty, t.fromWarehouseId, t.toWarehouseId))
                    }
                }
            }
        }
    }
}

@Composable
private fun DamageTrackingTab(vm: InventoryViewModel) {
    val products by vm.products.collectAsState()
    val warehouses by vm.warehouses.collectAsState()
    val reports by vm.damageReports.collectAsState()
    var selectedProduct by remember { mutableStateOf<String?>(null) }
    var selectedWarehouse by remember { mutableStateOf<String?>(null) }
    var qtyText by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }
    val submitScope = androidx.compose.runtime.rememberCoroutineScope()

    Column {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Report damaged stock", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            Text("Product", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            DropdownPicker(options = products.map { it.id to it.name }, selectedId = selectedProduct, onSelect = { selectedProduct = it })
            Spacer(Modifier.height(8.dp))
            Text("Warehouse", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            DropdownPicker(options = warehouses.map { it.id to it.name }, selectedId = selectedWarehouse, onSelect = { selectedWarehouse = it })
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Quantity damaged") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            message?.let { Text(it, color = if (it.startsWith("✓")) SuccessGreen else DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(bottom = 8.dp)) }
            Button(
                onClick = {
                    if (isSubmitting) return@Button
                    val qty = qtyText.toDoubleOrNull() ?: return@Button
                    val p = products.firstOrNull { it.id == selectedProduct } ?: return@Button
                    val w = selectedWarehouse ?: return@Button
                    isSubmitting = true
                    submitScope.launch {
                        var rejectReason: String? = null
                        val ok = vm.reportDamage(p.id, p.name, w, qty, reason, onRejected = { r -> rejectReason = r })
                        isSubmitting = false
                        message = if (ok) "✓ Damage report লেখা হয়েছে, স্টক থেকে বাদ" else (rejectReason ?: "রিপোর্ট করা যায়নি।")
                        if (ok) { qtyText = ""; reason = "" }
                    }
                },
                enabled = !isSubmitting && selectedProduct != null && selectedWarehouse != null && qtyText.toDoubleOrNull() != null,
                colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Report Damage") }
        }
        Spacer(Modifier.height(14.dp))
        Text("Damage history", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(reports) { r ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${r.productName} × ${"%.1f".format(r.qty)}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${r.reason} · by ${r.reportedBy}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        com.abm.erp.core.UniversalActionMenu(moduleReference = "DamageReport", entityId = r.id, entityLabel = r.productName, shareText = "Damage: ${r.productName} × ${r.qty}\nReason: ${r.reason}", csvHeader = "Product,Qty,Reason", csvRow = com.abm.erp.core.toCsvRow(r.productName, r.qty, r.reason))
                    }
                }
            }
        }
    }
}

@Composable
private fun ExpiryTrackingTab(vm: InventoryViewModel) {
    val products by vm.products.collectAsState()
    val warehouses by vm.warehouses.collectAsState()
    val lots by vm.inventoryLots.collectAsState()
    var selectedProduct by remember { mutableStateOf<String?>(null) }
    var selectedWarehouse by remember { mutableStateOf<String?>(null) }
    var qtyText by remember { mutableStateOf("") }
    var batchCode by remember { mutableStateOf("") }
    var expiryDays by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    val now = java.time.LocalDateTime.now()
    val expiryScope = rememberCoroutineScope()
    val soonExpiring = lots.filter { it.expiryDate != null && it.expiryDate.isBefore(now.plusDays(30)) && it.qtyRemaining > 0 }

    Column {
        if (soonExpiring.isNotEmpty()) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("⚠ ৩০ দিনের মধ্যে মেয়াদ শেষ হবে (${soonExpiring.size})", color = WarningAmber, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                soonExpiring.forEach { lot ->
                    val pname = products.firstOrNull { it.id == lot.productId }?.name ?: lot.productId
                    Text("$pname — batch ${lot.batchCode} · ${"%.1f".format(lot.qtyRemaining)} left · expires ${lot.expiryDate?.toLocalDate()}", style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Stock-in with expiry (perishable goods)", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            Text("Product", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            DropdownPicker(options = products.map { it.id to it.name }, selectedId = selectedProduct, onSelect = { selectedProduct = it })
            Spacer(Modifier.height(8.dp))
            Text("Warehouse", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            DropdownPicker(options = warehouses.map { it.id to it.name }, selectedId = selectedWarehouse, onSelect = { selectedWarehouse = it })
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Quantity") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = batchCode, onValueChange = { batchCode = it }, label = { Text("Batch code (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = expiryDays, onValueChange = { expiryDays = it }, label = { Text("মেয়াদ শেষ — কত দিন পরে (সংখ্যা)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            message?.let { Text(it, color = SuccessGreen, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(bottom = 8.dp)) }
            Button(
                onClick = {
                    val qty = qtyText.toDoubleOrNull() ?: return@Button
                    val p = selectedProduct ?: return@Button
                    val w = selectedWarehouse ?: return@Button
                    val days = expiryDays.toLongOrNull()
                    val expiry = days?.let { now.plusDays(it) }
                    expiryScope.launch { vm.stockInWithExpiry(p, w, qty, "Perishable stock-in", expiry, batchCode) }
                    message = "✓ Stock-in সম্পন্ন, expiry tracked"
                    qtyText = ""; batchCode = ""; expiryDays = ""
                },
                enabled = selectedProduct != null && selectedWarehouse != null && qtyText.toDoubleOrNull() != null,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Stock In") }
        }
    }
}

/** v86, Module 6 — Stock-Count workflow UI: create draft with counted quantities vs system quantities, submit, approve (applies real adjustment). */
@Composable
private fun StockCountTab(vm: InventoryViewModel) {
    val counts by com.abm.erp.data.InventoryRepository.stockCounts.collectAsState()
    val levels by vm.stockLevels.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    val countScope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Stock Count") }
        Spacer(Modifier.height(10.dp))
        if (counts.isEmpty()) {
            Text("এখনো কোনো Stock Count নেই।", color = TextSecondary)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(counts, key = { it.id }) { c ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${c.countNo} — ${c.warehouseName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(c.status, color = when (c.status) { "ADJUSTED" -> SuccessGreen; "APPROVED" -> Sky; else -> WarningAmber }, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                com.abm.erp.core.UniversalActionMenu(
                                    moduleReference = "StockCount", entityId = c.id, entityLabel = c.countNo,
                                    shareText = "${c.countNo} — ${c.warehouseName} — ${c.status}",
                                    csvHeader = "CountNo,Warehouse,Status", csvRow = com.abm.erp.core.toCsvRow(c.countNo, c.warehouseName, c.status),
                                )
                            }
                        }
                        c.lines.forEach { l ->
                            val diff = l.countedQty - l.systemQty
                            Text("${l.productName}: system ${l.systemQty} → counted ${l.countedQty} (${if (diff >= 0) "+" else ""}${"%.1f".format(diff)})", style = MaterialTheme.typography.labelSmall, color = if (diff != 0.0) WarningAmber else TextSecondary)
                        }
                        var showVarianceReport by remember { mutableStateOf(false) }
                        TextButton(onClick = { showVarianceReport = true }) { Text("📊 Variance Report") }
                        if (showVarianceReport) {
                            val report = remember(c.id) { com.abm.erp.data.InventoryRepository.computeVarianceReport(c) }
                            androidx.compose.ui.window.Dialog(onDismissRequest = { showVarianceReport = false }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp).heightIn(max = 500.dp).imePadding().verticalScroll(rememberScrollState())) {
                                        Text("Variance Report — ${report.countNo}", style = MaterialTheme.typography.titleMedium)
                                        Text("${report.warehouseName} · ${report.significantVarianceCount} significant variance(s)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                        Text("Total variance value: ৳${"%,.0f".format(report.totalVarianceValue)}", style = MaterialTheme.typography.bodyMedium, color = if (report.totalVarianceValue < 0) DangerRed else SuccessGreen)
                                        Spacer(Modifier.height(10.dp))
                                        if (report.lines.isEmpty()) {
                                            Text("কোনো variance পাওয়া যায়নি — physical count system-এর সাথে পুরোপুরি মিলেছে।", color = SuccessGreen)
                                        } else {
                                            report.lines.forEach { line ->
                                                Column(Modifier.padding(vertical = 4.dp)) {
                                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                                        Text("${line.productName}${line.batchCode?.let { " (batch: $it)" } ?: ""}", fontWeight = FontWeight.SemiBold)
                                                        Text(line.severity, color = when (line.severity) { "HIGH" -> DangerRed; "MEDIUM" -> WarningAmber; else -> TextSecondary }, style = MaterialTheme.typography.labelSmall)
                                                    }
                                                    Text("System: ${line.systemQty} → Counted: ${line.countedQty} (${"%+.1f".format(line.varianceQty)}, ${"%+.1f".format(line.variancePct)}%)", style = MaterialTheme.typography.labelSmall)
                                                    if (line.systemCartons != 0 || line.countedCartons != 0) {
                                                        Text("Cartons — System: ${line.systemCartons} → Counted: ${line.countedCartons} (${"%+d".format(line.varianceCartons)})", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (c.status == "DRAFT") {
                            TextButton(onClick = { countScope.launch { com.abm.erp.data.InventoryRepository.submitStockCount(c.id) } }) { Text("Submit") }
                        }
                        if (c.status == "SUBMITTED" && com.abm.erp.data.PermissionManager.canCurrentUser("inv", com.abm.erp.data.PermissionAction.APPROVE)) {
                            var approveCountError by remember(c.id) { mutableStateOf<String?>(null) }
                            approveCountError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                            Button(onClick = { countScope.launch { com.abm.erp.data.InventoryRepository.approveStockCount(c.id, onRejected = { r -> approveCountError = r }) } }, modifier = Modifier.fillMaxWidth()) { Text("Approve & Adjust Stock") }
                        }
                    }
                }
            }
        }
    }

    if (showNew) {
        var warehouseId by remember { mutableStateOf<String?>(null) }
        var warehouseName by remember { mutableStateOf("") }
        var lines by remember { mutableStateOf(listOf<com.abm.erp.data.StockCountLine>()) }
        Dialog(onDismissRequest = { showNew = false }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(modifier = Modifier.fillMaxSize(), color = com.abm.erp.theme.DashBg) {
                Column(Modifier.fillMaxSize().padding(16.dp).imePadding().verticalScroll(rememberScrollState())) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("New Stock Count", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { showNew = false }) { Text("✕ Close") }
                    }
                    Spacer(Modifier.height(8.dp))
                    val warehouseNames = levels.map { it.warehouseId to it.warehouseName }.distinct()
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        warehouseNames.forEach { (id, name) ->
                            FilterChip(selected = warehouseId == id, onClick = { warehouseId = id; warehouseName = name; lines = levels.filter { it.warehouseId == id }.map { com.abm.erp.data.StockCountLine(productId = it.productId, productName = it.productName, systemQty = it.quantityOnHand, countedQty = it.quantityOnHand) } }, label = { Text(name, style = MaterialTheme.typography.labelSmall) })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    lines.forEachIndexed { idx, line ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(line.productName, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            OutlinedTextField(
                                value = line.countedQty.toString(), onValueChange = { v -> v.toDoubleOrNull()?.let { newQty -> lines = lines.toMutableList().also { it[idx] = line.copy(countedQty = newQty) } } },
                                modifier = Modifier.width(90.dp), singleLine = true,
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { if (warehouseId != null) { countScope.launch { com.abm.erp.data.InventoryRepository.createStockCount(warehouseId!!, warehouseName, lines) }; showNew = false } },
                        enabled = warehouseId != null && lines.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Save Draft") }
                }
            }
        }
    }
}

/** Foundation 5 — Smart Stock Intelligence. Wires the previously-dead recommendation functions to real UI. */
@Composable
private fun StockIntelligenceTab() {
    var subTab by remember { mutableStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Stock Intelligence", style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { showSettings = true }) { Text("⚙ Settings") }
        }
        if (showSettings) {
            val current = InventoryRepository.stockIntelligenceThresholds
            var safetyDays by remember { mutableStateOf(current.safetyStockDays.toString()) }
            var leadDays by remember { mutableStateOf(current.leadTimeDays.toString()) }
            var deadDays by remember { mutableStateOf(current.deadStockDays.toString()) }
            var expiryDays by remember { mutableStateOf(current.expiryWarningDays.toString()) }
            var thresholdError by remember { mutableStateOf<String?>(null) }
            Dialog(onDismissRequest = { showSettings = false }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Stock Intelligence Settings", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = safetyDays, onValueChange = { safetyDays = it }, label = { Text("Safety stock (days)") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(value = leadDays, onValueChange = { leadDays = it }, label = { Text("Lead time (days)") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(value = deadDays, onValueChange = { deadDays = it }, label = { Text("Dead stock (days no movement)") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(value = expiryDays, onValueChange = { expiryDays = it }, label = { Text("Expiry warning (days)") }, modifier = Modifier.fillMaxWidth())
                        thresholdError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = {
                                val updated = current.copy(
                                    safetyStockDays = safetyDays.toIntOrNull() ?: current.safetyStockDays,
                                    leadTimeDays = leadDays.toIntOrNull() ?: current.leadTimeDays,
                                    deadStockDays = deadDays.toIntOrNull() ?: current.deadStockDays,
                                    expiryWarningDays = expiryDays.toIntOrNull() ?: current.expiryWarningDays,
                                )
                                if (InventoryRepository.updateStockIntelligenceThresholds(updated, onRejected = { e -> thresholdError = e })) showSettings = false
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Save") }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        ScrollableTabRow(selectedTabIndex = subTab) {
            Tab(selected = subTab == 0, onClick = { subTab = 0 }, text = { Text("Purchase", style = MaterialTheme.typography.labelSmall) })
            Tab(selected = subTab == 1, onClick = { subTab = 1 }, text = { Text("Production", style = MaterialTheme.typography.labelSmall) })
            Tab(selected = subTab == 2, onClick = { subTab = 2 }, text = { Text("Transfers", style = MaterialTheme.typography.labelSmall) })
            Tab(selected = subTab == 3, onClick = { subTab = 3 }, text = { Text("Retailer/Dealer", style = MaterialTheme.typography.labelSmall) })
        }
        Spacer(Modifier.height(10.dp))
        when (subTab) {
            0 -> {
                val recs by produceState<List<InventoryRepository.PurchaseRecommendation>>(initialValue = emptyList()) {
                    value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { InventoryRepository.purchaseRecommendations() }
                }
                Button(onClick = { InventoryRepository.raiseStockAlerts() }, modifier = Modifier.fillMaxWidth()) { Text("Raise Alerts for Critical Items") }
                Spacer(Modifier.height(8.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(recs) { r ->
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Text(r.productName, fontWeight = FontWeight.SemiBold)
                            Text(r.reason, style = MaterialTheme.typography.bodySmall, color = if (r.priority == "CRITICAL") DangerRed else if (r.priority == "HIGH") WarningAmber else TextSecondary)
                        }
                    }
                    if (recs.isEmpty()) item { Text("কোনো reorder প্রয়োজন নেই।", color = TextSecondary) }
                }
            }
            1 -> {
                val bomNames = remember { InventoryRepository.products.value.map { it.name }.toSet() }
                val recs by produceState<List<InventoryRepository.ProductionRecommendation>>(initialValue = emptyList()) {
                    value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { InventoryRepository.productionRecommendations(bomNames) }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(recs) { r ->
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Text(r.productName, fontWeight = FontWeight.SemiBold)
                            Text(r.reason, style = MaterialTheme.typography.bodySmall, color = if (r.priority == "CRITICAL") DangerRed else TextSecondary)
                        }
                    }
                    if (recs.isEmpty()) item { Text("কোনো production recommendation নেই।", color = TextSecondary) }
                }
            }
            2 -> {
                val recs by produceState<List<InventoryRepository.TransferRecommendation>>(initialValue = emptyList()) {
                    value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { InventoryRepository.warehouseBalancingRecommendations() }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(recs) { r ->
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Text("${r.productName}: ${r.fromWarehouseName} → ${r.toWarehouseName}", fontWeight = FontWeight.SemiBold)
                            Text("${r.recommendedQty.toInt()} units — ${r.reason}", style = MaterialTheme.typography.bodySmall, color = if (r.priority == "CRITICAL") DangerRed else TextSecondary)
                        }
                    }
                    if (recs.isEmpty()) item { Text("কোনো warehouse transfer প্রয়োজন নেই।", color = TextSecondary) }
                }
            }
            else -> {
                val retailerInsights by produceState<List<InventoryRepository.RetailerDemandInsight>>(initialValue = emptyList()) {
                    value = InventoryRepository.retailerDemandInsights().filter { it.isLost || it.isInactive || !it.isGrowing }
                }
                val dealerInsights by produceState<List<InventoryRepository.DealerStockHealthInsight>>(initialValue = emptyList()) {
                    value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                        InventoryRepository.dealerStockHealthInsights().filter { it.health != com.abm.erp.inventory.StockIntelligence.StockHealth.HEALTHY }
                    }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { Text("Retailer Demand Concerns", fontWeight = FontWeight.Bold) }
                    items(retailerInsights.take(20)) { r ->
                        Text("${r.retailerName}: ${if (r.isLost) "LOST" else if (r.isInactive) "INACTIVE" else "declining ${"%.0f".format(r.trendPct)}%"}", style = MaterialTheme.typography.bodySmall, color = if (r.isLost) DangerRed else WarningAmber)
                    }
                    item { Spacer(Modifier.height(10.dp)); Text("Dealer Stock Health", fontWeight = FontWeight.Bold) }
                    items(dealerInsights.take(20)) { d ->
                        Text("${d.dealerName}: ${d.health}", style = MaterialTheme.typography.bodySmall, color = if (d.health == com.abm.erp.inventory.StockIntelligence.StockHealth.CRITICAL || d.health == com.abm.erp.inventory.StockIntelligence.StockHealth.DEAD) DangerRed else WarningAmber)
                    }
                }
            }
        }
    }
}
