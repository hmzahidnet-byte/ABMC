package com.abm.erp.core

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * Shared building blocks for on-screen printable documents (Invoice, Memo, and any
 * future receipt/voucher screen). Originally lived only inside InvoiceDocumentScreen —
 * pulled out here (v113-153) so MemoDocumentScreen can reuse the exact same look
 * instead of a second, drifting copy. One home per feature.
 */

@Composable fun DocLabel(t: String) =
    Text(t.uppercase(), fontSize = 8.sp, color = TextSecondary, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)

@Composable fun DocValue(t: String) =
    Text(t, fontSize = 13.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)

@Composable fun RowScope.Th(t: String, w: Float, align: TextAlign = TextAlign.Start) =
    Text(t, Modifier.weight(w), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = align)

@Composable fun RowScope.Td(
    t: String, w: Float, align: TextAlign = TextAlign.Start, weight: FontWeight = FontWeight.Normal,
) = Text(t, Modifier.weight(w), color = TextPrimary, fontSize = 11.sp, textAlign = align, fontWeight = weight)

// v113-198 — bordered-cell variants of Th/Td, for the real full-grid table
// look the person's own reference (a classic invoice template with every
// cell boxed) asked for — Th/Td above stay untouched since other screens
// already depend on their exact look.
@Composable fun RowScope.ThGrid(t: String, w: Float, align: TextAlign = TextAlign.Start) =
    Text(
        t, Modifier.weight(w).border(0.5.dp, Color(0xFFC2440F)).padding(horizontal = 6.dp, vertical = 7.dp),
        color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = align,
    )

@Composable fun RowScope.TdGrid(
    t: String, w: Float, align: TextAlign = TextAlign.Start, weight: FontWeight = FontWeight.Normal, color: Color = TextPrimary,
) = Text(
    t, Modifier.weight(w).border(0.5.dp, HairlineBorder).padding(horizontal = 6.dp, vertical = 7.dp),
    color = color, fontSize = 11.sp, textAlign = align, fontWeight = weight,
)

// v113-198 — small logo mark ("ABM" on an orange square), for the masthead
// the person's reference shows next to the company name. One shared home so
// Invoice/Memo/anything else printable stays visually identical.
@Composable fun DocLogoMark(size: androidx.compose.ui.unit.Dp = 32.dp) {
    Box(
        Modifier.size(size).background(DarazOrange, RoundedCornerShape(6.dp)),
        contentAlignment = Alignment.Center,
    ) {
        Text("ABM", color = Color.White, fontSize = (size.value * 0.28f).sp, fontWeight = FontWeight.Black, letterSpacing = (-0.3).sp)
    }
}

// v113-198 — small colour bar for a section title (e.g. "Dealer"), matching
// the person's reference's "Bill To:" pattern — a thin labelled bar, not a
// big banner. Shared so the creation workspace and the printed document use
// the identical element.
@Composable fun DocBar(text: String) {
    Text(
        text.uppercase(), color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.4.sp,
        modifier = Modifier.fillMaxWidth().background(DarazOrange).padding(horizontal = 10.dp, vertical = 6.dp),
    )
}

@Composable fun TotalRow(label: String, value: String, color: Color = TextPrimary) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 11.sp, color = TextSecondary)
        Text(value, fontSize = 12.sp, color = color, fontWeight = FontWeight.SemiBold)
    }
}

@Composable fun SignatureSlot(role: String, name: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        if (name.isNotBlank()) {
            Text(name, fontSize = 9.sp, color = TextPrimary, maxLines = 1)
        } else {
            Spacer(Modifier.height(12.dp))
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(HairlineBorder))
        Spacer(Modifier.height(3.dp))
        Text(role, fontSize = 8.sp, color = TextSecondary, textAlign = TextAlign.Center)
    }
}

/**
 * Amount in words, Bangladeshi convention (lakh / crore rather than million / billion).
 *
 * Presentation only — it never feeds a calculation, and the numeric total beside it stays
 * the authority. Deliberately kept simple and total-agnostic so it cannot alter a figure.
 */
fun amountInWords(amount: Double): String {
    val n = kotlin.math.floor(amount).toLong()
    if (n == 0L) return "Zero Taka Only"
    if (n < 0L) return "Minus ${amountInWords(-amount)}"

    val ones = listOf(
        "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
        "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen",
    )
    val tens = listOf("", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety")

    fun under100(v: Int): String = when {
        v == 0 -> ""
        v < 20 -> ones[v]
        else -> (tens[v / 10] + if (v % 10 != 0) " ${ones[v % 10]}" else "")
    }

    fun under1000(v: Int): String {
        val h = v / 100
        val r = v % 100
        val parts = mutableListOf<String>()
        if (h > 0) parts += "${ones[h]} Hundred"
        if (r > 0) parts += under100(r)
        return parts.joinToString(" ")
    }

    val crore = (n / 10_000_000).toInt()
    val lakh = ((n / 100_000) % 100).toInt()
    val thousand = ((n / 1_000) % 100).toInt()
    val rest = (n % 1_000).toInt()

    val parts = mutableListOf<String>()
    if (crore > 0) parts += "${under1000(crore)} Crore"
    if (lakh > 0) parts += "${under100(lakh)} Lakh"
    if (thousand > 0) parts += "${under100(thousand)} Thousand"
    if (rest > 0) parts += under1000(rest)

    return parts.joinToString(" ").trim() + " Taka Only"
}

/**
 * v113-306 — item 14 of the person's 14-point list: "aisobe manually qr
 * er kno option ei rakhar drkr nai ata backend e auto genrate hbe tbe ha
 * tkni genarate hbe jokhon approveal pabe" — no manual QR option
 * anywhere; it generates in the backend, at approval.
 *
 * This used to be a real issue/reissue control on every Invoice and Memo
 * document. Both actions are gone. Reissue especially was destructive:
 * it revoked whatever code had already been printed and handed out,
 * which is precisely the kind of manual override being removed.
 *
 * Verified before removing that every real approval path already calls
 * `activateQrFor` — SalesInvoice at `approveSalesInvoice`, RetailOrder
 * at its own DEALER_ROUTED transition, plus Dealer, Retailer, Employee,
 * Delivery, ProductionBatch and WarehouseTransfer — so no document is
 * left without a QR by this change.
 *
 * What remains is honest status only. The scannable payload itself is
 * deliberately not re-rendered here: only a token HASH is ever stored,
 * so the real code exists only at the moment of issue and cannot be
 * reconstructed afterward.
 */
@Composable
fun DocumentQrControl(entityType: String, entityId: String, onPayloadReady: (String) -> Unit = {}) {
    var checked by remember(entityId) { mutableStateOf(false) }
    var payload by remember(entityId) { mutableStateOf<String?>(null) }
    var issuedButUnstored by remember(entityId) { mutableStateOf(false) }

    LaunchedEffect(entityId) {
        val row = com.abm.erp.data.QrRegistry.activeFor(entityType, entityId)
        payload = row?.payload
        issuedButUnstored = row != null && row.payload.isNullOrBlank()
        checked = true
        payload?.let(onPayloadReady)
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        when {
            !checked -> Text("…", fontSize = 9.sp, color = TextSecondary)
            // v113-326 — the person's report: "invoice apporve hoar poro qr
            // show kore na keno?" They were right. v113-306 correctly
            // removed the manual issue/reissue buttons, but left this
            // showing only the words "✓ QR issued" — because the payload
            // was genuinely unrecoverable (only its hash was persisted).
            // Now that the payload is stored (see QrRegistryEntity), the
            // real scannable code is drawn here, on the document, ready to
            // print — which was the whole point.
            payload != null -> {
                val bitmap = remember(payload) { com.abm.erp.util.QrCodeGenerator.generate(payload!!, 300) }
                androidx.compose.foundation.Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "QR code",
                    modifier = Modifier.size(96.dp),
                )
                Text("✓ approval-এ তৈরি", fontSize = 7.sp, color = SuccessGreen)
            }
            // An older QR, issued before the payload column existed. Saying
            // so plainly is better than drawing nothing with no explanation
            // or, worse, inventing a code that would fail every scan.
            issuedButUnstored -> {
                Text("✓ QR issued", fontSize = 9.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                Text("পুরনো QR — code সংরক্ষিত নেই", fontSize = 7.sp, color = TextSecondary)
            }
            else -> {
                Text("QR নেই", fontSize = 9.sp, color = TextSecondary)
                Text("approve হলে তৈরি হবে", fontSize = 7.sp, color = TextSecondary)
            }
        }
    }
}
