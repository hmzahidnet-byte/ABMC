package com.abm.erp.data

import android.content.Context
import android.net.Uri
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

/**
 * Thin Firebase layer for the data that genuinely needs to sync across
 * *different people's phones in real time* — an SR's complaint has to reach
 * the Chairman's device, a Chairman's vacancy toggle has to reach every
 * device instantly. That's impossible with the local-only Room database
 * (each phone would only ever see its own copy), which is exactly why this
 * exists.
 *
 * Scope for this pass: Complaint Box + Vacant Positions, because those two
 * screens already exist in Kotlin and are the clearest "must sync across
 * people" cases. Sales/Inventory/Payroll/etc. stay on local Room for now and
 * move here module-by-module in later phases — see the zip's README.
 *
 * IMPORTANT — one-time setup required from you (I can't do this part, it
 * needs your own Google account): create a Firebase project at
 * console.firebase.google.com, register this app (package: com.abm.erp),
 * download google-services.json into the app/ folder, and enable
 * "Anonymous" sign-in + Firestore in the console. Full steps in
 * SETUP_FIREBASE.md at the root of this zip.
 *
 * Until that's done, every call below fails safely into Logcat instead of
 * crashing — so this trial APK still runs perfectly well on local data only.
 */
object FirebaseSync {
    private const val TAG = "FirebaseSync"

    private var initialized = false
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }

    private var complaintsListener: ListenerRegistration? = null
    private var vacancyListener: ListenerRegistration? = null

    private val _complaints = MutableStateFlow<List<ComplaintRecord>>(emptyList())
    val complaints: StateFlow<List<ComplaintRecord>> = _complaints.asStateFlow()

    private val _vacantEmployeeIds = MutableStateFlow<Set<String>>(emptySet())
    val vacantEmployeeIds: StateFlow<Set<String>> = _vacantEmployeeIds.asStateFlow()

    // ================= Multi-tenant: Company Registry =================
    // Firestore, না Kotlin-এর fixed list — কারণ নতুন কোম্পানি ভাড়া নিলে
    // Super Admin থেকে তৈরি হবে, আর সেই মুহূর্তেই *সব* ডিভাইসের PIN login
    // screen সেটা চিনতে পারা দরকার, APK আবার বানানো/install ছাড়াই। তাই এটা
    // companies collection-এ, unlimited সংখ্যক কোম্পানি ধারণ করতে পারে।
    data class TenantCompany(
        val id: String = "", val code: String = "", val name: String = "", val status: String = "Active",
        val plan: String = "Trial", // "Trial" | "Basic" | "Premium"
        val monthlyFee: Double = 0.0,
        val createdAtMillis: Long = 0,
    )

    private var companiesListener: ListenerRegistration? = null
    private val _companies = MutableStateFlow<List<TenantCompany>>(emptyList())
    val companies: StateFlow<List<TenantCompany>> = _companies.asStateFlow()

    private fun listenCompanies() {
        companiesListener?.remove()
        companiesListener = db.collection("companies")
            .addSnapshotListener { snap, err ->
                if (err != null) { Log.w(TAG, "companies listener error", err); return@addSnapshotListener }
                _companies.value = snap?.documents?.mapNotNull { it.toObject(TenantCompany::class.java) }.orEmpty()
            }
    }

    fun validateCompanyCode(code: String): TenantCompany? =
        _companies.value.firstOrNull { it.code.equals(code.trim(), ignoreCase = true) && (it.status == "Active" || it.status == "Trial") }

    /** Registers a tenant company — from that point on, EVERY device's login screen recognizes the new code immediately. */
    fun createCompany(code: String, name: String, status: String = "Trial", plan: String = "Trial", monthlyFee: Double = 0.0) {
        val id = code.trim().uppercase()
        db.collection("companies").document(id)
            .set(TenantCompany(id, id, name, status, plan, monthlyFee, System.currentTimeMillis()))
            .addOnFailureListener { Log.w(TAG, "createCompany failed", it) }
    }

    fun setCompanyStatus(companyId: String, status: String) {
        db.collection("companies").document(companyId).update("status", status)
            .addOnFailureListener { Log.w(TAG, "setCompanyStatus failed", it) }
    }

    /**
     * One-time seed for the 3 demo companies, safe to call every app launch:
     * uses the company code itself as the document ID, so re-running this
     * just overwrites the same 3 documents rather than creating duplicates
     * or piling up every time someone opens the app.
     */
    private fun seedDemoCompaniesIfNeeded() {
        listOf(
            TenantCompany("ABM2026", "ABM2026", "ABM Corporation", "Active", "Premium", 25_000.0, System.currentTimeMillis()),
            TenantCompany("GVT2026", "GVT2026", "Green Valley Traders", "Active", "Basic", 8_000.0, System.currentTimeMillis()),
            TenantCompany("SBD2026", "SBD2026", "Sundarban Distribution", "Trial", "Trial", 0.0, System.currentTimeMillis()),
        ).forEach { company ->
            db.collection("companies").document(company.id).get()
                .addOnSuccessListener { doc ->
                    if (!doc.exists()) {
                        db.collection("companies").document(company.id).set(company)
                            .addOnFailureListener { Log.w(TAG, "seedDemoCompaniesIfNeeded failed for ${company.id}", it) }
                    }
                }
                .addOnFailureListener { Log.w(TAG, "seedDemoCompaniesIfNeeded check failed for ${company.id}", it) }
        }
    }

    // Support Tickets and Super Admin Audit Log removed — SaaS cross-company
    // support model cancelled; Chairman now sits at the top of the single-
    // company hierarchy instead of a separate Super Admin tier.


    // Every collection below EXCEPT "companies" itself now lives nested
    // under companies/{companyId}/... — this is the actual isolation
    // boundary: Company A's Chairman can never accidentally query Company
    // B's complaints/orders/etc., because they're not even in the same
    // Firestore subtree. currentCompanyId is set once, right after the
    // Company Code screen validates (or at cold start if already saved) —
    // see startCompanyScopedListeners().
    private var currentCompanyId: String? = null

    private fun companyCollection(name: String) =
        db.collection("companies").document(CompanyContext.current.value ?: "_unset").collection(name)

    /**
     * Call this once — right after Company Code validates, or at app cold
     * start if a code was already saved — to point every per-tenant
     * listener at the right company. Safe to call again if the same
     * company (re-attaches nothing extra); listeners are torn down and
     * restarted if it's actually a different company (e.g. Super Admin
     * switching context, or a device somehow re-registers to a new tenant).
     */
    fun startCompanyScopedListeners(companyId: String) {
        if (!CompanyContext.validateAndRecord(companyId)) {
            Log.w(TAG, "startCompanyScopedListeners refused invalid companyId '$companyId' — sync not started")
            return
        }
        if (companyId == currentCompanyId) return
        currentCompanyId = companyId
        listenComplaints()
        listenVacancy()
        listenDealerOrders()
        listenChairmanNotice()
        listenTrustedDevices()
        listenLoginLog()
        listenHelpdesk()
        listenAiUsage()
    }

    // ================= AI Assistant usage cap =================
    // একটা company-র সবার AI ব্যবহার একসাথে গোনা হয় (per-device না) — এক
    // মাসের ডকুমেন্ট আইডি "yyyy-MM", তাই মাস বদলালেই স্বয়ংক্রিয়ভাবে নতুন
    // কাউন্ট শুরু হয়ে যায়, আলাদা করে reset করার কোনো job লাগে না।
    const val AI_MONTHLY_CAP = 100

    private var aiUsageListener: ListenerRegistration? = null
    private val _aiUsageThisMonth = MutableStateFlow(0)
    val aiUsageThisMonth: StateFlow<Int> = _aiUsageThisMonth.asStateFlow()

    private fun currentYearMonth(): String {
        val cal = java.util.Calendar.getInstance()
        return "%04d-%02d".format(cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH) + 1)
    }

    private fun listenAiUsage() {
        aiUsageListener?.remove()
        aiUsageListener = companyCollection("aiUsage").document(currentYearMonth())
            .addSnapshotListener { snap, err ->
                if (err != null) { Log.w(TAG, "aiUsage listener error", err); return@addSnapshotListener }
                _aiUsageThisMonth.value = (snap?.getLong("count") ?: 0L).toInt()
            }
    }

    /** Call once per AI question asked (either slot) — returns false if the monthly cap is already hit, so the caller can refuse before spending anything. */
    fun tryConsumeAiUsage(): Boolean {
        if (_aiUsageThisMonth.value >= AI_MONTHLY_CAP) return false
        _aiUsageThisMonth.value += 1 // optimistic bump; the listener reconciles once the write lands
        companyCollection("aiUsage").document(currentYearMonth())
            .set(mapOf("count" to _aiUsageThisMonth.value), com.google.firebase.firestore.SetOptions.merge())
            .addOnFailureListener { Log.w(TAG, "tryConsumeAiUsage failed", it); _aiUsageThisMonth.value -= 1 }
        return true
    }

    // ================= Trusted Devices =================
    // { employeeId: [deviceId, ...] } — which devices have already
    // PIN-logged-in as which employee. Chairman-visible (Trusted Devices
    // screen) so a lost/stolen phone or an ex-employee's device can be
    // remotely logged out. Firestore, not Room, because the Chairman needs
    // to see THIS from a completely different physical device than the one
    // that got trusted.
    private var trustedDevicesListener: ListenerRegistration? = null
    private val _trustedDeviceIds = MutableStateFlow<Map<String, List<String>>>(emptyMap())
    val trustedDeviceIds: StateFlow<Map<String, List<String>>> = _trustedDeviceIds.asStateFlow()

    /**
     * Issue 2 fix — an empty _trustedDeviceIds map is ambiguous: it could
     * mean "genuinely no trusted devices" OR "the Firestore listener
     * hasn't delivered its first snapshot yet" (e.g. cold start, biometric
     * prompt fired before listenTrustedDevices() finished attaching).
     * Treating the latter as a confirmed revocation would wrongly clear a
     * valid biometric binding. This state makes the distinction explicit.
     */
    enum class TrustedDeviceLoadState { LOADING, LOADED, ERROR }
    private val _trustedDeviceLoadState = MutableStateFlow(TrustedDeviceLoadState.LOADING)
    val trustedDeviceLoadState: StateFlow<TrustedDeviceLoadState> = _trustedDeviceLoadState.asStateFlow()

    private fun listenTrustedDevices() {
        trustedDevicesListener?.remove()
        _trustedDeviceLoadState.value = TrustedDeviceLoadState.LOADING
        trustedDevicesListener = companyCollection("orgState").document("trustedDevices")
            .addSnapshotListener { snap, err ->
                if (err != null) { Log.w(TAG, "trustedDevices listener error", err); _trustedDeviceLoadState.value = TrustedDeviceLoadState.ERROR; return@addSnapshotListener }
                @Suppress("UNCHECKED_CAST")
                val raw = (snap?.get("map") as? Map<String, List<String>>).orEmpty()
                _trustedDeviceIds.value = raw
                _trustedDeviceLoadState.value = TrustedDeviceLoadState.LOADED
            }
    }

    fun isTrustedDevice(employeeId: String, deviceId: String): Boolean =
        _trustedDeviceIds.value[employeeId]?.contains(deviceId) == true

    /**
     * Issue 2 fix — one-shot authoritative Firestore read, for the exact
     * moment biometric restoration needs a real answer but the cached
     * listener state is still LOADING (never confirmed either way yet).
     * Returns null on failure/offline/timeout — the caller must treat
     * null as "cannot confirm right now", never as "confirmed untrusted".
     */
    suspend fun fetchTrustedDeviceAuthoritative(employeeId: String, deviceId: String): Boolean? {
        return try {
            val snap = companyCollection("orgState").document("trustedDevices").get().await()
            @Suppress("UNCHECKED_CAST")
            val raw = (snap.get("map") as? Map<String, List<String>>).orEmpty()
            raw[employeeId]?.contains(deviceId) == true
        } catch (e: Exception) {
            Log.w(TAG, "fetchTrustedDeviceAuthoritative failed", e)
            null
        }
    }

    fun addTrustedDevice(employeeId: String, deviceId: String) {
        val current = _trustedDeviceIds.value
        val next = current + (employeeId to ((current[employeeId] ?: emptyList()) + deviceId).distinct())
        _trustedDeviceIds.value = next
        companyCollection("orgState").document("trustedDevices").set(mapOf("map" to next))
            .addOnFailureListener { Log.w(TAG, "addTrustedDevice failed", it); _trustedDeviceIds.value = current }
    }

    /** Remote logout (Chairman, from the Trusted Devices screen) or automatic on termination. */
    fun removeTrustedDevice(employeeId: String, deviceId: String) {
        val current = _trustedDeviceIds.value
        val next = current + (employeeId to (current[employeeId].orEmpty() - deviceId))
        _trustedDeviceIds.value = next
        companyCollection("orgState").document("trustedDevices").set(mapOf("map" to next))
            .addOnFailureListener { Log.w(TAG, "removeTrustedDevice failed", it); _trustedDeviceIds.value = current }
    }

    /** Every device for this employee — used when they're marked Vacant (auto force-logout everywhere). */
    private fun clearAllTrustedDevicesFor(employeeId: String) {
        val current = _trustedDeviceIds.value
        val next = current - employeeId
        _trustedDeviceIds.value = next
        companyCollection("orgState").document("trustedDevices").set(mapOf("map" to next))
            .addOnFailureListener { Log.w(TAG, "clearAllTrustedDevicesFor failed", it); _trustedDeviceIds.value = current }
    }

    /**
     * Foundation Layer — Session Management: explicit, Chairman-triggered
     * force-logout (distinct from the automatic one toggleVacant() already
     * does). Clears every trusted device for this employee, so their next
     * app open needs a full PIN login again — same mechanism, just callable
     * on ANY employee, not only ones being marked vacant.
     */
    fun forceLogoutEmployee(employeeId: String) {
        clearAllTrustedDevicesFor(employeeId)
        MockRepository.logAudit("Session", employeeId, "FORCE_LOGOUT", oldValue = MockRepository.currentUser.name)
    }

    // ================= Login Activity Log =================
    private var loginLogListener: ListenerRegistration? = null
    private val _loginLog = MutableStateFlow<List<LoginLogEntry>>(emptyList())
    val loginLog: StateFlow<List<LoginLogEntry>> = _loginLog.asStateFlow()

    private fun listenLoginLog() {
        loginLogListener?.remove()
        loginLogListener = companyCollection("loginLog").orderBy("atMillis", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(200)
            .addSnapshotListener { snap, err ->
                if (err != null) { Log.w(TAG, "loginLog listener error", err); return@addSnapshotListener }
                _loginLog.value = snap?.documents?.mapNotNull { it.toObject(LoginLogEntry::class.java) }.orEmpty()
            }
    }

    fun recordLoginAttempt(employeeId: String?, employeeName: String, deviceId: String, success: Boolean, anomalous: Boolean = false) {
        val id = companyCollection("loginLog").document().id
        val entry = LoginLogEntry(id, employeeId, employeeName, deviceId, if (success) "Success" else "Failed", anomalous, System.currentTimeMillis())
        companyCollection("loginLog").document(id).set(entry)
            .addOnFailureListener { Log.w(TAG, "recordLoginAttempt failed", it) }
    }

    // ================= Helpdesk =================
    // Dealer/retailer-facing support tickets — distinct from Complaint Box
    // (which is internal staff-to-Chairman). A dealer raises a ticket from
    // DealerHomeScreen on their own phone; any staff member (BASE-tier
    // access, see ROLE_MODULES) can see and resolve it on theirs.
    private var helpdeskListener: ListenerRegistration? = null
    private val _helpdeskTickets = MutableStateFlow<List<HelpdeskTicket>>(emptyList())
    val helpdeskTickets: StateFlow<List<HelpdeskTicket>> = _helpdeskTickets.asStateFlow()

    private fun listenHelpdesk() {
        helpdeskListener?.remove()
        helpdeskListener = companyCollection("helpdeskTickets")
            .addSnapshotListener { snap, err ->
                if (err != null) { Log.w(TAG, "helpdesk listener error", err); return@addSnapshotListener }
                _helpdeskTickets.value = snap?.documents
                    ?.mapNotNull { it.toObject(HelpdeskTicket::class.java) }
                    ?.sortedByDescending { it.createdAtMillis }
                    .orEmpty()
            }
    }

    fun submitHelpdeskTicket(fromId: String, fromName: String, fromType: String, subject: String, message: String) {
        val id = companyCollection("helpdeskTickets").document().id
        val ticket = HelpdeskTicket(id, fromId, fromName, fromType, subject, message, "Open", System.currentTimeMillis())
        companyCollection("helpdeskTickets").document(id).set(ticket)
            .addOnFailureListener { Log.w(TAG, "submitHelpdeskTicket failed — check Firebase setup", it) }
        MockRepository.createNotification(NotificationCategory.HELPDESK, "New Helpdesk Ticket", "$fromName: $subject")
    }

    fun setHelpdeskTicketStatus(id: String, status: String) {
        companyCollection("helpdeskTickets").document(id).update("status", status)
            .addOnFailureListener { Log.w(TAG, "updating helpdesk ticket failed", it) }
    }


    // A dealer places an order on their own phone (DealerHomeScreen); the ASM
    // who covers that dealer's territory approves/rejects it on theirs
    // (DealersScreen). Only Firestore makes that cross-device handoff work.
    private var dealerOrdersListener: ListenerRegistration? = null
    private val _dealerOrders = MutableStateFlow<List<DealerOrderRecord>>(emptyList())
    val dealerOrders: StateFlow<List<DealerOrderRecord>> = _dealerOrders.asStateFlow()

    private fun listenDealerOrders() {
        dealerOrdersListener?.remove()
        dealerOrdersListener = companyCollection("dealerOrders")
            .addSnapshotListener { snap, err ->
                if (err != null) { Log.w(TAG, "dealerOrders listener error", err); return@addSnapshotListener }
                _dealerOrders.value = snap?.documents
                    ?.mapNotNull { it.toObject(DealerOrderRecord::class.java) }
                    ?.sortedByDescending { it.createdAtMillis }
                    .orEmpty()
            }
    }

    fun submitDealerOrder(dealerId: String, dealerName: String, product: String, qty: Int) {
        val id = companyCollection("dealerOrders").document().id
        val record = DealerOrderRecord(id, dealerId, dealerName, product, qty, "Pending", System.currentTimeMillis())
        companyCollection("dealerOrders").document(id).set(record)
            .addOnFailureListener { Log.w(TAG, "submitDealerOrder failed — check Firebase setup", it) }
    }

    fun setDealerOrderStatus(id: String, status: String) {
        companyCollection("dealerOrders").document(id).update("status", status)
            .addOnFailureListener { Log.w(TAG, "updating dealer order failed", it) }
    }

    // ================= Chairman's Notice =================
    // v113-157 — 3 independent slots (person's explicit request), each its own
    // Firestore document (orgState/chairmanNotice_0/_1/_2) so uploading to one
    // slot never touches another. Was a single shared document before this.
    private val noticeListeners = arrayOfNulls<ListenerRegistration>(3)
    private val _chairmanNotices = MutableStateFlow<List<ChairmanNotice?>>(listOf(null, null, null))
    val chairmanNotices: StateFlow<List<ChairmanNotice?>> = _chairmanNotices.asStateFlow()

    private fun listenChairmanNotice() {
        for (slot in 0..2) {
            noticeListeners[slot]?.remove()
            noticeListeners[slot] = companyCollection("orgState").document("chairmanNotice_$slot")
                .addSnapshotListener { snap, err ->
                    if (err != null) { Log.w(TAG, "notice listener error (slot $slot)", err); return@addSnapshotListener }
                    val updated = _chairmanNotices.value.toMutableList()
                    updated[slot] = snap?.toObject(ChairmanNotice::class.java)
                    _chairmanNotices.value = updated
                }
        }
    }

    /** Uploads the image to Firebase Storage, then writes its download URL + caption to Firestore, for the given slot (0, 1, or 2). */
    fun uploadChairmanNotice(slot: Int, localUri: Uri, caption: String) {
        require(slot in 0..2) { "Chairman's Notice has 3 slots (0-2), got $slot" }
        val ref = FirebaseStorage.getInstance().reference
            .child("chairman_notice/${slot}_${System.currentTimeMillis()}.jpg")
        ref.putFile(localUri)
            .continueWithTask { task ->
                if (!task.isSuccessful) throw task.exception ?: Exception("upload failed")
                ref.downloadUrl
            }
            .addOnSuccessListener { url ->
                companyCollection("orgState").document("chairmanNotice_$slot")
                    .set(ChairmanNotice(url.toString(), caption, System.currentTimeMillis()))
            }
            .addOnFailureListener { Log.w(TAG, "uploadChairmanNotice failed (slot $slot) — check Firebase Storage is enabled in the console", it) }
    }

    /**
     * Sets up Firebase + the company registry only — NOT the per-tenant
     * listeners (complaints, vacancy, etc.), since those need to know WHICH
     * company first. Call startCompanyScopedListeners(companyId) separately
     * once that's known (right after Company Code validates, or immediately
     * here too if a code was already saved from a previous run).
     */
    fun init(context: Context) {
        try {
            FirebaseApp.initializeApp(context)
            auth.signInAnonymously()
                .addOnSuccessListener {
                    initialized = true
                    listenCompanies()
                    seedDemoCompaniesIfNeeded()
                    getSavedCompanyCode(context)?.let { savedCode ->
                        startCompanyScopedListeners(savedCode)
                        com.abm.erp.data.MockRepository.startCrossDeviceSync(savedCode)
                        com.abm.erp.data.InventoryRepository.startCrossDeviceSync(savedCode)
                        com.abm.erp.data.PurchaseRepository.startCrossDeviceSync(savedCode)
                        com.abm.erp.data.AccountsRepository.startCrossDeviceSync(savedCode)
                        com.abm.erp.data.CrmRepository.startCrossDeviceSync(savedCode)
                        com.abm.erp.data.CommsRepository.startCrossDeviceSync(savedCode)
                    }
                }
                .addOnFailureListener {
                    Log.w(TAG, "Anonymous sign-in failed — is app/google-services.json in place and Anonymous auth enabled in the Firebase console? Running on local data only until then.", it)
                }
        } catch (e: Exception) {
            Log.w(TAG, "Firebase not configured yet — running on local data only. See SETUP_FIREBASE.md.", e)
        }
    }


    private fun listenComplaints() {
        complaintsListener?.remove()
        complaintsListener = companyCollection("complaints")
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    Log.w(TAG, "complaints listener error (check Firestore security rules)", err)
                    return@addSnapshotListener
                }
                _complaints.value = snap?.documents
                    ?.mapNotNull { it.toObject(ComplaintRecord::class.java) }
                    ?.sortedByDescending { it.createdAtMillis }
                    .orEmpty()
            }
    }

    fun submitComplaint(fromRole: String, fromName: String, subject: String, message: String, anonymous: Boolean) {
        val id = companyCollection("complaints").document().id
        val record = ComplaintRecord(
            id = id,
            fromRole = fromRole,
            fromName = if (anonymous) "Anonymous" else fromName,
            subject = subject,
            message = message,
            anonymous = anonymous,
            resolved = false,
            createdAtMillis = System.currentTimeMillis(),
        )
        companyCollection("complaints").document(id).set(record)
            .addOnFailureListener { Log.w(TAG, "submitComplaint failed — is Firebase set up yet? See SETUP_FIREBASE.md.", it) }
        MockRepository.createNotification(NotificationCategory.COMPLAINT, "New Complaint", "${record.fromName}: $subject")
    }

    fun setComplaintResolved(id: String, resolved: Boolean, onRejected: (String) -> Unit = {}) {
        // v113-122 — isChairman was computed in ComplaintBoxScreen.kt and correctly
        // hid this button from the UI, but this function itself had no backend
        // check at all — a UI-only gate, not defense-in-depth. Every other
        // mutating action in this app's Chairman-only screens re-checks
        // server/repo-side too (see PermissionControlCenterScreen.kt's own stated
        // principle); this one didn't, until now.
        if (MockRepository.currentUser.role != UserRole.CHAIRMAN) {
            MockRepository.logAudit("Complaint", id, "DENY", oldValue = MockRepository.currentUser.role.name, newValue = if (resolved) "RESOLVE" else "REOPEN")
            onRejected("শুধু Chairman এই Complaint resolve/reopen করতে পারেন।")
            return
        }
        companyCollection("complaints").document(id).update("resolved", resolved)
            .addOnFailureListener { Log.w(TAG, "updating complaint failed", it) }
        MockRepository.logAudit("Complaint", id, if (resolved) "RESOLVE" else "REOPEN")
    }

    // ================= Vacant Positions =================
    // Stored as one small document: { ids: [employeeId, ...] }. Simple and
    // cheap to read/write; fine at this scale (a Set of strings).
    private fun listenVacancy() {
        vacancyListener?.remove()
        vacancyListener = companyCollection("orgState").document("vacantEmployees")
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    Log.w(TAG, "vacancy listener error (check Firestore security rules)", err)
                    return@addSnapshotListener
                }
                @Suppress("UNCHECKED_CAST")
                val ids = (snap?.get("ids") as? List<String>).orEmpty().toSet()
                _vacantEmployeeIds.value = ids
            }
    }

    fun toggleVacant(employeeId: String) {
        val current = _vacantEmployeeIds.value
        val goingVacant = employeeId !in current
        val next = if (employeeId in current) current - employeeId else current + employeeId
        _vacantEmployeeIds.value = next // optimistic UI update; the listener above reconciles once the write lands
        companyCollection("orgState").document("vacantEmployees").set(mapOf("ids" to next.toList()))
            .addOnFailureListener {
                Log.w(TAG, "toggleVacant failed — is Firebase set up yet? See SETUP_FIREBASE.md.", it)
                _vacantEmployeeIds.value = current // roll back the optimistic update since the write didn't actually land
            }
        // চাকরিচ্যুতিতে auto force-logout — vacant করার সাথে সাথেই তার সব
        // trusted device বাদ যায়, যাতে ফোনে অ্যাপ খোলা থাকলেও পরের বার
        // biometric/quick-login কাজ না করে, নতুন PIN লাগবে (যেটা তখন আর জানা থাকবে না)।
        if (goingVacant) clearAllTrustedDevicesFor(employeeId)
    }
}

/**
 * Firestore needs a no-arg constructor to deserialize documents back into
 * this class — Kotlin data classes get one for free as long as every
 * property has a default value, which is why every field below has one.
 */
data class ComplaintRecord(
    val id: String = "",
    val fromRole: String = "",
    val fromName: String = "",
    val subject: String = "",
    val message: String = "",
    val anonymous: Boolean = false,
    val resolved: Boolean = false,
    val createdAtMillis: Long = 0,
)

data class DealerOrderRecord(
    val id: String = "",
    val dealerId: String = "",
    val dealerName: String = "",
    val product: String = "",
    val qty: Int = 0,
    val status: String = "Pending", // Pending | Approved | Rejected
    val createdAtMillis: Long = 0,
)

data class ChairmanNotice(
    val imageUrl: String = "",
    val caption: String = "",
    val uploadedAtMillis: Long = 0,
)

data class LoginLogEntry(
    val id: String = "",
    val employeeId: String? = null,
    val employeeName: String = "Unknown",
    val deviceId: String = "",
    val result: String = "", // "Success" | "Failed"
    val anomalous: Boolean = false,
    val atMillis: Long = 0,
)

data class HelpdeskTicket(
    val id: String = "",
    val fromId: String = "",
    val fromName: String = "",
    val fromType: String = "", // "Dealer" | "Retailer" | "Staff"
    val subject: String = "",
    val message: String = "",
    val status: String = "Open", // "Open" | "Resolved"
    val createdAtMillis: Long = 0,
)
