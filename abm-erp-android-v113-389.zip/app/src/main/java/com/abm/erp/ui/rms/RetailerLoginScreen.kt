package com.abm.erp.ui.rms

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.MockRepository
import com.abm.erp.data.Retailer
import com.abm.erp.theme.*
import com.abm.erp.util.LocationAnomalyChecker
import com.abm.erp.util.tryGetLoginLocation
import kotlinx.coroutines.launch

/**
 * v113-203 — Retailer's own entry point, mirroring DealerLoginScreen.kt
 * exactly (same structure, same 50km geo-block, same PIN-verification
 * flow) so DMS and RMS carry the identical "real software with its own
 * party login" shape the person asked for. Deliberately does NOT carry a
 * lifecycle-status block (Suspend/Terminate) — the person confirmed that
 * control is Dealer-only for now, not Retailer.
 */
@Composable
fun RetailerLoginScreen(onRetailerChosen: (retailerId: String) -> Unit, onBackToStaffLogin: () -> Unit) {
    val retailers by MockRepository.retailers.collectAsState()
    var selected by remember { mutableStateOf<Retailer?>(null) }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var checking by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") } // v113-359
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Box(
        modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(SkyTop, Sky, SkyHorizon, GoldBright))),
        contentAlignment = Alignment.Center,
    ) {
        // v113-359 — same real bug the dealer portal had: a non-scrolling picker
        // listing every retailer, with no search. Retailers outnumber dealers,
        // so this one was worse.
        Column(
            Modifier.fillMaxSize().padding(32.dp).imePadding().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text("🛍️", fontSize = 40.sp)
            Spacer(Modifier.height(12.dp))
            Text("Retailer Portal", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 20.sp)

            if (selected == null) {
                Text("Choose your business to continue", color = Color(0xFFE4EEF6), fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = search, onValueChange = { search = it },
                    label = { Text("নাম / কোড / এলাকা দিয়ে খুঁজুন") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Color.White, unfocusedBorderColor = Color(0xFFE4EEF6)),
                )
                Spacer(Modifier.height(10.dp))
                val shown = retailers.filter { rt ->
                    search.isBlank() || rt.name.contains(search, true) || rt.retailerCode.contains(search, true)
                }
                if (shown.isEmpty()) {
                    Text("কোনো retailer মিলল না।", color = Color(0xFFE4EEF6), fontSize = 12.sp)
                }
                shown.forEach { retailer ->
                    Surface(
                        onClick = { selected = retailer; pin = ""; error = null },
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0x22FFFFFF),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(retailer.name, color = Color(0xFFFCFAF3), fontWeight = FontWeight.SemiBold)
                            Text(retailer.market, color = Color(0xFFE4EEF6), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            } else {
                val retailer = selected!!
                Spacer(Modifier.height(6.dp))
                Text(retailer.name, color = Color(0xFFE4EEF6), fontSize = 13.sp)
                Text(retailer.market, color = Color(0xFFE4EEF6), style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = pin, onValueChange = { if (it.length <= 5) pin = it.filter(Char::isDigit) },
                    label = { Text("PIN") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Color.White, unfocusedBorderColor = Color(0xFFE4EEF6)),
                )
                error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = Color(0xFFFFCDD2), fontSize = 11.sp) }
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        if (!MockRepository.verifyRetailerPin(retailer, pin)) { error = "Incorrect PIN, or no PIN has been set for this retailer yet — contact your administrator."; return@Button }
                        checking = true
                        error = null
                        scope.launch {
                            val loc = tryGetLoginLocation(context)
                            // NOTE — LocationAnomalyChecker.isTooFarToLogin only has
                            // centroid data for "SR"/"TSM"/"ASM" (district) and
                            // "RSM"/"DEALER" (division) roles; there's no
                            // market-level reference data for Retailer, so this
                            // call is a harmless no-op today (always returns
                            // false) rather than a real geo-block. Left in,
                            // rather than removed, so it activates automatically
                            // the moment market-centroid data is ever added —
                            // documented honestly here instead of silently
                            // pretending it already blocks anything.
                            val tooFar = loc != null && LocationAnomalyChecker.isTooFarToLogin("RETAILER", retailer.market, null, loc.first, loc.second)
                            checking = false
                            if (tooFar) {
                                error = "Too far from your registered area — login blocked."
                            } else {
                                onRetailerChosen(retailer.id)
                            }
                        }
                    },
                    enabled = !checking,
                    modifier = Modifier.fillMaxWidth(0.7f),
                ) { Text(if (checking) "Checking…" else "Continue") }
                TextButton(onClick = { selected = null; pin = ""; error = null }) {
                    Text("← Choose a different business", color = Color(0xFFE4EEF6), fontSize = 11.sp)
                }
            }

            Spacer(Modifier.height(20.dp))
            TextButton(onClick = onBackToStaffLogin) {
                Text("← Back to staff login", color = Color(0xFFE4EEF6), fontSize = 12.sp)
            }
        }
    }
}
