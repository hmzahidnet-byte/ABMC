package com.abm.erp.ui.hr

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.AdvanceEngine
import com.abm.erp.data.AttendanceEngine
import com.abm.erp.data.CascadeEngine
import com.abm.erp.data.LeaveStatus
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import kotlinx.coroutines.launch

/**
 * v113-387 — HR Approve drawer (HRM ধাপ ৮, শেষ ধাপ)।
 *
 * DMS-এর approve drawer-এর মতোই: **সব মুলতুবি সিদ্ধান্ত এক জায়গায়**।
 *
 * কেন এটা দরকার ছিল: HR-এর অনুমোদনগুলো এতদিন **চারটে আলাদা জায়গায়** ছড়িয়ে
 * ছিল — ছুটি PayrollScreen-এর Leave ট্যাবে, অগ্রিম Finance drawer-এ, নিয়োগ
 * HiringApprovalCenter-এ, আর হাজিরা/অন্যান্য generic queue-তে। কেউ রোজ চারটে
 * জায়গা খুলে দেখবে না, তাই আবেদন পড়ে থাকত। DMS-এ ঠিক এই সমস্যাটাই
 * v113-368-এ ধরা পড়েছিল (DealerStock-এর approve করার বোতামই কোথাও ছিল না)।
 *
 * ✔/✕ দুটোতেই **confirm** — লেখা বোতাম চাপার আগে পড়া যেত, খালি আইকন যায় না,
 * তাই নিরাপত্তাটা ফিরিয়ে দিতে হয়। এটা DMS-এ নেওয়া একই সিদ্ধান্ত।
 */
@Composable
fun HrApproveTab(onNavigate: (String) -> Unit = {}) {
    val leaves by MockRepository.leaveRequests.collectAsState()
    val advances by MockRepository.employeeAdvances.collectAsState()
    val employees by MockRepository.employeeProfiles.collectAsState()
    val scope = rememberCoroutineScope()

    val settings = remember(employees) { MockRepository.companySettings() }
    val holidays = remember(settings.holidaysRaw) { AttendanceEngine.parseHolidays(settings.holidaysRaw) }

    val pendingLeaves = remember(leaves) { leaves.filter { it.status == LeaveStatus.PENDING } }
    val pendingAdvances = remember(advances) { advances.filter { it.status == "PENDING" } }
    val pendingHiring = remember(employees) {
        employees.filter {
            !it.isDeleted &&
                (it.onboardingStatus == com.abm.erp.data.EmployeeOnboardingStatus.PENDING_CHAIRMAN_APPROVAL ||
                    it.onboardingStatus == com.abm.erp.data.EmployeeOnboardingStatus.RETURNED_FOR_CORRECTION)
        }
    }

    val canApproveLeave = AttendanceEngine.canApproveLeave(MockRepository.currentUser.role)
    val canApproveAdvance = CascadeEngine.wingOf(MockRepository.currentUser.role) == CascadeEngine.Wing.OFFICE

    var msg by remember { mutableStateOf<String?>(null) }
    var ok by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf<Triple<String, String, () -> Unit>?>(null) }

    Column(
        Modifier.fillMaxSize().background(com.abm.erp.theme.DashBg)
            .verticalScroll(rememberScrollState()).padding(12.dp),
    ) {
        // ── উপরের tile: কোথায় কত জমেছে ──
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile(Icons.Filled.CalendarMonth, "ছুটি", pendingLeaves.size, Color(0xFF2563EB), Modifier.weight(1f))
            Tile(Icons.Filled.Payments, "অগ্রিম", pendingAdvances.size, WarningAmber, Modifier.weight(1f))
            Tile(Icons.Filled.PersonAdd, "নিয়োগ", pendingHiring.size, SuccessGreen, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))

        // ── ছুটির আবেদন ──
        Section("ছুটির আবেদন", pendingLeaves.size) {
            if (pendingLeaves.isEmpty()) Empty("কোনো ছুটির আবেদন মুলতুবি নেই।")
            pendingLeaves.forEach { r ->
                val days = AttendanceEngine.leaveWorkingDays(r, settings.workingDays, holidays)
                RequestRow(
                    title = r.employeeName,
                    // কর্মদিবস আলাদা করে দেখানো হয়: শুক্রবার বা ঘোষিত ছুটি মাঝে
                    // পড়লে সেগুলো গোনা হয় না, আর অনুমোদনকারীর সেটা জানা দরকার
                    line1 = "${r.fromDate} – ${r.toDate} · $days কর্মদিবস",
                    line2 = "কারণ: ${r.reason.ifBlank { "লেখা হয়নি" }}",
                    canAct = canApproveLeave,
                    onApprove = {
                        confirm = Triple("ছুটি অনুমোদন?", "${r.employeeName} · $days কর্মদিবস") {
                            scope.launch {
                                // setLeaveStatus নিজেই Boolean ফেরত দেয় — সেটাই
                                // ব্যবহার করা হচ্ছে। আগে msg খালি কি না দেখে
                                // অনুমান করছিলাম, যা ভঙ্গুর: onRejected না ডাকা
                                // অথচ ব্যর্থ — এমন হলে ভুল করে "সফল" দেখাত।
                                val done = MockRepository.setLeaveStatus(r.id, LeaveStatus.APPROVED) { e ->
                                    ok = false; msg = "✖ $e"
                                }
                                if (done) { ok = true; msg = "✔ ছুটি অনুমোদিত" }
                            }
                        }
                    },
                    onReject = {
                        confirm = Triple("ছুটি বাতিল?", r.employeeName) {
                            scope.launch {
                                val done = MockRepository.setLeaveStatus(r.id, LeaveStatus.REJECTED) { e ->
                                    ok = false; msg = "✖ $e"
                                }
                                if (done) { ok = true; msg = "✔ বাতিল করা হয়েছে" }
                            }
                        }
                    },
                )
            }
            if (!canApproveLeave && pendingLeaves.isNotEmpty()) {
                Note("ছুটি অনুমোদন কেবল Wing 1 (office) করতে পারে।")
            }
        }

        Spacer(Modifier.height(10.dp))

        // ── অগ্রিমের আবেদন ──
        Section("অগ্রিমের আবেদন", pendingAdvances.size) {
            if (pendingAdvances.isEmpty()) Empty("কোনো অগ্রিমের আবেদন মুলতুবি নেই।")
            pendingAdvances.forEach { a ->
                RequestRow(
                    title = a.employeeName,
                    line1 = "৳${"%,.0f".format(a.amount)} · ${a.installments} কিস্তি · প্রতি মাসে ৳${"%,.0f".format(a.perInstallment)}",
                    line2 = "কারণ: ${a.reason}",
                    canAct = canApproveAdvance,
                    onApprove = {
                        confirm = Triple("অগ্রিম অনুমোদন?", "${a.employeeName} · ৳${"%,.0f".format(a.amount)}") {
                            AdvanceEngine.decide(a.id, true) { e ->
                                ok = e.isBlank(); msg = if (e.isBlank()) "✔ অনুমোদিত" else "✖ $e"
                            }
                        }
                    },
                    onReject = {
                        confirm = Triple("আবেদন বাতিল?", a.employeeName) {
                            AdvanceEngine.decide(a.id, false) { e ->
                                ok = e.isBlank(); msg = if (e.isBlank()) "✔ বাতিল" else "✖ $e"
                            }
                        }
                    },
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        // ── নিয়োগ ──
        Section("নিয়োগের আবেদন", pendingHiring.size) {
            if (pendingHiring.isEmpty()) Empty("কোনো নিয়োগ মুলতুবি নেই।")
            pendingHiring.forEach { e ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(32.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFFE8F7F0)),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.PersonAdd, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp)) }
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.fullName, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
                        Text(e.onboardingStatus.name, fontSize = 9.5.sp, color = TextSecondary)
                    }
                    // নিয়োগ অনুমোদনে কোড, মোবাইল, বিভাগ, role, territory, manager —
                    // অনেক তথ্য লাগে, তাই এখানে সিদ্ধান্ত না নিয়ে নিজস্ব পাতায়
                    // পাঠানো হয়। ছোট সারিতে ✔ দিলে ওই তথ্যগুলো বসানোর সুযোগই থাকত না।
                    Box(
                        Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFFEEF4FF))
                            .clickable { onNavigate("hiring_center") }
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                    ) { Text("খুলুন", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2563EB)) }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        // ── ভার্চুয়াল সাইন / হাজিরা সংশোধন ──
        // v113-388 — আপনার নিয়ম: "ভার্চুয়াল সাইন যা Wing 1-এর যে কেউই verify
        // করতে পারবে"। ব্যবস্থাটা আগে থেকেই ছিল (generic approval queue,
        // entityType "AttendanceRecord"), কিন্তু HR-এর কোথাও দেখানো হতো না —
        // তাই কেউ verify করত না। এখন এই drawer-এ, বাকি সবের পাশে।
        com.abm.erp.core.ModuleApprovalSection(
            title = "ভার্চুয়াল সাইন — verify দরকার",
            entityTypes = setOf("AttendanceRecord"),
        )

        msg?.let {
            Spacer(Modifier.height(10.dp))
            Text(it, fontSize = 11.sp, color = if (ok) SuccessGreen else DangerRed, lineHeight = 16.sp)
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "HR-এর সব মুলতুবি সিদ্ধান্ত এক জায়গায় — ছুটি, অগ্রিম, নিয়োগ। " +
                "আগে এগুলো আলাদা আলাদা পাতায় ছিল, তাই আবেদন পড়ে থাকত।",
            fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
        )
        Spacer(Modifier.height(24.dp))
    }

    val c = confirm
    if (c != null) {
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(c.first) },
            text = { Text(c.second) },
            confirmButton = {
                TextButton(onClick = { confirm = null; msg = null; c.third() }) {
                    Text("হ্যাঁ, নিশ্চিত", color = DarazOrange)
                }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("না, থাক") } },
        )
    }
}

/* ── ছোট সহায়ক ─────────────────────────────────────────────────────────── */

@Composable
private fun RequestRow(
    title: String,
    line1: String,
    line2: String,
    canAct: Boolean,
    onApprove: () -> Unit,
    onReject: () -> Unit,
) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
            Text(line1, fontSize = 11.sp, color = TextPrimary, maxLines = 1)
            Text(line2, fontSize = 9.5.sp, color = TextSecondary, maxLines = 2)
        }
        if (canAct) {
            Dot(Icons.Filled.Check, SuccessGreen, Color(0xFFE8F7F0), onApprove)
            Spacer(Modifier.width(3.dp))
            Dot(Icons.Filled.Close, DangerRed, Color(0xFFFDECEA), onReject)
        }
    }
}

@Composable
private fun Dot(icon: ImageVector, ink: Color, bg: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(30.dp).clip(RoundedCornerShape(15.dp)).background(bg).clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) { Icon(icon, contentDescription = null, tint = ink, modifier = Modifier.size(15.dp)) }
}

@Composable
private fun Tile(icon: ImageVector, label: String, count: Int, ink: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(13.dp)).background(Color.White)
            .border(1.dp, if (count > 0) DarazOrange else HairlineBorder, RoundedCornerShape(13.dp))
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = label, tint = ink, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 9.sp, color = TextSecondary)
        Text("$count", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = if (count > 0) DarazOrange else TextSecondary)
    }
}

@Composable
private fun Section(title: String, count: Int, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color.White)
            .border(1.dp, HairlineBorder, RoundedCornerShape(13.dp)).padding(11.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            if (count > 0) {
                Box(
                    Modifier.clip(RoundedCornerShape(8.dp)).background(DarazOrange).padding(horizontal = 7.dp, vertical = 1.dp),
                ) { Text("$count", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = Color.White) }
            }
        }
        content()
    }
}

@Composable
private fun Empty(text: String) {
    Spacer(Modifier.height(4.dp))
    Text(text, fontSize = 10.5.sp, color = TextSecondary)
}

@Composable
private fun Note(text: String) {
    Spacer(Modifier.height(6.dp))
    Text(text, fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp)
}
