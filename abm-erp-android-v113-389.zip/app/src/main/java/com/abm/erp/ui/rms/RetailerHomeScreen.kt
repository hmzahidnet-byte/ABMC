package com.abm.erp.ui.rms

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * v113-203 — Retailer's own self-service home, mirroring DealerHomeScreen's
 * overall shape (branded header + logout + own record list + helpdesk),
 * but deliberately WITHOUT DealerHomeScreen's "place a new order" form:
 * in this app's actual business flow, retailers are serviced by a visiting
 * Sales Rep who logs their memo/order for them (RmsMemoWorkspace) — there
 * is no self-ordering concept for a retailer the way there is for a
 * dealer ordering stock directly from the company. Rather than invent a
 * self-order flow that doesn't match the real workflow, this stays to
 * what's unambiguous: see your own account and recent memos, and reach
 * support. Easy to extend later if a genuine self-order need is confirmed.
 */
class RetailerHomeViewModel : ViewModel() {
    val retailers = MockRepository.retailers
    val orders = MockRepository.orders
    fun submitHelpdeskTicket(fromId: String, fromName: String, fromType: String, subject: String, message: String) =
        FirebaseSync.submitHelpdeskTicket(fromId, fromName, fromType, subject, message)
}

@Composable
fun RetailerHomeScreen(retailerId: String, onLogout: () -> Unit, vm: RetailerHomeViewModel = viewModel()) {
    val retailer = vm.retailers.collectAsState().value.firstOrNull { it.id == retailerId }
    val allOrders by vm.orders.collectAsState()
    val myOrders = remember(allOrders, retailerId, retailer) {
        allOrders.filter { it.retailerId == retailerId || (it.retailerId == null && it.retailerName == retailer?.name) }
            .sortedByDescending { it.loggedAt }
    }

    var showHelp by remember { mutableStateOf(false) }
    var helpSubject by remember { mutableStateOf("") }
    var helpMessage by remember { mutableStateOf("") }
    var helpJustSent by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().background(Color(0xFF0E7C7B)).padding(16.dp)) {
            Text("Retailer Portal", color = Color(0xFFE4EEF6), style = MaterialTheme.typography.labelSmall)
            Text(retailer?.name ?: "Retailer", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Text(retailer?.market ?: "", color = Color(0xFFE4EEF6), style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onLogout) { Text("Logout", color = Color.White) }
        }

        Column(
            Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
        ) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("আপনার একাউন্ট", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("বকেয়া (Due)", color = TextSecondary)
                    Text(
                        "৳${"%,.0f".format(retailer?.dueBalance ?: 0.0)}",
                        fontWeight = FontWeight.Bold,
                        color = if ((retailer?.dueBalance ?: 0.0) > 0) WarningAmber else SuccessGreen,
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("সাম্প্রতিক Memo", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            if (myOrders.isEmpty()) {
                Text("এখনো কোনো memo নেই।", color = TextSecondary)
            }
            myOrders.take(20).forEach { o -> RetailerOrderRow(o.orderNo, o.amount, o.stage.name); Spacer(Modifier.height(8.dp)) }

            Spacer(Modifier.height(16.dp))
            Text("সাহায্য দরকার?", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                if (!showHelp) {
                    OutlinedButton(onClick = { showHelp = true; helpJustSent = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("🎧 Raise a support ticket")
                    }
                } else {
                    OutlinedTextField(value = helpSubject, onValueChange = { helpSubject = it }, label = { Text("Subject") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = helpMessage, onValueChange = { helpMessage = it }, label = { Text("What's the problem?") }, modifier = Modifier.fillMaxWidth())
                    if (helpJustSent) {
                        Spacer(Modifier.height(6.dp))
                        Text("✓ Sent — staff will get back to you soon.", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (helpSubject.isBlank() || retailer == null) return@Button
                                vm.submitHelpdeskTicket(retailer.id, retailer.name, "Retailer", helpSubject, helpMessage)
                                helpSubject = ""; helpMessage = ""; helpJustSent = true
                            },
                        ) { Text("Send") }
                        OutlinedButton(onClick = { showHelp = false }) { Text("Close") }
                    }
                }
            }
        }
    }
}

@Composable
private fun RetailerOrderRow(orderNo: String, amount: Double, stage: String) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(orderNo, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            val color = when (stage) { "DELIVERED", "VERIFIED" -> SuccessGreen; "REJECTED", "CANCELLED" -> DangerRed; else -> WarningAmber }
            Text(stage, color = color, style = MaterialTheme.typography.labelSmall)
        }
        Text("৳${"%,.0f".format(amount)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    }
}
