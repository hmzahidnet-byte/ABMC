package com.abm.erp.data

import java.time.LocalDate

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * v113-386 — ROUTE ENGINE (HRM ধাপ ৭)
 *
 * আপনার নিয়ম, হুবহু:
 *
 *   *"Wing 1 panel wing 2 তে route plan দিবে, তবে cascade wise wing 2 তে
 *   route plan set করতে পারবে। যদি cascade e vacancy থাকে সেখানে — for
 *   example SR — কেউ, wing 1 head মানে chairman route plan দিতে পারবে।"*
 *
 * অর্থাৎ **নতুন কোনো নিয়ম লাগে না** — টার্গেট যেভাবে নামে, dealer যেভাবে
 * assign হয়, approval যেভাবে যায়, route plan-ও ঠিক সেভাবেই। একটাই
 * `CascadeEngine`, চার জায়গায় ব্যবহৃত। এই ফাইল সেটাকেই জিজ্ঞেস করে।
 *
 * ─── কেন gate দরকার ছিল ────────────────────────────────────────────────────
 * `MockRepository.createRoute()` আগে থেকেই ছিল, কিন্তু **কোনো permission
 * যাচাই ছাড়া** — যে কেউ যে কারও route বানাতে পারত। DMS-এ ঠিক এই ধরনের
 * ফাঁক বারবার সমস্যা করেছে (v113-368-এ stock গণনা, v113-375-এ payment
 * verify)। তাই gate এখানে, repository-তে নয়: নিয়ম এক জায়গায় থাকলে
 * বদলাতেও এক জায়গায় হয়।
 *
 * ─── মানচিত্রে DMS-এর তথ্য ─────────────────────────────────────────────────
 * আপনার প্রস্তাব: route plan-এর সময় ওই বাজারের dealer/retailer দেখা গেলে
 * কাজ মসৃণ হয়। `Dealer`/`Retailer` দুটোতেই `lat`/`lng` **আগে থেকেই আছে** —
 * কেউ ব্যবহার করছিল না। `marketSnapshot()` সেটাই তুলে আনে, যাতে route
 * বানানো অন্ধ কাজ না থাকে।
 * ═════════════════════════════════════════════════════════════════════════════
 */
object RouteEngine {

    /**
     * এই ব্যক্তি কাদের জন্য route plan বানাতে পারে।
     *
     * `CascadeEngine.canActOn` — অর্থাৎ Chairman সর্বত্র, Wing 1 পুরো Wing 2-এর
     * উপরে, আর Wing 2-এর ভেতরে নিজের অধীনস্থদের জন্য। ভ্যাকেন্সি হলে দায়িত্ব
     * উপরে ওঠে, তাই TSM না থাকলে ASM-ই SR-এর route বানাবে — আলাদা কিছু
     * লেখার দরকার হয়নি।
     */
    fun plannableFor(
        actor: EmployeeProfile,
        date: LocalDate = LocalDate.now(),
        employees: List<EmployeeProfile> = MockRepository.employeeProfiles.value.filter { !it.isDeleted },
    ): List<EmployeeProfile> = employees.filter {
        CascadeEngine.isActiveOn(it, date) && CascadeEngine.canActOn(actor, it, date, employees)
    }

    fun canPlanFor(
        actorId: String,
        subjectId: String,
        date: LocalDate = LocalDate.now(),
    ): Boolean {
        val all = MockRepository.employeeProfiles.value.filter { !it.isDeleted }
        val a = all.firstOrNull { it.id == actorId } ?: return false
        val s = all.firstOrNull { it.id == subjectId } ?: return false
        return CascadeEngine.canActOn(a, s, date, all)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // বাজারের ছবি — DMS-এর ডেটা
    // ─────────────────────────────────────────────────────────────────────────

    data class OutletPin(
        val id: String,
        val name: String,
        val isDealer: Boolean,
        val lat: Double?,
        val lng: Double?,
        val due: Double,
        /** শেষ লেনদেনের পর কত দিন — কোথায় আগে যেতে হবে তার সবচেয়ে সৎ সংকেত। */
        val daysSinceLastOrder: Int?,
    )

    data class MarketSnapshot(
        val dealers: List<OutletPin>,
        val retailers: List<OutletPin>,
    ) {
        val totalDue: Double get() = moneyRound(dealers.sumOf { it.due } + retailers.sumOf { it.due })
        /** ১৪ দিনের বেশি নীরব — route বানানোর সময় এদেরই আগে ধরা উচিত। */
        val stale: List<OutletPin>
            get() = (dealers + retailers).filter { (it.daysSinceLastOrder ?: 0) > 14 }
    }

    /**
     * একটা এলাকার dealer ও retailer, তাদের বাকি ও নীরবতা সহ।
     *
     * এলাকা মেলানো হয় `zone`/`market` ধরে — নিখুঁত নয়, কিন্তু এই কোডবেসে
     * এটুকুই আছে, আর অনুমানে lat/lng-এর দূরত্ব দিয়ে ছাঁকলে ভুল আউটলেট বাদ
     * পড়ত। ফাঁকা key দিলে সব ফেরত যায় (ছাঁকনি নেই), লুকিয়ে ফেলা নয়।
     */
    fun marketSnapshot(
        areaKey: String?,
        dealers: List<Dealer> = MockRepository.dealers.value,
        retailers: List<Retailer> = MockRepository.retailers.value,
        invoices: List<SalesInvoice> = MockRepository.salesInvoices.value,
        orders: List<RetailOrder> = MockRepository.orders.value,
        today: LocalDate = LocalDate.now(),
    ): MarketSnapshot {
        fun matches(a: String?, b: String?): Boolean =
            areaKey.isNullOrBlank() || a.equals(areaKey, true) || b.equals(areaKey, true)

        val dPins = dealers.filter { !it.isDeleted && it.hasBeenApproved && matches(it.zone, it.district) }
            .map { d ->
                val last = invoices.filter { it.dealerId == d.id && !it.isDeleted }
                    .maxByOrNull { it.createdAt }?.createdAt?.toLocalDate()
                OutletPin(
                    d.id, d.name, true, d.lat, d.lng, d.dueBalance,
                    last?.let { java.time.temporal.ChronoUnit.DAYS.between(it, today).toInt() },
                )
            }
        val rPins = retailers.filter { !it.isDeleted && matches(it.market, it.district) }
            .map { r ->
                val last = orders.filter { it.retailerId == r.id && it.stage != OrderStage.REJECTED }
                    .maxByOrNull { it.loggedAt }?.loggedAt?.toLocalDate()
                OutletPin(
                    r.id, r.name, false, r.lat, r.lng, r.dueBalance,
                    last?.let { java.time.temporal.ChronoUnit.DAYS.between(it, today).toInt() },
                )
            }
        return MarketSnapshot(dPins, rPins)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Route সংরক্ষণ
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Route বানানো বা হালনাগাদ।
     *
     * `outletIds`-এর **ক্রমই ভিজিটের ক্রম** — তালিকায় যেভাবে সাজানো, মাঠে
     * সেভাবেই যাবে। তাই ডুপ্লিকেট বাদ দেওয়া হয় ক্রম রেখে (`distinct()`),
     * এলোমেলো করে নয়: একই দোকান দুবার থাকলে দ্বিতীয়বার অর্থহীন, কিন্তু
     * প্রথমবারের অবস্থান গুরুত্বপূর্ণ।
     */
    fun saveRoute(
        actorId: String,
        routeId: String?,
        name: String,
        forEmployeeId: String,
        territoryId: String?,
        outletIds: List<String>,
        onResult: (String) -> Unit = {},
    ) {
        if (name.isBlank()) {
            onResult("Route-এর নাম দিন।")
            return
        }
        if (outletIds.isEmpty()) {
            onResult("অন্তত একটা outlet যোগ করুন — খালি route মাঠে কোনো কাজে আসে না।")
            return
        }
        if (!canPlanFor(actorId, forEmployeeId)) {
            val who = MockRepository.employeeProfiles.value.firstOrNull { it.id == forEmployeeId }?.fullName ?: "এই employee"
            onResult("$who-এর জন্য route plan দেওয়ার অধিকার আপনার নেই।")
            return
        }
        MockRepository.saveSalesRoute(
            routeId = routeId,
            name = name.trim(),
            territoryId = territoryId,
            assignedToEmployeeId = forEmployeeId,
            outletIds = outletIds.distinct(),
            onResult = onResult,
        )
    }

    /** এই ব্যক্তির route গুলো। */
    fun routesOf(
        employeeId: String,
        routes: List<SalesRoute> = MockRepository.salesRoutes.value,
    ): List<SalesRoute> = routes.filter { it.assignedToEmployeeId == employeeId && it.isActive }

    /**
     * পরিকল্পিত outlet-এর মধ্যে কতগুলো আজ ভিজিট হয়েছে।
     *
     * মানচিত্রে সবুজ/ফাঁপা marker আর "৪/৬ ভিজিট" — দুটোরই ভিত্তি এটা।
     */
    fun visitedToday(
        route: SalesRoute,
        visits: List<VisitLog> = MockRepository.visitLogs.value,
        today: LocalDate = LocalDate.now(),
    ): Set<String> = visits.filter { it.checkInAt.toLocalDate() == today }
        .map { it.partyId }.toSet().intersect(route.outletIds.toSet())
}
