package com.abm.erp.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.abm.erp.MainActivity
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

private const val CHANNEL_ID = "abm_general_notifications"

/**
 * Receives push notifications — Chairman's Notice broadcasts, complaint
 * updates, order/invoice status changes, and anything else pushed from the
 * backend. This is separate from PresenceHeartbeatService's own persistent
 * notification channel; that one is for the ongoing GPS heartbeat, this one
 * is for one-off pushed messages.
 */
class AbmFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // The token itself is written to Firestore once the user is known
        // to be logged in — see MockRepository.registerFcmToken(), called
        // right after a successful PIN login (LoginScreen.kt).
        FcmTokenHolder.pendingToken = token
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val title = message.notification?.title ?: message.data["title"] ?: "ABM ERP"
        val body = message.notification?.body ?: message.data["body"] ?: ""
        // v113-366 — a server push used to land in this file's own single
        // "General notifications" channel with no route, so tapping it just
        // opened the dashboard. AppNotifier already owns the real channels and
        // the deep-link Intent that MainActivity reads; a push should behave
        // exactly like the same event raised on-device, not like a lesser one.
        // The category comes from the payload when the sender provides one
        // (data["category"]); anything unknown falls back to GENERAL rather
        // than guessing a destination and dead-ending the tap.
        val category = message.data["category"]?.let { raw ->
            runCatching { com.abm.erp.data.NotificationCategory.valueOf(raw.trim().uppercase()) }.getOrNull()
        }
        if (category != null) {
            com.abm.erp.notifications.AppNotifier.post(applicationContext, category, title, body)
        } else {
            showNotification(title, body)
        }
    }

    private fun showNotification(title: String, body: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val existing = manager.getNotificationChannel(CHANNEL_ID)
            if (existing == null) {
                manager.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "General notifications", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
        }
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()
        try {
            manager.notify(System.currentTimeMillis().toInt(), notification)
        } catch (e: SecurityException) {
            // POST_NOTIFICATIONS was declined — Crashlytics logs this as a
            // non-fatal so we can see how often it happens, but the app
            // must never crash over a denied notification permission.
            FirebaseCrashlytics.getInstance().recordException(e)
        }
    }
}

/** Holds a token that arrived before login (e.g. app just installed) until MockRepository can attach it to the now-known employee/company. */
object FcmTokenHolder {
    var pendingToken: String? = null
}
