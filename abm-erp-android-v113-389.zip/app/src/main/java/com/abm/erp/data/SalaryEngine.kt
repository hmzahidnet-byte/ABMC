package com.abm.erp.data

import java.time.LocalDate

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * v113-382 — SALARY ENGINE (HRM ধাপ ৩)
 *
 * আলোচনায় ঠিক হওয়া নিয়ম, হুবহু:
 *
 *   · Wing 1 — বেসিক (তারা বিক্রি করে না)
 *   · Wing 2 — বেসিক + কমিশন mix
 *   · গঠন **ব্যক্তিভেদে** — কারও শুধু বেসিক, কারও শুধু কমিশন, কারও দুটোই
 *   · কমিশনের হার **Wing 1 ঠিক করে**
 *   · approve/delivery-র আগে কমিশন **কিছুই না**
 *   · **নগদ** → সাথে সাথে · **বাকি** → collection হলে, যতটা উঠল ততটার উপর
 *   · **Return** → বিয়োগ, চেইনের সবার, **কারণসহ দৃশ্যমান**
 *   · চেইনের সবাই পায় — নিজের বিক্রিতে এক হারে, অধীনস্থদের বিক্রিতে override হারে
 *   · **ভ্যাকেন্সি পূরণে কমিশন বাড়ে না** — "তাদের কমিশন বাড়বে না"
 *   · TA/DA আলাদা, মেশানো হয় না
 *   · কর্তন **Wing 1-এর ম্যানুয়াল সিদ্ধান্ত** — অ্যাপ নিজে কাটে না
 *
 * ─── পুরনো হিসাবের সাথে তিনটে সংঘর্ষ, ইচ্ছাকৃতভাবে বদলানো ───────────────────
 * `PayrollLine`-এর computed property গুলো (v86-এর) আমাদের নিয়ম মানে না:
 *   ১. `scalingFactor` — অর্জন অনুযায়ী বেসিক ৫০%–১৫০% করে দেয়। কিন্তু আপনার
 *      নিয়মে বেসিক নির্দিষ্ট, আর কমানো-বাড়ানো Wing 1-এর সিদ্ধান্ত।
 *   ২. `commission = achievedAmount × rate` — অর্জনের উপর। আমাদের নিয়মে
 *      **collection-এর উপর**, নইলে বাকি টাকার উপরেও কমিশন হয়ে যেত।
 *   ৩. `absencePenalty` — আপনাআপনি কাটে। আপনার নিয়মে অ্যাপ দেখায়, কাটে না।
 * ওই property গুলো ভাঙা হয়নি (অন্য স্ক্রিন এখনো পড়ে); এই engine সেগুলো
 * ব্যবহার না করে নিজের হিসাব করে। পুরনোগুলো সরানো আলাদা কাজ।
 * ═════════════════════════════════════════════════════════════════════════════
 */
object SalaryEngine {

    /**
     * একটা মাসের পূর্ণ হিসাব। প্রতিটা অংশ আলাদা রাখা হয়েছে যাতে পর্দায়
     * "প্রাপ্য কত, দেওয়া কত, পার্থক্য কেন" — তিনটেই দেখানো যায়।
     */
    data class Breakdown(
        val employeeId: String,
        val employeeName: String,
        val periodStart: LocalDate,
        val periodEnd: LocalDate,

        val basePay: Double,
        val ownSales: Double,
        val ownCommissionPct: Double,
        val ownCommission: Double,
        val teamSales: Double,
        val overrideCommissionPct: Double,
        val overrideCommission: Double,
        val taDa: Double,
        val returnDeduction: Double,
        val returnReasons: List<String>,

        /** Wing 1-এর হাতে-করা কর্তন (জরিমানা), কারণসহ। */
        val manualDeduction: Double = 0.0,
        val manualDeductionReason: String = "",

        /**
         * v113-389 — অগ্রিমের কিস্তি, আলাদা ঘরে।
         *
         * `manualDeduction`-এর সাথে মেশানো হয়নি — ইচ্ছাকৃত। দুটোর প্রকৃতি
         * সম্পূর্ণ আলাদা: জরিমানা Wing 1-এর **সিদ্ধান্ত** (না করলেও চলত),
         * কিস্তি **আগে থেকেই সম্মত ঋণ পরিশোধ** (অ্যাপ নিজেই কাটে)। এক ঘরে
         * মেশালে কর্মী দেখত "কর্তন ৫,৬০০" আর বুঝত না কতটা শাস্তি, কতটা
         * নিজের ধার শোধ।
         */
        val advanceInstalment: Double = 0.0,
        val advanceLabel: String = "",

        /** তথ্য হিসেবে — কাটা হয় না, Wing 1 দেখে সিদ্ধান্ত নেয়। */
        val lateDays: Int = 0,
        val absentDays: Int = 0,
    ) {
        /** কর্তনের আগে যা প্রাপ্য। */
        val gross: Double get() = moneyRound(basePay + ownCommission + overrideCommission + taDa)

        /** Return সমন্বয়ের পর — এটাই "প্রাপ্য"। */
        val payable: Double get() = moneyRound(gross - returnDeduction)

        /** Wing 1-এর কর্তন ও অগ্রিমের কিস্তি — দুটোর পর যা সত্যিই হাতে যায়। */
        val paid: Double get() = moneyRound(payable - manualDeduction - advanceInstalment)

        /**
         * প্রাপ্য আর দেওয়ার মোট ফারাক = জরিমানা + অগ্রিমের কিস্তি।
         *
         * v113-389 — দুটো কারণ একসাথে ধরা হয়, কিন্তু পর্দায় **আলাদা করে**
         * দেখানো হয়। "চেয়ারম্যান মর্জিমতো কাটবে, কিন্তু হিসাব একুরেটই
         * দেখাবে" — একটা মোট সংখ্যা দেখালে কর্মী বুঝত না কতটা শাস্তি আর
         * কতটা নিজের ধার শোধ।
         */
        val difference: Double get() = moneyRound(payable - paid)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // কমিশনের ভিত্তি — collection, অর্জন নয়
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * এই সময়সীমায় এই ব্যক্তির বিক্রি থেকে **আসলে কত টাকা উঠেছে**।
     *
     * কেন invoice-এর মোট নয়: "যে মাল বাকিতে যাবে ওই মালের কমিশন হবে না...
     * হিসাবটা হবে ওই party-র collection wise"। তাই:
     *
     *   · **নগদ (CASH)** invoice — approve হলেই পুরোটা গোনা হয়, কারণ টাকা
     *     তখনই হাতে এসেছে
     *   · **COD** — PAID হলে, অর্থাৎ delivery-তে টাকা ওঠার পর
     *   · **বাকি (DUE)** — `paidAmount` যতটা, ততটাই; আংশিক আদায়ে আংশিক কমিশন
     *
     * `paidAmount` ভরসাযোগ্য, কারণ v113-376-এর FIFO auto-allocation প্রতিটা
     * verified collection-কে পুরনো invoice থেকে বসিয়ে দেয় — কোন টাকা কোন
     * invoice-এর, অ্যাপ ইতিমধ্যেই জানে।
     */
    fun collectedSalesOf(
        employeeName: String,
        periodStart: LocalDate,
        periodEnd: LocalDate,
        invoices: List<SalesInvoice> = MockRepository.salesInvoices.value,
    ): Double {
        val mine = invoices.filter {
            !it.isDeleted && it.createdBy == employeeName &&
                !it.createdAt.toLocalDate().isBefore(periodStart) &&
                !it.createdAt.toLocalDate().isAfter(periodEnd)
        }
        return moneyRound(
            mine.sumOf { inv ->
                when {
                    inv.status == "CANCELLED" || inv.status == "PENDING" || inv.status == "REJECTED" -> 0.0
                    inv.paymentMethod == "CASH" -> inv.netAfterDiscount
                    inv.paymentMethod == "COD" -> if (inv.status == "PAID") inv.netAfterDiscount else 0.0
                    else -> inv.paidAmount.coerceAtMost(inv.netAfterDiscount)
                }
            },
        )
    }

    /**
     * Return-এর কারণে কত কমিশন ফেরত যাবে, আর কেন।
     *
     * "রিটার্ন হলেও বিমান হারে সবারটা কাটবে, তবে কত কাটলো তার visually দেখা
     * যাবে কারণ সহ" — তাই শুধু অঙ্ক নয়, কারণের তালিকাও ফেরত দেওয়া হয়।
     *
     * কাটা হয় **যে বিক্রি করেছিল** তার খাতা থেকে — সময়-ভিত্তিক নিয়মেই, আর
     * তাতেই ন্যায্য: যে টাকা পেয়েছিল সে-ই ফেরত দিচ্ছে।
     */
    fun returnAdjustment(
        employeeName: String,
        commissionPct: Double,
        periodStart: LocalDate,
        periodEnd: LocalDate,
        returns: List<SalesReturn> = MockRepository.salesReturns.value,
        invoices: List<SalesInvoice> = MockRepository.salesInvoices.value,
    ): Pair<Double, List<String>> {
        if (commissionPct <= 0.0) return 0.0 to emptyList()
        val reasons = mutableListOf<String>()
        var total = 0.0
        returns.filter {
            it.status == "APPROVED" &&
                !it.createdAt.toLocalDate().isBefore(periodStart) &&
                !it.createdAt.toLocalDate().isAfter(periodEnd)
        }.forEach { ret ->
            // যার invoice, তার কমিশন কাটবে — return কে জমা দিল তা নয়
            val inv = ret.invoiceId?.let { id -> invoices.firstOrNull { it.id == id } }
            val soldBy = inv?.createdBy ?: ret.createdBy
            if (soldBy != employeeName) return@forEach
            val value = if (ret.refundAmount > 0.0) ret.refundAmount else ret.lineItems.sumOf { it.lineTotal }
            val cut = moneyRound(value * commissionPct / 100.0)
            if (cut <= 0.0) return@forEach
            total += cut
            reasons += "${ret.returnNo} — ${ret.reason.ifBlank { "কারণ লেখা হয়নি" }} · ৳${"%,.2f".format(cut)}"
        }
        return moneyRound(total) to reasons
    }

    // ─────────────────────────────────────────────────────────────────────────
    // পূর্ণ হিসাব
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * একজনের এক মাসের হিসাব।
     *
     * অধীনস্থ কারা — সেটা `CascadeEngine` ঠিক করে, এখানে নতুন নিয়ম নেই।
     * আর **ভ্যাকেন্সি পূরণে বাড়তি কিছু যোগ হয় না**: করিম TSM-এর কাজ চালালেও
     * তার override হার তার নিজেরটাই থাকে, TSM-এর হার কেউ পায় না।
     */
    fun compute(
        employee: EmployeeProfile,
        periodStart: LocalDate,
        periodEnd: LocalDate,
        manualDeduction: Double = 0.0,
        manualDeductionReason: String = "",
        lateDays: Int = 0,
        absentDays: Int = 0,
        employees: List<EmployeeProfile> = MockRepository.employeeProfiles.value.filter { !it.isDeleted },
        invoices: List<SalesInvoice> = MockRepository.salesInvoices.value,
        returns: List<SalesReturn> = MockRepository.salesReturns.value,
    ): Breakdown {
        val own = collectedSalesOf(employee.fullName, periodStart, periodEnd, invoices)
        val ownComm = moneyRound(own * employee.ownCommissionPct / 100.0)

        // অধীনস্থদের বিক্রি — override হারে
        val team = if (employee.overrideCommissionPct <= 0.0) 0.0 else {
            CascadeEngine.allReportsOf(employee, periodEnd, employees)
                .sumOf { collectedSalesOf(it.fullName, periodStart, periodEnd, invoices) }
                .let { moneyRound(it) }
        }
        val overrideComm = moneyRound(team * employee.overrideCommissionPct / 100.0)

        val (retCut, retReasons) = returnAdjustment(
            employee.fullName, employee.ownCommissionPct, periodStart, periodEnd, returns, invoices,
        )

        return Breakdown(
            employeeId = employee.id,
            employeeName = employee.fullName,
            periodStart = periodStart,
            periodEnd = periodEnd,
            basePay = moneyRound(employee.basePayMonthly),
            ownSales = own,
            ownCommissionPct = employee.ownCommissionPct,
            ownCommission = ownComm,
            teamSales = team,
            overrideCommissionPct = employee.overrideCommissionPct,
            overrideCommission = overrideComm,
            taDa = moneyRound(employee.taDaMonthly),
            returnDeduction = retCut,
            returnReasons = retReasons,
            manualDeduction = moneyRound(manualDeduction),
            manualDeductionReason = manualDeductionReason,
            // v113-389 — চলমান অগ্রিম থাকলে এই মাসের কিস্তি আপনাআপনি বসে।
            // v113-384-এ পর্দায় লিখেছিলাম "বেতন থেকে আপনাআপনি কাটে", কিন্তু
            // SalaryEngine অগ্রিমের কথা জানতই না — লেখা আর কোড আলাদা ছিল।
            advanceInstalment = AdvanceEngine.dueThisMonth(employee.id),
            advanceLabel = AdvanceEngine.runningAdvance(employee.id)?.let {
                "অগ্রিম — বাকি ৳${"%,.2f".format(it.outstanding)}"
            } ?: "",
            lateDays = lateDays,
            absentDays = absentDays,
        )
    }

    /**
     * বেতনের গঠন বদলানো — কেবল Wing 1 ("কমিশন হার wing 1 set করে")।
     *
     * বদল **আগামীর জন্য**: চলতি মাসের হিসাব নতুন হারে হবে। পুরনো মাস
     * অক্ষত থাকে কারণ ওই মাসের হিসাব ইতিমধ্যে `PayrollLine`-এ লেখা হয়ে
     * গেছে — গঠন বদলালে সেটা বদলায় না। এটাই "সেই মাসের গঠন সারিতেই লিখে
     * রাখা"-র মূল উদ্দেশ্য।
     */
    fun setStructure(
        employeeId: String,
        basePay: Double,
        ownPct: Double,
        overridePct: Double,
        taDa: Double,
        onResult: (String) -> Unit = {},
    ) {
        val actor = MockRepository.currentUser
        if (CascadeEngine.wingOf(actor.role) != CascadeEngine.Wing.OFFICE) {
            onResult("বেতনের গঠন কেবল Wing 1 (office) ঠিক করতে পারে।")
            return
        }
        if (ownPct < 0 || overridePct < 0 || basePay < 0 || taDa < 0) {
            onResult("ঋণাত্মক মান দেওয়া যাবে না।")
            return
        }
        if (ownPct > 100 || overridePct > 100) {
            onResult("কমিশনের হার ১০০%-এর বেশি হতে পারে না।")
            return
        }
        MockRepository.updateSalaryStructure(employeeId, basePay, ownPct, overridePct, taDa, onResult)
    }
}
