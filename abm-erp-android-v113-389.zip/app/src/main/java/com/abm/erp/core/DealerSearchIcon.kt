package com.abm.erp.core

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.abm.erp.data.Dealer
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

/**
 * v113-305 — item 11 of the person's 14-point list: "Invoice theke suru
 * kore Pura dms system e joto Deler sarch button ase oigaula akta akta
 * Deler icon akare hbe icon e click korle then box asbe. Ete kore screen
 * ta onk sapce pabe ar fresh n clean look debe."
 *
 * Every "search for a dealer" surface across DMS was its own always-open
 * inline search field, each permanently occupying a full row of vertical
 * space even when nobody was searching. This replaces them with a single
 * small icon: tapping it opens a real search dialog, picking a dealer
 * closes it and reports the choice back.
 *
 * One shared implementation rather than per-screen copies, so every
 * dealer-search surface behaves identically and future changes land
 * everywhere at once — the same consolidation principle that fixed the
 * duplicate Dealer list in v113-299.
 *
 * @param selectedLabel what to show beside the icon when a dealer is
 *   already chosen; null renders the icon alone (the most compact form).
 */
@Composable
fun DealerSearchIcon(
    dealers: List<Dealer>,
    onPick: (Dealer) -> Unit,
    modifier: Modifier = Modifier,
    selectedLabel: String? = null,
    accent: Color = Color(0xFF2563EB),
    emptyText: String = "কোনো Dealer পাওয়া যায়নি।",
) {
    var open by remember { mutableStateOf(false) }

    Row(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selectedLabel != null) accent.copy(alpha = 0.08f) else Color.Transparent)
            .border(1.dp, if (selectedLabel != null) accent.copy(alpha = 0.4f) else HairlineBorder, RoundedCornerShape(10.dp))
            .clickable { open = true }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Store, contentDescription = "Dealer খুঁজুন", tint = accent, modifier = Modifier.size(18.dp))
        if (selectedLabel != null) {
            Spacer(Modifier.width(8.dp))
            Text(selectedLabel, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
        }
    }

    if (open) {
        DealerSearchDialog(
            dealers = dealers,
            emptyText = emptyText,
            onDismiss = { open = false },
            onPick = { d -> onPick(d); open = false },
        )
    }
}

/**
 * v113-308 — the generic sibling of `DealerSearchIcon`, for the same
 * "pick one party" pattern where the parties aren't `Dealer` objects.
 * Closes the loose end named in v113-305: item 11 asked for dealer
 * search specifically, so retailer-side pickers with the identical
 * always-open-field shape were left alone at the time. This gives them
 * the same icon-then-box treatment without forcing them through the
 * `Dealer` type.
 *
 * Takes plain display values rather than a domain type, so any
 * party-like list (retailers, campaign parties, collection parties) can
 * use it as-is.
 */
@Composable
fun PartySearchIcon(
    partyLabel: String,
    items: List<PartyPickItem>,
    onPick: (String) -> Unit,
    modifier: Modifier = Modifier,
    accent: Color = Color(0xFF2563EB),
) {
    var open by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    Row(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, HairlineBorder, RoundedCornerShape(10.dp))
            .clickable { open = true }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Store, contentDescription = "$partyLabel খুঁজুন", tint = accent, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text("$partyLabel বাছুন", color = TextSecondary, fontSize = 13.sp)
    }

    if (open) {
        val filtered = remember(items, query) {
            if (query.isBlank()) items
            else items.filter { it.name.contains(query, true) || it.subtitle.contains(query, true) }
        }
        Dialog(onDismissRequest = { open = false }) {
            Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
                Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("$partyLabel বাছুন", fontWeight = FontWeight.Bold, color = TextPrimary, modifier = Modifier.weight(1f))
                        IconButton(onClick = { open = false }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Filled.Close, contentDescription = "বন্ধ করুন", tint = TextSecondary, modifier = Modifier.size(18.dp))
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        placeholder = { Text("নাম বা এলাকা…") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp)) },
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(10.dp))
                    if (filtered.isEmpty()) {
                        Text("কিছু পাওয়া যায়নি।", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(filtered.take(60), key = { it.id }) { item ->
                            val rowAccent = browseAvatarColor(item.name)
                            Row(
                                Modifier.fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Brush.linearGradient(listOf(rowAccent.copy(alpha = 0.09f), Color.White)))
                                    .border(1.dp, rowAccent.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                                    .clickable { onPick(item.id); open = false; query = "" }
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(
                                    Modifier.size(34.dp).clip(RoundedCornerShape(9.dp))
                                        .background(Brush.linearGradient(listOf(rowAccent.copy(alpha = 0.85f), rowAccent))),
                                    contentAlignment = Alignment.Center,
                                ) { Text(browseInitials(item.name), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(item.name, fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 13.sp, maxLines = 1)
                                    if (item.subtitle.isNotBlank()) {
                                        Text(item.subtitle, fontSize = 11.sp, color = TextSecondary, maxLines = 1)
                                    }
                                }
                                if (item.trailing.isNotBlank()) {
                                    Text(item.trailing, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = com.abm.erp.theme.WarningAmber)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Plain display shape for [PartySearchIcon] — deliberately not tied to any domain type. */
data class PartyPickItem(val id: String, val name: String, val subtitle: String = "", val trailing: String = "")

@Composable
fun DealerSearchDialog(
    dealers: List<Dealer>,
    onDismiss: () -> Unit,
    onPick: (Dealer) -> Unit,
    emptyText: String = "কোনো Dealer পাওয়া যায়নি।",
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(dealers, query) {
        val live = dealers.filter { !it.isDeleted }
        if (query.isBlank()) live
        else live.filter {
            it.name.contains(query, true) || it.zone.contains(query, true) || it.dealerCode.contains(query, true) || it.phone.contains(query, true)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
            Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Dealer বাছুন", fontWeight = FontWeight.Bold, color = TextPrimary, modifier = Modifier.weight(1f))
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Filled.Close, contentDescription = "বন্ধ করুন", tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("নাম, কোড, ফোন বা এলাকা…") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp)) },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(10.dp))
                if (filtered.isEmpty()) {
                    Text(emptyText, color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(filtered.take(60), key = { it.id }) { d ->
                        val rowAccent = browseAvatarColor(d.name)
                        Row(
                            Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Brush.linearGradient(listOf(rowAccent.copy(alpha = 0.09f), Color.White)))
                                .border(1.dp, rowAccent.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                                .clickable { onPick(d) }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier.size(34.dp).clip(RoundedCornerShape(9.dp))
                                    .background(Brush.linearGradient(listOf(rowAccent.copy(alpha = 0.85f), rowAccent))),
                                contentAlignment = Alignment.Center,
                            ) { Text(browseInitials(d.name), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(d.name, fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 13.sp, maxLines = 1)
                                Text(
                                    "${d.dealerCode.ifBlank { d.id.take(8).uppercase() }} · ${d.zone}",
                                    fontSize = 11.sp, color = TextSecondary, maxLines = 1,
                                )
                            }
                            if (d.dueBalance > 0) {
                                Text(
                                    "৳${"%,.0f".format(d.dueBalance)}",
                                    fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                    color = com.abm.erp.theme.WarningAmber,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
