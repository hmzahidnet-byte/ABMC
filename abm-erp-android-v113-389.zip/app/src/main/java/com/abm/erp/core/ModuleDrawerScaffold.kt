package com.abm.erp.core

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.theme.DashBg
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * v113-74 — the shell every "mother module" uses (DMS, RMS, HR, FMS, Chairman, AI).
 *
 * The person's rule, restated from the drafts:
 *  - the Home Dashboard shows exactly six mother modules and nothing else;
 *  - entering one opens a left drawer listing only *that* module's options;
 *  - picking an option closes the drawer, so the option gets the whole screen —
 *    that is the entire point ("phone er display ta onek boro pabo");
 *  - one module's drawer never lists another module's items. To switch modules you
 *    go back to Home. This keeps the UI clean and is why there is no cross-module
 *    shortcut anywhere in here.
 *
 * Only the *shell* is shared. Each module passes its own item list, its own colours
 * and its own content — the options are deliberately different per module.
 *
 * Performance: this renders on every module entry, so the drawer body is a plain
 * Column in a scroll container (item counts are ~8–10, a LazyColumn would cost more
 * than it saves) and no work happens in composition beyond drawing. Target is a
 * steady 90Hz minimum, 120Hz where the panel allows.
 */
// v113-267 — the person's own direct request: each drawer item its own
// colour, "eye-catching", a bit of glossy/"3D" feel — a tasteful, curated
// palette (not raw saturated primaries) cycled by position, one accent
// colour per row, applied to that row's own icon chip + label together.
private val DRAWER_ITEM_PALETTE = listOf(
    0xFFE85D4A, 0xFF2563EB, 0xFF1FA972, 0xFF9C6EFF, 0xFFDB2777,
    0xFF0EA5A4, 0xFFF5A623, 0xFF8A6DFF, 0xFF12C2A9, 0xFF475569,
)

data class ModuleDrawerItem(
    val key: String,
    val label: String,
    val icon: ImageVector,
    /** Optional short line under the label, e.g. "Direct Invoice + Auto Data". */
    val hint: String = "",
)

// ============================================================
// v113-263 — the person's own confirmed, concrete example: a Ledger
// screen has no single per-row "record" the way a Dealer/Voucher does, so
// UniversalActionMenu's own per-row model doesn't fit it — but the person
// still needs to Export/Share/Print it, and the module's own ⋮ (which
// exists on every screen already, always in the same place) is the
// logical, single place for that, not a bespoke button re-invented per
// screen. Any content screen — arbitrarily deep in the module (a Ledger
// reached via List → Details → Ledger, several composables down) — can
// call `RegisterModuleMenuContent` to make the module's own ⋮ genuinely
// export/share/print whatever it's currently showing. A CompositionLocal
// is the right tool here specifically because the registering screen can
// be many levels deep with no direct parameter path back up to
// ModuleDrawerScaffold — threading a callback through every intermediate
// composable's own signature would be a far riskier edit than this.
// ============================================================

/** Holds whatever the CURRENTLY-shown screen has registered for the module's own ⋮ to export/share/print. Null fields = nothing registered — the ⋮ shows only Home, same as before. */
class ModuleMenuContent {
    var title by mutableStateOf<String?>(null)
    var rows by mutableStateOf<List<Pair<String, String>>>(emptyList())
}

val LocalModuleMenuContent = staticCompositionLocalOf<ModuleMenuContent?> { null }

/**
 * Call from any content screen (however deep inside a mother module) that
 * wants the module's own ⋮ to offer real Export CSV/PDF/Share/Print for
 * what's currently on screen — a Ledger table, a report, anything without
 * a natural per-row UniversalActionMenu. Registers on entry; clears on
 * leaving (via DisposableEffect, keyed so a stale screen's content can
 * never be exported after navigating away from it — checked directly
 * against Compose's own documented DisposableEffect lifecycle rather than
 * assumed safe). A no-op if called outside a ModuleDrawerScaffold (the
 * CompositionLocal is null), so nothing crashes if reused somewhere this
 * shell doesn't wrap.
 */
@Composable
fun RegisterModuleMenuContent(title: String, rows: List<Pair<String, String>>) {
    val holder = LocalModuleMenuContent.current ?: return
    DisposableEffect(title, rows) {
        holder.title = title
        holder.rows = rows
        onDispose {
            if (holder.title == title) {
                holder.title = null
                holder.rows = emptyList()
            }
        }
    }
}

// v113-276 — the person's own direct instruction: the module-level ⋮
// should show the SAME rich UniversalActionMenu options (View Details/
// Preview/Correction Request/Approval History/Activity Log/Attachments/
// Export/Share/Print) a specific record's own Detail screen already has
// inline — not a second, thinner menu. A separate holder from
// ModuleMenuContent above rather than extending it: that one is a
// screen-level "title + summary rows" concept (Ledger tables, Dashboards
// — nothing that is itself one specific record), this one is a genuine
// single record's own identity (moduleReference/entityId/entityLabel) —
// conflating the two would have made ModuleMenuContent ambiguous about
// which shape of data it's holding at any given moment.
class RecordActionMenuData {
    var moduleReference by mutableStateOf<String?>(null)
    var entityId by mutableStateOf("")
    var entityLabel by mutableStateOf("")
    var shareText by mutableStateOf("")
    var csvHeader by mutableStateOf("")
    var csvRow by mutableStateOf("")
    // v113-358 — the top ⋮ used to share the GENERIC title+body image even when
    // the record's own ⋮ had a bespoke document. Carried here so both triggers
    // produce the same file.
    var customDocumentImage by mutableStateOf<(suspend (android.content.Context) -> android.graphics.Bitmap)?>(null)

    // v113-363 — a screen can add its OWN item to the module ⋮ (the person's
    // instruction for the COD board: "ওই মেনুতে তুমি আরেকটা বাটন যোগ করবে").
    // Rides the same single-popup path v113-361 established, so a screen item
    // and the universal items sit in one menu under the ⋮, not two.
    var extraMenuItems by mutableStateOf<(@Composable ColumnScope.() -> Unit)?>(null)
}

/**
 * v113-363 — registers one extra ⋮ item for as long as the calling screen is on
 * screen. Deliberately separate from RegisterRecordActionMenu: a screen may want
 * its own action without pretending to be a record.
 */
@Composable
fun RegisterMenuExtraItems(key: Any?, items: @Composable ColumnScope.() -> Unit) {
    val holder = LocalRecordActionMenu.current ?: return
    DisposableEffect(key) {
        holder.extraMenuItems = items
        onDispose { holder.extraMenuItems = null }
    }
}

val LocalRecordActionMenu = staticCompositionLocalOf<RecordActionMenuData?> { null }

/**
 * Call from a screen showing one specific record's own full detail (a
 * Dealer/Retailer/Employee/Product Detail screen, an Invoice/Memo
 * document view, etc.) so the module-level ⋮ can offer that SAME
 * record's real UniversalActionMenuBody. Deliberately mirrors only the
 * safe, viewing-type parameters ModuleBrowseDetail's own inline
 * UniversalActionMenu call already uses (moduleReference/entityId/
 * entityLabel/shareText/csvHeader/csvRow — confirmed directly against
 * that call site before matching it, not guessed) — mutating actions
 * (Edit/Approve/Reject/Duplicate/Archive) stay on the record's own
 * inline menu, where the person can see the actual record they're acting
 * on, not a second copy triggered from a completely different position
 * on screen. Registers on entry, clears on leaving — same real
 * DisposableEffect lifecycle pattern as RegisterModuleMenuContent above.
 */
@Composable
fun RegisterRecordActionMenu(
    moduleReference: String,
    entityId: String,
    entityLabel: String,
    shareText: String,
    // v113-358 — so the top ⋮ shares the SAME bespoke document the record's own
    // ⋮ does, instead of the generic title+body image.
    customDocumentImage: (suspend (android.content.Context) -> android.graphics.Bitmap)? = null,
    csvHeader: String = "",
    csvRow: String = "",
) {
    val holder = LocalRecordActionMenu.current ?: return
    DisposableEffect(moduleReference, entityId) {
        holder.moduleReference = moduleReference
        holder.entityId = entityId
        holder.entityLabel = entityLabel
        holder.shareText = shareText
        holder.customDocumentImage = customDocumentImage
        holder.csvHeader = csvHeader
        holder.csvRow = csvRow
        onDispose {
            if (holder.moduleReference == moduleReference && holder.entityId == entityId) {
                holder.moduleReference = null
            }
        }
    }
}

@Composable
fun ModuleDrawerScaffold(
    moduleName: String,
    moduleSubtitle: String,
    colorStart: Long,
    colorEnd: Long,
    moduleIcon: ImageVector,
    items: List<ModuleDrawerItem>,
    selectedKey: String,
    onSelect: (String) -> Unit,
    onBackToHome: () -> Unit,
    // v113-211 — the person's own request: when viewing a completed
    // invoice/memo, the document itself should fill the whole screen
    // rather than sitting under this module's own "hamburger + name +
    // Home" bar. Defaults to false (unchanged for every other screen in
    // every module) — only the specific workspace that owns a "viewing a
    // finished document" state opts into this, and only while that state
    // is active. The content itself already carries its own "← ফিরে যান"
    // exit affordance (confirmed directly in DmsInvoiceWorkspace before
    // relying on it here), so hiding this bar never strands the person.
    hideTopBar: Boolean = false,
    // v113-260 — the person's own confirmed instruction: only the phone's
    // own back gesture/button navigates now that TaskHeader/BrowseTopBar/
    // ModuleWorkspaceHeader's visible arrows are gone. Several drawer
    // items never had a header at all even before this batch (Alerts,
    // Approve, Finance, CollectionWorkspace, PartyCampaignSection,
    // CourierScreen, ComplaintBoxScreen…) — for those, reopening the
    // drawer was the only way back. `homeKey` names the key that counts
    // as this module's own landing screen (defaults to "dashboard"; DMS
    // passes "list", its own real landing key since v113-249) so back
    // consistently returns there from any other key, and — once already
    // on that landing key — a further back press falls through to the
    // real NavGraph pop (leaving the module), matching `onBackToHome`.
    // The ⋮ menu's own content is deliberately untouched this batch — the
    // person's own instruction was to leave it exactly as it is.
    homeKey: String = "dashboard",
    content: @Composable (String) -> Unit,
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val start = Color(colorStart)
    val end = Color(colorEnd)
    // v113-263 — one holder per module-shell instance, provided down
    // through composition so any content screen — however deep — can
    // register what the ⋮ should Export/Share/Print right now.
    val menuContent = remember { ModuleMenuContent() }
    val recordActionMenu = remember { RecordActionMenuData() }
    // v113-296 — the person's own direct instruction: the top ⋮ should
    // reflect whichever record's own local ⋮ was most recently tapped
    // (see UniversalActionMenu's own thin wrapper). Cleared whenever the
    // person switches to a different drawer item, so a record tapped on
    // one screen doesn't linger and show up as if it belonged to a
    // completely different, unrelated screen navigated to afterward.
    LaunchedEffect(selectedKey) { recordActionMenu.moduleReference = null }

    androidx.activity.compose.BackHandler(enabled = selectedKey != homeKey) { onSelect(homeKey) }

    CompositionLocalProvider(LocalModuleMenuContent provides menuContent, LocalRecordActionMenu provides recordActionMenu) {
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = DashBg) {
                Column(
                    Modifier.fillMaxWidth()
                        .background(Brush.linearGradient(listOf(start, end)))
                        .padding(18.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(moduleIcon, contentDescription = null, tint = Color.White)
                        Spacer(Modifier.width(10.dp))
                        Text(moduleName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(moduleSubtitle, color = Color(0xFFE8ECFF), fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    // v113-267 — the person's own direct request: each
                    // drawer item felt monotone (same colour every row) —
                    // eye-catching, "3D vibe"/glossy per item instead. A
                    // small fixed palette, cycled by position, applied to
                    // the icon's own chip (a soft gradient, for the glossy
                    // feel asked for) and the label text — only when NOT
                    // the currently-selected item, so the existing
                    // selection highlight (the module's own accent colour,
                    // bold text) stays the one clear "you are here"
                    // signal, not competing with a second colour scheme.
                    items.forEachIndexed { idx, item ->
                        val selected = item.key == selectedKey
                        val accent = Color(DRAWER_ITEM_PALETTE[idx % DRAWER_ITEM_PALETTE.size])
                        Row(
                            Modifier.fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 3.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (selected) start.copy(alpha = 0.12f) else Color.Transparent)
                                .clickable {
                                    onSelect(item.key)
                                    // Close on pick — this is what frees the whole screen for the task.
                                    scope.launch { drawerState.close() }
                                }
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier.size(34.dp).clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (selected) Brush.linearGradient(listOf(start, end))
                                        else Brush.linearGradient(listOf(accent.copy(alpha = 0.85f), accent)),
                                    ),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(
                                    item.icon, contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    item.label,
                                    color = if (selected) start else accent,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                )
                                if (item.hint.isNotBlank()) {
                                    Text(item.hint, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                }
                            }
                        }
                    }
                }
                Divider()
                Row(
                    Modifier.fillMaxWidth().clickable { onBackToHome() }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("← Home", color = TextSecondary, style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.weight(1f))
                    Text(
                        "অন্য মডিউলে যেতে Home-এ ফিরুন",
                        style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                    )
                }
            }
        },
    ) {
        Box(Modifier.fillMaxSize()) {
            // v113-262 — the person's own repeated point: not just the
            // SECOND header (already removed, v113-260) — this bar's own
            // solid colour band was itself costing real vertical space
            // and visual weight, the exact same complaint from the start
            // ("phone display already small"). The colour fill is gone;
            // ☰/⋮ are now small floating icon chips with their own
            // individual dark backing (not a full-width coloured strip)
            // instead of a solid bar.
            // v113-277 — the person's own further, now-explicit
            // instruction: even the small transparent GAP the content
            // used to be pushed down by (reserved so ☰/⋮ never sat on
            // top of a screen's own top content) should go too — "কিছুরই
            // দরকার নাই, running page-টাই বড় আকারে দেখাবে" (nothing's
            // needed there, the running page itself should show big).
            // Every screen now behaves the way `hideTopBar=true` screens
            // already did — content starts at the very top of the
            // screen, using the full display — and ☰/⋮ float ON TOP as a
            // real overlay (their own dark semi-transparent circular
            // backing already exists specifically so they stay legible
            // over whatever's underneath) rather than content being
            // pushed down to make room for them.
            var overflowOpen by remember { mutableStateOf(false) }
            Column(Modifier.fillMaxSize()) {
                content(selectedKey)
            }
            // v113-351 — the one host for the full-screen success tick
            // (SuccessBus). Placed here because this scaffold wraps every
            // module screen, so any completed action anywhere shows the
            // same centre-screen celebration without per-screen plumbing.
            SuccessOverlayHost()
            if (!hideTopBar) {
            // v113-333 — corrected placement. Their instruction was "akdm
            // left e bottom e hbe top e na" — bottom-left, not top. I had
            // read the earlier "menu button er akdm niche" as "directly
            // beside ☰" and put it in the top bar; that was wrong.
            //
            // It sits in the same full-size Box overlay as ☰/⋮ and carries
            // the same dark circular backing, so it stays legible over
            // whatever content is underneath — and because it is an
            // overlay, no screen loses any height to it.
            //
            // Behaviour still mirrors the scaffold's own BackHandler
            // exactly, so the on-screen button and the phone's back gesture
            // can never disagree: from any drawer item, return to the
            // module's home item; from home, leave the module.
            Box(
                Modifier.align(Alignment.BottomStart).padding(start = 12.dp, bottom = 16.dp)
                    .size(44.dp).clip(RoundedCornerShape(22.dp))
                    .background(Color.Black.copy(alpha = 0.42f)),
            ) {
                IconButton(onClick = {
                    if (selectedKey != homeKey) onSelect(homeKey) else onBackToHome()
                }) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "পিছনে", tint = Color.White)
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(36.dp).clip(RoundedCornerShape(18.dp)).background(Color.Black.copy(alpha = 0.32f))) {
                    IconButton(onClick = { scope.launch { drawerState.open() } }) {
                        Icon(Icons.Filled.Menu, contentDescription = "Options", tint = Color.White)
                    }
                }
                Spacer(Modifier.weight(1f))
                Box(Modifier.size(36.dp).clip(RoundedCornerShape(18.dp)).background(Color.Black.copy(alpha = 0.32f))) {
                    IconButton(onClick = { overflowOpen = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "আরও", tint = Color.White)
                    }
                    // v113-325 tried to fix this with a TopEnd-aligned
                    // wrapper Box; the person reports the menu is STILL
                    // opening on the left, so that approach did not work —
                    // wrapping only changes the wrapper's own layout, not
                    // where the popup window gets positioned.
                    //
                    // v113-335 — using the real mechanism instead:
                    // DropdownMenu's own `offset`. Compose anchors the popup
                    // to this 36dp box and, when the menu is wider than the
                    // anchor, extends it in whichever direction has room —
                    // which threw it left, away from the ⋮ that opened it.
                    // A negative x offset pulls it back so its right edge
                    // sits under the button, which is what "option gulao
                    // right side e Aste hbe" asks for. Sized against the
                    // menu's own real content width (~220dp for the longest
                    // label, "Approval History") minus the 36dp anchor.
                    // v113-349 — the person's report: the ⋮ menu STILL opens on
                    // the left. The v113-335 "fix" was itself the cause: a
                    // negative x offset of -184dp explicitly pushes the popup
                    // 184dp LEFT of its anchor. Compose's own popup positioner
                    // already right-aligns a menu against the window edge when
                    // the anchor sits at the screen's right side — no offset
                    // needed at all. Removed.
                    // v113-361 — no wrapper DropdownMenu any more. "🏠 Home" is
                    // handed to UniversalActionMenuBody as extraLeadingItems so
                    // there is exactly ONE popup, anchored to this ⋮ box.
                    val homeLeadingItem: @Composable ColumnScope.() -> Unit = {
                        DropdownMenuItem(
                            text = { Text("🏠 Home") },
                            onClick = { overflowOpen = false; onBackToHome() },
                        )
                        // v113-363 — the current screen's own extra item(s), if any,
                        // sit right under Home and above the universal actions.
                        recordActionMenu.extraMenuItems?.invoke(this)
                        Divider()
                    }
                    // v113-361 — the leftover empty `Box {}` that used to hold the
                    // wrapper menu is gone too: a zero-size Box sits at the 36dp
                    // button's TopStart, so the popup was anchoring to a point
                    // slightly left of the ⋮ instead of to the ⋮ itself.
                    run {
                        // v113-276 — the person's own direct instruction:
                        // when a specific record is actually in view
                        // (registered via RegisterRecordActionMenu — a
                        // Dealer/Retailer/Employee/Product Detail screen,
                        // an Invoice/Memo document, etc.), the module ⋮
                        // shows that SAME record's full real
                        // UniversalActionMenuBody — the exact same
                        // component, same dialogs, same real Export/
                        // Share/Print/Approval-History/Activity-Log/
                        // Attachments logic the record's own inline menu
                        // already has — not a second, thinner menu. Takes
                        // priority over the plain screen-summary Export/
                        // Share/Print below when both could apply, since a
                        // specific record is the more precise thing to
                        // act on.
                        if (recordActionMenu.moduleReference != null) {
                            UniversalActionMenuBody(
                                extraLeadingItems = homeLeadingItem,
                                moduleReference = recordActionMenu.moduleReference!!,
                                entityId = recordActionMenu.entityId,
                                entityLabel = recordActionMenu.entityLabel,
                                shareText = recordActionMenu.shareText,
                                customDocumentImage = recordActionMenu.customDocumentImage,
                                csvHeader = recordActionMenu.csvHeader,
                                csvRow = recordActionMenu.csvRow,
                                expanded = overflowOpen,
                                onDismissMenu = { overflowOpen = false },
                            )
                        } else {
                            // v113-311 — the person's own repeated point,
                            // now answered directly by them: "পুরো screen-এর
                            // জন্য universal menu — যেমন Ledger screen-এ
                            // থাকলে পুরো Ledger-এর Export CSV/PDF/JPG,
                            // Share, Print, Activity Log, Attachments —
                            // অর্থাৎ record-ভিত্তিক না, screen-ভিত্তিক।"
                            //
                            // Previously this branch only did anything when
                            // a screen had explicitly called
                            // RegisterModuleMenuContent — and only 5 screens
                            // in the whole app ever did (the module
                            // Dashboards). Every other drawer item — Ledger,
                            // Stock, Approve, Finance, Recycle, Notice and
                            // the rest — left the ⋮ showing nothing but
                            // "Home", which is exactly the complaint.
                            //
                            // Now the SCREEN ITSELF is treated as the
                            // entity: the drawer item's own key is the
                            // entityId and its own label the entityLabel, so
                            // every screen in every module gets the same
                            // real UniversalActionMenuBody — the identical
                            // component, dialogs and Export/Share/Print/
                            // Approval-History/Activity-Log/Attachments
                            // logic a record's own inline ⋮ has — with no
                            // per-screen wiring at all. Screens that DO
                            // register summary rows simply get richer
                            // Share/CSV content inside that same menu
                            // rather than a different, thinner one.
                            val screenLabel = items.firstOrNull { it.key == selectedKey }?.label ?: moduleName
                            val screenTitle = menuContent.title ?: "$moduleName — $screenLabel"
                            val screenRows = menuContent.rows
                            UniversalActionMenuBody(
                                extraLeadingItems = homeLeadingItem,
                                moduleReference = moduleName,
                                entityId = selectedKey,
                                entityLabel = screenTitle,
                                shareText = if (screenRows.isEmpty()) screenTitle
                                    else moduleSummaryText(screenTitle, screenRows),
                                csvHeader = if (screenRows.isEmpty()) "Screen" else "Label,Value",
                                csvRow = if (screenRows.isEmpty()) toCsvRow(screenTitle)
                                    else screenRows.joinToString("\n") { toCsvRow(it.first, it.second) },
                                canEdit = false,
                                canArchive = false,
                                expanded = overflowOpen,
                                onDismissMenu = { overflowOpen = false },
                            )
                        }
                    }
                }
            }
            }
        }
    }
    }
}

/**
 * Used where a mother module lists its own records for the person to drill into
 * (e.g. DMS → Ledger → pick a dealer). Kept here so both DMS and RMS draw the same
 * row rather than each inventing one.
 */
@Composable
fun ModuleDrillRow(title: String, subtitle: String, onClick: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                if (subtitle.isNotBlank()) {
                    Text(subtitle, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextSecondary)
        }
    }
}

/**
 * Honest placeholder. Used only where the draft asks for something this codebase does
 * not have yet (e.g. Retailer Stock, Gift entry). It states plainly what is missing
 * instead of showing a fake screen that looks finished.
 */
@Composable
fun NotBuiltYet(what: String, detail: String = "") {
    Column(Modifier.fillMaxWidth().padding(24.dp)) {
        Text("$what — এখনো বানানো হয়নি", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        Text(
            detail.ifBlank { "এই অংশটা draft-এ আছে কিন্তু কোডে এখনো নেই। পরের ব্যাচে বানানো হবে।" },
            style = MaterialTheme.typography.bodySmall, color = TextSecondary,
        )
    }
}
