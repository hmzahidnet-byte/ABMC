package com.abm.erp.ui.hr

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.AdvanceEngine
import com.abm.erp.data.CascadeEngine
import com.abm.erp.data.EmployeeAdvance
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.DarazOrangeDark
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * v113-384 — HRM Finance drawer: অগ্রিম ও ধার (ধাপ ৫)।
 *
 * ডিজাইন r3-এর "৩ · Finance"। তিনটে অংশ: মোট হিসাব · মুলতুবি আবেদন
 * (👁 ✔ ✕) · চলমান কিস্তির অগ্রগতি।
 *
 * অনুমোদন কেবল Wing 1 — `AdvanceEngine` নিজেই যাচাই করে, তাই বোতাম লুকানোটা
 * শুধু সৌজন্য; অন্য পথে ডাকলেও নিয়ম ভাঙা যায় না।
 */
@Composable
fun HrFinanceTab() {
    val advances by MockRepository.employeeAdvances.collectAsState()
    val employees by MockRepository.employeeProfiles.collectAsState()
    val live = remember(employees) { employees.filter { !it.isDeleted } }
    val canDecide = CascadeEngine.wingOf(MockRepository.currentUser.role) == CascadeEngine.Wing.OFFICE

    val totals = remember(advances) { AdvanceEngine.totals(advances) }
    val pending = remember(advances) { advances.filter { it.status == "PENDING" } }
    val running = remember(advances) { advances.filter { it.status == "APPROVED" && !it.isSettled } }
    val closed = remember(advances) { advances.filter { it.status == "CLOSED" } }

    var msg by remember { mutableStateOf<String?>(null) }
    var ok by remember { mutableStateOf(false) }
    var confirming by remember { mutableStateOf<Pair<EmployeeAdvance, Boolean>?>(null) }

    Column(
        Modifier.fillMaxSize().background(com.abm.erp.theme.DashBg)
            .verticalScroll(rememberScrollState()).imePadding().padding(12.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Stat("মোট অগ্রিম", totals.given, WarningAmber, Color(0xFFFFF7E6), Modifier.weight(1f))
            Stat("আদায়", totals.recovered, SuccessGreen, Color(0xFFE8F7F0), Modifier.weight(1f))
            Stat("বকেয়া", totals.outstanding, DangerRed, Color(0xFFFDECEA), Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))

        NewRequestCard(live) { err ->
            ok = err.isBlank()
            msg = if (err.isBlank()) "✔ আবেদন জমা হয়েছে — Wing 1 অনুমোদন করবে" else "✖ $err"
        }
        Spacer(Modifier.height(10.dp))

        // ── মুলতুবি আবেদন ──
        Card {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("অগ্রিমের আবেদন", Modifier.weight(1f), fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                if (pending.isNotEmpty()) {
                    Box(
                        Modifier.clip(RoundedCornerShape(8.dp)).background(DangerRed).padding(horizontal = 7.dp, vertical = 1.dp),
                    ) { Text("${pending.size} pending", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                }
            }
            if (pending.isEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text("কোনো আবেদন মুলতুবি নেই।", fontSize = 10.5.sp, color = TextSecondary)
            }
            pending.forEach { a ->
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(32.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFFFFF7E6)),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.Payments, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(16.dp)) }
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.employeeName, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
                        Text("৳${num(a.amount)} · ${a.installments} কিস্তি", fontSize = 11.sp, color = TextPrimary)
                        Text("কারণ: ${a.reason}", fontSize = 9.5.sp, color = TextSecondary, maxLines = 2)
                    }
                    if (canDecide) {
                        ActionDot(Icons.Filled.Check, SuccessGreen, Color(0xFFE8F7F0)) { confirming = a to true }
                        Spacer(Modifier.width(3.dp))
                        ActionDot(Icons.Filled.Close, DangerRed, Color(0xFFFDECEA)) { confirming = a to false }
                    }
                }
            }
            if (!canDecide && pending.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text("অনুমোদন কেবল Wing 1 (office) করতে পারে।", fontSize = 9.5.sp, color = TextSecondary)
            }
        }

        Spacer(Modifier.height(10.dp))

        // ── চলমান কিস্তি ──
        Card {
            Text("চলমান কিস্তি", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            if (running.isEmpty() && closed.isEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text("কোনো চলমান অগ্রিম নেই।", fontSize = 10.5.sp, color = TextSecondary)
            }
            (running + closed.take(3)).forEach { a ->
                val done = ((a.repaid / a.amount) * a.installments).toInt().coerceIn(0, a.installments)
                Column(Modifier.fillMaxWidth().padding(top = 9.dp)) {
                    Row(Modifier.fillMaxWidth()) {
                        Text(a.employeeName, Modifier.weight(1f), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(
                            if (a.isSettled) "✔ শোধ" else "বাকি ৳${num(a.outstanding)}",
                            fontSize = 10.5.sp, fontWeight = FontWeight.Bold,
                            color = if (a.isSettled) SuccessGreen else WarningAmber,
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        repeat(a.installments) { i ->
                            Box(
                                Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp))
                                    .background(if (i < done) SuccessGreen else Color(0xFFE5E9EF)),
                            )
                        }
                    }
                    Text(
                        "কিস্তি $done/${a.installments} · প্রতি মাসে ৳${num(a.perInstallment)} — বেতন থেকে আপনাআপনি কাটে",
                        fontSize = 8.5.sp, color = TextSecondary, lineHeight = 13.sp,
                    )
                }
            }
        }

        msg?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, fontSize = 11.sp, color = if (ok) SuccessGreen else DangerRed, lineHeight = 16.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "কিস্তি বেতন থেকে আপনাআপনি কাটে — এটাই একমাত্র জায়গা যেখানে অ্যাপ নিজে কাটে, " +
                "কারণ এটা শাস্তি নয়, আগে থেকেই সম্মত ঋণ পরিশোধ।",
            fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
        )
        Spacer(Modifier.height(24.dp))
    }

    val c = confirming
    if (c != null) {
        val (adv, approve) = c
        AlertDialog(
            onDismissRequest = { confirming = null },
            title = { Text(if (approve) "অগ্রিম অনুমোদন?" else "আবেদন বাতিল?") },
            text = {
                Text(
                    "${adv.employeeName} — ৳${num(adv.amount)}, ${adv.installments} কিস্তি।\n" +
                        if (approve) "অনুমোদন করলে টাকা cash book থেকে বেরোবে, আর কিস্তি বেতন থেকে কাটা শুরু হবে।"
                        else "বাতিল করলে কর্মী আবার আবেদন করতে পারবে।",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirming = null
                    AdvanceEngine.decide(adv.id, approve) { err ->
                        ok = err.isBlank()
                        msg = if (err.isBlank()) (if (approve) "✔ অনুমোদিত" else "✔ বাতিল করা হয়েছে") else "✖ $err"
                    }
                }) { Text(if (approve) "হ্যাঁ, অনুমোদন" else "হ্যাঁ, বাতিল", color = if (approve) SuccessGreen else DangerRed) }
            },
            dismissButton = { TextButton(onClick = { confirming = null }) { Text("না, থাক") } },
        )
    }
}

/* ── নতুন আবেদন ────────────────────────────────────────────────────────── */

@Composable
private fun NewRequestCard(
    employees: List<com.abm.erp.data.EmployeeProfile>,
    onDone: (String) -> Unit,
) {
    var forId by remember { mutableStateOf<String?>(null) }
    var amount by remember { mutableStateOf("") }
    var inst by remember { mutableStateOf("3") }
    var reason by remember { mutableStateOf("") }
    val selected = employees.firstOrNull { it.id == forId }

    Card {
        Text("নতুন অগ্রিমের আবেদন", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            employees.take(12).forEach { e ->
                val on = e.id == forId
                Box(
                    Modifier.clip(RoundedCornerShape(14.dp))
                        .background(if (on) DarazOrange else Color.White)
                        .border(1.dp, if (on) DarazOrange else HairlineBorder, RoundedCornerShape(14.dp))
                        .clickable { forId = e.id }
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                ) {
                    Text(
                        e.fullName.take(12), fontSize = 10.5.sp, fontWeight = FontWeight.Bold,
                        color = if (on) Color.White else TextSecondary, maxLines = 1,
                    )
                }
            }
        }
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Num(amount, "পরিমাণ ৳", Modifier.weight(1.4f)) { amount = it }
            Num(inst, "কিস্তি", Modifier.weight(1f)) { inst = it }
        }
        Spacer(Modifier.height(7.dp))
        OutlinedTextField(
            value = reason, onValueChange = { reason = it },
            label = { Text("কারণ", fontSize = 10.sp) }, singleLine = true,
            textStyle = MaterialTheme.typography.bodySmall,
            modifier = Modifier.fillMaxWidth().height(56.dp),
        )
        Spacer(Modifier.height(8.dp))
        val ready = selected != null && (amount.toDoubleOrNull() ?: 0.0) > 0 && reason.isNotBlank()
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                .background(if (ready) DarazOrange else Color(0xFFCBD5E1))
                .clickable(enabled = ready) {
                    AdvanceEngine.request(
                        employeeId = selected!!.id,
                        amount = amount.toDoubleOrNull() ?: 0.0,
                        reason = reason,
                        installments = inst.toIntOrNull() ?: 1,
                        onResult = { err ->
                            if (err.isBlank()) { amount = ""; reason = "" }
                            onDone(err)
                        },
                    )
                }
                .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center,
        ) { Text("আবেদন জমা দিন", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White) }
        if (selected != null) {
            Spacer(Modifier.height(5.dp))
            val perMonth = (amount.toDoubleOrNull() ?: 0.0) / (inst.toIntOrNull()?.coerceAtLeast(1) ?: 1)
            Text(
                "প্রতি মাসে কাটবে ≈ ৳${num(perMonth)} · বেসিক ৳${num(selected.basePayMonthly)}",
                fontSize = 9.5.sp, color = DarazOrangeDark,
            )
        }
    }
}

/* ── ছোট সহায়ক ─────────────────────────────────────────────────────────── */

@Composable
private fun Num(value: String, label: String, modifier: Modifier = Modifier, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { t -> onChange(t.filter { it.isDigit() || it == '.' }) },
        label = { Text(label, fontSize = 10.sp) },
        singleLine = true,
        textStyle = MaterialTheme.typography.bodySmall,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier.height(56.dp),
    )
}

@Composable
private fun ActionDot(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    ink: Color,
    bg: Color,
    onClick: () -> Unit,
) {
    Box(
        Modifier.size(30.dp).clip(RoundedCornerShape(15.dp)).background(bg).clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) { Icon(icon, contentDescription = null, tint = ink, modifier = Modifier.size(15.dp)) }
}

@Composable
private fun Stat(label: String, value: Double, ink: Color, bg: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(11.dp)).background(bg).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(label, fontSize = 8.5.sp, color = TextSecondary, maxLines = 1)
        Text("৳${num(value)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ink, maxLines = 1)
    }
}

@Composable
private fun Card(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color.White)
            .border(1.dp, HairlineBorder, RoundedCornerShape(13.dp)).padding(11.dp),
        content = content,
    )
}

private fun num(v: Double): String =
    if (kotlin.math.abs(v % 1.0) < 0.001) "%,.0f".format(v) else "%,.2f".format(v)
