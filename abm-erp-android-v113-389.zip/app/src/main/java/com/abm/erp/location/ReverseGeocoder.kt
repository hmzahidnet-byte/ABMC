package com.abm.erp.location

import android.content.Context
import android.location.Geocoder
import java.util.Locale

/**
 * v113-327 — the person's own bug report: "jkn new Deler ba retailer add
 * hoy tkn to address er box ase ar niche location. akn Jodi oi location e
 * giye tap kore taile to upore address je box gula ase oigula auto real
 * location name diye fill hoar kotha."
 *
 * They're right and it was a genuine gap: `tagLocationNow()` captured
 * latitude and longitude and stopped there. The address fields sitting
 * directly above it were never touched, so a person who had just tapped
 * "capture location" still had to type out where they were standing.
 *
 * This turns a fix into real place names using Android's own `Geocoder`.
 * Deliberately additive and non-destructive:
 *
 *  - Reverse geocoding needs network and can genuinely fail or return
 *    nothing. Every failure returns null and the caller simply leaves the
 *    fields as they were — a missing auto-fill is a small annoyance, a
 *    wrong or half-written address silently overwriting a typed one is
 *    worse.
 *  - Callers only fill fields that are still BLANK, so a person who
 *    already typed a precise address (a shop name, a floor, a landmark
 *    the map doesn't know) never loses it to a coarser machine guess.
 */
object ReverseGeocoder {

    data class Resolved(
        /** Full readable line — house/road/area/city, as the provider gives it. */
        val addressLine: String,
        /** Coarser components, for the form's own separate district/upazila boxes. */
        val district: String?,
        val subArea: String?,
    )

    /**
     * Blocking network call — must run off the main thread. Returns null
     * when there is no network, no geocoder on the device, or simply no
     * match for that point.
     */
    fun resolve(context: Context, lat: Double, lng: Double): Resolved? {
        if (!Geocoder.isPresent()) return null
        return try {
            val geocoder = Geocoder(context, Locale.getDefault())
            @Suppress("DEPRECATION")
            val results = geocoder.getFromLocation(lat, lng, 1)
            val a = results?.firstOrNull() ?: return null

            // getAddressLine(0) is the provider's own best full-line
            // rendering. Falling back to assembling the parts by hand only
            // when it's absent keeps the common case in the provider's
            // (better) formatting rather than a home-made join.
            val line = a.getAddressLine(0)
                ?: listOfNotNull(a.featureName, a.thoroughfare, a.subLocality, a.locality)
                    .distinct().joinToString(", ").ifBlank { null }
                ?: return null

            Resolved(
                addressLine = line,
                // adminArea is the province/division; subAdminArea is
                // typically the district in BD address data — using the
                // narrower one first and falling back.
                district = (a.subAdminArea ?: a.adminArea)?.takeIf { it.isNotBlank() },
                subArea = (a.locality ?: a.subLocality)?.takeIf { it.isNotBlank() },
            )
        } catch (e: Exception) {
            // No network, service unavailable, malformed response — all the
            // same outcome from the form's point of view: no auto-fill.
            null
        }
    }
}
