package com.abm.erp.core

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * v113-328 — the person's chosen answer ("ক + গ") to the problem they
 * raised: where no Sales Officer records retailer sales, a dealer's
 * stock never depletes in the system, so alerts misfire and the next
 * order is sized against a number that stopped being true weeks ago.
 *
 * This is one sheet serving both chosen options, because they are the
 * same act at different moments:
 *  - **ক** — opened on demand, whenever a dealer or a visiting employee
 *    wants to correct the figures.
 *  - **গ** — opened at reorder, so the correction happens at the natural
 *    moment with no extra trip and no extra habit to build.
 *
 * ## Why it asks for a COUNT, not a "sold" figure
 * A person standing at a shelf can count what is in front of them.
 * Asking them to recall how much left over three weeks is asking for a
 * guess, and a guess entered into a stock ledger is indistinguishable
 * from a fact afterwards. Each row is pre-filled with what the system
 * currently believes, so an unchanged product needs no work at all — the
 * person only touches what is actually different.
 *
 * The difference is shown live per row, and the whole thing is honest
 * about being a count: nothing here claims to know who bought what.
 */
@Composable
fun DealerStockDeclarationSheet(
    dealerId: String,
    dealerName: String,
    onDismiss: () -> Unit,
    reasonNote: String? = null,
) {
    val lines by MockRepository.dealerStockLinesFor(dealerId).collectAsState(initial = emptyList())
    // Keyed by product id; starts as the system's own belief so an
    // untouched row is explicitly "no change", never an accidental zero.
    val counted = remember(lines) {
        mutableStateMapOf<String, String>().apply {
            lines.forEach { put(it.productId, it.qty.toString()) }
        }
    }
    var result by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
            Column(Modifier.fillMaxWidth().heightIn(max = 560.dp).padding(16.dp)) {
                Text("Stock গণনা — $dealerName", fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(
                    "দোকানে এখন যত পিস আছে সেটাই লিখুন। কত বিক্রি হয়েছে সেটা হিসাব করতে হবে না — সিস্টেম নিজেই বের করবে।",
                    style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                )
                Spacer(Modifier.height(6.dp))
                // v113-346 — said plainly, because the person must not think
                // the stock has already moved when they close this sheet.
                Text(
                    "⚠ এটি সরাসরি stock বদলাবে না — approval-এ যাবে, approve হলে তবেই হিসাব বদলাবে।",
                    style = MaterialTheme.typography.labelSmall, color = WarningAmber,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(12.dp))

                if (lines.isEmpty()) {
                    Text(
                        "এই dealer-এর নামে এখনো কোনো stock নেই — invoice approve হলে এখানে পণ্য দেখা যাবে।",
                        style = MaterialTheme.typography.bodySmall, color = TextSecondary,
                    )
                } else {
                    LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(lines, key = { it.productId }) { line ->
                            val typed = counted[line.productId].orEmpty()
                            val countedQty = typed.toIntOrNull()
                            val diff = countedQty?.let { it - line.qty }
                            Row(
                                Modifier.fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(1.dp, HairlineBorder, RoundedCornerShape(10.dp))
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(line.productName, fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 13.sp, maxLines = 1)
                                    Text("সিস্টেমে আছে: ${line.qty} পিস", fontSize = 11.sp, color = TextSecondary)
                                    // Shown only when it actually differs, so
                                    // the row stays quiet until it matters.
                                    if (diff != null && diff != 0) {
                                        Text(
                                            if (diff < 0) "→ ${-diff} পিস কমেছে (বিক্রি ধরা হবে)" else "→ $diff পিস বেড়েছে",
                                            fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                            color = if (diff < 0) WarningAmber else SuccessGreen,
                                        )
                                    }
                                }
                                Spacer(Modifier.width(10.dp))
                                OutlinedTextField(
                                    value = typed,
                                    onValueChange = { counted[line.productId] = it.filter(Char::isDigit).take(6) },
                                    label = { Text("গুনে দেখুন (≤ বর্তমান)", fontSize = 10.sp) },
                                    singleLine = true,
                                    modifier = Modifier.width(110.dp),
                                )
                            }
                        }
                    }
                }

                result?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        it, style = MaterialTheme.typography.labelSmall,
                        color = if (it.startsWith("✔")) SuccessGreen else TextSecondary,
                    )
                }

                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("বাতিল") }
                    Button(
                        onClick = {
                            saving = true; result = null
                            MockRepository.requestDealerStockAdjustment(
                                dealerId = dealerId,
                                dealerName = dealerName,
                                countedByProductId = counted.mapNotNull { (id, text) ->
                                    text.toIntOrNull()?.let { id to it }
                                }.toMap(),
                                note = reasonNote,
                            ) { msg -> result = msg; saving = false }
                        },
                        enabled = !saving && lines.isNotEmpty(),
                        modifier = Modifier.weight(1f),
                    ) { Text(if (saving) "পাঠানো হচ্ছে…" else "Approval-এ পাঠান") }
                }
            }
        }
    }
}
