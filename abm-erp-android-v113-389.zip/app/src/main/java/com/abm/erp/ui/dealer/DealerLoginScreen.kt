package com.abm.erp.ui.dealer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.Dealer
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.*
import com.abm.erp.util.LocationAnomalyChecker
import com.abm.erp.util.tryGetLoginLocation
import kotlinx.coroutines.launch

/**
 * Dealer's own entry point — pick your business, then confirm with your PIN
 * (matching staff login's structure). Same 50km geo-block as SR/TSM/ASM/RSM,
 * checked against the dealer's own zone (division-level).
 */
@Composable
fun DealerLoginScreen(onDealerChosen: (dealerId: String) -> Unit, onBackToStaffLogin: () -> Unit) {
    val dealers by MockRepository.dealers.collectAsState()
    var selected by remember { mutableStateOf<Dealer?>(null) }
    var pin by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") } // v113-359
    var error by remember { mutableStateOf<String?>(null) }
    var checking by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Box(
        modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(SkyTop, Sky, SkyHorizon, GoldBright))),
        contentAlignment = Alignment.Center,
    ) {
        // v113-359 — audit of the person's "dealer-login পথে ভুল নম্বরে back আছে
        // কিনা" concern. HONEST FINDING: this path never asks for a number at
        // all (it is a picker), so the v113-349 wrong-number trap cannot happen
        // here — but the audit did find a real adjacent bug: the picker listed
        // every dealer in a NON-scrolling centred Column, so past a handful of
        // dealers the rest were simply unreachable, and there was no search.
        // Both fixed: the column scrolls, lifts for the keyboard, and filters.
        Column(
            Modifier.fillMaxSize().padding(32.dp).imePadding().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text("🏪", fontSize = 40.sp)
            Spacer(Modifier.height(12.dp))
            Text("Dealer Portal", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 20.sp)

            if (selected == null) {
                Text("Choose your business to continue", color = Color(0xFFE4EEF6), fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = search, onValueChange = { search = it },
                    label = { Text("নাম / কোড / এলাকা দিয়ে খুঁজুন") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Color.White, unfocusedBorderColor = Color(0xFFE4EEF6)),
                )
                Spacer(Modifier.height(10.dp))
                val shown = dealers.filter { d ->
                    search.isBlank() || d.name.contains(search, true) ||
                        d.zone.contains(search, true) || d.dealerCode.contains(search, true)
                }
                if (shown.isEmpty()) {
                    Text("কোনো dealer মিলল না।", color = Color(0xFFE4EEF6), fontSize = 12.sp)
                }
                shown.forEach { dealer ->
                    Surface(
                        onClick = { selected = dealer; pin = ""; error = null },
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0x22FFFFFF),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(dealer.name, color = Color(0xFFFCFAF3), fontWeight = FontWeight.SemiBold)
                            Text(dealer.zone, color = Color(0xFFE4EEF6), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            } else {
                val dealer = selected!!
                Spacer(Modifier.height(6.dp))
                Text(dealer.name, color = Color(0xFFE4EEF6), fontSize = 13.sp)
                Text(dealer.zone, color = Color(0xFFE4EEF6), style = MaterialTheme.typography.labelSmall)
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = pin, onValueChange = { if (it.length <= 5) pin = it.filter(Char::isDigit) },
                    label = { Text("PIN") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Color.White, unfocusedBorderColor = Color(0xFFE4EEF6)),
                )
                error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = Color(0xFFFFCDD2), fontSize = 11.sp) }
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        if (!MockRepository.verifyDealerPin(dealer, pin)) { error = "Incorrect PIN, or no PIN has been set for this dealer yet — contact your administrator."; return@Button }
                        // v113-201 — Chairman's new Suspend/Terminate lifecycle control
                        // (setDealerLifecycleStatus in MockRepository.kt) blocks the
                        // dealer's own login here, confirmed directly with the person:
                        // Suspend blocks login, Terminate blocks login too (both
                        // reversible via Reactivate). Pause deliberately does NOT
                        // block login — only new invoices — so it's not checked here.
                        if (dealer.status == "SUSPENDED" || dealer.status == "TERMINATED") {
                            error = "এই dealer account ${dealer.status.lowercase()} করা হয়েছে — administrator-এর সাথে যোগাযোগ করুন।"
                            return@Button
                        }
                        checking = true
                        error = null
                        scope.launch {
                            val loc = tryGetLoginLocation(context)
                            val tooFar = loc != null && LocationAnomalyChecker.isTooFarToLogin("DEALER", dealer.zone, null, loc.first, loc.second)
                            checking = false
                            if (tooFar) {
                                error = "Too far from your registered area — login blocked."
                            } else {
                                onDealerChosen(dealer.id)
                            }
                        }
                    },
                    enabled = !checking,
                    modifier = Modifier.fillMaxWidth(0.7f),
                ) { Text(if (checking) "Checking…" else "Continue") }
                TextButton(onClick = { selected = null; pin = ""; error = null }) {
                    Text("← Choose a different business", color = Color(0xFFE4EEF6), fontSize = 11.sp)
                }
            }

            Spacer(Modifier.height(20.dp))
            TextButton(onClick = onBackToStaffLogin) {
                Text("← Back to staff login", color = Color(0xFFE4EEF6), fontSize = 12.sp)
            }
        }
    }
}
