package com.abm.erp.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.abm.erp.MainActivity
import com.abm.erp.data.NotificationCategory

/**
 * v113-322 — the person's own instruction: "প্রত্যেকটা সফটওয়্যারের
 * প্রত্যেকটা যে নোটিফিকেশন... ফেসবুক, হোয়াটসঅ্যাপে উপর থেকে
 * নোটিফিকেশন মেসেজ আসে ঐরকম কিন্তু নোটিফিকেশন মেসেজটা দিবে। প্রত্যেকটা
 * মডিউলের ক্ষেত্রেই একদম ফান্ডামেন্টাল ভাবেই করবে... নোটিফিকেশনে ক্লিক
 * করলে ঐ ইউআই টা চলে যাবে।"
 *
 * ## What was actually missing
 * The app already raised real notification events from every module —
 * `MockRepository.createNotification(...)` is called for approvals, low
 * stock, collections, attendance, complaints, deliveries and more, 20
 * real categories in all. But every one of them only ever landed in an
 * in-app list. Nothing appeared on the phone. So the person still had to
 * open the app and go looking, which is exactly what they described
 * wanting to stop doing.
 *
 * `AbmFirebaseMessagingService` did exist, but it only fires for pushes
 * sent from a backend server — and these events are detected by the app
 * itself, on the device, with no server involved. That is why FCM being
 * present didn't solve this.
 *
 * ## What this does
 * Posts a real system notification for every event the app raises, and
 * carries a deep-link route so tapping it opens the screen that event
 * belongs to rather than just the dashboard.
 *
 * Channels are split by importance rather than lumped together, because
 * a low-stock warning and a routine sales-order update should not
 * interrupt equally — Android lets the person then tune each one
 * separately in system settings, which a single channel would deny them.
 */
object AppNotifier {

    private const val CHANNEL_URGENT = "abm_urgent"
    private const val CHANNEL_APPROVAL = "abm_approvals"
    private const val CHANNEL_GENERAL = "abm_general_notifications"

    /** Extra key read by MainActivity to deep-link into the right screen. */
    const val EXTRA_ROUTE = "abm_notification_route"

    /**
     * Where each category should land. These are real routes registered in
     * NavGraph — verified against it rather than invented, so a tap never
     * dead-ends. Categories with no single sensible destination fall
     * through to null and simply open the app.
     */
    private fun routeFor(category: NotificationCategory): String? = when (category) {
        NotificationCategory.APPROVAL,
        NotificationCategory.DEALER_REGISTRATION,
        NotificationCategory.RETAILER_REGISTRATION,
        -> "dms?key=approve"

        NotificationCategory.INVOICE, NotificationCategory.SALES_ORDER -> "dms?key=invoice"
        NotificationCategory.COLLECTION, NotificationCategory.PAYMENT -> "dms?key=finance"
        NotificationCategory.LOW_STOCK, NotificationCategory.STOCK_TRANSFER -> "inventory"
        // v113-338 — the courier destination no longer exists; a DELIVERY
        // notification would have deep-linked to a dead route. Null means
        // "just open the app", which is honest rather than a tap that
        // silently does nothing.
        NotificationCategory.DELIVERY -> null
        NotificationCategory.PRODUCTION, NotificationCategory.QUALITY_CHECK -> "production"
        NotificationCategory.ATTENDANCE, NotificationCategory.LEAVE -> "hr_module"
        NotificationCategory.COMPLAINT, NotificationCategory.HELPDESK -> "complaint"
        NotificationCategory.PURCHASE_ORDER, NotificationCategory.GOODS_RECEIPT -> "purchase"
        NotificationCategory.TASK, NotificationCategory.ALERT -> null
    }

    private fun channelFor(category: NotificationCategory): String = when (category) {
        NotificationCategory.LOW_STOCK, NotificationCategory.ALERT, NotificationCategory.COMPLAINT -> CHANNEL_URGENT
        NotificationCategory.APPROVAL, NotificationCategory.DEALER_REGISTRATION,
        NotificationCategory.RETAILER_REGISTRATION, NotificationCategory.PURCHASE_ORDER,
        -> CHANNEL_APPROVAL
        else -> CHANNEL_GENERAL
    }

    private fun ensureChannels(manager: NotificationManager) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        listOf(
            Triple(CHANNEL_URGENT, "জরুরি সতর্কতা", NotificationManager.IMPORTANCE_HIGH),
            Triple(CHANNEL_APPROVAL, "অনুমোদন", NotificationManager.IMPORTANCE_DEFAULT),
            Triple(CHANNEL_GENERAL, "সাধারণ", NotificationManager.IMPORTANCE_DEFAULT),
        ).forEach { (id, name, importance) ->
            if (manager.getNotificationChannel(id) == null) {
                manager.createNotificationChannel(NotificationChannel(id, name, importance))
            }
        }
    }

    /**
     * Posts one system notification. Safe to call from anywhere,
     * including a background coroutine — every failure path is swallowed,
     * because a notification that can't be shown must never take down the
     * business action that raised it.
     */
    fun post(context: Context, category: NotificationCategory, title: String, body: String) {
        try {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            ensureChannels(manager)

            val route = routeFor(category)
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                if (route != null) putExtra(EXTRA_ROUTE, route)
            }
            // A distinct requestCode per route keeps separate destinations
            // from collapsing into one another's PendingIntent — without
            // it, FLAG_UPDATE_CURRENT would make every notification open
            // whichever route was registered last.
            val pendingIntent = PendingIntent.getActivity(
                context, (route ?: "home").hashCode(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )

            val notification = NotificationCompat.Builder(context, channelFor(category))
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(
                    if (channelFor(category) == CHANNEL_URGENT) NotificationCompat.PRIORITY_HIGH
                    else NotificationCompat.PRIORITY_DEFAULT,
                )
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()

            manager.notify(System.currentTimeMillis().toInt(), notification)
        } catch (e: SecurityException) {
            // POST_NOTIFICATIONS declined — expected on Android 13+ when the
            // person said no. Never a crash.
        } catch (e: Exception) {
            // Same principle: the raising action already succeeded.
        }
    }
}
