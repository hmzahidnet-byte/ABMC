package com.abm.erp.core

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.abm.erp.data.MockRepository
import com.abm.erp.data.submitCorrectionRequest
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import java.io.File
import kotlinx.coroutines.launch

/**
 * Global Rule — Universal Action Menu. Every record/card across every
 * module attaches this SAME kebab menu instead of each screen inventing
 * its own bespoke set of buttons. View Details/Edit are the caller's own
 * inline UI (this menu doesn't duplicate that); everything else —
 * Approval History, Activity Log, Attachments, Share, Archive/Restore,
 * PDF/Excel export, Duplicate — is handled generically here, reading from
 * the SAME shared tables every module already posts into (audit_log,
 * ApprovalRequest.entityType/entityId, the Attachment table).
 */
@Composable
fun UniversalActionMenu(
    moduleReference: String,
    entityId: String,
    entityLabel: String,
    shareText: String,
    // v113-354 — when set, Share and Export PNG render THIS bespoke Style A
    // document (invoice/memo/ledger/profile) instead of the generic
    // title+body layout; suspend so the lambda can walk the QR approval gate.
    customDocumentImage: (suspend (android.content.Context) -> android.graphics.Bitmap)? = null,
    isDeleted: Boolean = false,
    onEdit: (() -> Unit)? = null,
    onDuplicate: ((onError: (String) -> Unit) -> Unit)? = null,
    onArchive: ((onError: (String) -> Unit) -> Unit)? = null,
    recordStatus: String? = null, // Task 4 — checked against ActionSafetyPolicy before Archive is allowed to fire
    archiveBlockedReasonOverride: String? = null, // Task B — for real conditions that aren't a "status" (e.g. outstanding due balance on master data); takes precedence over the status-based check so we never have to fabricate a fake status string just to trigger protection
    onRestore: (() -> Unit)? = null,
    onViewDetails: (() -> Unit)? = null,
    onSubmit: (() -> Unit)? = null, // Section 8 — "Submit" action, e.g. submitExpense/submit-for-approval; module wires its own real function
    onApprove: (() -> Unit)? = null, // Section 8 — "Approve" action, e.g. approveSalesInvoice/approveExpense/verifyCollection
    onReject: ((reason: String) -> Unit)? = null, // Section 8 — "Reject" action, requires a reason
    canApprove: Boolean = true,
    csvHeader: String = "",
    csvRow: String = "",
    historyLabel: String? = null, // "Stock History" | "Sales History" | "Dealer History" | "Retailer History" — module-specific quick view
    historyItems: List<String> = emptyList(),
    canEdit: Boolean = true, // Task 5 — permission-aware visibility: false shows Edit/Duplicate disabled with an explanation instead of hiding them outright
    canArchive: Boolean = true,
) {
    var expanded by remember { mutableStateOf(false) }
    // v113-296 — the person's own direct complaint: the module-level top
    // ⋮ only ever reflected a record's own real options on the 4
    // ModuleBrowseDetail screens (the only place
    // RegisterRecordActionMenu was ever called from) — every other real
    // screen's own UniversalActionMenu (Invoice/Purchase/Production/HR/
    // CRM/Courier and ~40 more real call sites, confirmed via a
    // project-wide grep before designing this fix) never fed the top ⋮
    // anything, so tapping it there showed nothing record-specific.
    // Writing directly into the same shared holder right here —
    // imperative, on tap, not the DisposableEffect-based registration
    // ModuleBrowseDetail's own persistent single-record view still uses
    // for its own different reason — means the top ⋮ now reflects
    // whichever record's own local ⋮ was most recently tapped,
    // everywhere in the app, from one real central fix instead of
    // individually wiring ~50 separate screens one at a time.
    val recordHolder = LocalRecordActionMenu.current
    Box {
        IconButton(onClick = {
            expanded = true
            recordHolder?.let {
                it.moduleReference = moduleReference
                it.entityId = entityId
                it.entityLabel = entityLabel
                it.shareText = shareText
                it.customDocumentImage = customDocumentImage
                it.csvHeader = csvHeader
                it.csvRow = csvRow
            }
        }) {
            Icon(Icons.Filled.MoreVert, contentDescription = "Actions")
        }
        UniversalActionMenuBody(
            moduleReference = moduleReference,
            entityId = entityId,
            entityLabel = entityLabel,
            shareText = shareText,
            customDocumentImage = customDocumentImage,
            isDeleted = isDeleted,
            onEdit = onEdit,
            onDuplicate = onDuplicate,
            onArchive = onArchive,
            recordStatus = recordStatus,
            archiveBlockedReasonOverride = archiveBlockedReasonOverride,
            onRestore = onRestore,
            onViewDetails = onViewDetails,
            onSubmit = onSubmit,
            onApprove = onApprove,
            onReject = onReject,
            canApprove = canApprove,
            csvHeader = csvHeader,
            csvRow = csvRow,
            historyLabel = historyLabel,
            historyItems = historyItems,
            canEdit = canEdit,
            canArchive = canArchive,
            expanded = expanded,
            onDismissMenu = { expanded = false },
        )
    }
}

// v113-276 — the person's own direct instruction: the module-level ⋮
// (ModuleDrawerScaffold's own top button, not this component's own local
// trigger) should show these SAME rich options when a specific record is
// in view — not a second, separate, thinner action menu. Extracted from
// what used to be UniversalActionMenu's own inline body so BOTH triggers
// call the exact same real implementation (same dialogs, same real
// export/share/print/approval-history/activity-log/attachments logic) —
// this function owns none of its own trigger UI (no IconButton, no
// DropdownMenu's own anchor Box) so it can be embedded inside either
// UniversalActionMenu's own local dropdown (unchanged for the ~17+
// existing callers — see the thin wrapper above) or
// ModuleDrawerScaffold's own top-level dropdown (new, see
// RegisterRecordActionMenu below), each correctly anchored to its own
// real trigger button rather than one DropdownMenu instance trying to
// serve two different screen positions.
@Composable
fun UniversalActionMenuBody(
    moduleReference: String,
    entityId: String,
    entityLabel: String,
    shareText: String,
    // v113-354 — when set, Share and Export PNG render THIS bespoke Style A
    // document (invoice/memo/ledger/profile) instead of the generic
    // title+body layout; suspend so the lambda can walk the QR approval gate.
    customDocumentImage: (suspend (android.content.Context) -> android.graphics.Bitmap)? = null,
    isDeleted: Boolean = false,
    onEdit: (() -> Unit)? = null,
    onDuplicate: ((onError: (String) -> Unit) -> Unit)? = null,
    onArchive: ((onError: (String) -> Unit) -> Unit)? = null,
    recordStatus: String? = null, // Task 4 — checked against ActionSafetyPolicy before Archive is allowed to fire
    archiveBlockedReasonOverride: String? = null, // Task B — for real conditions that aren't a "status" (e.g. outstanding due balance on master data); takes precedence over the status-based check so we never have to fabricate a fake status string just to trigger protection
    onRestore: (() -> Unit)? = null,
    onViewDetails: (() -> Unit)? = null,
    onSubmit: (() -> Unit)? = null, // Section 8 — "Submit" action, e.g. submitExpense/submit-for-approval; module wires its own real function
    onApprove: (() -> Unit)? = null, // Section 8 — "Approve" action, e.g. approveSalesInvoice/approveExpense/verifyCollection
    onReject: ((reason: String) -> Unit)? = null, // Section 8 — "Reject" action, requires a reason
    canApprove: Boolean = true,
    csvHeader: String = "",
    csvRow: String = "",
    historyLabel: String? = null, // "Stock History" | "Sales History" | "Dealer History" | "Retailer History" — module-specific quick view
    historyItems: List<String> = emptyList(),
    canEdit: Boolean = true, // Task 5 — permission-aware visibility: false shows Edit/Duplicate disabled with an explanation instead of hiding them outright
    canArchive: Boolean = true,
    // v113-361 — items the CALLER wants at the top of this same popup (the
    // module scaffold's "🏠 Home"). Exists so callers never have to wrap this
    // component in a DropdownMenu of their own: see the note on the
    // DropdownMenu below for why nesting was the real bug.
    extraLeadingItems: (@Composable ColumnScope.() -> Unit)? = null,
    expanded: Boolean,
    onDismissMenu: () -> Unit,
) {
    val context = LocalContext.current
    val menuScope = rememberCoroutineScope()
    var activeDialog by remember { mutableStateOf<String?>(null) }
    var viewDetailsOpen by remember { mutableStateOf(false) }
    var confirmArchiveOpen by remember { mutableStateOf(false) }
    var previewOpen by remember { mutableStateOf(false) }
    var rejectDialogOpen by remember { mutableStateOf(false) }
    var correctionDialogOpen by remember { mutableStateOf(false) }

    // v113-361 — THE ⋮ POSITION BUG, finally at its real cause.
    //
    // The module scaffold used to open its OWN DropdownMenu (with "🏠 Home" in
    // it) and call this component inside it — so this DropdownMenu became a
    // second popup nested in the first. A nested popup does not inherit its
    // parent popup's anchor: Compose positions it from scratch, which is why
    // the universal options landed under the ☰ on the left while "Home" sat
    // correctly under the ⋮ on the right.
    //
    // Three earlier attempts (v113-325 wrapper Box, v113-335 offset = -184dp,
    // v113-349 removing that offset) all adjusted the OUTER menu's alignment.
    // The outer menu was never misplaced, so none of them could have worked.
    // The fix is to have ONE popup: callers pass their own items through
    // extraLeadingItems instead of wrapping this in a second DropdownMenu.
    //
    // It also fixes a second, quieter bug in that nested arrangement: every
    // item here calls onDismissMenu() before opening a dialog, which closed
    // the outer menu and tore this whole subtree — dialogs included — out of
    // composition, so Preview/Reject/Correction simply never appeared from the
    // module ⋮. The dialogs below sit outside this DropdownMenu, so with one
    // popup they survive the dismiss.
    DropdownMenu(expanded = expanded, onDismissRequest = onDismissMenu) {
            extraLeadingItems?.invoke(this)
            DropdownMenuItem(
                text = { Text("View Details") },
                onClick = { onDismissMenu(); if (onViewDetails != null) onViewDetails() else viewDetailsOpen = true },
            )
            DropdownMenuItem(text = { Text("Preview") }, onClick = { onDismissMenu(); previewOpen = true })
            if (onEdit != null) {
                DropdownMenuItem(
                    text = { Text("Edit", color = if (!canEdit) TextSecondary else Color.Unspecified) },
                    onClick = { onDismissMenu(); if (canEdit) onEdit() else Toast.makeText(context, "এই কাজের জন্য আপনার permission নেই।", Toast.LENGTH_LONG).show() },
                )
            }
            if (onDuplicate != null) {
                DropdownMenuItem(
                    text = { Text("Duplicate", color = if (!canEdit) TextSecondary else Color.Unspecified) },
                    onClick = { onDismissMenu(); if (canEdit) onDuplicate { e -> Toast.makeText(context, e, Toast.LENGTH_LONG).show() } else Toast.makeText(context, "এই কাজের জন্য আপনার permission নেই।", Toast.LENGTH_LONG).show() },
                )
            }
            if (onSubmit != null) {
                DropdownMenuItem(text = { Text("Submit") }, onClick = { onDismissMenu(); onSubmit() })
            }
            if (onApprove != null) {
                DropdownMenuItem(
                    text = { Text("Approve", color = if (!canApprove) TextSecondary else SuccessGreen) },
                    onClick = { onDismissMenu(); if (canApprove) onApprove() else Toast.makeText(context, "এই কাজের জন্য আপনার permission নেই।", Toast.LENGTH_LONG).show() },
                )
            }
            if (onReject != null) {
                DropdownMenuItem(
                    text = { Text("Reject", color = if (!canApprove) TextSecondary else DangerRed) },
                    onClick = { onDismissMenu(); if (canApprove) rejectDialogOpen = true else Toast.makeText(context, "এই কাজের জন্য আপনার permission নেই।", Toast.LENGTH_LONG).show() },
                )
            }
            DropdownMenuItem(text = { Text("Correction Request") }, onClick = { onDismissMenu(); correctionDialogOpen = true })
            DropdownMenuItem(text = { Text("Approval History") }, onClick = { onDismissMenu(); activeDialog = "approvals" })
            DropdownMenuItem(text = { Text("Activity Log") }, onClick = { onDismissMenu(); activeDialog = "activity" })
            if (historyLabel != null) {
                DropdownMenuItem(text = { Text(historyLabel) }, onClick = { onDismissMenu(); activeDialog = "history" })
            }
            DropdownMenuItem(text = { Text("Attachments") }, onClick = { onDismissMenu(); activeDialog = "attachments" })
            if (csvRow.isNotBlank()) {
                DropdownMenuItem(
                    text = { Text("Export CSV") },
                    onClick = {
                        onDismissMenu()
                        try {
                            val dir = context.getExternalFilesDir(null)
                            if (dir == null) {
                                Toast.makeText(context, "Storage সহজলভ্য নেই — export সম্ভব হলো না।", Toast.LENGTH_LONG).show()
                            } else {
                                val file = File(dir, "${moduleReference}_${entityId.take(8)}_${System.currentTimeMillis()}.csv")
                                file.writeText((csvHeader.ifBlank { "Field,Value" }) + "\n" + csvRow)
                                // v113-351 — point 3: visible in the file manager, not only app-private storage.
                                publishFileToDownloads(context, file, "text/csv")
                                Toast.makeText(context, "Saved: Downloads/ABM ERP/${file.name}", Toast.LENGTH_LONG).show()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(context, "CSV export ব্যর্থ হয়েছে: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    },
                )
            }
            if (csvRow.isNotBlank()) {
                DropdownMenuItem(
                    text = { Text("Export Excel") },
                    onClick = {
                        onDismissMenu()
                        try {
                            // v113-351 — real .xlsx (person's point 2), from the same
                            // csvHeader/csvRow every call site already supplies, so all
                            // ~50 records gain Excel at once with no per-screen wiring.
                            val file = XlsxExport.writeWorkbook(context, "${moduleReference}_${entityId.take(8)}_${System.currentTimeMillis()}", csvHeader.ifBlank { "Field,Value" }, listOf(csvRow))
                            publishFileToDownloads(context, file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                            Toast.makeText(context, "Saved: Downloads/ABM ERP/${file.name}", Toast.LENGTH_LONG).show()
                        } catch (e: Exception) {
                            Toast.makeText(context, "Excel তৈরি ব্যর্থ হয়েছে: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    },
                )
            }
            DropdownMenuItem(
                text = { Text("Export PDF") },
                onClick = {
                    onDismissMenu()
                    try {
                        val file = exportRecordPdf(context, moduleReference, entityLabel, shareText)
                        publishFileToDownloads(context, file, "application/pdf")
                        Toast.makeText(context, "Saved: Downloads/ABM ERP/${file.name}", Toast.LENGTH_LONG).show()
                    } catch (e: Exception) {
                        Toast.makeText(context, "PDF তৈরি ব্যর্থ হয়েছে: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                },
            )
            DropdownMenuItem(
                text = { Text("Export PNG") },
                onClick = {
                    onDismissMenu()
                    if (customDocumentImage != null) {
                        // v113-354 — bespoke Style A document; falls back to the
                        // generic renderer if the bespoke one throws, because an
                        // export that fails to change style must still export.
                        menuScope.launch {
                            val file = try {
                                val bmp = customDocumentImage.invoke(context)
                                publishImageToGallery(context, bmp, "${moduleReference}_${System.currentTimeMillis()}")
                                val dir = File(context.cacheDir, "shares").apply { if (!exists()) mkdirs() }
                                File(dir, "${moduleReference}_${System.currentTimeMillis()}.png").also { f ->
                                    java.io.FileOutputStream(f).use { out -> bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out) }
                                }
                            } catch (e: Exception) {
                                try { exportRecordImage(context, moduleReference, entityLabel, shareText) } catch (e2: Exception) { null }
                            }
                            if (file == null) {
                                Toast.makeText(context, "PNG তৈরি ব্যর্থ হয়েছে।", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "Saved: ${file.name}", Toast.LENGTH_LONG).show()
                                try { shareImageFile(context, file, entityLabel) } catch (e: Exception) { Toast.makeText(context, "Saved, but no app found to share it.", Toast.LENGTH_LONG).show() }
                            }
                        }
                    } else {
                        try {
                            val file = exportRecordImage(context, moduleReference, entityLabel, shareText)
                            Toast.makeText(context, "Saved: ${file.name}", Toast.LENGTH_LONG).show()
                            try { shareImageFile(context, file, entityLabel) } catch (e: Exception) { Toast.makeText(context, "Saved, but no app found to share it.", Toast.LENGTH_LONG).show() }
                        } catch (e: Exception) {
                            Toast.makeText(context, "PNG তৈরি ব্যর্থ হয়েছে: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                },
            )
            DropdownMenuItem(
                text = { Text("Share") },
                onClick = {
                    onDismissMenu()
                    // v113-331 — the person's own instruction: "jkn universal
                    // key diye share e click kori then jkn Whatsapp e pathai
                    // tkn text akare msg send na hoy... oi screen er main
                    // dwtar view tai hbe. aitai proffesonal hbe."
                    //
                    // Share sent `text/plain`, so an invoice arrived in
                    // WhatsApp as a wall of unformatted lines. They want the
                    // record itself as a picture — and confirmed when asked
                    // that this means the screen's MAIN DATA rendered
                    // properly (the whole invoice, the whole ledger, the
                    // whole profile), not a crop of whatever happened to be
                    // visible.
                    //
                    // That renderer already existed and was already used by
                    // "Export JPG" — `renderRecordBitmap` lays the record out
                    // in full, beyond the screen's own height. So Share now
                    // sends exactly what Export JPG produces, through the
                    // same proven `shareImageFile` path. This applies
                    // everywhere at once, because every module's ⋮ goes
                    // through this one component.
                    //
                    // Falls back to text if image generation genuinely fails
                    // (no storage, render error) — sharing something is
                    // better than sharing nothing, and the fallback is the
                    // exact behaviour that existed before.
                    if (customDocumentImage != null) {
                        // v113-354 — bespoke path with the same something-always-
                        // goes-out chain: bespoke → generic image → plain text.
                        menuScope.launch {
                            try {
                                val bmp = customDocumentImage.invoke(context)
                                shareStyledDocumentImage(context, entityLabel, bmp)
                            } catch (e: Exception) {
                                try {
                                    val file = exportRecordImage(context, moduleReference, entityLabel, shareText)
                                    shareImageFile(context, file, entityLabel)
                                } catch (e2: Exception) {
                                    val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, shareText) }
                                    try { context.startActivity(Intent.createChooser(intent, entityLabel)) } catch (e3: Exception) { Toast.makeText(context, "No app found to share this.", Toast.LENGTH_LONG).show() }
                                }
                            }
                        }
                    } else {
                        try {
                            val file = exportRecordImage(context, moduleReference, entityLabel, shareText)
                            shareImageFile(context, file, entityLabel)
                        } catch (e: Exception) {
                            val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, shareText) }
                            try { context.startActivity(Intent.createChooser(intent, entityLabel)) } catch (e2: Exception) { Toast.makeText(context, "No app found to share this.", Toast.LENGTH_LONG).show() }
                        }
                    }
                },
            )
            DropdownMenuItem(
                text = { Text("Print") },
                onClick = {
                    onDismissMenu()
                    printRecord(context, entityLabel, shareText)
                },
            )
            if (!isDeleted && onArchive != null) {
                val blockedReason = archiveBlockedReasonOverride
                    ?: ActionSafetyPolicy.archiveBlockedReason(recordStatus)
                    ?: if (!canArchive) "এই কাজের জন্য আপনার permission নেই।" else null
                DropdownMenuItem(
                    text = { Text("Archive (Soft Delete)", color = if (blockedReason != null) TextSecondary else Color.Unspecified) },
                    onClick = {
                        onDismissMenu()
                        if (blockedReason != null) Toast.makeText(context, blockedReason, Toast.LENGTH_LONG).show() else confirmArchiveOpen = true
                    },
                )
            }
            if (isDeleted && onRestore != null) {
                DropdownMenuItem(text = { Text("Restore") }, onClick = { onDismissMenu(); onRestore() })
            }
        }

    when (activeDialog) {
        "approvals" -> ApprovalHistoryDialog(moduleReference, entityId) { activeDialog = null }
        "activity" -> ActivityLogDialog(moduleReference, entityId) { activeDialog = null }
        "attachments" -> AttachmentsDialog(moduleReference, entityId) { activeDialog = null }
        "history" -> SimpleHistoryDialog(historyLabel ?: "History", historyItems) { activeDialog = null }
    }

    if (viewDetailsOpen) {
        Dialog(onDismissRequest = { viewDetailsOpen = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(entityLabel, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Text(shareText, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(10.dp))
                    TextButton(onClick = { viewDetailsOpen = false }) { Text("Close") }
                }
            }
        }
    }

    if (confirmArchiveOpen) {
        AlertDialog(
            onDismissRequest = { confirmArchiveOpen = false },
            title = { Text("Archive $entityLabel?") },
            text = { Text("এটা soft-delete হবে — পরে \"Restore\" দিয়ে ফিরিয়ে আনা যাবে।") },
            confirmButton = {
                TextButton(onClick = { confirmArchiveOpen = false; onArchive?.invoke { e -> Toast.makeText(context, e, Toast.LENGTH_LONG).show() } }) { Text("Archive", color = DangerRed) }
            },
            dismissButton = {
                TextButton(onClick = { confirmArchiveOpen = false }) { Text("Cancel") }
            },
        )
    }

    if (rejectDialogOpen) {
        var reason by remember { mutableStateOf("") }
        Dialog(onDismissRequest = { rejectDialogOpen = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Reject $entityLabel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ (আবশ্যক)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { rejectDialogOpen = false }) { Text("Cancel") }
                        Button(onClick = { if (reason.isNotBlank()) { onReject?.invoke(reason); rejectDialogOpen = false } }, enabled = reason.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = DangerRed)) { Text("Reject") }
                    }
                }
            }
        }
    }

    if (correctionDialogOpen) {
        var correctionType by remember { mutableStateOf(com.abm.erp.data.CorrectionType.EDIT) }
        var proposedChange by remember { mutableStateOf("") }
        var reason by remember { mutableStateOf("") }
        var submitted by remember { mutableStateOf(false) }
        Dialog(onDismissRequest = { correctionDialogOpen = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                // v113-357 — worklist কাজ ৩-এর নাম-ধরা "correction request dialog";
                // দুটো TextField (proposed change + কারণ) কিবোর্ডের নিচে চলে যেত।
                Column(Modifier.padding(16.dp).imePadding()) {
                    Text("Correction Request — $entityLabel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = correctionType == com.abm.erp.data.CorrectionType.EDIT, onClick = { correctionType = com.abm.erp.data.CorrectionType.EDIT }, label = { Text("Edit") })
                        FilterChip(selected = correctionType == com.abm.erp.data.CorrectionType.DELETE, onClick = { correctionType = com.abm.erp.data.CorrectionType.DELETE }, label = { Text("Delete") })
                    }
                    if (correctionType == com.abm.erp.data.CorrectionType.EDIT) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = proposedChange, onValueChange = { proposedChange = it }, label = { Text("field=newValue") }, modifier = Modifier.fillMaxWidth())
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ (আবশ্যক)") }, modifier = Modifier.fillMaxWidth())
                    if (submitted) Text("✓ জমা দেওয়া হয়েছে — Manager/Chairman review করবেন।", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { correctionDialogOpen = false }) { Text("Close") }
                        Button(
                            onClick = {
                                MockRepository.submitCorrectionRequest(moduleReference, entityId, correctionType, reason, proposedChange, shareText)
                                submitted = true
                            },
                            enabled = reason.isNotBlank() && !submitted,
                        ) { Text("Submit") }
                    }
                }
            }
        }
    }

    if (previewOpen) {
        // v113-358 — Preview used to always draw the generic title+body image, so
        // it showed something the Share/Export buttons right below it would NOT
        // produce. Now it previews the real bespoke document when one exists,
        // falling back to the generic render (and then to null) on failure.
        var bitmap by remember(entityId) { mutableStateOf<android.graphics.Bitmap?>(null) }
        LaunchedEffect(entityId, customDocumentImage != null) {
            bitmap = if (customDocumentImage != null) {
                try { customDocumentImage.invoke(context) }
                catch (e: Exception) { try { renderRecordBitmap(entityLabel, shareText) } catch (e2: Exception) { null } }
            } else {
                try { renderRecordBitmap(entityLabel, shareText) } catch (e: Exception) { null }
            }
        }
        Dialog(onDismissRequest = { previewOpen = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Preview", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    // v113-358 — held in a local val: `bitmap` is now a delegated
                    // state var, and Kotlin will not smart-cast one to non-null.
                    val previewBitmap = bitmap
                    if (previewBitmap != null) {
                        androidx.compose.foundation.Image(
                            bitmap = previewBitmap.asImageBitmap(),
                            contentDescription = entityLabel,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    } else {
                        Text("Preview তৈরি করা যায়নি — তবু নিচে থেকে Save/Share করতে পারবেন।", color = TextSecondary)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = {
                            try {
                                val file = exportRecordImage(context, moduleReference, entityLabel, shareText)
                                Toast.makeText(context, "Saved: ${file.name}", Toast.LENGTH_LONG).show()
                                previewOpen = false
                                try {
                                    shareImageFile(context, file, entityLabel)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Saved, but no app found to share it.", Toast.LENGTH_LONG).show()
                                }
                            } catch (e: Exception) {
                                Toast.makeText(context, "PNG তৈরি ব্যর্থ হয়েছে: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        }) { Text("Save as JPG") }
                        TextButton(onClick = { previewOpen = false }) { Text("Close") }
                    }
                }
            }
        }
    }

}


/** Universal Action Menu — Print, via Android's own android.print.PrintManager (system print dialog: physical printer or "Save as PDF"), no external library. */
fun printRecord(context: android.content.Context, title: String, body: String) {
    val printManager = context.getSystemService(android.content.Context.PRINT_SERVICE) as android.print.PrintManager
    val adapter = object : android.print.PrintDocumentAdapter() {
        override fun onLayout(
            oldAttributes: android.print.PrintAttributes?, newAttributes: android.print.PrintAttributes,
            cancellationSignal: android.os.CancellationSignal?, callback: LayoutResultCallback, extras: android.os.Bundle?,
        ) {
            if (cancellationSignal?.isCanceled == true) { callback.onLayoutCancelled(); return }
            val info = android.print.PrintDocumentInfo.Builder("$title.pdf")
                .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build()
            callback.onLayoutFinished(info, true)
        }

        override fun onWrite(
            pages: Array<out android.print.PageRange>?, destination: android.os.ParcelFileDescriptor,
            cancellationSignal: android.os.CancellationSignal?, callback: WriteResultCallback,
        ) {
            val pdfDocument = android.graphics.pdf.PdfDocument()
            val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val titlePaint = android.graphics.Paint().apply { textSize = 18f; isFakeBoldText = true }
            val bodyPaint = android.graphics.Paint().apply { textSize = 12f }
            page.canvas.drawText(title, 40f, 50f, titlePaint)
            var y = 80f
            body.split("\n").forEach { line -> page.canvas.drawText(line, 40f, y, bodyPaint); y += 18f }
            pdfDocument.finishPage(page)
            pdfDocument.writeTo(android.os.ParcelFileDescriptor.AutoCloseOutputStream(destination))
            pdfDocument.close()
            callback.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
        }
    }
    printManager.print(title, adapter, android.print.PrintAttributes.Builder().build())
}

/**
 * Task 6 — reusable CSV escaping utility. Wraps a field in quotes and
 * doubles any internal quotes whenever the value contains a comma, quote,
 * or newline — the standard CSV escaping rule (RFC 4180). Bengali text
 * passes through unescaped/untouched (UTF-8, no special CSV meaning).
 */
fun escapeCsvField(value: String): String =
    if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
        "\"" + value.replace("\"", "\"\"") + "\""
    } else value

fun toCsvRow(vararg fields: Any?): String = fields.joinToString(",") { escapeCsvField(it?.toString() ?: "") }

/**
 * Renders a record's title+body as an actual bitmap via android.graphics.Canvas
 * — the same real data used for Share/PDF, drawn onto pixels rather than a
 * screenshot of the live Compose UI (this codebase has no existing
 * composable-to-bitmap capture pattern, and adding one safely is a bigger
 * change than this version's scope). This is a genuinely rendered image
 * with the record's real current data, not a renamed or fabricated file.
 */
private fun renderRecordBitmap(title: String, body: String): android.graphics.Bitmap =
    // v113-351 — delegates to the ONE styled renderer (Style A) in
    // StructuredExports, so Export PNG, Share, and every module summary all
    // produce the same professional document look. The v113-331/337 content
    // sizing and OOM cap live inside it.
    renderStyledDocumentBitmap(title, body)

private fun shareImageFile(context: android.content.Context, file: File, label: String) {
    val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "image/png"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, label))
}

/** Export JPG — writes the rendered bitmap above to a real .jpg file next to the CSV/PDF exports. */
private fun exportRecordImage(context: android.content.Context, moduleReference: String, title: String, body: String): File {
    val bitmap = renderRecordBitmap(title, body)
    // v113-350 — every produced image also lands in the device gallery
    // (Pictures/ABM ERP); the cache copy below stays for FileProvider sharing.
    publishImageToGallery(context, bitmap, "${moduleReference}_${System.currentTimeMillis()}")
    // v113-337 — cacheDir, not external storage: external can genuinely be
    // unavailable or return null, and this file is handed straight to
    // FileProvider for sharing. Same reason as shareTextSummary.
    val dir = File(context.cacheDir, "shares").apply { if (!exists()) mkdirs() }
    // v113-350 — PNG, the person's choice: edits don't hide in recompression,
    // and it matches the gallery copy above.
    val file = File(dir, "${moduleReference}_${System.currentTimeMillis()}.png")
    java.io.FileOutputStream(file).use { out -> bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out) }
    return file
}

/** Single-record PDF, same android.graphics.pdf.PdfDocument approach as the Reports screen's summary export — no external library. */
private fun exportRecordPdf(context: android.content.Context, moduleReference: String, title: String, body: String): File {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas
    val titlePaint = android.graphics.Paint().apply { textSize = 18f; isFakeBoldText = true }
    val bodyPaint = android.graphics.Paint().apply { textSize = 12f }
    canvas.drawText(title, 40f, 50f, titlePaint)
    var y = 80f
    body.split("\n").forEach { line ->
        canvas.drawText(line, 40f, y, bodyPaint)
        y += 18f
    }
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "${moduleReference}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

@Composable
private fun SimpleHistoryDialog(label: String, items: List<String>, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 500.dp)) {
                Text(label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                if (items.isEmpty()) {
                    Text("এখনো কোনো রেকর্ড নেই।", color = TextSecondary)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(items) { line ->
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Text(line, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                TextButton(onClick = onClose) { Text("Close") }
            }
        }
    }
}

@Composable
private fun ApprovalHistoryDialog(moduleReference: String, entityId: String, onClose: () -> Unit) {
    val history = remember(entityId) { MockRepository.approvalHistoryFor(moduleReference, entityId) }
    Dialog(onDismissRequest = onClose) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 500.dp)) {
                Text("Approval History", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                if (history.isEmpty()) {
                    Text("এই রেকর্ডের জন্য কোনো approval history নেই।", color = TextSecondary)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(history) { a ->
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Level ${a.level} — ${a.fromEmployee}", style = MaterialTheme.typography.bodySmall)
                                    Text(a.status.name, color = when (a.status.name) { "APPROVED" -> SuccessGreen; "REJECTED" -> DangerRed; else -> WarningAmber }, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                                }
                                a.rejectReason?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                TextButton(onClick = onClose) { Text("Close") }
            }
        }
    }
}

@Composable
private fun ActivityLogDialog(moduleReference: String, entityId: String, onClose: () -> Unit) {
    val log by MockRepository.activityLogFor(moduleReference, entityId).collectAsState(initial = emptyList())
    Dialog(onDismissRequest = onClose) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 500.dp)) {
                Text("Activity Log", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                if (log.isEmpty()) {
                    Text("এই রেকর্ডের জন্য কোনো activity log নেই।", color = TextSecondary)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(log) { e ->
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(e.action, fontWeight = FontWeight.Bold, color = TextPrimary, style = MaterialTheme.typography.labelMedium)
                                    Text("${e.timestamp}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                }
                                Text("by ${e.performedBy} (${e.performedByRole})", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                TextButton(onClick = onClose) { Text("Close") }
            }
        }
    }
}

@Composable
private fun AttachmentsDialog(moduleReference: String, entityId: String, onClose: () -> Unit) {
    val attachments by MockRepository.attachmentsFor(moduleReference, entityId).collectAsState(initial = emptyList())
    val context = LocalContext.current
    var pendingCameraUri by remember { mutableStateOf<android.net.Uri?>(null) }

    val filePicker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent(),
    ) { uri ->
        if (uri != null) {
            val mime = context.contentResolver.getType(uri) ?: ""
            val type = when {
                mime.startsWith("image") -> com.abm.erp.data.AttachmentType.PHOTO
                mime.startsWith("audio") -> com.abm.erp.data.AttachmentType.AUDIO
                mime.startsWith("video") -> com.abm.erp.data.AttachmentType.VIDEO
                mime == "application/pdf" -> com.abm.erp.data.AttachmentType.PDF
                else -> com.abm.erp.data.AttachmentType.DOCUMENT
            }
            MockRepository.uploadAttachment(context, moduleReference, entityId, type, uri.toString(), onRejected = { reason -> android.widget.Toast.makeText(context, reason, android.widget.Toast.LENGTH_LONG).show() }) { }
        }
    }
    // Camera capture (Photo) — writes straight into a FileProvider-backed cache Uri, same pattern as Sales Chain's existing outlet-photo capture.
    val cameraLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.TakePicture(),
    ) { success ->
        if (success && pendingCameraUri != null) {
            MockRepository.uploadAttachment(context, moduleReference, entityId, com.abm.erp.data.AttachmentType.PHOTO, pendingCameraUri.toString(), onRejected = { reason -> android.widget.Toast.makeText(context, reason, android.widget.Toast.LENGTH_LONG).show() }) { }
        }
    }
    // Audio record (Audio Note) via the device's own voice recorder app — no in-app mic-recording UI needed, avoids a whole new permission+MediaRecorder subsystem for a rarely-used capture path.
    val audioLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(),
    ) { result -> result.data?.data?.let { uri -> MockRepository.uploadAttachment(context, moduleReference, entityId, com.abm.erp.data.AttachmentType.AUDIO, uri.toString(), onRejected = { reason -> android.widget.Toast.makeText(context, reason, android.widget.Toast.LENGTH_LONG).show() }) { } } }
    // Video capture via the device camera app's own video mode.
    val videoLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CaptureVideo(),
    ) { success ->
        if (success && pendingCameraUri != null) {
            MockRepository.uploadAttachment(context, moduleReference, entityId, com.abm.erp.data.AttachmentType.VIDEO, pendingCameraUri.toString(), onRejected = { reason -> android.widget.Toast.makeText(context, reason, android.widget.Toast.LENGTH_LONG).show() }) { }
        }
    }

    fun newCacheUri(ext: String): android.net.Uri {
        val file = File(context.cacheDir, "capture_${System.currentTimeMillis()}.$ext")
        return androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    Dialog(onDismissRequest = onClose) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 500.dp)) {
                Text("Attachments", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { filePicker.launch("*/*") }, modifier = Modifier.fillMaxWidth()) { Text("📁 Pick Photo/PDF/Doc/Audio/Video") }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = { val uri = newCacheUri("jpg"); pendingCameraUri = uri; cameraLauncher.launch(uri) }, modifier = Modifier.weight(1f)) { Text("📷 Photo") }
                    Button(onClick = { val uri = newCacheUri("mp4"); pendingCameraUri = uri; videoLauncher.launch(uri) }, modifier = Modifier.weight(1f)) { Text("🎥 Video") }
                    Button(onClick = { audioLauncher.launch(Intent(android.provider.MediaStore.Audio.Media.RECORD_SOUND_ACTION)) }, modifier = Modifier.weight(1f)) { Text("🎙️ Audio") }
                }
                Spacer(Modifier.height(10.dp))
                if (attachments.isEmpty()) {
                    Text("এখনো কোনো attachment নেই।", color = TextSecondary)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(attachments) { a ->
                            var showRemoveConfirm by remember { mutableStateOf(false) }
                            GlassCard(modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text(a.type.name, fontWeight = FontWeight.SemiBold, color = TextPrimary, style = MaterialTheme.typography.labelMedium)
                                        Text("by ${a.uploadedBy} · ${a.createdAt}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                    }
                                    TextButton(onClick = { showRemoveConfirm = true }) { Text("Remove", color = DangerRed) }
                                }
                                if (showRemoveConfirm) {
                                    Dialog(onDismissRequest = { showRemoveConfirm = false }) {
                                        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                            Column(Modifier.padding(16.dp)) {
                                                Text("Remove this attachment?", style = MaterialTheme.typography.titleMedium)
                                                Text("এটা undo করা যায় না।", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                                Spacer(Modifier.height(10.dp))
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    TextButton(onClick = { showRemoveConfirm = false }) { Text("Cancel") }
                                                    Button(onClick = { MockRepository.removeAttachment(a); showRemoveConfirm = false }, colors = ButtonDefaults.buttonColors(containerColor = DangerRed)) { Text("Remove") }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                TextButton(onClick = onClose) { Text("Close") }
            }
        }
    }
}
