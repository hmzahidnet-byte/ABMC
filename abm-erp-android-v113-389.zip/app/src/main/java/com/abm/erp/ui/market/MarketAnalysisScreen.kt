package com.abm.erp.ui.market

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.data.MockRepository
import androidx.compose.foundation.background
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import androidx.compose.ui.graphics.Color

class MarketAnalysisViewModel : ViewModel() {
    val dealers = MockRepository.dealers
    val marketSummary = MockRepository.marketSummary
}

/**
 * Zone-wise trend, computed from real dealer sales data (not a separate
 * forecast model yet — that needs historical time-series data this
 * prototype doesn't capture). Shows each zone's 90-day sales and how much
 * of it is tied up in due balance, which is the clearest real signal we
 * have today about which zones are healthy vs strained.
 */
@Composable
fun MarketAnalysisScreen(vm: MarketAnalysisViewModel = viewModel()) {
    val dealers by vm.dealers.collectAsState()
    val precomputed by vm.marketSummary.collectAsState()
    val byZone = remember(dealers, precomputed) {
        if (precomputed.isNotEmpty()) {
            precomputed.map { it.zone to (it.salesLast90Days to it.dueBalance) }.sortedByDescending { it.second.first }
        } else {
            dealers.groupBy { it.zone }.mapValues { (_, list) ->
                list.sumOf { it.salesLast90Days } to list.sumOf { it.dueBalance }
            }.toList().sortedByDescending { it.second.first }
        }
    }

    val zoneCount = dealers.map { it.zone }.distinct().size
    val totalMarketDue = dealers.sumOf { it.dueBalance }
    Column(Modifier.fillMaxSize()) {
        com.abm.erp.core.ModuleWorkspaceHeader("Market Analysis", "📈", 0xFF38C96A, 0xFF1E9E4C, iconVector = Icons.Filled.QueryStats, miniDashboard = {
            com.abm.erp.core.ModuleStat("Zones", "$zoneCount", TextPrimary)
            com.abm.erp.core.ModuleStat("Dealers", "${dealers.size}", TextPrimary)
            com.abm.erp.core.ModuleStat("Total Due", "৳${"%,.0f".format(totalMarketDue)}", if (totalMarketDue > 0) WarningAmber else SuccessGreen)
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("Dealer", "SalesInvoice"))
        })
        Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Zone-wise sales vs due balance, from live dealer data.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "Zone,Sales90d,Due\n"
                    val rows = byZone.joinToString("\n") { (zone, pair) -> com.abm.erp.core.toCsvRow(zone, pair.first, pair.second) }
                    val file = java.io.File(context.getExternalFilesDir(null), "market_analysis_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Market Analysis\n" + byZone.joinToString("\n") { (zone, pair) -> "$zone — Sales ৳${pair.first}, Due ৳${pair.second}" }
                    // v113-335 — was a hand-rolled text/plain share. Now routed
                    // through the one shared helper so every screen sends the
                    // rendered image, per the person's own requirement.
                    com.abm.erp.core.shareTextSummary(context, "Market Analysis", summary)
                },
            )
        }
        Spacer(Modifier.height(6.dp))

        if (byZone.isEmpty()) {
            Text("No dealer sales data yet.", color = TextSecondary)
        }
        byZone.forEach { (zone, pair) ->
            val (sales, due) = pair
            val dueRatio = if (sales == 0.0) 0.0 else due / sales
            GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(zone, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text(
                            if (dueRatio < 0.3) "Healthy" else if (dueRatio < 0.6) "Watch" else "At risk",
                            color = if (dueRatio < 0.3) SuccessGreen else if (dueRatio < 0.6) TextSecondary else DangerRed,
                            style = MaterialTheme.typography.labelSmall,
                        )
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "MarketAnalysis", entityId = zone, entityLabel = "$zone — Market Analysis",
                            shareText = "$zone\n90-day sales: ৳${"%,.0f".format(sales)}\nDue: ৳${"%,.0f".format(due)} (${"%.0f".format(dueRatio * 100)}%)",
                            csvHeader = "Zone,Sales90d,Due,DueRatioPct", csvRow = com.abm.erp.core.toCsvRow(zone, sales, due, "%.0f".format(dueRatio * 100)),
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text("90-day sales: ৳${"%,.0f".format(sales)}", style = MaterialTheme.typography.bodyMedium)
                Text("Due balance: ৳${"%,.0f".format(due)} (${"%.0f".format(dueRatio * 100)}% of sales)", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                Spacer(Modifier.height(6.dp))
                val barColor = if (dueRatio < 0.3) SuccessGreen else if (dueRatio < 0.6) WarningAmber else DangerRed
                androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth().height(8.dp).background(Color(0xFFEEF1F5), androidx.compose.foundation.shape.RoundedCornerShape(999.dp))) {
                    androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth(dueRatio.toFloat().coerceIn(0f, 1f)).fillMaxHeight().background(barColor, androidx.compose.foundation.shape.RoundedCornerShape(999.dp)))
                }
            }
        }
        }
    }
}
