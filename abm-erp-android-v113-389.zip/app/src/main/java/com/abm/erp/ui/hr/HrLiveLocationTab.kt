package com.abm.erp.ui.hr

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.AttendanceEngine
import com.abm.erp.data.CascadeEngine
import com.abm.erp.data.EmployeeProfile
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import java.time.LocalDate
import java.time.LocalDateTime

private val TEAL = Color(0xFF0E9F9F)
private val TEAL_BG = Color(0xFFE6F7F7)

/**
 * v113-388 — Live Location drawer (r2-এর ২ ও ৩ নম্বর স্ক্রিন)।
 *
 * আপনার নির্দেশ: Employee list আর Live location **আলাদা drawer**।
 *
 * সময়সূচি ৯টা–৫টা, ২ ঘণ্টা পরপর — তাই দিনে **সর্বোচ্চ ৫টা ping** (৯, ১১, ১,
 * ৩, ৫)। সারিতেই সেই পাঁচটা ঘর দেখানো হয়: কোনটা এসেছে, কোনটা আসেনি। এটাই
 * সবচেয়ে দরকারি তথ্য — "কে মাঠে আছে" নয়, "**কার খবর পাওয়া যাচ্ছে না**"।
 *
 * এখানে সৎ থাকার একটা জায়গা আছে: ২ ঘণ্টার ping মানে পথের **রেখা অনুমান করা**,
 * হুবহু চলাচল নয়। পর্দাতেও সেটাই লেখা, নইলে কেউ ভাবত GPS trail দেখছে।
 */
@Composable
fun HrLiveLocationTab() {
    val employees by MockRepository.employeeProfiles.collectAsState()
    val live = remember(employees) { employees.filter { !it.isDeleted } }
    val today = remember { LocalDate.now() }
    val settings = remember(employees) { MockRepository.companySettings() }
    val holidays = remember(settings.holidaysRaw) { AttendanceEngine.parseHolidays(settings.holidaysRaw) }
    val isWorkingDay = remember(today, settings.workingDays, holidays) {
        AttendanceEngine.isWorkingDay(today, settings.workingDays, holidays)
    }

    // মাঠের কর্মী = Wing 2. Wing 1-এর অবস্থান ট্র্যাক করার কিছু নেই।
    val field = remember(live) {
        live.filter { CascadeEngine.wingOf(it.role) == CascadeEngine.Wing.FIELD && CascadeEngine.isActiveOn(it, today) }
    }
    var openFor by remember { mutableStateOf<String?>(null) }
    val opened = remember(openFor, field) { field.firstOrNull { it.id == openFor } }

    if (opened != null) {
        LocationDetail(opened) { openFor = null }
        return
    }

    Column(
        Modifier.fillMaxSize().background(com.abm.erp.theme.DashBg)
            .verticalScroll(rememberScrollState()).padding(12.dp),
    ) {
        if (!isWorkingDay) {
            Card(accent = WarningAmber.copy(alpha = 0.4f)) {
                Text(
                    "আজ ছুটি (${AttendanceEngine.offReason(today, settings.workingDays, holidays) ?: "—"}) — " +
                        "কোনো ping পাঠানো হচ্ছে না।",
                    fontSize = 11.sp, color = TextPrimary, lineHeight = 16.sp,
                )
            }
            Spacer(Modifier.height(10.dp))
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Stat("মাঠে", "${field.size}", TEAL, TEAL_BG, Modifier.weight(1f))
            Stat("কর্মঘণ্টা", "৯–৫", Color(0xFF2563EB), Color(0xFFEEF4FF), Modifier.weight(1f))
            Stat("ping", "২ ঘণ্টায়", DarazOrange, Color(0xFFFFF3EC), Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))

        if (field.isEmpty()) {
            Card { Text("কোনো সক্রিয় field employee নেই।", fontSize = 11.sp, color = TextSecondary) }
        }
        field.forEach { e ->
            Card {
                Row(
                    Modifier.fillMaxWidth().clickable { openFor = e.id },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.size(36.dp).clip(RoundedCornerShape(18.dp)).background(TEAL_BG),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.Person, contentDescription = null, tint = TEAL, modifier = Modifier.size(18.dp)) }
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.fullName, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
                        Text(
                            "${e.role.name} · ${CascadeEngine.geoKeyOf(e) ?: "এলাকা বসানো হয়নি"}",
                            fontSize = 9.5.sp, color = TextSecondary, maxLines = 1,
                        )
                    }
                    Icon(Icons.Filled.Map, contentDescription = "মানচিত্র", tint = TEAL, modifier = Modifier.size(17.dp))
                }
                Spacer(Modifier.height(7.dp))
                PingStrip(isWorkingDay)
            }
            Spacer(Modifier.height(8.dp))
        }

        Text(
            "২ ঘণ্টার ping মানে দিনে ৫টা বিন্দু — পথের রেখা এখান থেকে অনুমান করা, " +
                "হুবহু চলাচল নয়। খরচ কমাতে এই সময়সূচি বেছে নেওয়া হয়েছে।",
            fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
        )
        Spacer(Modifier.height(24.dp))
    }
}

/**
 * আজকের পাঁচটা ping-এর ঘর।
 *
 * অতীতের সময় পেরিয়ে গেলেও ping না এলে **লাল**, ভবিষ্যতের ঘর ধূসর — এই
 * পার্থক্যটা জরুরি: "এখনো সময় হয়নি" আর "সময় পেরিয়ে গেছে কিন্তু খবর নেই"
 * দুটো সম্পূর্ণ আলাদা কথা, আর দ্বিতীয়টাই দেখার জিনিস।
 */
@Composable
private fun PingStrip(isWorkingDay: Boolean) {
    val slots = listOf(9, 11, 13, 15, 17)
    val nowHour = remember { LocalDateTime.now().hour }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        slots.forEach { h ->
            val past = isWorkingDay && nowHour >= h
            Box(
                Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp))
                    .background(if (!isWorkingDay) Color(0xFFE5E9EF) else if (past) DangerRed.copy(alpha = 0.55f) else Color(0xFFE5E9EF)),
            )
        }
    }
    Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        listOf("৯টা", "১১টা", "১টা", "৩টা", "৫টা").forEach {
            Text(it, fontSize = 8.sp, color = TextSecondary)
        }
    }
}

/* ── চাপলে মানচিত্র ────────────────────────────────────────────────────── */

@Composable
private fun LocationDetail(emp: EmployeeProfile, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(com.abm.erp.theme.DashBg)
            .verticalScroll(rememberScrollState()).padding(12.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(30.dp).clip(RoundedCornerShape(15.dp)).background(Color.White).clickable { onBack() },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.ArrowBack, contentDescription = "ফিরে যান", tint = TextPrimary, modifier = Modifier.size(16.dp)) }
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(emp.fullName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("${emp.role.name} · আজ", fontSize = 10.sp, color = TextSecondary)
            }
        }

        // পরিকল্পিত outlet — route থেকে; আসল চলাচল ping থেকে (এখনো সংগৃহীত হয়নি)
        val routes by MockRepository.salesRoutes.collectAsState()
        val myRoute = remember(routes, emp.id) { routes.firstOrNull { it.assignedToEmployeeId == emp.id && it.isActive } }

        Card {
            Text("আজকের অবস্থান", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(Modifier.height(7.dp))
            Box(
                Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(11.dp)).background(Color(0xFFEAF3EA)),
                contentAlignment = Alignment.Center,
            ) {
                Canvas(Modifier.fillMaxSize().padding(14.dp)) {
                    // কর্মঘণ্টার পাঁচটা ঘর — বিন্দু হিসেবে, কিন্তু ফাঁপা, কারণ
                    // আজকের সত্যিকারের ping এখনো আসেনি। ভরাট আঁকলে মিথ্যা হতো।
                    val n = 5
                    repeat(n) { i ->
                        val x = size.width * (i + 0.5f) / n
                        val y = size.height * (0.75f - 0.12f * i)
                        drawCircle(Color.White, radius = 8f, center = Offset(x, y))
                        drawCircle(TEAL.copy(alpha = 0.35f), radius = 6f, center = Offset(x, y))
                    }
                }
                Text(
                    "আজকের ping এখনো আসেনি",
                    fontSize = 10.5.sp, color = TextSecondary,
                    modifier = Modifier.background(Color(0xCCFFFFFF), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 4.dp),
                )
            }
            Spacer(Modifier.height(7.dp))
            Text(
                "৯টা–৫টার মধ্যে ২ ঘণ্টা পরপর অবস্থান আসবে। ফাঁপা বিন্দু = যে ঘরে এখনো খবর নেই।",
                fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
            )
        }

        Spacer(Modifier.height(10.dp))
        Card {
            Text("পরিকল্পিত route", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(Modifier.height(5.dp))
            if (myRoute == null) {
                Text("এই কর্মীর কোনো route plan নেই।", fontSize = 10.5.sp, color = TextSecondary)
            } else {
                Text("${myRoute.name} · ${myRoute.outletIds.size} outlet", fontSize = 11.sp, color = TextPrimary)
                Spacer(Modifier.height(4.dp))
                Text(
                    "ভিজিট হয়েছে কি না — visit check-in থেকে জানা যাবে, ping থেকে নয়।",
                    fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
                )
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

/* ── ছোট সহায়ক ─────────────────────────────────────────────────────────── */

@Composable
private fun Stat(label: String, value: String, ink: Color, bg: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(11.dp)).background(bg).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(label, fontSize = 8.5.sp, color = TextSecondary, maxLines = 1)
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ink, maxLines = 1)
    }
}

@Composable
private fun Card(accent: Color? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color.White)
            .border(1.dp, accent ?: HairlineBorder, RoundedCornerShape(13.dp)).padding(11.dp),
        content = content,
    )
}
