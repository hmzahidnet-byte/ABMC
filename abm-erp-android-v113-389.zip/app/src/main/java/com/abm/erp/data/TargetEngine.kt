package com.abm.erp.data

import java.time.LocalDate
import java.time.LocalDateTime

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * v113-380 — TARGET ENGINE (HRM ধাপ ২)
 *
 * আলোচনায় ঠিক হওয়া নিয়ম, হুবহু:
 *
 *   · চেয়ারম্যান **জাতীয় product-wise** টার্গেট বানান
 *     — product ধরে দিলে টাকার অঙ্ক আপনা থেকে হিসাব হয়
 *   · সেটাই **Wing 1-এর সবার** টার্গেট (MD, GM, AGM, NSM — সবার এক),
 *     কারণ তারা কেউ আলাদা এলাকা সামলায় না
 *   · Wing 2-তে নামে **হাতে ভাগ করে**, ফাঁকা পদ এড়িয়ে
 *   · **অ্যাপ কখনো নিজে ভাগ করবে না** — "সব জায়গায় sales তো সমান হয় না"
 *   · **১০০% বণ্টন না হলে distribute হবে না** — "কোনো গ্যাপ থাকতে পারবে না"
 *   · যাচাই **প্রতি product-এ আলাদা** — সিমেন্ট ১০০% কিন্তু রড ৮০% হলেও আটকাবে
 *   · Chairman সরাসরি নিচে দিলেও **চেইনের সবার খাতায় বসবে**, চিহ্ন সহ —
 *     নইলে যোগফল ভাঙত
 *
 * "কাকে দেওয়া যাবে" — সেই প্রশ্নের উত্তর এই engine নিজে দেয় না, **CascadeEngine
 * কে জিজ্ঞেস করে**। ফাঁকা পদ, চেইন, কে কার উপরে — সব ওখানে, এক জায়গায়।
 * ═════════════════════════════════════════════════════════════════════════════
 */
object TargetEngine {

    /** একটা product-এর জন্য একজনকে কত দেওয়া হলো। UI এটাই তৈরি করে পাঠায়। */
    data class Allocation(
        val employeeId: String,
        val productId: String,
        val value: Double,
    )

    /** একটা product-এর বণ্টনের অবস্থা — পর্দায় লাল/সবুজ দেখানোর জন্য। */
    data class ProductBalance(
        val productId: String,
        val productName: String,
        val parentValue: Double,
        val distributed: Double,
    ) {
        val remaining: Double get() = moneyRound(parentValue - distributed)
        val isComplete: Boolean get() = kotlin.math.abs(remaining) < 0.001
        val isOver: Boolean get() = remaining < -0.001
    }

    sealed class Result {
        data class Ok(val created: Int) : Result()
        data class Rejected(val reason: String) : Result()
    }

    // ─────────────────────────────────────────────────────────────────────────
    // যাচাই — distribute করার আগে
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * প্রতি product-এ কত বণ্টিত, কত বাকি।
     *
     * প্রতি product-এ **আলাদা** হিসাব — এটাই মূল কথা। মোট টাকার অঙ্ক মিলে
     * গেলেও product ধরে ভুল থাকতে পারে: সিমেন্ট ১২০%, রড ৮০% — যোগফল ঠিক,
     * বাস্তবে দুটোই ভুল।
     */
    fun balances(
        parentTargets: List<Target>,
        allocations: List<Allocation>,
        productName: (String) -> String,
    ): List<ProductBalance> = parentTargets
        .filter { it.productId != null }
        .map { parent ->
            val pid = parent.productId!!
            ProductBalance(
                productId = pid,
                productName = productName(pid),
                parentValue = parent.targetValue,
                distributed = moneyRound(allocations.filter { it.productId == pid }.sumOf { it.value }),
            )
        }

    /**
     * distribute করা যাবে কি না — একটা বাক্যে কারণসহ।
     *
     * UI বোতামটা ধূসর রাখতে এটাই ব্যবহার করবে, আর `distribute()` নিজেও আবার
     * যাচাই করে: পর্দা এড়িয়ে অন্য পথে ডাকলেও নিয়ম ভাঙা যাবে না।
     */
    fun validationError(balances: List<ProductBalance>): String? {
        if (balances.isEmpty()) return "কোনো product-wise টার্গেট নেই।"
        val over = balances.filter { it.isOver }
        if (over.isNotEmpty()) {
            return "বেশি বণ্টন হয়েছে — " + over.joinToString(", ") {
                "${it.productName} (+${fmt(-it.remaining)})"
            }
        }
        val gap = balances.filter { !it.isComplete }
        if (gap.isNotEmpty()) {
            return "১০০% বণ্টন হয়নি — " + gap.joinToString(", ") {
                "${it.productName} (বাকি ${fmt(it.remaining)})"
            }
        }
        return null
    }

    // ─────────────────────────────────────────────────────────────────────────
    // কাকে দেওয়া যাবে
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * এই ব্যক্তি তার টার্গেট কাদের মধ্যে ভাগ করবে।
     *
     * নিয়মটা CascadeEngine-এর: "DSM আছে → DSM পাবে; DSM নেই → সরাসরি RSM-রা;
     * RSM-ও নেই → ASM-রা"। ফাঁকা স্তর এড়িয়ে নিচে নামে, টার্গেট আটকে থাকে না।
     */
    fun recipientsFor(
        distributor: EmployeeProfile,
        date: LocalDate = LocalDate.now(),
        employees: List<EmployeeProfile> = MockRepository.employeeProfiles.value.filter { !it.isDeleted },
    ): List<EmployeeProfile> = CascadeEngine.distributionTargetsUnder(distributor, date, employees)

    // ─────────────────────────────────────────────────────────────────────────
    // জাতীয় টার্গেট — Chairman
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * চেয়ারম্যানের জাতীয় product-wise টার্গেট।
     *
     * Wing 1-এর সবার টার্গেট এটাই — তাদের জন্য আলাদা সারি বানানো হয় না,
     * কারণ তারা কেউ আলাদা এলাকা সামলায় না; আলাদা সারি বানালে একই সংখ্যা
     * পাঁচ জায়গায় থাকত আর একটা বদলালে বাকিগুলো পুরনো থেকে যেত।
     */
    fun nationalTargets(
        periodStart: LocalDate,
        periodEnd: LocalDate,
        all: List<Target> = MockRepository.targets.value,
    ): List<Target> = all.filter {
        it.scopeType == TargetScopeType.COMPANY &&
            it.status == "ACTIVE" &&
            it.productId != null &&
            it.periodStart == periodStart && it.periodEnd == periodEnd
    }

    /**
     * জাতীয় টার্গেট বসানো বা বদলানো। কেবল Chairman।
     *
     * পুরনো মান মুছে ফেলা হয় না — বদল হলে `TargetChangeLog`-এ সারি যোগ হয়,
     * কারণ "Target changes must never overwrite history" (মডেলের নিজের নিয়ম)
     * আর আপনার নিজের কথা: history থাকলে সব transparent এমনিতেই হয়।
     */
    fun setNationalTarget(
        productId: String,
        value: Double,
        periodStart: LocalDate,
        periodEnd: LocalDate,
        reason: String = "",
        onResult: (Result) -> Unit = {},
    ) {
        if (MockRepository.currentUser.role != UserRole.CHAIRMAN) {
            onResult(Result.Rejected("জাতীয় টার্গেট কেবল Chairman বসাতে পারেন।"))
            return
        }
        if (value <= 0.0) {
            onResult(Result.Rejected("টার্গেট শূন্য বা ঋণাত্মক হতে পারে না।"))
            return
        }
        MockRepository.upsertNationalTarget(productId, value, periodStart, periodEnd, reason, onResult)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // বণ্টন
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * টার্গেট নিচে নামানো।
     *
     * তিনটে জিনিস এখানে ইচ্ছাকৃত:
     *
     * ১. **যাচাই আবার করা হয়** — UI বোতাম ধূসর রাখলেও, নিয়ম UI-তে থাকে না।
     * ২. **আগের সন্তান-সারি মুছে তবেই নতুন বসে** — নইলে পুনরায় বণ্টনে পুরনো
     *    ও নতুন দুটোই থেকে যেত, আর যোগফল দ্বিগুণ দেখাত।
     * ৩. **একসাথে বসে** (`upsertAll`) — অর্ধেক বসে বাকিটা ব্যর্থ হলে যোগফল
     *    ভেঙে যেত, আর সেটা কেউ টের পেত না।
     */
    fun distribute(
        distributorId: String,
        parentTargets: List<Target>,
        allocations: List<Allocation>,
        productName: (String) -> String,
        onResult: (Result) -> Unit = {},
    ) {
        val employees = MockRepository.employeeProfiles.value.filter { !it.isDeleted }
        val distributor = employees.firstOrNull { it.id == distributorId }
        if (distributor == null) {
            onResult(Result.Rejected("বণ্টনকারী employee পাওয়া যায়নি।"))
            return
        }

        // কেবল নিজের অধীনস্থদের — CascadeEngine-এর সিদ্ধান্ত, এখানে নতুন নিয়ম নেই
        val allowed = recipientsFor(distributor, employees = employees).map { it.id }.toSet()
        val outsiders = allocations.map { it.employeeId }.distinct().filterNot { it in allowed }
        if (outsiders.isNotEmpty()) {
            val names = outsiders.mapNotNull { id -> employees.firstOrNull { it.id == id }?.fullName }
            onResult(Result.Rejected("এদের টার্গেট দেওয়ার অধিকার নেই: ${names.joinToString(", ").ifBlank { "অজানা" }}"))
            return
        }

        val negative = allocations.filter { it.value < 0.0 }
        if (negative.isNotEmpty()) {
            onResult(Result.Rejected("ঋণাত্মক টার্গেট দেওয়া যাবে না।"))
            return
        }

        validationError(balances(parentTargets, allocations, productName))?.let {
            onResult(Result.Rejected(it))
            return
        }

        MockRepository.saveTargetDistribution(distributor, parentTargets, allocations, onResult)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // পড়ার সুবিধা
    // ─────────────────────────────────────────────────────────────────────────

    /** এই ব্যক্তির product-wise টার্গেট, একটা সময়সীমায়। */
    fun targetsOf(
        employeeId: String,
        periodStart: LocalDate,
        periodEnd: LocalDate,
        all: List<Target> = MockRepository.targets.value,
    ): List<Target> = all.filter {
        it.scopeType == TargetScopeType.EMPLOYEE && it.scopeId == employeeId &&
            it.status == "ACTIVE" && it.periodStart == periodStart && it.periodEnd == periodEnd
    }

    /**
     * অর্জনের শতাংশ। টার্গেট শূন্য হলে ০ — শূন্য দিয়ে ভাগ করা যায় না, আর
     * "টার্গেট নেই তাই ১০০%" বলাটা মিথ্যা হতো।
     */
    fun achievementPct(t: Target): Double =
        if (t.targetValue <= 0.0) 0.0 else moneyRound(t.achievedValue / t.targetValue * 100.0)

    private fun fmt(v: Double): String =
        if (kotlin.math.abs(v % 1.0) < 0.001) "%,.0f".format(v) else "%,.2f".format(v)
}
