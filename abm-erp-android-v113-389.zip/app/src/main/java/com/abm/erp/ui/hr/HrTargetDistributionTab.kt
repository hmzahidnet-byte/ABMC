package com.abm.erp.ui.hr

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.CascadeEngine
import com.abm.erp.data.EmployeeProfile
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.MockRepository
import com.abm.erp.data.Target
import com.abm.erp.data.TargetEngine
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.DarazOrangeDark
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import java.time.LocalDate

/**
 * v113-380 — টার্গেট বণ্টনের পর্দা (HRM ধাপ ২)।
 *
 * ডিজাইনে এখানে **সংখ্যাই নায়ক, আইকন নয়** — ইচ্ছাকৃত। বাকি সব স্ক্রিন
 * আইকন-ভিত্তিক, কিন্তু "কত দিলাম, কত বাকি" আইকনে দেখানো যায় না, আর এই
 * পর্দার পুরো উদ্দেশ্যই ওই দুটো সংখ্যা।
 *
 * নিয়ম এখানে নেই — সব `TargetEngine`-এ। এই স্ক্রিন শুধু:
 *   · কাকে দেওয়া যাবে জিজ্ঞেস করে (CascadeEngine হয়ে, ফাঁকা পদ এড়িয়ে)
 *   · কত বাকি দেখায় (লাল/সবুজ)
 *   · ১০০% না হলে বোতাম ধূসর রাখে
 * বোতাম ধূসর রাখাটা সৌজন্য মাত্র — `TargetEngine.distribute()` নিজেও আবার
 * যাচাই করে, তাই অন্য পথে ডাকলেও নিয়ম ভাঙা যায় না।
 */
@Composable
fun HrTargetDistributionTab() {
    val employees by MockRepository.employeeProfiles.collectAsState()
    val allTargets by MockRepository.targets.collectAsState()
    val products by InventoryRepository.products.collectAsState()
    val me = MockRepository.currentUser

    val today = remember { LocalDate.now() }
    val periodStart = remember(today) { today.withDayOfMonth(1) }
    val periodEnd = remember(today) { today.withDayOfMonth(today.lengthOfMonth()) }

    val live = remember(employees) { employees.filter { !it.isDeleted } }
    val myProfile = remember(live, me) { live.firstOrNull { it.userAccountId == me.id || it.id == me.employeeId } }

    val parents = remember(allTargets, periodStart, periodEnd) {
        TargetEngine.nationalTargets(periodStart, periodEnd, allTargets)
    }
    val recipients = remember(myProfile, live) {
        myProfile?.let { TargetEngine.recipientsFor(it, today, live) } ?: emptyList()
    }
    val productName: (String) -> String = { pid ->
        products.firstOrNull { it.id == pid }?.name ?: pid
    }

    // key = "employeeId|productId"
    val alloc = remember { mutableStateMapOf<String, Double>() }
    var note by remember { mutableStateOf<String?>(null) }
    var noteOk by remember { mutableStateOf(false) }

    val allocations = remember(alloc.toMap()) {
        alloc.entries.mapNotNull { (k, v) ->
            val parts = k.split("|")
            if (parts.size != 2 || v <= 0.0) null
            else TargetEngine.Allocation(parts[0], parts[1], v)
        }
    }
    val balances = remember(parents, allocations) { TargetEngine.balances(parents, allocations, productName) }
    val error = remember(balances) { TargetEngine.validationError(balances) }
    val canDistribute = error == null && recipients.isNotEmpty() && myProfile != null

    Column(
        Modifier.fillMaxSize().background(com.abm.erp.theme.DashBg)
            .verticalScroll(rememberScrollState()).padding(12.dp),
    ) {
        // ── জাতীয় টার্গেট ──
        Section {
            RowHead("জাতীয় টার্গেট", "${periodStart.month.name.take(3)} ${periodStart.year}")
            if (parents.isEmpty()) {
                Text(
                    "এই মাসের জাতীয় টার্গেট এখনো বসানো হয়নি। Chairman drawer থেকে product ধরে ধরে বসাতে হবে।",
                    fontSize = 11.sp, color = DangerRed, lineHeight = 16.sp,
                )
            }
            parents.forEach { p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(productName(p.productId ?: ""), Modifier.weight(1f), fontSize = 11.5.sp, color = TextPrimary)
                    Text(num(p.targetValue), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        // ── কাকে দেওয়া হবে ──
        if (myProfile == null) {
            Section { Text("আপনার employee প্রোফাইল পাওয়া যায়নি — টার্গেট বণ্টন করা যাবে না।", fontSize = 11.sp, color = DangerRed) }
        } else if (recipients.isEmpty()) {
            Section {
                Text("আপনার অধীনে কোনো সক্রিয় employee নেই — বণ্টনের কেউ নেই।", fontSize = 11.sp, color = DangerRed, lineHeight = 16.sp)
            }
        } else {
            parents.forEach { parent ->
                val pid = parent.productId ?: return@forEach
                Section {
                    RowHead(productName(pid), "মোট ${num(parent.targetValue)}")
                    recipients.forEach { r ->
                        AllocationRow(
                            employee = r,
                            value = alloc["${r.id}|$pid"] ?: 0.0,
                            onChange = { v -> alloc["${r.id}|$pid"] = v.coerceAtLeast(0.0) },
                        )
                    }
                    val b = balances.firstOrNull { it.productId == pid }
                    if (b != null) BalanceBar(b)
                }
                Spacer(Modifier.height(10.dp))
            }
        }

        // ── ফল ও বোতাম ──
        note?.let {
            Text(
                it, fontSize = 11.sp, lineHeight = 16.sp,
                color = if (noteOk) SuccessGreen else DangerRed,
                modifier = Modifier.padding(bottom = 8.dp),
            )
        }
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(11.dp))
                .background(if (canDistribute) DarazOrange else Color(0xFFCBD5E1))
                .clickable(enabled = canDistribute) {
                    val p = myProfile ?: return@clickable
                    // v113-380 — onResult নাম দিয়ে দেওয়া, trailing lambda দিয়ে নয়।
                    // distribute-এর শেষ দুটো param-ই lambda (productName non-default,
                    // onResult default), আর trailing-lambda ওখানে পড়তে গিয়ে ভুল
                    // বোঝায় — checker #9 ঠিক এই প্যাটার্নটাই ধরে।
                    TargetEngine.distribute(
                        distributorId = p.id,
                        parentTargets = parents,
                        allocations = allocations,
                        productName = productName,
                        onResult = { res ->
                        when (res) {
                            is TargetEngine.Result.Ok -> {
                                noteOk = true
                                note = "✔ বণ্টন সম্পন্ন — ${res.created} সারি সংরক্ষিত।"
                            }
                            is TargetEngine.Result.Rejected -> {
                                noteOk = false
                                note = "✖ ${res.reason}"
                            }
                        }
                        },
                    )
                }
                .padding(vertical = 11.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                if (canDistribute) "Distribute করুন" else (error ?: "বণ্টনের কেউ নেই"),
                fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White,
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "প্রতিটা product-এ আলাদা যাচাই — একটার মোট মিলে গিয়ে আরেকটায় ঘাটতি থাকলেও আটকাবে। " +
                "অ্যাপ নিজে ভাগ করে না, কারণ সব এলাকার বিক্রি সমান নয়।",
            fontSize = 10.sp, color = TextSecondary, lineHeight = 15.sp,
        )
        Spacer(Modifier.height(24.dp))
    }
}

/* ── একজনের জন্য এক product-এর ঘর ─────────────────────────────────────── */

@Composable
private fun AllocationRow(employee: EmployeeProfile, value: Double, onChange: (Double) -> Unit) {
    val step = 100.0
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(employee.fullName, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
            Text(
                "${employee.role.name} · ${CascadeEngine.geoKeyOf(employee) ?: "এলাকা বসানো হয়নি"}",
                fontSize = 9.5.sp, color = TextSecondary, maxLines = 1,
            )
        }
        StepButton(Icons.Filled.Remove, "কমান") { onChange(value - step) }
        Text(
            num(value),
            Modifier.width(56.dp), fontSize = 14.sp, fontWeight = FontWeight.Bold,
            color = if (value > 0) TextPrimary else TextSecondary,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        StepButton(Icons.Filled.Add, "বাড়ান", filled = true) { onChange(value + step) }
    }
}

@Composable
private fun StepButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String,
    filled: Boolean = false,
    onClick: () -> Unit,
) {
    Box(
        Modifier.size(28.dp).clip(RoundedCornerShape(14.dp))
            .background(if (filled) DarazOrange else Color.White)
            .border(1.dp, if (filled) DarazOrange else com.abm.erp.theme.HairlineBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = desc, tint = if (filled) Color.White else TextSecondary, modifier = Modifier.size(15.dp))
    }
}

/* ── কত বাকি — লাল/সবুজ ───────────────────────────────────────────────── */

@Composable
private fun BalanceBar(b: TargetEngine.ProductBalance) {
    val ok = b.isComplete
    val tint = if (ok) SuccessGreen else DangerRed
    Column(
        Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(10.dp))
            .background(if (ok) Color(0xFFE8F7F0) else Color(0xFFFDECEA))
            .border(1.5.dp, tint, RoundedCornerShape(10.dp))
            .padding(10.dp),
    ) {
        Row(Modifier.fillMaxWidth()) {
            Text("বণ্টিত", Modifier.weight(1f), fontSize = 11.sp, color = TextPrimary)
            Text(num(b.distributed), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        }
        Spacer(Modifier.height(2.dp))
        Row(Modifier.fillMaxWidth()) {
            Text(
                if (ok) "✔ সম্পূর্ণ বণ্টিত" else if (b.isOver) "বেশি হয়ে গেছে" else "বাকি (গ্যাপ)",
                Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = tint,
            )
            Text(
                if (ok) "0" else num(kotlin.math.abs(b.remaining)),
                fontSize = 14.sp, fontWeight = FontWeight.Bold, color = tint,
            )
        }
    }
}

/* ── ছোট সহায়ক ─────────────────────────────────────────────────────────── */

@Composable
private fun Section(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color.White)
            .border(1.dp, com.abm.erp.theme.HairlineBorder, RoundedCornerShape(13.dp)).padding(11.dp),
        content = content,
    )
}

@Composable
private fun RowHead(title: String, badge: String) {
    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Text(badge, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DarazOrangeDark)
    }
}

/** পূর্ণসংখ্যা হলে দশমিক দেখানো হয় না — "৪০০.০০ বস্তা" ভুল পড়ায়। */
private fun num(v: Double): String =
    if (kotlin.math.abs(v % 1.0) < 0.001) "%,.0f".format(v) else "%,.2f".format(v)
