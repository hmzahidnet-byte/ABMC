package com.abm.erp.ui.scanner

import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.abm.erp.data.CodeRegistry
import com.abm.erp.data.resolveRegistered
import com.abm.erp.data.MockRepository
import com.abm.erp.data.rejectCollection
import com.abm.erp.data.verifyCollection
import com.abm.erp.theme.*
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

/**
 * Universal QR Scanner — ONE scan button, ONE central resolver, real
 * detail for all 6 required types. Previously scanning lived only inside
 * DealersScreen (Dealer/Retailer only, Employee/Carton just showed a
 * toast telling the person to go look elsewhere, Production Batch and
 * Warehouse/Delivery weren't recognized as types at all).
 */
@Composable
fun UniversalScannerScreen(onNavigate: (String) -> Unit = {}, onBack: () -> Unit = {}) {
    val context = LocalContext.current
    var resolved by remember { mutableStateOf<CodeRegistry.ResolveResult?>(null) }
    var lastScannedRaw by remember { mutableStateOf("") }

    var secureDenial by remember { mutableStateOf<String?>(null) }
    var offlineVerified by remember { mutableStateOf(false) }
    val scanScope = androidx.compose.runtime.rememberCoroutineScope()

    // v113-138 — QR is a universal action, so tapping the QR button anywhere should
    // open the camera itself, not a landing page with another button on it. The
    // camera now launches automatically on first entry; the screen underneath stays
    // as the RESULT view (and lets the person re-scan without going back out).
    var autoLaunched by rememberSaveable { mutableStateOf(false) }
    val scanLauncher = androidx.activity.compose.rememberLauncherForActivityResult(ScanContract()) { result ->
        // v113-319 — the person's own instruction: "ওইটা ক্লিক করলে
        // ক্যামেরা আসবে, ব্যাকে দিলে আবার ব্যাকে চলে আসবে। আবার মাঝখানে
        // আর কোনো অপশন থাকবে না।"
        //
        // The camera already auto-opened on entry (v113-138), but
        // cancelling it just returned here — a landing page whose only
        // real content was another "📷 আবার স্ক্যান করুন" button. So
        // backing out of the camera left the person stranded on exactly
        // the intermediate screen they're describing. Cancelling now
        // leaves the scanner entirely, but ONLY when nothing has been
        // scanned yet: after a successful scan this same screen is the
        // real result view, and closing that automatically would throw
        // away what they just scanned.
        val code = result?.contents
        if (code == null) {
            if (resolved == null && secureDenial == null) onBack()
            return@rememberLauncherForActivityResult
        }
        lastScannedRaw = code
        secureDenial = null
        offlineVerified = false

        if (com.abm.erp.data.QrRegistry.isSecurePayload(code)) {
            // Secure path: the payload is one of ours, so it must pass full registry
            // validation — company isolation, token, status, expiry, permission. A
            // failure here never falls through to the legacy matcher; that would
            // defeat the point of revocation.
            resolved = null
            scanScope.launch {
                val online = com.abm.erp.util.NetworkStatus.isOnline(context)
                when (val res = com.abm.erp.data.QrRegistry.resolve(code, online)) {
                    is com.abm.erp.data.QrRegistry.Resolution.Allowed -> {
                        offlineVerified = res.offlineVerified
                        resolved = CodeRegistry.resolveRegistered(res.entityType, res.entityId)
                    }
                    is com.abm.erp.data.QrRegistry.Resolution.Denied -> {
                        secureDenial = res.reason
                    }
                }
            }
        } else {
            // Legacy path: a code printed before the secure registry existed, or a
            // supplier's own barcode. Still resolved so old tags keep working, but it
            // is labelled as unverified in the UI rather than presented as trusted.
            resolved = CodeRegistry.resolve(code)
            val r = resolved
            if (r is CodeRegistry.ResolveResult.Found) {
                MockRepository.logAudit(r.type.name, r.id, "QR_SCANNED_LEGACY", reason = "Unregistered code scanned by ${MockRepository.currentUser.name}")
            }
        }
    }

    LaunchedEffect(Unit) {
        if (!autoLaunched) { autoLaunched = true; scanLauncher.launch(abmScanOptions()) }
    }

    // v113-229 — the person's own explicit, direct complaint: scanning
    // Dealer/Retailer/Employee/Product used to always show a small,
    // bespoke "card" (a few lines of text and 2-3 buttons) instead of the
    // same rich, consistent design every List screen's own detail view
    // already has (Info, Ledger, 90-Day, Graph, Calendar, QR, extraTabs).
    // Those four types already have real BrowseConfigs built and proven
    // elsewhere (Dealer/Retailer/Employee/Product List) — reused directly
    // here via the same generic ModuleBrowseDetail, rather than building
    // a second, different-looking view of the same data. When one of
    // these resolves successfully, it now takes over the full screen,
    // exactly like tapping into that same record from its own List would.
    val r = if (secureDenial != null) null else resolved
    if (r is CodeRegistry.ResolveResult.Found && r.type in setOf(CodeRegistry.CodeType.DEALER, CodeRegistry.CodeType.RETAILER, CodeRegistry.CodeType.EMPLOYEE, CodeRegistry.CodeType.PRODUCT, CodeRegistry.CodeType.CARTON)) {
        RichScanDetailScreen(r, onNavigate) { resolved = null }
        return
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Universal QR Scanner", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(6.dp))
        Text("Employee, Retailer, Dealer, Product/Carton, Production Batch, Warehouse/Delivery, Invoice, Collection — সব এক জায়গা থেকে স্ক্যান করুন।", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { scanLauncher.launch(abmScanOptions()) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("📷 আরেকটা স্ক্যান করুন") }
        Spacer(Modifier.height(16.dp))

        Column(Modifier.weight(1f).imePadding().verticalScroll(rememberScrollState())) {
            // A secure-registry denial takes precedence over everything: the record is not
            // shown, only the reason. Blueprint/Part 2 — never open a record because a
            // visible id happened to match.
            secureDenial?.let { reason ->
                com.abm.erp.core.WorkspaceErrorState(reason) { secureDenial = null }
            }
            if (offlineVerified && secureDenial == null && resolved != null) {
                Text(
                    "⚠ অফলাইন যাচাই — এই ডিভাইসে সংরক্ষিত তথ্য দিয়ে মিলানো হয়েছে; সার্ভারে বাতিল হয়েছে কিনা এখন নিশ্চিত করা যায়নি।",
                    color = com.abm.erp.theme.StatusAmber,
                    style = MaterialTheme.typography.labelSmall,
                )
                Spacer(Modifier.height(8.dp))
            }
            when (val r = if (secureDenial != null) null else resolved) {
                null -> if (secureDenial == null) Text("স্ক্যান করার জন্য উপরের বাটনে চাপুন।", color = TextSecondary)
                is CodeRegistry.ResolveResult.Invalid -> Text("অবৈধ কোড।", color = DangerRed)
                is CodeRegistry.ResolveResult.NotFound -> Text("কোনো মিলে যাওয়া রেকর্ড পাওয়া যায়নি: $lastScannedRaw", color = DangerRed)
                is CodeRegistry.ResolveResult.Ambiguous -> {
                    Text("⚠ এই কোড একাধিক রেকর্ডের সাথে মিলছে — ডেটা সমস্যা, Chairman-কে জানান।", color = DangerRed, fontWeight = FontWeight.Bold)
                    r.matches.forEach { (type, id) -> Text("• $type — $id", color = TextSecondary) }
                }
                is CodeRegistry.ResolveResult.Found -> ScanResultCard(r, onNavigate)
            }
        }
    }
}

@Composable
private fun RichScanDetailScreen(result: CodeRegistry.ResolveResult.Found, onNavigate: (String) -> Unit, onBack: () -> Unit) {
    val currentUser = MockRepository.currentUser
    // Same territory/permission validation ScanResultCard's own dealer/
    // retailer/employee branches already did — kept identical, just
    // scoped to these four types since the other types still go through
    // ScanResultCard's own full check.
    val (allowed, denyReason) = remember(result.id, result.type) {
        when (result.type) {
            CodeRegistry.CodeType.DEALER ->
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("dealer", com.abm.erp.data.PermissionAction.VIEW)) false to "Dealer তথ্য দেখার অনুমতি নেই।"
                else if (result.id !in MockRepository.visibleDealerIds(currentUser.employeeId)) false to "এই Dealer আপনার এলাকার বাইরে — অ্যাক্সেস নেই।"
                else true to null
            CodeRegistry.CodeType.RETAILER ->
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("dealer", com.abm.erp.data.PermissionAction.VIEW)) false to "Retailer তথ্য দেখার অনুমতি নেই।"
                else if (result.id !in MockRepository.visibleRetailerIds(currentUser.employeeId)) false to "এই Retailer আপনার এলাকার বাইরে — অ্যাক্সেস নেই।"
                else true to null
            CodeRegistry.CodeType.EMPLOYEE ->
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("hr", com.abm.erp.data.PermissionAction.VIEW)) false to "Employee তথ্য দেখার অনুমতি নেই।"
                else if (result.id !in MockRepository.visibleEmployeeIds(currentUser.employeeId)) false to "এই Employee আপনার hierarchy-র বাইরে — অ্যাক্সেস নেই।"
                else true to null
            CodeRegistry.CodeType.PRODUCT ->
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("inv", com.abm.erp.data.PermissionAction.VIEW)) false to "Product তথ্য দেখার অনুমতি নেই।"
                else true to null
            else -> true to null
        }
    }
    if (!allowed) {
        MockRepository.logAudit(result.type.name, result.id, "SCAN_ACCESS_DENIED", reason = denyReason)
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            com.abm.erp.core.WorkspaceErrorState(denyReason ?: "অ্যাক্সেস নেই।", onBack)
        }
        return
    }

    when (result.type) {
        CodeRegistry.CodeType.DEALER -> {
            val dealers by MockRepository.dealers.collectAsState()
            val dealer = dealers.firstOrNull { it.id == result.id }
            if (dealer == null) { com.abm.erp.core.WorkspaceErrorState("এই Dealer আর নেই — মুছে ফেলা হয়ে থাকতে পারে।", onBack); return }
            val zones = remember(dealers) { dealers.map { it.zone }.filter { it.isNotBlank() }.distinct().sorted() }
            com.abm.erp.core.ModuleBrowseDetail(com.abm.erp.core.rememberDealerBrowseConfig(zones), dealer, onBack, onNavigate)
        }
        CodeRegistry.CodeType.RETAILER -> {
            val retailers by MockRepository.retailers.collectAsState()
            val retailer = retailers.firstOrNull { it.id == result.id }
            if (retailer == null) { com.abm.erp.core.WorkspaceErrorState("এই Retailer আর নেই — মুছে ফেলা হয়ে থাকতে পারে।", onBack); return }
            val markets = remember(retailers) { retailers.map { it.market }.filter { it.isNotBlank() }.distinct().sorted() }
            com.abm.erp.core.ModuleBrowseDetail(com.abm.erp.core.rememberRetailerBrowseConfig(markets), retailer, onBack, onNavigate)
        }
        CodeRegistry.CodeType.EMPLOYEE -> {
            val profiles by MockRepository.employeeProfiles.collectAsState()
            val emp = profiles.firstOrNull { it.id == result.id }
            if (emp == null) { com.abm.erp.core.WorkspaceErrorState("এই Employee আর নেই — মুছে ফেলা হয়ে থাকতে পারে।", onBack); return }
            val departments = remember(profiles) { profiles.map { it.department }.filter { it.isNotBlank() }.distinct().sorted() }
            com.abm.erp.core.ModuleBrowseDetail(com.abm.erp.core.rememberEmployeeBrowseConfig(departments), emp, onBack, onNavigate)
        }
        CodeRegistry.CodeType.PRODUCT -> {
            val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
            val product = products.firstOrNull { it.id == result.id }
            if (product == null) { com.abm.erp.core.WorkspaceErrorState("এই Product আর নেই — মুছে ফেলা হয়ে থাকতে পারে।", onBack); return }
            val categories = remember(products) { products.map { it.category }.filter { it.isNotBlank() }.distinct().sorted() }
            com.abm.erp.core.ModuleBrowseDetail(com.abm.erp.core.rememberProductBrowseConfig(categories), product, onBack, onNavigate)
        }
        CodeRegistry.CodeType.CARTON -> CartonScanDetail(result.id, result.extra, onBack)
        else -> {}
    }
}

@Composable
private fun ScanResultCard(result: CodeRegistry.ResolveResult.Found, onNavigate: (String) -> Unit) {
    val currentUser = MockRepository.currentUser
    // Real territory + permission validation — was completely missing
    // before: any resolved code's details were shown regardless of
    // whether this employee was even authorized to view that module, or
    // whether the specific record was inside their assigned territory.
    val (allowed, denyReason) = remember(result.id, result.type) {
        when (result.type) {
            CodeRegistry.CodeType.DEALER -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("dealer", com.abm.erp.data.PermissionAction.VIEW)) false to "Dealer তথ্য দেখার অনুমতি নেই।"
                else if (result.id !in MockRepository.visibleDealerIds(currentUser.employeeId)) false to "এই Dealer আপনার এলাকার বাইরে — অ্যাক্সেস নেই।"
                else true to null
            }
            CodeRegistry.CodeType.RETAILER -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("dealer", com.abm.erp.data.PermissionAction.VIEW)) false to "Retailer তথ্য দেখার অনুমতি নেই।"
                else if (result.id !in MockRepository.visibleRetailerIds(currentUser.employeeId)) false to "এই Retailer আপনার এলাকার বাইরে — অ্যাক্সেস নেই।"
                else true to null
            }
            CodeRegistry.CodeType.EMPLOYEE -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("hr", com.abm.erp.data.PermissionAction.VIEW)) false to "Employee তথ্য দেখার অনুমতি নেই।"
                else if (result.id !in MockRepository.visibleEmployeeIds(currentUser.employeeId)) false to "এই Employee আপনার hierarchy-র বাইরে — অ্যাক্সেস নেই।"
                else true to null
            }
            CodeRegistry.CodeType.CARTON, CodeRegistry.CodeType.PRODUCTION_BATCH -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("prod", com.abm.erp.data.PermissionAction.VIEW)) false to "Production তথ্য দেখার অনুমতি নেই।"
                else true to null
            }
            CodeRegistry.CodeType.WAREHOUSE_TRANSFER -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("stock", com.abm.erp.data.PermissionAction.VIEW)) false to "Warehouse তথ্য দেখার অনুমতি নেই।"
                else true to null
            }
            CodeRegistry.CodeType.INVOICE, CodeRegistry.CodeType.COLLECTION -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("bill", com.abm.erp.data.PermissionAction.VIEW)) false to "এই তথ্য দেখার অনুমতি নেই।"
                else true to null
            }
            CodeRegistry.CodeType.PRODUCT -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("inv", com.abm.erp.data.PermissionAction.VIEW)) false to "Product তথ্য দেখার অনুমতি নেই।"
                else true to null
            }
            CodeRegistry.CodeType.DELIVERY -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("stock", com.abm.erp.data.PermissionAction.VIEW)) false to "Delivery তথ্য দেখার অনুমতি নেই।"
                else true to null
            }
            CodeRegistry.CodeType.UNKNOWN -> true to null
        }
    }
    if (!allowed) {
        MockRepository.logAudit(result.type.name, result.id, "SCAN_ACCESS_DENIED", reason = denyReason)
        Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
            Text(denyReason ?: "অ্যাক্সেস নেই।", color = DangerRed, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
        }
        return
    }
    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            when (result.type) {
                CodeRegistry.CodeType.EMPLOYEE -> EmployeeScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.RETAILER -> RetailerScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.DEALER -> DealerScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.CARTON -> {} // v113-230 — now handled by RichScanDetailScreen before this card is ever reached; CartonScanDetail's signature changed to a full-screen one (needs onBack), which this small embedded card doesn't have.
                CodeRegistry.CodeType.PRODUCTION_BATCH -> ProductionBatchScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.WAREHOUSE_TRANSFER -> WarehouseTransferScanDetail(result.id)
                CodeRegistry.CodeType.INVOICE -> InvoiceScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.COLLECTION -> CollectionScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.PRODUCT -> ProductScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.DELIVERY -> DeliveryScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.UNKNOWN -> Text("অজানা কোড টাইপ।", color = TextSecondary)
            }
        }
    }
}

@Composable
private fun EmployeeScanDetail(employeeId: String, onNavigate: (String) -> Unit) {
    val profiles by MockRepository.employeeProfiles.collectAsState()
    val emp = profiles.firstOrNull { it.id == employeeId }
    var attendanceSummary by remember(employeeId) { mutableStateOf<Pair<Int, Int>?>(null) } // present, absent
    LaunchedEffect(employeeId) { attendanceSummary = MockRepository.attendanceSummary(employeeId) }
    Text("👤 Employee", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(emp?.fullName ?: employeeId, style = MaterialTheme.typography.titleMedium)
    Text("${emp?.designation ?: ""} — ${emp?.department ?: ""}", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
    Text("Employee Code: ${emp?.employeeCode ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    attendanceSummary?.let { (present, absent) ->
        Text("Attendance: $present দিন উপস্থিত, $absent দিন অনুপস্থিত", style = MaterialTheme.typography.bodySmall)
    } ?: com.abm.erp.core.WorkspaceLoadingState("Attendance লোড হচ্ছে…")
    Spacer(Modifier.height(8.dp))
    Text("Connected workflow", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TextButton(onClick = { onNavigate("hrm") }) { Text("Attendance") }
        TextButton(onClick = { onNavigate("hrm") }) { Text("Payroll") }
        TextButton(onClick = { onNavigate("enterprise_audit_center") }) { Text("Activity") }
    }
}

@Composable
private fun RetailerScanDetail(retailerId: String, onNavigate: (String) -> Unit) {
    val retailers by MockRepository.retailers.collectAsState()
    val orders by MockRepository.orders.collectAsState()
    val retailer = retailers.firstOrNull { it.id == retailerId }
    val latestOrder = orders.filter { it.retailerId == retailerId }.maxByOrNull { it.loggedAt }
    Text("🏪 Retailer", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(retailer?.name ?: retailerId, style = MaterialTheme.typography.titleMedium)
    Text("Code: ${retailer?.retailerCode ?: "—"} — Due: ৳${"%,.0f".format(retailer?.dueBalance ?: 0.0)}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    if (latestOrder != null) {
        Text("সর্বশেষ অর্ডার: ${latestOrder.orderNo} — ৳${"%,.0f".format(latestOrder.amount)} (${latestOrder.stage})", style = MaterialTheme.typography.bodySmall)
    } else {
        Text("কোনো সাম্প্রতিক অর্ডার পাওয়া যায়নি।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
    }
    Spacer(Modifier.height(8.dp))
    Text("Connected workflow", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TextButton(onClick = { onNavigate("sales") }) { Text("Order/Invoice") }
        TextButton(onClick = { onNavigate("dealers") }) { Text("Collection") }
        TextButton(onClick = { onNavigate("statement/RETAILER/$retailerId") }) { Text("Statement") }
    }
    // v113-316 — same as the Dealer scan view: the retailer's own real
    // full profile (rich_retailer_detail → Transactions, Login PIN,
    // Actions, plus Ledger/90-Day/Graph/Calendar) was never reachable
    // from a scan.
    Spacer(Modifier.height(10.dp))
    Button(
        onClick = { onNavigate("rich_retailer_detail/$retailerId") },
        modifier = Modifier.fillMaxWidth(),
    ) { Text("পুরো প্রোফাইল — History, Ledger, Graph") }
}

@Composable
private fun DealerScanDetail(dealerId: String, onNavigate: (String) -> Unit) {
    val dealers by MockRepository.dealers.collectAsState()
    val dealer = dealers.firstOrNull { it.id == dealerId }
    val ledger by remember(dealerId) { MockRepository.partyLedgerFor(com.abm.erp.data.PartyType.DEALER, dealerId) }.collectAsState(initial = emptyList())
    val latestLedgerEntries = ledger.sortedByDescending { it.createdAt }.take(5)
    Text("🏢 Dealer Dashboard", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(dealer?.name ?: dealerId, style = MaterialTheme.typography.titleMedium)
    Text("Code: ${dealer?.dealerCode ?: "—"} — Due: ৳${"%,.0f".format(dealer?.dueBalance ?: 0.0)}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Text("সর্বশেষ লেজার এন্ট্রি:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    if (latestLedgerEntries.isEmpty()) Text("কোনো এন্ট্রি নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
    latestLedgerEntries.forEach { Text("• ${it.type} ৳${"%,.0f".format(it.amount)} — ${it.reason}", style = MaterialTheme.typography.bodySmall) }
    Spacer(Modifier.height(8.dp))
    Text("Connected workflow", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TextButton(onClick = { onNavigate("sales") }) { Text("Invoice") }
        TextButton(onClick = { onNavigate("dealers") }) { Text("Collection") }
        // Opens THIS dealer's statement, not the generic ledger module.
        TextButton(onClick = { onNavigate("statement/DEALER/$dealerId") }) { Text("Statement") }
    }
    // v113-316 — the person's own description of what scanning should do:
    // "ওই কিউআর কোডে সার্চ দিলে ওনার টোটাল হিস্টোরি, ওনার লিস্ট বের হয়ে
    // যাবে, ওনার টোটাল গ্রাফ-ট্রাফ যা আছে এইরকম।" The scan view showed a
    // summary (name, code, due, last 5 ledger lines) and links that only
    // opened OTHER modules — never this dealer's own full profile. The
    // real full view already exists (`rich_dealer_detail/{id}` →
    // ModuleBrowseDetail: Transactions, Stock, Contact, Complaint, Sales
    // Report, plus Ledger / 90-Day / Graph / Calendar). It simply wasn't
    // reachable from a scan. Wired here as the primary action.
    Spacer(Modifier.height(10.dp))
    Button(
        onClick = { onNavigate("rich_dealer_detail/$dealerId") },
        modifier = Modifier.fillMaxWidth(),
    ) { Text("পুরো প্রোফাইল — History, Ledger, Graph") }
}

@Composable
private fun CartonScanDetail(cartonId: String, cartonCode: String?, onBack: () -> Unit) {
    // v113-230 — visual upgrade to match the person's own explicit request:
    // the same polished style as Dealer/Employee/Product's own detail view
    // (branded gradient header, clean white card body, QR), even though
    // Carton's own DATA is genuinely different (a physical tracking
    // journey — packed/warehouse/dispatch/delivered — not a money-bearing
    // party's history), so it isn't a ModuleBrowseDetail/BrowseConfig
    // underneath (Ledger/Graph/90-Day genuinely have nothing to show for
    // a carton) — same visual language, honest about having different
    // content. Full journey shown (whichever stages actually happened),
    // plus exactly one contextual action for wherever it is right now —
    // unchanged from the real, working v113-216 logic, just re-presented.
    val cartons by MockRepository.cartons.collectAsState()
    val carton = cartons.firstOrNull { it.id == cartonId }
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var success by remember { mutableStateOf(false) }
    var showQr by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(DashBg)) {
        com.abm.erp.core.BrowseTopBar("Carton Details", carton?.cartonCode ?: cartonCode, 0xFFE85D4A, 0xFFC03A2B, onBack)
        if (carton == null) {
            Column(Modifier.padding(16.dp)) {
                Text(cartonCode ?: cartonId, style = MaterialTheme.typography.titleMedium)
                Text("এই Carton খুঁজে পাওয়া যায়নি — এটা কি একটা পুরনো/manual code, real QR না?", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            return
        }
        Column(Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState()).background(Color.White).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(8.dp)).background(DashBg)
                        .clickable { showQr = true },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.QrCode2, "QR", tint = TextPrimary, modifier = Modifier.size(26.dp)) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(carton.cartonCode, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("${carton.productName} · ${"%,.1f".format(carton.quantityInside)} ${carton.unit}", fontSize = 11.sp, color = TextSecondary)
                }
                val statusColor = when (carton.status) {
                    "DELIVERED" -> SuccessGreen
                    "DISPATCHED" -> WarningAmber
                    "WAREHOUSE_RECEIVED" -> com.abm.erp.theme.StatusBlue
                    else -> TextSecondary
                }
                Text(carton.status, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = statusColor)
            }
            Spacer(Modifier.height(12.dp)); Divider(); Spacer(Modifier.height(10.dp))

            Surface(tonalElevation = 2.dp, shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Basic Information", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    listOf(
                        "Carton Code" to carton.cartonCode,
                        "Product" to carton.productName,
                        "Quantity" to "${"%,.1f".format(carton.quantityInside)} ${carton.unit}",
                        "Batch" to (carton.batchCode ?: "এখনো নির্ধারিত হয়নি (QC pending)"),
                        "Status" to carton.status,
                    ).forEach { (label, value) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(label, fontSize = 12.sp, color = TextSecondary)
                            Text(value, fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Medium, maxLines = 1)
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Surface(tonalElevation = 2.dp, shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("যাত্রা (Journey)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    Text("📦 Packed — ${carton.packedBy}, ${carton.packedAt.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    carton.warehouseReceivedAt?.let { Text("🏭 Warehouse — ${carton.warehouseReceivedBy}, ${it.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                    carton.dispatchedAt?.let { Text("🚚 Dispatched → ${carton.dispatchedTo} — ${carton.dispatchedBy}, ${it.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                    carton.deliveredAt?.let { Text("✅ Delivered — ${carton.deliveredBy}, ${it.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                }
            }
            error?.let { Spacer(Modifier.height(10.dp)); Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
            if (success) { Spacer(Modifier.height(10.dp)); Text("✓ Updated হয়েছে।", color = SuccessGreen, style = MaterialTheme.typography.labelSmall) }
            Spacer(Modifier.height(14.dp))

            when (carton.status) {
                "PACKED" -> {
                    val warehouses by com.abm.erp.data.InventoryRepository.warehouses.collectAsState()
                    var expanded by remember { mutableStateOf(false) }
                    var selectedWarehouseId by remember { mutableStateOf<String?>(null) }
                    val selectedWarehouse = warehouses.firstOrNull { it.id == selectedWarehouseId }
                    Box {
                        OutlinedButton(onClick = { expanded = true }) { Text(selectedWarehouse?.name ?: "Warehouse বেছে নিন") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            warehouses.forEach { w -> DropdownMenuItem(text = { Text(w.name) }, onClick = { selectedWarehouseId = w.id; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Button(
                        enabled = !busy && selectedWarehouseId != null,
                        onClick = {
                            busy = true; error = null; success = false
                            scope.launch {
                                val ok = MockRepository.receiveCartonAtWarehouse(carton.id, selectedWarehouseId!!, onRejected = { e -> error = e })
                                busy = false; success = ok
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("✓ Warehouse Receive") }
                }
                "WAREHOUSE_RECEIVED" -> {
                    var dispatchedTo by remember { mutableStateOf("") }
                    OutlinedTextField(value = dispatchedTo, onValueChange = { dispatchedTo = it }, label = { Text("কোথায় পাঠানো হচ্ছে (dealer/route/vehicle)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Button(
                        enabled = !busy && dispatchedTo.isNotBlank(),
                        onClick = {
                            busy = true; error = null; success = false
                            scope.launch {
                                val ok = MockRepository.dispatchCarton(carton.id, dispatchedTo, onRejected = { e -> error = e })
                                busy = false; success = ok
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("🚚 Dispatch") }
                }
                "DISPATCHED" -> {
                    Button(
                        enabled = !busy,
                        onClick = {
                            busy = true; error = null; success = false
                            scope.launch {
                                val ok = MockRepository.deliverCarton(carton.id, onRejected = { e -> error = e })
                                busy = false; success = ok
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("✓ Mark Delivered") }
                }
                "DELIVERED" -> Text("এই carton-এর যাত্রা সম্পূর্ণ — manufacturing → warehouse → dispatch → delivery।", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
            }
        }
    }
    if (showQr) {
        // v113-245 build fix — the compiler doesn't carry the earlier
        // `if (carton == null) return` smart-cast this far down reliably
        // in this exact shape, so it correctly flags carton as still
        // nullable here. Using ?.let is the safe, idiomatic fix rather
        // than a !! assertion — behaves identically in practice (carton
        // is guaranteed non-null by this point) but never crashes even
        // if that guarantee were ever violated.
        carton?.let { c ->
            com.abm.erp.core.RecordQrDialog(code = c.cartonCode, title = c.cartonCode, subtitle = c.productName, onDismiss = { showQr = false })
        }
    }
}

@Composable
private fun ProductionBatchScanDetail(planId: String, onNavigate: (String) -> Unit) {
    val plans by MockRepository.productionPlans.collectAsState()
    val qc by MockRepository.qualityInspections.collectAsState()
    val plan = plans.firstOrNull { it.id == planId }
    val qcRecords = qc.filter { it.productionPlanId == planId }
    Text("🏭 Production Batch", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(plan?.batchNumber ?: planId, style = MaterialTheme.typography.titleMedium)
    Text("Product: ${plan?.productId ?: "—"} — Planned: ${plan?.plannedQuantity ?: 0.0} ${plan?.unit ?: ""}", style = MaterialTheme.typography.bodySmall)
    Text("Status: ${plan?.status ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Text("QC Inspections: ${qcRecords.size}টি", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    qcRecords.take(3).forEach { Text("• ${it.result}${it.testParameters?.let { p -> " — $p" } ?: ""}", style = MaterialTheme.typography.bodySmall) }
    Spacer(Modifier.height(8.dp))
    Text("Connected workflow", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TextButton(onClick = { onNavigate("production") }) { Text("QC") }
        TextButton(onClick = { onNavigate("production_warehouse") }) { Text("Transfer") }
        TextButton(onClick = { onNavigate("inventory") }) { Text("Warehouse") }
    }
}

@Composable
private fun WarehouseTransferScanDetail(transferId: String) {
    val transfers by MockRepository.warehouseTransfers.collectAsState()
    val transfer = transfers.firstOrNull { it.id == transferId }
    Text("🚚 Warehouse / Delivery", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(transfer?.transferNumber ?: transferId, style = MaterialTheme.typography.titleMedium)
    Text("${transfer?.sourceWarehouseId ?: "—"} → ${transfer?.destinationWarehouseId ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Text("Status: ${transfer?.status ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(4.dp))
    Text("${transfer?.lines?.size ?: 0}টি লাইন-আইটেম", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
}

@Composable
private fun InvoiceScanDetail(invoiceId: String, onNavigate: (String) -> Unit) {
    val invoices by MockRepository.salesInvoices.collectAsState()
    val invoice = invoices.firstOrNull { it.id == invoiceId }
    // v113-350 — the person's own point, and they were right: scanning an
    // invoice showed "Stock / Ledger / Delivery" — MODULE links, none of them
    // this invoice's own work. "প্রত্যেকটা QR code যে কাজ সম্পর্কিত, শুধুমাত্র
    // ওই অপশনগুলোই show করবে।" An invoice QR now offers exactly the
    // invoice's own things: open it (Print lives inside the document), and
    // its full history — issue → approve → delivery → scan — from the same
    // audit log every other history view reads. Dealer-level accounting
    // belongs to the DEALER's QR, their own words.
    var historyOpen by remember { mutableStateOf(false) }
    Text("🧾 Invoice", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(invoice?.invoiceNo ?: invoiceId, style = MaterialTheme.typography.titleMedium)
    Text(invoice?.dealerName ?: "—", style = MaterialTheme.typography.bodySmall)
    Text("৳${"%,.2f".format(invoice?.total ?: 0.0)} — Status: ${invoice?.status ?: "—"}", style = MaterialTheme.typography.bodySmall)
    if (invoice != null && !invoice.isApprovedOrLater) {
        Text(
            if (invoice.status == "CANCELLED") "⚠ এই invoice বাতিল করা হয়েছে" else "⚠ এখনো approve হয়নি — DRAFT",
            style = MaterialTheme.typography.labelSmall, color = WarningAmber,
        )
    }
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Button(onClick = { onNavigate("invoice_doc/$invoiceId") }) { Text("Invoice খুলুন") }
        TextButton(onClick = { historyOpen = true }) { Text("পুরো History") }
    }
    // v113-350 — the person's point 4: from a verified invoice's QR, a
    // return/cancel path must exist, and it needs approval like everything
    // else ("approve thaka lgbe"). This raises a FULL-invoice SalesReturn
    // (their chosen option: return approve = whole invoice cancel) in
    // PENDING — nothing moves until it is approved through the normal
    // return-approval flow, at which point approveSalesReturn reverses the
    // money/stock and flips the invoice to CANCELLED.
    if (invoice != null && invoice.isApprovedOrLater && invoice.status != "CANCELLED") {
        var returnOpen by remember { mutableStateOf(false) }
        var returnReason by remember { mutableStateOf("") }
        val scanScope = rememberCoroutineScope()
        val ctx = androidx.compose.ui.platform.LocalContext.current
        TextButton(onClick = { returnOpen = true }) { Text("Return / Cancel", color = DangerRed) }
        if (returnOpen) {
            Dialog(onDismissRequest = { returnOpen = false }) {
                Surface(shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("পুরো Invoice Return", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "সব পণ্য ফেরত হিসেবে ধরা হবে (৳${"%,.2f".format(invoice.total)})। Approve হলে তবেই টাকা/স্টক ফিরবে ও invoice CANCELLED হবে — এখন কিছুই বদলাবে না।",
                            style = MaterialTheme.typography.bodySmall, color = TextSecondary,
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = returnReason, onValueChange = { returnReason = it }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { returnOpen = false }) { Text("Cancel") }
                            Button(
                                enabled = returnReason.isNotBlank(),
                                onClick = {
                                    scanScope.launch {
                                        val created = MockRepository.createSalesReturn(
                                            invoiceId = invoice.id, partyType = com.abm.erp.data.PartyType.DEALER,
                                            partyId = invoice.dealerId, partyName = invoice.dealerName,
                                            lineItems = invoice.lineItems, reason = returnReason.trim(),
                                            onRejected = { r -> android.widget.Toast.makeText(ctx, r, android.widget.Toast.LENGTH_LONG).show() },
                                        )
                                        if (created != null) {
                                            android.widget.Toast.makeText(ctx, "Return ${created.returnNo} — approval-এ পাঠানো হলো।", android.widget.Toast.LENGTH_LONG).show()
                                            com.abm.erp.core.SuccessBus.show("Approval-এ পাঠানো হয়েছে", created.returnNo)
                                            returnOpen = false
                                        }
                                    }
                                },
                            ) { Text("Approval-এ পাঠান") }
                        }
                    }
                }
            }
        }
    }
    if (historyOpen) {
        val log by MockRepository.activityLogFor("SalesInvoice", invoiceId).collectAsState(initial = emptyList())
        Dialog(onDismissRequest = { historyOpen = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 480.dp)) {
                    Text("Invoice History — ${invoice?.invoiceNo ?: ""}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    if (log.isEmpty()) {
                        Text("কোনো log নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(log) { e ->
                                Column {
                                    Text("${e.action} — ${e.performedBy}", style = MaterialTheme.typography.labelMedium)
                                    Text("${e.timestamp}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { historyOpen = false }) { Text("Close") }
                }
            }
        }
    }
}

// v113-355 — shared history dialog for the redesigned scan-detail screens.
// Same audit source (activityLogFor) every other history view in the app
// reads, so a scanned record's "পুরো History" shows the exact same trail as
// its browse-list ⋮ → Activity Log. Called with named args (never a trailing
// lambda) so the trailing-lambda checker stays quiet.
@Composable
private fun ScanHistoryDialog(title: String, entityType: String, entityId: String, onClose: () -> Unit) {
    val log by MockRepository.activityLogFor(entityType, entityId).collectAsState(initial = emptyList())
    Dialog(onDismissRequest = onClose) {
        Surface(shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 480.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                if (log.isEmpty()) {
                    Text("কোনো log নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(log) { e ->
                            Column {
                                Text("${e.action} — ${e.performedBy}", style = MaterialTheme.typography.labelMedium)
                                Text("${e.timestamp}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onClose) { Text("Close") }
            }
        }
    }
}

@Composable
private fun CollectionScanDetail(collectionId: String, onNavigate: (String) -> Unit) {
    val collections by MockRepository.partyCollections.collectAsState()
    val collection = collections.firstOrNull { it.id == collectionId }
    var historyOpen by remember { mutableStateOf(false) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    // v113-355 — redesigned to the invoice-QR pattern: the collection's OWN
    // data + its OWN history + its OWN action, no jump to a generic ledger
    // workspace. A PENDING collection can be Verified/Rejected right from its
    // QR (same engine, so the same permission + territory + double-count
    // guards apply); anything already decided just shows its state.
    Text("💵 Collection", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(collection?.collectionNo ?: collectionId, style = MaterialTheme.typography.titleMedium)
    Text(collection?.partyName ?: "—", style = MaterialTheme.typography.bodySmall)
    Text("৳${"%,.2f".format(collection?.amount ?: 0.0)} · ${collection?.method ?: "—"}", style = MaterialTheme.typography.bodySmall)
    if (collection != null) {
        Text(
            "Collected by ${collection.collectedBy.ifBlank { "—" }} · ${collection.createdAt.toLocalDate()}",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Text(
            "Status: ${collection.status}",
            style = MaterialTheme.typography.bodySmall,
            color = when (collection.status) { "VERIFIED" -> SuccessGreen; "REJECTED" -> DangerRed; else -> WarningAmber },
        )
        if (collection.status == "VERIFIED" && collection.verifiedBy != null) {
            Text("Verified by ${collection.verifiedBy}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
        if (collection.allocatedInvoiceId != null) {
            Text("Invoice-এ allocate করা হয়েছে", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
    }
    Spacer(Modifier.height(8.dp))
    TextButton(onClick = { historyOpen = true }) { Text("পুরো History") }
    if (collection != null && collection.status == "PENDING" &&
        com.abm.erp.data.PermissionManager.canCurrentUser("bill", com.abm.erp.data.PermissionAction.APPROVE)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = {
                val ok = MockRepository.verifyCollection(
                    collection.id,
                    onRejected = { r -> android.widget.Toast.makeText(ctx, r, android.widget.Toast.LENGTH_LONG).show() },
                )
                if (ok) android.widget.Toast.makeText(ctx, "Collection verified.", android.widget.Toast.LENGTH_SHORT).show()
            }) { Text("Verify") }
            TextButton(onClick = {
                MockRepository.rejectCollection(
                    collection.id,
                    onRejected = { r -> android.widget.Toast.makeText(ctx, r, android.widget.Toast.LENGTH_LONG).show() },
                )
            }) { Text("Reject", color = DangerRed) }
        }
    }
    if (historyOpen) {
        ScanHistoryDialog(
            title = "Collection History — ${collection?.collectionNo ?: ""}",
            entityType = "Collection", entityId = collectionId,
            onClose = { historyOpen = false },
        )
    }
}

@Composable
private fun ProductScanDetail(productId: String, onNavigate: (String) -> Unit) {
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val product = products.firstOrNull { it.id == productId }
    val levels by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
    val movements by com.abm.erp.data.InventoryRepository.movements.collectAsState()
    var historyOpen by remember { mutableStateOf(false) }
    // v113-355 — a product's OWN data + its OWN stock-movement history. The
    // on-hand figure is summed from the real stockLevels flow across every
    // warehouse (not fabricated), and the history is its actual IN/OUT/ADJUST
    // trail — not a jump to the generic inventory list.
    val onHand = levels.filter { it.productId == productId }.sumOf { it.quantityOnHand }
    val reorder = product?.reorderThreshold ?: 0.0
    val low = product != null && onHand <= reorder
    Text("📦 Product", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(product?.name ?: productId, style = MaterialTheme.typography.titleMedium)
    Text("SKU: ${product?.sku ?: "—"} · ${product?.category ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Text("দর ৳${"%,.2f".format(product?.defaultUnitPrice ?: 0.0)} / ${product?.unit ?: ""}", style = MaterialTheme.typography.bodySmall)
    Text(
        "Stock on hand: ${"%,.1f".format(onHand)} ${product?.unit ?: ""}",
        style = MaterialTheme.typography.bodySmall,
        color = if (low) DangerRed else SuccessGreen,
    )
    if (low) Text("⚠ reorder সীমার নিচে (${"%,.0f".format(reorder)})", style = MaterialTheme.typography.labelSmall, color = DangerRed)
    Spacer(Modifier.height(8.dp))
    TextButton(onClick = { historyOpen = true }) { Text("Stock Movement History") }
    if (historyOpen) {
        val rows = movements.filter { it.productId == productId }.sortedByDescending { it.timestamp }.take(30)
        Dialog(onDismissRequest = { historyOpen = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 480.dp)) {
                    Text("Stock Movement — ${product?.name ?: ""}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    if (rows.isEmpty()) {
                        Text("কোনো movement নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(rows) { m ->
                                Column {
                                    Text(
                                        "${m.type} ${"%,.1f".format(m.quantity)} ${product?.unit ?: ""} — ${m.reason}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = when (m.type) {
                                            com.abm.erp.data.MovementType.IN -> SuccessGreen
                                            com.abm.erp.data.MovementType.OUT -> DangerRed
                                            else -> WarningAmber
                                        },
                                    )
                                    Text("${m.warehouseName} · ${m.timestamp.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { historyOpen = false }) { Text("Close") }
                }
            }
        }
    }
}

@Composable
private fun DeliveryScanDetail(challanId: String, onNavigate: (String) -> Unit) {
    val challans by MockRepository.deliveryChallans.collectAsState()
    val challan = challans.firstOrNull { it.id == challanId }
    var historyOpen by remember { mutableStateOf(false) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    // v113-355 — a challan's OWN action is moving it along its OWN lifecycle
    // (PENDING → DISPATCHED → DELIVERED), not opening the billing module.
    // updateChallanStatus fires its own SuccessBus + COD-paid hook on DELIVERED.
    Text("🚛 Delivery", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(challan?.challanNo ?: challanId, style = MaterialTheme.typography.titleMedium)
    Text(challan?.partyName ?: "—", style = MaterialTheme.typography.bodySmall)
    Text(
        "Vehicle: ${challan?.vehicleNo?.ifBlank { "—" } ?: "—"} · Driver: ${challan?.driverName?.ifBlank { "—" } ?: "—"}",
        style = MaterialTheme.typography.bodySmall,
    )
    if (challan != null) {
        Text(
            "${challan.lineItems.size} item · Status: ${challan.status}",
            style = MaterialTheme.typography.bodySmall,
            color = when (challan.status) { "DELIVERED" -> SuccessGreen; "DISPATCHED" -> WarningAmber; else -> TextSecondary },
        )
    }
    Spacer(Modifier.height(8.dp))
    TextButton(onClick = { historyOpen = true }) { Text("পুরো History") }
    if (challan != null && challan.status == "PENDING") {
        Button(onClick = {
            MockRepository.updateChallanStatus(challan.id, "DISPATCHED")
            android.widget.Toast.makeText(ctx, "Dispatched.", android.widget.Toast.LENGTH_SHORT).show()
        }) { Text("Dispatch করুন") }
    } else if (challan != null && challan.status == "DISPATCHED") {
        Button(onClick = {
            MockRepository.updateChallanStatus(challan.id, "DELIVERED")
        }) { Text("Delivered চিহ্নিত করুন") }
    }
    if (historyOpen) {
        ScanHistoryDialog(
            title = "Delivery History — ${challan?.challanNo ?: ""}",
            entityType = "DeliveryChallan", entityId = challanId,
            onClose = { historyOpen = false },
        )
    }
}

/**
 * v113-138 — one shared scan configuration for the whole app.
 * `setOrientationLocked(false)` previously let the scanner flip to landscape when
 * the phone tilted, which is wrong for a QR held in front of you — locked to the
 * app's portrait orientation instead. Defined once here so every entry point
 * (dashboard, invoice, memo, collection, browse-list FAB) opens an identical
 * scanner rather than each configuring its own.
 */
private fun abmScanOptions(): ScanOptions = ScanOptions()
    .setPrompt("QR/Barcode স্ক্যান করুন")
    .setBeepEnabled(true)
    .setOrientationLocked(true)
