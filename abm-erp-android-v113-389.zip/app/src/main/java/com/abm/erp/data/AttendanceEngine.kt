package com.abm.erp.data

import java.time.DayOfWeek
import java.time.LocalDate

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * v113-383 — ATTENDANCE ENGINE (HRM ধাপ ৪)
 *
 * আলোচনায় ঠিক হওয়া নিয়ম, হুবহু:
 *
 *   · ভার্চুয়াল সাইন — **Wing 1-এর যে কেউ** verify করতে পারবে
 *     (Wing 1 এলাকাহীন, তাই যে কেউ)
 *   · দেরি হলে **লাল চিহ্ন উঠবে** — কিন্তু বেতন **আপনাআপনি কাটবে না**
 *   · অনুপস্থিতি/ছুটিও দেখাবে, কাটার সিদ্ধান্ত **Wing 1-এর ম্যানুয়াল**
 *   · **শুক্রবার আপনাআপনি ছুটি**
 *   · ঈদ/পূজা/বিশেষ দিন → **Chairman drawer থেকে ঘোষণা** → আপনাআপনি সবার ছুটি
 *   · কর্মঘণ্টা ৯টা–৫টা
 *
 * ─── এই engine কখনো শাস্তি দেয় না ──────────────────────────────────────────
 * এখানে কোনো `penalty`, কোনো `deduction` নেই — ইচ্ছাকৃতভাবে। engine শুধু
 * **গোনে ও দেখায়**; কাটার সিদ্ধান্ত `SalaryEngine`-এর `manualDeduction`-এ,
 * যা Wing 1 হাতে বসায় কারণসহ।
 *
 * এর একটা দাবি আছে, আর সেটা আলোচনাতেই বলা হয়েছিল: যেহেতু কিছুই আপনাআপনি
 * হচ্ছে না, **দেখানোটা নিখুঁত হতে হবে** — Wing 1 যেন এক নজরে দেখে এই মাসে
 * কার কত দেরি, কত অনুপস্থিতি। তালিকা ঘেঁটে বের করতে হলে বাস্তবে কেউ করবে না।
 * তাই `monthlySummary()` পুরো মাসের হিসাব এক জায়গায় দেয়।
 * ═════════════════════════════════════════════════════════════════════════════
 */
object AttendanceEngine {

    /** ঘোষিত ছুটি — `CompanySettings.holidaysRaw`-এ "epochDay:name;…" আকারে জমা। */
    data class Holiday(val date: LocalDate, val name: String)

    // ─────────────────────────────────────────────────────────────────────────
    // ছুটির দিন
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * প্যাক-করা স্ট্রিং থেকে ঘোষিত ছুটির তালিকা।
     *
     * ভাঙা অংশ নীরবে বাদ যায় (`mapNotNull`) — একটা খারাপ এন্ট্রির জন্য পুরো
     * তালিকা হারানো, বা crash করা, দুটোই এর চেয়ে খারাপ। ছুটির তালিকা
     * ব্যবসার কাজ আটকায় না, তাই এখানে সহনশীলতাই সঠিক আচরণ।
     */
    fun parseHolidays(raw: String): List<Holiday> =
        raw.split(";").mapNotNull { chunk ->
            val part = chunk.trim()
            if (part.isBlank()) return@mapNotNull null
            val sep = part.indexOf(':')
            if (sep <= 0) return@mapNotNull null
            val day = part.substring(0, sep).trim().toLongOrNull() ?: return@mapNotNull null
            Holiday(LocalDate.ofEpochDay(day), part.substring(sep + 1).trim().ifBlank { "ছুটি" })
        }.sortedBy { it.date }

    fun packHolidays(list: List<Holiday>): String =
        list.distinctBy { it.date }.sortedBy { it.date }
            .joinToString(";") { "${it.date.toEpochDay()}:${it.name.replace(';', ',').replace(':', '-')}" }

    /**
     * এই দিনটা কি কর্মদিবস?
     *
     * দুটো আলাদা কারণ, তাই দুটো আলাদা পরীক্ষা:
     *   · সাপ্তাহিক ছুটি — `CompanySettings.workingDays`-এ নেই (শুক্রবার)
     *   · ঘোষিত ছুটি — Chairman বসিয়েছেন (ঈদ, পূজা)
     */
    fun isWorkingDay(
        date: LocalDate,
        workingDays: List<String>,
        holidays: List<Holiday>,
    ): Boolean {
        if (holidays.any { it.date == date }) return false
        if (workingDays.isEmpty()) return date.dayOfWeek != DayOfWeek.FRIDAY // নিরাপদ ডিফল্ট
        return workingDays.any { it.equals(date.dayOfWeek.name, ignoreCase = true) }
    }

    /** কেন ছুটি — পর্দায় কারণ দেখানোর জন্য। কর্মদিবস হলে null। */
    fun offReason(date: LocalDate, workingDays: List<String>, holidays: List<Holiday>): String? {
        holidays.firstOrNull { it.date == date }?.let { return it.name }
        val isWorking = if (workingDays.isEmpty()) date.dayOfWeek != DayOfWeek.FRIDAY
        else workingDays.any { it.equals(date.dayOfWeek.name, ignoreCase = true) }
        return if (isWorking) null else "সাপ্তাহিক ছুটি"
    }

    /** একটা সময়সীমায় মোট কর্মদিবস — অনুপস্থিতির হিসাবের ভিত্তি। */
    fun workingDaysBetween(
        from: LocalDate,
        to: LocalDate,
        workingDays: List<String>,
        holidays: List<Holiday>,
    ): Int {
        var d = from
        var n = 0
        while (!d.isAfter(to)) {
            if (isWorkingDay(d, workingDays, holidays)) n++
            d = d.plusDays(1)
        }
        return n
    }

    // ─────────────────────────────────────────────────────────────────────────
    // মাসিক সারাংশ — Wing 1-এর সিদ্ধান্তের ভিত্তি
    // ─────────────────────────────────────────────────────────────────────────

    data class Summary(
        val employeeId: String,
        val employeeName: String,
        val workingDays: Int,
        val present: Int,
        val late: Int,
        val onLeave: Int,
        /**
         * অনুপস্থিত = কর্মদিবস − উপস্থিত − ছুটি।
         *
         * ভবিষ্যতের দিন বাদ দেওয়া হয়: আজ ১০ তারিখ হলে বাকি ২০ দিন
         * "অনুপস্থিত" দেখানো নির্জলা মিথ্যা হতো, আর কেউ সেটার ভিত্তিতে বেতন
         * কাটলে অন্যায় হতো।
         */
        val absent: Int,
    ) {
        val hasIssue: Boolean get() = late > 0 || absent > 0
    }

    /**
     * এক মাসের হিসাব, একজনের।
     *
     * `records` ওই employee-র হাজিরার সারি। যে দিনের সারি নেই সেই দিন
     * অনুপস্থিত ধরা হয় — কিন্তু কেবল **আজ পর্যন্ত**।
     */
    fun monthlySummary(
        employee: EmployeeProfile,
        from: LocalDate,
        to: LocalDate,
        records: List<com.abm.erp.data.room.AttendanceRecordEntity>,
        workingDays: List<String>,
        holidays: List<Holiday>,
        today: LocalDate = LocalDate.now(),
    ): Summary {
        val upto = if (to.isAfter(today)) today else to
        val mine = records.filter {
            it.employeeId == employee.id &&
                LocalDate.ofEpochDay(it.dateEpochDay).let { d -> !d.isBefore(from) && !d.isAfter(upto) }
        }
        val present = mine.count { it.checkedIn && !it.isOnLeave }
        val late = mine.count { it.checkedIn && it.isLate }
        val leave = mine.count { it.isOnLeave }
        val totalWorking = workingDaysBetween(from, upto, workingDays, holidays)
        return Summary(
            employeeId = employee.id,
            employeeName = employee.fullName,
            workingDays = totalWorking,
            present = present,
            late = late,
            onLeave = leave,
            absent = (totalWorking - present - leave).coerceAtLeast(0),
        )
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ছুটি ঘোষণা — Chairman-এর বড় ক্ষমতা
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * ঈদ/পূজা/বিশেষ দিন ঘোষণা।
     *
     * "এটা চেয়ারম্যান drawer-এ একটা huge authoritical power" — আপনার নিজের
     * কথা, আর সেটা সত্যি: এক ক্লিকে গোটা কোম্পানির হাজিরার হিসাব বদলে যায়,
     * কারণ ওই দিনগুলো আর কর্মদিবস নয়, তাই কেউ অনুপস্থিতও নয়।
     *
     * তাই কেবল Chairman, আর নাম বাধ্যতামূলক — "১৫ এপ্রিল ছুটি" পরে কেউ
     * দেখলে কারণ জানতে পারবে না।
     */
    fun declareHoliday(date: LocalDate, name: String, onResult: (String) -> Unit = {}) {
        if (MockRepository.currentUser.role != UserRole.CHAIRMAN) {
            onResult("ছুটি ঘোষণা কেবল Chairman করতে পারেন।")
            return
        }
        if (name.isBlank()) {
            onResult("ছুটির নাম লিখুন — পরে কেউ দেখলে কারণ বুঝতে হবে।")
            return
        }
        MockRepository.updateHolidays(date, name, remove = false, onResult = onResult)
    }

    /** ঘোষিত ছুটি তুলে নেওয়া — কেবল Chairman। */
    fun removeHoliday(date: LocalDate, onResult: (String) -> Unit = {}) {
        if (MockRepository.currentUser.role != UserRole.CHAIRMAN) {
            onResult("কেবল Chairman পারেন।")
            return
        }
        MockRepository.updateHolidays(date, "", remove = true, onResult = onResult)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ছুটির আবেদন — অনুমোদন Wing 1
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * এই ব্যক্তি ছুটি অনুমোদন করতে পারে কি না।
     *
     * "ছুটি approve wing 1 ই করতে পারবে" — এলাকা দেখা হয় না, কারণ Wing 1
     * এলাকাহীন। এটাই cascade-এর সাথে সঙ্গতিপূর্ণ: Wing 1 নিয়ম ঠিক করে,
     * Wing 2 কাজ করে।
     */
    fun canApproveLeave(actor: UserRole): Boolean =
        CascadeEngine.wingOf(actor) == CascadeEngine.Wing.OFFICE

    /**
     * ছুটির আবেদনে কত **কর্মদিবস** পড়ছে।
     *
     * শুক্রবার বা ঘোষিত ছুটি মাঝে পড়লে সেগুলো গোনা হয় না — নইলে ঈদের
     * ছুটির মধ্যে দুদিনের ছুটি চাইলে সাত দিন কাটা যেত।
     */
    fun leaveWorkingDays(
        req: LeaveRequest,
        workingDays: List<String>,
        holidays: List<Holiday>,
    ): Int = workingDaysBetween(req.fromDate, req.toDate, workingDays, holidays)
}
