package com.abm.erp.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.*
import com.abm.erp.theme.*
import kotlinx.coroutines.launch

/**
 * v113-221 — the person's own explicit request, radically simplified from
 * what this screen used to be (15+ fields: fiscal year, tax/VAT, currency
 * format, working days, holidays, five separate policy notes — all real,
 * none deleted, just relocated to where they actually belong: fiscal
 * year/working days/holidays/policies and the HR-relevant business rules
 * moved into HR's own Chairman panel as "Company & Payroll Setup"; the
 * DMS-relevant rules moved into DMS's own Chairman panel — matching the
 * person's own principle, "একেক জায়গায় একেকটা rules হবে", rules belong
 * where they're actually used, not centralized generically). What's left
 * here is exactly what the person asked for: name, address, contact, and
 * — genuinely new — a real logo that now reflects across the app instead
 * of staying hardcoded "ABM ERP" regardless of who's running it.
 */
@Composable
fun CompanySettingsCenterScreen() {
    val currentUser = MockRepository.currentUser
    if (currentUser.role != UserRole.CHAIRMAN) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("এই স্ক্রিন শুধু Chairman-এর জন্য।") }
        return
    }
    val settingsList by MockRepository.companySettingsList.collectAsState()
    val settings = remember(settingsList) { MockRepository.companySettings() }

    var companyName by remember(settings) { mutableStateOf(settings.companyName) }
    var companyAddress by remember(settings) { mutableStateOf(settings.companyAddress) }
    var companyPhone by remember(settings) { mutableStateOf(settings.companyPhone) }
    var companyEmail by remember(settings) { mutableStateOf(settings.companyEmail) }
    var saved by remember { mutableStateOf(false) }
    val logoContext = androidx.compose.ui.platform.LocalContext.current
    var uploadingLogo by remember { mutableStateOf(false) }
    val logoPicker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            uploadingLogo = true
            MockRepository.uploadCompanyLogo(logoContext, uri.toString()) { uploadingLogo = false }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp).imePadding().verticalScroll(rememberScrollState())) {
        Text("Company Info", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(4.dp))
        Text("এই তথ্য পুরো অ্যাপ জুড়ে দেখাবে — invoice, memo, ও main dashboard-এর হেডারে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (!settings.companyLogoUri.isNullOrBlank()) {
                coil.compose.AsyncImage(
                    model = settings.companyLogoUri, contentDescription = "Company logo",
                    modifier = Modifier.size(64.dp).clip(CircleShape),
                )
            } else {
                Box(
                    Modifier.size(64.dp).clip(CircleShape).background(com.abm.erp.theme.DarazOrange.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center,
                ) { Text("🏢", fontSize = 28.sp) }
            }
            TextButton(onClick = { logoPicker.launch("image/*") }) {
                Text(if (uploadingLogo) "Uploading…" else if (settings.companyLogoUri.isNullOrBlank()) "+ Logo যোগ করুন" else "Logo বদলান")
            }
        }
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(value = companyName, onValueChange = { companyName = it }, label = { Text("Company Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = companyAddress, onValueChange = { companyAddress = it }, label = { Text("Address / Location") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = companyPhone, onValueChange = { companyPhone = it }, label = { Text("Phone") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(value = companyEmail, onValueChange = { companyEmail = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.weight(1f))
        }

        Spacer(Modifier.height(20.dp))
        if (saved) { Text("✓ সংরক্ষিত হয়েছে", color = SuccessGreen, style = MaterialTheme.typography.labelSmall); Spacer(Modifier.height(8.dp)) }
        Button(
            onClick = {
                saved = MockRepository.updateCompanySettings(
                    settings.copy(companyName = companyName, companyAddress = companyAddress, companyPhone = companyPhone, companyEmail = companyEmail),
                )
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Save") }
    }
}
