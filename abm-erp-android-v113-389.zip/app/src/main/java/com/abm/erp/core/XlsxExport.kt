package com.abm.erp.core

import android.content.Context
import java.io.File

/**
 * v113-351 — real .xlsx export, the person's point 2 ("Excel ar png option
 * nai"). No Apache POI: an xlsx is a ZIP of five small XML parts, written
 * here directly with inline strings — Excel, WPS and Google Sheets all open
 * it. Numeric-looking cells are written as numbers so totals stay summable.
 */
object XlsxExport {

    /** Splits one CSV line honouring double-quotes, so a value containing a comma survives as one cell. */
    private fun parseCsvLine(line: String): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var inQ = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                ch == '"' && inQ && i + 1 < line.length && line[i + 1] == '"' -> { cur.append('"'); i++ }
                ch == '"' -> inQ = !inQ
                ch == ',' && !inQ -> { out.add(cur.toString()); cur.clear() }
                else -> cur.append(ch)
            }
            i++
        }
        out.add(cur.toString())
        return out
    }

    private fun xmlEscape(s: String) = s
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")

    private fun colRef(index: Int): String { // 0 -> A, 25 -> Z, 26 -> AA
        var i = index
        val sb = StringBuilder()
        while (i >= 0) { sb.insert(0, ('A' + i % 26)); i = i / 26 - 1 }
        return sb.toString()
    }

    private fun sheetXml(rows: List<List<String>>): String {
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        sb.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
        rows.forEachIndexed { r, cells ->
            sb.append("<row r=\"${r + 1}\">")
            cells.forEachIndexed { c, raw ->
                val ref = "${colRef(c)}${r + 1}"
                val num = raw.trim().toDoubleOrNull()
                if (num != null && raw.trim().isNotEmpty()) {
                    sb.append("<c r=\"$ref\"><v>${raw.trim()}</v></c>")
                } else {
                    sb.append("<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xmlEscape(raw)}</t></is></c>")
                }
            }
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")
        return sb.toString()
    }

    /** Writes a single-sheet workbook from CSV-shaped header + data rows; returns the file. */
    fun writeWorkbook(context: Context, fileBaseName: String, csvHeader: String, csvRows: List<String>): File {
        val rows = buildList {
            if (csvHeader.isNotBlank()) add(parseCsvLine(csvHeader))
            csvRows.filter { it.isNotBlank() }.forEach { add(parseCsvLine(it)) }
        }.ifEmpty { listOf(listOf("(empty)")) }

        val parts = linkedMapOf(
            "[Content_Types].xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""",
            "_rels/.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""",
            "xl/workbook.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>""",
            "xl/_rels/workbook.xml.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""",
            "xl/worksheets/sheet1.xml" to sheetXml(rows),
        )

        val dir = File(context.cacheDir, "shares").apply { if (!exists()) mkdirs() }
        val file = File(dir, "$fileBaseName.xlsx")
        java.util.zip.ZipOutputStream(java.io.FileOutputStream(file)).use { zip ->
            parts.forEach { (name, content) ->
                zip.putNextEntry(java.util.zip.ZipEntry(name))
                zip.write(content.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
        }
        return file
    }
}

/**
 * v113-351 — companion to publishImageToGallery for non-image exports: lands
 * a produced file in the device's Downloads/ABM ERP so the file manager can
 * see it (the person's point 3 covered CSV/Excel/PDF too, not only images).
 * Best-effort; the export/share never depends on it.
 */
fun publishFileToDownloads(context: Context, file: File, mime: String): Boolean = try {
    if (android.os.Build.VERSION.SDK_INT >= 29) {
        val values = android.content.ContentValues().apply {
            put(android.provider.MediaStore.Downloads.DISPLAY_NAME, file.name)
            put(android.provider.MediaStore.Downloads.MIME_TYPE, mime)
            put(android.provider.MediaStore.Downloads.RELATIVE_PATH, "Download/ABM ERP")
        }
        val uri = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        if (uri != null) {
            context.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            true
        } else false
    } else {
        @Suppress("DEPRECATION")
        val dir = File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), "ABM ERP").apply { if (!exists()) mkdirs() }
        val dest = File(dir, file.name)
        file.copyTo(dest, overwrite = true)
        context.sendBroadcast(android.content.Intent(android.content.Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, android.net.Uri.fromFile(dest)))
        true
    }
} catch (e: Exception) {
    com.abm.erp.config.AppLog.w("XlsxExport", "downloads publish failed (export unaffected)", e)
    false
}
