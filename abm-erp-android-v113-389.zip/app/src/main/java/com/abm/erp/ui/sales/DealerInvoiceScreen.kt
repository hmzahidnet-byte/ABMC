package com.abm.erp.ui.sales

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.DealerPickerDialog
import com.abm.erp.core.ProductPickerDialog
import com.abm.erp.core.Space
import com.abm.erp.data.MockRepository
import com.abm.erp.data.SalesInvoiceLineItem
import com.abm.erp.theme.*
import kotlinx.coroutines.launch

/**
 * Dealer Invoice — the creation form IS the bill.
 *
 * The old flow was a plain form (dealer list, product search, cart rows as plain text) that,
 * once saved, could only be *viewed* properly on a separate document page. This page removes
 * that split: the Dealer box, the item table and the totals are laid out exactly like
 * `InvoiceDocumentScreen`, and they are also the live inputs. What you're looking at while
 * building the invoice is what it will look like once it exists.
 *
 * **Every real check is untouched.** Submission calls the exact same
 * `MockRepository.createSalesInvoice(...)` the old form called, with the same parameters, so
 * stock validation, credit-limit blocking, and closed-period rejection all still apply exactly
 * as before — this page only changes how the inputs are laid out, not what happens when you
 * submit them.
 */
@Composable
fun DealerInvoiceScreen(onBack: () -> Unit, onNavigate: (String) -> Unit = {}) {
    // Decision 4 (v113-73) — was `MockRepository.dealers.collectAsState()`, i.e. the raw
    // unscoped list, which then went straight into DealerPickerDialog. An SR could pick and
    // invoice a dealer outside his own territory from here. Now cascade-scoped like every
    // other dealer surface.
    val dealers = com.abm.erp.core.rememberVisibleDealers()
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedDealerId by remember { mutableStateOf<String?>(null) }
    var cart by remember { mutableStateOf(listOf<SalesInvoiceLineItem>()) }
    var courier by remember { mutableStateOf("") }
    var dealerDiscount by remember { mutableStateOf("") }
    var commission by remember { mutableStateOf("") }
    var withSignature by remember { mutableStateOf(false) }
    var isSubmitting by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    var showDealerPicker by remember { mutableStateOf(false) }
    var showProductPicker by remember { mutableStateOf(false) }

    val dealer = dealers.firstOrNull { it.id == selectedDealerId }
    val subTotal = cart.sumOf { it.lineTotal }
    val discountPct = dealerDiscount.toDoubleOrNull() ?: 0.0
    val discountAmt = subTotal * (discountPct / 100)
    val netTotal = subTotal - discountAmt
    val previousDue = dealer?.dueBalance ?: 0.0
    val projectedDue = previousDue + netTotal
    val overLimit = dealer != null && dealer.creditLimit > 0 && projectedDue > dealer.creditLimit

    Column(Modifier.fillMaxSize().background(DashBg)) {

        // ── top bar ──
        Row(
            Modifier.fillMaxWidth().background(Color.White).padding(horizontal = Space.md, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back", tint = TextPrimary) }
            Column(Modifier.weight(1f)) {
                Text("New Dealer Invoice", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextPrimary)
                Text("তৈরি করার সময়েই বিলের আকারে দেখা যায়", fontSize = 10.sp, color = TextSecondary)
            }
        }

        Column(Modifier.weight(1f).imePadding().verticalScroll(rememberScrollState()).padding(Space.md)) {

            // ═══ THE DOCUMENT — also the form ═══
            Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp))) {

                Row(
                    Modifier.fillMaxWidth()
                        .background(Brush.horizontalGradient(listOf(DarazOrange, DarazOrangeDark)), RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                        .padding(Space.lg),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("ABM CORPORATION", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("Enterprise. Control. Growth.", color = Color.White.copy(alpha = 0.85f), fontSize = 9.sp)
                    }
                    Text("INVOICE (Draft)", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                Column(Modifier.padding(Space.lg)) {

                    // ── tappable Dealer box — selecting it live-loads real due/limit ──
                    Text("DEALER", fontSize = 8.sp, color = TextSecondary, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
                    Spacer(Modifier.height(4.dp))
                    Column(
                        Modifier.fillMaxWidth()
                            .background(if (dealer == null) Color(0xFFFFF4ED) else Color(0xFFF7F8FA), RoundedCornerShape(10.dp))
                            .clickable { showDealerPicker = true }
                            .padding(Space.md),
                    ) {
                        if (dealer == null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Business, null, tint = DarazOrange, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(Space.sm))
                                Text("ডিলার বাছতে চাপুন", color = DarazOrange, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        } else {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text(dealer.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    Text(dealer.zone, fontSize = 10.sp, color = TextSecondary)
                                }
                                Text("বদলান", fontSize = 10.sp, color = DarazOrange, fontWeight = FontWeight.SemiBold)
                            }
                            Spacer(Modifier.height(6.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Previous Due", fontSize = 10.sp, color = TextSecondary)
                                Text("৳${"%,.0f".format(previousDue)}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            }
                            if (dealer.creditLimit > 0) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Credit Limit", fontSize = 10.sp, color = TextSecondary)
                                    Text("৳${"%,.0f".format(dealer.creditLimit)}", fontSize = 11.sp, color = TextSecondary)
                                }
                            }
                            if (overLimit) {
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "⚠ এই ইনভয়েসের পর বকেয়া credit limit ছাড়িয়ে যাবে — জমা দেওয়ার সময় আটকাতে পারে।",
                                    fontSize = 10.sp, color = StatusRed, fontWeight = FontWeight.SemiBold,
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(Space.lg))

                    // ── item table — also the form; "+ Add Item" is a real row in it ──
                    Row(
                        Modifier.fillMaxWidth().background(Color(0xFF1B2430), RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                            .padding(horizontal = Space.sm, vertical = 8.dp),
                    ) {
                        Text("Item / Product", Modifier.weight(0.40f), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("Qty", Modifier.weight(0.22f), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        Text("Rate", Modifier.weight(0.19f), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                        Text("Amount", Modifier.weight(0.19f), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                    }
                    cart.forEachIndexed { idx, line ->
                        Row(
                            Modifier.fillMaxWidth()
                                .background(if (idx % 2 == 1) Color(0xFFF7F8FA) else Color.White)
                                .padding(horizontal = Space.sm, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(line.name, Modifier.weight(0.40f), fontSize = 11.sp, color = TextPrimary, maxLines = 1)
                            Row(Modifier.weight(0.22f), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { cart = cart.toMutableList().also { it[idx] = it[idx].copy(qty = maxOf(1, it[idx].qty - 1)) } },
                                    modifier = Modifier.size(22.dp),
                                ) { Icon(Icons.Filled.Remove, "−", tint = DarazOrange, modifier = Modifier.size(14.dp)) }
                                Text("${line.qty}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                IconButton(
                                    onClick = { cart = cart.toMutableList().also { it[idx] = it[idx].copy(qty = it[idx].qty + 1) } },
                                    modifier = Modifier.size(22.dp),
                                ) { Icon(Icons.Filled.Add, "+", tint = DarazOrange, modifier = Modifier.size(14.dp)) }
                            }
                            Text("৳${"%,.0f".format(line.unitPrice)}", Modifier.weight(0.19f), fontSize = 10.sp, color = TextSecondary, textAlign = TextAlign.End)
                            Row(Modifier.weight(0.19f), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                                Text("৳${"%,.0f".format(line.lineTotal)}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                IconButton(onClick = { cart = cart.filterIndexed { i, _ -> i != idx } }, modifier = Modifier.size(20.dp)) {
                                    Icon(Icons.Filled.Close, "Remove", tint = StatusRed, modifier = Modifier.size(13.dp))
                                }
                            }
                        }
                    }
                    // The "add item" row — visually the next row of the same table.
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { showProductPicker = true }
                            .padding(horizontal = Space.sm, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.AddCircleOutline, null, tint = DarazOrange, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(Space.sm))
                        Text("+ Add Item", color = DarazOrange, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    if (cart.isEmpty()) {
                        Text(
                            "উপরের \"+ Add Item\" চেপে পণ্য যোগ করুন।",
                            fontSize = 10.sp, color = TextSecondary,
                            modifier = Modifier.padding(horizontal = Space.sm, vertical = 4.dp),
                        )
                    }

                    Spacer(Modifier.height(Space.md))

                    // ── discount / commission / courier — real inputs, feed the live total above ──
                    OutlinedTextField(
                        value = dealerDiscount, onValueChange = { dealerDiscount = it.filter { c -> c.isDigit() || c == '.' } },
                        label = { Text("Discount %", fontSize = 11.sp) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(Space.sm))
                    OutlinedTextField(
                        value = commission, onValueChange = { commission = it.filter { c -> c.isDigit() || c == '.' } },
                        label = { Text("Commission %", fontSize = 11.sp) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(Space.sm))
                    OutlinedTextField(
                        value = courier, onValueChange = { courier = it },
                        label = { Text("Courier (optional)", fontSize = 11.sp) }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                        Checkbox(checked = withSignature, onCheckedChange = { withSignature = it })
                        Text("Virtual signature (${MockRepository.currentUser.role})", fontSize = 11.sp, color = TextSecondary)
                    }

                    Spacer(Modifier.height(Space.md))

                    // ── live totals ──
                    TotalLine("Subtotal", "৳${"%,.0f".format(subTotal)}")
                    if (discountPct > 0) TotalLine("Discount (${"%.0f".format(discountPct)}%)", "− ৳${"%,.0f".format(discountAmt)}", StatusRed)
                    Spacer(Modifier.height(Space.sm))
                    Row(
                        Modifier.fillMaxWidth()
                            .background(Brush.horizontalGradient(listOf(DarazOrange, DarazOrangeDark)), RoundedCornerShape(10.dp))
                            .padding(horizontal = Space.md, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Total Amount", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("৳${"%,.0f".format(netTotal)}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                    if (dealer != null) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "এই ইনভয়েসের পর মোট বকেয়া হবে ৳${"%,.0f".format(projectedDue)}",
                            fontSize = 10.sp, color = if (overLimit) StatusRed else TextSecondary,
                        )
                    }
                }
            }

            errorMsg?.let {
                Spacer(Modifier.height(Space.md))
                com.abm.erp.core.PremiumCard(padding = Space.md) {
                    Text(it, fontSize = 11.sp, color = StatusRed)
                }
            }

            Spacer(Modifier.height(Space.lg))
        }

        // ── submit ──
        Box(Modifier.fillMaxWidth().background(Color.White).padding(Space.md)) {
            com.abm.erp.core.PrimaryButton(
                text = if (isSubmitting) "তৈরি হচ্ছে…" else "Create Invoice",
                loading = isSubmitting,
                enabled = dealer != null && cart.isNotEmpty(),
                icon = Icons.Filled.ReceiptLong,
                onClick = {
                    val d = dealer ?: return@PrimaryButton
                    if (cart.isEmpty() || isSubmitting) return@PrimaryButton
                    isSubmitting = true
                    errorMsg = null
                    scope.launch {
                        // Same call, same parameters, same validation as the old form —
                        // this page only changed the layout that leads up to this line.
                        val created = MockRepository.createSalesInvoice(
                            dealerId = d.id, dealerName = d.name, dealerZone = d.zone, lineItems = cart,
                            dealerDiscountPct = discountPct, commissionPct = commission.toDoubleOrNull() ?: 0.0,
                            courier = courier.ifBlank { null },
                            signedByRole = if (withSignature) MockRepository.currentUser.role.name else null,
                            onRejected = { reason -> errorMsg = reason },
                        )
                        isSubmitting = false
                        if (created) {
                            onBack()
                        } else if (errorMsg == null) {
                            errorMsg = "ইনভয়েস তৈরি ব্যর্থ হয়েছে — স্টক, ক্রেডিট-লিমিট বা বন্ধ-পিরিয়ড চেক করুন।"
                        }
                    }
                },
            )
        }
    }

    if (showDealerPicker) {
        DealerPickerDialog(
            dealers = dealers,
            onDismiss = { showDealerPicker = false },
            onPick = { selectedDealerId = it.id; showDealerPicker = false },
        )
    }
    if (showProductPicker) {
        ProductPickerDialog(
            products = products,
            onDismiss = { showProductPicker = false },
            onPick = { line ->
                cart = if (cart.any { it.productId == line.productId }) {
                    cart.map { if (it.productId == line.productId) it.copy(qty = it.qty + 1) else it }
                } else {
                    cart + line
                }
                showProductPicker = false
            },
        )
    }
}

@Composable
private fun TotalLine(label: String, value: String, color: Color = TextPrimary) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 11.sp, color = TextSecondary)
        Text(value, fontSize = 12.sp, color = color, fontWeight = FontWeight.SemiBold)
    }
}
