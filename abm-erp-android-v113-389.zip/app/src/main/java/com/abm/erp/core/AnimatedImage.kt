package com.abm.erp.core

import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder

// v113-290 — the person's own direct request named GIF explicitly for
// the new DMS notice slots. Plain coil.compose.AsyncImage only ever
// shows a GIF's first frame — no animation — since the base
// coil-compose artifact doesn't register a GIF decoder at all (checked
// directly against this project's own build.gradle.kts before assuming
// it did). ImageDecoderDecoder is the real, hardware-accelerated
// decoder on API 28+ (Android 9+); GifDecoder is the software fallback
// for anything older — the same real split Coil's own docs recommend,
// not a workaround invented here. A single shared composable so every
// real place a GIF might show up in this app (starting with the two
// notice slots, but not limited to them) gets real animation through
// one real implementation rather than each call site rebuilding its own
// ImageLoader.
@Composable
fun AnimatedImage(
    model: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    alignment: Alignment = Alignment.Center,
) {
    val context = LocalContext.current
    val gifImageLoader = remember(context) {
        ImageLoader.Builder(context)
            .components {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    add(ImageDecoderDecoder.Factory())
                } else {
                    add(GifDecoder.Factory())
                }
            }
            .build()
    }
    AsyncImage(
        model = model, contentDescription = contentDescription, modifier = modifier,
        contentScale = contentScale, alignment = alignment, imageLoader = gifImageLoader,
    )
}
