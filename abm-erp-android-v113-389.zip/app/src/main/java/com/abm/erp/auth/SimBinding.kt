package com.abm.erp.auth

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

/**
 * v113-320 — SIM binding, the person's own chosen option ("ক") for their
 * stated rule: "যেই ফোন নাম্বার দিয়ে আমরা রেজিস্ট্রেশন করব ওই ফোন
 * নাম্বার যদি ওই ফোনের মধ্যে না থাকে তাহলে ওই সফটওয়্যারটা যাতে লগইন না
 * হয়।"
 *
 * **What this genuinely can and cannot do**, stated plainly because the
 * difference matters for a security rule:
 *
 * Android 9+ does not let an app read the SIM's phone NUMBER.
 * `TelephonyManager.getLine1Number()` returns null on effectively every
 * Bangladeshi SIM, because operators don't provision the MSISDN onto the
 * card. bKash/Nagad don't read it either — they verify by SMS. So a
 * literal "is this the same number?" check is not implementable.
 *
 * What IS reliable is the SIM's own IDENTITY: its ICCID (the printed
 * serial on the card) or, failing that, its subscription id. Those are
 * stable per physical SIM. Binding to that gives the real property the
 * person actually wants — swap the SIM, and login stops working — via a
 * mechanism that actually exists.
 *
 * Everything here degrades honestly:
 *  - permission not granted → [readSimIdentity] returns null, and
 *    [check] reports NOT_AVAILABLE rather than pretending to verify.
 *  - no SIM in the phone → NO_SIM, a real, distinguishable state.
 *  - dual SIM → ALL inserted SIMs are considered a match, so a person
 *    with two cards isn't locked out for having their work SIM in slot 2.
 *
 * The identity is never logged and never synced — it stays in local
 * prefs on the one device, which is the only place it means anything.
 */
object SimBinding {

    enum class Result {
        /** The registered SIM is present — allow login. */
        MATCH,

        /** A SIM is present but not the registered one — block login. */
        MISMATCH,

        /** No SIM at all in the device — block login. */
        NO_SIM,

        /** Nothing bound yet; this login should bind. */
        NOT_BOUND,

        /** Permission denied or OS didn't expose it — cannot verify, so don't block. */
        NOT_AVAILABLE,
    }

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    /**
     * Every inserted SIM's stable identity. Returns null when the OS
     * won't tell us (no permission, or an OEM that withholds it) — which
     * is deliberately different from an empty list, which means "asked
     * successfully, and there is genuinely no SIM".
     */
    fun readSimIdentities(context: Context): List<String>? {
        if (!hasPermission(context)) return null
        return try {
            val subs = ContextCompat.getSystemService(context, SubscriptionManager::class.java)
            @Suppress("MissingPermission")
            val active = subs?.activeSubscriptionInfoList
            if (active != null) {
                return active.mapNotNull { info ->
                    // ICCID is the printed card serial — the most stable id
                    // available. Falls back to the subscription id, which is
                    // stable while the card stays inserted.
                    info.iccId?.takeIf { it.isNotBlank() } ?: info.subscriptionId.takeIf { it >= 0 }?.toString()
                }
            }
            // Older devices / no SubscriptionManager: fall back to TelephonyManager's serial.
            val tm = ContextCompat.getSystemService(context, TelephonyManager::class.java) ?: return null
            @Suppress("MissingPermission", "DEPRECATION")
            val serial = if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) tm.simSerialNumber else null
            if (serial.isNullOrBlank()) emptyList() else listOf(serial)
        } catch (e: SecurityException) {
            null
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Compares what's in the phone now against what was bound at
     * registration. [boundIdentity] is whatever [readSimIdentities]
     * returned when this employee first logged in on this device.
     */
    fun check(context: Context, boundIdentity: String?): Result {
        if (boundIdentity.isNullOrBlank()) return Result.NOT_BOUND
        val present = readSimIdentities(context) ?: return Result.NOT_AVAILABLE
        if (present.isEmpty()) return Result.NO_SIM
        return if (present.any { it == boundIdentity }) Result.MATCH else Result.MISMATCH
    }

    /** The identity to store when binding — the first inserted SIM. Null when unavailable. */
    fun identityToBind(context: Context): String? = readSimIdentities(context)?.firstOrNull()

    fun messageFor(result: Result): String? = when (result) {
        Result.MISMATCH -> "এই ফোনে রেজিস্টার করা সিমটি নেই — নিজের সিম ঢুকিয়ে আবার চেষ্টা করুন।"
        Result.NO_SIM -> "ফোনে কোনো সিম পাওয়া যায়নি — রেজিস্টার করা সিম ঢুকিয়ে আবার চেষ্টা করুন।"
        else -> null
    }
}
