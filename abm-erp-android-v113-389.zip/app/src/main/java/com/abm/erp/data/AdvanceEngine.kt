package com.abm.erp.data

import java.time.LocalDateTime

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * v113-384 — ADVANCE ENGINE (HRM ধাপ ৫)
 *
 * "অনেক employee অগ্রিম কিছু ধার নেয়, এইসব financial issue তো আছেই।"
 *
 * ─── কেন এটাই একমাত্র জায়গা যেখানে অ্যাপ নিজে কাটে ─────────────────────────
 * বাকি সব জায়গায় নিয়ম: **অ্যাপ দেখায়, Wing 1 সিদ্ধান্ত নেয়** — দেরি, অনুপস্থিতি,
 * টার্গেট, কোনোটাতেই আপনাআপনি কাটে না। অগ্রিমের কিস্তি ব্যতিক্রম, কারণ এটা
 * **শাস্তি নয়** — কর্মী নিজে চেয়েছে, Wing 1 অনুমোদন করেছে, আর কত কিস্তিতে
 * শোধ হবে সেটা তখনই ঠিক হয়ে গেছে। **আগে থেকে সম্মত পরিশোধ** প্রতি মাসে হাতে
 * বসাতে হলে কেউ ভুলে যেত, আর ধার চিরকাল বকেয়া থেকে যেত।
 *
 * ─── সংখ্যা নয়, টাকাই সত্য ────────────────────────────────────────────────
 * `repaid` টাকায় রাখা হয়, "কত কিস্তি হলো" নয়। কেউ হাতে বেশি ফেরত দিলে বা এক
 * মাসে কম কাটলে সংখ্যা আর টাকা আলাদা হয়ে যায় — তখন টাকাটাই আসল হিসাব।
 * ═════════════════════════════════════════════════════════════════════════════
 */
object AdvanceEngine {

    /**
     * অগ্রিমের আবেদন। যে কেউ নিজের জন্য চাইতে পারে; **অনুমোদন Wing 1-এর**,
     * ছুটির মতোই — টাকার সিদ্ধান্ত মাঠপর্যায়ে থাকা উচিত নয়।
     */
    fun request(
        employeeId: String,
        amount: Double,
        reason: String,
        installments: Int,
        onResult: (String) -> Unit = {},
    ) {
        if (amount <= 0.0) {
            onResult("পরিমাণ শূন্যের বেশি হতে হবে।")
            return
        }
        if (installments < 1 || installments > 24) {
            onResult("কিস্তি ১ থেকে ২৪-এর মধ্যে হতে হবে।")
            return
        }
        if (reason.isBlank()) {
            onResult("কারণ লিখুন — অনুমোদনকারীকে জানতে হবে কীসের জন্য।")
            return
        }
        val emp = MockRepository.employeeProfiles.value.firstOrNull { it.id == employeeId && !it.isDeleted }
        if (emp == null) {
            onResult("Employee পাওয়া যায়নি।")
            return
        }
        // একই সময়ে দুটো চলমান অগ্রিম হলে বেতন থেকে দুই কিস্তি কাটত, আর
        // কেউ হিসাব মেলাতে পারত না।
        val running = MockRepository.employeeAdvances.value.firstOrNull {
            it.employeeId == employeeId && it.status == "APPROVED" && !it.isSettled
        }
        if (running != null) {
            onResult("আগের অগ্রিম এখনো শোধ হয়নি (বাকি ৳${"%,.2f".format(running.outstanding)})।")
            return
        }
        MockRepository.saveAdvanceRequest(emp, amount, reason.trim(), installments, onResult)
    }

    /** অনুমোদন/বাতিল — কেবল Wing 1। */
    fun decide(advanceId: String, approve: Boolean, onResult: (String) -> Unit = {}) {
        if (CascadeEngine.wingOf(MockRepository.currentUser.role) != CascadeEngine.Wing.OFFICE) {
            onResult("অগ্রিম অনুমোদন কেবল Wing 1 (office) করতে পারে।")
            return
        }
        MockRepository.decideAdvance(advanceId, approve, onResult)
    }

    /**
     * এই মাসে বেতন থেকে কত কিস্তি কাটবে।
     *
     * শেষ কিস্তিতে **বাকিটুকুই** যায়, নির্ধারিত অঙ্ক নয় — নইলে ভাগ মেলাতে
     * গিয়ে দু-চার টাকা বেশি কেটে ফেলত, আর ধার ঋণাত্মক হয়ে বসে থাকত।
     */
    fun dueThisMonth(employeeId: String, advances: List<EmployeeAdvance> = MockRepository.employeeAdvances.value): Double {
        val a = advances.firstOrNull { it.employeeId == employeeId && it.status == "APPROVED" && !it.isSettled }
            ?: return 0.0
        return moneyRound(minOf(a.perInstallment, a.outstanding))
    }

    /** চলমান অগ্রিমটি — পর্দায় "কিস্তি ২/৫" দেখানোর জন্য। */
    fun runningAdvance(employeeId: String, advances: List<EmployeeAdvance> = MockRepository.employeeAdvances.value): EmployeeAdvance? =
        advances.firstOrNull { it.employeeId == employeeId && it.status == "APPROVED" && !it.isSettled }

    /**
     * কিস্তি আদায় লিখে রাখা — বেতন দেওয়ার সময় ডাকা হয়।
     *
     * পুরো শোধ হয়ে গেলে status CLOSED হয়, যাতে পরের মাসে আর কাটা না হয়
     * আর নতুন অগ্রিম চাওয়ার পথ খোলে।
     */
    fun recordRepayment(advanceId: String, amount: Double, onResult: (String) -> Unit = {}) {
        if (amount <= 0.0) {
            onResult("আদায়ের পরিমাণ শূন্যের বেশি হতে হবে।")
            return
        }
        MockRepository.recordAdvanceRepayment(advanceId, amount, onResult)
    }

    // ── সারাংশ, পর্দার উপরের সংখ্যাগুলোর জন্য ──────────────────────────────

    data class Totals(val given: Double, val recovered: Double, val outstanding: Double, val pending: Int)

    fun totals(advances: List<EmployeeAdvance> = MockRepository.employeeAdvances.value): Totals {
        val approved = advances.filter { it.status == "APPROVED" || it.status == "CLOSED" }
        return Totals(
            given = moneyRound(approved.sumOf { it.amount }),
            recovered = moneyRound(approved.sumOf { it.repaid }),
            outstanding = moneyRound(approved.sumOf { it.outstanding }),
            pending = advances.count { it.status == "PENDING" },
        )
    }
}
