package com.abm.erp.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.MockRepository
import com.abm.erp.data.UserRole
import com.abm.erp.theme.DashBg
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

/**
 * v113-77 — the person's final Home Dashboard, replacing the old widget-heavy
 * MainDashboardScreen as the app's landing screen. His exact spec:
 *
 *   "main dashboard e akn sudu 3 ta notice slot ar 5 ta module show korbe.
 *    Echara ar head e ager motoei search and qr button thakbe. Akdm nit n clean UI."
 *
 * So this screen contains, in full: a header with Search and QR Scan (same targets as
 * before — UniversalSearchDialog and the universal scanner), three notice slots (the
 * three most recent unread-first notifications, tapping opens Notifications), and the
 * five mother-module tiles. Nothing else. Every widget the old dashboard had
 * (KPI cards, trends, quick actions, smart alerts…) is deliberately absent — that data
 * all lives inside the module it belongs to now, which is the entire philosophy of the
 * restructure.
 *
 * The old `MainDashboardScreen` file is left in the codebase un-routed rather than
 * deleted this batch: several of its private widgets are candidates for reuse inside
 * module dashboards later, and deleting 61KB of working code in the same batch as a
 * navigation swap would make any compile error ambiguous. Removing it entirely is a
 * one-line follow-up once the person confirms the new Home on-device.
 */
/**
 * v113-77 (Home Dashboard base) + v113-83 (KPI card restored) — the person's final
 * spec, in two parts he gave a session apart:
 *
 *   v113-77: "sudu 3 ta notice slot ar 5 ta module... akdm nit n clean UI."
 *   v113-83 (this batch, from the DMS full-flow reference image): "Main dashboard ei
 *   design thakbe. Sudu 3 ta notice slot. Ar KPI card ta thakbe." — i.e. keep the
 *   reference poster's "Today's Overview" KPI card, but still only 3 notices (not the
 *   poster's 5), still no Quick Actions row (not mentioned as returning), still no
 *   bottom nav (not mentioned as returning) — only the KPI card is added back to the
 *   otherwise-clean v113-77 layout.
 *
 * KPI figures are computed from real, already-synced flows — nothing fabricated:
 * Sales/Collection = today's SalesInvoice/PartyCollection totals; Total Due = the
 * same dealer+retailer due sum the old dashboard used; Stock Value = Σ(on-hand qty ×
 * product's own default unit price) across `InventoryRepository.stockLevels`. No
 * percentage-change chip is shown next to any figure — that needs a trusted
 * previous-period baseline this app doesn't compute anywhere yet, and inventing one
 * would be exactly the kind of fabricated number the person's own rules forbid.
 */
@Composable
fun HomeScreen(onNavigate: (String) -> Unit) {
    val notifications by MockRepository.notifications.collectAsState()
    val topNotices = remember(notifications) {
        // Unread first, then newest — three slots exactly, per the spec.
        notifications.sortedWith(compareBy({ it.isRead }, { -it.createdAt.toEpochSecond(java.time.ZoneOffset.UTC) })).take(3)
    }
    var showSearch by remember { mutableStateOf(false) }
    val isChairman = MockRepository.currentUser.role == UserRole.CHAIRMAN

    val invoices by MockRepository.salesInvoices.collectAsState()
    val collections by MockRepository.partyCollections.collectAsState()
    val dealers by MockRepository.dealers.collectAsState()
    val retailers by MockRepository.retailers.collectAsState()
    val stockLevels by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val today = remember { java.time.LocalDate.now() }
    val todaySales = remember(invoices) { invoices.filter { !it.isDeleted && it.createdAt.toLocalDate() == today }.sumOf { it.total } }
    val todayCollection = remember(collections) { collections.filter { it.status == "VERIFIED" && it.createdAt.toLocalDate() == today }.sumOf { it.amount } }
    val totalDue = remember(dealers, retailers) { dealers.sumOf { it.dueBalance } + retailers.sumOf { it.dueBalance } }
    val stockValue = remember(stockLevels, products) {
        val priceOf = products.associate { it.id to it.defaultUnitPrice }
        stockLevels.sumOf { it.quantityOnHand * (priceOf[it.productId] ?: 0.0) }
    }

    Column(Modifier.fillMaxSize().background(DashBg)) {
        // ── Header: brand + Search + QR, nothing else ──
        // v113-221 — was hardcoded "ABM ERP" regardless of who's actually
        // running this app on their own company. Now reads the real
        // CompanySettings (name + logo, both set from the Chairman
        // module's own simplified Company Info screen) with the same
        // fallback the invoice/memo headers already used, so the brand
        // stays consistent everywhere rather than this one screen being
        // the odd one out.
        val homeCompanyList by MockRepository.companySettingsList.collectAsState()
        val homeCompany = remember(homeCompanyList) { MockRepository.companySettings() }
        Row(
            Modifier.fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(Color(0xFF0F1E3D), Color(0xFF1E3A8A))))
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (!homeCompany.companyLogoUri.isNullOrBlank()) {
                coil.compose.AsyncImage(
                    model = homeCompany.companyLogoUri, contentDescription = "Company logo",
                    modifier = Modifier.size(36.dp).clip(androidx.compose.foundation.shape.CircleShape),
                )
                Spacer(Modifier.width(10.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(homeCompany.companyName.ifBlank { "ABM ERP" }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text("Smart · Fast · Accurate", color = Color(0xFFB8C4E8), fontSize = 11.sp)
            }
            IconButton(onClick = { showSearch = true }) {
                Icon(Icons.Filled.Search, contentDescription = "Search", tint = Color.White)
            }
            IconButton(onClick = { onNavigate("universal_scanner") }) {
                Icon(Icons.Filled.QrCodeScanner, contentDescription = "QR Scan", tint = Color.White)
            }
        }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            // ── KPI card: "Today's Overview", restored per v113-83 ──
            Box(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF6D5AE6), Color(0xFF4A38C4))))
                    .padding(16.dp),
            ) {
                Column {
                    Text("Today's Overview", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("Sales", color = Color(0xFFE0DBFF), fontSize = 11.sp)
                            Text("৳${"%,.0f".format(todaySales)}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Collection", color = Color(0xFFE0DBFF), fontSize = 11.sp)
                            Text("৳${"%,.0f".format(todayCollection)}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("Total Due", color = Color(0xFFE0DBFF), fontSize = 11.sp)
                            Text("৳${"%,.0f".format(totalDue)}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Stock Value", color = Color(0xFFE0DBFF), fontSize = 11.sp)
                            Text("৳${"%,.0f".format(stockValue)}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))

            // ── Three notice slots ──
            Text("Notice", fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Spacer(Modifier.height(8.dp))
            if (topNotices.isEmpty()) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("কোনো নোটিশ নেই।", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            } else {
                topNotices.forEach { n ->
                    GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("notifications") }) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            if (!n.isRead) {
                                Box(Modifier.size(8.dp).clip(RoundedCornerShape(999.dp)).background(Color(0xFF2563EB)))
                                Spacer(Modifier.width(8.dp))
                            }
                            // v113-224 — the person's own explicit request: the
                            // Chairman Notice slot can carry a photo, not just
                            // text — shown here as a small thumbnail so the
                            // three-slot layout this whole design was built
                            // around (v113-77's own spec) doesn't grow when a
                            // notice happens to have one.
                            if (!n.imageUri.isNullOrBlank()) {
                                coil.compose.AsyncImage(
                                    model = n.imageUri, contentDescription = null,
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                    modifier = Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)),
                                )
                                Spacer(Modifier.width(8.dp))
                            }
                            Column(Modifier.weight(1f)) {
                                Text(n.title, fontWeight = FontWeight.SemiBold, color = TextPrimary, maxLines = 1)
                                Text(n.body, style = MaterialTheme.typography.labelSmall, color = TextSecondary, maxLines = 2)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }

            Spacer(Modifier.height(12.dp))

            // ── Four mother modules ── (v113-265: RMS folded into DMS —
            // its own Memo/List/Finance/Approvals/Restore live inside
            // DMS's own drawer now, not a separate tile here)
            Text("Modules", fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Spacer(Modifier.height(8.dp))
            data class Mother(val label: String, val sub: String, val emoji: String, val route: String, val start: Long, val end: Long)
            val mothers = buildList {
                add(Mother("DMS", "Dealer Management", "\uD83C\uDFEC", "dms", 0xFF2563EB, 0xFF1E3A8A))
                add(Mother("HR", "Employee Management", "\uD83D\uDC65", "hr_module", 0xFFDB2777, 0xFF9D174D))
                add(Mother("FMS", "Factory Management", "\uD83C\uDFED", "fms", 0xFFE85D4A, 0xFFC03A2B))
                if (isChairman) add(Mother("CHAIRMAN", "Full Control + AI", "\uD83D\uDC51", "chairman_module", 0xFF0F1E3D, 0xFF0A1428))
            }
            mothers.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { m ->
                        Column(
                            Modifier.weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Brush.linearGradient(listOf(Color(m.start), Color(m.end))))
                                .clickable { onNavigate(m.route) }
                                .padding(16.dp),
                        ) {
                            Text(m.emoji, fontSize = 26.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(m.label, color = Color.White, fontWeight = FontWeight.Bold)
                            Text(m.sub, color = Color(0xFFE0E7FF), fontSize = 10.sp, maxLines = 1)
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showSearch) {
        com.abm.erp.ui.search.UniversalSearchDialog(onDismiss = { showSearch = false }, onNavigate = onNavigate)
    }
}
