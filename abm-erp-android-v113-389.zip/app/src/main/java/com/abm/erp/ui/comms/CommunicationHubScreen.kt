package com.abm.erp.ui.comms

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.core.ModuleGradientHeader
import com.abm.erp.data.*
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

/**
 * Module 14 — Communication Hub. Internal Chat is channel-based (fixed
 * department channels), not full peer-to-peer DM with typing indicators —
 * see CommsRepository's own doc comment for why. Announcements/Circulars
 * are company/department broadcasts, distinct from the Chairman's single
 * image Notice already on the Dashboard (this is text-based, list-style,
 * and anyone with canCreate permission can post — not Chairman-only).
 */
class CommsViewModel : ViewModel() {
    val currentUser get() = MockRepository.currentUser
    val announcements = CommsRepository.announcements
    val circulars = CommsRepository.circulars
    fun messagesForChannel(channelId: String) = CommsRepository.messagesForChannel(channelId)
    fun sendMessage(channelId: String, message: String) = CommsRepository.sendMessage(channelId, message)
    fun postAnnouncement(title: String, body: String, onRejected: (String) -> Unit = {}) = CommsRepository.postAnnouncement(title, body, onRejected)
    fun deleteAnnouncement(id: String, onRejected: (String) -> Unit = {}) = CommsRepository.deleteAnnouncement(id, onRejected)
    fun postCircular(title: String, body: String, department: String?, onRejected: (String) -> Unit = {}) = CommsRepository.postCircular(title, body, department, onRejected)
    fun deleteCircular(id: String, onRejected: (String) -> Unit = {}) = CommsRepository.deleteCircular(id, onRejected)
    fun canPost() = PermissionManager.canCurrentUser("comms", PermissionAction.CREATE)
    fun canDelete() = PermissionManager.canCurrentUser("comms", PermissionAction.DELETE)
}

@Composable
fun CommunicationHubScreen(vm: CommsViewModel = viewModel()) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        com.abm.erp.core.ModuleWorkspaceHeader("Communication Hub", "💬", 0xFF3FA9F5, 0xFF1D78C7, iconVector = Icons.Filled.Forum, quickActions = {
            AssistChip(onClick = { tab = 0 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.Forum, null, Modifier.size(16.dp)) }, label = { Text("Chat") })
            AssistChip(onClick = { tab = 1 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.Campaign, null, Modifier.size(16.dp)) }, label = { Text("Announcements") })
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("Announcement", "ChatMessage", "Notice"))
        })
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            ScrollableTabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Chat") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Announcements") })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Circulars") })
            }
            Spacer(Modifier.height(12.dp))
            when (tab) {
                0 -> ChatTab(vm)
                1 -> AnnouncementsTab(vm)
                else -> CircularsTab(vm)
            }
        }
    }
}

@Composable
private fun ChatTab(vm: CommsViewModel) {
    var channel by remember { mutableStateOf(CommsRepository.CHANNELS.first()) }
    val messages by vm.messagesForChannel(channel).collectAsState(initial = emptyList())
    var input by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CommsRepository.CHANNELS.forEach { c -> FilterChip(selected = channel == c, onClick = { channel = c }, label = { Text("#$c") }) }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages, key = { it.id }) { m ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(m.senderName, fontWeight = FontWeight.SemiBold, color = TextPrimary, style = MaterialTheme.typography.labelMedium)
                        Text(m.createdAt.toLocalTime().toString().take(5), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Text(m.message, style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (messages.isEmpty()) item { Text("#$channel চ্যানেলে এখনো কোনো মেসেজ নেই।", color = TextSecondary) }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = input, onValueChange = { input = it }, placeholder = { Text("#$channel-এ লিখুন…") }, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            Button(onClick = { if (input.isNotBlank()) { vm.sendMessage(channel, input); input = "" } }) { Text("Send") }
        }
    }
}

@Composable
private fun AnnouncementsTab(vm: CommsViewModel) {
    val announcements by vm.announcements.collectAsState()
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "Title,Body,PostedBy\n"
                    val rows = announcements.joinToString("\n") { a -> com.abm.erp.core.toCsvRow(a.title, a.body, a.postedBy) }
                    val file = java.io.File(context.getExternalFilesDir(null), "announcements_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Announcements (${announcements.size})\n" + announcements.joinToString("\n") { "${it.title}: ${it.body}" }
                    // v113-335 — was a hand-rolled text/plain share. Now routed
                    // through the one shared helper so every screen sends the
                    // rendered image, per the person's own requirement.
                    com.abm.erp.core.shareTextSummary(context, "Announcements", summary)
                },
            )
        }
        if (vm.canPost()) {
            Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Post Announcement") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(announcements, key = { it.id }) { a ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(a.title, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(a.body, style = MaterialTheme.typography.bodyMedium)
                            Text("— ${a.postedBy}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        if (vm.canDelete()) TextButton(onClick = { vm.deleteAnnouncement(a.id) }) { Text("✕", color = DangerRed) }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Announcement", entityId = a.id, entityLabel = a.title,
                            shareText = "${a.title}\n${a.body}\n— ${a.postedBy}",
                            isDeleted = a.isDeleted,
                            onArchive = { onError -> vm.deleteAnnouncement(a.id, onRejected = onError) },
                            canArchive = vm.canDelete(),
                            csvHeader = "Title,Body,PostedBy", csvRow = com.abm.erp.core.toCsvRow(a.title, a.body, a.postedBy),
                        )
                    }
                }
            }
            if (announcements.isEmpty()) item { Text("এখনো কোনো Announcement নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var title by remember { mutableStateOf("") }
                var body by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp)) {
                    Text("New Announcement", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Message") }, modifier = Modifier.fillMaxWidth())
                    var annError by remember { mutableStateOf<String?>(null) }
                    annError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { if (vm.postAnnouncement(title, body, onRejected = { e -> annError = e }) != null) showNew = false }, enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Post to Everyone") }
                }
            }
        }
    }
}

@Composable
private fun CircularsTab(vm: CommsViewModel) {
    val circulars by vm.circulars.collectAsState()
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        if (vm.canPost()) {
            Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Circular") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(circulars, key = { it.id }) { c ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(c.title, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(c.department?.let { "Department: $it" } ?: "Company-wide", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                            Spacer(Modifier.height(4.dp))
                            Text(c.body, style = MaterialTheme.typography.bodyMedium)
                            Text("— ${c.postedBy}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        if (vm.canDelete()) TextButton(onClick = { vm.deleteCircular(c.id) }) { Text("✕", color = DangerRed) }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Circular", entityId = c.id, entityLabel = c.title,
                            shareText = "${c.title}\n${c.department ?: "Company-wide"}\n${c.body}\n— ${c.postedBy}",
                            isDeleted = c.isDeleted,
                            onArchive = { onError -> vm.deleteCircular(c.id, onRejected = onError) },
                            canArchive = vm.canDelete(),
                            csvHeader = "Title,Department,Body,PostedBy", csvRow = com.abm.erp.core.toCsvRow(c.title, c.department ?: "All", c.body, c.postedBy),
                        )
                    }
                }
            }
            if (circulars.isEmpty()) item { Text("এখনো কোনো Circular নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var title by remember { mutableStateOf("") }
                var body by remember { mutableStateOf("") }
                var department by remember { mutableStateOf<String?>(null) }
                var expanded by remember { mutableStateOf(false) }
                Column(Modifier.padding(16.dp)) {
                    Text("New Circular", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Body") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(department ?: "Company-wide") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            DropdownMenuItem(text = { Text("Company-wide") }, onClick = { department = null; expanded = false })
                            CommsRepository.CHANNELS.filter { it != "general" }.forEach { d -> DropdownMenuItem(text = { Text(d) }, onClick = { department = d; expanded = false }) }
                        }
                    }
                    var circError by remember { mutableStateOf<String?>(null) }
                    circError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { if (vm.postCircular(title, body, department, onRejected = { e -> circError = e }) != null) showNew = false }, enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Publish Circular") }
                }
            }
        }
    }
}
