package com.abm.erp.ui.hr

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.CascadeEngine
import com.abm.erp.data.EmployeeProfile
import com.abm.erp.data.MockRepository
import com.abm.erp.data.RouteEngine
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.DarazOrangeDark
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

private val TEAL = Color(0xFF0E9F9F)
private val TEAL_BG = Color(0xFFE6F7F7)

/**
 * v113-386 — Route Plan (HRM ধাপ ৭)।
 *
 * ডিজাইন r3-এর "৪ · Map + DMS indicator" — আপনার নিজের প্রস্তাব, আর এই
 * মডিউলের সবচেয়ে কাজের জিনিস: **route বানানো আর অন্ধ কাজ নয়।** মানচিত্রে
 * dealer কোথায়, retailer কোথায়, কার কত বাকি, কে কতদিন নীরব — সব দেখা যায়।
 *
 * অধিকার cascade ধরে: Wing 1 সবার, Wing 2 নিজের অধীনস্থদের, আর পদ ফাঁকা
 * হলে দায়িত্ব উপরে ওঠে। নিয়ম `RouteEngine`-এ, এখানে একটুও নেই।
 */
@Composable
fun HrRoutePlanTab() {
    val employees by MockRepository.employeeProfiles.collectAsState()
    val dealers by MockRepository.dealers.collectAsState()
    val retailers by MockRepository.retailers.collectAsState()
    val routes by MockRepository.salesRoutes.collectAsState()
    val me = MockRepository.currentUser

    val live = remember(employees) { employees.filter { !it.isDeleted } }
    val myProfile = remember(live, me) { live.firstOrNull { it.userAccountId == me.id || it.id == me.employeeId } }
    val plannable = remember(myProfile, live) {
        myProfile?.let { RouteEngine.plannableFor(it, employees = live) } ?: emptyList()
    }

    var forId by remember { mutableStateOf<String?>(null) }
    val target = remember(plannable, forId) { plannable.firstOrNull { it.id == forId } ?: plannable.firstOrNull() }
    val areaKey = remember(target) { target?.let { CascadeEngine.geoKeyOf(it) } }

    val snapshot = remember(areaKey, dealers, retailers) {
        RouteEngine.marketSnapshot(areaKey, dealers, retailers)
    }
    val existingRoute = remember(routes, target) { target?.let { RouteEngine.routesOf(it.id, routes).firstOrNull() } }

    val picked = remember { mutableStateListOf<String>() }
    var routeName by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var ok by remember { mutableStateOf(false) }

    // বিদ্যমান route থাকলে সেটাই ভরা হয় — নইলে সম্পাদনা করতে গিয়ে সব
    // আবার হাতে বাছতে হতো, আর কেউ করত না
    LaunchedEffect(existingRoute?.id) {
        picked.clear()
        existingRoute?.let { picked.addAll(it.outletIds); routeName = it.name }
        if (existingRoute == null) routeName = ""
    }

    Column(
        Modifier.fillMaxSize().background(com.abm.erp.theme.DashBg)
            .verticalScroll(rememberScrollState()).imePadding().padding(12.dp),
    ) {
        if (myProfile == null) {
            Card { Text("আপনার employee প্রোফাইল পাওয়া যায়নি।", fontSize = 11.sp, color = DangerRed) }
            return@Column
        }
        if (plannable.isEmpty()) {
            Card {
                Text(
                    "আপনার অধীনে কেউ নেই — route plan দেওয়ার মতো কাউকে পাওয়া যায়নি।",
                    fontSize = 11.sp, color = DangerRed, lineHeight = 16.sp,
                )
            }
            return@Column
        }

        // ── কার জন্য ──
        Card {
            Text("কার route", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(Modifier.height(6.dp))
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                plannable.take(12).forEach { e ->
                    val on = e.id == target?.id
                    Box(
                        Modifier.clip(RoundedCornerShape(14.dp))
                            .background(if (on) TEAL else Color.White)
                            .border(1.dp, if (on) TEAL else HairlineBorder, RoundedCornerShape(14.dp))
                            .clickable { forId = e.id }
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                    ) {
                        Text(
                            "${e.fullName.take(10)} · ${e.role.name}",
                            fontSize = 10.sp, fontWeight = FontWeight.Bold,
                            color = if (on) Color.White else TextSecondary, maxLines = 1,
                        )
                    }
                }
            }
            target?.let {
                Spacer(Modifier.height(5.dp))
                Text(
                    "এলাকা: ${areaKey ?: "বসানো হয়নি"} · ${snapshot.dealers.size} dealer · ${snapshot.retailers.size} retailer",
                    fontSize = 9.5.sp, color = TextSecondary,
                )
                // v113-389 — আজকের অগ্রগতি। RouteEngine.visitedToday() লেখা
                // হয়েছিল কিন্তু কেউ ডাকত না — অর্থাৎ route বানানো যেত, কিন্তু
                // "কতটা হলো" কোথাও দেখা যেত না, যা অর্ধেক কাজ।
                existingRoute?.let { r ->
                    val done = RouteEngine.visitedToday(r).size
                    val total = r.outletIds.size
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "আজকের ভিজিট", Modifier.weight(1f),
                            fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextPrimary,
                        )
                        Text(
                            "$done / $total",
                            fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            color = if (done >= total && total > 0) SuccessGreen else WarningAmber,
                        )
                    }
                    Spacer(Modifier.height(3.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        repeat(total.coerceAtLeast(1)) { i ->
                            Box(
                                Modifier.weight(1f).height(5.dp).clip(RoundedCornerShape(3.dp))
                                    .background(if (i < done) SuccessGreen else Color(0xFFE5E9EF)),
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))

        // ── মানচিত্র ──
        MarketMap(snapshot, picked)
        Spacer(Modifier.height(10.dp))

        // ── এই বাজারের সংখ্যা ──
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Stat("Dealer", "${snapshot.dealers.size}", DarazOrangeDark, Color(0xFFFFF3EC), Modifier.weight(1f))
            Stat("Retailer", "${snapshot.retailers.size}", TEAL, TEAL_BG, Modifier.weight(1f))
            Stat("মোট বাকি", "৳${short(snapshot.totalDue)}", DangerRed, Color(0xFFFDECEA), Modifier.weight(1f))
            Stat("নীরব ১৪দিন+", "${snapshot.stale.size}", WarningAmber, Color(0xFFFFF7E6), Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))

        // ── outlet বাছাই, ক্রম সহ ──
        Card {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("ভিজিটের ক্রম", Modifier.weight(1f), fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("${picked.size} বাছা", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TEAL)
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "তালিকায় যে ক্রমে, মাঠে সেই ক্রমেই যাবে। বাকি বেশি বা বেশিদিন নীরব — এদের আগে রাখুন।",
                fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
            )
            Spacer(Modifier.height(6.dp))
            (snapshot.dealers + snapshot.retailers).forEach { pin ->
                val idx = picked.indexOf(pin.id)
                val on = idx >= 0
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { if (on) picked.remove(pin.id) else picked.add(pin.id) }
                        .padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.size(24.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (on) TEAL else Color.White)
                            .border(1.5.dp, if (on) TEAL else HairlineBorder, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            if (on) "${idx + 1}" else "",
                            fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White,
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(pin.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
                        Text(
                            buildString {
                                append(if (pin.isDealer) "Dealer" else "Retailer")
                                if (pin.due > 0) append(" · বাকি ৳${short(pin.due)}")
                                pin.daysSinceLastOrder?.let { append(" · $it দিন আগে") }
                            },
                            fontSize = 9.5.sp,
                            color = if ((pin.daysSinceLastOrder ?: 0) > 14) DangerRed else TextSecondary,
                            maxLines = 1,
                        )
                    }
                    if (pin.lat == null || pin.lng == null) {
                        // সৎভাবে বলা — নইলে কেউ ভাবত মানচিত্রে থাকার কথা ছিল
                        Text("অবস্থান নেই", fontSize = 8.5.sp, color = WarningAmber)
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = routeName, onValueChange = { routeName = it },
            label = { Text("Route-এর নাম", fontSize = 10.sp) }, singleLine = true,
            textStyle = MaterialTheme.typography.bodySmall,
            modifier = Modifier.fillMaxWidth().height(56.dp),
        )
        Spacer(Modifier.height(8.dp))
        val ready = routeName.isNotBlank() && picked.isNotEmpty() && target != null
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(11.dp))
                .background(if (ready) DarazOrange else Color(0xFFCBD5E1))
                .clickable(enabled = ready) {
                    RouteEngine.saveRoute(
                        actorId = myProfile.id,
                        routeId = existingRoute?.id,
                        name = routeName,
                        forEmployeeId = target!!.id,
                        territoryId = target.territoryId,
                        outletIds = picked.toList(),
                        onResult = { err ->
                            ok = err.isBlank()
                            msg = if (err.isBlank()) "✔ Route সংরক্ষিত — ${picked.size} outlet" else "✖ $err"
                        },
                    )
                }
                .padding(vertical = 11.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                if (existingRoute != null) "Route হালনাগাদ" else "Route সংরক্ষণ",
                fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White,
            )
        }
        msg?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, fontSize = 11.sp, color = if (ok) SuccessGreen else DangerRed, lineHeight = 16.sp)
        }
        Spacer(Modifier.height(24.dp))
    }
}

/* ── মানচিত্র ──────────────────────────────────────────────────────────── */

/**
 * Dealer ও retailer-এর অবস্থান। বড় কমলা = dealer, ছোট সবুজাভ = retailer,
 * বাছাই করা হলে ভরাট।
 *
 * lat/lng-এর প্রকৃত পরিসর ধরে স্কেল করা হয় — স্থির সীমা ধরলে একটা এলাকার
 * সব বিন্দু এক জায়গায় জমে যেত। পরিসর শূন্য হলে (এক জায়গায় সব, বা একটাই
 * outlet) কেন্দ্রে বসানো হয়, শূন্য দিয়ে ভাগ এড়াতে।
 */
@Composable
private fun MarketMap(snapshot: RouteEngine.MarketSnapshot, picked: List<String>) {
    val pins = (snapshot.dealers + snapshot.retailers).filter { it.lat != null && it.lng != null }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color(0xFFEAF3EA))
            .border(1.dp, HairlineBorder, RoundedCornerShape(13.dp)),
    ) {
        if (pins.isEmpty()) {
            Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                Text(
                    "কোনো outlet-এর অবস্থান (lat/lng) নেই — মানচিত্র দেখানো যাচ্ছে না।",
                    fontSize = 10.5.sp, color = TextSecondary,
                )
            }
        } else {
            val minLat = pins.minOf { it.lat!! }
            val maxLat = pins.maxOf { it.lat!! }
            val minLng = pins.minOf { it.lng!! }
            val maxLng = pins.maxOf { it.lng!! }
            Canvas(Modifier.fillMaxWidth().height(210.dp).padding(10.dp)) {
                val latSpan = (maxLat - minLat).takeIf { it > 1e-6 }
                val lngSpan = (maxLng - minLng).takeIf { it > 1e-6 }
                pins.forEach { p ->
                    val x = if (lngSpan == null) size.width / 2f
                    else (((p.lng!! - minLng) / lngSpan) * size.width).toFloat()
                    // উত্তর উপরে — তাই lat উল্টো করে বসানো
                    val y = if (latSpan == null) size.height / 2f
                    else (((maxLat - p.lat!!) / latSpan) * size.height).toFloat()
                    val on = p.id in picked
                    val r = if (p.isDealer) 9f else 5.5f
                    val ink = if (p.isDealer) DarazOrange else TEAL
                    drawCircle(Color.White, radius = r + 2f, center = Offset(x, y))
                    drawCircle(
                        if (on) ink else ink.copy(alpha = 0.45f),
                        radius = r, center = Offset(x, y),
                    )
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Color(0x14000000)).padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            LegendDot(DarazOrange, "dealer")
            Spacer(Modifier.width(10.dp))
            LegendDot(TEAL, "retailer")
            Spacer(Modifier.weight(1f))
            Text("ভরাট = route-এ আছে", fontSize = 8.5.sp, color = TextSecondary)
        }
    }
}

@Composable
private fun LegendDot(ink: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).clip(RoundedCornerShape(5.dp)).background(ink))
        Spacer(Modifier.width(4.dp))
        Text(label, fontSize = 8.5.sp, color = TextSecondary)
    }
}

/* ── ছোট সহায়ক ─────────────────────────────────────────────────────────── */

@Composable
private fun Stat(label: String, value: String, ink: Color, bg: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(11.dp)).background(bg).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(label, fontSize = 8.5.sp, color = TextSecondary, maxLines = 1)
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ink, maxLines = 1)
    }
}

@Composable
private fun Card(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color.White)
            .border(1.dp, HairlineBorder, RoundedCornerShape(13.dp)).padding(11.dp),
        content = content,
    )
}

/** বড় অঙ্ক ছোট করে — "৳1.2L" পড়া সহজ, আর সারিতে জায়গাও কম লাগে। */
private fun short(v: Double): String = when {
    v >= 100000 -> "%.1fL".format(v / 100000)
    v >= 1000 -> "%.1fk".format(v / 1000)
    else -> "%,.0f".format(v)
}
