package com.abm.erp.ui.hr

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.CascadeEngine
import com.abm.erp.data.EmployeeProfile
import com.abm.erp.data.MockRepository
import com.abm.erp.data.SalaryEngine
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.DarazOrangeDark
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import java.time.LocalDate

/**
 * v113-382 — বেতনের গঠন ও মাসিক হিসাব (HRM ধাপ ৩)।
 *
 * ডিজাইন r1-এর "৩ · বেতন গঠন": চারটে টগল-আইকন, প্রতিটার কোণে সবুজ/ধূসর
 * বিন্দু = চালু/বন্ধ, নিচে **বড় করে মান**। আইকন প্রবেশপথ, সংখ্যা পাঠ্য।
 *
 * হিসাবের অংশে সংখ্যা নায়ক — **প্রাপ্য · দেওয়া · পার্থক্য**, তিনটেই আলাদা,
 * কারণ "চেয়ারম্যান মর্জিমতো কাটবে কিন্তু হিসাব একুরেটই দেখাবে"।
 */
@Composable
fun HrSalaryStructureTab() {
    val employees by MockRepository.employeeProfiles.collectAsState()
    val invoices by MockRepository.salesInvoices.collectAsState()
    val returns by MockRepository.salesReturns.collectAsState()

    val today = remember { LocalDate.now() }
    val periodStart = remember(today) { today.withDayOfMonth(1) }
    val periodEnd = remember(today) { today.withDayOfMonth(today.lengthOfMonth()) }

    val live = remember(employees) { employees.filter { !it.isDeleted } }
    var selectedId by remember { mutableStateOf<String?>(null) }
    val selected = remember(live, selectedId) {
        live.firstOrNull { it.id == selectedId } ?: live.firstOrNull()
    }
    val canEdit = CascadeEngine.wingOf(MockRepository.currentUser.role) == CascadeEngine.Wing.OFFICE

    Column(
        Modifier.fillMaxSize().background(com.abm.erp.theme.DashBg)
            .verticalScroll(rememberScrollState()).imePadding().padding(12.dp),
    ) {
        if (live.isEmpty()) {
            Card { Text("কোনো employee নেই।", fontSize = 11.sp, color = TextSecondary) }
            return@Column
        }

        // ── কার হিসাব ──
        Card {
            Text("কার বেতন", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(Modifier.height(6.dp))
            Row(
                Modifier.fillMaxWidth().horizontalScrollable(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                live.take(12).forEach { e ->
                    val on = e.id == selected?.id
                    Box(
                        Modifier.clip(RoundedCornerShape(14.dp))
                            .background(if (on) DarazOrange else Color.White)
                            .border(1.dp, if (on) DarazOrange else HairlineBorder, RoundedCornerShape(14.dp))
                            .clickable { selectedId = e.id }
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                    ) {
                        Text(
                            e.fullName.take(12),
                            fontSize = 10.5.sp, fontWeight = FontWeight.Bold,
                            color = if (on) Color.White else TextSecondary, maxLines = 1,
                        )
                    }
                }
            }
        }

        val emp = selected ?: return@Column
        Spacer(Modifier.height(10.dp))
        StructureCard(emp, canEdit)
        Spacer(Modifier.height(10.dp))
        BreakdownCard(emp, periodStart, periodEnd, live, invoices, returns)
        Spacer(Modifier.height(24.dp))
    }
}

/* ── গঠন: চারটে টগল ───────────────────────────────────────────────────── */

@Composable
private fun StructureCard(emp: EmployeeProfile, canEdit: Boolean) {
    var base by remember(emp.id) { mutableStateOf(fmtIn(emp.basePayMonthly)) }
    var own by remember(emp.id) { mutableStateOf(fmtIn(emp.ownCommissionPct)) }
    var ovr by remember(emp.id) { mutableStateOf(fmtIn(emp.overrideCommissionPct)) }
    var tada by remember(emp.id) { mutableStateOf(fmtIn(emp.taDaMonthly)) }
    var msg by remember(emp.id) { mutableStateOf<String?>(null) }
    var ok by remember(emp.id) { mutableStateOf(false) }

    Card {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("বেতনের গঠন", Modifier.weight(1f), fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(
                "${emp.role.name} · ${if (CascadeEngine.wingOf(emp.role) == CascadeEngine.Wing.OFFICE) "Wing 1" else "Wing 2"}",
                fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DarazOrangeDark,
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
            ToggleIcon(Icons.Filled.Payments, "বেসিক", base, "৳", Color(0xFF22A06B))
            ToggleIcon(Icons.Filled.LocalOffer, "নিজের কমিশন", own, "%", DarazOrangeDark)
            ToggleIcon(Icons.Filled.Groups, "Override", ovr, "%", Color(0xFF9C6EFF))
            ToggleIcon(Icons.Filled.LocalShipping, "TA/DA", tada, "৳", Color(0xFF2563EB))
        }
        Spacer(Modifier.height(10.dp))
        if (canEdit) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                NumField(base, "বেসিক ৳", Modifier.weight(1f)) { base = it }
                NumField(own, "নিজের %", Modifier.weight(1f)) { own = it }
            }
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                NumField(ovr, "Override %", Modifier.weight(1f)) { ovr = it }
                NumField(tada, "TA/DA ৳", Modifier.weight(1f)) { tada = it }
            }
            Spacer(Modifier.height(9.dp))
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(DarazOrange)
                    .clickable {
                        SalaryEngine.setStructure(
                            employeeId = emp.id,
                            basePay = base.toDoubleOrNull() ?: 0.0,
                            ownPct = own.toDoubleOrNull() ?: 0.0,
                            overridePct = ovr.toDoubleOrNull() ?: 0.0,
                            taDa = tada.toDoubleOrNull() ?: 0.0,
                            onResult = { err ->
                                ok = err.isBlank()
                                msg = if (err.isBlank()) "✔ সংরক্ষিত" else "✖ $err"
                            },
                        )
                    }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) { Text("গঠন সংরক্ষণ", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White) }
        } else {
            Text(
                "গঠন বদলানোর অধিকার কেবল Wing 1-এর (office)।",
                fontSize = 10.5.sp, color = TextSecondary, lineHeight = 15.sp,
            )
        }
        msg?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, fontSize = 11.sp, color = if (ok) SuccessGreen else DangerRed)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "শূন্য মানে বন্ধ। নিজের বিক্রিতে এক হার, অধীনস্থদের বিক্রিতে override হার — " +
                "SR-এর override শূন্য, কারণ তার নিচে কেউ নেই।",
            fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
        )
    }
}

@Composable
private fun ToggleIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    raw: String,
    unit: String,
    accent: Color,
) {
    val v = raw.toDoubleOrNull() ?: 0.0
    val on = v > 0.0
    Column(Modifier.width(74.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.BottomEnd) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(22.dp))
                    .background(if (on) DarazOrange.copy(alpha = 0.10f) else Color(0xFFF7F8FA))
                    .border(1.5.dp, if (on) DarazOrange else HairlineBorder, RoundedCornerShape(22.dp)),
                contentAlignment = Alignment.Center,
            ) { Icon(icon, contentDescription = label, tint = if (on) DarazOrange else accent, modifier = Modifier.size(20.dp)) }
            // চালু/বন্ধ বোঝানোর ছোট বিন্দু — টগল-বোধটা এখান থেকেই আসে
            Box(
                Modifier.size(14.dp).clip(RoundedCornerShape(7.dp))
                    .background(if (on) SuccessGreen else Color(0xFFCBD5E1))
                    .border(2.dp, Color.White, RoundedCornerShape(7.dp)),
            )
        }
        Spacer(Modifier.height(3.dp))
        Text(label, fontSize = 8.5.sp, color = TextSecondary, maxLines = 1)
        Text(
            if (on) (if (unit == "৳") "৳${num(v)}" else "${num(v)}%") else "বন্ধ",
            fontSize = 11.sp, fontWeight = FontWeight.Bold,
            color = if (on) DarazOrangeDark else Color(0xFFCBD5E1), maxLines = 1,
        )
    }
}

@Composable
private fun NumField(value: String, label: String, modifier: Modifier = Modifier, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { t -> onChange(t.filter { it.isDigit() || it == '.' }) },
        label = { Text(label, fontSize = 10.sp) },
        singleLine = true,
        textStyle = MaterialTheme.typography.bodySmall,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier.height(56.dp),
    )
}

/* ── মাসিক হিসাব: প্রাপ্য · দেওয়া · পার্থক্য ─────────────────────────── */

@Composable
private fun BreakdownCard(
    emp: EmployeeProfile,
    periodStart: LocalDate,
    periodEnd: LocalDate,
    employees: List<EmployeeProfile>,
    invoices: List<com.abm.erp.data.SalesInvoice>,
    returns: List<com.abm.erp.data.SalesReturn>,
) {
    var cut by remember(emp.id) { mutableStateOf("") }
    var cutReason by remember(emp.id) { mutableStateOf("") }

    val b = remember(emp, invoices, returns, cut, cutReason, employees) {
        SalaryEngine.compute(
            employee = emp,
            periodStart = periodStart,
            periodEnd = periodEnd,
            manualDeduction = cut.toDoubleOrNull() ?: 0.0,
            manualDeductionReason = cutReason,
            employees = employees,
            invoices = invoices,
            returns = returns,
        )
    }

    Card {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("এই মাসের হিসাব", Modifier.weight(1f), fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text("${periodStart.month.name.take(3)} ${periodStart.year}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DarazOrangeDark)
        }
        Spacer(Modifier.height(7.dp))

        Line("বেসিক", "৳${num(b.basePay)}", TextPrimary)
        if (b.ownCommissionPct > 0) {
            Line("নিজের বিক্রি (আদায়) ৳${num(b.ownSales)} → ${num(b.ownCommissionPct)}%", "৳${num(b.ownCommission)}", SuccessGreen)
        }
        if (b.overrideCommissionPct > 0) {
            Line("অধীনস্থ (আদায়) ৳${num(b.teamSales)} → ${num(b.overrideCommissionPct)}%", "৳${num(b.overrideCommission)}", SuccessGreen)
        }
        if (b.taDa > 0) Line("TA/DA", "৳${num(b.taDa)}", TextPrimary)
        if (b.returnDeduction > 0) Line("Return সমন্বয়", "−৳${num(b.returnDeduction)}", DangerRed)

        // Return কেন কাটল — "কত কাটলো তার visually দেখা যাবে কারণ সহ"
        b.returnReasons.forEach {
            Text("   • $it", fontSize = 9.5.sp, color = DangerRed, lineHeight = 14.sp)
        }

        Divider(Modifier.padding(vertical = 7.dp))
        Row(Modifier.fillMaxWidth()) {
            Text("প্রাপ্য", Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text("৳${num(b.payable)}", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = DarazOrange)
        }

        Spacer(Modifier.height(9.dp))
        Text("Wing 1-এর কর্তন (ঐচ্ছিক)", fontSize = 10.sp, color = TextSecondary)
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            NumField(cut, "কত ৳", Modifier.weight(1f)) { cut = it }
            OutlinedTextField(
                value = cutReason, onValueChange = { cutReason = it },
                label = { Text("কারণ", fontSize = 10.sp) }, singleLine = true,
                textStyle = MaterialTheme.typography.bodySmall,
                modifier = Modifier.weight(1.4f).height(56.dp),
            )
        }

        // v113-389 — অগ্রিমের কিস্তি আলাদা করে দেখানো। টাকা কমছে অথচ কারণ
        // দেখা যাচ্ছে না — এমন হলে কর্মী ভাবত বেতন কম দেওয়া হয়েছে।
        if (b.advanceInstalment > 0) {
            Spacer(Modifier.height(5.dp))
            Row(Modifier.fillMaxWidth()) {
                Text(b.advanceLabel.ifBlank { "অগ্রিমের কিস্তি" }, Modifier.weight(1f), fontSize = 11.sp, color = TextSecondary)
                Text("−৳${num(b.advanceInstalment)}", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFFF5A623))
            }
        }

        if (b.manualDeduction > 0 || b.advanceInstalment > 0) {
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth()) {
                Text("দেওয়া হলো", Modifier.weight(1f), fontSize = 11.5.sp, color = TextPrimary)
                Text("৳${num(b.paid)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            }
            if (b.manualDeduction > 0) {
                Row(Modifier.fillMaxWidth()) {
                    Text(
                        "কর্তন — ${b.manualDeductionReason.ifBlank { "কারণ লেখা হয়নি" }}",
                        Modifier.weight(1f), fontSize = 11.sp, color = DangerRed,
                    )
                    Text("−৳${num(b.manualDeduction)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DangerRed)
                }
            }
        }

        // v113-389 — কিস্তি "কেটেছি" বলে লিখে রাখার বোতাম।
        //
        // এটা ছাড়া অর্ধেক কাজ হয়ে থাকত: হিসাবে কিস্তি বাদ যেত, কিন্তু
        // অগ্রিমের `repaid` কখনো বাড়ত না — তাই বকেয়া চিরকাল একই থাকত আর
        // প্রতি মাসে একই কিস্তি কাটতে থাকত, অনন্তকাল।
        //
        // বোতামটা আলাদা রাখা হয়েছে, আপনাআপনি নয়: বেতন সত্যিই দেওয়া হলো
        // কি না সেটা অ্যাপ জানে না। যে দিচ্ছে সে-ই বলবে।
        if (b.advanceInstalment > 0) {
            Spacer(Modifier.height(9.dp))
            var recorded by remember(emp.id) { mutableStateOf(false) }
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                    .background(if (recorded) Color(0xFFE8F7F0) else Color(0xFFFFF7E6))
                    .border(1.dp, if (recorded) SuccessGreen else Color(0xFFF5A623), RoundedCornerShape(10.dp))
                    .clickable(enabled = !recorded) {
                        com.abm.erp.data.AdvanceEngine.runningAdvance(emp.id)?.let { adv ->
                            com.abm.erp.data.AdvanceEngine.recordRepayment(adv.id, b.advanceInstalment) {
                                if (it.isBlank()) recorded = true
                            }
                        }
                    }
                    .padding(vertical = 9.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    if (recorded) "✔ কিস্তি আদায় লেখা হয়েছে" else "বেতন দেওয়া হয়েছে — কিস্তি আদায় লিখুন",
                    fontSize = 11.5.sp, fontWeight = FontWeight.Bold,
                    color = if (recorded) SuccessGreen else Color(0xFFB87500),
                )
            }
        }

        Spacer(Modifier.height(7.dp))
        Text(
            "কমিশন গোনা হয় **আদায়ের** উপর, বিক্রির উপর নয় — বাকিতে যাওয়া মালের কমিশন " +
                "টাকা ওঠার পরেই যোগ হয়। অ্যাপ নিজে কিছু কাটে না; কর্তন Wing 1-এর সিদ্ধান্ত।",
            fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
        )
    }
}

/* ── ছোট সহায়ক ─────────────────────────────────────────────────────────── */

@Composable
private fun Line(label: String, value: String, tint: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, Modifier.weight(1f), fontSize = 11.sp, color = TextSecondary, lineHeight = 15.sp)
        Text(value, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = tint)
    }
}

@Composable
private fun Card(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color.White)
            .border(1.dp, HairlineBorder, RoundedCornerShape(13.dp)).padding(11.dp),
        content = content,
    )
}

/** সারি লম্বা হলে পাশে সরানো যায় — কর্মী বেশি হলে চিপ গুলো আটকে যেত। */
@Composable
private fun Modifier.horizontalScrollable(): Modifier =
    this.then(Modifier.horizontalScroll(rememberScrollState()))

private fun num(v: Double): String =
    if (kotlin.math.abs(v % 1.0) < 0.001) "%,.0f".format(v) else "%,.2f".format(v)

private fun fmtIn(v: Double): String = if (v <= 0.0) "" else num(v)
