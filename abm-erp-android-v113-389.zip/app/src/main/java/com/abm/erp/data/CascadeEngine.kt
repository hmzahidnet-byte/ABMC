package com.abm.erp.data

import java.time.LocalDate

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * v113-380 — CASCADE ENGINE
 *
 * এই ফাইলটাই সংগঠনের একমাত্র সত্য। "কে কার উপরে", "পদ ফাঁকা হলে কে",
 * "অমুক তারিখে কে দায়িত্বে ছিল" — এই প্রশ্নগুলোর উত্তর **শুধু এখান থেকেই**
 * আসবে। টার্গেট বণ্টন, dealer assign, approval routing, route plan — চারটেই
 * এই এক জায়গায় জিজ্ঞেস করবে।
 *
 * কেন এক জায়গায়: এই ফাইল লেখার আগে অ্যাপে চারটে আলাদা নিয়ম চলত —
 *   · approve করার ক্ষমতা → PermissionManager-এর role.ordinal
 *   · কে কোন dealer দেখবে → assignedEmployeeId মেলানো
 *   · কে dealer assign করবে → DMS-এর ফর্মে হাতে বাছাই
 *   · ভ্যাকেন্সি হলে কে → কোথাও কিছু নেই
 * DMS-এ এই ছড়ানো-ছিটানো নিয়মই বারবার ভুল দেখিয়েছে (v113-379-এ dealer দুই
 * উৎস থেকে পড়া হচ্ছিল বলে সারা দিন খুঁজতে হয়েছিল)। HRM-এ শুরু থেকেই এক
 * জায়গায়।
 *
 * ─── দুই wing ───────────────────────────────────────────────────────────────
 *   Wing 1 (Office) : CHAIRMAN · MD · GM · AGM · NSM      — এলাকা নেই, জাতীয়
 *   Wing 2 (Field)  : DSM · RSM · ASM · TSM · SR          — এলাকা আছে
 *   DSM = সংযোগস্থল: field-এর সবার উপরে, office-এর সবার নিচে।
 *
 * ─── এলাকার স্তর (Wing 2) ───────────────────────────────────────────────────
 *   SR → রুট · TSM → টেরিটরি · ASM → এরিয়া · RSM → রিজিওন · DSM → ডিভিশন
 *
 * ─── ভ্যাকেন্সির সংজ্ঞা ─────────────────────────────────────────────────────
 * "ওই এলাকায় ওই role-এ active কোনো employee নেই বলেই সেটা vacant।"
 * আলাদা কোনো Vacancy টেবিল দেখা হয় না — employee তালিকা দেখেই। তাই দুটো
 * জিনিস কখনো অমিল হতে পারে না।
 *
 * ─── কেন সব উত্তর সময়-ভিত্তিক ──────────────────────────────────────────────
 * প্রশ্ন কখনোই "কে দায়িত্বে?" নয়, সবসময় "অমুক তারিখে কে দায়িত্বে ছিল?"।
 * নইলে মে মাসে গিয়ে জানুয়ারির হিসাব খুললে আজকের লোকের নামে দেখাত, অথচ কাজটা
 * করেছিল অন্য কেউ — বেতন, কমিশন, মূল্যায়ন সব ভুল হয়ে যেত।
 *
 * এই engine শুধু **লাইভ প্রশ্নের** উত্তর দেয়। ঘটে যাওয়া রেকর্ডে সেই মুহূর্তের
 * উত্তর **লিখে রাখতে হবে** (invoice-এ "করিম, ভ্যাকেন্সি পূরণে")। দুটো আলাদা
 * না রাখলে ইতিহাস প্রতিবার বদলাবে।
 * ═════════════════════════════════════════════════════════════════════════════
 */
object CascadeEngine {

    // ─────────────────────────────────────────────────────────────────────────
    // Wing ও পদক্রম
    // ─────────────────────────────────────────────────────────────────────────

    enum class Wing { OFFICE, FIELD }

    /**
     * ছোট থেকে বড়। এটাই একমাত্র জায়গা যেখানে পদক্রম লেখা — অন্য কোথাও
     * role.ordinal বা হাতে-লেখা তুলনা থাকা চলবে না, নইলে দুই জায়গায় দুই ক্রম
     * হয়ে যাবে।
     *
     * UserRole enum-এর নিজের ordinal ব্যবহার করা হয়নি ইচ্ছাকৃতভাবে: ওখানে
     * DSM বসানো আছে RSM-এর পরে (SR, TSM, ASM, RSM, DSM, NSM…), অথচ বাস্তবে
     * DSM-এর নিচে RSM — অর্থাৎ enum-এর ক্রম ব্যবসার ক্রম নয়। enum বদলালে
     * পুরনো serialized ডেটা ভাঙত, তাই ক্রমটা এখানে আলাদা করে লেখা।
     */
    val RANK: List<UserRole> = listOf(
        UserRole.SR,
        UserRole.TSM,
        UserRole.ASM,
        UserRole.RSM,
        UserRole.DSM,
        UserRole.NSM,
        UserRole.AGM,
        UserRole.GM,
        UserRole.MD,
        UserRole.CHAIRMAN,
    )

    val FIELD_ROLES: List<UserRole> = listOf(UserRole.SR, UserRole.TSM, UserRole.ASM, UserRole.RSM, UserRole.DSM)
    val OFFICE_ROLES: List<UserRole> = listOf(UserRole.NSM, UserRole.AGM, UserRole.GM, UserRole.MD, UserRole.CHAIRMAN)

    fun wingOf(role: UserRole): Wing = if (role in FIELD_ROLES) Wing.FIELD else Wing.OFFICE

    /** ছোট সংখ্যা = নিচের পদ। অচেনা role এলে সবচেয়ে নিচে ধরা হয় — নীরবে উপরে তোলা বিপজ্জনক। */
    fun rankOf(role: UserRole): Int = RANK.indexOf(role).let { if (it < 0) 0 else it }

    fun isAbove(higher: UserRole, lower: UserRole): Boolean = rankOf(higher) > rankOf(lower)

    /** পদক্রমে ঠিক পরের ধাপ। CHAIRMAN-এর উপরে কেউ নেই, তাই null। */
    fun roleAbove(role: UserRole): UserRole? = RANK.getOrNull(rankOf(role) + 1)

    // ─────────────────────────────────────────────────────────────────────────
    // এলাকার স্তর
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * কোন পদ কোন স্তরে কাজ করে। Wing 1-এর জন্য NATIONAL — তাদের এলাকা নেই,
     * তাই এলাকা ধরে ভ্যাকেন্সি খোঁজা ওখানে অর্থহীন।
     */
    enum class GeoLevel { ROUTE, TERRITORY, AREA, REGION, DIVISION, NATIONAL }

    fun geoLevelOf(role: UserRole): GeoLevel = when (role) {
        UserRole.SR -> GeoLevel.ROUTE
        UserRole.TSM -> GeoLevel.TERRITORY
        UserRole.ASM -> GeoLevel.AREA
        UserRole.RSM -> GeoLevel.REGION
        UserRole.DSM -> GeoLevel.DIVISION
        else -> GeoLevel.NATIONAL
    }

    /**
     * একজন employee কোন এলাকায় বসে, সেটা তার পদের স্তর অনুযায়ী পড়া।
     *
     * খালি স্ট্রিং আর null এক করে দেওয়া হয়েছে (`ifBlank { null }`) — কারণ
     * EmployeeProfile-এ region/area খালি স্ট্রিং হিসেবে থাকে কিন্তু territoryId
     * nullable, আর "খালি" মানে দুটো ক্ষেত্রেই একই: এলাকা বসানো হয়নি।
     */
    fun geoKeyOf(emp: EmployeeProfile): String? = when (geoLevelOf(emp.role)) {
        GeoLevel.ROUTE -> emp.routeId?.ifBlank { null }
        GeoLevel.TERRITORY -> emp.territoryId?.ifBlank { null }
        GeoLevel.AREA -> emp.area.ifBlank { null }
        GeoLevel.REGION -> emp.region.ifBlank { null }
        GeoLevel.DIVISION -> emp.divisionId?.ifBlank { null }
        GeoLevel.NATIONAL -> null
    }

    /**
     * এই employee-র নিজের **উপরের স্তরের** এলাকা কী।
     *
     * একজন SR-এর রুট রুট-৪, কিন্তু তার TSM বসে টেরিটরি-১২-তে। ধাপ ৩-এ উপরে
     * উঠতে গেলে এই মানচিত্রটা লাগে — নইলে "রুট-৪-এর TSM" খুঁজতে গিয়ে কিছুই
     * পাওয়া যেত না।
     */
    fun geoKeyAt(emp: EmployeeProfile, level: GeoLevel): String? = when (level) {
        GeoLevel.ROUTE -> emp.routeId?.ifBlank { null }
        GeoLevel.TERRITORY -> emp.territoryId?.ifBlank { null }
        GeoLevel.AREA -> emp.area.ifBlank { null }
        GeoLevel.REGION -> emp.region.ifBlank { null }
        GeoLevel.DIVISION -> emp.divisionId?.ifBlank { null }
        GeoLevel.NATIONAL -> null
    }

    // ─────────────────────────────────────────────────────────────────────────
    // "সক্রিয়" — সময় ধরে
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * এই তারিখে employee কি সত্যিই কর্মরত ছিল?
     *
     * তিনটে শর্ত, তিনটেই লাগে:
     *   ১. status কাজ করার মতো (ছুটিতে থাকা লোকও দায়িত্বে — ON_LEAVE বাদ যায়
     *      না, কারণ ছুটি মানে চাকরি শেষ নয়; SUSPENDED বাদ যায়, কারণ তার
     *      ক্ষমতাই স্থগিত)
     *   ২. onboarding শেষ হয়েছে (DRAFT/SUBMITTED অবস্থায় কেউ দায়িত্ব পায় না)
     *   ৩. তারিখটা joining ও exit-এর মাঝে
     *
     * joiningDate null হলে বাধা দেওয়া হয় না — পুরনো রেকর্ডে তারিখ লেখাই হয়নি,
     * আর সেই কারণে কাউকে "অস্তিত্বহীন" ধরে নেওয়া তার চেয়ে বড় ভুল।
     */
    fun isActiveOn(emp: EmployeeProfile, date: LocalDate): Boolean {
        val statusOk = when (emp.status) {
            EmployeeStatus.ACTIVE, EmployeeStatus.PROBATION,
            EmployeeStatus.CONFIRMED, EmployeeStatus.ON_LEAVE -> true
            else -> false
        }
        if (!statusOk) return false
        if (emp.onboardingStatus != EmployeeOnboardingStatus.ACTIVE) return false
        emp.joiningDate?.let { if (date.isBefore(it)) return false }
        emp.exitDate?.let { if (date.isAfter(it)) return false }
        return true
    }

    // ─────────────────────────────────────────────────────────────────────────
    // মূল প্রশ্ন: "অমুক তারিখে, অমুক এলাকায়, অমুক পদে কে ছিল?"
    // ─────────────────────────────────────────────────────────────────────────

    /** উত্তর কীভাবে পাওয়া গেল — রেকর্ডে লিখে রাখার জন্য, যাতে ইতিহাস কথা বলে। */
    enum class HolderBasis {
        /** নিজের পদে, নিজের এলাকায় — স্বাভাবিক অবস্থা */
        OWN_POST,
        /** Chairman হাতে বসিয়েছেন */
        OVERRIDE,
        /** পদ ফাঁকা, উপরের কেউ দায়িত্ব চালাচ্ছেন */
        VACANCY_COVER,
        /** কাউকেই পাওয়া যায়নি — চেইনের শেষ */
        CHAIRMAN_FALLBACK,
    }

    data class Holder(
        val employee: EmployeeProfile?,
        val basis: HolderBasis,
        /** কোন পদের দায়িত্ব চালাচ্ছেন (ফাঁকা পদ পূরণের ক্ষেত্রে নিজের পদের চেয়ে আলাদা) */
        val coveringRole: UserRole,
        val geoKey: String?,
    ) {
        /** রেকর্ডে লিখে রাখার মতো এক লাইন — পরে কেউ প্রশ্ন করলে এটাই উত্তর। */
        val auditLabel: String
            get() = when {
                employee == null -> "কেউ পাওয়া যায়নি"
                basis == HolderBasis.OWN_POST -> "${employee.fullName} (${employee.role.name})"
                basis == HolderBasis.OVERRIDE -> "${employee.fullName} (${employee.role.name}) — Chairman override"
                basis == HolderBasis.VACANCY_COVER -> "${employee.fullName} (${employee.role.name}) — ${coveringRole.name} ভ্যাকেন্সি পূরণে"
                else -> "${employee.fullName} — চেইনের শেষ"
            }
    }

    /**
     * Chairman-এর হাতে বসানো ব্যতিক্রম। নিয়ম নিয়ম করে হাত-পা বেঁধে ফেলা যায় না,
     * কিন্তু override হবে **ব্যতিক্রম**, ডিফল্ট নয় — আর কারণ ছাড়া নয়।
     */
    data class Override(
        val role: UserRole,
        val geoKey: String,
        val employeeId: String,
        val fromDate: LocalDate,
        val toDate: LocalDate?,
        val reason: String,
    ) {
        fun coversOn(date: LocalDate): Boolean =
            !date.isBefore(fromDate) && (toDate == null || !date.isAfter(toDate))
    }

    /**
     * ★ Engine-এর হৃদয়। বাকি সব ফাংশন এটাকেই ডাকে।
     *
     * ধাপ ১ — ওই তারিখে ওই এলাকায় ওই পদে সক্রিয় কেউ আছে? → সে
     * ধাপ ২ — না থাকলে override আছে? → সে
     * ধাপ ৩ — তাও না? → উপরের স্তরে ওঠো, যাকে প্রথম পাওয়া যায়
     * ধাপ ৪ — কাউকেই না? → Chairman
     *
     * @param role কোন পদের দায়িত্ব খুঁজছি
     * @param geoKey কোন এলাকায় (Wing 1-এর জন্য null)
     * @param date কোন তারিখে — ডিফল্ট আজ, কিন্তু পুরনো হিসাবে অতীতের তারিখ
     */
    fun holderOf(
        role: UserRole,
        geoKey: String?,
        date: LocalDate,
        employees: List<EmployeeProfile>,
        overrides: List<Override> = emptyList(),
    ): Holder {
        val active = employees.filter { isActiveOn(it, date) }

        // ধাপ ১ — নিজের পদে, নিজের এলাকায়
        active.firstOrNull { it.role == role && matchesGeo(it, geoKey) }?.let {
            return Holder(it, HolderBasis.OWN_POST, role, geoKey)
        }

        // ধাপ ২ — Chairman override
        overrides.firstOrNull { it.role == role && it.geoKey == geoKey && it.coversOn(date) }
            ?.let { ov ->
                active.firstOrNull { it.id == ov.employeeId }?.let {
                    return Holder(it, HolderBasis.OVERRIDE, role, geoKey)
                }
                // override-এ যাকে বসানো হয়েছিল সে আর সক্রিয় নেই — override
                // উপেক্ষা করে স্বাভাবিক cascade চলবে। নীরবে ভুল লোক দেখানোর
                // চেয়ে নিয়মে ফিরে যাওয়া নিরাপদ।
            }

        // ধাপ ৩ — উপরে ওঠো
        var current = role
        // মূল employee-টা কে, তার এলাকা-তথ্য থেকে উপরের স্তরের key বের করতে হয়।
        // সেটা পেতে ওই এলাকায় *যে কেউ* একজনকে ধরা হয় — এলাকা এক হলে উপরের
        // স্তরের key-ও এক, তাই কে সেটা গুরুত্বপূর্ণ নয়।
        val anchor = employees.firstOrNull { it.role == role && matchesGeo(it, geoKey) }
            ?: employees.firstOrNull { matchesGeo(it, geoKey) }

        while (true) {
            val next = roleAbove(current) ?: break
            val nextLevel = geoLevelOf(next)
            val nextKey = if (nextLevel == GeoLevel.NATIONAL) null else anchor?.let { geoKeyAt(it, nextLevel) }

            active.firstOrNull { it.role == next && matchesGeo(it, nextKey) }?.let {
                return Holder(it, HolderBasis.VACANCY_COVER, role, geoKey)
            }
            current = next
        }

        // ধাপ ৪ — Chairman। চেইনের শেষ, তাই কোনো কাজ কখনো মালিকহীন থাকে না।
        // Chairman না পাওয়া গেলেও basis একই — employee null থাকলে auditLabel
        // নিজেই "কেউ পাওয়া যায়নি" বলবে, তাই আলাদা শাখার দরকার নেই।
        val chairman = active.firstOrNull { it.role == UserRole.CHAIRMAN }
        return Holder(chairman, HolderBasis.CHAIRMAN_FALLBACK, role, geoKey)
    }

    /**
     * এলাকা মেলে কি না। Wing 1-এর জন্য geoKey null, আর তখন এলাকা দেখা হয় না —
     * তারা জাতীয়, তাদের এলাকা নেই।
     */
    private fun matchesGeo(emp: EmployeeProfile, geoKey: String?): Boolean {
        if (geoLevelOf(emp.role) == GeoLevel.NATIONAL) return true
        if (geoKey == null) return false
        return geoKeyOf(emp).equals(geoKey, ignoreCase = true)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // চেইন — উপরে ও নিচে
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * এই employee-র উপরে কে। প্রথমে তার নিজের directManager (হাতে বসানো),
     * সেটা না থাকলে বা সে নিষ্ক্রিয় হলে পদক্রম ধরে খোঁজা।
     *
     * directManager-কে অগ্রাধিকার দেওয়া হয়েছে ইচ্ছাকৃতভাবে: বাস্তবে কখনো
     * ব্যতিক্রম থাকে (একজন SR সরাসরি ASM-কে রিপোর্ট করে), আর সেটা নীরবে
     * উপেক্ষা করলে অ্যাপ বাস্তবের সাথে মিলবে না।
     */
    fun managerOf(
        emp: EmployeeProfile,
        date: LocalDate,
        employees: List<EmployeeProfile>,
        overrides: List<Override> = emptyList(),
    ): Holder {
        emp.directManagerId?.ifBlank { null }?.let { mid ->
            employees.firstOrNull { it.id == mid && isActiveOn(it, date) }?.let {
                return Holder(it, HolderBasis.OWN_POST, it.role, geoKeyOf(it))
            }
        }
        val above = roleAbove(emp.role) ?: return Holder(null, HolderBasis.CHAIRMAN_FALLBACK, emp.role, null)
        val aboveLevel = geoLevelOf(above)
        val key = if (aboveLevel == GeoLevel.NATIONAL) null else geoKeyAt(emp, aboveLevel)
        return holderOf(above, key, date, employees, overrides)
    }

    /**
     * এই employee-র সরাসরি অধীনস্থরা। পদক্রমে ঠিক এক ধাপ নিচে, এবং তার
     * এলাকার ভেতরে।
     *
     * directManagerId মেলানোকেও ধরা হয়েছে — কেউ হাতে অন্য কাউকে assign করলে
     * সে-ও অধীনস্থ, এলাকা যাই হোক।
     */
    fun directReportsOf(
        emp: EmployeeProfile,
        date: LocalDate,
        employees: List<EmployeeProfile>,
    ): List<EmployeeProfile> {
        val below = RANK.getOrNull(rankOf(emp.role) - 1) ?: return emptyList()
        val myLevel = geoLevelOf(emp.role)
        val myKey = geoKeyOf(emp)
        return employees.filter { candidate ->
            if (!isActiveOn(candidate, date)) return@filter false
            if (candidate.id == emp.id) return@filter false
            val byManager = candidate.directManagerId == emp.id
            val byChain = candidate.role == below &&
                (myLevel == GeoLevel.NATIONAL || geoKeyAt(candidate, myLevel).equals(myKey, ignoreCase = true))
            byManager || byChain
        }
    }

    /** সব স্তর মিলিয়ে অধীনস্থদের পুরো গাছ — টার্গেটের যোগফল ও override কমিশনের জন্য। */
    fun allReportsOf(
        emp: EmployeeProfile,
        date: LocalDate,
        employees: List<EmployeeProfile>,
    ): List<EmployeeProfile> {
        val out = LinkedHashMap<String, EmployeeProfile>()
        val queue = ArrayDeque(directReportsOf(emp, date, employees))
        // ঘুরপথ (A-এর ম্যানেজার B, B-এর ম্যানেজার A) হাতে বসানো ডেটায় সম্ভব,
        // তাই দেখা-হয়ে-যাওয়া id মনে রাখা হয় — নইলে অসীম লুপে আটকাত।
        while (queue.isNotEmpty()) {
            val next = queue.removeFirst()
            if (out.containsKey(next.id) || next.id == emp.id) continue
            out[next.id] = next
            queue.addAll(directReportsOf(next, date, employees))
        }
        return out.values.toList()
    }

    /**
     * X কি Y-এর উপরে (সরাসরি বা পরোক্ষভাবে)?
     *
     * এটাই ঠিক করে কে কাকে টার্গেট দিতে পারে, কার dealer assign করতে পারে,
     * কার route plan বানাতে পারে, কার আবেদন approve করতে পারে।
     */
    fun canActOn(
        actor: EmployeeProfile,
        subject: EmployeeProfile,
        date: LocalDate,
        employees: List<EmployeeProfile>,
    ): Boolean {
        if (actor.id == subject.id) return false
        // Chairman সর্বত্র — "চেয়ারম্যান পুরো setup-এর main core, তার বিচরণ সবখানে"
        if (actor.role == UserRole.CHAIRMAN) return true
        // Wing 1 পুরো Wing 2-এর উপরে: তারা জাতীয়, এলাকার সীমা তাদের আটকায় না
        if (wingOf(actor.role) == Wing.OFFICE && wingOf(subject.role) == Wing.FIELD) return true
        if (!isAbove(actor.role, subject.role)) return false
        return allReportsOf(actor, date, employees).any { it.id == subject.id }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ভ্যাকেন্সি
    // ─────────────────────────────────────────────────────────────────────────

    data class Vacancy(
        val role: UserRole,
        val geoKey: String,
        /** এখন কে দায়িত্ব চালাচ্ছেন — cascade দিয়ে বের করা, হাতে বসানো নয় */
        val coveredBy: Holder,
    )

    /**
     * সব ফাঁকা পদ। "ওই এলাকায় ওই role-এ active কেউ নেই বলেই সেটা vacant" —
     * তাই যে এলাকাগুলো অ্যাপ চেনে (কারও না কারও রেকর্ডে আছে) সেগুলোর
     * বিপরীতে প্রতিটা field-পদ যাচাই করা হয়।
     *
     * শুধু Wing 2 — Wing 1-এর এলাকা নেই, ওখানে "ফাঁকা" মানে সোজা পদ খালি,
     * সেটা আলাদা প্রশ্ন।
     */
    fun vacanciesOn(
        date: LocalDate,
        employees: List<EmployeeProfile>,
        overrides: List<Override> = emptyList(),
    ): List<Vacancy> {
        val out = mutableListOf<Vacancy>()
        val active = employees.filter { isActiveOn(it, date) }
        for (role in FIELD_ROLES) {
            val level = geoLevelOf(role)
            // অ্যাপ যে এলাকাগুলো চেনে — কারও না কারও রেকর্ড থেকে সংগ্রহ
            val knownKeys = employees.mapNotNull { geoKeyAt(it, level) }.map { it.trim() }
                .filter { it.isNotBlank() }.distinct()
            for (key in knownKeys) {
                val filled = active.any { it.role == role && geoKeyOf(it).equals(key, ignoreCase = true) }
                if (!filled) {
                    out += Vacancy(role, key, holderOf(role, key, date, employees, overrides))
                }
            }
        }
        return out
    }

    // ─────────────────────────────────────────────────────────────────────────
    // দায়িত্বের টাইমলাইন — ইতিহাস কেন বদলায় না
    // ─────────────────────────────────────────────────────────────────────────

    data class Tenure(
        val from: LocalDate,
        val to: LocalDate?,
        val holder: Holder,
    )

    /**
     * একটা পদ-এলাকা জোড়ার দায়িত্ব কার হাতে কখন ছিল, তার পুরো তালিকা।
     *
     * উদাহরণ — টেরিটরি-১২, TSM:
     *   ১ জানু – ২৮ ফেব্রু  → করিম (ASM, ভ্যাকেন্সি পূরণে)
     *   ১ মার্চ – ৩০ এপ্রি  → রফিক (TSM, নিজের পদ)
     *   ১ মে   – ১০ মে     → সালাম (RSM, ভ্যাকেন্সি পূরণে)
     *   ১১ মে  – চলমান     → জামাল (TSM, নিজের পদ)
     *
     * তিনবার হাতবদল, অথচ কেউ কিছু হাতে করেনি — শুধু কার joining/exit কবে,
     * সেটুকু থেকেই পুরো তালিকা বেরোয়।
     *
     * হিসাব হয় **ঘটনার তারিখগুলোতে** (joining/exit/override সীমানা), দিনে
     * দিনে নয় — এক বছরের জন্য ৩৬৫ বার না চালিয়ে গোটা দশেক বার চালালেই হয়।
     */
    fun tenureTimeline(
        role: UserRole,
        geoKey: String?,
        from: LocalDate,
        to: LocalDate,
        employees: List<EmployeeProfile>,
        overrides: List<Override> = emptyList(),
    ): List<Tenure> {
        val marks = sortedSetOf(from)
        employees.forEach { e ->
            e.joiningDate?.let { if (!it.isBefore(from) && !it.isAfter(to)) marks.add(it) }
            e.exitDate?.let { d -> d.plusDays(1).let { if (!it.isBefore(from) && !it.isAfter(to)) marks.add(it) } }
        }
        overrides.forEach { o ->
            if (!o.fromDate.isBefore(from) && !o.fromDate.isAfter(to)) marks.add(o.fromDate)
            o.toDate?.let { d -> d.plusDays(1).let { if (!it.isBefore(from) && !it.isAfter(to)) marks.add(it) } }
        }

        val out = mutableListOf<Tenure>()
        val list = marks.toList()
        for ((i, start) in list.withIndex()) {
            val holder = holderOf(role, geoKey, start, employees, overrides)
            val end = list.getOrNull(i + 1)?.minusDays(1) ?: to
            val last = out.lastOrNull()
            // পরপর দুটো সময়ে একই লোক একই ভিত্তিতে থাকলে আলাদা সারি বানানো
            // অর্থহীন — জুড়ে দেওয়া হয়, যাতে তালিকা পড়ার মতো থাকে।
            if (last != null && last.holder.employee?.id == holder.employee?.id && last.holder.basis == holder.basis) {
                out[out.lastIndex] = last.copy(to = end)
            } else {
                out += Tenure(start, end, holder)
            }
        }
        if (out.isNotEmpty()) {
            val lastRow = out.last()
            if (lastRow.to == to) out[out.lastIndex] = lastRow.copy(to = null) // চলমান
        }
        return out
    }

    // ─────────────────────────────────────────────────────────────────────────
    // সুবিধার মোড়ক — MockRepository-র লাইভ ডেটা ধরে
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * `employeeProfiles` একটা lateinit StateFlow — MockRepository.init() চলার
     * আগে ছুঁলে UninitializedPropertyAccessException। Engine নিজে থেকে অ্যাপ
     * ফেলে দেবে না, তাই খালি তালিকা ফেরায়; আর soft-deleted রেকর্ড এখানেই
     * ছেঁকে ফেলা হয় যাতে প্রতিটা ডাকার জায়গায় আলাদা করে মনে রাখতে না হয় —
     * মুছে ফেলা লোক কোনো পদের দায়িত্বে থাকতে পারে না।
     */
    private fun liveEmployees(): List<EmployeeProfile> =
        runCatching { MockRepository.employeeProfiles.value }.getOrDefault(emptyList())
            .filter { !it.isDeleted }

    /** আজ এই এলাকায় এই পদের দায়িত্বে কে। */
    fun holderToday(role: UserRole, geoKey: String?): Holder =
        holderOf(role, geoKey, LocalDate.now(), liveEmployees())

    /** এই employee-র আজকের ম্যানেজার। */
    fun managerToday(employeeId: String): Holder? =
        liveEmployees().firstOrNull { it.id == employeeId }
            ?.let { managerOf(it, LocalDate.now(), liveEmployees()) }

    /** আজ কোন কোন পদ ফাঁকা, আর কে চালাচ্ছেন। */
    fun vacanciesToday(): List<Vacancy> = vacanciesOn(LocalDate.now(), liveEmployees())

    /** actor কি subject-এর উপর কাজ করতে পারে (টার্গেট দেওয়া, assign, approve, route plan)। */
    fun canActOnToday(actorId: String, subjectId: String): Boolean {
        val all = liveEmployees()
        val a = all.firstOrNull { it.id == actorId } ?: return false
        val s = all.firstOrNull { it.id == subjectId } ?: return false
        return canActOn(a, s, LocalDate.now(), all)
    }

    /**
     * টার্গেট / route plan কাদের মধ্যে ভাগ করতে হবে — ফাঁকা পদ এড়িয়ে।
     *
     * "যে ডিভিশনে DSM আছে → DSM পাবে; DSM নেই → সরাসরি RSM-রা; RSM-ও নেই →
     * সরাসরি ASM-রা" — আপনার নিজের নিয়ম, এখানে কোডে।
     */
    fun distributionTargetsUnder(
        actor: EmployeeProfile,
        date: LocalDate = LocalDate.now(),
        employees: List<EmployeeProfile> = liveEmployees(),
    ): List<EmployeeProfile> {
        var below = RANK.getOrNull(rankOf(actor.role) - 1)
        while (below != null) {
            val found = directReportsOf(actor, date, employees).filter { it.role == below }
            if (found.isNotEmpty()) return found
            // এই স্তর পুরো ফাঁকা — এক ধাপ নিচে নামো। টার্গেট আটকে থাকে না।
            below = RANK.getOrNull(rankOf(below) - 1)
        }
        return emptyList()
    }
}
