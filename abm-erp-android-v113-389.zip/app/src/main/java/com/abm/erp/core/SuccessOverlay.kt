package com.abm.erp.core

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * v113-351 — the person's point 5, decided by option: on ANY completed
 * action, a full-screen green tick rises at the exact middle of the
 * screen, bKash-style — "এখন ছোট করে একটু টিক চিহ্ন উঠে সবুজ। ওটা আসলে
 * অনেক সময় ধরা যায় না।" Variant 1 (their choice): the circle DRAWS
 * itself, then the tick strokes in, with a soft expanding pulse behind.
 *
 * Design: a tiny global bus + one host. Any code completes an action and
 * calls `SuccessBus.show("Invoice তৈরি সম্পন্ন", "INV-0847 · ৳27,313.50")`
 * — one line, no plumbing — and the single host inside
 * ModuleDrawerScaffold renders it over whatever screen is open. Auto
 * dismisses after ~1.7s; tapping dismisses immediately (nobody should be
 * held hostage by an animation).
 */
object SuccessBus {
    data class Event(val label: String, val detail: String? = null, val stamp: Long = System.currentTimeMillis())
    private val _event = MutableStateFlow<Event?>(null)
    val event: StateFlow<Event?> = _event
    fun show(label: String, detail: String? = null) { _event.value = Event(label, detail) }
    internal fun clear() { _event.value = null }
}

@Composable
fun SuccessOverlayHost() {
    val event by SuccessBus.event.collectAsState()
    val current = event ?: return
    // keyed on stamp so two rapid successes each replay the animation
    key(current.stamp) {
        SuccessCelebration(
            label = current.label,
            detail = current.detail,
            onDone = { SuccessBus.clear() },
        )
    }
}

@Composable
private fun SuccessCelebration(label: String, detail: String?, onDone: () -> Unit) {
    val green = Color(0xFF17A34A)
    val ring = remember { Animatable(0f) }
    val tick = remember { Animatable(0f) }
    val pulse = remember { Animatable(0f) }
    val textIn = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        // orchestration mirrors the approved mock-up timings
        coroutineScope {
            launch { pulse.animateTo(1f, tween(1100)) }
            ring.animateTo(1f, tween(550))
            launch { textIn.animateTo(1f, tween(400)) }
            tick.animateTo(1f, tween(380))
        }
        delay(900)
        onDone()
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xEB0E141C))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
            ) { onDone() },
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(150.dp)) {
                    val stroke = 8.dp.toPx()
                    val r = size.minDimension / 2f - stroke
                    // soft pulse behind
                    if (pulse.value > 0f) {
                        drawCircle(green.copy(alpha = (1f - pulse.value) * 0.45f), radius = r * (0.7f + 0.9f * pulse.value))
                    }
                    // the ring draws itself
                    drawArc(
                        color = green, startAngle = -90f, sweepAngle = 360f * ring.value, useCenter = false,
                        topLeft = Offset(center.x - r, center.y - r), size = Size(r * 2, r * 2),
                        style = Stroke(width = stroke, cap = StrokeCap.Round),
                    )
                    // the tick strokes in
                    if (tick.value > 0f) {
                        val p = Path().apply {
                            moveTo(center.x - r * 0.42f, center.y + r * 0.02f)
                            lineTo(center.x - r * 0.10f, center.y + r * 0.34f)
                            lineTo(center.x + r * 0.48f, center.y - r * 0.30f)
                        }
                        val pm = PathMeasure().apply { setPath(p, false) }
                        val seg = Path()
                        pm.getSegment(0f, pm.length * tick.value, seg, true)
                        drawPath(seg, green, style = Stroke(width = 11.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Text(
                label, color = Color.White.copy(alpha = textIn.value), fontWeight = FontWeight.Bold,
                fontSize = 18.sp, style = MaterialTheme.typography.titleMedium,
            )
            if (detail != null) {
                Spacer(Modifier.height(4.dp))
                Text(detail, color = Color(0xFF9FB3A8).copy(alpha = textIn.value), fontSize = 13.sp)
            }
        }
    }
}
