package com.abm.erp.data

import java.time.LocalDate
import java.time.LocalDateTime
import com.abm.erp.data.room.ApprovalRequestEntity

// ============================================================================
// v113-81 Phase 3 — the Approvals + SLA group, moved out of MockRepository.kt:
// requestApproval, setApprovalStatus, advanceApproval, overdueApprovals,
// pendingApprovalSlaItems, checkAndNotifySlaBreaches, escalateApproval,
// forwardApproval, reassignApproval (+ the private slaTierFor helper).
//
// Same mechanics as CollectionsEngine.kt: extension functions on the
// MockRepository object, so every call site inside the object and across the
// UI is textually identical; private-member access goes through the object's
// existing internal bridges (database / launchInRepoScope / qrSyncCollection).
// Bodies untouched — permission gates, SLA tiers, escalation and audit trail
// exactly as they were.
// ============================================================================

fun MockRepository.requestApproval(type: ApprovalType, fromEmployee: String, detail: String) {
    launchInRepoScope {
        val entity = ApprovalRequestEntity(
            id = java.util.UUID.randomUUID().toString(), type = type.name, fromEmployee = fromEmployee,
            detail = detail, status = ApprovalStatus.PENDING.name, createdAtEpochMillis = System.currentTimeMillis(),
        )
        database.approvalDao().upsert(entity)
        pushApproval(entity)
    }
}

/** Returns false (and logs a DENY entry) if the current user's role isn't allowed to approve/reject — enforced here, not just hidden in the UI, so a bypassed/tampered client can't force it through. */
fun MockRepository.setApprovalStatus(id: String, status: ApprovalStatus, onRejected: (String) -> Unit = {}): Boolean {
    val needsApprovePermission = status == ApprovalStatus.APPROVED || status == ApprovalStatus.REJECTED
    if (needsApprovePermission && !PermissionManager.canCurrentUser("approval", PermissionAction.APPROVE)) {
        logAudit("ApprovalRequest", id, "DENY", oldValue = currentUser.role.name, newValue = status)
        onRejected("আপনার role-এ approve/reject করার অনুমতি নেই।")
        return false
    }
    launchInRepoScope {
        val before = approvals.value.firstOrNull { it.id == id }
        database.approvalDao().setStatus(id, status.name)
        qrSyncCollection("approvals").document(id).update("status", status.name)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push approval-status failed", it) }
        val action = if (status == ApprovalStatus.APPROVED) "APPROVE" else if (status == ApprovalStatus.REJECTED) "REJECT" else "UPDATE"
        logAudit("ApprovalRequest", id, action, oldValue = before?.status, newValue = status)
    }
    return true
}

/**
 * Foundation Layer — Cascade Approval Engine. SO submits at level 1
 * (needs ASM); ASM approving advances it to level 2 (needs RSM); RSM
 * approving advances it to level 3 (needs GM, the final sign-off).
 * GM/MD/CHAIRMAN can short-circuit-approve at any level (matches their
 * full-access permission definition in PermissionManager). A REJECT at
 * any level is terminal — status becomes REJECTED with a reason
 * attached; the submitter sees why and can raise a fresh request to
 * try again (this build doesn't auto-resubmit a rejected request).
 */
internal val CASCADE_CHAIN = listOf(UserRole.ASM, UserRole.RSM, UserRole.GM) // v113-101: was file-private; ModuleApprovals.kt needs this to show/gate the real per-request tier, not just a blanket permission

fun MockRepository.advanceApproval(id: String, decision: ApprovalStatus, rejectReason: String? = null, onRejected: (String) -> Unit = {}): Boolean {
    // v113-103 — added when the full-app sweep caught that v113-101 had already
    // wired ModuleApprovals.kt to pass onRejected= here, but this function itself
    // never received the parameter — a real compile error waiting in the last
    // shipped zip, caught before another round, not after.
    if (decision != ApprovalStatus.APPROVED && decision != ApprovalStatus.REJECTED) { onRejected("সিদ্ধান্ত সঠিক না।"); return false }
    if (!PermissionManager.canCurrentUser("approval", PermissionAction.APPROVE)) {
        logAudit("ApprovalRequest", id, "DENY", oldValue = currentUser.role.name, newValue = decision)
        onRejected("আপনার role-এ approve/reject করার অনুমতি নেই।")
        return false
    }
    val request = approvals.value.firstOrNull { it.id == id } ?: run { onRejected("এই Approval request খুঁজে পাওয়া যায়নি।"); return false }
    // v86 fix — this used to proceed straight into level/role checks
    // with no check that the request was still PENDING, meaning an
    // already-APPROVED or already-REJECTED request could be processed
    // again (double-approval, or approving something already
    // rejected/cancelled). "No duplicate approval" / "no approval
    // after cancellation" are explicit Module 11 requirements.
    if (request.status != ApprovalStatus.PENDING) {
        logAudit("ApprovalRequest", id, "DENY", oldValue = request.status.name, newValue = "already ${request.status.name} — cannot process again")
        onRejected("এটা ইতিমধ্যে ${request.status} — আবার প্রসেস করা যাবে না।")
        return false
    }
    val requiredTier = CASCADE_CHAIN.getOrNull(request.level - 1)
    val isOverrideRole = currentUser.role in setOf(UserRole.GM, UserRole.MD, UserRole.CHAIRMAN, UserRole.AGM)
    if (requiredTier != null && currentUser.role != requiredTier && !isOverrideRole) {
        logAudit("ApprovalRequest", id, "DENY", oldValue = "${currentUser.role} tried level ${request.level} (needs $requiredTier)", newValue = decision)
        onRejected("এই request-এর জন্য $requiredTier tier দরকার — আপনার role (${currentUser.role}) না।")
        return false
    }
    // v88 fix — real, per-employee canApproveAmount check for
    // Voucher-type approvals specifically (Foundation 2, Section 7-8
    // + Section 13 segregation of duties), using the actual Voucher's
    // real debit total rather than parsing the free-text detail
    // string. Only applies when both the approver and the voucher's
    // creator have a linked EmployeeProfile — an honest hybrid while
    // the old and new identity systems coexist.
    if (decision == ApprovalStatus.APPROVED && request.entityType == "Voucher") {
        val voucher = AccountsRepository.vouchers.value.firstOrNull { it.id == request.entityId }
        val approverProfile = employeeProfiles.value.firstOrNull { it.userAccountId == currentUser.id }
        val creatorProfile = employeeProfiles.value.firstOrNull { it.fullName == voucher?.createdBy }
        if (voucher != null && approverProfile != null && creatorProfile != null) {
            val amount = voucher.lines.sumOf { it.debit }
            val (allowed, reason) = canApproveAmount(approverProfile.id, creatorProfile.id, MockRepository.ApprovalLimitType.FINANCIAL, amount)
            if (!allowed) {
                logAudit("ApprovalRequest", id, "DENY", oldValue = reason ?: "insufficient authority", newValue = decision)
                onRejected(reason ?: "এই পরিমাণ approve করার যথেষ্ট authority নেই।")
                return false
            }
        }
    }
    launchInRepoScope {
        val now = System.currentTimeMillis()
        if (decision == ApprovalStatus.REJECTED) {
            database.approvalDao().setStatus(id, ApprovalStatus.REJECTED.name)
            qrSyncCollection("approvals").document(id)
                .update(mapOf("status" to ApprovalStatus.REJECTED.name, "approvedBy" to currentUser.name, "approvedAtEpochMillis" to now, "rejectReason" to rejectReason))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push approval-reject failed", it) }
            logAudit("ApprovalRequest", id, "REJECT", oldValue = "level ${request.level}", newValue = rejectReason ?: "no reason given")
            createNotification(NotificationCategory.APPROVAL, "Request Rejected", "${request.type} — ${request.fromEmployee}: ${rejectReason ?: "কারণ দেওয়া হয়নি"}", request.fromEmployee)
            return@launchInRepoScope
        }
        val isFinalLevel = isOverrideRole || request.level >= CASCADE_CHAIN.size
        if (isFinalLevel) {
            database.approvalDao().setStatus(id, ApprovalStatus.APPROVED.name)
            qrSyncCollection("approvals").document(id)
                .update(mapOf("status" to ApprovalStatus.APPROVED.name, "approvedBy" to currentUser.name, "approvedAtEpochMillis" to now))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push approval-final failed", it) }
            logAudit("ApprovalRequest", id, "APPROVE", oldValue = "level ${request.level} (final)", newValue = "APPROVED")
            createNotification(NotificationCategory.APPROVAL, "Request Approved", "${request.type} — ${request.fromEmployee}", request.fromEmployee)
            // v86, Module 11 — "Status update in the original module":
            // this generic approval function never actually applied
            // entity-specific side-effects before. Attendance correction
            // is the first one wired; other entityTypes fall through
            // unaffected (documented gap, not silently claimed complete).
            // v113-346 — dealer stock adjustment. This is the ONLY path
            // that moves a dealer's stock from a counted figure: the count
            // itself raises a request and changes nothing, and the change
            // lands here, after a real approval. Their own rule —
            // "approve Pele stock calculate korbe".
            if (request.entityType == "DealerStock") {
                applyApprovedStockAdjustment(request.entityId, request.detail)
            }
            if (request.entityType == "AttendanceRecord") {
                val parts = request.entityId.split("|")
                if (parts.size == 3) {
                    val (employeeId, dayStr, checkedInStr) = parts
                    val dateEpochDay = dayStr.toLongOrNull()
                    if (dateEpochDay != null) {
                        if (isDateLocked(LocalDate.ofEpochDay(dateEpochDay))) {
                            logAudit("AttendanceRecord", request.entityId, "DENY_LOCKED_PERIOD", newValue = "CORRECTION_BLOCKED — accounting period is locked")
                        } else {
                            database.attendanceDao().correctCheckedIn(employeeId, dateEpochDay, checkedInStr.toBoolean())
                            logAudit("AttendanceRecord", request.entityId, "CORRECTED", newValue = checkedInStr)
                        }
                    }
                }
            }
        } else {
            val nextLevel = request.level + 1
            database.approvalDao().setLevel(id, nextLevel)
            qrSyncCollection("approvals").document(id).update("level", nextLevel)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push approval-cascade failed", it) }
            logAudit("ApprovalRequest", id, "APPROVE", oldValue = "level ${request.level}", newValue = "advanced to level $nextLevel (${CASCADE_CHAIN.getOrNull(nextLevel - 1)})")
        }
    }
    return true
}

/** Escalate — jumps straight to the next tier up regardless of the normal per-level cascade (for when the assigned approver isn't responding in time). */
/** v86 - Escalation rule (surfacing, not auto-actioning): pending approvals older than the threshold, real createdAt-based, for Dashboard/Approval Center to flag. */
fun MockRepository.overdueApprovals(thresholdHours: Long = 48): List<ApprovalRequest> {
    val cutoff = LocalDateTime.now().minusHours(thresholdHours)
    return approvals.value.filter { it.status == ApprovalStatus.PENDING && it.createdAt.isBefore(cutoff) }
}

// ==========================================================
// Section 5 — Approval SLA & Escalation (real, unified across
// all 6 approval types — the old overdueApprovals() above only ever
// covered the generic ApprovalRequest list, which itself only
// carries LEAVE/DISCOUNT/EXPENSE/OTHER — Hiring, Invoice, Collection,
// Stock Adjustment, and Production approvals each live in their own
// entity with their own pending-status, and were never included.
// ==========================================================
enum class SlaTier { ON_TIME, REMINDER_24H, ESCALATION_48H, CHAIRMAN_ALERT_72H }

data class PendingApprovalSlaItem(
    val approvalKind: String, // "Hiring" | "Leave" | "Invoice" | "Collection" | "StockAdjustment" | "Production"
    val entityId: String,
    val label: String,
    val submittedAt: LocalDateTime,
    val ageHours: Long,
    val tier: SlaTier,
)

private fun MockRepository.slaTierFor(ageHours: Long): SlaTier = when {
    ageHours >= 72 -> SlaTier.CHAIRMAN_ALERT_72H
    ageHours >= 48 -> SlaTier.ESCALATION_48H
    ageHours >= 24 -> SlaTier.REMINDER_24H
    else -> SlaTier.ON_TIME
}

/** Real, unified SLA scan across all 6 approval types — the actual detection logic, not just the generic ApprovalRequest list. */
fun MockRepository.pendingApprovalSlaItems(): List<PendingApprovalSlaItem> {
    val now = LocalDateTime.now()
    fun age(t: LocalDateTime) = java.time.Duration.between(t, now).toHours()
    val items = mutableListOf<PendingApprovalSlaItem>()
    employeeProfiles.value.filter { it.onboardingStatus == EmployeeOnboardingStatus.PENDING_CHAIRMAN_APPROVAL }.forEach {
        items += PendingApprovalSlaItem("Hiring", it.id, it.fullName, it.createdAt, age(it.createdAt), slaTierFor(age(it.createdAt)))
    }
    approvals.value.filter { it.status == ApprovalStatus.PENDING && it.type == ApprovalType.LEAVE }.forEach {
        items += PendingApprovalSlaItem("Leave", it.id, it.fromEmployee, it.createdAt, age(it.createdAt), slaTierFor(age(it.createdAt)))
    }
    salesInvoices.value.filter { it.status == "PENDING" && !it.isDeleted }.forEach {
        items += PendingApprovalSlaItem("Invoice", it.id, it.invoiceNo, it.createdAt, age(it.createdAt), slaTierFor(age(it.createdAt)))
    }
    partyCollections.value.filter { it.status == "PENDING" }.forEach {
        items += PendingApprovalSlaItem("Collection", it.id, it.collectionNo.ifBlank { it.partyName }, it.createdAt, age(it.createdAt), slaTierFor(age(it.createdAt)))
    }
    InventoryRepository.stockCounts.value.filter { it.status == "SUBMITTED" }.forEach {
        items += PendingApprovalSlaItem("StockAdjustment", it.id, it.countNo, it.createdAt, age(it.createdAt), slaTierFor(age(it.createdAt)))
    }
    productionPlans.value.filter { it.status == ProductionPlanStatus.DRAFT }.forEach {
        val submittedAt = it.createdAt
        items += PendingApprovalSlaItem("Production", it.id, it.batchNumber, submittedAt, age(submittedAt), slaTierFor(age(submittedAt)))
    }
    return items.filter { it.tier != SlaTier.ON_TIME }.sortedByDescending { it.ageHours }
}

// Dedup guard — without this, calling checkAndNotifySlaBreaches() on every
// periodic tick would re-send the SAME reminder/escalation/alert every
// time, since pendingApprovalSlaItems() re-detects the same still-pending
// item on every call. Tracks the highest tier already notified per entity
// for this session; real persistence isn't needed since a fresh app
// launch re-notifying an already-overdue item is the SAFE failure mode
// (over-notifying), not the dangerous one (silently missing an alert).
private val slaLastNotifiedTier = mutableMapOf<String, SlaTier>()

/** Real notification-sending — call periodically (see ApprovalSlaWorker) rather than only when a screen happens to query pendingApprovalSlaItems(). */
fun MockRepository.checkAndNotifySlaBreaches() {
    val chairmanEmployeeId = employeeProfiles.value.firstOrNull { it.role == UserRole.CHAIRMAN && it.hasActiveAccess }?.id
    pendingApprovalSlaItems().forEach { item ->
        val key = "${item.approvalKind}:${item.entityId}"
        if (slaLastNotifiedTier[key] == item.tier) return@forEach // already notified at this exact tier
        slaLastNotifiedTier[key] = item.tier
        when (item.tier) {
            SlaTier.REMINDER_24H -> createNotification(NotificationCategory.APPROVAL, "Approval Reminder (24h)", "${item.approvalKind}: ${item.label} — ২৪ ঘণ্টা ধরে অপেক্ষমাণ")
            SlaTier.ESCALATION_48H -> {
                createNotification(NotificationCategory.APPROVAL, "Approval Escalation (48h)", "${item.approvalKind}: ${item.label} — ৪৮ ঘণ্টা পার, escalate করা হলো")
                logAudit(item.approvalKind, item.entityId, "SLA_ESCALATION_48H", newValue = "age=${item.ageHours}h")
            }
            SlaTier.CHAIRMAN_ALERT_72H -> {
                // Real Chairman-specific targeting — was previously untargeted (null), indistinguishable from a generic broadcast reminder.
                createNotification(NotificationCategory.APPROVAL, "⚠ Chairman Alert (72h)", "${item.approvalKind}: ${item.label} — ৭২ ঘণ্টা পার হয়ে গেছে, Chairman-এর নজরে আনা দরকার", targetEmployeeId = chairmanEmployeeId)
                logAudit(item.approvalKind, item.entityId, "SLA_CHAIRMAN_ALERT_72H", newValue = "age=${item.ageHours}h")
            }
            SlaTier.ON_TIME -> {}
        }
    }
}

fun MockRepository.escalateApproval(id: String, onRejected: (String) -> Unit = {}): Boolean {
    if (!PermissionManager.canCurrentUser("approval", PermissionAction.APPROVE)) { onRejected("আপনার role-এ Escalate করার অনুমতি নেই।"); return false }
    val request = approvals.value.firstOrNull { it.id == id } ?: run { onRejected("এই Approval request খুঁজে পাওয়া যায়নি।"); return false }
    if (request.status != ApprovalStatus.PENDING) { onRejected("এটা ইতিমধ্যে ${request.status} — escalate করা যাবে না।"); return false }
    val nextLevel = (request.level + 1).coerceAtMost(CASCADE_CHAIN.size)
    launchInRepoScope {
        database.approvalDao().setLevel(id, nextLevel)
        database.approvalDao().setEscalated(id, true)
        qrSyncCollection("approvals").document(id).update(mapOf("level" to nextLevel, "escalated" to true))
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push approval-escalate failed", it) }
        logAudit("ApprovalRequest", id, "UPDATE", oldValue = "level ${request.level}", newValue = "ESCALATED to level $nextLevel")
    }
    return true
}

/** Forward — hands this specific request to a named employee (outside the normal cascade), e.g. a specialist or a covering manager. */
fun MockRepository.forwardApproval(id: String, toEmployeeId: String): Boolean {
    if (!PermissionManager.canCurrentUser("approval", PermissionAction.APPROVE)) return false
    launchInRepoScope {
        database.approvalDao().setAssignedTo(id, toEmployeeId)
        qrSyncCollection("approvals").document(id).update("assignedToEmployeeId", toEmployeeId)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push approval-forward failed", it) }
        logAudit("ApprovalRequest", id, "UPDATE", newValue = "FORWARDED to $toEmployeeId")
    }
    return true
}

/** Reassign — same mechanism as Forward, semantically "permanently hand off" rather than "temporarily loop in". */
fun MockRepository.reassignApproval(id: String, toEmployeeId: String): Boolean = forwardApproval(id, toEmployeeId)
