package com.abm.erp.ui.invoice

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.DocLabel
import com.abm.erp.core.DocValue
import com.abm.erp.core.SignatureSlot
import com.abm.erp.core.Space
import com.abm.erp.core.Th
import com.abm.erp.core.Td
import com.abm.erp.core.ThGrid
import com.abm.erp.core.TdGrid
import com.abm.erp.core.TotalRow
import com.abm.erp.core.amountInWords
import com.abm.erp.data.MockRepository
import com.abm.erp.data.SalesInvoice
import com.abm.erp.theme.*
import kotlinx.coroutines.launch

/**
 * Invoice Document — the printable bill, rendered on screen.
 *
 * The PDF export already produced a proper document; on screen an invoice was still
 * just a list row. This is the same document, laid out for the phone, so what a user
 * sees is what they will print. Every value comes from the real `SalesInvoice` — no
 * placeholder rows, and no figure recomputed here (subTotal / discount / total are
 * the model's own computed properties, so the numbers on screen can never drift from
 * the numbers in the ledger).
 *
 * v113-162 — the branded document card itself is now `InvoiceDocumentBody` below,
 * extracted so `DmsInvoiceWorkspace` can render the identical document inline
 * (person's request: create and view/print should feel like one workspace, not a
 * form screen that navigates away to a different-looking document screen). This
 * screen is unchanged in behavior — still the standalone destination reached from
 * Search/Scanner/other places outside the DMS workspace's own context — it just
 * calls the shared body instead of inlining it.
 */
@Composable
fun InvoiceDocumentScreen(invoiceId: String, onBack: () -> Unit) {
    val invoices by MockRepository.salesInvoices.collectAsState()
    val invoice = invoices.firstOrNull { it.id == invoiceId }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    // v113-161 — shared with DocumentQrControl (inside InvoiceDocumentBody) via
    // onQrPayloadReady, so Print/PDF embeds the exact same QR shown on screen
    // instead of minting a second, different one.
    var qrPayloadForPdf by remember(invoice?.id) { mutableStateOf<String?>(null) }

    if (invoice == null) {
        Column(Modifier.fillMaxSize().padding(Space.xl), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(80.dp))
            com.abm.erp.core.WorkspaceEmptyState("এই ইনভয়েসটি পাওয়া যায়নি।", iconVector = Icons.Filled.ReceiptLong)
            Spacer(Modifier.height(Space.lg))
            com.abm.erp.core.SecondaryButton("← ফিরে যান", onClick = onBack)
        }
        return
    }

    Column(Modifier.fillMaxSize().background(DashBg)) {

        // ── top bar ──
        Row(
            Modifier.fillMaxWidth().background(Color.White).padding(horizontal = Space.md, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back", tint = TextPrimary) }
            Column(Modifier.weight(1f)) {
                Text("Invoice", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextPrimary)
                Text(invoice.invoiceNo, fontSize = 10.sp, color = TextSecondary)
            }
            com.abm.erp.core.StatusPill(invoice.status)
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(Space.md)) {
            InvoiceDocumentBody(invoice = invoice, onQrPayloadReady = { qrPayloadForPdf = it })
            Spacer(Modifier.height(Space.lg))
        }

        // ── actions ──
        Row(
            Modifier.fillMaxWidth().background(Color.White).padding(Space.md),
            horizontalArrangement = Arrangement.spacedBy(Space.sm),
        ) {
            Box(Modifier.weight(1f)) {
                com.abm.erp.core.SecondaryButton("Share", onClick = {
                    runCatching {
                        val summary = "Invoice ${invoice.invoiceNo}\n${invoice.dealerName}\nTotal: ৳${"%,.0f".format(invoice.total)}\nStatus: ${invoice.status}"
                        val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                            type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary)
                        }
                        context.startActivity(android.content.Intent.createChooser(i, "Share invoice"))
                    }.onFailure {
                        android.widget.Toast.makeText(context, "Share করার মতো app পাওয়া যায়নি।", android.widget.Toast.LENGTH_LONG).show()
                    }
                }, icon = Icons.Filled.Share)
            }
            Box(Modifier.weight(1.4f)) {
                com.abm.erp.core.PrimaryButton(
                    text = if (busy) "তৈরি হচ্ছে…" else "Print / PDF",
                    icon = Icons.Filled.Print,
                    loading = busy,
                    onClick = {
                        busy = true
                        scope.launch {
                            // Reuses the existing PDF exporter — the on-screen document and the
                            // printed one are generated from the same invoice, so they cannot disagree.
                            runCatching {
                                // v113-161 — no longer unconditionally (re)issues. Reuses whatever
                                // QR is already showing on screen; if none has been captured this
                                // session, issues fresh ONLY when this invoice has genuinely never
                                // had one (safe, first-ever QR). If one already exists in the
                                // registry but isn't held in this session, printing is blocked with
                                // a message pointing at the "Reissue QR" control above — which
                                // shows the explicit warning — rather than silently invalidating
                                // whatever was already printed.
                                val payload = qrPayloadForPdf ?: run {
                                    val alreadyExists = com.abm.erp.data.QrRegistry.activeFor("SalesInvoice", invoice.id) != null
                                    if (alreadyExists) null
                                    else com.abm.erp.data.QrRegistry.issue("SalesInvoice", invoice.id)?.also { qrPayloadForPdf = it }
                                }
                                if (payload == null) {
                                    android.widget.Toast.makeText(
                                        context,
                                        "এই ইনভয়েসের QR আগেই issue করা আছে — উপরে \"Reissue QR\"-এ ট্যাপ করে নতুন QR নিন, তারপর Print করুন।",
                                        android.widget.Toast.LENGTH_LONG,
                                    ).show()
                                } else {
                                    val file = com.abm.erp.core.exportSalesInvoicePdf(context, invoice, payload)
                                    val uri = androidx.core.content.FileProvider.getUriForFile(
                                        context, "${context.packageName}.fileprovider", file,
                                    )
                                    val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                        type = "application/pdf"
                                        putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(android.content.Intent.createChooser(i, "Invoice PDF"))
                                }
                            }.onFailure { e ->
                                com.abm.erp.config.AppLog.w("InvoiceDocumentScreen", "PDF export/share failed", e)
                                val msg = if (com.abm.erp.config.AppEnvironment.isDebugOrStaging) "PDF তৈরি করা যায়নি: ${e.javaClass.simpleName} — ${e.message}" else "PDF তৈরি করা যায়নি।"
                                android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()
                            }
                            busy = false
                        }
                    },
                )
            }
        }
    }
}

/**
 * v113-162 — the branded document card itself, extracted out of
 * `InvoiceDocumentScreen` so `DmsInvoiceWorkspace` can render the identical
 * document inline (its "view an invoice" mode) instead of navigating to a
 * separate, differently-styled screen. Byte-for-byte the same rendering
 * that used to live directly inside `InvoiceDocumentScreen` — only wrapped
 * in a function signature, nothing about the layout changed.
 */
@Composable
fun InvoiceDocumentBody(invoice: SalesInvoice, onQrPayloadReady: (String) -> Unit = {}) {
    val company = remember { MockRepository.companySettings() }

    // ═══ THE DOCUMENT ═══
    // v113-198 — restyled from an orange gradient banner to a plain white
    // masthead with a logo mark, matching the person's own reference invoice
    // template: colour is spent only on the logo, the INVOICE label, section
    // bars, the table header, and the total figure — the page itself reads
    // as a real printed document, not an app screen.
    Column(
        Modifier.fillMaxWidth()
            .background(Color.White, RoundedCornerShape(4.dp))
            .border(1.dp, HairlineBorder, RoundedCornerShape(4.dp)),
    ) {
        // ── masthead ──
        Row(
            Modifier.fillMaxWidth().padding(Space.lg),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            com.abm.erp.core.DocLogoMark()
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                // Reads the Chairman's own company settings rather than a hardcoded name,
                // so branding configured in Company Settings actually reaches the printed bill.
                Text(
                    company.companyName.ifBlank { "ABM Corporation" },
                    color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                )
                val sub = listOfNotNull(
                    company.companyAddress.ifBlank { null },
                    company.companyPhone.ifBlank { null },
                ).joinToString(" · ").ifBlank { "Enterprise. Control. Growth." }
                Text(sub, color = TextSecondary, fontSize = 9.sp, maxLines = 2)
            }
            Text("INVOICE", color = DarazOrange, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        }

        Column(Modifier.padding(Space.lg)) {

            // ── meta + QR verification, boxed like the reference's Date/Invoice#/etc. block ──
            Row(
                Modifier.fillMaxWidth().border(1.dp, HairlineBorder),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f).padding(Space.md)) {
                    DocLabel("Invoice No")
                    DocValue(invoice.invoiceNo)
                    Spacer(Modifier.height(Space.sm))
                    DocLabel("Date")
                    DocValue(invoice.createdAt.toLocalDate().toString())
                }
                Box(Modifier.border(1.dp, HairlineBorder).fillMaxHeight().padding(Space.sm), contentAlignment = Alignment.Center) {
                    // v113-161 — was calling QrRegistry.issue() fresh on every tap of
                    // this button, silently reissuing (and invalidating) an
                    // already-printed QR. DocumentQrControl checks for an existing
                    // active code first and requires an explicit confirm to reissue.
                    com.abm.erp.core.DocumentQrControl("SalesInvoice", invoice.id, onPayloadReady = onQrPayloadReady)
                }
            }

            Spacer(Modifier.height(Space.lg))

            // ── dealer + payment terms, bar + boxed like the reference's "Bill To:" ──
            com.abm.erp.core.DocBar("Dealer")
            Row(
                Modifier.fillMaxWidth().border(1.dp, HairlineBorder).padding(Space.md),
                horizontalArrangement = Arrangement.spacedBy(Space.md),
            ) {
                Column(Modifier.weight(1f)) {
                    DocValue(invoice.dealerName)
                    Text(invoice.dealerZone, fontSize = 10.sp, color = TextSecondary)
                }
                Column(Modifier.weight(1f)) {
                    DocLabel("Payment Terms")
                    // v113-275 — the person's own direct wording: "Paid"
                    // and "Due" specifically — "Credit" wasn't the word
                    // asked for. PARTIALLY_PAID (a real, distinct status
                    // this invoice can actually have — confirmed against
                    // SalesInvoice's own status comment) now shown as its
                    // own real label too, not folded into the same
                    // generic else-branch "Paid" and unpaid used to share.
                    DocValue(
                        when (invoice.status) {
                            "PAID" -> "Paid"
                            "PARTIALLY_PAID" -> "Partially Paid"
                            else -> "Due"
                        },
                    )
                    Text(
                        "Courier: ${invoice.courier?.ifBlank { null } ?: "—"}",
                        fontSize = 10.sp, color = TextSecondary,
                    )
                }
            }

            Spacer(Modifier.height(Space.lg))

            // ── item table — real grid, orange masthead, matching the reference ──
            com.abm.erp.core.DocBar("Invoice Items")
            Row(Modifier.fillMaxWidth().background(DarazOrange)) {
                ThGrid("#", 0.10f); ThGrid("Item / Product", 0.42f)
                ThGrid("Qty", 0.13f, TextAlign.End)
                ThGrid("Rate", 0.17f, TextAlign.End); ThGrid("Amount", 0.18f, TextAlign.End)
            }
            invoice.lineItems.forEachIndexed { i, item ->
                Row(
                    Modifier.fillMaxWidth().background(if (i % 2 == 1) Color(0xFFF7F8FA) else Color.White),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TdGrid("%02d".format(i + 1), 0.10f)
                    Column(Modifier.weight(0.42f).border(0.5.dp, HairlineBorder).padding(horizontal = 6.dp, vertical = 7.dp)) {
                        Text(item.name, fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                        Text(item.unit, fontSize = 9.sp, color = TextSecondary)
                    }
                    TdGrid("${item.qty}", 0.13f, TextAlign.End)
                    TdGrid("৳${"%,.0f".format(item.unitPrice)}", 0.17f, TextAlign.End)
                    TdGrid("৳${"%,.0f".format(item.lineTotal)}", 0.18f, TextAlign.End, FontWeight.SemiBold)
                }
            }
            if (invoice.lineItems.isEmpty()) {
                Text(
                    "কোনো আইটেম নেই।",
                    fontSize = 11.sp, color = TextSecondary,
                    modifier = Modifier.fillMaxWidth().border(1.dp, HairlineBorder).padding(vertical = 14.dp),
                    textAlign = TextAlign.Center,
                )
            }

            Spacer(Modifier.height(Space.md))

            // ── totals — boxed rows, ledger rule above the total, no heavy banner ──
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Column(Modifier.fillMaxWidth(0.62f).border(1.dp, HairlineBorder).padding(horizontal = Space.md, vertical = 6.dp)) {
                    TotalRow("Subtotal", "৳${"%,.0f".format(invoice.subTotal)}")
                    if (invoice.dealerDiscountPct > 0) {
                        TotalRow("Discount (${invoice.dealerDiscountPct}%)", "− ৳${"%,.0f".format(invoice.dealerDiscountAmt)}", StatusRed)
                    }
                    if (invoice.paidAmount > 0) {
                        TotalRow("Paid", "৳${"%,.0f".format(invoice.paidAmount)}", StatusGreen)
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(TextSecondary))
                    Spacer(Modifier.height(2.dp))
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("Total", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("৳${"%,.0f".format(invoice.total)}", color = DarazOrange, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }

            // ── party balance ──
            // Snapshot values are used when present. Invoices created before v70 have
            // none, so those fall back to the dealer's live balance and are labelled
            // as such — showing today's figure on an old bill without saying so would
            // be worse than showing nothing.
            Spacer(Modifier.height(Space.md))
            val dealers by MockRepository.dealers.collectAsState()
            val liveDue = dealers.firstOrNull { it.id == invoice.dealerId }?.dueBalance ?: 0.0
            val hasSnapshot = invoice.closingDueSnapshot > 0.0 || invoice.previousDueSnapshot > 0.0
            val prevDue = if (hasSnapshot) invoice.previousDueSnapshot else (liveDue - invoice.total).coerceAtLeast(0.0)
            val approvedTotalDue = if (hasSnapshot) invoice.closingDueSnapshot else liveDue
            // v113-213 — the person's own decision: pending (not yet
            // approved) invoices should also count toward the balance
            // shown here, but the pending portion must stay clearly called
            // out on its own line, not silently merged into one number —
            // so this is additive to the existing approved-balance
            // calculation above, not a replacement of it. Sums every OTHER
            // pending invoice for this same dealer (excluding the invoice
            // being viewed right now, which is already its own "This
            // Invoice" line below) — dealer.dueBalance itself intentionally
            // stays approved-only everywhere else (credit-limit checks,
            // etc.), only this display adds the pending view alongside it.
            val allInvoices by MockRepository.salesInvoices.collectAsState()
            val otherPendingSum = remember(allInvoices, invoice.id, invoice.dealerId) {
                allInvoices.filter { it.dealerId == invoice.dealerId && it.status == "PENDING" && it.id != invoice.id && !it.isDeleted }.sumOf { it.total }
            }
            val totalDue = approvedTotalDue + otherPendingSum

            Column(
                Modifier.fillMaxWidth()
                    .background(Color(0xFFF7F8FA), RoundedCornerShape(10.dp))
                    .padding(Space.md),
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Previous Due (Approved)", fontSize = 11.sp, color = TextSecondary)
                    Text("৳${"%,.0f".format(prevDue)}", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                }
                if (otherPendingSum > 0) {
                    Spacer(Modifier.height(4.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Pending (other invoices)", fontSize = 11.sp, color = StatusAmber)
                        Text("৳${"%,.0f".format(otherPendingSum)}", fontSize = 12.sp, color = StatusAmber, fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("This Invoice", fontSize = 11.sp, color = TextSecondary)
                    Text("৳${"%,.0f".format(invoice.total)}", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(6.dp))
                Box(Modifier.fillMaxWidth().height(1.dp).background(HairlineBorder))
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(if (otherPendingSum > 0) "Total Due (incl. pending)" else "Total Due", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                    Text(
                        "৳${"%,.0f".format(totalDue)}",
                        fontSize = 14.sp,
                        color = if (totalDue > 0) StatusAmber else StatusGreen,
                        fontWeight = FontWeight.Bold,
                    )
                }
                if (!hasSnapshot) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "* এই ইনভয়েসের সময়ের ব্যালেন্স সংরক্ষিত নেই — বর্তমান বকেয়া দেখানো হচ্ছে।",
                        fontSize = 8.sp, color = TextSecondary,
                    )
                }
            }

            Spacer(Modifier.height(Space.md))
            Text(
                "In Words: ${amountInWords(invoice.total)}",
                fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.Medium,
            )
            // v113-264 — Gift/Note, shown on the real printed document
            // whenever present — confirmed with the person: text only,
            // never part of the money calculation above it.
            if (!invoice.giftNote.isNullOrBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "🎁 Gift/Note: ${invoice.giftNote}",
                    fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.Medium,
                )
            }

            Spacer(Modifier.height(Space.xl))

            // ── signatures ──
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
                SignatureSlot("Prepared By", invoice.createdBy, Modifier.weight(1f))
                SignatureSlot("Checked By", "", Modifier.weight(1f))
                SignatureSlot("Authorized By", invoice.signedByRole ?: "", Modifier.weight(1f))
            }

            Spacer(Modifier.height(Space.lg))
            Text(
                "Thank you for your business!",
                fontSize = 10.sp, color = TextSecondary,
                modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(Space.sm))
        }
    }
}

// Document primitives (DocLabel/DocValue/Th/Td/TotalRow/SignatureSlot/amountInWords)
// moved to core/DocumentPrimitives.kt (v113-153) so MemoDocumentScreen reuses the
// exact same building blocks instead of a second copy. See imports above.
