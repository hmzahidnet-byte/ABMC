package com.abm.erp.core

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MarkunreadMailbox
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.CampaignChannel
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

/** A dealer/retailer as this composer needs to see them — just enough to call/text/select. */
data class CampaignParty(val id: String, val name: String, val phone: String, val zone: String, val due: Double = 0.0)

/**
 * v113-266 — full redesign, the person's own direct complaint: everything (search,
 * message box, template button, party list with per-row icons, campaign history) sat
 * stacked in one continuous scroll — "huge, পেরা পেরা লাগে". Split into two real,
 * separately-purposed tabs, and made everything that isn't the contact list itself
 * on-demand rather than permanently on screen:
 *
 *  - "প্রমোশনাল" — the general-purpose composer (same real Call/SMS/WhatsApp
 *    mechanism as before — unchanged). The message box and multi-select checkboxes
 *    are no longer permanently visible; a clean contact list is the default, with
 *    compose/select available on tap. History moved behind a small icon + dialog
 *    instead of a permanent list at the bottom of the scroll.
 *  - "বাকি তাগাদা" — the person's own new, simpler flow: search/QR-pick ONE dealer
 *    or retailer, see their real live due immediately, and send a reminder built
 *    from that real number — not a general compose screen repurposed for this.
 */
@Composable
fun PartyCampaignSection(
    /** e.g. "Dealer" / "Retailer" — display only. */
    audienceLabel: String,
    parties: List<CampaignParty>,
    onNavigate: (String) -> Unit = {},
) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("প্রমোশনাল") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("বাকি তাগাদা") })
        }
        when (tab) {
            0 -> PromotionalTab(audienceLabel, parties)
            else -> DueReminderTab(audienceLabel, parties, onNavigate)
        }
    }
}

// ── shared real send mechanisms — identical to the pre-redesign version, unchanged ──

private fun callOne(context: android.content.Context, phone: String, toast: (String) -> Unit) {
    try { context.startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:$phone"))) }
    catch (e: Exception) { toast("Call করা যায়নি।") }
}
private fun smsMany(context: android.content.Context, phones: List<String>, body: String, toast: (String) -> Unit) {
    try {
        val intent = android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:${phones.joinToString(",")}"))
        if (body.isNotBlank()) intent.putExtra("sms_body", body)
        context.startActivity(intent)
    } catch (e: Exception) { toast("SMS app পাওয়া যায়নি।") }
}
private fun whatsappOne(context: android.content.Context, phone: String, body: String, toast: (String) -> Unit) {
    try {
        val digits = phone.filter { it.isDigit() }
        val intl = if (digits.startsWith("880")) digits else "88" + digits.removePrefix("0").let { d -> if (d.startsWith("1")) "0$d" else d }
        val encoded = java.net.URLEncoder.encode(body, "UTF-8")
        context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://wa.me/$intl?text=$encoded")))
    } catch (e: Exception) { toast("WhatsApp খোলা যায়নি।") }
}
private fun personalize(p: CampaignParty, body: String) = body
    .replace("{নাম}", p.name)
    .replace("{বকেয়া}", "%,.0f".format(p.due))

// ============================================================
// Tab 1 — প্রমোশনাল/শুভেচ্ছা
// ============================================================

@Composable
private fun PromotionalTab(audienceLabel: String, parties: List<CampaignParty>) {
    val campaigns by MockRepository.campaigns.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current
    var query by remember { mutableStateOf("") }
    var dueOnly by remember { mutableStateOf(false) }
    var multiSelectMode by remember { mutableStateOf(false) }
    var selectedIds by remember { mutableStateOf(setOf<String>()) }
    var showHistory by remember { mutableStateOf(false) }
    // v113-266 — the message box is no longer permanently on screen; this
    // holds who a compose action is currently for (one row's own SMS/
    // WhatsApp icon, or the multi-select bar's own "SMS পাঠান" button) and
    // which channel, so ONE dialog serves every entry point instead of a
    // box sitting at the top of the screen at all times.
    var composeFor by remember { mutableStateOf<List<CampaignParty>?>(null) }
    var composeChannel by remember { mutableStateOf<String?>(null) } // "sms" | "whatsapp"

    fun toast(msg: String) = android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()

    val filtered = remember(parties, query, dueOnly) {
        val base = if (dueOnly) parties.filter { it.due > 0 } else parties
        (if (query.isBlank()) base else base.filter { it.name.contains(query, ignoreCase = true) || it.zone.contains(query, ignoreCase = true) })
            .sortedByDescending { it.due }
    }
    val selectedParties = remember(parties, selectedIds) { parties.filter { it.id in selectedIds } }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("$audienceLabel-দের সাথে সরাসরি যোগাযোগ", fontWeight = FontWeight.SemiBold, color = TextPrimary, modifier = Modifier.weight(1f))
            IconButton(onClick = { showHistory = true }) { Icon(Icons.Filled.History, contentDescription = "History", tint = TextPrimary) }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("নাম বা এলাকা দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            FilterChip(selected = dueOnly, onClick = { dueOnly = !dueOnly }, label = { Text("শুধু বকেয়া আছে এমন", fontSize = 11.sp) })
            FilterChip(
                selected = multiSelectMode,
                onClick = { multiSelectMode = !multiSelectMode; if (!multiSelectMode) selectedIds = emptySet() },
                label = { Text("☑ একাধিক বাছুন", fontSize = 11.sp) },
            )
        }

        if (multiSelectMode && selectedIds.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text("${selectedIds.size} জন বেছে নেওয়া হয়েছে", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { composeFor = selectedParties; composeChannel = "sms" }) { Text("📱 SMS লিখে পাঠান") }
                        if (selectedIds.size == 1) {
                            OutlinedButton(onClick = { composeFor = selectedParties; composeChannel = "whatsapp" }) { Text("💬 WhatsApp") }
                        }
                        TextButton(onClick = { selectedIds = emptySet() }) { Text("বাতিল") }
                    }
                    if (selectedIds.size > 1) {
                        Spacer(Modifier.height(4.dp))
                        Text("WhatsApp একসাথে একাধিক জনকে পাঠানো যায় না (WhatsApp-এর নিজস্ব সীমাবদ্ধতা) — একজন একজন করে নিচের তালিকা থেকে পাঠান।", fontSize = 9.sp, color = TextSecondary)
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Text("$audienceLabel তালিকা (${filtered.size})", fontWeight = FontWeight.SemiBold, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            filtered.take(50).forEach { p ->
                // v113-278 — the person's own direct request: Message/CRM
                // more organized and beautiful, matching the same real
                // boxy-avatar + accent-colour treatment already applied
                // to Dealer/Retailer List rows (v113-273) — same real
                // per-name hash colour, for a consistent visual language
                // across the app rather than a one-off style here.
                val pAccent = com.abm.erp.core.browseAvatarColor(p.name)
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (multiSelectMode) {
                            Checkbox(
                                checked = p.id in selectedIds,
                                onCheckedChange = { checked -> selectedIds = if (checked) selectedIds + p.id else selectedIds - p.id },
                            )
                        }
                        Box(
                            Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))
                                .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(pAccent.copy(alpha = 0.85f), pAccent))),
                            contentAlignment = Alignment.Center,
                        ) { Text(p.name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.SemiBold, color = TextPrimary, maxLines = 1)
                            Text("${p.zone} · ${p.phone.ifBlank { "নম্বর নেই" }}", style = MaterialTheme.typography.labelSmall, color = TextSecondary, maxLines = 1)
                            if (p.due > 0) {
                                Text("বকেয়া ৳${"%,.0f".format(p.due)}", style = MaterialTheme.typography.labelSmall, color = com.abm.erp.theme.WarningAmber, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        if (p.phone.isNotBlank()) {
                            Box(Modifier.size(30.dp).clip(RoundedCornerShape(8.dp)).background(SuccessGreen.copy(alpha = 0.12f))) {
                                IconButton(onClick = { callOne(context, p.phone) { m -> toast(m) } }, modifier = Modifier.size(30.dp)) { Icon(Icons.Filled.Call, contentDescription = "Call ${p.name}", tint = SuccessGreen, modifier = Modifier.size(16.dp)) }
                            }
                            Spacer(Modifier.width(4.dp))
                            Box(Modifier.size(30.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF2563EB).copy(alpha = 0.12f))) {
                                IconButton(onClick = { composeFor = listOf(p); composeChannel = "sms" }, modifier = Modifier.size(30.dp)) { Icon(Icons.Filled.MarkunreadMailbox, contentDescription = "SMS ${p.name}", tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp)) }
                            }
                            Spacer(Modifier.width(4.dp))
                            Box(Modifier.size(30.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF25D366).copy(alpha = 0.12f))) {
                                IconButton(onClick = { composeFor = listOf(p); composeChannel = "whatsapp" }, modifier = Modifier.size(30.dp)) { Icon(Icons.Filled.Send, contentDescription = "WhatsApp ${p.name}", tint = Color(0xFF25D366), modifier = Modifier.size(16.dp)) }
                            }
                        }
                    }
                }
            }
            if (filtered.isEmpty()) Text("কোনো $audienceLabel পাওয়া যায়নি।", color = TextSecondary, modifier = Modifier.padding(vertical = 8.dp))
        }
    }

    // v113-266 — the one compose dialog every entry point above opens —
    // same real message field + due-reminder template shortcut the old
    // always-visible box had, just on-demand now.
    if (composeFor != null && composeChannel != null) {
        val targets = composeFor!!
        val channel = composeChannel!!
        var body by remember(targets, channel) { mutableStateOf("") }
        androidx.compose.ui.window.Dialog(onDismissRequest = { composeFor = null; composeChannel = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
                    Text(
                        if (targets.size == 1) "${if (channel == "sms") "SMS" else "WhatsApp"} — ${targets.first().name}" else "SMS — ${targets.size} জনকে",
                        style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary,
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = body, onValueChange = { body = it },
                        label = { Text("বার্তা") }, minLines = 3, modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(4.dp))
                    TextButton(onClick = { body = "প্রিয় {নাম}, আপনার বর্তমান বকেয়া ৳{বকেয়া}। দ্রুত পরিশোধের অনুরোধ রইলো। ধন্যবাদ — ABM Corporation" }) {
                        Text("💰 বকেয়া রিমাইন্ডার টেমপ্লেট বসান", fontSize = 11.sp)
                    }
                    if (targets.size > 1) {
                        Text(
                            "একসাথে অনেকজনকে পাঠালে হুবহু যাবে — তাই {নাম}/{বকেয়া} ব্যবহার না করাই ভালো।",
                            fontSize = 9.5.sp, color = TextSecondary,
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            if (channel == "sms") {
                                if (targets.size == 1) smsMany(context, targets.map { it.phone }, personalize(targets.first(), body)) { m -> toast(m) }
                                else smsMany(context, targets.map { it.phone }, body) { m -> toast(m) }
                                MockRepository.broadcastCampaign(CampaignChannel.SMS, body, targets.map { it.zone }.distinct().joinToString(", "), onRejected = {})
                            } else {
                                whatsappOne(context, targets.first().phone, personalize(targets.first(), body)) { m -> toast(m) }
                                MockRepository.broadcastCampaign(CampaignChannel.WHATSAPP, body, targets.first().zone, onRejected = {})
                            }
                            composeFor = null; composeChannel = null
                        },
                        enabled = body.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("পাঠান") }
                }
            }
        }
    }

    if (showHistory) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showHistory = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
                    Text("পাঠানো Campaign — রেকর্ড (${campaigns.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    if (campaigns.isEmpty()) {
                        Text("এখনো কোনো campaign পাঠানো হয়নি।", color = TextSecondary)
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            campaigns.take(20).forEach { c ->
                                GlassCard(modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(c.channel.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                        Text("→ ${c.targetZone}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                    }
                                    Text(c.message, style = MaterialTheme.typography.bodySmall)
                                    Text("পৌঁছেছে: ${c.sentCount}", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    TextButton(onClick = { showHistory = false }, modifier = Modifier.fillMaxWidth()) { Text("বন্ধ করুন") }
                }
            }
        }
    }
}

// ============================================================
// Tab 2 — বাকি তাগাদা (Due Reminder)
// ============================================================

/**
 * v113-266 — the person's own new, simpler flow, described directly:
 * search/QR-pick ONE dealer/retailer → real live due shown immediately →
 * a reminder built from that real number → send. Deliberately NOT the
 * general composer reused — a dedicated, minimal path for exactly this
 * one task.
 */
@Composable
private fun DueReminderTab(audienceLabel: String, parties: List<CampaignParty>, onNavigate: (String) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var pickerOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var selectedId by remember { mutableStateOf<String?>(null) }

    fun toast(msg: String) = android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()

    val selected = parties.firstOrNull { it.id == selectedId }

    Column(Modifier.fillMaxSize()) {
        if (selected == null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { pickerOpen = !pickerOpen }) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("$audienceLabel বাছুন")
                }
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = { onNavigate("universal_scanner") }) {
                    Icon(Icons.Filled.QrCodeScanner, contentDescription = "Scan", tint = TextPrimary)
                }
            }
            if (pickerOpen) {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("নাম বা এলাকা দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                val matches = remember(parties, query) {
                    if (query.isBlank()) emptyList() else parties.filter { it.name.contains(query, true) || it.zone.contains(query, true) }.take(8)
                }
                matches.forEach { p ->
                    Row(
                        Modifier.fillMaxWidth().clickable { selectedId = p.id; pickerOpen = false; query = "" }.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column {
                            Text(p.name, color = TextPrimary)
                            Text(p.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        if (p.due > 0) Text("৳${"%,.0f".format(p.due)}", color = com.abm.erp.theme.WarningAmber, fontWeight = FontWeight.SemiBold)
                    }
                }
                if (query.isNotBlank() && matches.isEmpty()) {
                    Text("আপনার এলাকায় মেলেনি।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            } else {
                Spacer(Modifier.height(16.dp))
                Text("বাকি তাগাদা পাঠাতে একজন $audienceLabel বাছুন — real বকেয়ার হিসাব দেখাবে।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            }
        } else {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(selected.name, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(selected.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { selectedId = null }) { Text("বদলান") }
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("বর্তমান বকেয়া", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(
                        "৳${"%,.0f".format(selected.due)}",
                        fontWeight = FontWeight.Bold,
                        color = if (selected.due > 0) com.abm.erp.theme.WarningAmber else SuccessGreen,
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            // v113-266 — auto-filled the moment a party is selected, from
            // this same real live due above — kept editable, matching the
            // "practical, functional" bar the rest of this batch held to,
            // rather than a locked, non-adjustable message.
            var reminderText by remember(selected.id) {
                mutableStateOf("প্রিয় ${selected.name}, আপনার বর্তমান বকেয়া ৳${"%,.0f".format(selected.due)}। দ্রুত পরিশোধের অনুরোধ রইলো। ধন্যবাদ — ABM Corporation")
            }
            OutlinedTextField(value = reminderText, onValueChange = { reminderText = it }, label = { Text("বার্তা") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        if (selected.phone.isBlank()) { toast("এই $audienceLabel-এর কোনো ফোন নম্বর নেই।"); return@Button }
                        smsMany(context, listOf(selected.phone), reminderText) { m -> toast(m) }
                        MockRepository.broadcastCampaign(CampaignChannel.SMS, reminderText, selected.zone, onRejected = {})
                    },
                    enabled = selected.phone.isNotBlank(),
                ) { Text("📱 SMS পাঠান") }
                OutlinedButton(
                    onClick = {
                        if (selected.phone.isBlank()) { toast("এই $audienceLabel-এর কোনো ফোন নম্বর নেই।"); return@OutlinedButton }
                        whatsappOne(context, selected.phone, reminderText) { m -> toast(m) }
                        MockRepository.broadcastCampaign(CampaignChannel.WHATSAPP, reminderText, selected.zone, onRejected = {})
                    },
                    enabled = selected.phone.isNotBlank(),
                ) { Text("💬 WhatsApp পাঠান") }
            }
            if (selected.phone.isBlank()) {
                Spacer(Modifier.height(4.dp))
                Text("⚠ কোনো ফোন নম্বর সংরক্ষিত নেই।", style = MaterialTheme.typography.labelSmall, color = DangerRed)
            }
        }
    }
}
