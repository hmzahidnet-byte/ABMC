package com.abm.erp.ui.chairman

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import androidx.compose.ui.unit.sp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.MockRepository
import com.abm.erp.data.UserRole
import com.abm.erp.theme.*

/**
 * v113-154 — one tile in the "Full Module Overview" quick-access grid. `dest`
 * is a real onNavigate() argument: either a standalone route ("ledger",
 * "reports", "system_health_dashboard" — all already registered in
 * NavGraph.kt) or "chairman_module?key=<drawer key>", the exact same
 * deep-link mechanism DMS/RMS/HR/FMS already use (`ChairmanHomeScreen` reads
 * this `key` query param as its initial `selected` drawer tab — confirmed
 * against its own source, not assumed). `dest == null` means the tile is
 * purely informational (the Dashboard tile — it IS this screen).
 */
private data class ChairmanQuickTile(
    val number: Int,
    val title: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val stat: String?,
    val dest: String?,
)

/**
 * Enterprise Workspace redesign — Chairman Intelligence Hub. A dedicated executive workspace,
 * not a new business module: every number here is read from repository functions that already
 * existed (computeSalesKpi/computeCollectionKpi/computeRetailerKpi/topRisks/
 * computeSmartBusinessAlerts/computeSystemHealthSnapshot — the same ones BoardroomScreen and the
 * Dashboard already use), reused rather than reimplemented. No new business logic.
 *
 * Access: Chairman always. Anyone else only if the Chairman has explicitly delegated authority to
 * them via the existing Delegation system (MockRepository.activeDelegationFor) — never a new
 * access-control mechanism, and never an identity re-selection.
 */
@Composable
fun ChairmanHubScreen(onNavigate: (String) -> Unit = {}) {
    val context = LocalContext.current
    val currentUser = MockRepository.currentUser
    val profiles by MockRepository.employeeProfiles.collectAsState()

    val activeDelegation = remember(currentUser.employeeId) { MockRepository.activeDelegationFor(currentUser.employeeId) }
    val delegatorRole = remember(activeDelegation) { activeDelegation?.let { d -> profiles.firstOrNull { it.id == d.delegatorId }?.role } }
    val authorized = currentUser.role == UserRole.CHAIRMAN || delegatorRole == UserRole.CHAIRMAN

    if (!authorized) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("🔒 Chairman Intelligence Hub", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(
                "শুধু Chairman অথবা Chairman কর্তৃক explicitly authorized ব্যক্তি এই workspace দেখতে পারবেন।",
                style = MaterialTheme.typography.bodyMedium, color = TextSecondary,
            )
        }
        return
    }

    val dealers by MockRepository.dealers.collectAsState()
    val retailers by MockRepository.retailers.collectAsState()
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val stockLevels by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
    val approvals by MockRepository.approvals.collectAsState()
    val payroll by MockRepository.payroll.collectAsState()

    // v113-131 — real weekly Sales-vs-Collection buckets for the last 5 weeks
    // (Monday-anchored), computed directly from the same real salesInvoices/
    // partyCollections lists every other KPI on this screen already reads —
    // no separate/duplicate data source, no fabricated week-over-week shape.
    val salesInvoicesAll by MockRepository.salesInvoices.collectAsState()
    val collectionsAll by MockRepository.partyCollections.collectAsState()
    val weeklySalesVsCollection = remember(salesInvoicesAll, collectionsAll) {
        val today = java.time.LocalDate.now()
        val thisMonday = today.minusDays(((today.dayOfWeek.value - 1).toLong()))
        (4 downTo 0).map { weeksAgo ->
            val weekStart = thisMonday.minusWeeks(weeksAgo.toLong())
            val weekEnd = weekStart.plusDays(7)
            val sales = salesInvoicesAll.filter { !it.isDeleted && !it.createdAt.toLocalDate().isBefore(weekStart) && it.createdAt.toLocalDate().isBefore(weekEnd) }
                .sumOf { it.lineItems.sumOf { li -> li.lineTotal } }
            val collected = collectionsAll.filter { it.status == "VERIFIED" && !it.createdAt.toLocalDate().isBefore(weekStart) && it.createdAt.toLocalDate().isBefore(weekEnd) }
                .sumOf { it.amount }
            Triple("${weekStart.dayOfMonth} ${weekStart.month.name.take(3).lowercase().replaceFirstChar { c -> c.uppercase() }}", sales, collected)
        }
    }

    val salesKpi = remember { MockRepository.computeSalesKpi() }
    val collectionKpi = remember { MockRepository.computeCollectionKpi() }
    val retailerKpi = remember { MockRepository.computeRetailerKpi() }
    val risks = remember { MockRepository.topRisks() }

    // v113-263 — same real Export/Share/Print registration as the other 4
    // module dashboards, using the same real KPI numbers this screen's
    // own Business Overview card already shows.
    com.abm.erp.core.RegisterModuleMenuContent(
        title = "Chairman — Business Overview",
        rows = listOf(
            "This Month Sales" to "৳${"%,.0f".format(salesKpi.thisMonth)}",
            "This Month Collection" to "৳${"%,.0f".format(collectionKpi.thisMonth)}",
            "Outstanding Due" to "৳${"%,.0f".format(collectionKpi.outstandingDue)}",
            "Dealer" to "${dealers.count { !it.isDeleted }}",
            "Retailer" to "${retailers.count { !it.isDeleted }}",
            "Product" to "${products.count { !it.isDeleted }}",
        ),
    )
    var smartAlerts by remember { mutableStateOf<List<MockRepository.SmartBusinessAlert>>(emptyList()) }
    var healthSnapshot by remember { mutableStateOf<MockRepository.SystemHealthSnapshot?>(null) }
    LaunchedEffect(Unit) {
        smartAlerts = MockRepository.computeSmartBusinessAlerts()
        healthSnapshot = MockRepository.computeSystemHealthSnapshot(context)
    }

    val pendingApprovalsCount = approvals.count { it.status == com.abm.erp.data.ApprovalStatus.PENDING }
    val totalDue = dealers.sumOf { it.dueBalance } + retailers.sumOf { it.dueBalance }
    val lowStockCount = stockLevels.count { it.isLowStock }
    val dashTarget = payroll.sumOf { it.targetAmount }
    val dashAchieved = payroll.sumOf { it.achievedAmount }

    // v113-154 — reference-poster gaps closed: real employee count, real top-due
    // parties, real top-performing areas. All three read data already loaded on
    // this screen (profiles/dealers/retailers/salesInvoicesAll) — no new data
    // source, nothing invented.
    val totalEmployees = profiles.count { it.hasActiveAccess }
    val topDueParties = remember(dealers, retailers) {
        (dealers.filter { !it.isDeleted && it.dueBalance > 0 }.map { Triple(it.name, it.dueBalance, "Dealer") } +
            retailers.filter { !it.isDeleted && it.dueBalance > 0 }.map { Triple(it.name, it.dueBalance, "Retailer") })
            .sortedByDescending { it.second }.take(5)
    }
    val topAreas = remember(salesInvoicesAll) {
        salesInvoicesAll.filter { !it.isDeleted && it.dealerZone.isNotBlank() }
            .groupBy { it.dealerZone }
            .mapValues { (_, invs) -> invs.sumOf { it.total } }
            .entries.sortedByDescending { it.value }.take(5)
    }
    // v113-208 — Chairman module simplification, the person's explicit new
    // priority this pass: this 13-tile grid was mostly redundant with the
    // module's own 11-item drawer sitting one tap away the whole time (tap
    // the drawer's "Approval Center" vs. this tile labelled "Approval
    // Center" — same destination, same screen, no difference at all) —
    // and tile #1 ("Chairman Dashboard") was outright dead: dest == null
    // means it was never clickable to begin with, a decorative button that
    // did nothing, exactly the kind of "option with no real functionality"
    // called out directly. Cut every tile that duplicates a drawer item
    // one-for-one (Approval Center, Business Overview, Company Settings,
    // Reports & Analytics, Audit Trail, Backup & Restore, System Logs,
    // Notices — all still one tap away via the drawer, zero functionality
    // lost) and the dead tile. Kept only what genuinely isn't reachable any
    // other way from here: the four cross-module shortcuts into DMS/RMS/
    // HR's own Chairman panels, and Ledger Book. 13 tiles down to 5.
    val quickTiles = listOf(
        ChairmanQuickTile(1, "Product Control", Icons.Filled.Inventory2, "${products.count { !it.isDeleted }} active", "dms?key=chairman"),
        ChairmanQuickTile(2, "User & Role Management", Icons.Filled.ManageAccounts, "$totalEmployees employees", "hr_module?key=chairman"),
        ChairmanQuickTile(3, "Dealer Control", Icons.Filled.Groups, "${dealers.count { !it.isDeleted }} dealers", "dms?key=chairman"),
        // v113-265 — RMS's own standalone Chairman tab removed with the
        // rest of the module; Retailer Control now lives inside DMS's own
        // Chairman panel (Approve tab has Retailer Add/Cancellation,
        // Restore tab has Retailer Restore).
        ChairmanQuickTile(4, "Retailer Control", Icons.Filled.Store, "${retailers.count { !it.isDeleted }} retailers", "dms?key=chairman"),
        ChairmanQuickTile(5, "Ledger Book", Icons.Filled.MenuBook, "৳${"%,.0f".format(totalDue)} due", "ledger"),
    )

    Column(Modifier.fillMaxSize()) {
        com.abm.erp.core.ModuleWorkspaceHeader("Chairman Intelligence Hub", "👑", 0xFF0F1E3D, 0xFF0A1428, iconVector = Icons.Filled.WorkspacePremium, miniDashboard = {
            com.abm.erp.core.ModuleStat("Pending Approvals", "$pendingApprovalsCount", if (pendingApprovalsCount > 0) WarningAmber else SuccessGreen)
            com.abm.erp.core.ModuleStat("Total Due", "৳${"%,.0f".format(totalDue)}", if (totalDue > 0) WarningAmber else SuccessGreen)
            com.abm.erp.core.ModuleStat("Low Stock", "$lowStockCount", if (lowStockCount > 0) DangerRed else SuccessGreen)
            com.abm.erp.core.ModuleStat("Alerts", "${smartAlerts.size}", if (smartAlerts.isNotEmpty()) DangerRed else SuccessGreen)
        })

        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            // v113-221 — the person's own explicit decision: this was a
            // full standalone "Approval Center" drawer destination
            // (removed — everything else it showed duplicated a module's
            // own approval panel). Correction Requests is the one
            // genuinely homeless piece — no single module owns it — so it
            // stays reachable, but as a section right here on the
            // dashboard, not a separate destination.
            com.abm.erp.ui.chairmanmodule.ChairmanCorrectionSection()

            // v113-239 — a real, valuable function found with zero callers
            // anywhere in the app, from the same proactive sweep as the
            // login/payroll/vacancy findings: checkAndNotifyHierarchyIssues
            // already correctly detects invalid reporting chains,
            // soon-expiring delegations, and employees missing a territory
            // assignment — and creates real notifications for each — but
            // had no trigger anywhere. A manual button here rather than an
            // automatic background job: this app has no existing periodic-
            // job infrastructure to hook into safely, and a Chairman-
            // initiated check is honest about when it actually runs,
            // rather than silently claiming to run on a schedule it
            // doesn't have.
            run {
                val healthScope = rememberCoroutineScope()
                var checking by remember { mutableStateOf(false) }
                var checkedMsg by remember { mutableStateOf<String?>(null) }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("System Health Check", fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("Reporting chain, delegation, territory coverage — সমস্যা থাকলে Notification-এ জানাবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            checkedMsg?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = SuccessGreen) }
                        }
                        Button(
                            enabled = !checking,
                            onClick = {
                                checking = true; checkedMsg = null
                                healthScope.launch {
                                    MockRepository.checkAndNotifyHierarchyIssues()
                                    checking = false
                                    checkedMsg = "✓ চেক সম্পন্ন — Notification দেখুন।"
                                }
                            },
                        ) { Text(if (checking) "..." else "Run Check") }
                    }
                }
            }

            // ---- Full Module Overview — every reference-poster area, one tap away ----
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("সব বিভাগ — Full Module Overview", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                quickTiles.chunked(2).forEach { rowTiles ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowTiles.forEach { tile ->
                            val dest = tile.dest
                            Column(
                                Modifier.weight(1f)
                                    .background(androidx.compose.ui.graphics.Color(0xFFF7F8FA), androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                                    .let { m -> if (dest != null) m.clickable { onNavigate(dest) } else m }
                                    .padding(10.dp),
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        Modifier.size(22.dp).background(DarazOrange.copy(alpha = 0.14f), androidx.compose.foundation.shape.RoundedCornerShape(7.dp)),
                                        contentAlignment = Alignment.Center,
                                    ) { Text("${tile.number}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DarazOrange) }
                                    Spacer(Modifier.width(6.dp))
                                    Icon(tile.icon, null, tint = TextSecondary, modifier = Modifier.size(15.dp))
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(tile.title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, lineHeight = 13.sp)
                                tile.stat?.let {
                                    Spacer(Modifier.height(2.dp))
                                    Text(it, fontSize = 9.sp, color = TextSecondary)
                                }
                            }
                        }
                        if (rowTiles.size == 1) Spacer(Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }

            // ---- Executive Dashboard ----
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("ledger") }) {
                Text("Executive Dashboard", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Today's Sales", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(salesKpi.today)}", fontWeight = FontWeight.Bold) }
                    Column { Text("This Month", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(salesKpi.thisMonth)}", fontWeight = FontWeight.Bold) }
                    Column { Text("Collection Efficiency", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${"%.0f".format(collectionKpi.efficiencyPct)}%", fontWeight = FontWeight.Bold) }
                }
            }

            // v113-131 — the drawer's own subtitle for this screen already says
            // "Business Overview in Real Time" — this card completes what that
            // promised but the screen didn't yet deliver: Total Sales/Collection/
            // Due (already-computed real KPIs, reused not reinvented) plus Total
            // Dealers/Retailers/Products (real counts) and a real weekly
            // Sales-vs-Collection comparison, not a second competing screen.
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Business Overview — This Month", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Total Sales", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(salesKpi.thisMonth)}", fontWeight = FontWeight.Bold, color = SuccessGreen) }
                    Column { Text("Collection", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(collectionKpi.thisMonth)}", fontWeight = FontWeight.Bold, color = SuccessGreen) }
                    Column { Text("Total Due", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(collectionKpi.outstandingDue)}", fontWeight = FontWeight.Bold, color = WarningAmber) }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Total Dealers", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${dealers.count { !it.isDeleted }}", fontWeight = FontWeight.Bold) }
                    Column { Text("Total Retailers", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${retailers.count { !it.isDeleted }}", fontWeight = FontWeight.Bold) }
                    Column { Text("Total Products", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${products.count { !it.isDeleted }}", fontWeight = FontWeight.Bold) }
                }
                Spacer(Modifier.height(6.dp))
                // v113-154 — reference poster's Chairman Dashboard names "Total Employees"
                // as its own figure; added as a clearly-labelled line rather than
                // squeezing a 4th column into the row above.
                Text("Total Employees: $totalEmployees", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(14.dp))
                Text("Sales vs Collection — Last 5 Weeks", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = TextSecondary)
                Spacer(Modifier.height(8.dp))
                if (weeklySalesVsCollection.all { it.second == 0.0 && it.third == 0.0 }) {
                    Text("এই সময়ে দেখানোর মতো যথেষ্ট ডেটা নেই।", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                } else {
                    com.abm.erp.core.DualSeriesBarChart(weeklySalesVsCollection, "Sales", "Collection")
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    var overviewError by remember { mutableStateOf<String?>(null) }
                    TextButton(onClick = {
                        try {
                            val file = com.abm.erp.core.exportListAsCsv(
                                context, "BusinessOverview", weeklySalesVsCollection,
                                listOf("Week" to { w: Triple<String, Double, Double> -> w.first }, "Sales" to { w -> "%,.0f".format(w.second) }, "Collection" to { w -> "%,.0f".format(w.third) }),
                            )
                            com.abm.erp.core.shareStructuredCsv(context, file, "Business Overview")
                        } catch (e: Exception) { overviewError = "Export ব্যর্থ হয়েছে: ${e.message ?: "unknown error"}" }
                    }) { Text("↓ Download") }
                    TextButton(onClick = {
                        val summary = "Business Overview — This Month\nTotal Sales: ৳${"%,.0f".format(salesKpi.thisMonth)}\nCollection: ৳${"%,.0f".format(collectionKpi.thisMonth)}\nTotal Due: ৳${"%,.0f".format(collectionKpi.outstandingDue)}\nDealers: ${dealers.count { !it.isDeleted }} · Retailers: ${retailers.count { !it.isDeleted }} · Products: ${products.count { !it.isDeleted }}"
                        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                        context.startActivity(android.content.Intent.createChooser(intent, "Business Overview"))
                    }) { Text("↗ Share") }
                    TextButton(onClick = { onNavigate("reports") }) { Text("Full Report") }
                    overviewError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                }
            }

            // ---- Top 5 Due Dealers (reference poster's Chairman Dashboard list) ----
            if (topDueParties.isNotEmpty()) {
                GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("dealers") }) {
                    Text("Top 5 Due Dealers/Retailers", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    topDueParties.forEach { (name, due, kind) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(name, fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                                Text(kind, fontSize = 9.sp, color = TextSecondary)
                            }
                            Text("৳${"%,.0f".format(due)}", fontSize = 12.sp, color = WarningAmber, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // ---- Top Performing Areas (reference poster's Business Overview section) ----
            if (topAreas.isNotEmpty()) {
                GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("reports") }) {
                    Text("Top Performing Areas", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    topAreas.forEach { (zone, amount) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(zone, fontSize = 12.sp, color = TextPrimary)
                            Text("৳${"%,.0f".format(amount)}", fontSize = 12.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // ---- Static Graphs: real last-7-days sales trend (non-interactive, board-report style) ----
            val dailySales = healthSnapshot?.salesDailyLast7Days
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Sales Trend — Last 7 Days", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                if (dailySales != null && dailySales.size >= 2) {
                    com.abm.erp.ui.core.TrendLineChart(values = dailySales)
                } else {
                    Text("গ্রাফ দেখানোর জন্য যথেষ্ট ডেটা এখনো নেই।", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }

            // ---- System Health ----
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("system_health_dashboard") }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("System Health", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                val h = healthSnapshot
                if (h == null) {
                    com.abm.erp.core.WorkspaceLoadingState("System Health লোড হচ্ছে…")
                } else {
                    Text(if (h.serverOnline) "🟢 Server Online" else "🔴 Server Offline", color = if (h.serverOnline) SuccessGreen else DangerRed, style = MaterialTheme.typography.bodySmall)
                    Text("Devices: ${h.activeDeviceCount} active · ${h.offlineDeviceCount} offline", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Text("Today's Login: ${h.todaysLoginSuccessCount} success · ${h.todaysLoginFailedCount} failed", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Text("Sync Failures (session): ${h.failedSyncCount}", style = MaterialTheme.typography.bodySmall, color = if (h.failedSyncCount > 0) WarningAmber else TextSecondary)
                    if (h.errors.isNotEmpty()) Text("⚠ ${h.errors.size} system error(s) detected", style = MaterialTheme.typography.bodySmall, color = DangerRed)
                }
            }

            // ---- Business Risks ----
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("boardroom") }) {
                Text("Business Risks", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = DangerRed)
                Spacer(Modifier.height(6.dp))
                if (risks.isEmpty()) {
                    Text("এই মুহূর্তে কোনো চিহ্নিত ঝুঁকি নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                } else {
                    risks.forEach { r -> Text("• ${r.type} — ${r.evidence}", style = MaterialTheme.typography.bodySmall) }
                }
            }

            // ---- Approvals ----
            // Decision 2 (v113-72) — Chairman *observes* here; he doesn't action from here.
            // The central Approvals screen is gone, so this card is a count only and each
            // approval is approved inside its own module (HRM / Expenses / Ledger / DMS).
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Approvals", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    if (pendingApprovalsCount > 0) "$pendingApprovalsCount টি অনুমোদন অপেক্ষমাণ — যে মডিউলের অনুমোদন, সেই মডিউলেই অনুমোদন করুন।" else "কোনো অপেক্ষমাণ অনুমোদন নেই।",
                    color = if (pendingApprovalsCount > 0) WarningAmber else SuccessGreen, style = MaterialTheme.typography.bodySmall,
                )
            }

            // ---- Company Performance ----
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("dealers") }) {
                Text("Company Performance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Active Retailers", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${retailerKpi.totalActive}", fontWeight = FontWeight.Bold) }
                    Column { Text("New This Month", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${retailerKpi.newThisMonth}", fontWeight = FontWeight.Bold, color = SuccessGreen) }
                    Column { Text("Inactive", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("${retailerKpi.inactive}", fontWeight = FontWeight.Bold, color = if (retailerKpi.inactive > 0) WarningAmber else SuccessGreen) }
                }
            }

            // ---- Target Achievement ----
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("hrm") }) {
                Text("Target Achievement", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(if (dashTarget > 0) "৳${"%,.0f".format(dashAchieved)} / ৳${"%,.0f".format(dashTarget)} (${"%.0f".format(dashAchieved / dashTarget * 100)}%)" else "কোনো টার্গেট নির্ধারিত নেই।", fontWeight = FontWeight.Bold, color = Gold)
                if (dashTarget > 0) {
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(progress = (dashAchieved / dashTarget).toFloat().coerceIn(0f, 1f), modifier = Modifier.fillMaxWidth().height(6.dp), color = Gold)
                }
            }

            // ---- Alerts ----
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("notifications") }) {
                Text("Alerts", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                if (smartAlerts.isEmpty()) {
                    Text("এই মুহূর্তে কোনো সতর্কতা নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                } else {
                    smartAlerts.forEach { a ->
                        Text(
                            "${if (a.severity == MockRepository.SmartAlertSeverity.CRITICAL) "🔴" else "⚠"} ${a.message}",
                            color = if (a.severity == MockRepository.SmartAlertSeverity.CRITICAL) DangerRed else WarningAmber,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }

            // ---- Recent Activity (company-wide) ----
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("enterprise_audit_center") }) {
                com.abm.erp.core.ModuleRecentActivity(
                    setOf("SalesInvoice", "PartyCollection", "Collection", "WarehouseTransfer", "ProductionOrder", "Voucher", "CorrectionRequest"),
                    limit = 6,
                )
            }

            // ---- Admin & Access Tools (moved here from Dashboard) ----
            var showAccountsPanel by remember { mutableStateOf(false) }
            var showDevicesPanel by remember { mutableStateOf(false) }
            var showLoginLogPanel by remember { mutableStateOf(false) }
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Admin & Access Tools", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                // Blueprint §24 — 3-column icon-chip tile grid. Dialog-backed tools open their
                // existing screens; route-backed tools navigate to routes already registered in
                // NavGraph. No new screens, no new permissions.
                // v113-215 — the person asked directly whether the Chairman
                // module was genuinely fixed as asked; re-checking properly
                // (rather than just repeating the earlier v113-208 answer)
                // found this SEPARATE tile grid had never actually been
                // checked against the drawer — only the "Full Module
                // Overview" grid was, back at v113-208. Six of the original
                // fifteen tiles here turned out to be exact duplicates of a
                // drawer item, confirmed one at a time by tracing each
                // route to its real destination screen, not assumed from
                // the label: Backup & Recovery (= drawer's Backup &
                // Restore), Audit Log (= drawer's System Logs), Business
                // Rules, Global Settings (= drawer's Company Settings),
                // Helpdesk (= drawer's Support/Helpdesk), and Reports (=
                // drawer's Reports & Analytics). A seventh, System Health,
                // wasn't a drawer duplicate but WAS a duplicate of this
                // same screen's own earlier "System Health" card just
                // above — which already shows a live summary, not just a
                // bare link, so it's the better version of the two. Cut
                // all seven; kept only what's genuinely reachable no other
                // way from here.
                val tools: List<Triple<String, androidx.compose.ui.graphics.vector.ImageVector, () -> Unit>> = listOf(
                    // v113-213 — was opening VacantPositionsScreen, a
                    // synthetic-only screen (toggle a fake EMPLOYEE_DIRECTORY
                    // entry as "vacant") entirely disconnected from the real
                    // Vacancy model HR's own Vacancy & Target Center uses —
                    // marking someone vacant here had zero effect on the real
                    // coverage-notification system (NotificationsScreen.kt/
                    // MainDashboardScreen.kt, both switched to real Vacancy
                    // data this same pass). Routes to the real thing instead.
                    Triple("Vacant\nPositions", Icons.Filled.PersonSearch) { onNavigate("hr_module?key=chairman") },
                    Triple("Account &\nAccess", Icons.Filled.VpnKey) { showAccountsPanel = true },
                    Triple("Trusted\nDevices", Icons.Filled.PhoneAndroid) { showDevicesPanel = true },
                    Triple("Login\nActivity", Icons.Filled.History) { showLoginLogPanel = true },
                    Triple("Chairman\nNotice", Icons.Filled.Campaign) { onNavigate("notifications") },
                    Triple("Communication\nHub", Icons.Filled.Forum) { onNavigate("comms") },
                    Triple("Complaint\nBox", Icons.Filled.MarkunreadMailbox) { onNavigate("complaint") },
                    Triple("Sync\nStatus", Icons.Filled.Sync) { onNavigate("sync_status_center") },
                )
                val accents = listOf(
                    com.abm.erp.theme.StatusRed, com.abm.erp.theme.StatusGreen, com.abm.erp.theme.StatusBlue,
                    com.abm.erp.theme.DarazOrange, com.abm.erp.theme.StatusGreen, com.abm.erp.theme.StatusRed,
                    com.abm.erp.theme.StatusBlue, com.abm.erp.theme.DarazOrange, com.abm.erp.theme.StatusAmber,
                    com.abm.erp.theme.StatusBlue, com.abm.erp.theme.StatusRed, com.abm.erp.theme.StatusAmber,
                    com.abm.erp.theme.StatusBlue, com.abm.erp.theme.StatusGreen, com.abm.erp.theme.DarazOrange,
                )
                tools.chunked(3).forEachIndexed { rowIdx, rowTools ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowTools.forEachIndexed { colIdx, (label, icon, action) ->
                            val accent = accents[(rowIdx * 3 + colIdx) % accents.size]
                            Column(
                                Modifier.weight(1f)
                                    .clickable(onClick = action)
                                    .padding(vertical = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                com.abm.erp.core.IconChip(icon = icon, accent = accent, size = 38)
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    lineHeight = 13.sp,
                                )
                            }
                        }
                        repeat(3 - rowTools.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            if (showAccountsPanel) {
                Dialog(onDismissRequest = { showAccountsPanel = false }) {
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                        com.abm.erp.ui.dashboard.AccountsScreen(onClose = { showAccountsPanel = false })
                    }
                }
            }
            if (showDevicesPanel) {
                Dialog(onDismissRequest = { showDevicesPanel = false }) {
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                        com.abm.erp.ui.dashboard.TrustedDevicesScreen(onClose = { showDevicesPanel = false })
                    }
                }
            }
            if (showLoginLogPanel) {
                Dialog(onDismissRequest = { showLoginLogPanel = false }) {
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                        com.abm.erp.ui.dashboard.LoginActivityLogScreen(onClose = { showLoginLogPanel = false })
                    }
                }
            }
        }
    }
}
