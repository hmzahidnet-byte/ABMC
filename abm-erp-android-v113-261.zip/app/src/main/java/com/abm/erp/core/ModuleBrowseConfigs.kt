package com.abm.erp.core

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.MarkunreadMailbox
import androidx.compose.material.icons.filled.Send
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.Dealer
import com.abm.erp.data.EmployeeProfile
import com.abm.erp.data.MockRepository
import com.abm.erp.data.createCustomerComplaint
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.data.PartyType
import com.abm.erp.data.Product
import com.abm.erp.data.Retailer
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import kotlinx.coroutines.launch
import java.time.LocalDate

/**
 * v113-85 — per-module descriptors for the shared browse flow (ModuleBrowseFlow.kt).
 * Each is small on purpose: the screens live in one place, these only say what a
 * module's records look like and which drill-downs it genuinely has.
 *
 * Honest asymmetry, deliberately preserved rather than papered over:
 *  - Dealer and Retailer are money-bearing parties → they get Ledger, Calendar,
 *    Product Graph and 90-Day, all off real PartyLedger / invoice / collection data.
 *  - Employee is not a money-bearing party in this codebase — there is no employee
 *    ledger — so HR's browse flow shows identity, role/geo and status only, with no
 *    ledger/graph buttons. Rendering empty ones would imply data exists that doesn't.
 */

private fun classLabel(c: String) = when (c) { "A" -> "A-Class"; "C" -> "C-Class"; else -> "B-Class" }

// ── DMS · Dealer ───────────────────────────────────────────────────────────────

@Composable
fun rememberDealerBrowseConfig(zones: List<String>): BrowseConfig<Dealer> {
    val invoices by MockRepository.salesInvoices.collectAsState()
    val collections by MockRepository.partyCollections.collectAsState()
    return remember(zones, invoices, collections) {
        BrowseConfig(
            moduleName = "DMS", entityLabel = "Dealer",
            colorStart = 0xFF2563EB, colorEnd = 0xFF1E3A8A,
            idOf = { it.id },
            titleOf = { it.name },
            codeOf = { it.dealerCode.ifBlank { it.id.take(8).uppercase() } },
            subtitleOf = { "${it.phone.ifBlank { "ফোন নেই" }} · ${it.zone}" },
            categoryOf = { "${classLabel(it.classification)} Dealer" },
            isActiveOf = { it.isActive },
            photoUriOf = { it.photoUri },
            searchMatches = { d, q -> d.name.contains(q, true) || d.dealerCode.contains(q, true) || d.phone.contains(q, true) || d.zone.contains(q, true) },
            facets = listOf(
                BrowseFacet("Area", zones) { d, o -> d.zone == o },
                BrowseFacet("Category", listOf("A", "B", "C")) { d, o -> d.classification == o },
                BrowseFacet("Status", listOf("Active", "Inactive")) { d, o -> (o == "Active") == d.isActive },
            ),
            infoRows = { d ->
                listOf(
                    BrowseInfoRow("Dealer Code", d.dealerCode.ifBlank { d.id.take(8).uppercase() }),
                    BrowseInfoRow("Dealer Name", d.name),
                    BrowseInfoRow("Owner Name", d.proprietorName.ifBlank { "—" }),
                    BrowseInfoRow("Phone", d.phone.ifBlank { "—" }),
                    BrowseInfoRow("Area / Zone", d.zone),
                    BrowseInfoRow("Address", d.address.ifBlank { "—" }),
                    BrowseInfoRow("Category", "${classLabel(d.classification)} Dealer"),
                    BrowseInfoRow("Status", if (d.isActive) "Active" else "Inactive"),
                    BrowseInfoRow("Join Date", d.createdAt.toLocalDate().toString()),
                    BrowseInfoRow("Credit Limit", if (d.creditLimit > 0) "৳${"%,.0f".format(d.creditLimit)}" else "নির্ধারিত নেই"),
                )
            },
            kpis = { d ->
                val inv = invoices.filter { !it.isDeleted && it.dealerId == d.id }
                val col = collections.filter { it.partyType == PartyType.DEALER && it.partyId == d.id && it.status == "VERIFIED" }
                listOf(
                    BrowseKpi("Total Sales", "৳${"%,.0f".format(inv.sumOf { it.total })}"),
                    BrowseKpi("Total Collection", "৳${"%,.0f".format(col.sumOf { it.amount })}", SuccessGreen),
                    BrowseKpi("Total Due", "৳${"%,.0f".format(d.dueBalance)}", if (d.dueBalance > 0) WarningAmber else SuccessGreen),
                )
            },
            hasLedger = true,
            activities = { d -> rememberPartyActivities(PartyType.DEALER, d.id) },
            hasGraph = true,
            slices = { d ->
                invoices.filter { !it.isDeleted && it.dealerId == d.id }
                    .flatMap { it.lineItems }.groupBy { it.name }
                    .map { (n, l) -> BrowseSlice(n, l.sumOf { it.lineTotal }) }
            },
            has90Day = true,
            summary90 = { d ->
                val cutoff = LocalDate.now().minusDays(90)
                val inv = invoices.filter { !it.isDeleted && it.dealerId == d.id && it.createdAt.toLocalDate() >= cutoff }
                val col = collections.filter { it.partyType == PartyType.DEALER && it.partyId == d.id && it.status == "VERIFIED" && it.createdAt.toLocalDate() >= cutoff }
                listOf(
                    BrowseKpi("Sales", "৳${"%,.0f".format(inv.sumOf { it.total })}"),
                    BrowseKpi("Collection", "৳${"%,.0f".format(col.sumOf { it.amount })}", SuccessGreen),
                    BrowseKpi("Due", "৳${"%,.0f".format(d.dueBalance)}", WarningAmber),
                    BrowseKpi("Invoices", "${inv.size}"),
                    BrowseKpi("Collections", "${col.size}"),
                    BrowseKpi("Stock Units", "${d.stockUnits}"),
                )
            },
            qrEntityType = "Dealer", // canonical registry type — same string activateQrFor uses at approval
            addRoute = "dms?key=newdealer",
            // v113-146 — real CSV import for dealers. Column names match what
            // `exportListAsCsv` writes plus the fields createDealer needs, so an
            // exported sheet edited in Excel round-trips. Each row goes through the
            // SAME createDealer the manual form uses, so permission/duplicate/
            // validation rules are identical and each failure reports its real reason.
            importCsv = { text ->
                val lines = text.lines().filter { it.isNotBlank() }
                if (lines.size < 2) {
                    CsvImport.ImportOutcome(0, 0, 0, emptyList(), "ফাইলে header ছাড়া কোনো row নেই।")
                } else {
                    val header = CsvImport.splitCsvLine(lines.first())
                    val (idx, missing) = CsvImport.headerIndex(header, listOf("Name", "Phone"))
                    if (missing != null) {
                        CsvImport.ImportOutcome(0, 0, 0, emptyList(), missing)
                    } else {
                        val results = mutableListOf<CsvImport.RowResult>()
                        lines.drop(1).forEachIndexed { i, raw ->
                            val cols = CsvImport.splitCsvLine(raw)
                            fun col(name: String): String = idx[name.lowercase()]?.let { cols.getOrNull(it) }.orEmpty()
                            val name = col("Name")
                            var reason: String? = null
                            val created = MockRepository.createDealer(
                                name = name, zone = col("Zone"), phone = col("Phone"), address = col("Address"),
                                onRejected = { r -> reason = r },
                            )
                            results.add(CsvImport.RowResult(i + 2, name.ifBlank { "(নামহীন)" }, created != null, reason))
                        }
                        CsvImport.ImportOutcome(results.size, results.count { it.ok }, results.count { !it.ok }, results)
                    }
                }
            },
            extraTabs = listOf("Transactions", "Status Control", "Merge/Transfer", "Stock", "Account", "Complaint", "Sales Report"),
            extraTabContent = { d, tabIdx, onNavigate ->
                when (tabIdx) {
                    1 -> PartyTransactionsTab(PartyType.DEALER, d.id, invoices.filter { !it.isDeleted && it.dealerId == d.id }.map {
                        Triple(it.invoiceNo, it.total, it.createdAt.toLocalDate().toString())
                    }, onNavigate)
                    2 -> DealerLifecycleControlTab(d)
                    3 -> DealerMergeTransferTab(d)
                    4 -> com.abm.erp.ui.dealer.DealerStockContent(d)
                    5 -> DealerAccountControlTab(d)
                    6 -> DealerComplaintTab(d)
                    else -> DealerSalesReportTab(d)
                }
            },
        )
    }
}

// v113-201 — Dealer lifecycle control tab: Pause / Suspend / Terminate /
// Reactivate, calling MockRepository.setDealerLifecycleStatus directly.
// Deliberately reached only through DMS's Chairman panel (DmsChairmanPanel
// is itself gated to isChairman at DmsHomeScreen level), so no extra
// role-check is duplicated here — the repository function also enforces
// Chairman-only server-side regardless of how this UI is reached.
@Composable
private fun DealerLifecycleControlTab(dealer: Dealer) {
    var reason by remember(dealer.id) { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }
    var result by remember(dealer.id) { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun apply(newStatus: String) {
        if (reason.isBlank()) { result = "কারণ লিখুন — audit-এ থেকে যাবে।"; return }
        working = true; result = null
        scope.launch {
            val ok = MockRepository.setDealerLifecycleStatus(dealer.id, newStatus, reason, onRejected = { r -> result = "✖ $r" })
            if (ok) { result = "✔ Status বদলে $newStatus হয়েছে।"; reason = "" }
            working = false
        }
    }

    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text("বর্তমান Status", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Text(dealer.status, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = reason, onValueChange = { reason = it },
            label = { Text("কারণ (আবশ্যক)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { apply("ACTIVE") }, enabled = !working && dealer.status != "ACTIVE") { Text("Activate") }
            Button(onClick = { apply("PAUSED") }, enabled = !working && dealer.status != "PAUSED") { Text("Pause") }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { apply("SUSPENDED") }, enabled = !working && dealer.status != "SUSPENDED", colors = ButtonDefaults.buttonColors(containerColor = WarningAmber)) { Text("Suspend") }
            Button(onClick = { apply("TERMINATED") }, enabled = !working && dealer.status != "TERMINATED", colors = ButtonDefaults.buttonColors(containerColor = com.abm.erp.theme.DangerRed)) { Text("Terminate") }
        }
        result?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = if (it.startsWith("✔")) SuccessGreen else com.abm.erp.theme.DangerRed, style = MaterialTheme.typography.labelSmall)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "Suspend/Terminate করলে dealer-এর নিজের login বন্ধ হয়ে যাবে এবং নতুন invoice করা যাবে না। Pause শুধু নতুন invoice বন্ধ করে, login চলবে। Terminate reversible — পরে আবার Activate করা যায়।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
    }
}

// v113-244 — the person's own direct follow-up: DealersScreen.kt's own
// legacy DealerDetailPanel (reached from its Directory tab, separate
// from search/scan which already correctly use ModuleBrowseDetail) was
// left alone at v113-236 specifically because two of its real
// capabilities — pending-application Approve/Reject, and Set/Reset Login
// PIN — had no equivalent anywhere in this Dealer config's own extraTabs
// yet. Built here, following the exact same pattern Retailer's own
// RetailerPinControlTab already established, so ModuleBrowseDetail
// genuinely has full parity with the legacy panel's two most
// consequential actions before anything gets redirected to it.
@Composable
private fun DealerAccountControlTab(dealer: Dealer) {
    var newPin by remember(dealer.id) { mutableStateOf("") }
    var pinError by remember(dealer.id) { mutableStateOf<String?>(null) }
    var pinSaved by remember(dealer.id) { mutableStateOf(false) }
    var showReject by remember(dealer.id) { mutableStateOf(false) }
    var approvalError by remember(dealer.id) { mutableStateOf<String?>(null) }
    val callContext = androidx.compose.ui.platform.LocalContext.current
    // v113-249 — the person's own direct request for Dealer List
    // richness: photoUri already existed and was already wired for
    // display, just nothing anywhere let anyone upload one.
    val photoScope = rememberCoroutineScope()
    var photoUploading by remember(dealer.id) { mutableStateOf(false) }
    val photoLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent(),
    ) { uri ->
        if (uri != null) {
            photoUploading = true
            photoScope.launch { MockRepository.uploadDealerPhoto(callContext, dealer.id, uri.toString()) { photoUploading = false } }
        }
    }

    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        if (!dealer.isActive) {
            Surface(color = com.abm.erp.theme.WarningAmber.copy(alpha = 0.12f), shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text("⏳ Application pending approval", fontWeight = FontWeight.Bold, color = com.abm.erp.theme.WarningAmber, style = MaterialTheme.typography.labelMedium)
                    approvalError?.let { Text(it, color = com.abm.erp.theme.DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                        Button(onClick = { MockRepository.approveDealer(dealer.id, onRejected = { e -> approvalError = e }) }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) { Text("Approve") }
                        OutlinedButton(onClick = { showReject = true }) { Text("Reject", color = com.abm.erp.theme.DangerRed) }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        }
        // v113-244 — the legacy panel's real Call/SMS/WhatsApp quick
        // actions, carried over so redirecting away from it doesn't lose
        // something people actually use day to day. Plain device Intents,
        // same as the original — no backend needed, each with its own
        // real failure path.
        if (dealer.phone.isNotBlank()) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                IconButton(onClick = {
                    try { callContext.startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:${dealer.phone}"))) }
                    catch (e: Exception) { android.widget.Toast.makeText(callContext, "Call করা যায়নি।", android.widget.Toast.LENGTH_SHORT).show() }
                }) { Icon(Icons.Filled.Call, contentDescription = "Call ${dealer.name}") }
                IconButton(onClick = {
                    try { callContext.startActivity(android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:${dealer.phone}"))) }
                    catch (e: Exception) { android.widget.Toast.makeText(callContext, "SMS app পাওয়া যায়নি।", android.widget.Toast.LENGTH_SHORT).show() }
                }) { Icon(Icons.Filled.MarkunreadMailbox, contentDescription = "SMS ${dealer.name}") }
                IconButton(onClick = {
                    try {
                        val digits = dealer.phone.filter { it.isDigit() }
                        val intl = if (digits.startsWith("880")) digits else "88" + digits.removePrefix("0").let { d -> if (d.startsWith("1")) "0$d" else d }
                        callContext.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://wa.me/$intl")))
                    } catch (e: Exception) { android.widget.Toast.makeText(callContext, "WhatsApp খোলা যায়নি।", android.widget.Toast.LENGTH_SHORT).show() }
                }) { Icon(Icons.Filled.Send, contentDescription = "WhatsApp ${dealer.name}") }
            }
            Spacer(Modifier.height(10.dp))
        }
        if (dealer.photoUri != null) {
            coil.compose.AsyncImage(
                model = dealer.photoUri, contentDescription = dealer.name,
                modifier = Modifier.fillMaxWidth().height(140.dp),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
            )
            Spacer(Modifier.height(6.dp))
        }
        OutlinedButton(onClick = { photoLauncher.launch("image/*") }, enabled = !photoUploading, modifier = Modifier.fillMaxWidth()) {
            Text(
                when {
                    photoUploading -> "আপলোড হচ্ছে…"
                    dealer.photoUri != null -> "📷 ছবি বদলান"
                    else -> "📷 Dealer-এর ছবি যোগ করুন"
                },
            )
        }
        Spacer(Modifier.height(14.dp))
        Text(
            if (dealer.pinHash != null) "একটা PIN আগে থেকেই সেট করা আছে — নতুন PIN দিলে সেটা বদলে যাবে।" else "এই dealer এখনো নিজের PIN দিয়ে login করতে পারবে না — একটা PIN সেট করুন।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = newPin, onValueChange = { newPin = it.filter(Char::isDigit).take(5); pinSaved = false },
            label = { Text("নতুন PIN (4-5 digit, একঘেয়ে/ক্রমিক না)") }, modifier = Modifier.fillMaxWidth(),
        )
        pinError?.let { Spacer(Modifier.height(4.dp)); Text(it, color = com.abm.erp.theme.DangerRed, style = MaterialTheme.typography.labelSmall) }
        if (pinSaved) { Spacer(Modifier.height(4.dp)); Text("✔ PIN সেট হয়েছে।", color = SuccessGreen, style = MaterialTheme.typography.labelSmall) }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                pinError = null
                if (!MockRepository.setDealerPin(dealer.id, newPin)) pinError = "খুব সহজ PIN — অন্যটা বেছে নিন।"
                else { pinSaved = true; newPin = "" }
            },
            enabled = newPin.length in 4..5,
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (dealer.pinHash != null) "Reset PIN" else "Set PIN") }
    }

    if (showReject) {
        var rejectReason by remember { mutableStateOf("") }
        var rejectError by remember { mutableStateOf<String?>(null) }
        androidx.compose.ui.window.Dialog(onDismissRequest = { showReject = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Reject Application — ${dealer.name}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = rejectReason, onValueChange = { rejectReason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
                    rejectError?.let { Spacer(Modifier.height(6.dp)); Text(it, color = com.abm.erp.theme.DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { val ok = MockRepository.rejectDealer(dealer.id, rejectReason, onRejected = { e -> rejectError = e }); if (ok) showReject = false },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm Reject") }
                }
            }
        }
    }
}

// v113-249 — the person's own direct request: a Dealer-specific complaint
// box within Dealer's own rich detail — "শুধুমাত্র ডিলাররাই দিবে" (only
// dealers will submit here). CustomerComplaint already correctly
// separates Dealer/Retailer complaints via partyType (confirmed directly
// against the model — dealerId/dealerName for one, retailerId/
// retailerName for the other, not a shared generic partyId), so this is
// a real filter on real, already-separated data, not a new distinction.
@Composable
private fun DealerComplaintTab(dealer: Dealer) {
    val allComplaints by MockRepository.customerComplaints.collectAsState()
    val complaints = remember(allComplaints, dealer.id) {
        allComplaints.filter { it.partyType == PartyType.DEALER && it.dealerId == dealer.id && !it.isDeleted }.sortedByDescending { it.createdAt }
    }
    var showNew by remember(dealer.id) { mutableStateOf(false) }
    var description by remember(dealer.id) { mutableStateOf("") }
    var category by remember(dealer.id) { mutableStateOf("OTHER") }
    var priority by remember(dealer.id) { mutableStateOf("NORMAL") }
    var submitError by remember(dealer.id) { mutableStateOf<String?>(null) }
    val complaintScope = rememberCoroutineScope()

    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text("Complaint (${complaints.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
            TextButton(onClick = { showNew = true }) { Text("+ নতুন") }
        }
        if (complaints.isEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text("এই dealer-এর কোনো complaint নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
        Spacer(Modifier.height(6.dp))
        complaints.forEach { c ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(c.complaintNo, fontWeight = FontWeight.SemiBold, color = TextPrimary, style = MaterialTheme.typography.labelMedium)
                    Text(
                        c.status.name,
                        color = when (c.status) {
                            com.abm.erp.data.CustomerComplaintStatus.RESOLVED, com.abm.erp.data.CustomerComplaintStatus.CLOSED -> SuccessGreen
                            com.abm.erp.data.CustomerComplaintStatus.REJECTED -> com.abm.erp.theme.DangerRed
                            else -> WarningAmber
                        },
                        style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold,
                    )
                }
                Text("${c.category} · ${c.priority}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text(c.description, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                c.resolutionNote?.ifBlank { null }?.let {
                    Spacer(Modifier.height(4.dp))
                    Text("সমাধান: $it", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                }
            }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                    Text("নতুন Complaint — ${dealer.name}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Category", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        listOf("QUALITY", "QUANTITY", "DELIVERY", "BILLING", "OTHER").forEach { cat ->
                            FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat, style = MaterialTheme.typography.labelSmall) })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Priority", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("LOW", "NORMAL", "HIGH", "URGENT").forEach { p ->
                            FilterChip(selected = priority == p, onClick = { priority = p }, label = { Text(p, style = MaterialTheme.typography.labelSmall) })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("বিবরণ") }, modifier = Modifier.fillMaxWidth())
                    submitError?.let { Spacer(Modifier.height(6.dp)); Text(it, color = com.abm.erp.theme.DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            complaintScope.launch {
                                val c = MockRepository.createCustomerComplaint(
                                    dealer.id, dealer.name, description.trim(), category, priority,
                                    onRejected = { r -> submitError = r },
                                )
                                if (c != null) { showNew = false; description = "" }
                            }
                        },
                        enabled = description.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("জমা দিন") }
                }
            }
        }
    }
}


// v113-227 — chairmanMergeDealers/chairmanTransferDealer were both fully
// real, Chairman-only functions with zero UI callers anywhere — found via
// the same proactive sweep as Retailer's own equivalent gap, fixed the
// same way, right after it (see this file's Retailer Actions tab for the
// fuller trace).
@Composable
private fun DealerMergeTransferTab(dealer: Dealer) {
    val scope = rememberCoroutineScope()
    val allDealers by MockRepository.dealers.collectAsState()
    val profiles by MockRepository.employeeProfiles.collectAsState()
    var showMerge by remember(dealer.id) { mutableStateOf(false) }
    var showTransfer by remember(dealer.id) { mutableStateOf(false) }
    var actionMsg by remember(dealer.id) { mutableStateOf<String?>(null) }
    var actionError by remember(dealer.id) { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        actionMsg?.let { Text(it, color = SuccessGreen, style = MaterialTheme.typography.labelSmall) }
        actionError?.let { Text(it, color = com.abm.erp.theme.DangerRed, style = MaterialTheme.typography.labelSmall) }
        TextButton(onClick = { showTransfer = true }) { Text("Zone/Territory/Employee Transfer") }
        TextButton(onClick = { showMerge = true }) { Text("Merge Duplicate Dealer", color = com.abm.erp.theme.DangerRed) }
    }

    if (showTransfer) {
        var newZone by remember { mutableStateOf(dealer.zone) }
        var newAssignedEmployeeId by remember { mutableStateOf<String?>(null) }
        androidx.compose.ui.window.Dialog(onDismissRequest = { showTransfer = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                    Text("Transfer — ${dealer.name}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newZone, onValueChange = { newZone = it }, label = { Text("Zone") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Text("নতুন দায়িত্বপ্রাপ্ত Employee (ঐচ্ছিক)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    profiles.filter { it.hasActiveAccess }.take(30).forEach { p ->
                        Text(
                            p.fullName, fontWeight = if (newAssignedEmployeeId == p.id) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { newAssignedEmployeeId = p.id },
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            scope.launch {
                                actionError = null
                                val ok = MockRepository.chairmanTransferDealer(dealer.id, newZone.trim().ifBlank { null }, dealer.territoryId, newAssignedEmployeeId)
                                if (ok) { actionMsg = "Transfer সংরক্ষিত হয়েছে।"; showTransfer = false } else actionError = "সংরক্ষণ করা যায়নি।"
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm Transfer") }
                }
            }
        }
    }
    if (showMerge) {
        var duplicateId by remember { mutableStateOf<String?>(null) }
        androidx.compose.ui.window.Dialog(onDismissRequest = { showMerge = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                    Text("Merge Duplicate Into — ${dealer.name}", style = MaterialTheme.typography.titleMedium)
                    Text("এই dealer-টাই থাকবে (survivor)। নিচে থেকে duplicate-টা বেছে দিন — সেটা মুছে যাবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(Modifier.height(8.dp))
                    allDealers.filter { !it.isDeleted && it.id != dealer.id }.forEach { dup ->
                        Text(
                            "${dup.name} (${dup.dealerCode})", fontWeight = if (duplicateId == dup.id) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { duplicateId = dup.id },
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val dupId = duplicateId
                            if (dupId != null) {
                                scope.launch {
                                    actionError = null
                                    val ok = MockRepository.chairmanMergeDealers(dealer.id, dupId)
                                    if (ok) { actionMsg = "Merge সম্পন্ন হয়েছে।"; showMerge = false } else actionError = "সংরক্ষণ করা যায়নি।"
                                }
                            }
                        },
                        enabled = duplicateId != null, modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = com.abm.erp.theme.DangerRed),
                    ) { Text("Confirm Merge") }
                }
            }
        }
    }
}

// ── RMS · Retailer ─────────────────────────────────────────────────────────────

@Composable
fun rememberRetailerBrowseConfig(markets: List<String>): BrowseConfig<Retailer> {
    val orders by MockRepository.orders.collectAsState()
    val collections by MockRepository.partyCollections.collectAsState()
    return remember(markets, orders, collections) {
        BrowseConfig(
            moduleName = "RMS", entityLabel = "Retailer",
            colorStart = 0xFF0EA5A4, colorEnd = 0xFF0F766E,
            idOf = { it.id },
            titleOf = { it.name },
            codeOf = { it.retailerCode.ifBlank { it.id.take(8).uppercase() } },
            subtitleOf = { "${it.phone.ifBlank { "ফোন নেই" }} · ${it.market.ifBlank { "market নেই" }}" },
            categoryOf = { "${classLabel(it.classification)} Retailer" },
            isActiveOf = { it.isActive },
            photoUriOf = { it.photoUri },
            searchMatches = { r, q -> r.name.contains(q, true) || r.retailerCode.contains(q, true) || r.phone.contains(q, true) || r.market.contains(q, true) },
            facets = listOf(
                BrowseFacet("Market", markets) { r, o -> r.market == o },
                BrowseFacet("Category", listOf("A", "B", "C")) { r, o -> r.classification == o },
                BrowseFacet("Status", listOf("Active", "Inactive")) { r, o -> (o == "Active") == r.isActive },
            ),
            infoRows = { r ->
                listOf(
                    BrowseInfoRow("Retailer Code", r.retailerCode.ifBlank { r.id.take(8).uppercase() }),
                    BrowseInfoRow("Retailer Name", r.name),
                    BrowseInfoRow("Owner Name", r.ownerName.ifBlank { "—" }),
                    BrowseInfoRow("Phone", r.phone.ifBlank { "—" }),
                    BrowseInfoRow("Market / Route", r.market.ifBlank { "—" }),
                    BrowseInfoRow("Address", r.address.ifBlank { "—" }),
                    BrowseInfoRow("Category", "${classLabel(r.classification)} Retailer"),
                    BrowseInfoRow("Status", if (r.isActive) "Active" else "Inactive"),
                    BrowseInfoRow("Join Date", r.createdAt.toLocalDate().toString()),
                    BrowseInfoRow("Credit Limit", if (r.creditLimit > 0) "৳${"%,.0f".format(r.creditLimit)}" else "নির্ধারিত নেই"),
                )
            },
            kpis = { r ->
                val myOrders = orders.filter { it.retailerId == r.id || (it.retailerId == null && it.retailerName == r.name) }
                val col = collections.filter { it.partyType == PartyType.RETAILER && it.partyId == r.id && it.status == "VERIFIED" }
                listOf(
                    BrowseKpi("Memo Total", "৳${"%,.0f".format(myOrders.sumOf { it.amount })}"),
                    BrowseKpi("Collection", "৳${"%,.0f".format(col.sumOf { it.amount })}", SuccessGreen),
                    BrowseKpi("Total Due", "৳${"%,.0f".format(r.dueBalance)}", if (r.dueBalance > 0) WarningAmber else SuccessGreen),
                )
            },
            hasLedger = true,
            activities = { r -> rememberPartyActivities(PartyType.RETAILER, r.id) },
            hasGraph = true,
            slices = { r ->
                orders.filter { it.retailerId == r.id || (it.retailerId == null && it.retailerName == r.name) }
                    .flatMap { it.lineItems }.groupBy { it.name }
                    .map { (n, l) -> BrowseSlice(n, l.sumOf { it.lineTotal }) }
            },
            has90Day = true,
            summary90 = { r ->
                val cutoff = LocalDate.now().minusDays(90)
                val myOrders = orders.filter { (it.retailerId == r.id || (it.retailerId == null && it.retailerName == r.name)) && it.loggedAt.toLocalDate() >= cutoff }
                val col = collections.filter { it.partyType == PartyType.RETAILER && it.partyId == r.id && it.status == "VERIFIED" && it.createdAt.toLocalDate() >= cutoff }
                listOf(
                    BrowseKpi("Memo Amount", "৳${"%,.0f".format(myOrders.sumOf { it.amount })}"),
                    BrowseKpi("Collection", "৳${"%,.0f".format(col.sumOf { it.amount })}", SuccessGreen),
                    BrowseKpi("Due", "৳${"%,.0f".format(r.dueBalance)}", WarningAmber),
                    BrowseKpi("Memos", "${myOrders.size}"),
                    BrowseKpi("Collections", "${col.size}"),
                )
            },
            qrEntityType = "Retailer",
            addRoute = "rms?key=add",
            extraTabs = listOf("Transactions", "Login PIN", "Actions"),
            extraTabContent = { r, tabIdx, onNavigate ->
                when (tabIdx) {
                    1 -> PartyTransactionsTab(PartyType.RETAILER, r.id, orders
                        .filter { it.retailerId == r.id || (it.retailerId == null && it.retailerName == r.name) }
                        .map { Triple(it.orderNo, it.amount, it.loggedAt.toLocalDate().toString()) }, onNavigate)
                    2 -> RetailerPinControlTab(r)
                    else -> RetailerActionsTab(r)
                }
            },
        )
    }
}

// v113-227 — mergeRetailers/overrideRetailerCreditCheck/transferRetailerRoute
// were all fully real, working, Chairman/authorized-role-gated functions
// with zero UI callers anywhere — found via the same proactive sweep that
// caught the check-out and vacancy-fill gaps. Same extraTab mechanism
// Dealer's own admin actions already use (verified the real tabIdx
// semantics — offset by 1 relative to extraTabs, since tab 0 is always
// the built-in Info panel — directly against ModuleBrowseFlow.kt before
// adding a third tab here, rather than assume from the existing two).
@Composable
private fun RetailerActionsTab(retailer: Retailer) {
    val scope = rememberCoroutineScope()
    val allRetailers by MockRepository.retailers.collectAsState()
    val routes by MockRepository.salesRoutes.collectAsState()
    var showMerge by remember(retailer.id) { mutableStateOf(false) }
    var showCreditOverride by remember(retailer.id) { mutableStateOf(false) }
    var showRouteTransfer by remember(retailer.id) { mutableStateOf(false) }
    var actionMsg by remember(retailer.id) { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        actionMsg?.let { Text(it, color = SuccessGreen, style = MaterialTheme.typography.labelSmall) }
        TextButton(onClick = { showCreditOverride = true }) { Text("Credit Check Override") }
        TextButton(onClick = { showRouteTransfer = true }) { Text("Route Transfer") }
        TextButton(onClick = { showMerge = true }) { Text("Merge Duplicate Retailer", color = com.abm.erp.theme.DangerRed) }
    }

    if (showCreditOverride) {
        var reason by remember { mutableStateOf("") }
        androidx.compose.ui.window.Dialog(onDismissRequest = { showCreditOverride = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Credit Check Override — ${retailer.name}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val ok = MockRepository.overrideRetailerCreditCheck(retailer.id, reason.trim())
                            if (ok) { actionMsg = "Override সংরক্ষিত হয়েছে।"; showCreditOverride = false }
                        },
                        enabled = reason.isNotBlank(), modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm Override") }
                }
            }
        }
    }
    if (showRouteTransfer) {
        var selectedRouteId by remember { mutableStateOf<String?>(null) }
        var reason by remember { mutableStateOf("") }
        androidx.compose.ui.window.Dialog(onDismissRequest = { showRouteTransfer = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    Text("Route Transfer — ${retailer.name}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    routes.filter { it.isActive }.forEach { rt ->
                        Text(
                            rt.name, fontWeight = if (selectedRouteId == rt.id) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { selectedRouteId = rt.id },
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val rid = selectedRouteId
                            if (rid != null) {
                                val ok = MockRepository.transferRetailerRoute(retailer.id, rid, reason.trim())
                                if (ok) { actionMsg = "Route transfer সংরক্ষিত হয়েছে।"; showRouteTransfer = false }
                            }
                        },
                        enabled = selectedRouteId != null && reason.isNotBlank(), modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm Transfer") }
                }
            }
        }
    }
    if (showMerge) {
        var duplicateId by remember { mutableStateOf<String?>(null) }
        var reason by remember { mutableStateOf("") }
        androidx.compose.ui.window.Dialog(onDismissRequest = { showMerge = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                    Text("Merge Duplicate Into — ${retailer.name}", style = MaterialTheme.typography.titleMedium)
                    Text("এই retailer-টাই থাকবে (survivor)। নিচে থেকে duplicate-টা বেছে দিন — সেটা মুছে যাবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(Modifier.height(8.dp))
                    allRetailers.filter { !it.isDeleted && it.id != retailer.id }.forEach { dup ->
                        Text(
                            "${dup.name} (${dup.retailerCode})", fontWeight = if (duplicateId == dup.id) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { duplicateId = dup.id },
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val dupId = duplicateId
                            if (dupId != null) {
                                val ok = MockRepository.mergeRetailers(retailer.id, dupId, reason.trim())
                                if (ok) { actionMsg = "Merge সম্পন্ন হয়েছে।"; showMerge = false }
                            }
                        },
                        enabled = duplicateId != null && reason.isNotBlank(), modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = com.abm.erp.theme.DangerRed),
                    ) { Text("Confirm Merge") }
                }
            }
        }
    }
}

// v113-203 — Retailer's own self-service-login PIN control, same shape as
// Dealer's Set/Reset PIN action in DealersScreen.kt (mirrors setDealerPin's
// UI exactly), just reached through the generic browse-detail extraTab
// mechanism instead of a bespoke screen, since Retailer has no equivalent
// of DealersScreen.kt — it's managed entirely through this shared flow.
@Composable
private fun RetailerPinControlTab(retailer: Retailer) {
    var newPin by remember(retailer.id) { mutableStateOf("") }
    var pinError by remember(retailer.id) { mutableStateOf<String?>(null) }
    var saved by remember(retailer.id) { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text(
            if (retailer.pinHash != null) "একটা PIN আগে থেকেই সেট করা আছে — নতুন PIN দিলে সেটা বদলে যাবে।" else "এই retailer এখনো নিজের PIN দিয়ে login করতে পারবে না — একটা PIN সেট করুন।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = newPin, onValueChange = { newPin = it.filter(Char::isDigit).take(5); saved = false },
            label = { Text("নতুন PIN (4-5 digit, একঘেয়ে/ক্রমিক না)") }, modifier = Modifier.fillMaxWidth(),
        )
        pinError?.let { Spacer(Modifier.height(4.dp)); Text(it, color = com.abm.erp.theme.DangerRed, style = MaterialTheme.typography.labelSmall) }
        if (saved) { Spacer(Modifier.height(4.dp)); Text("✔ PIN সেট হয়েছে।", color = SuccessGreen, style = MaterialTheme.typography.labelSmall) }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                pinError = null
                if (!MockRepository.setRetailerPin(retailer.id, newPin)) pinError = "খুব সহজ PIN — অন্যটা বেছে নিন।"
                else { saved = true; newPin = "" }
            },
            enabled = newPin.length in 4..5,
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (retailer.pinHash != null) "Reset PIN" else "Set PIN") }
    }
}

// ── HR · Employee ──────────────────────────────────────────────────────────────

@Composable
fun rememberEmployeeBrowseConfig(departments: List<String>): BrowseConfig<EmployeeProfile> =
    remember(departments) {
        BrowseConfig(
            moduleName = "HR", entityLabel = "Employee",
            auditEntityType = "EmployeeProfile",
            colorStart = 0xFFDB2777, colorEnd = 0xFF9D174D,
            idOf = { it.id },
            titleOf = { it.fullName },
            codeOf = { it.employeeCode.ifBlank { it.id.take(8).uppercase() } },
            subtitleOf = { "${it.designation.ifBlank { it.role.name }} · ${it.department.ifBlank { "বিভাগ নেই" }}" },
            categoryOf = { it.role.name },
            isActiveOf = { it.hasActiveAccess },
            photoUriOf = { it.profilePhotoUri },
            searchMatches = { e, q -> e.fullName.contains(q, true) || e.employeeCode.contains(q, true) || e.mobile.contains(q, true) || e.designation.contains(q, true) },
            facets = listOf(
                BrowseFacet("Department", departments) { e, o -> e.department == o },
                BrowseFacet("Status", listOf("Active", "Inactive")) { e, o -> (o == "Active") == e.hasActiveAccess },
            ),
            infoRows = { e ->
                listOf(
                    BrowseInfoRow("Employee ID", e.employeeCode.ifBlank { e.id.take(8).uppercase() }),
                    BrowseInfoRow("Full Name", e.fullName),
                    BrowseInfoRow("Designation", e.designation.ifBlank { "—" }),
                    BrowseInfoRow("Role (permission)", e.role.name),
                    BrowseInfoRow("Department", e.department.ifBlank { "—" }),
                    BrowseInfoRow("Mobile", e.mobile.ifBlank { "—" }),
                    BrowseInfoRow("Employment Status", e.status.name),
                    BrowseInfoRow("Access", if (e.hasActiveAccess) "Active" else "No active access"),
                    BrowseInfoRow("Joined", e.createdAt.toLocalDate().toString()),
                )
            },
            // No ledger/graph/90-day: employees are not money-bearing parties in this
            // codebase, so those drill-downs genuinely have no data behind them.
            // First registry type introduced from the card itself: employees were never
            // auto-issued at approval (unlike Dealer/Retailer), so the card's "Issue"
            // button is the entry point. resolve() is type-agnostic, so scans validate.
            qrEntityType = "Employee",
            addRoute = "hr_module?key=add",
            // v113-219 — the person's own direct request: Employee's detail
            // view should carry everything, exactly like Dealer's own
            // "Status Control"/"Transactions" extraTabs. The full management
            // console (onboarding actions, area assignment, appraisal,
            // login-account/PIN control, emergency override, role/status
            // change, manager/approval-limits/transfer/delegate) already
            // existed and worked — it lived in a separate "Employee
            // Management" tab, mechanically extracted (not rewritten) to
            // `EmployeeManagementPanel` in PayrollScreen.kt and called
            // directly here, so it's the exact same, already-tested
            // behaviour, just reachable from the one comprehensive place
            // now instead of a separate tab.
            extraTabs = listOf("Manage", "Salary"),
            extraTabContent = { emp, tabIdx, _ ->
                if (tabIdx == 1) com.abm.erp.ui.hrm.EmployeeManagementPanel(emp) else com.abm.erp.ui.hrm.EmployeeSalaryTab(emp)
            },
        )
    }


// ── FMS · Product / Stock ──────────────────────────────────────────────────────

/**
 * v113-86 — FMS's "list" is a PRODUCT list, not a party list. The record shape is
 * honestly different: no phone/owner/due, but sku/unit/price and per-warehouse stock.
 * The engine's capability flags carry that honestly — no Ledger and no 90-Day (a
 * product has no party ledger or due), but the Graph drill-down IS enabled and shows
 * the real per-warehouse stock split for that product, which is the product-shaped
 * equivalent of the dealer's product split.
 */
@Composable
fun rememberProductBrowseConfig(categories: List<String>): BrowseConfig<Product> {
    val stockLevels by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
    return remember(categories, stockLevels) {
        BrowseConfig(
            moduleName = "FMS", entityLabel = "Product",
            colorStart = 0xFFE85D4A, colorEnd = 0xFFC03A2B,
            idOf = { it.id },
            titleOf = { it.name },
            codeOf = { it.sku.ifBlank { it.id.take(8).uppercase() } },
            subtitleOf = { p ->
                val onHand = stockLevels.filter { it.productId == p.id }.sumOf { it.quantityOnHand }
                "${p.category.ifBlank { "category নেই" }} · Stock: ${"%,.0f".format(onHand)} ${p.unit}"
            },
            categoryOf = { it.category.ifBlank { "Uncategorised" } },
            isActiveOf = { it.isActive && !it.isDeleted },
            searchMatches = { pr, q -> pr.name.contains(q, true) || pr.sku.contains(q, true) || pr.category.contains(q, true) },
            facets = listOf(
                BrowseFacet("Category", categories) { pr, o -> pr.category == o },
                BrowseFacet("Status", listOf("Active", "Inactive")) { pr, o -> (o == "Active") == (pr.isActive && !pr.isDeleted) },
            ),
            infoRows = { pr ->
                val levels = stockLevels.filter { it.productId == pr.id }
                val onHand = levels.sumOf { it.quantityOnHand }
                listOf(
                    BrowseInfoRow("SKU", pr.sku.ifBlank { "—" }),
                    BrowseInfoRow("Product Name", pr.name),
                    BrowseInfoRow("Category", pr.category.ifBlank { "—" }),
                    BrowseInfoRow("Unit", pr.unit),
                    BrowseInfoRow("Sale Price", "৳${"%,.2f".format(pr.defaultUnitPrice)}"),
                    BrowseInfoRow("Cost Price", if (pr.costPrice > 0) "৳${"%,.2f".format(pr.costPrice)}" else "সেট করা নেই"),
                    BrowseInfoRow("On Hand (all warehouses)", "${"%,.0f".format(onHand)} ${pr.unit}"),
                    BrowseInfoRow("Reorder Threshold", "${"%,.0f".format(pr.reorderThreshold)} ${pr.unit}"),
                    BrowseInfoRow("Status", if (pr.isActive && !pr.isDeleted) "Active" else "Inactive"),
                    BrowseInfoRow("Created", pr.createdAt.toLocalDate().toString()),
                )
            },
            kpis = { pr ->
                val levels = stockLevels.filter { it.productId == pr.id }
                val onHand = levels.sumOf { it.quantityOnHand }
                listOf(
                    BrowseKpi("On Hand", "${"%,.0f".format(onHand)} ${pr.unit}"),
                    BrowseKpi("Stock Value", "৳${"%,.0f".format(onHand * pr.defaultUnitPrice)}"),
                    BrowseKpi("Warehouses", "${levels.count { it.quantityOnHand > 0 }}"),
                )
            },
            // Graph = per-warehouse stock split (the product-shaped "where is it" view).
            hasGraph = true,
            slices = { pr ->
                stockLevels.filter { it.productId == pr.id && it.quantityOnHand > 0 }
                    .map { BrowseSlice(it.warehouseName, it.quantityOnHand * pr.defaultUnitPrice) }
            },
            // No hasLedger / has90Day: a product has no party ledger and no due — the
            // engine simply won't render those buttons.
            graphTitle = "Warehouse Wise Stock", // default title says "Sales" — this graph is a stock split, not sales
            qrEntityType = "Product",
        )
    }
}

// ── shared helpers used by the configs ─────────────────────────────────────────

/** Real party ledger → browse activities. One place, both DMS and RMS. */
@Composable
private fun rememberPartyActivities(partyType: PartyType, partyId: String): List<BrowseActivity> {
    val entries by remember(partyType, partyId) { MockRepository.partyLedgerFor(partyType, partyId) }
        .collectAsState(initial = emptyList())
    return remember(entries) {
        entries.map { e ->
            BrowseActivity(
                date = e.createdAt.toLocalDate(),
                title = e.reason,
                kind = if (e.type == "DEBIT") "Invoice/Memo" else "Collection/Return",
                amount = e.amount,
                isDebit = e.type == "DEBIT",
                balanceAfter = e.balanceAfter,
            )
        }
    }
}

@Composable
private fun PartyTransactionsTab(
    partyType: PartyType,
    partyId: String,
    docs: List<Triple<String, Double, String>>,
    onNavigate: (String) -> Unit,
) {
    val collections by MockRepository.partyCollections.collectAsState()
    val myCollections = remember(collections, partyId) {
        collections.filter { it.partyType == partyType && it.partyId == partyId }.sortedByDescending { it.createdAt }
    }
    Column(Modifier.fillMaxWidth()) {
        Text("Transactions", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(8.dp))
        if (docs.isEmpty() && myCollections.isEmpty()) Text("কোনো লেনদেন নেই।", color = TextSecondary)
        docs.take(15).forEach { (no, amount, date) ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(no, fontWeight = FontWeight.SemiBold, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                        Text(date, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Text("৳${"%,.0f".format(amount)}", fontWeight = FontWeight.Bold, color = TextPrimary)
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        myCollections.take(15).forEach { c ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(c.collectionNo.ifBlank { c.id.take(8) }, fontWeight = FontWeight.SemiBold, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                        Text("Collection · ${c.method} · ${c.createdAt.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Text("৳${"%,.0f".format(c.amount)}", fontWeight = FontWeight.Bold, color = SuccessGreen)
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

// v113-249 — the person's own direct request: a Dealer Sales Report,
// same shape as the one already built for Territory/Area Overview
// (Today/7/30/90-day + Custom date range, product-wise breakdown) —
// reused directly rather than a third variant of the same idea, just
// scoped to this one dealer's own invoices instead of a whole area's.
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun DealerSalesReportTab(dealer: Dealer) {
    val allInvoices by MockRepository.salesInvoices.collectAsState()
    val dealerInvoicesAllTime = remember(allInvoices, dealer.id) {
        allInvoices.filter { !it.isDeleted && it.dealerId == dealer.id }
    }

    var rangeMode by remember { mutableStateOf(1) } // 0=Today 1=7 Days 2=30 Days 3=90 Days 4=Custom
    var customFrom by remember { mutableStateOf<java.time.LocalDate?>(null) }
    var customTo by remember { mutableStateOf<java.time.LocalDate?>(null) }
    var pickerFor by remember { mutableStateOf<String?>(null) }

    val today = java.time.LocalDate.now()
    val (fromDate, toDate) = when (rangeMode) {
        0 -> today to today
        1 -> today.minusDays(6) to today
        2 -> today.minusDays(29) to today
        3 -> today.minusDays(89) to today
        else -> (customFrom ?: today.minusDays(6)) to (customTo ?: today)
    }

    val rangeInvoices = remember(dealerInvoicesAllTime, fromDate, toDate) {
        dealerInvoicesAllTime.filter { val d = it.createdAt.toLocalDate(); !d.isBefore(fromDate) && !d.isAfter(toDate) }
    }
    val rangeTotal = rangeInvoices.sumOf { it.total }

    data class ProductRow(val name: String, val qty: Int, val value: Double)
    val productSales = remember(rangeInvoices) {
        rangeInvoices.flatMap { it.lineItems }
            .groupBy { it.name }
            .map { (name, lines) -> ProductRow(name, lines.sumOf { it.qty }, lines.sumOf { it.lineTotal }) }
            .sortedByDescending { it.value }.take(10)
    }
    val productMax = productSales.maxOfOrNull { it.value } ?: 0.0

    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Today", "7 Days", "30 Days", "90 Days", "Custom").forEachIndexed { i, label ->
                FilterChip(
                    selected = rangeMode == i,
                    onClick = { rangeMode = i; if (i == 4 && customFrom == null) pickerFor = "from" },
                    label = { Text(label, fontSize = 11.sp) },
                )
            }
        }
        if (rangeMode == 4) {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.weight(1f)) {
                    com.abm.erp.core.SecondaryButton("From: ${customFrom ?: "—"}", onClick = { pickerFor = "from" }, icon = Icons.Filled.CalendarMonth)
                }
                Box(Modifier.weight(1f)) {
                    com.abm.erp.core.SecondaryButton("To: ${customTo ?: "—"}", onClick = { pickerFor = "to" }, icon = Icons.Filled.CalendarMonth)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("মোট বিক্রি (${rangeInvoices.size} invoice)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text("৳${"%,.0f".format(rangeTotal)}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = com.abm.erp.theme.DarazOrange)
        }
        Spacer(Modifier.height(12.dp))
        Text("Product-wise", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        if (productSales.isEmpty()) {
            Text("এই সময়ে কোনো বিক্রি নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        } else {
            productSales.forEach { p ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(p.name, fontSize = 12.sp, color = TextPrimary, maxLines = 1, modifier = Modifier.weight(1f))
                        Text("${p.qty} · ৳${"%,.0f".format(p.value)}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    }
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.fillMaxWidth().height(5.dp).background(HairlineBorder, androidx.compose.foundation.shape.RoundedCornerShape(999.dp))) {
                        Box(
                            Modifier.fillMaxWidth(if (productMax > 0) (p.value / productMax).toFloat().coerceIn(0f, 1f) else 0f)
                                .fillMaxHeight().background(com.abm.erp.theme.DarazOrange, androidx.compose.foundation.shape.RoundedCornerShape(999.dp)),
                        )
                    }
                }
            }
        }
    }

    if (pickerFor != null) {
        val state = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { pickerFor = null },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { ms ->
                        val picked = java.time.Instant.ofEpochMilli(ms).atZone(java.time.ZoneOffset.UTC).toLocalDate()
                        if (pickerFor == "from") customFrom = picked else customTo = picked
                        rangeMode = 4
                    }
                    pickerFor = null
                }) { Text("ঠিক আছে") }
            },
            dismissButton = { TextButton(onClick = { pickerFor = null }) { Text("বাতিল") } },
        ) { DatePicker(state = state) }
    }
}
