package com.abm.erp.ui.purchase

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.BackToSubMenuLink
import com.abm.erp.core.GlassCard
import com.abm.erp.core.ModuleGradientHeader
import com.abm.erp.core.SubModuleGrid
import com.abm.erp.core.SubModuleItem
import com.abm.erp.data.*
import com.abm.erp.theme.*

/**
 * Module 5 — Purchase Management. PurchaseRepository (data layer) already
 * existed with full Supplier/PO/GRN/Return/Payment logic and its own
 * permission-gated + audit-logged functions; this file is the missing UI.
 */
class PurchaseViewModel : ViewModel() {
    val suppliers = PurchaseRepository.suppliers
    val purchaseOrders = PurchaseRepository.purchaseOrders
    val goodsReceivedNotes = PurchaseRepository.goodsReceivedNotes
    val purchaseReturns = PurchaseRepository.purchaseReturns
    val warehouses = InventoryRepository.warehouses
    val currentUser get() = MockRepository.currentUser

    fun createSupplier(name: String, phone: String, address: String, creditLimit: Double, onRejected: (String) -> Unit = {}) =
        PurchaseRepository.createSupplier(name, phone, address, creditLimit, onRejected = onRejected)
    fun deleteSupplier(id: String, onRejected: (String) -> Unit = {}) = PurchaseRepository.deleteSupplier(id, onRejected)
    fun duplicateSupplier(id: String, onRejected: (String) -> Unit = {}) = PurchaseRepository.duplicateSupplier(id, onRejected)
    suspend fun restoreSupplier(id: String) = PurchaseRepository.restoreSupplier(id)
    suspend fun duplicatePurchaseOrder(id: String, onRejected: (String) -> Unit = {}) = PurchaseRepository.duplicatePurchaseOrder(id, onRejected)

    suspend fun createPurchaseOrder(supplierId: String, supplierName: String, lineItems: List<PurchaseLineItem>, onRejected: (String) -> Unit = {}) =
        PurchaseRepository.createPurchaseOrder(supplierId, supplierName, lineItems, onRejected)
    fun updatePurchaseOrderStatus(id: String, status: String) = PurchaseRepository.updatePurchaseOrderStatus(id, status)

    fun receiveGoods(poId: String, supplierId: String, supplierName: String, items: List<PurchaseLineItem>, warehouseId: String, onRejected: (String) -> Unit = {}) =
        PurchaseRepository.receiveGoods(poId, supplierId, supplierName, items, warehouseId, onRejected)

    suspend fun createPurchaseReturn(poId: String?, supplierId: String, supplierName: String, items: List<PurchaseLineItem>, reason: String, onRejected: (String) -> Unit = {}) =
        PurchaseRepository.createPurchaseReturn(poId, supplierId, supplierName, items, reason, onRejected)
    fun approvePurchaseReturn(id: String, onRejected: (String) -> Unit = {}) = PurchaseRepository.approvePurchaseReturn(id, onRejected)
    fun rejectPurchaseReturn(id: String) = PurchaseRepository.rejectPurchaseReturn(id)

    fun createSupplierPayment(supplierId: String, amount: Double, method: String) =
        PurchaseRepository.createSupplierPayment(supplierId, amount, method)

    fun canCreate() = PermissionManager.canCurrentUser("stock", PermissionAction.CREATE)
    fun canApprove() = PermissionManager.canCurrentUser("stock", PermissionAction.APPROVE)
    fun canDelete() = PermissionManager.canCurrentUser("stock", PermissionAction.DELETE)
}

@Composable
fun PurchaseScreen(startTab: Int? = null, onBack: () -> Unit = {}, vm: PurchaseViewModel = viewModel()) {
    var tab by remember { mutableStateOf<Int?>(startTab) }
    val subItems = listOf(
        SubModuleItem("suppliers", "Suppliers", "🏢", 0xFF8A6DFF, 0xFF5B3FE0, Icons.Filled.Business),
        SubModuleItem("request", "Purchase Requests", "📋", 0xFF6EC6FF, 0xFF2E8FE0, Icons.Filled.Assignment),
        SubModuleItem("po", "Purchase Orders", "📝", 0xFF4E9CFF, 0xFF2E6FE0, Icons.Filled.EditNote),
        SubModuleItem("grn", "GRN (Receive Goods)", "📥", 0xFF3DDC97, 0xFF1FA972, Icons.Filled.MoveToInbox),
        SubModuleItem("return", "Purchase Return", "↩️", 0xFFE85D4A, 0xFFC03A2B, Icons.Filled.AssignmentReturn),
        SubModuleItem("payment", "Supplier Payment", "💳", 0xFFFFB020, 0xFFE08A00, Icons.Filled.CreditCard),
    )
    val suppliersForMini by com.abm.erp.data.PurchaseRepository.suppliers.collectAsState()
    val poForMini by com.abm.erp.data.PurchaseRepository.purchaseOrders.collectAsState()
    val prForMini by com.abm.erp.data.PurchaseRepository.purchaseRequests.collectAsState()
    val pendingRequests = prForMini.count { it.status == "PENDING" }
    val openPos = poForMini.count { it.status == "SENT" || it.status == "PARTIALLY_RECEIVED" }
    val receivedPos = poForMini.count { it.status == "RECEIVED" }
    Column(Modifier.fillMaxSize()) {
        if (startTab == null) {
        com.abm.erp.core.ModuleWorkspaceHeader("Purchase Management", "🛍️", 0xFF8A6DFF, 0xFF5B3FE0, iconVector = Icons.Filled.ShoppingCart, miniDashboard = {
            com.abm.erp.core.ModuleStat("Suppliers", "${suppliersForMini.size}", TextPrimary)
            com.abm.erp.core.ModuleStat("Pending Requests", "$pendingRequests", if (pendingRequests > 0) WarningAmber else SuccessGreen) { tab = 1 }
            com.abm.erp.core.ModuleStat("Open POs", "$openPos", if (openPos > 0) WarningAmber else SuccessGreen) { tab = 2 }
            com.abm.erp.core.ModuleStat("Received", "$receivedPos", SuccessGreen)
        }, quickActions = {
            AssistChip(onClick = { tab = 1 }, label = { Text("+ Request") })
            AssistChip(onClick = { tab = 2 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.EditNote, null, Modifier.size(16.dp)) }, label = { Text("New PO") })
            AssistChip(onClick = { tab = 3 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.MoveToInbox, null, Modifier.size(16.dp)) }, label = { Text("Receive") })
            AssistChip(onClick = { tab = 5 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.CreditCard, null, Modifier.size(16.dp)) }, label = { Text("Payment") })
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("PurchaseOrder", "PurchaseRequest", "Supplier", "GRN"))
        })
        } else {
            val taskKey = when (tab) { 0 -> "suppliers"; 1 -> "po"; 2 -> "grn"; 3 -> "return"; 5 -> "request"; else -> "payment" }
            val taskTitle = subItems.firstOrNull { it.key == taskKey }?.label ?: "Purchase"
            com.abm.erp.core.TaskHeader(taskTitle, 0xFF8A6DFF, 0xFF5B3FE0, onBack = onBack, iconVector = Icons.Filled.ShoppingCart)
        }
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            if (tab == null) {
                SubModuleGrid(subItems) { key -> tab = when (key) { "suppliers" -> 0; "request" -> 5; "po" -> 1; "grn" -> 2; "return" -> 3; else -> 4 } }
            } else {
                if (startTab == null) BackToSubMenuLink(onClick = { tab = null })
                when (tab) {
                    0 -> SuppliersTab(vm)
                    1 -> PurchaseOrdersTab(vm)
                    2 -> GrnTab(vm)
                    3 -> PurchaseReturnTab(vm)
                    5 -> PurchaseRequestsTab(vm)
                    else -> SupplierPaymentTab(vm)
                }
            }
        }
    }
}

@Composable
private fun SuppliersTab(vm: PurchaseViewModel) {
    val suppliers by vm.suppliers.collectAsState()
    val allOrders by vm.purchaseOrders.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var showScorecard by remember { mutableStateOf(false) }
    val supplierScope = rememberCoroutineScope()
    val scorecards = remember(suppliers, allOrders) {
        suppliers.map { s ->
            val orders = allOrders.filter { it.supplierId == s.id }
            val received = orders.count { it.status == "RECEIVED" }
            val cancelled = orders.count { it.status == "CANCELLED" }
            val pending = orders.count { it.status != "RECEIVED" && it.status != "CANCELLED" }
            val totalValue = orders.filter { it.status != "CANCELLED" }.sumOf { it.subTotal }
            s.name to Triple(received, cancelled, Pair(pending, totalValue))
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "Name,Due,CreditLimit\n"
                    val rows = suppliers.joinToString("\n") { s -> com.abm.erp.core.toCsvRow(s.name, s.dueBalance, s.creditLimit) }
                    val file = java.io.File(context.getExternalFilesDir(null), "suppliers_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Suppliers (${suppliers.size})\n" + suppliers.take(20).joinToString("\n") { "${it.name} — Due ৳${it.dueBalance}" }
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                    try { context.startActivity(android.content.Intent.createChooser(intent, "Suppliers")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                },
            )
        }
        TextButton(onClick = { showScorecard = !showScorecard }, modifier = Modifier.fillMaxWidth()) { Text(if (showScorecard) "▲ Hide Supplier Scorecard" else "▼ Supplier Scorecard") }
        if (showScorecard) {
            GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                Text("Supplier Scorecard", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                if (scorecards.isEmpty()) {
                    Text("এখনো কোনো সরবরাহকারী নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                } else {
                    scorecards.forEach { (name, data) ->
                        val (received, cancelled, pendingValue) = data
                        Column(Modifier.padding(vertical = 4.dp)) {
                            Text(name, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                            Text("Received: $received · Cancelled: $cancelled · Pending: ${pendingValue.first} · Value: ৳${"%,.0f".format(pendingValue.second)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                }
            }
        }
        if (vm.canCreate()) {
            Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add Supplier") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(suppliers, key = { it.id }) { s ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(s.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("We owe: ৳${"%,.0f".format(s.dueBalance)}" + if (s.creditLimit > 0) " / limit ৳${"%,.0f".format(s.creditLimit)}" else "", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Row {
                            if (vm.canDelete()) {
                                val delSupContext = androidx.compose.ui.platform.LocalContext.current
                                TextButton(onClick = { vm.deleteSupplier(s.id, onRejected = { e -> android.widget.Toast.makeText(delSupContext, e, android.widget.Toast.LENGTH_LONG).show() }) }) { Text("Delete", color = DangerRed) }
                            }
                            com.abm.erp.core.UniversalActionMenu(
                                moduleReference = "Supplier", entityId = s.id, entityLabel = s.name,
                                shareText = "Supplier: ${s.name}\nDue: ৳${s.dueBalance}",
                                isDeleted = s.isDeleted,
                                onDuplicate = { onError -> vm.duplicateSupplier(s.id, onRejected = onError) },
                                onArchive = { onError -> vm.deleteSupplier(s.id, onRejected = onError) },
                                canArchive = vm.canDelete(),
                                archiveBlockedReasonOverride = if (s.dueBalance > 0) "এই সাপ্লায়ারের কাছে আমাদের বকেয়া ৳${"%,.0f".format(s.dueBalance)} আছে — বকেয়া মেটানো না হওয়া পর্যন্ত archive করা যাবে না।" else null,
                                onRestore = { supplierScope.launch { vm.restoreSupplier(s.id) } },
                                csvHeader = "Name,Due,CreditLimit",
                                csvRow = com.abm.erp.core.toCsvRow(s.name, s.dueBalance, s.creditLimit),
                            )
                        }
                    }
                }
            }
            if (suppliers.isEmpty()) item { Text("এখনো কোনো সাপ্লায়ার নেই।", color = TextSecondary) }
        }
    }

    if (showAdd) {
        Dialog(onDismissRequest = { showAdd = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var name by remember { mutableStateOf("") }
                var phone by remember { mutableStateOf("") }
                var address by remember { mutableStateOf("") }
                var creditLimitText by remember { mutableStateOf("") }
                var error by remember { mutableStateOf<String?>(null) }
                Column(Modifier.padding(16.dp)) {
                    Text("Supplier Registration", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Supplier name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = creditLimitText, onValueChange = { creditLimitText = it }, label = { Text("Credit limit they extend to us (৳, optional)") }, modifier = Modifier.fillMaxWidth())
                    error?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 6.dp)) }
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = {
                            val created = vm.createSupplier(name, phone, address, creditLimitText.toDoubleOrNull() ?: 0.0, onRejected = { reason -> error = reason })
                            if (created != null) showAdd = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Register Supplier") }
                }
            }
        }
    }
}

@Composable
private fun PoLineItemBuilder(items: MutableList<PurchaseLineItem>) {
    var name by remember { mutableStateOf("") }
    var qtyText by remember { mutableStateOf("") }
    var costText by remember { mutableStateOf("") }

    Column {
        items.forEachIndexed { idx, item ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${item.name} × ${item.qty} @ ৳${item.unitCost}", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { items.removeAt(idx) }) { Text("✕", color = DangerRed) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Item") }, modifier = Modifier.weight(2f))
            OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Qty") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = costText, onValueChange = { costText = it }, label = { Text("৳ cost") }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Button(
            onClick = {
                val qty = qtyText.toDoubleOrNull() ?: return@Button
                val cost = costText.toDoubleOrNull() ?: return@Button
                if (name.isBlank()) return@Button
                items.add(PurchaseLineItem(productId = "", name = name, unit = "pcs", qty = qty, unitCost = cost))
                name = ""; qtyText = ""; costText = ""
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("+ Add item") }
    }
}

@Composable
private fun PurchaseOrdersTab(vm: PurchaseViewModel) {
    val orders by vm.purchaseOrders.collectAsState()
    val suppliers by vm.suppliers.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    var statusFilter by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    val duplicateScope = androidx.compose.runtime.rememberCoroutineScope()

    val pendingCount = orders.count { it.status == "DRAFT" }
    val approvedCount = orders.count { it.status == "SENT" }
    val receivedCount = orders.count { it.status == "RECEIVED" }
    val cancelledCount = orders.count { it.status == "CANCELLED" }
    val totalValue = orders.filter { it.status != "CANCELLED" }.sumOf { it.subTotal }
    val topSuppliers = remember(orders) {
        orders.filter { it.status != "CANCELLED" }.groupBy { it.supplierName }
            .mapValues { (_, list) -> list.sumOf { it.subTotal } }
            .entries.sortedByDescending { it.value }.take(3)
    }
    var supplierFilter by remember { mutableStateOf<String?>(null) }
    var dateFilter by remember { mutableStateOf(0) } // 0=All,1=Today,2=Week,3=Month
    val poCutoff = when (dateFilter) {
        1 -> java.time.LocalDate.now().atStartOfDay()
        2 -> java.time.LocalDate.now().minusDays(7).atStartOfDay()
        3 -> java.time.LocalDate.now().minusDays(30).atStartOfDay()
        else -> null
    }
    val filteredOrders = remember(orders, statusFilter, searchQuery, supplierFilter, dateFilter) {
        orders.filter { po ->
            (statusFilter == null || po.status == statusFilter) &&
                (searchQuery.isBlank() || po.poNo.contains(searchQuery, ignoreCase = true) || po.supplierName.contains(searchQuery, ignoreCase = true)) &&
                (supplierFilter == null || po.supplierName == supplierFilter) &&
                (poCutoff == null || po.createdAt.isAfter(poCutoff))
        }
    }

    Column(Modifier.fillMaxSize()) {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Purchase Insights", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Column { Text("Draft", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("$pendingCount", fontWeight = FontWeight.Bold, color = WarningAmber) }
                Column { Text("Sent", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("$approvedCount", fontWeight = FontWeight.Bold, color = Sky) }
                Column { Text("Received", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("$receivedCount", fontWeight = FontWeight.Bold, color = SuccessGreen) }
                Column { Text("Cancelled", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("$cancelledCount", fontWeight = FontWeight.Bold, color = DangerRed) }
            }
            Spacer(Modifier.height(6.dp))
            Text("Total Purchase Value: ৳${"%,.0f".format(totalValue)}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            if (topSuppliers.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text("Top suppliers: " + topSuppliers.joinToString(", ") { "${it.key} (৳${"%,.0f".format(it.value)})" }, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            val costComparison = remember(orders) {
                orders.filter { it.status != "CANCELLED" }.flatMap { po -> po.lineItems.map { it.name to (po.supplierName to it.unitCost) } }
                    .groupBy { it.first }
                    .mapValues { (_, list) -> list.map { it.second }.distinctBy { it.first } }
                    .filter { (_, suppliers) -> suppliers.size > 1 }
            }
            if (costComparison.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text("Cost Comparison (একই product একাধিক supplier থেকে):", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, color = Sky)
                costComparison.entries.take(5).forEach { (product, suppliers) ->
                    Text("$product: " + suppliers.joinToString(", ") { "${it.first} ৳${"%.0f".format(it.second)}" }, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = searchQuery, onValueChange = { searchQuery = it },
            placeholder = { Text("PO number/supplier খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            FilterChip(selected = statusFilter == null, onClick = { statusFilter = null }, label = { Text("All") })
            listOf("DRAFT", "SENT", "PARTIALLY_RECEIVED", "RECEIVED", "CANCELLED").forEach { s -> FilterChip(selected = statusFilter == s, onClick = { statusFilter = s }, label = { Text(s) }) }
        }
        val supplierNames = remember(orders) { orders.map { it.supplierName }.distinct().sorted() }
        if (supplierNames.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                FilterChip(selected = supplierFilter == null, onClick = { supplierFilter = null }, label = { Text("All Suppliers") })
                supplierNames.forEach { s -> FilterChip(selected = supplierFilter == s, onClick = { supplierFilter = s }, label = { Text(s) }) }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            FilterChip(selected = dateFilter == 0, onClick = { dateFilter = 0 }, label = { Text("All") })
            FilterChip(selected = dateFilter == 1, onClick = { dateFilter = 1 }, label = { Text("Today") })
            FilterChip(selected = dateFilter == 2, onClick = { dateFilter = 2 }, label = { Text("Week") })
            FilterChip(selected = dateFilter == 3, onClick = { dateFilter = 3 }, label = { Text("Month") })
        }
        Spacer(Modifier.height(10.dp))
        if (vm.canCreate()) {
            Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Purchase Order") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filteredOrders) { po ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${po.poNo} — ${po.supplierName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("৳${"%,.0f".format(po.subTotal)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Row {
                            Text(po.status, color = when (po.status) { "RECEIVED" -> SuccessGreen; "CANCELLED" -> DangerRed; else -> WarningAmber }, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            val context = androidx.compose.ui.platform.LocalContext.current
                            TextButton(onClick = {
                                try {
                                    val file = com.abm.erp.core.exportPurchaseOrderPdf(context, po)
                                    com.abm.erp.core.shareStructuredPdf(context, file, "PO ${po.poNo}")
                                } catch (e: Exception) {
                                    android.widget.Toast.makeText(context, "PO PDF তৈরি ব্যর্থ হয়েছে: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                                }
                            }) { Text("📄", style = MaterialTheme.typography.labelSmall) }
                            val poAuditLog by MockRepository.activityLogFor("PurchaseOrder", po.id).collectAsState(initial = emptyList())
                            com.abm.erp.core.UniversalActionMenu(
                                moduleReference = "PurchaseOrder", entityId = po.id, entityLabel = po.poNo,
                                shareText = "PO ${po.poNo} — ${po.supplierName}\nTotal: ৳${po.subTotal}\nStatus: ${po.status}",
                                onDuplicate = { onError -> duplicateScope.launch { vm.duplicatePurchaseOrder(po.id, onRejected = onError) } },
                                csvHeader = "PONo,Supplier,SubTotal,Status",
                                csvRow = com.abm.erp.core.toCsvRow(po.poNo, po.supplierName, po.subTotal, po.status),
                                historyLabel = "PO Timeline",
                                historyItems = poAuditLog.sortedByDescending { it.timestamp }.map { "${it.action} — ${it.performedBy} (${it.timestamp.toLocalDate()})" },
                            )
                        }
                    }
                    if (po.status == "DRAFT") {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.updatePurchaseOrderStatus(po.id, "SENT") }) { Text("Send to Supplier") }
                            OutlinedButton(onClick = { vm.updatePurchaseOrderStatus(po.id, "CANCELLED") }) { Text("Cancel", color = DangerRed) }
                        }
                    }
                }
            }
            if (filteredOrders.isEmpty()) item { Text("এখনো কোনো Purchase Order নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var selectedSupplier by remember { mutableStateOf<Supplier?>(null) }
                var expanded by remember { mutableStateOf(false) }
                val lineItems = remember { mutableStateListOf<PurchaseLineItem>() }
                val poScope = androidx.compose.runtime.rememberCoroutineScope()
                Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
                    Text("New Purchase Order", style = MaterialTheme.typography.titleMedium)
                    var poError by remember { mutableStateOf<String?>(null) }
                    poError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedSupplier?.name ?: "Select supplier") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            suppliers.forEach { s -> DropdownMenuItem(text = { Text(s.name) }, onClick = { selectedSupplier = s; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    PoLineItemBuilder(lineItems)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val s = selectedSupplier ?: return@Button
                            if (lineItems.isEmpty()) return@Button
                            poScope.launch {
                                val created = vm.createPurchaseOrder(s.id, s.name, lineItems.toList(), onRejected = { e -> poError = e })
                                if (created != null) showNew = false
                            }
                        },
                        enabled = selectedSupplier != null && lineItems.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Create Purchase Order") }
                }
            }
        }
    }
}

@Composable
private fun GrnTab(vm: PurchaseViewModel) {
    val grns by vm.goodsReceivedNotes.collectAsState()
    val orders by vm.purchaseOrders.collectAsState()
    val warehouses by vm.warehouses.collectAsState()
    val sentOrders = orders.filter { it.status in setOf("SENT", "PARTIALLY_RECEIVED") }
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        if (vm.canCreate()) {
            Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth(), enabled = sentOrders.isNotEmpty()) { Text("+ Receive Goods (GRN)") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(grns) { g ->
                val relatedPo = orders.firstOrNull { it.id == g.purchaseOrderId }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${g.grnNo} — ${g.supplierName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("৳${"%,.0f".format(g.totalValue)} · received by ${g.receivedBy}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "GRN", entityId = g.id, entityLabel = g.grnNo,
                            shareText = "GRN ${g.grnNo} — ${g.supplierName}\nValue: ৳${g.totalValue}",
                            csvHeader = "GRNNo,Supplier,TotalValue,ReceivedBy", csvRow = com.abm.erp.core.toCsvRow(g.grnNo, g.supplierName, g.totalValue, g.receivedBy),
                        )
                    }
                    if (relatedPo != null) {
                        val variances = relatedPo.lineItems.mapNotNull { ordered ->
                            val received = g.receivedItems.firstOrNull { it.productId == ordered.productId }?.qty ?: 0.0
                            if (received != ordered.qty) ordered.name to (received - ordered.qty) else null
                        }
                        if (variances.isNotEmpty()) {
                            Spacer(Modifier.height(6.dp))
                            Text("Variance (received − ordered):", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, color = WarningAmber)
                            variances.forEach { (name, diff) -> Text("$name: ${if (diff > 0) "+" else ""}${"%.1f".format(diff)}", style = MaterialTheme.typography.labelSmall, color = if (diff < 0) DangerRed else SuccessGreen) }
                        }
                    }
                }
            }
            if (grns.isEmpty()) item { Text("এখনো কোনো GRN নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var selectedPo by remember { mutableStateOf<PurchaseOrder?>(null) }
                var poExpanded by remember { mutableStateOf(false) }
                var selectedWarehouse by remember { mutableStateOf<String?>(null) }
                var whExpanded by remember { mutableStateOf(false) }
                Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
                    Text("Goods Received Note", style = MaterialTheme.typography.titleMedium)
                    Text("PO-তে থাকা সব item পুরোপুরি গ্রহণ করা হচ্ছে ধরে নেওয়া হবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    var receiveError by remember { mutableStateOf<String?>(null) }
                    receiveError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Box {
                        OutlinedButton(onClick = { poExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedPo?.poNo ?: "Select Purchase Order") }
                        DropdownMenu(expanded = poExpanded, onDismissRequest = { poExpanded = false }) {
                            sentOrders.forEach { po -> DropdownMenuItem(text = { Text("${po.poNo} — ${po.supplierName}") }, onClick = { selectedPo = po; poExpanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Box {
                        OutlinedButton(onClick = { whExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(warehouses.firstOrNull { it.id == selectedWarehouse }?.name ?: "Select warehouse")
                        }
                        DropdownMenu(expanded = whExpanded, onDismissRequest = { whExpanded = false }) {
                            warehouses.forEach { w -> DropdownMenuItem(text = { Text(w.name) }, onClick = { selectedWarehouse = w.id; whExpanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val po = selectedPo ?: return@Button
                            val wh = selectedWarehouse ?: return@Button
                            val created = vm.receiveGoods(po.id, po.supplierId, po.supplierName, po.lineItems, wh, onRejected = { r -> receiveError = r })
                            if (created != null) showNew = false
                        },
                        enabled = selectedPo != null && selectedWarehouse != null,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm Receipt — Stock In") }
                }
            }
        }
    }
}

@Composable
private fun PurchaseReturnTab(vm: PurchaseViewModel) {
    val returns by vm.purchaseReturns.collectAsState()
    val suppliers by vm.suppliers.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    val purchaseReturnScope = androidx.compose.runtime.rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Purchase Return") }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(returns) { r ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${r.returnNo} — ${r.supplierName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("৳${"%,.0f".format(r.refundAmount)} · ${r.reason}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text(r.status, color = when (r.status) { "APPROVED" -> SuccessGreen; "REJECTED" -> DangerRed; else -> WarningAmber }, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                    }
                    if (r.status == "PENDING" && vm.canApprove()) {
                        var returnActionError by remember(r.id) { mutableStateOf<String?>(null) }
                        returnActionError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.approvePurchaseReturn(r.id, onRejected = { e -> returnActionError = e }) }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) { Text("Approve") }
                            OutlinedButton(onClick = { vm.rejectPurchaseReturn(r.id) }) { Text("Reject", color = DangerRed) }
                        }
                    }
                }
            }
            if (returns.isEmpty()) item { Text("এখনো কোনো Purchase Return নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var selectedSupplier by remember { mutableStateOf<Supplier?>(null) }
                var expanded by remember { mutableStateOf(false) }
                var reason by remember { mutableStateOf("") }
                val lineItems = remember { mutableStateListOf<PurchaseLineItem>() }
                Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
                    Text("New Purchase Return", style = MaterialTheme.typography.titleMedium)
                    var prError by remember { mutableStateOf<String?>(null) }
                    prError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedSupplier?.name ?: "Select supplier") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            suppliers.forEach { s -> DropdownMenuItem(text = { Text(s.name) }, onClick = { selectedSupplier = s; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    PoLineItemBuilder(lineItems)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val s = selectedSupplier ?: return@Button
                            purchaseReturnScope.launch {
                                val created = vm.createPurchaseReturn(null, s.id, s.name, lineItems.toList(), reason, onRejected = { e -> prError = e })
                                if (created != null) showNew = false
                            }
                        },
                        enabled = selectedSupplier != null && lineItems.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Submit Return") }
                }
            }
        }
    }
}

@Composable
private fun SupplierPaymentTab(vm: PurchaseViewModel) {
    val suppliers by vm.suppliers.collectAsState()
    var selectedSupplier by remember { mutableStateOf<Supplier?>(null) }
    var expanded by remember { mutableStateOf(false) }
    var amountText by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("BANK") }
    var message by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        Text("Pay a Supplier", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedSupplier?.name ?: "Select supplier") }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                suppliers.forEach { s -> DropdownMenuItem(text = { Text("${s.name} (due ৳${"%,.0f".format(s.dueBalance)})") }, onClick = { selectedSupplier = s; expanded = false }) }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("Amount (৳)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("CASH", "BANK", "MOBILE_BANKING", "CHEQUE").forEach { m -> FilterChip(selected = method == m, onClick = { method = m }, label = { Text(m) }) }
        }
        Spacer(Modifier.height(12.dp))
        message?.let { Text(it, color = SuccessGreen, modifier = Modifier.padding(bottom = 8.dp)) }
        Button(
            onClick = {
                val s = selectedSupplier ?: return@Button
                val amt = amountText.toDoubleOrNull() ?: return@Button
                vm.createSupplierPayment(s.id, amt, method)
                message = "✓ ৳${"%,.0f".format(amt)} ${s.name}-কে পরিশোধ রেকর্ড হয়েছে"
                amountText = ""
            },
            enabled = selectedSupplier != null && amountText.toDoubleOrNull() != null,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Record Payment") }
    }
}

/**
 * v86, Module 7 — Purchase Requisition UI: create/approve/reject/convert.
 * Line items are entered as simple product-name + qty pairs (no product
 * picker component exists elsewhere in this module to reuse) — real
 * persistence and workflow, not a placeholder form.
 */
@Composable
private fun PurchaseRequestsTab(vm: PurchaseViewModel) {
    val requests by com.abm.erp.data.PurchaseRepository.purchaseRequests.collectAsState()
    val suppliers by vm.suppliers.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    var showConvertFor by remember { mutableStateOf<String?>(null) }
    val requestScope = androidx.compose.runtime.rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Purchase Request") }
        Spacer(Modifier.height(10.dp))
        if (requests.isEmpty()) {
            Text("এখনো কোনো Purchase Request নেই।", color = TextSecondary)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(requests, key = { it.id }) { r ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(r.requestNo, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                r.lineItems.forEach { li -> Text("${li.name} × ${li.qty}", style = MaterialTheme.typography.bodySmall) }
                                if (r.reason.isNotBlank()) Text(r.reason, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                            Text(
                                r.status,
                                color = when (r.status) { "APPROVED" -> SuccessGreen; "REJECTED" -> DangerRed; "CONVERTED" -> Sky; else -> WarningAmber },
                                fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall,
                            )
                            com.abm.erp.core.UniversalActionMenu(
                                moduleReference = "PurchaseRequest", entityId = r.id, entityLabel = r.requestNo,
                                shareText = "${r.requestNo} — ${r.status}\n${r.reason}",
                                csvHeader = "RequestNo,Status,Reason", csvRow = com.abm.erp.core.toCsvRow(r.requestNo, r.status, r.reason),
                            )
                        }
                        if (r.supplierQuotes.isNotEmpty()) {
                            Spacer(Modifier.height(6.dp))
                            Text("Quotes:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Sky)
                            r.supplierQuotes.sortedBy { it.quotedAmount }.forEach { q ->
                                Text("${q.supplierName}: ৳${"%,.0f".format(q.quotedAmount)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                        if (r.status == "PENDING") {
                            var showQuote by remember { mutableStateOf(false) }
                            TextButton(onClick = { showQuote = true }) { Text("+ Add Quote") }
                            if (showQuote) {
                                var qSupplier by remember { mutableStateOf("") }
                                var qAmount by remember { mutableStateOf("") }
                                Dialog(onDismissRequest = { showQuote = false }) {
                                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                        Column(Modifier.padding(16.dp)) {
                                            Text("Add Supplier Quote", style = MaterialTheme.typography.titleMedium)
                                            Spacer(Modifier.height(8.dp))
                                            OutlinedTextField(value = qSupplier, onValueChange = { qSupplier = it }, label = { Text("Supplier name") }, modifier = Modifier.fillMaxWidth())
                                            Spacer(Modifier.height(8.dp))
                                            OutlinedTextField(value = qAmount, onValueChange = { qAmount = it }, label = { Text("Quoted Amount (৳)") }, modifier = Modifier.fillMaxWidth())
                                            Spacer(Modifier.height(10.dp))
                                            Button(
                                                onClick = { qAmount.toDoubleOrNull()?.let { com.abm.erp.data.PurchaseRepository.addSupplierQuote(r.id, "", qSupplier, it); showQuote = false } },
                                                enabled = qSupplier.isNotBlank() && qAmount.toDoubleOrNull() != null,
                                                modifier = Modifier.fillMaxWidth(),
                                            ) { Text("Save Quote") }
                                        }
                                    }
                                }
                            }
                        }
                        if (r.status == "PENDING" && vm.canCreate()) {
                            Spacer(Modifier.height(6.dp))
                            val purchaseReqContext = androidx.compose.ui.platform.LocalContext.current
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { com.abm.erp.data.PurchaseRepository.approvePurchaseRequest(r.id, onRejected = { e -> android.widget.Toast.makeText(purchaseReqContext, e, android.widget.Toast.LENGTH_LONG).show() }) }) { Text("Approve") }
                                TextButton(onClick = { com.abm.erp.data.PurchaseRepository.rejectPurchaseRequest(r.id, "Rejected by ${MockRepository.currentUser.name}", onRejected = { e -> android.widget.Toast.makeText(purchaseReqContext, e, android.widget.Toast.LENGTH_LONG).show() }) }) { Text("Reject", color = DangerRed) }
                            }
                        }
                        if (r.status == "APPROVED") {
                            Spacer(Modifier.height(6.dp))
                            Button(onClick = { showConvertFor = r.id }, modifier = Modifier.fillMaxWidth()) { Text("Convert to Purchase Order") }
                        }
                    }
                }
            }
        }
    }

    if (showNew) {
        var productName by remember { mutableStateOf("") }
        var qty by remember { mutableStateOf("") }
        var reason by remember { mutableStateOf("") }
        var cart by remember { mutableStateOf(listOf<com.abm.erp.data.PurchaseLineItem>()) }
        Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                    Text("New Purchase Request", style = MaterialTheme.typography.titleMedium)
                    var reqError by remember { mutableStateOf<String?>(null) }
                    reqError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(8.dp))
                    cart.forEach { li -> Text("• ${li.name} × ${li.qty}", style = MaterialTheme.typography.bodySmall) }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = productName, onValueChange = { productName = it }, label = { Text("Product") }, modifier = Modifier.weight(2f))
                        OutlinedTextField(value = qty, onValueChange = { qty = it }, label = { Text("Qty") }, modifier = Modifier.weight(1f))
                    }
                    TextButton(onClick = {
                        val q = qty.toDoubleOrNull()
                        if (productName.isNotBlank() && q != null && q > 0) {
                            cart = cart + com.abm.erp.data.PurchaseLineItem(productId = "", name = productName, unit = "pcs", qty = q, unitCost = 0.0)
                            productName = ""; qty = ""
                        }
                    }) { Text("+ Add Item") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { com.abm.erp.data.PurchaseRepository.createPurchaseRequest(cart, null, reason, onRejected = { e -> reqError = e })?.let { showNew = false } },
                        enabled = cart.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Submit Request") }
                }
            }
        }
    }

    if (showConvertFor != null) {
        val requestId = showConvertFor!!
        var selectedSupplierId by remember { mutableStateOf<String?>(null) }
        Dialog(onDismissRequest = { showConvertFor = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 400.dp)) {
                    Text("Select Supplier", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Column(Modifier.heightIn(max = 240.dp).verticalScroll(rememberScrollState())) {
                        suppliers.forEach { s ->
                            Text(s.name, fontWeight = if (selectedSupplierId == s.id) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.fillMaxWidth().clickable { selectedSupplierId = s.id }.padding(vertical = 6.dp))
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val s = suppliers.firstOrNull { it.id == selectedSupplierId }
                            if (s != null) { requestScope.launch { com.abm.erp.data.PurchaseRepository.convertRequestToPurchaseOrder(requestId, s.id, s.name) }; showConvertFor = null }
                        },
                        enabled = selectedSupplierId != null,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Create Purchase Order") }
                }
            }
        }
    }
}
