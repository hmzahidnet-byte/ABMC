package com.abm.erp.data.room

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CompanyDao {
    @Query("SELECT * FROM companies")
    fun getAll(): Flow<List<CompanyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(companies: List<CompanyEntity>)
}

@Dao
interface AppUserDao {
    @Query("SELECT * FROM app_users LIMIT 1")
    fun getCurrent(): Flow<AppUserEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(user: AppUserEntity)
}

@Dao
interface RetailOrderDao {
    @Query("SELECT * FROM retail_orders ORDER BY loggedAtEpochMillis DESC")
    fun getAll(): Flow<List<RetailOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(order: RetailOrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(orders: List<RetailOrderEntity>)

    @Query("UPDATE retail_orders SET stage = :stage, routedDealerId = COALESCE(:dealerId, routedDealerId) WHERE id = :id")
    suspend fun advance(id: String, stage: String, dealerId: String?)

    @Query("SELECT COUNT(*) FROM retail_orders")
    suspend fun count(): Int

    /** v113-373 — removes only the three seeded demo memos, by id. */
    @Query("DELETE FROM retail_orders WHERE id LIKE 'seed-ord-%'")
    suspend fun deleteDemoSeeded()
}

@Dao
interface DealerDao {
    // v113-342 — real hard delete, for Recycle's own permanent-delete
    // action. Every other delete in this app is a soft delete; this is
    // the only path that actually removes the row, and it is reachable
    // solely from a confirm-gated Chairman action.
    @Query("DELETE FROM dealers WHERE id = :id")
    suspend fun purgeDealer(id: String)

    @Query("SELECT * FROM dealers")
    fun getAll(): Flow<List<DealerEntity>>

    @Query("SELECT * FROM dealers WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): DealerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(dealers: List<DealerEntity>)

    @Query("SELECT COUNT(*) FROM dealers")
    suspend fun count(): Int

    @Query("UPDATE dealers SET stockUnits = stockUnits + :delta WHERE id = :dealerId")
    suspend fun adjustStock(dealerId: String, delta: Int)

    @Query("UPDATE dealers SET dueBalance = dueBalance + :delta WHERE id = :dealerId")
    suspend fun adjustDueBalance(dealerId: String, delta: Double)

    @Query("UPDATE dealers SET monthlyTarget = :target WHERE id = :dealerId")
    suspend fun updateMonthlyTarget(dealerId: String, target: Double)

    @Query("UPDATE dealers SET promiseToPayEpochMillis = :date, promiseToPayAmount = :amount, promiseNote = :note WHERE id = :dealerId")
    suspend fun setPromiseToPay(dealerId: String, date: Long?, amount: Double, note: String?)

    @Query("UPDATE dealers SET weeklyPaidAmount = :weeklyPaidAmount, weekStartEpochDay = :weekStartEpochDay WHERE id = :dealerId")
    suspend fun updateWeeklyPaid(dealerId: String, weeklyPaidAmount: Double, weekStartEpochDay: Long)

    @Query("UPDATE dealers SET creditStatus = :status, creditStatusReason = :reason, creditStatusChangedBy = :changedBy, creditStatusChangedAtEpochMillis = :changedAt WHERE id = :dealerId")
    suspend fun updateCreditStatus(dealerId: String, status: String, reason: String, changedBy: String, changedAt: Long)

    @Query("SELECT COUNT(*) FROM dealers WHERE dedupKey = :dedupKey AND isDeleted = 0")
    suspend fun countByDedupKey(dedupKey: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(dealer: DealerEntity)

    @Query("UPDATE dealers SET isDeleted = 1, deletedAtEpochMillis = :deletedAt, deletedBy = :deletedBy WHERE id = :id")
    suspend fun softDelete(id: String, deletedAt: Long, deletedBy: String)

    @Query("UPDATE dealers SET isDeleted = 0, deletedAtEpochMillis = NULL, deletedBy = NULL WHERE id = :id")
    suspend fun restore(id: String)
}

@Dao
interface AdministrativeLocationDao {
    @Query("SELECT * FROM administrative_locations WHERE active = 1")
    fun getAll(): Flow<List<AdministrativeLocationEntity>>

    @Query("SELECT * FROM administrative_locations WHERE type = :type AND active = 1 ORDER BY nameEn")
    fun getByType(type: String): Flow<List<AdministrativeLocationEntity>>

    @Query("SELECT * FROM administrative_locations WHERE parentId = :parentId AND active = 1 ORDER BY nameEn")
    fun getChildren(parentId: String): Flow<List<AdministrativeLocationEntity>>

    @Query("SELECT * FROM administrative_locations WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): AdministrativeLocationEntity?

    @Query("SELECT COUNT(*) FROM administrative_locations")
    suspend fun count(): Int

    @Query("SELECT COUNT(*) FROM administrative_locations WHERE type = :type")
    suspend fun countByType(type: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: AdministrativeLocationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<AdministrativeLocationEntity>)

    @Query("SELECT * FROM administrative_locations WHERE (nameEn LIKE '%' || :query || '%' OR nameBn LIKE '%' || :query || '%') AND active = 1 LIMIT 50")
    suspend fun search(query: String): List<AdministrativeLocationEntity>

    @Query("SELECT * FROM administrative_locations WHERE type = 'DISTRICT' AND polygonRaw != ''")
    suspend fun districtsWithPolygon(): List<AdministrativeLocationEntity>
}

@Dao
interface CompanyMarketDao {
    @Query("SELECT * FROM company_markets ORDER BY name")
    fun getAll(): Flow<List<CompanyMarketEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: CompanyMarketEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<CompanyMarketEntity>)

    @Query("SELECT COUNT(*) FROM company_markets WHERE parentAdminId = :parentAdminId AND name = :name")
    suspend fun countDuplicate(parentAdminId: String, name: String): Int
}

@Dao
interface UserAccountDao {
    @Query("SELECT * FROM user_accounts WHERE active = 1")
    fun getAll(): Flow<List<UserAccountEntity>>

    @Query("SELECT * FROM user_accounts WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): UserAccountEntity?

    @Query("SELECT * FROM user_accounts WHERE employeeProfileId = :employeeProfileId AND active = 1 LIMIT 1")
    suspend fun getByEmployeeProfileId(employeeProfileId: String): UserAccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: UserAccountEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<UserAccountEntity>)

    @Query("UPDATE user_accounts SET failedAttempts = :attempts, lockedUntilEpochMillis = :lockedUntil, locked = :locked, updatedAtEpochMillis = :now WHERE id = :id")
    suspend fun updateLockoutState(id: String, attempts: Int, lockedUntil: Long?, locked: Boolean, now: Long)

    @Query("UPDATE user_accounts SET pinHash = :hash, pinSalt = :salt, pinIterations = :iterations, pinSetAtEpochMillis = :now, pinExpiresAtEpochMillis = :expiresAt, mustChangePinOnNextLogin = 0, failedAttempts = 0, lockedUntilEpochMillis = NULL, locked = 0, updatedAtEpochMillis = :now WHERE id = :id")
    suspend fun updatePin(id: String, hash: String, salt: String, iterations: Int, now: Long, expiresAt: Long?)

    @Query("UPDATE user_accounts SET active = :active, updatedAtEpochMillis = :now WHERE id = :id")
    suspend fun setActive(id: String, active: Boolean, now: Long)
}

@Dao
interface LoginAttemptDao {
    @Insert
    suspend fun insert(entity: LoginAttemptEntity)

    @Query("SELECT COUNT(*) FROM login_attempts WHERE userAccountId = :userAccountId AND success = 0 AND attemptedAtEpochMillis > :sinceEpochMillis")
    suspend fun countRecentFailures(userAccountId: String, sinceEpochMillis: Long): Int

    @Query("SELECT * FROM login_attempts WHERE userAccountId = :userAccountId ORDER BY attemptedAtEpochMillis DESC LIMIT :limit")
    suspend fun recentFor(userAccountId: String, limit: Int): List<LoginAttemptEntity>
}

@Dao
interface TerritoryDao {
    @Query("SELECT * FROM territories")
    fun getAll(): Flow<List<TerritoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(territories: List<TerritoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(territory: TerritoryEntity)

    @Query("UPDATE territories SET polygonRaw = :polygonRaw, polygonVersion = polygonVersion + 1 WHERE id = :id")
    suspend fun setPolygon(id: String, polygonRaw: String)

    @Query("UPDATE territories SET defaultVisitRadiusMeters = :radius WHERE id = :id")
    suspend fun setDefaultRadius(id: String, radius: Double)
}

@Dao
interface TransferRequestDao {
    @Query("SELECT * FROM transfer_requests ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<TransferRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(request: TransferRequestEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(requests: List<TransferRequestEntity>)

    @Query("UPDATE transfer_requests SET stage = :stage, rejectReason = :reason WHERE id = :id")
    suspend fun setStage(id: String, stage: String, reason: String?)
}

@Dao
interface DelegationDao {
    @Query("SELECT * FROM delegations ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<DelegationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(delegation: DelegationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(delegations: List<DelegationEntity>)

    @Query("UPDATE delegations SET isActive = 0 WHERE id = :id")
    suspend fun deactivate(id: String)
}

@Dao
interface EmployeeAreaAssignmentDao {
    @Query("SELECT * FROM employee_area_assignments")
    fun getAll(): Flow<List<EmployeeAreaAssignmentEntity>>

    @Query("SELECT * FROM employee_area_assignments WHERE employeeId = :employeeId AND isActive = 1")
    suspend fun getActiveForEmployee(employeeId: String): List<EmployeeAreaAssignmentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: EmployeeAreaAssignmentEntity)

    @Query("UPDATE employee_area_assignments SET isActive = 0, endDateEpochDay = :endDateEpochDay WHERE id = :id")
    suspend fun close(id: String, endDateEpochDay: Long)
}

@Dao
interface EmployeeAppraisalDao {
    @Query("SELECT * FROM employee_appraisals")
    fun getAll(): Flow<List<EmployeeAppraisalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: EmployeeAppraisalEntity)
}

@Dao
interface ManufacturingWorkerAssignmentDao {
    @Query("SELECT * FROM manufacturing_worker_assignments")
    fun getAll(): Flow<List<ManufacturingWorkerAssignmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ManufacturingWorkerAssignmentEntity)

    @Query("UPDATE manufacturing_worker_assignments SET isActive = 0, endDateEpochDay = :endDateEpochDay WHERE id = :id")
    suspend fun close(id: String, endDateEpochDay: Long)
}

@Dao
interface EmployeePermissionOverrideDao {
    @Query("SELECT * FROM employee_permission_overrides")
    fun getAll(): Flow<List<EmployeePermissionOverrideEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: EmployeePermissionOverrideEntity)

    @Query("DELETE FROM employee_permission_overrides WHERE employeeId = :employeeId AND moduleKey = :moduleKey")
    suspend fun clear(employeeId: String, moduleKey: String)

    @Query("DELETE FROM employee_permission_overrides WHERE employeeId = :employeeId")
    suspend fun clearAllForEmployee(employeeId: String)
}

@Dao
interface VacancyDao {
    @Query("SELECT * FROM vacancies")
    fun getAll(): Flow<List<VacancyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: VacancyEntity)
}

@Dao
interface TargetDao {
    @Query("SELECT * FROM targets")
    fun getAll(): Flow<List<TargetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: TargetEntity)
}

@Dao
interface TargetChangeLogDao {
    @Query("SELECT * FROM target_change_logs")
    fun getAll(): Flow<List<TargetChangeLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: TargetChangeLogEntity)
}

@Dao
interface CorrectionRequestDao {
    @Query("SELECT * FROM correction_requests")
    fun getAll(): Flow<List<CorrectionRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: CorrectionRequestEntity)
}

@Dao
interface AccountingPeriodLockDao {
    @Query("SELECT * FROM accounting_period_locks")
    fun getAll(): Flow<List<AccountingPeriodLockEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: AccountingPeriodLockEntity)
}

@Dao
interface NumberSeriesConfigDao {
    @Query("SELECT * FROM number_series_configs")
    fun getAll(): Flow<List<NumberSeriesConfigEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: NumberSeriesConfigEntity)
}

@Dao
interface OwnershipTransferRecordDao {
    @Query("SELECT * FROM ownership_transfer_records")
    fun getAll(): Flow<List<OwnershipTransferRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: OwnershipTransferRecordEntity)
}

@Dao
interface BusinessRuleDao {
    @Query("SELECT * FROM business_rules")
    fun getAll(): Flow<List<BusinessRuleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: BusinessRuleEntity)
}

@Dao
interface CompanySettingsDao {
    @Query("SELECT * FROM company_settings")
    fun getAll(): Flow<List<CompanySettingsEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: CompanySettingsEntity)
}

@Dao
interface ExpenseDao {
    @Query("SELECT * FROM expenses ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<ExpenseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ExpenseEntity)

    @Query("UPDATE expenses SET status = :status, approvedBy = :approvedBy, rejectReason = :rejectReason, approvedAtEpochMillis = :approvedAt WHERE id = :id")
    suspend fun setStatus(id: String, status: String, approvedBy: String?, rejectReason: String?, approvedAt: Long?)
}

@Dao
interface ProductionPlanDao {
    @Query("SELECT * FROM production_plans")
    fun getAll(): Flow<List<ProductionPlanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ProductionPlanEntity)
}

@Dao
interface RawMaterialIssueDao {
    @Query("SELECT * FROM raw_material_issues")
    fun getAll(): Flow<List<RawMaterialIssueEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: RawMaterialIssueEntity)
}

@Dao
interface QualityInspectionDao {
    @Query("SELECT * FROM quality_inspections")
    fun getAll(): Flow<List<QualityInspectionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: QualityInspectionEntity)
}

@Dao
interface PackingRecordDao {
    @Query("SELECT * FROM packing_records")
    fun getAll(): Flow<List<PackingRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: PackingRecordEntity)
}

@Dao
interface CartonDao {
    @Query("SELECT * FROM cartons")
    fun getAll(): Flow<List<CartonEntity>>

    @Query("SELECT * FROM cartons WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): CartonEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: CartonEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<CartonEntity>)

    // v113-216 — batch-code assignment happens later than packing
    // (confirmFinishedGoods runs after recordPacking, once QC has passed),
    // so cartons are created without one and this fills it in for every
    // carton belonging to the same production plan once the real code exists.
    @Query("UPDATE cartons SET batchCode = :batchCode WHERE productionPlanId = :productionPlanId")
    suspend fun assignBatchCodeForPlan(productionPlanId: String, batchCode: String)
}

@Dao
interface FinishedGoodsReceiptDao {
    @Query("SELECT * FROM finished_goods_receipts")
    fun getAll(): Flow<List<FinishedGoodsReceiptEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: FinishedGoodsReceiptEntity)
}

@Dao
interface WarehouseTransferDao {
    @Query("SELECT * FROM warehouse_transfers")
    fun getAll(): Flow<List<WarehouseTransferEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: WarehouseTransferEntity)
}

@Dao
interface WarehouseReceiptDao {
    @Query("SELECT * FROM warehouse_receipts")
    fun getAll(): Flow<List<WarehouseReceiptEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: WarehouseReceiptEntity)
}

@Dao
interface EmployeeProfileDao {
    @Query("SELECT * FROM employee_profiles WHERE isDeleted = 0")
    fun getAll(): Flow<List<EmployeeProfileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(employee: EmployeeProfileEntity)

    @Query("UPDATE employee_profiles SET profilePhotoUri = :photoUri WHERE id = :id")
    suspend fun updateProfilePhoto(id: String, photoUri: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(employees: List<EmployeeProfileEntity>)

    @Query("SELECT COUNT(*) FROM employee_profiles WHERE employeeCode = :code AND isDeleted = 0")
    suspend fun countByCode(code: String): Int

    @Query("SELECT COUNT(*) FROM employee_profiles WHERE (mobile = :mobile OR email = :email) AND email != '' AND isDeleted = 0")
    suspend fun countByContact(mobile: String, email: String): Int

    @Query("UPDATE employee_profiles SET userAccountId = :userAccountId WHERE id = :id")
    suspend fun linkUserAccount(id: String, userAccountId: String)

    @Query("UPDATE employee_profiles SET onboardingStatus = :status, rejectReason = :reason WHERE id = :id")
    suspend fun setOnboardingStatus(id: String, status: String, reason: String?)

    @Query("UPDATE employee_profiles SET status = :status, statusReason = :reason WHERE id = :id")
    suspend fun setStatus(id: String, status: String, reason: String?)

    @Query("UPDATE employee_profiles SET directManagerId = :managerId WHERE id = :id")
    suspend fun setDirectManager(id: String, managerId: String?)

    @Query("UPDATE employee_profiles SET tempManagerId = :managerId, tempAssignmentFromEpochDay = :from, tempAssignmentToEpochDay = :to WHERE id = :id")
    suspend fun setTempManager(id: String, managerId: String?, from: Long?, to: Long?)

    @Query("UPDATE employee_profiles SET role = :role, designation = :designation WHERE id = :id")
    suspend fun setRole(id: String, role: String, designation: String)

    @Query("UPDATE employee_profiles SET territoryId = :territoryId, routeId = :routeId, branch = :branch, region = :region, area = :area WHERE id = :id")
    suspend fun setAssignment(id: String, territoryId: String?, routeId: String?, branch: String, region: String, area: String)

    @Query("UPDATE employee_profiles SET financialApprovalLimit = :financial, creditOverrideLimit = :credit, discountApprovalLimitPct = :discount, stockAdjustmentApprovalLimit = :stock, purchaseApprovalLimit = :purchase, leaveApprovalAuthority = :leaveAuth, attendanceCorrectionAuthority = :attendanceAuth, approvalAuthorityLevel = :level WHERE id = :id")
    suspend fun setApprovalLimits(id: String, financial: Double, credit: Double, discount: Double, stock: Double, purchase: Double, leaveAuth: Boolean, attendanceAuth: Boolean, level: Int)

    @Query("UPDATE employee_profiles SET isDeleted = 1, deletedAtEpochMillis = :now, deletedBy = :by WHERE id = :id")
    suspend fun softDelete(id: String, now: Long, by: String)
}

@Dao
interface RetailerLocationHistoryDao {
    @Query("SELECT * FROM retailer_location_history WHERE retailerId = :retailerId ORDER BY changedAtEpochMillis DESC")
    fun getForRetailer(retailerId: String): Flow<List<RetailerLocationHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: RetailerLocationHistoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entries: List<RetailerLocationHistoryEntity>)

    @Query("SELECT COUNT(*) FROM retailer_location_history WHERE retailerId = :retailerId")
    suspend fun countForRetailer(retailerId: String): Int
}

@Dao
interface EmployeeLocationSnapshotDao {
    @Query("SELECT * FROM employee_location_snapshots WHERE employeeId = :employeeId ORDER BY capturedAtEpochMillis DESC")
    fun getForEmployee(employeeId: String): Flow<List<EmployeeLocationSnapshotEntity>>

    @Query("SELECT * FROM employee_location_snapshots ORDER BY capturedAtEpochMillis DESC")
    fun getAll(): Flow<List<EmployeeLocationSnapshotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(snapshot: EmployeeLocationSnapshotEntity)

    @Query("UPDATE employee_location_snapshots SET syncStatus = :status WHERE id = :id")
    suspend fun setSyncStatus(id: String, status: String)

    @Query("SELECT * FROM employee_location_snapshots WHERE syncStatus != 'SYNCED'")
    suspend fun pendingSync(): List<EmployeeLocationSnapshotEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(snapshots: List<EmployeeLocationSnapshotEntity>)

    @Query("SELECT * FROM employee_location_snapshots WHERE employeeId = :employeeId ORDER BY capturedAtEpochMillis DESC LIMIT 1")
    suspend fun latestForEmployee(employeeId: String): EmployeeLocationSnapshotEntity?
}

@Dao
interface LocationAlertDao {
    @Query("SELECT * FROM location_alerts ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<LocationAlertEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(alert: LocationAlertEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(alerts: List<LocationAlertEntity>)

    @Query("UPDATE location_alerts SET isReviewed = 1, reviewedBy = :reviewedBy, reviewedAtEpochMillis = :reviewedAt, reviewAction = :action, reviewComment = :comment WHERE id = :id")
    suspend fun review(id: String, reviewedBy: String, reviewedAt: Long, action: String, comment: String?)
}

@Dao
interface ExecutiveExceptionDao {
    @Query("SELECT * FROM executive_exceptions ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<ExecutiveExceptionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(e: ExecutiveExceptionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<ExecutiveExceptionEntity>)

    @Query("SELECT COUNT(*) FROM executive_exceptions WHERE dedupKey = :dedupKey AND status NOT IN ('RESOLVED','REJECTED','CLOSED')")
    suspend fun countActiveByDedupKey(dedupKey: String): Int

    @Query("UPDATE executive_exceptions SET status = :status, assignedReviewer = :reviewer, resolutionNote = :note, updatedAtEpochMillis = :now WHERE id = :id")
    suspend fun updateStatus(id: String, status: String, reviewer: String?, note: String?, now: Long)
}

@Dao
interface ManagementActionDao {
    @Query("SELECT * FROM management_actions ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<ManagementActionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(a: ManagementActionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<ManagementActionEntity>)

    @Query("UPDATE management_actions SET status = :status, completionNote = :note WHERE id = :id")
    suspend fun updateStatus(id: String, status: String, note: String?)
}

@Dao
interface DecisionQueryAuditDao {
    @Query("SELECT * FROM decision_query_audit ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<DecisionQueryAuditEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(q: DecisionQueryAuditEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<DecisionQueryAuditEntity>)
}

@Dao
interface SecurityEventDao {
    @Query("SELECT * FROM security_events ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<SecurityEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(event: SecurityEventEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(events: List<SecurityEventEntity>)

    @Query("SELECT COUNT(*) FROM security_events WHERE employeeId = :employeeId AND type = :type AND createdAtEpochMillis > :sinceEpochMillis")
    suspend fun countRecentByType(employeeId: String, type: String, sinceEpochMillis: Long): Int

    @Query("UPDATE security_events SET isReviewed = 1, reviewedBy = :reviewedBy, reviewedAtEpochMillis = :reviewedAt, reviewAction = :action, reviewComment = :comment WHERE id = :id")
    suspend fun review(id: String, reviewedBy: String, reviewedAt: Long, action: String, comment: String?)
}

@Dao
interface GeoOverrideDao {
    @Query("SELECT * FROM geo_overrides ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<GeoOverrideEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(override: GeoOverrideEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(overrides: List<GeoOverrideEntity>)

    @Query("SELECT * FROM geo_overrides WHERE employeeId = :employeeId AND actionType = :actionType AND used = 0 AND expiresAtEpochMillis > :nowEpochMillis ORDER BY createdAtEpochMillis DESC LIMIT 1")
    suspend fun findActive(employeeId: String, actionType: String, nowEpochMillis: Long): GeoOverrideEntity?

    @Query("UPDATE geo_overrides SET used = 1, usedAtEpochMillis = :usedAt WHERE id = :id")
    suspend fun markUsed(id: String, usedAt: Long)
}

@Dao
interface TrustedDeviceDao {
    @Query("SELECT * FROM trusted_devices ORDER BY lastActiveAtEpochMillis DESC")
    fun getAll(): Flow<List<TrustedDeviceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(device: TrustedDeviceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(devices: List<TrustedDeviceEntity>)

    @Query("SELECT * FROM trusted_devices WHERE deviceId = :deviceId AND employeeId = :employeeId LIMIT 1")
    suspend fun find(deviceId: String, employeeId: String): TrustedDeviceEntity?

    @Query("UPDATE trusted_devices SET lastActiveAtEpochMillis = :now, lastLocationAtEpochMillis = :locationAt WHERE id = :id")
    suspend fun touch(id: String, now: Long, locationAt: Long?)

    @Query("UPDATE trusted_devices SET mockSuspicionCount = mockSuspicionCount + 1 WHERE id = :id")
    suspend fun incrementMockSuspicion(id: String)

    @Query("UPDATE trusted_devices SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)
}

@Dao
interface RetailerDao {
    // v113-342 — real hard delete, for Recycle's own permanent-delete
    // action. Every other delete in this app is a soft delete; this is
    // the only path that actually removes the row, and it is reachable
    // solely from a confirm-gated Chairman action.
    @Query("DELETE FROM retailers WHERE id = :id")
    suspend fun purgeRetailer(id: String)

    @Query("SELECT * FROM retailers WHERE isDeleted = 0")
    fun getAll(): Flow<List<RetailerEntity>>

    @Query("SELECT * FROM retailers WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): RetailerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(retailer: RetailerEntity)

    @Query("UPDATE retailers SET photoUri = :photoUri WHERE id = :id")
    suspend fun updateShopPhoto(id: String, photoUri: String)

    @Query("UPDATE retailers SET ownerPhotoUri = :photoUri WHERE id = :id")
    suspend fun updateOwnerPhoto(id: String, photoUri: String)

    @Query("UPDATE retailers SET qrCode = :qrCode WHERE id = :id")
    suspend fun updateQrCode(id: String, qrCode: String)

    @Query(
        """
        UPDATE retailers SET lat = :lat, lng = :lng, gpsAccuracyMeters = :accuracyMeters,
        geoCapturedAtEpochMillis = :capturedAt, locationProvider = :provider,
        locationCapturedByEmployeeId = :capturedByEmployeeId, locationCapturedDeviceId = :deviceId,
        locationCaptureMethod = :captureMethod, locationVerificationStatus = :verificationStatus,
        lastLocationUpdateReason = :reason, locationRevision = locationRevision + 1
        WHERE id = :id
        """,
    )
    suspend fun updateLocation(
        id: String, lat: Double, lng: Double, accuracyMeters: Double?, capturedAt: Long, provider: String?,
        capturedByEmployeeId: String?, deviceId: String?, captureMethod: String, verificationStatus: String, reason: String?,
    )

    @Query(
        """
        UPDATE retailers SET locationVerificationStatus = :status, locationVerificationScore = :score,
        locationVerifiedBy = :verifiedBy, locationVerifiedAtEpochMillis = :verifiedAt, locationVerificationComment = :comment
        WHERE id = :id
        """,
    )
    suspend fun setLocationVerification(id: String, status: String, score: Int?, verifiedBy: String, verifiedAt: Long, comment: String?)

    @Query("UPDATE retailers SET geofenceRadiusMeters = :radius WHERE id = :id")
    suspend fun setGeofenceRadius(id: String, radius: Double?)

    @Query("SELECT COUNT(*) FROM retailers WHERE dedupKey = :dedupKey AND isDeleted = 0")
    suspend fun countByDedupKey(dedupKey: String): Int

    @Query("UPDATE retailers SET dueBalance = dueBalance + :delta WHERE id = :id")
    suspend fun adjustDueBalance(id: String, delta: Double)

    @Query("UPDATE retailers SET isDeleted = 1, deletedAtEpochMillis = :deletedAt, deletedBy = :deletedBy WHERE id = :id")
    suspend fun softDelete(id: String, deletedAt: Long, deletedBy: String)

    @Query("UPDATE retailers SET isDeleted = 0, deletedAtEpochMillis = NULL, deletedBy = NULL WHERE id = :id")
    suspend fun restore(id: String)

    @Query("UPDATE retailers SET onboardingStatus = :status, rejectReason = :rejectReason WHERE id = :id")
    suspend fun setOnboardingStatus(id: String, status: String, rejectReason: String?)

    @Query("UPDATE retailers SET isActive = :isActive, businessStatus = :businessStatus WHERE id = :id")
    suspend fun setActiveAndStatus(id: String, isActive: Boolean, businessStatus: String)

    @Query("UPDATE retailers SET officerId = :officerId, officerName = :officerName WHERE id = :id")
    suspend fun assignOfficer(id: String, officerId: String, officerName: String)

    @Query("UPDATE retailers SET routeId = :routeId WHERE id = :id")
    suspend fun assignRoute(id: String, routeId: String)

    @Query("UPDATE retailers SET businessStatus = :status, statusReason = :reason, isActive = :isActive WHERE id = :id")
    suspend fun setBusinessStatus(id: String, status: String, reason: String, isActive: Boolean)

    @Query("UPDATE retailers SET creditHold = :hold, creditHoldReason = :reason WHERE id = :id")
    suspend fun setCreditHold(id: String, hold: Boolean, reason: String?)
}

@Dao
interface RoleDefinitionDao {
    @Query("SELECT * FROM role_definitions")
    fun getAll(): Flow<List<RoleDefinitionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(roles: List<RoleDefinitionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(role: RoleDefinitionEntity)

    @Query("DELETE FROM role_definitions WHERE role = :roleKey")
    suspend fun deleteByKey(roleKey: String)
}

@Dao
interface FieldEmployeeRouteDao {
    @Query("SELECT * FROM field_employee_routes")
    fun getAll(): Flow<List<FieldEmployeeRouteEntity>>

    @Query("SELECT * FROM field_employee_routes WHERE employeeId = :employeeId AND dateEpochDay = :dateEpochDay LIMIT 1")
    suspend fun getForEmployeeAndDate(employeeId: String, dateEpochDay: Long): FieldEmployeeRouteEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(routes: List<FieldEmployeeRouteEntity>)

    @Query("SELECT COUNT(*) FROM field_employee_routes")
    suspend fun count(): Int
}

@Dao
interface EngagementCampaignDao {
    @Query("SELECT * FROM engagement_campaigns")
    fun getAll(): Flow<List<EngagementCampaignEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(campaign: EngagementCampaignEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(campaigns: List<EngagementCampaignEntity>)
}

@Dao
interface PayrollDao {
    @Query("SELECT * FROM payroll_lines")
    fun getAll(): Flow<List<PayrollLineEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(lines: List<PayrollLineEntity>)

    @Query("SELECT COUNT(*) FROM payroll_lines")
    suspend fun count(): Int

    @Query("UPDATE payroll_lines SET unapprovedAbsenceDays = :days WHERE employeeId = :employeeId")
    suspend fun updateAbsenceDays(employeeId: String, days: Int)

    @Query("UPDATE payroll_lines SET overtimeMinutes = :overtimeMinutes, overtimePay = :overtimePay, attendanceDaysPresent = :daysPresent, attendanceDaysAbsent = :daysAbsent WHERE employeeId = :employeeId")
    suspend fun updateAttendanceStats(employeeId: String, overtimeMinutes: Int, overtimePay: Double, daysPresent: Int, daysAbsent: Int)
}

@Dao
interface SalesOrderDao {
    @Query("SELECT * FROM sales_orders WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<SalesOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(order: SalesOrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(orders: List<SalesOrderEntity>)

    @Query("UPDATE sales_orders SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("UPDATE sales_orders SET status = :status, approvedBy = :approvedBy, approvedAtEpochMillis = :approvedAt WHERE id = :id")
    suspend fun approve(id: String, status: String, approvedBy: String, approvedAt: Long)

    @Query("UPDATE sales_orders SET status = :status, deliveredQtyRaw = :deliveredQtyRaw WHERE id = :id")
    suspend fun updateDelivery(id: String, status: String, deliveredQtyRaw: String)

    @Query("UPDATE sales_orders SET status = :status, convertedToInvoiceId = :invoiceId WHERE id = :id")
    suspend fun markInvoiced(id: String, status: String, invoiceId: String)
}

@Dao
interface InvoiceDao {
    // v113-342 — real hard delete, for Recycle's permanent-delete action.
    @Query("DELETE FROM invoices WHERE id = :id")
    suspend fun purgeInvoice(id: String)

    @Query("SELECT * FROM invoices WHERE type = 'VOICE' AND isDeleted = 0")
    fun getAllVoice(): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM invoices WHERE type = 'SALES' AND isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAllSales(): Flow<List<InvoiceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(invoice: InvoiceEntity)

    @Query("UPDATE invoices SET paidAmount = :paidAmount, status = :status WHERE id = :invoiceId")
    suspend fun updatePaidAmountAndStatus(invoiceId: String, paidAmount: Double, status: String)

    @Query("UPDATE invoices SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(invoices: List<InvoiceEntity>)

    @Update
    suspend fun update(invoice: InvoiceEntity)

    @Query("SELECT COUNT(*) FROM invoices WHERE type = :type")
    suspend fun countByType(type: String): Int

    @Query("UPDATE invoices SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)

    @Query("UPDATE invoices SET isDeleted = 0, deletedAtEpochMillis = NULL, deletedBy = NULL WHERE id = :id")
    suspend fun restore(id: String)
}

@Dao
interface PaymentProofDao {
    @Query("SELECT * FROM payment_proofs")
    fun getAll(): Flow<List<PaymentProofEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(payments: List<PaymentProofEntity>)

    @Query("UPDATE payment_proofs SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("SELECT COUNT(*) FROM payment_proofs")
    suspend fun count(): Int

    /** v113-373 — the one seeded demo payment proof. */
    @Query("DELETE FROM payment_proofs WHERE id = 'PMT-1'")
    suspend fun deleteDemoSeeded()
}

@Dao
interface RawMaterialLotDao {
    @Query("SELECT * FROM raw_material_lots")
    fun getAll(): Flow<List<RawMaterialLotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(lots: List<RawMaterialLotEntity>)

    @Query("SELECT COUNT(*) FROM raw_material_lots")
    suspend fun count(): Int
}

@Dao
interface ProductionBatchDao {
    @Query("SELECT * FROM production_batches")
    fun getAll(): Flow<List<ProductionBatchEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(batches: List<ProductionBatchEntity>)

    @Query("UPDATE production_batches SET gatepassReceived = 1 WHERE id = :id")
    suspend fun receiveGatepass(id: String)

    @Query("SELECT COUNT(*) FROM production_batches")
    suspend fun count(): Int
}

@Dao
interface PrescriptionCardDao {
    @Query("SELECT * FROM prescription_cards")
    fun getAll(): Flow<List<PrescriptionCardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(cards: List<PrescriptionCardEntity>)

    @Query("SELECT COUNT(*) FROM prescription_cards")
    suspend fun count(): Int
}

@Dao
interface BoardroomQueryDao {
    @Query("SELECT * FROM boardroom_queries ORDER BY askedAtEpochMillis ASC")
    fun getAll(): Flow<List<BoardroomQueryEntity>>

    @Insert
    suspend fun insert(query: BoardroomQueryEntity)
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<TaskItemEntity>>

    @Query("SELECT * FROM tasks WHERE isDeleted = 1 ORDER BY createdAtEpochMillis DESC")
    fun getDeleted(): Flow<List<TaskItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: TaskItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(tasks: List<TaskItemEntity>)

    @Query("UPDATE tasks SET done = :done WHERE id = :id")
    suspend fun setDone(id: String, done: Boolean)

    @Query("UPDATE tasks SET status = :status, done = :done WHERE id = :id")
    suspend fun setStatus(id: String, status: String, done: Boolean)

    @Query("SELECT * FROM tasks WHERE parentTaskId = :parentId AND isDeleted = 0")
    fun getSubTasks(parentId: String): Flow<List<TaskItemEntity>>

    @Query("UPDATE tasks SET isDeleted = 1, deletedAtEpochMillis = :deletedAt, deletedBy = :deletedBy WHERE id = :id")
    suspend fun softDelete(id: String, deletedAt: Long, deletedBy: String)

    @Query("UPDATE tasks SET isDeleted = 0, deletedAtEpochMillis = NULL, deletedBy = NULL WHERE id = :id")
    suspend fun restore(id: String)
}

@Dao
interface ApprovalDao {
    @Query("SELECT * FROM approval_requests ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<ApprovalRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(request: ApprovalRequestEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(requests: List<ApprovalRequestEntity>)

    @Query("UPDATE approval_requests SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("UPDATE approval_requests SET level = :level WHERE id = :id")
    suspend fun setLevel(id: String, level: Int)

    @Query("UPDATE approval_requests SET assignedToEmployeeId = :employeeId WHERE id = :id")
    suspend fun setAssignedTo(id: String, employeeId: String?)

    @Query("UPDATE approval_requests SET escalated = :escalated WHERE id = :id")
    suspend fun setEscalated(id: String, escalated: Boolean)

    @Query("SELECT COUNT(*) FROM approval_requests")
    suspend fun count(): Int

    /** v113-373 — the one seeded demo approval request. */
    @Query("DELETE FROM approval_requests WHERE id = 'APR-1'")
    suspend fun deleteDemoSeeded()
}

@Dao
interface CourierDao {
    @Query("SELECT * FROM courier_partners")
    fun getAll(): Flow<List<CourierPartnerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(couriers: List<CourierPartnerEntity>)

    @Query("SELECT COUNT(*) FROM courier_partners")
    suspend fun count(): Int
}

@Dao
interface ShipmentDao {
    @Query("SELECT * FROM shipments")
    fun getAll(): Flow<List<ShipmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(shipment: ShipmentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(shipments: List<ShipmentEntity>)

    @Query("UPDATE shipments SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)
}

@Dao
interface LedgerDao {
    @Query("SELECT * FROM ledger_entries ORDER BY recordedAtEpochMillis DESC")
    fun getAll(): Flow<List<LedgerEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: LedgerEntryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entries: List<LedgerEntryEntity>)

    @Query("SELECT COUNT(*) FROM ledger_entries")
    suspend fun count(): Int

    /** v113-373 — the five seeded demo ledger lines, by id. */
    @Query("DELETE FROM ledger_entries WHERE id LIKE 'LEDGER-%'")
    suspend fun deleteDemoSeeded()
}

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance_records WHERE employeeId = :employeeId AND dateEpochDay = :dateEpochDay LIMIT 1")
    suspend fun getForDay(employeeId: String, dateEpochDay: Long): AttendanceRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(record: AttendanceRecordEntity)

    @Query("UPDATE attendance_records SET shiftType = :shiftType WHERE employeeId = :employeeId AND dateEpochDay = :dateEpochDay")
    suspend fun assignShift(employeeId: String, dateEpochDay: Long, shiftType: String)

    @Query("SELECT * FROM attendance_records WHERE employeeId = :employeeId ORDER BY dateEpochDay DESC")
    fun getAllForEmployee(employeeId: String): Flow<List<AttendanceRecordEntity>>

    @Query("SELECT COUNT(*) FROM attendance_records WHERE employeeId = :employeeId AND checkedIn = 0 AND isOnLeave = 0")
    suspend fun countAbsences(employeeId: String): Int

    @Query("SELECT COUNT(*) FROM attendance_records WHERE employeeId = :employeeId AND checkedIn = 1")
    suspend fun countPresentDays(employeeId: String): Int

    @Query("SELECT COALESCE(SUM(overtimeMinutes), 0) FROM attendance_records WHERE employeeId = :employeeId AND checkedIn = 1")
    suspend fun sumOvertimeMinutes(employeeId: String): Int

    @Query("SELECT COUNT(*) FROM attendance_records WHERE dateEpochDay = :dateEpochDay AND checkedIn = 1")
    suspend fun countPresentForDay(dateEpochDay: Long): Int

    // v86, Module 10 — Attendance Correction. Note: this table's PrimaryKey
    // is the autoGenerate rowId, NOT (employeeId, dateEpochDay) — a naive
    // upsert() with a freshly-built entity would INSERT a duplicate row
    // instead of correcting the existing one. This targeted UPDATE avoids
    // that trap entirely.
    @Query("UPDATE attendance_records SET checkedIn = :checkedIn WHERE employeeId = :employeeId AND dateEpochDay = :dateEpochDay")
    suspend fun correctCheckedIn(employeeId: String, dateEpochDay: Long, checkedIn: Boolean)
}

@Dao
interface AuditLogDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: AuditLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entries: List<AuditLogEntity>)

    @Query("SELECT * FROM audit_log ORDER BY timestampEpochMillis DESC")
    fun getAll(): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM audit_log WHERE entityType = :entityType AND entityId = :entityId ORDER BY timestampEpochMillis DESC")
    fun getForEntity(entityType: String, entityId: String): Flow<List<AuditLogEntity>>
}

@Dao
interface BackupDao {
    @Query("SELECT * FROM backup_metadata ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<BackupMetadataEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: BackupMetadataEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<BackupMetadataEntity>)
}

@Dao
interface QuotationDao {
    @Query("SELECT * FROM quotations WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<QuotationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(quotation: QuotationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(quotations: List<QuotationEntity>)

    @Query("UPDATE quotations SET status = :status, convertedInvoiceId = :invoiceId WHERE id = :id")
    suspend fun setStatus(id: String, status: String, invoiceId: String? = null)

    @Query("UPDATE quotations SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)

    @Query("SELECT COUNT(*) FROM quotations")
    suspend fun count(): Int
}

@Dao
interface DeliveryChallanDao {
    @Query("SELECT * FROM delivery_challans WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<DeliveryChallanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(challan: DeliveryChallanEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(challans: List<DeliveryChallanEntity>)

    @Query("UPDATE delivery_challans SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("UPDATE delivery_challans SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)

    @Query("SELECT COUNT(*) FROM delivery_challans")
    suspend fun count(): Int
}

@Dao
interface SalesReturnDao {
    @Query("SELECT * FROM sales_returns WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<SalesReturnEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(salesReturn: SalesReturnEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(returns: List<SalesReturnEntity>)

    @Query("UPDATE sales_returns SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("UPDATE sales_returns SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)

    @Query("SELECT COUNT(*) FROM sales_returns")
    suspend fun count(): Int
}

@Dao
interface PartyLedgerDao {
    @Query("SELECT * FROM party_ledger WHERE partyType = :partyType AND partyId = :partyId ORDER BY createdAtEpochMillis DESC")
    fun getForParty(partyType: String, partyId: String): Flow<List<PartyLedgerEntryEntity>>

    @Query("SELECT * FROM party_ledger ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<PartyLedgerEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: PartyLedgerEntryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entries: List<PartyLedgerEntryEntity>)
}

@Dao
interface PartyCollectionDao {
    @Query("SELECT * FROM party_collections ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<PartyCollectionEntity>>

    @Query("SELECT * FROM party_collections WHERE partyType = :partyType AND partyId = :partyId ORDER BY createdAtEpochMillis DESC")
    fun getForParty(partyType: String, partyId: String): Flow<List<PartyCollectionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(collection: PartyCollectionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(collections: List<PartyCollectionEntity>)

    @Query("UPDATE party_collections SET status = :status, verifiedBy = :verifiedBy, verifiedAtEpochMillis = :verifiedAt WHERE id = :id")
    suspend fun setStatus(id: String, status: String, verifiedBy: String?, verifiedAt: Long?)

    /** v113-369 — proofs still on a local file:// path, i.e. the Storage upload never landed. Swept at startup, same as pending attachments. */
    @Query("SELECT * FROM party_collections WHERE proofUri LIKE 'file:%'")
    suspend fun getPendingProofUpload(): List<PartyCollectionEntity>
}

@Dao
interface CustomerComplaintDao {
    @Query("SELECT * FROM customer_complaints WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<CustomerComplaintEntity>>

    @Query("SELECT * FROM customer_complaints WHERE dealerId = :dealerId AND isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getForDealer(dealerId: String): Flow<List<CustomerComplaintEntity>>

    // v113-75 — retailer side. partyType filters it apart from dealer complaints, which
    // all carry the pre-existing default 'DEALER' and an empty retailerId.
    @Query("SELECT * FROM customer_complaints WHERE retailerId = :retailerId AND partyType = 'RETAILER' AND isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getForRetailer(retailerId: String): Flow<List<CustomerComplaintEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(complaint: CustomerComplaintEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(complaints: List<CustomerComplaintEntity>)

    @Query("UPDATE customer_complaints SET status = :status, assignedEmployeeId = :assignedEmployeeId, assignedEmployeeName = :assignedEmployeeName WHERE id = :id")
    suspend fun assign(id: String, status: String, assignedEmployeeId: String, assignedEmployeeName: String)

    @Query("UPDATE customer_complaints SET status = :status, resolutionNote = :resolutionNote, resolvedAtEpochMillis = :resolvedAt WHERE id = :id")
    suspend fun resolve(id: String, status: String, resolutionNote: String, resolvedAt: Long)

    @Query("UPDATE customer_complaints SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)
}

@Dao
interface DiscountRuleDao {
    @Query("SELECT * FROM discount_rules WHERE isActive = 1")
    fun getAll(): Flow<List<DiscountRuleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(rule: DiscountRuleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(rules: List<DiscountRuleEntity>)
}

@Dao
interface SalesRouteDao {
    @Query("SELECT * FROM sales_routes WHERE isActive = 1")
    fun getAll(): Flow<List<SalesRouteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(route: SalesRouteEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(routes: List<SalesRouteEntity>)
}

@Dao
interface VisitLogDao {
    @Query("SELECT * FROM visit_logs ORDER BY checkInAtEpochMillis DESC")
    fun getAll(): Flow<List<VisitLogEntity>>

    @Query("SELECT * FROM visit_logs WHERE partyType = :partyType AND partyId = :partyId ORDER BY checkInAtEpochMillis DESC")
    fun getForParty(partyType: String, partyId: String): Flow<List<VisitLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(visit: VisitLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(visits: List<VisitLogEntity>)

    @Query("UPDATE visit_logs SET checkOutAtEpochMillis = :checkOutAt WHERE id = :id")
    suspend fun setCheckOut(id: String, checkOutAt: Long)

    /** v89, Foundation 3 — the real full checkout, storing everything Section 6 requires (was previously just a bare timestamp flip). */
    @Query(
        """
        UPDATE visit_logs SET checkOutAtEpochMillis = :checkOutAt, checkOutLat = :lat, checkOutLng = :lng,
        checkOutAccuracyMeters = :accuracyMeters, checkOutMockSuspected = :mockSuspected,
        checkOutDistanceFromRetailerMeters = :distanceMeters, verificationResult = :verificationResult, verificationScore = :score
        WHERE id = :id
        """,
    )
    suspend fun setFullCheckOut(id: String, checkOutAt: Long, lat: Double, lng: Double, accuracyMeters: Float?, mockSuspected: Boolean, distanceMeters: Double?, verificationResult: String, score: Int)

    @Query(
        """
        UPDATE visit_logs SET checkInAccuracyMeters = :accuracyMeters, checkInProvider = :provider,
        checkInMockSuspected = :mockSuspected, checkInDistanceFromRetailerMeters = :distanceMeters,
        deviceId = :deviceId, verificationResult = :verificationResult, verificationScore = :score, routeId = :routeId
        WHERE id = :id
        """,
    )
    suspend fun setCheckInVerification(id: String, accuracyMeters: Float?, provider: String?, mockSuspected: Boolean, distanceMeters: Double?, deviceId: String?, verificationResult: String, score: Int, routeId: String?)

    @Query("UPDATE visit_logs SET orderCreatedId = :orderId WHERE id = :id")
    suspend fun linkOrder(id: String, orderId: String)

    @Query("UPDATE visit_logs SET collectionCreatedId = :collectionId WHERE id = :id")
    suspend fun linkCollection(id: String, collectionId: String)

    @Query("UPDATE visit_logs SET complaintCreatedId = :complaintId WHERE id = :id")
    suspend fun linkComplaint(id: String, complaintId: String)

    @Query("UPDATE visit_logs SET notes = :notes WHERE id = :id")
    suspend fun setNotes(id: String, notes: String)

    @Query("SELECT * FROM visit_logs WHERE employeeId = :employeeId AND checkOutAtEpochMillis IS NULL LIMIT 1")
    suspend fun activeVisitForEmployee(employeeId: String): VisitLogEntity?
}

// ================= Module 5: Purchase Management =================

@Dao
interface SupplierDao {
    @Query("SELECT * FROM suppliers WHERE isDeleted = 0")
    fun getAll(): Flow<List<SupplierEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(supplier: SupplierEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(suppliers: List<SupplierEntity>)

    @Query("SELECT COUNT(*) FROM suppliers WHERE dedupKey = :dedupKey AND isDeleted = 0")
    suspend fun countByDedupKey(dedupKey: String): Int

    @Query("UPDATE suppliers SET dueBalance = dueBalance + :delta WHERE id = :id")
    suspend fun adjustDueBalance(id: String, delta: Double)

    @Query("UPDATE suppliers SET isDeleted = 1, deletedAtEpochMillis = :deletedAt, deletedBy = :deletedBy WHERE id = :id")
    suspend fun softDelete(id: String, deletedAt: Long, deletedBy: String)

    @Query("UPDATE suppliers SET isDeleted = 0, deletedAtEpochMillis = NULL, deletedBy = NULL WHERE id = :id")
    suspend fun restore(id: String)
}

@Dao
interface PurchaseRequestDao {
    @Query("SELECT * FROM purchase_requests WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<PurchaseRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(request: PurchaseRequestEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(requests: List<PurchaseRequestEntity>)

    @Query("UPDATE purchase_requests SET status = :status, approvedBy = :approvedBy, approvedAtEpochMillis = :approvedAt WHERE id = :id")
    suspend fun approve(id: String, status: String, approvedBy: String, approvedAt: Long)

    @Query("UPDATE purchase_requests SET status = :status, rejectReason = :reason WHERE id = :id")
    suspend fun reject(id: String, status: String, reason: String)

    @Query("UPDATE purchase_requests SET status = :status, convertedToPoId = :poId WHERE id = :id")
    suspend fun markConverted(id: String, status: String, poId: String)
}

@Dao
interface PurchaseOrderDao {
    @Query("SELECT * FROM purchase_orders WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<PurchaseOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(po: PurchaseOrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(pos: List<PurchaseOrderEntity>)

    @Query("UPDATE purchase_orders SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("SELECT COUNT(*) FROM purchase_orders")
    suspend fun count(): Int
}

@Dao
interface GoodsReceivedNoteDao {
    @Query("SELECT * FROM goods_received_notes WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<GoodsReceivedNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(grn: GoodsReceivedNoteEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(grns: List<GoodsReceivedNoteEntity>)
}

@Dao
interface PurchaseReturnDao {
    @Query("SELECT * FROM purchase_returns WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<PurchaseReturnEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(pr: PurchaseReturnEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(prs: List<PurchaseReturnEntity>)

    @Query("UPDATE purchase_returns SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)
}

// ================= Module 3: Inventory extras =================

@Dao
interface ProductCategoryDao {
    @Query("SELECT * FROM product_categories WHERE isActive = 1")
    fun getAll(): Flow<List<ProductCategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(category: ProductCategoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(categories: List<ProductCategoryEntity>)
}

@Dao
interface ProductBrandDao {
    @Query("SELECT * FROM product_brands WHERE isActive = 1")
    fun getAll(): Flow<List<ProductBrandEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(brand: ProductBrandEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(brands: List<ProductBrandEntity>)
}

@Dao
interface InventoryLotDao {
    @Query("SELECT * FROM inventory_lots WHERE productId = :productId AND warehouseId = :warehouseId AND qtyRemaining > 0 ORDER BY expiryDateEpochMillis ASC")
    suspend fun getLotsFefo(productId: String, warehouseId: String): List<InventoryLotEntity>

    @Query("SELECT * FROM inventory_lots WHERE qtyRemaining > 0")
    fun getAll(): Flow<List<InventoryLotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(lot: InventoryLotEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(lots: List<InventoryLotEntity>)

    @Query("UPDATE inventory_lots SET qtyRemaining = :qty WHERE id = :id")
    suspend fun setRemaining(id: String, qty: Double)
}

@Dao
interface DamageReportDao {
    @Query("SELECT * FROM damage_reports ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<DamageReportEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(report: DamageReportEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(reports: List<DamageReportEntity>)
}

@Dao
interface StockTransferDao {
    @Query("SELECT * FROM stock_transfers ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<StockTransferEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(transfer: StockTransferEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(transfers: List<StockTransferEntity>)
}

// ================= Module 2: Manufacturing & Production extras =================

@Dao
interface BillOfMaterialsDao {
    @Query("SELECT * FROM bill_of_materials WHERE isActive = 1")
    fun getAll(): Flow<List<BillOfMaterialsEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(bom: BillOfMaterialsEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(boms: List<BillOfMaterialsEntity>)
}

@Dao
interface ProductionOrderDao {
    @Query("SELECT * FROM production_orders ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<ProductionOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(order: ProductionOrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(orders: List<ProductionOrderEntity>)

    @Query("UPDATE production_orders SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)
}

@Dao
interface QualityCheckDao {
    @Query("SELECT * FROM quality_checks ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<QualityCheckEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(check: QualityCheckEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(checks: List<QualityCheckEntity>)
}

@Dao
interface ProductionLossDao {
    @Query("SELECT * FROM production_losses ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<ProductionLossEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(loss: ProductionLossEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(losses: List<ProductionLossEntity>)
}

@Dao
interface MachineLogDao {
    @Query("SELECT * FROM machine_logs ORDER BY recordedAtEpochMillis DESC")
    fun getAll(): Flow<List<MachineLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(log: MachineLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(logs: List<MachineLogEntity>)
}

@Dao
interface ChartOfAccountDao {
    @Query("SELECT * FROM chart_of_accounts WHERE isActive = 1 ORDER BY code ASC")
    fun getAll(): Flow<List<ChartOfAccountEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(account: ChartOfAccountEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(accounts: List<ChartOfAccountEntity>)

    @Query("SELECT COUNT(*) FROM chart_of_accounts")
    suspend fun count(): Int
}

@Entity(tableName = "closed_periods")
data class ClosedPeriodEntity(
    @PrimaryKey val yearMonth: String = "", // "2026-07" format
    val closedBy: String = "",
    val closedAtEpochMillis: Long = 0,
)

@Dao
interface ClosedPeriodDao {
    @Query("SELECT * FROM closed_periods")
    fun getAll(): Flow<List<ClosedPeriodEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(period: ClosedPeriodEntity)
}

@Dao
interface VoucherDao {
    @Query("SELECT * FROM vouchers WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<VoucherEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(voucher: VoucherEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(vouchers: List<VoucherEntity>)

    @Query("UPDATE vouchers SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)

    @Query("SELECT COUNT(*) FROM vouchers")
    suspend fun count(): Int
}

@Dao
interface LeadDao {
    @Query("SELECT * FROM leads WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<LeadEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(lead: LeadEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(leads: List<LeadEntity>)

    @Query("UPDATE leads SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("UPDATE leads SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)
}

@Dao
interface OpportunityDao {
    @Query("SELECT * FROM opportunities ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<OpportunityEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(opportunity: OpportunityEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(opportunities: List<OpportunityEntity>)

    @Query("UPDATE opportunities SET stage = :stage WHERE id = :id")
    suspend fun setStage(id: String, stage: String)
}

@Dao
interface CustomerSegmentDao {
    @Query("SELECT * FROM customer_segments")
    fun getAll(): Flow<List<CustomerSegmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(segment: CustomerSegmentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(segments: List<CustomerSegmentEntity>)
}

@Dao
interface CallLogDao {
    @Query("SELECT * FROM call_logs ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<CallLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(call: CallLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(calls: List<CallLogEntity>)
}

@Dao
interface MeetingLogDao {
    @Query("SELECT * FROM meeting_logs ORDER BY meetingDateEpochMillis DESC")
    fun getAll(): Flow<List<MeetingLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(meeting: MeetingLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(meetings: List<MeetingLogEntity>)
}

@Dao
interface FollowUpDao {
    @Query("SELECT * FROM follow_ups ORDER BY dueDateEpochMillis ASC")
    fun getAll(): Flow<List<FollowUpEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(followUp: FollowUpEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(followUps: List<FollowUpEntity>)

    @Query("UPDATE follow_ups SET done = :done WHERE id = :id")
    suspend fun setDone(id: String, done: Boolean)
}

@Dao
interface LeaveRequestDao {
    @Query("SELECT * FROM leave_requests ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<LeaveRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(leave: LeaveRequestEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(leaves: List<LeaveRequestEntity>)

    @Query("UPDATE leave_requests SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)
}

@Dao
interface EmployeeLifecycleEventDao {
    @Query("SELECT * FROM employee_lifecycle_events ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<EmployeeLifecycleEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(event: EmployeeLifecycleEventEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(events: List<EmployeeLifecycleEventEntity>)
}

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages WHERE channelId = :channelId ORDER BY createdAtEpochMillis ASC")
    fun getForChannel(channelId: String): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages ORDER BY createdAtEpochMillis ASC")
    fun getAll(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(message: ChatMessageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(messages: List<ChatMessageEntity>)
}

@Dao
interface AnnouncementDao {
    @Query("SELECT * FROM announcements WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<AnnouncementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(announcement: AnnouncementEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(announcements: List<AnnouncementEntity>)

    @Query("UPDATE announcements SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)
}

@Dao
interface CircularDao {
    @Query("SELECT * FROM circulars WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<CircularEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(circular: CircularEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(circulars: List<CircularEntity>)

    @Query("UPDATE circulars SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)
}

@Dao
interface VehicleDao {
    @Query("SELECT * FROM vehicles WHERE isActive = 1")
    fun getAll(): Flow<List<VehicleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(vehicle: VehicleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(vehicles: List<VehicleEntity>)
}

@Dao
interface VehicleLocationPingDao {
    @Query("SELECT * FROM vehicle_location_pings WHERE vehicleId = :vehicleId ORDER BY recordedAtEpochMillis DESC LIMIT 1")
    fun getLatestForVehicle(vehicleId: String): Flow<VehicleLocationPingEntity?>

    @Query("SELECT * FROM vehicle_location_pings ORDER BY recordedAtEpochMillis DESC")
    fun getAll(): Flow<List<VehicleLocationPingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(ping: VehicleLocationPingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(pings: List<VehicleLocationPingEntity>)
}

@Dao
interface AttachmentDao {
    @Query("SELECT * FROM attachments WHERE moduleReference = :moduleReference AND entityId = :entityId ORDER BY createdAtEpochMillis DESC")
    fun getForEntity(moduleReference: String, entityId: String): Flow<List<AttachmentEntity>>

    @Query("SELECT * FROM attachments ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<AttachmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(attachment: AttachmentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(attachments: List<AttachmentEntity>)

    @Query("DELETE FROM attachments WHERE id = :id")
    suspend fun delete(id: String)

    /**
     * v113-359 — attachments whose uri is still a local file:// path, i.e. the
     * Storage upload never succeeded. Read once at startup so a picture taken
     * offline is not stranded on the device forever (v113-350 made the save
     * local-first, which fixed the data loss but left retry to chance).
     */
    @Query("SELECT * FROM attachments WHERE uri LIKE 'file:%'")
    suspend fun getPendingUpload(): List<AttachmentEntity>
}

@Dao
interface NotificationEntryDao {
    @Query("SELECT * FROM notification_entries ORDER BY createdAtEpochMillis DESC LIMIT 100")
    fun getAll(): Flow<List<NotificationEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: NotificationEntryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entries: List<NotificationEntryEntity>)

    @Query("UPDATE notification_entries SET isRead = 1 WHERE id = :id")
    suspend fun markRead(id: String)
}

/** Product-wise dealer stock. Every mutation is a full row upsert, keyed by (dealerId,
 *  productId), so a "how much of X does dealer Y hold" question is always one row. */
@Dao
interface DealerStockLineDao {
    @Query("SELECT * FROM dealer_stock_lines WHERE dealerId = :dealerId ORDER BY qty DESC")
    fun observeForDealer(dealerId: String): Flow<List<DealerStockLineEntity>>

    // v113-249 — the person's own direct request: a real, live "which
    // products are short at which dealers" alert needs to check across
    // ALL dealers at once, not one at a time — the existing
    // observeForDealer is scoped to a single dealer by design (that's
    // what the Stock tab itself needs) and genuinely can't answer this.
    @Query("SELECT * FROM dealer_stock_lines")
    fun observeAll(): Flow<List<DealerStockLineEntity>>

    @Query("SELECT * FROM dealer_stock_lines WHERE dealerId = :dealerId AND productId = :productId LIMIT 1")
    suspend fun find(dealerId: String, productId: String): DealerStockLineEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(line: DealerStockLineEntity)
}

/** v113-75 — retailer-side mirror of DealerStockLineDao, same shape and same reasoning. */
@Dao
interface RetailerStockLineDao {
    @Query("SELECT * FROM retailer_stock_lines WHERE retailerId = :retailerId ORDER BY qty DESC")
    fun observeForRetailer(retailerId: String): Flow<List<RetailerStockLineEntity>>

    @Query("SELECT * FROM retailer_stock_lines WHERE retailerId = :retailerId AND productId = :productId LIMIT 1")
    suspend fun find(retailerId: String, productId: String): RetailerStockLineEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(line: RetailerStockLineEntity)
}
