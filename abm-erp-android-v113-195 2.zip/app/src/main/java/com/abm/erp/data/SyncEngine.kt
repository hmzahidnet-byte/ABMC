package com.abm.erp.data
import android.content.Context
import com.abm.erp.location.GeoLock
import com.abm.erp.location.LocationVerification
import com.abm.erp.executive.ExecutiveIntelligence
import com.abm.erp.data.room.AppDatabase
import com.abm.erp.data.room.ApprovalRequestEntity
import com.abm.erp.data.room.AttendanceRecordEntity
import com.abm.erp.data.room.BoardroomQueryEntity
import com.abm.erp.data.room.Converters
import com.abm.erp.data.room.CourierPartnerEntity
import com.abm.erp.data.room.DealerEntity
import com.abm.erp.data.room.EngagementCampaignEntity
import com.abm.erp.data.room.FieldEmployeeRouteEntity
import com.abm.erp.data.room.AuditLogEntity
import com.abm.erp.data.room.LedgerEntryEntity
import com.abm.erp.data.room.PaymentProofEntity
import com.abm.erp.data.room.PayrollLineEntity
import com.abm.erp.data.room.ProductionBatchEntity
import com.abm.erp.data.room.RawMaterialLotEntity
import com.abm.erp.data.room.RetailOrderEntity
import com.abm.erp.data.room.InvoiceEntity
import com.abm.erp.data.room.ShipmentEntity
import com.abm.erp.data.room.TaskItemEntity
import com.abm.erp.data.room.QuotationEntity
import com.abm.erp.data.room.DeliveryChallanEntity
import com.abm.erp.data.room.SalesReturnEntity
import com.abm.erp.data.room.PartyLedgerEntryEntity
import com.abm.erp.data.room.PartyCollectionEntity
import com.abm.erp.data.room.DiscountRuleEntity
import com.abm.erp.data.room.SalesRouteEntity
import com.abm.erp.data.room.VisitLogEntity
import com.abm.erp.data.room.AttachmentEntity
import com.abm.erp.data.room.BillOfMaterialsEntity
import com.abm.erp.data.room.EmployeeLifecycleEventEntity
import com.abm.erp.data.room.LeaveRequestEntity
import com.abm.erp.data.room.MachineLogEntity
import com.abm.erp.data.room.NotificationEntryEntity
import com.abm.erp.data.room.ProductionLossEntity
import com.abm.erp.data.room.ProductionOrderEntity
import com.abm.erp.data.room.QualityCheckEntity
import com.abm.erp.data.room.RetailerEntity
import com.abm.erp.data.room.RoleDefinitionEntity
import com.abm.erp.data.room.TerritoryEntity
import com.abm.erp.data.room.VehicleEntity
import com.abm.erp.data.room.VehicleLocationPingEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import androidx.room.withTransaction
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.runBlocking
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneOffset
// ============================================================================
// v113-88 Phase 7 — THE FIRESTORE SYNC ENGINE, moved out of MockRepository.kt.
//
// This was the piece three earlier batches deferred as "real re-architecture".
// What made it finally safe was proving, by script, that the cluster is CLOSED:
// all 44 `xListenerReg` registration fields are referenced ONLY inside the 49
// `listenXRemote()` functions plus startCrossDeviceSync/forceResync — zero
// references anywhere else in the object (the check ran before a single line
// moved; `liveLocationsListener` matched the earlier loose grep only because
// its TYPE contains "ListenerReg[istration]" — it belongs to the live-tracking
// feature's separate lifecycle and stays behind untouched).
//
// Mechanics, same as Phases 2-6 with one addition: the registration fields
// become TOP-LEVEL PRIVATE VARS in this file (file-private state, the same
// pattern ApprovalsEngine used for its SLA-dedup map) — legal because the
// closure proof above guarantees nobody else touches them. Extension functions
// keep every call site identical (`MockRepository.startCrossDeviceSync(...)`
// in LoginScreen / SyncStatusCenterScreen / ABMApplication is textually
// unchanged). `syncCompanyId` could NOT move — two push-payload builders in
// the object read it — so it was widened private→internal and stays there.
// Listener BODIES are byte-identical: server-wins upserts into Room, the same
// AppLog warnings, the same re-attach guards.
// ============================================================================

/** Manual "Retry" entry point (Sync Status Center) — startCrossDeviceSync no-ops once a company is
 * already syncing (companyId == syncCompanyId), which is correct for automatic/repeated calls but means
 * a person tapping Retry after a connectivity blip previously triggered nothing at all. Resetting the
 * guard first makes the retry genuinely re-attach every listener, same real effect SyncRetryWorker's
 * periodic run already has. */
fun MockRepository.forceResync(companyId: String) {
    syncCompanyId = null
    startCrossDeviceSync(companyId)
    // Flush any QR scan logs recorded while offline. Scan evidence is the one thing
    // that must not be lost to a connectivity gap.
    launchInRepoScope { QrRegistry.syncPending() }
}

private var ordersListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var dealersListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var attendanceListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var payrollListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var salesInvoicesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var ledgerListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var auditLogListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var campaignsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var tasksListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var approvalsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var shipmentsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var couriersListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var retailersListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var territoriesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var roleDefinitionsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

/** Call once the company code is known (mirrors FirebaseSync.startCompanyScopedListeners). Safe to call again; re-attaches nothing if it's the same company. */
fun MockRepository.startCrossDeviceSync(companyId: String) {
    if (!CompanyContext.validateAndRecord(companyId)) {
        android.util.Log.w("MockRepository", "startCrossDeviceSync refused invalid companyId '$companyId' — sync not started")
        return
    }
    if (companyId == syncCompanyId) return
    syncCompanyId = companyId
    listenRetailOrdersRemote()
    listenDealersRemote()
    listenAttendanceRemote()
    listenPayrollRemote()
    listenSalesInvoicesRemote()
    listenSalesOrdersRemote()
    listenLedgerRemote()
    listenCampaignsRemote()
    listenTasksRemote()
    listenApprovalsRemote()
    listenShipmentsRemote()
    listenCouriersRemote()
    listenAuditLogRemote()
    listenMarketSummaryRemote()
    listenRetailersRemote()
    listenEmployeeProfilesRemote()
    listenTransferRequestsRemote()
    listenRetailerLocationHistoryRemote()
    listenEmployeeLocationSnapshotsRemote()
    listenLocationAlertsRemote()
    listenTrustedDevicesRemote()
    listenSecurityEventsRemote()
    listenGeoOverridesRemote()
    listenExecutiveExceptionsRemote()
    listenManagementActionsRemote()
    listenDecisionQueryAuditRemote()
    listenCompanyMarketsRemote()
    listenDelegationsRemote()
    listenTerritoriesRemote()
    listenRoleDefinitionsRemote()
    listenQuotationsRemote()
    listenDeliveryChallansRemote()
    listenSalesReturnsRemote()
    listenPartyLedgerRemote()
    listenPartyCollectionsRemote()
    listenCustomerComplaintsRemote()
    listenDiscountRulesRemote()
    listenSalesRoutesRemote()
    listenVisitLogsRemote()
    listenLeaveRequestsRemote()
    listenLifecycleEventsRemote()
    listenVehiclesRemote()
    listenVehiclePingsRemote()
    listenNotificationsRemote()
    listenBomRemote()
    listenProductionOrdersRemote()
    listenQualityChecksRemote()
    listenProductionLossesRemote()
    listenMachineLogsRemote()
}

private fun MockRepository.listenBomRemote() {
    qrSyncCollection("billOfMaterials").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "billOfMaterials sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.BillOfMaterialsEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.billOfMaterialsDao().upsertAll(list) }
    }
}

private fun MockRepository.listenProductionOrdersRemote() {
    qrSyncCollection("productionOrders").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "productionOrders sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.ProductionOrderEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.productionOrderDao().upsertAll(list) }
    }
}

private fun MockRepository.listenQualityChecksRemote() {
    qrSyncCollection("qualityChecks").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "qualityChecks sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.QualityCheckEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.qualityCheckDao().upsertAll(list) }
    }
}

private fun MockRepository.listenProductionLossesRemote() {
    qrSyncCollection("productionLosses").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "productionLosses sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.ProductionLossEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.productionLossDao().upsertAll(list) }
    }
}

private fun MockRepository.listenMachineLogsRemote() {
    qrSyncCollection("machineLogs").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "machineLogs sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.MachineLogEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.machineLogDao().upsertAll(list) }
    }
}

private fun MockRepository.listenRetailOrdersRemote() {
    ordersListenerReg?.remove()
    ordersListenerReg = qrSyncCollection("retailOrders").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "retailOrders sync listener error", err); return@addSnapshotListener }
        snap?.documentChanges?.forEach { change ->
            val e = change.document.toObject(RetailOrderEntity::class.java)
            launchInRepoScope { database.retailOrderDao().upsert(e) }
        }
    }
}

private fun MockRepository.listenDealersRemote() {
    dealersListenerReg?.remove()
    dealersListenerReg = qrSyncCollection("dealers").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "dealers sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(DealerEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.dealerDao().upsertAll(list) }
    }
}

private var employeeProfilesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

// v113-195 — TEMPORARY diagnostic: records the last Firestore snapshot
// received for EMP-CHAIR specifically (if any), so LoginScreen's debug
// panel can directly confirm or rule out whether this "server-wins"
// listener is what's been reverting the local bootstrap-account fixes,
// instead of continuing to theorize from behavior alone. Remove alongside
// the rest of the temporary login diagnostics once the real cause is
// confirmed fixed.
var lastRemoteEmpChairSnapshot: String? = null

private fun MockRepository.listenEmployeeProfilesRemote() {
    employeeProfilesListenerReg?.remove()
    employeeProfilesListenerReg = qrSyncCollection("employeeProfiles").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "employeeProfiles sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.EmployeeProfileEntity::class.java) }.orEmpty()
        list.firstOrNull { it.id == "EMP-CHAIR" }?.let {
            lastRemoteEmpChairSnapshot = "mobile='${it.mobile}' onboarding=${it.onboardingStatus} receivedAtMillis=${System.currentTimeMillis()}"
        }
        if (list.isNotEmpty()) launchInRepoScope { database.employeeProfileDao().upsertAll(list) }
    }
}

private var transferRequestsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenTransferRequestsRemote() {
    transferRequestsListenerReg?.remove()
    transferRequestsListenerReg = qrSyncCollection("transferRequests").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "transferRequests sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.TransferRequestEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.transferRequestDao().upsertAll(list) }
    }
}

private var retailerLocationHistoryListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenRetailerLocationHistoryRemote() {
    retailerLocationHistoryListenerReg?.remove()
    retailerLocationHistoryListenerReg = qrSyncCollection("retailerLocationHistory").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "retailerLocationHistory sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.RetailerLocationHistoryEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.retailerLocationHistoryDao().upsertAll(list) }
    }
}

private var employeeLocationSnapshotsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenEmployeeLocationSnapshotsRemote() {
    employeeLocationSnapshotsListenerReg?.remove()
    employeeLocationSnapshotsListenerReg = qrSyncCollection("employeeLocationSnapshots").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "employeeLocationSnapshots sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.EmployeeLocationSnapshotEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.employeeLocationSnapshotDao().upsertAll(list) }
    }
}

private var locationAlertsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenLocationAlertsRemote() {
    locationAlertsListenerReg?.remove()
    locationAlertsListenerReg = qrSyncCollection("locationAlerts").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "locationAlerts sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.LocationAlertEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.locationAlertDao().upsertAll(list) }
    }
}

private var trustedDevicesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenTrustedDevicesRemote() {
    trustedDevicesListenerReg?.remove()
    trustedDevicesListenerReg = qrSyncCollection("trustedDevices").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "trustedDevices sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.TrustedDeviceEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.trustedDeviceDao().upsertAll(list) }
    }
}

private var securityEventsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenSecurityEventsRemote() {
    securityEventsListenerReg?.remove()
    securityEventsListenerReg = qrSyncCollection("securityEvents").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "securityEvents sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.SecurityEventEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.securityEventDao().upsertAll(list) }
    }
}

private var geoOverridesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenGeoOverridesRemote() {
    geoOverridesListenerReg?.remove()
    geoOverridesListenerReg = qrSyncCollection("geoOverrides").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "geoOverrides sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.GeoOverrideEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.geoOverrideDao().upsertAll(list) }
    }
}

private var executiveExceptionsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenExecutiveExceptionsRemote() {
    executiveExceptionsListenerReg?.remove()
    executiveExceptionsListenerReg = qrSyncCollection("executiveExceptions").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "executiveExceptions sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.ExecutiveExceptionEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.executiveExceptionDao().upsertAll(list) }
    }
}

private var managementActionsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenManagementActionsRemote() {
    managementActionsListenerReg?.remove()
    managementActionsListenerReg = qrSyncCollection("managementActions").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "managementActions sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.ManagementActionEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.managementActionDao().upsertAll(list) }
    }
}

private var decisionQueryAuditListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenDecisionQueryAuditRemote() {
    decisionQueryAuditListenerReg?.remove()
    decisionQueryAuditListenerReg = qrSyncCollection("decisionQueryAudit").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "decisionQueryAudit sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.DecisionQueryAuditEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.decisionQueryAuditDao().upsertAll(list) }
    }
}

private var companyMarketsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenCompanyMarketsRemote() {
    companyMarketsListenerReg?.remove()
    companyMarketsListenerReg = qrSyncCollection("companyMarkets").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "companyMarkets sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.CompanyMarketEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.companyMarketDao().upsertAll(list) }
    }
}

private var delegationsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenDelegationsRemote() {
    delegationsListenerReg?.remove()
    delegationsListenerReg = qrSyncCollection("delegations").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "delegations sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.DelegationEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.delegationDao().upsertAll(list) }
    }
}

// internal, not private: the object's own refreshRetailers() delegates here from another file.
internal fun MockRepository.listenRetailersRemote() {
    retailersListenerReg?.remove()
    retailersListenerReg = qrSyncCollection("retailers").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "retailers sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.RetailerEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { list.forEach { database.retailerDao().upsert(it) } }
    }
}

private fun MockRepository.listenTerritoriesRemote() {
    territoriesListenerReg?.remove()
    territoriesListenerReg = qrSyncCollection("territories").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "territories sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.TerritoryEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.territoryDao().upsertAll(list) }
    }
}

private fun MockRepository.listenRoleDefinitionsRemote() {
    roleDefinitionsListenerReg?.remove()
    roleDefinitionsListenerReg = qrSyncCollection("roleDefinitions").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "roleDefinitions sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.RoleDefinitionEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.roleDefinitionDao().upsertAll(list) }
    }
}

private var quotationsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var deliveryChallansListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var salesReturnsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var partyLedgerListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var partyCollectionsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var discountRulesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var salesRoutesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var visitLogsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenQuotationsRemote() {
    quotationsListenerReg?.remove()
    quotationsListenerReg = qrSyncCollection("quotations").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "quotations sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(QuotationEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.quotationDao().upsertAll(list) }
    }
}

private fun MockRepository.listenDeliveryChallansRemote() {
    deliveryChallansListenerReg?.remove()
    deliveryChallansListenerReg = qrSyncCollection("deliveryChallans").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "deliveryChallans sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(DeliveryChallanEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.deliveryChallanDao().upsertAll(list) }
    }
}

private fun MockRepository.listenSalesReturnsRemote() {
    salesReturnsListenerReg?.remove()
    salesReturnsListenerReg = qrSyncCollection("salesReturns").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "salesReturns sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(SalesReturnEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.salesReturnDao().upsertAll(list) }
    }
}

private fun MockRepository.listenPartyLedgerRemote() {
    partyLedgerListenerReg?.remove()
    partyLedgerListenerReg = qrSyncCollection("partyLedger").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "partyLedger sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(PartyLedgerEntryEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.partyLedgerDao().upsertAll(list) }
    }
}

private fun MockRepository.listenPartyCollectionsRemote() {
    partyCollectionsListenerReg?.remove()
    partyCollectionsListenerReg = qrSyncCollection("partyCollections").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "partyCollections sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(PartyCollectionEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.partyCollectionDao().upsertAll(list) }
    }
}

private var customerComplaintsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenCustomerComplaintsRemote() {
    customerComplaintsListenerReg?.remove()
    customerComplaintsListenerReg = qrSyncCollection("customerComplaints").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "customerComplaints sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.CustomerComplaintEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.customerComplaintDao().upsertAll(list) }
    }
}

private fun MockRepository.listenDiscountRulesRemote() {
    discountRulesListenerReg?.remove()
    discountRulesListenerReg = qrSyncCollection("discountRules").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "discountRules sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(DiscountRuleEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.discountRuleDao().upsertAll(list) }
    }
}

private fun MockRepository.listenSalesRoutesRemote() {
    salesRoutesListenerReg?.remove()
    salesRoutesListenerReg = qrSyncCollection("salesRoutes").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "salesRoutes sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(SalesRouteEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.salesRouteDao().upsertAll(list) }
    }
}

private fun MockRepository.listenVisitLogsRemote() {
    visitLogsListenerReg?.remove()
    visitLogsListenerReg = qrSyncCollection("visitLogs").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "visitLogs sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(VisitLogEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.visitLogDao().upsertAll(list) }
    }
}

private var leaveRequestsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var lifecycleEventsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenLeaveRequestsRemote() {
    leaveRequestsListenerReg?.remove()
    leaveRequestsListenerReg = qrSyncCollection("leaveRequests").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "leaveRequests sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.LeaveRequestEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.leaveRequestDao().upsertAll(list) }
    }
}

private fun MockRepository.listenLifecycleEventsRemote() {
    lifecycleEventsListenerReg?.remove()
    lifecycleEventsListenerReg = qrSyncCollection("employeeLifecycleEvents").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "employeeLifecycleEvents sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.EmployeeLifecycleEventEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.employeeLifecycleEventDao().upsertAll(list) }
    }
}

private var vehiclesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private var vehiclePingsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenVehiclesRemote() {
    vehiclesListenerReg?.remove()
    vehiclesListenerReg = qrSyncCollection("vehicles").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "vehicles sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.VehicleEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.vehicleDao().upsertAll(list) }
    }
}

private fun MockRepository.listenVehiclePingsRemote() {
    vehiclePingsListenerReg?.remove()
    vehiclePingsListenerReg = qrSyncCollection("vehicleLocationPings").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "vehicleLocationPings sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.VehicleLocationPingEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.vehicleLocationPingDao().upsertAll(list) }
    }
}

private fun MockRepository.listenAttendanceRemote() {
    attendanceListenerReg?.remove()
    attendanceListenerReg = qrSyncCollection("attendance").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "attendance sync listener error", err); return@addSnapshotListener }
        snap?.documentChanges?.forEach { change ->
            val e = change.document.toObject(AttendanceRecordEntity::class.java)
            launchInRepoScope { database.attendanceDao().upsert(e) }
        }
    }
}

private fun MockRepository.listenPayrollRemote() {
    payrollListenerReg?.remove()
    payrollListenerReg = qrSyncCollection("payroll").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "payroll sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(PayrollLineEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.payrollDao().upsertAll(list) }
    }
}

private fun MockRepository.listenSalesInvoicesRemote() {
    salesInvoicesListenerReg?.remove()
    salesInvoicesListenerReg = qrSyncCollection("salesInvoices").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "salesInvoices sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(InvoiceEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.invoiceDao().upsertAll(list) }
    }
}

private var salesOrdersListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenSalesOrdersRemote() {
    salesOrdersListenerReg?.remove()
    salesOrdersListenerReg = qrSyncCollection("salesOrders").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "salesOrders sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.SalesOrderEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.salesOrderDao().upsertAll(list) }
    }
}

private fun MockRepository.listenLedgerRemote() {
    ledgerListenerReg?.remove()
    ledgerListenerReg = qrSyncCollection("ledger").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "ledger sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(LedgerEntryEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.ledgerDao().upsertAll(list) }
    }
}

private fun MockRepository.listenCampaignsRemote() {
    campaignsListenerReg?.remove()
    campaignsListenerReg = qrSyncCollection("campaigns").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "campaigns sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(EngagementCampaignEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.engagementCampaignDao().upsertAll(list) }
    }
}

private fun MockRepository.listenTasksRemote() {
    tasksListenerReg?.remove()
    tasksListenerReg = qrSyncCollection("tasks").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "tasks sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(TaskItemEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.taskDao().upsertAll(list) }
    }
}

private fun MockRepository.listenApprovalsRemote() {
    approvalsListenerReg?.remove()
    approvalsListenerReg = qrSyncCollection("approvals").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "approvals sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(ApprovalRequestEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.approvalDao().upsertAll(list) }
    }
}

private fun MockRepository.listenShipmentsRemote() {
    shipmentsListenerReg?.remove()
    shipmentsListenerReg = qrSyncCollection("shipments").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "shipments sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(ShipmentEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.shipmentDao().upsertAll(list) }
    }
}

private fun MockRepository.listenCouriersRemote() {
    couriersListenerReg?.remove()
    couriersListenerReg = qrSyncCollection("couriers").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "couriers sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(CourierPartnerEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.courierDao().upsertAll(list) }
    }
}

private fun MockRepository.listenAuditLogRemote() {
    auditLogListenerReg?.remove()
    auditLogListenerReg = qrSyncCollection("auditLog").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "auditLog sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(AuditLogEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.auditLogDao().upsertAll(list) }
    }
}

private var marketSummaryListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenMarketSummaryRemote() {
    marketSummaryListenerReg?.remove()
    marketSummaryListenerReg = qrSyncCollection("orgState").document("marketSummary").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "marketSummary listener error", err); return@addSnapshotListener }
        val byZone = snap?.get("byZone") as? Map<*, *> ?: return@addSnapshotListener
        _marketSummary.value = byZone.entries.mapNotNull { (k, v) ->
            val zoneData = v as? Map<*, *> ?: return@mapNotNull null
            MockRepository.ZoneSummary(
                zone = k as? String ?: return@mapNotNull null,
                salesLast90Days = (zoneData["salesLast90Days"] as? Number)?.toDouble() ?: 0.0,
                dueBalance = (zoneData["dueBalance"] as? Number)?.toDouble() ?: 0.0,
            )
        }
    }
}

private var notificationsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

private fun MockRepository.listenNotificationsRemote() {
    notificationsListenerReg?.remove()
    notificationsListenerReg = qrSyncCollection("notifications").addSnapshotListener { snap, err ->
        if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "notifications sync listener error", err); return@addSnapshotListener }
        val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.NotificationEntryEntity::class.java) }.orEmpty()
        if (list.isNotEmpty()) launchInRepoScope { database.notificationEntryDao().upsertAll(list) }
    }
}
