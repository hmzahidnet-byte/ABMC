package com.abm.erp.ui.dms

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.core.ModuleDrawerItem
import com.abm.erp.core.ModuleDrawerScaffold
import com.abm.erp.core.ModuleDrillRow
import com.abm.erp.core.Space
import com.abm.erp.core.rememberVisibleDealers
import com.abm.erp.data.MockRepository
import com.abm.erp.data.rejectCollection // v113-190: missing import — real CI compile error
import com.abm.erp.data.verifyCollection // v113-190: missing import — real CI compile error
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import kotlinx.coroutines.launch

/**
 * DMS — Dealer Management System. One of the six mother modules.
 *
 * Built to the person's hand-drawn DMS draft: a left drawer with the module's own
 * options, and everything about a dealer living *inside* here — nothing pulled out
 * into a cross-cutting screen, and no other mother module visible from in here.
 *
 * Where an option already exists as working code elsewhere, this hosts that exact
 * composable rather than writing a second copy. That is deliberate: duplicating the
 * dealer invoice UI would mean two places to fix every future bug, and the person's
 * standing rule is one home per feature.
 */
private val DMS_COLOR_START = 0xFF2563EB
private val DMS_COLOR_END = 0xFF1E3A8A

private val DMS_ITEMS_BASE = listOf(
    ModuleDrawerItem("dashboard", "DMS Dashboard", Icons.Filled.Home, "সারসংক্ষেপ"),
    ModuleDrawerItem("invoice", "Invoice", Icons.Filled.Description, "Direct Invoice + Auto Data"),
    ModuleDrawerItem("message", "Message / CRM", Icons.Filled.Forum, "Offer / Due / Custom SMS"),
    ModuleDrawerItem("list", "List", Icons.Filled.ListAlt, "Dealer Info & Full History"),
    // v113-265 — the person's own direct instruction: RMS as a separate
    // mother module removed entirely — genuinely duplicate weight (its
    // own Dashboard/Report/Chairman tab, mostly repeating DMS's own
    // shape) folded away, and Retailer Stock dropped outright (never
    // asked for again once named). What's kept — Memo/List/Finance, the
    // 3 things actually used day to day — lives here as one drawer item
    // with its own internal tabs, the same "one drawer key, its own
    // ScrollableTabRow" shape "chairman" below already uses, not a
    // second full module shell for 3 screens.
    ModuleDrawerItem("rms", "RMS", Icons.Filled.Store, "Retailer Memo · List · Finance"),
    ModuleDrawerItem("approve", "Approve", Icons.Filled.FactCheck, "Approvals & Permissions"),
    ModuleDrawerItem("alerts", "Alerts", Icons.Filled.Warning, "Stock Shortage · Due Over Limit"),
    ModuleDrawerItem("logistic", "Logistic", Icons.Filled.LocalShipping, "Courier Tracking & API"),
    ModuleDrawerItem("finance", "Finance", Icons.Filled.Payments, "Finance & Cash Management"),
    ModuleDrawerItem("complain", "Complain", Icons.Filled.ReportProblem, "Dealer Complaints"),
)

// v113-167 — same pattern as HR: one drawer item, always last, Chairman-only,
// hosting every Chairman-only-gated action for this module. Dealer/Retailer
// approve uses the broader GM/MD/AGM/Chairman tier (same as Invoice) so it
// stays in "approve" as-is — only setCourierApiConfig is genuinely
// Chairman-only-gated in DMS.
private val DMS_CHAIRMAN_ITEM = ModuleDrawerItem("chairman", "Chairman", Icons.Filled.Star, "Dealer Control · Product · Restore · Courier API")

@Composable
fun DmsHomeScreen(
    startKey: String? = null,
    onBackToHome: () -> Unit = {},
    onNavigate: (String) -> Unit = {},
) {
    // v113-249 — the person's own direct instruction from the diagnostic-
    // center discussion: entering a module should land directly on the
    // real work (the dealer list), not require an extra tap through a
    // summary screen first. Dashboard stays reachable — just not default.
    var selected by remember { mutableStateOf(startKey ?: "list") }
    val salesVm: com.abm.erp.ui.sales.SalesChainViewModel = viewModel()
    val dealersVm: com.abm.erp.ui.dealer.DealersScreenViewModel = viewModel()
    val dealers = rememberVisibleDealers()
    // v113-265 — RMS's own retailers, now read here directly (same real
    // geo-scoped accessor RMS itself always used — confirmed Retailer
    // already follows the identical hierarchy-based territory rule as
    // Dealer, via visibleRetailerIds/visibleDealerIds, before relying on
    // this being "already correct" rather than assumed).
    val retailers = com.abm.erp.core.rememberVisibleRetailers()
    val isChairman = MockRepository.currentUser.role == com.abm.erp.data.UserRole.CHAIRMAN
    val items = if (isChairman) DMS_ITEMS_BASE + DMS_CHAIRMAN_ITEM else DMS_ITEMS_BASE
    // v113-211 — the person's own request: viewing a completed invoice
    // should fill the whole screen. DmsInvoiceWorkspace owns the actual
    // "am I viewing a finished document" state internally, so it reports
    // changes up through this callback rather than that state being
    // duplicated or lifted here.
    var fullScreenDocument by remember { mutableStateOf(false) }

    ModuleDrawerScaffold(
        moduleName = "DMS",
        moduleSubtitle = "Dealer Management System",
        colorStart = DMS_COLOR_START,
        colorEnd = DMS_COLOR_END,
        moduleIcon = Icons.Filled.Business,
        items = items,
        selectedKey = selected,
        onSelect = { selected = it },
        onBackToHome = onBackToHome,
        // v113-265 — the new "rms" section's own Memo tab (RmsMemoWorkspace)
        // has the identical "viewing a finished document" full-screen need
        // Invoice already had — same mechanism, same reasoning.
        hideTopBar = fullScreenDocument && (selected == "invoice" || selected == "rms"),
        // v113-260 — DMS's own real landing key is "list" (v113-249), not
        // "dashboard" — the module-level back-to-home mechanism needs to
        // know that to return to the right place.
        homeKey = "list",
    ) { key ->
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            when (key) {
                "dashboard" -> DmsDashboard(dealers)
                // v113-80 — the workspace contract's reference implementation: the whole
                // invoice operation in ONE screen (dealer QR/search/add + financial
                // context + product + offer/discount + return + summary + approve +
                // history). Old DealerInvoiceTab remains for legacy Sales suite until
                // the final strip-down.
                "invoice" -> DmsInvoiceWorkspace(onNavigate, onViewingDocumentChange = { fullScreenDocument = it })
                // v113-249 — ledger/stock/newdealer drawer items removed
                // (the person's own direct instruction, from the earlier
                // diagnostic-center discussion): each was just "pick a
                // dealer, then see ONE thing about them" — a real,
                // confirmed duplicate of what "list" → a dealer's own rich
                // detail already shows in full (Ledger + Graph + 90-Day
                // sub, the Stock extraTab, and the same detail's own
                // +Add-Dealer button). "list" is the single, complete home
                // for all three now; the underlying dealer_stock/{id} and
                // statement/DEALER/{id} routes are untouched for anything
                // else that might still reference them directly.
                "list" -> com.abm.erp.core.ModuleBrowseList(
                    config = com.abm.erp.core.rememberDealerBrowseConfig(
                        zones = remember(dealers) { dealers.map { it.zone }.filter { it.isNotBlank() }.distinct().sorted() },
                    ),
                    // v113-253 — audit catch, the most visible place this
                    // gap could show up: ModuleBrowseList itself doesn't
                    // filter isDeleted (confirmed directly against its
                    // own implementation — it only filters by search/
                    // facets, the caller owns what "records" it's given),
                    // and dealers here wasn't guaranteed clean on every
                    // visibleDealersFor role path. Without this, a soft-
                    // deleted dealer could appear in the primary Dealer
                    // List itself and be clicked into.
                    records = remember(dealers) { dealers.filter { !it.isDeleted } },
                    onBack = { selected = "dashboard" },
                    onNavigate = onNavigate,
                )
                "approve" -> DmsApprove(dealers, salesVm, onNavigate)
                "alerts" -> DmsAlertsTab(dealers, onNavigate)
                "logistic" -> com.abm.erp.ui.courier.CourierScreen()
                "newdealer" -> com.abm.erp.ui.dealer.AddDealerForm(dealersVm) { selected = "list" }
                // v113-265 — the new home for what used to be the standalone
                // RMS mother module's Memo/List/Finance (the only 3 the
                // person confirmed were still genuinely needed day to day).
                "rms" -> DmsRmsSection(
                    retailers = retailers, onNavigate = onNavigate,
                    onViewingDocumentChange = { fullScreenDocument = it },
                )
                "newretailer" -> com.abm.erp.ui.dealer.AddRetailerForm(dealersVm, dealers) { selected = "rms" }
                // v113-81 — workspace contract: whole collection operation in one screen
                // (party QR/search + due context + entry + dual-control verify history).
                "finance" -> com.abm.erp.core.CollectionWorkspace(
                    partyType = com.abm.erp.data.PartyType.DEALER, partyLabel = "Dealer",
                    // v113-253 — a real audit catch, checking every drawer
                    // item's own logic directly: visibleDealersFor doesn't
                    // filter isDeleted on every one of its own branches
                    // (confirmed directly — only the profile-linked path
                    // does), and "message" right below already added its
                    // own defensive !isDeleted filter for exactly that
                    // reason — this one hadn't, meaning a soft-deleted
                    // (cancelled) dealer could still appear as a valid
                    // target to record a brand new collection against.
                    parties = remember(dealers) { dealers.filter { !it.isDeleted }.map { com.abm.erp.core.CollectionParty(it.id, it.name, it.zone, it.dueBalance) } },
                    onNavigate = onNavigate,
                )
                "message" -> com.abm.erp.core.PartyCampaignSection(
                    audienceLabel = "Dealer/Retailer",
                    // v113-265 — the person's own confirmed decision: DMS's
                    // Message/CRM now reaches both Dealer and Retailer
                    // contacts (RMS's own separate "Relation" removed) —
                    // same real per-party phone/due data either way, just
                    // combined into one list.
                    parties = remember(dealers, retailers) {
                        dealers.filter { !it.isDeleted }.map { com.abm.erp.core.CampaignParty(it.id, it.name, it.phone, it.zone, it.dueBalance) } +
                            retailers.filter { !it.isDeleted }.map { com.abm.erp.core.CampaignParty(it.id, it.name, it.phone, it.market, it.dueBalance) }
                    },
                    // v113-266 — the person's own request: QR-scan next to
                    // the party picker in the new "বাকি তাগাদা" tab.
                    onNavigate = onNavigate,
                )
                // v113-77 — hosted from GeoCrmScreen (made internal); CRM's own tab now
                // points here. One implementation, one home.
                // v113-265 — now also carries retailers, RMS's own separate
                // "Complaint" drawer item removed (see CustomerComplaintsTab
                // itself for the Dealer/Retailer toggle).
                "complain" -> com.abm.erp.ui.crm.CustomerComplaintsTab(dealers, retailers)
                "chairman" -> if (isChairman) DmsChairmanPanel(onNavigate) else DmsDashboard(dealers)
                else -> DmsDashboard(dealers)
            }
        }
    }
}

/**
 * v113-265 — the person's own direct instruction: RMS's own real-world-used
 * features (Memo/List/Finance — everything else either duplicated DMS's own
 * shape or was Retailer Stock, which was cut outright) live here now, one
 * drawer key with its own internal tabs — the same "chairman"/DmsChairmanPanel
 * shape immediately below, not a second full module shell for 3 screens.
 * Every composable here is the exact same one RMS itself used
 * (RmsMemoWorkspace, ModuleBrowseList+rememberRetailerBrowseConfig,
 * CollectionWorkspace) — relocated, not reimplemented.
 */
@Composable
private fun DmsRmsSection(
    retailers: List<com.abm.erp.data.Retailer>,
    onNavigate: (String) -> Unit,
    onViewingDocumentChange: (Boolean) -> Unit,
) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        androidx.compose.material3.ScrollableTabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Memo") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("List") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Finance") })
        }
        when (tab) {
            0 -> com.abm.erp.ui.rms.RmsMemoWorkspace(onNavigate, onViewingDocumentChange = onViewingDocumentChange)
            1 -> com.abm.erp.core.ModuleBrowseList(
                config = com.abm.erp.core.rememberRetailerBrowseConfig(
                    markets = remember(retailers) { retailers.map { it.market }.filter { it.isNotBlank() }.distinct().sorted() },
                ),
                records = remember(retailers) { retailers.filter { !it.isDeleted } },
                onBack = {},
                onNavigate = onNavigate,
            )
            else -> com.abm.erp.core.CollectionWorkspace(
                partyType = com.abm.erp.data.PartyType.RETAILER, partyLabel = "Retailer",
                parties = remember(retailers) { retailers.filter { !it.isDeleted }.map { com.abm.erp.core.CollectionParty(it.id, it.name, it.market.orEmpty(), it.dueBalance) } },
                onNavigate = onNavigate,
            )
        }
    }
}

/**
 * v113-175 — person's specific request for DMS's Chairman panel: a clean
 * approval-only view, not a full browse. If someone wants to add a dealer,
 * that shows here for Chairman to approve — plus Dealer Cancellation and
 * Collection verification (anyone can log a collection; Chairman verifies
 * it). All three already exist as real repository functions
 * (approveDealer/rejectDealer, deleteDealer, verifyCollection/
 * rejectCollection) — this is their first home inside the new DMS module
 * (previously only reachable via the legacy DealersScreen).
 */
// v113-249 — the person's own direct, confirmed finding: DMS had two
// separate implementations of the same "approve pending things" idea —
// Chairman's own panel had a real, complete one (Dealer Add + Invoice +
// Collection, each with real action buttons), while the regular "Approve"
// drawer item (meant for any ASM+ role with real approve permission, per
// PermissionManager's own canApprove = role.ordinal >= ASM.ordinal) had
// only a passive count pointing elsewhere. Extracted the real, working
// content into one shared composable so both call sites show the exact
// same thing — not a second, parallel reimplementation. Dealer
// Cancellation (a more sensitive, destructive delete, not an approval)
// deliberately stays Chairman-panel-only, not pulled into this shared
// piece.
@Composable
private fun DealerApprovalsShared() {
    // v113-271 — the real, confirmed cascade gap: this used to read raw,
    // unscoped MockRepository.dealers/retailers directly — meaning any
    // user reaching either the regular "Approve" key or the Chairman
    // panel's own Approvals tab (this same shared component) could see,
    // and act on, a pending Dealer/Retailer/Invoice/Collection/Memo from
    // a completely different territory. Same real scoped accessor
    // "List" already uses (rememberVisibleDealers/rememberVisibleRetailers,
    // company-wide for Chairman/MD/GM/AGM built into that function
    // already), now the actual source for every pending-list filter
    // below — not a second, parallel scoping mechanism.
    val dealers = com.abm.erp.core.rememberVisibleDealers()
    val collections by MockRepository.partyCollections.collectAsState()
    val invoices by MockRepository.salesInvoices.collectAsState()
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    val visibleDealerIds = remember(dealers) { dealers.map { it.id }.toSet() }
    val pendingDealers = remember(dealers) { dealers.filter { !it.isDeleted && !it.isActive && it.status == "PENDING_APPROVAL" } }
    // v113-265 — a real catch made while folding Retailer Collections in as
    // its own section below: this filter never excluded partyType at all,
    // so once Retailer collections started sharing the same
    // partyCollections table (RMS's own CollectionWorkspace call), a
    // retailer's pending collection could already have been silently
    // showing up in a section labelled "Dealer Collections". Scoped
    // properly to DEALER now that Retailer gets its own real section
    // instead of leaking into this one.
    // v113-271 — also now scoped to visibleDealerIds, same real gap fix.
    val pendingCollections = remember(collections, visibleDealerIds) {
        collections.filter { it.status == "PENDING" && it.partyType == com.abm.erp.data.PartyType.DEALER && it.partyId in visibleDealerIds }
    }
    val pendingInvoices = remember(invoices, visibleDealerIds) {
        invoices.filter { !it.isDeleted && it.status == "PENDING" && it.dealerId in visibleDealerIds }
    }

    // v113-265 — the person's own confirmed decision: Retailer Add
    // approval, Retailer Collections, and Memo Verification (all formerly
    // RMS's own separate "Approvals" panel) now live here, right beside
    // Dealer's equivalents — one Approve panel for both party types,
    // reusing the exact same approveRetailer/rejectRetailer/
    // verifyCollection/rejectCollection/advanceOrder engines RMS itself
    // called, not a second implementation.
    val retailers = com.abm.erp.core.rememberVisibleRetailers()
    val orders by MockRepository.orders.collectAsState()
    val rmsDealers = dealers
    val visibleRetailerIds = remember(retailers) { retailers.map { it.id }.toSet() }
    val pendingRetailers = remember(retailers) { retailers.filter { !it.isDeleted && !it.isActive && it.onboardingStatus == "PENDING_APPROVAL" } }
    val pendingRetailerCollections = remember(collections, visibleRetailerIds) {
        collections.filter { it.status == "PENDING" && it.partyType == com.abm.erp.data.PartyType.RETAILER && it.partyId in visibleRetailerIds }
    }
    // v113-271 — Memo scoping is a little different: an anonymous memo
    // (no linked retailerId — confirmed a real, existing case directly in
    // logNewOrder's own signature) has no party to check territory
    // against, so it's shown to everyone with Approve access rather than
    // hidden from all of them, matching how advanceOrder's own new
    // territory gate treats the same null case.
    val pendingMemos = remember(orders, visibleRetailerIds) {
        orders.filter { it.stage == com.abm.erp.data.OrderStage.SO_LOGGED && (it.retailerId == null || it.retailerId in visibleRetailerIds) }
    }

    fun toast(msg: String) = android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()

    // v113-267 — the person's own confirmed decision: submitting a NEW
    // dealer/retailer no longer starts from the List screen's own "+ Add"
    // (removed there, see rememberDealerBrowseConfig/
    // rememberRetailerBrowseConfig's own addRoute) — it lives here now,
    // right beside the pending list it feeds, in the one screen (this
    // component, shared by both the regular "Approve" key and the
    // Chairman panel's own Approvals tab) that already shows "Dealer Add
    // (pending count)"/"Retailer Add (pending count)".
    val dealersVm: com.abm.erp.ui.dealer.DealersScreenViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    var showAddDealer by remember { mutableStateOf(false) }
    var showAddRetailer by remember { mutableStateOf(false) }

    // v113-264 — the person's own direct instruction, stated as a GENERAL
    // rule for every approval segment in the whole app, not just this one:
    // "সে ওটা ক্লিক করবে, দেখতে পারবে, then ওটা সে approve করবে" — Approve/
    // Reject without ever being able to see what's actually being approved
    // has no basis to decide on. The row's own quick Approve/Reject buttons
    // stay (unchanged, for when a quick decision is genuinely enough), but
    // tapping the row itself now opens the real, full content first.
    var viewingDealerAppId by remember { mutableStateOf<String?>(null) }
    var viewingInvoiceAppId by remember { mutableStateOf<String?>(null) }
    var viewingCollectionAppId by remember { mutableStateOf<String?>(null) }
    var viewingRetailerAppId by remember { mutableStateOf<String?>(null) }
    var viewingRetailerCollectionAppId by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxWidth()) {
        Text("Dealer Add (${pendingDealers.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        Button(onClick = { showAddDealer = true }, modifier = Modifier.padding(vertical = 6.dp)) {
            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text("নতুন Dealer জমা দিন")
        }
        if (pendingDealers.isEmpty()) Text("কোনো pending dealer নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingDealers.forEach { d ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { viewingDealerAppId = d.id }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(d.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(d.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { scope.launch { MockRepository.approveDealer(d.id, onRejected = { r -> toast(r) }) } }) { Text("Approve") }
                    TextButton(onClick = { scope.launch { MockRepository.rejectDealer(d.id, "Rejected", onRejected = { r -> toast(r) }) } }) { Text("Reject", color = DangerRed) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Invoice Approvals (${pendingInvoices.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingInvoices.isEmpty()) Text("কোনো pending invoice নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingInvoices.take(30).forEach { inv ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { viewingInvoiceAppId = inv.id }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${inv.invoiceNo} — ${inv.dealerName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("৳${"%,.0f".format(inv.total)} · ${inv.createdAt.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { MockRepository.approveSalesInvoice(inv.id, onRejected = { r -> toast(r) }) }) { Text("Approve") }
                    TextButton(onClick = { if (!MockRepository.rejectSalesInvoice(inv.id, "Rejected")) toast("Reject করা যায়নি।") }) { Text("Reject", color = DangerRed) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Dealer Collections (${pendingCollections.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingCollections.isEmpty()) Text("কোনো pending collection নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingCollections.forEach { c ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { viewingCollectionAppId = c.id }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.partyName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("৳${"%,.0f".format(c.amount)} · ${c.method}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { scope.launch { MockRepository.verifyCollection(c.id, onRejected = { r -> toast(r) }) } }) { Text("Verify") }
                    TextButton(onClick = { scope.launch { MockRepository.rejectCollection(c.id, onRejected = { r -> toast(r) }) } }) { Text("Reject", color = DangerRed) }
                }
                if (c.proofUri != null) {
                    Spacer(Modifier.height(6.dp))
                    coil.compose.AsyncImage(
                        model = c.proofUri, contentDescription = "লেনদেনের প্রমাণ",
                        modifier = Modifier.height(110.dp).fillMaxWidth(),
                        contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                    )
                } else {
                    Spacer(Modifier.height(4.dp))
                    Text("⚠ কোনো প্রমাণের ছবি সংযুক্ত করা হয়নি।", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                }
            }
        }

        // v113-265 — Retailer Add / Memo Verification / Retailer
        // Collections, RMS's own former "Approvals" panel, now here beside
        // Dealer's equivalents. Same engines, same real logic — relocated.
        Spacer(Modifier.height(16.dp))
        Text("Retailer Add (${pendingRetailers.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        Button(onClick = { showAddRetailer = true }, modifier = Modifier.padding(vertical = 6.dp)) {
            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text("নতুন Retailer জমা দিন")
        }
        if (pendingRetailers.isEmpty()) Text("কোনো pending retailer নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingRetailers.forEach { r ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { viewingRetailerAppId = r.id }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(r.market.orEmpty(), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { scope.launch { MockRepository.approveRetailer(r.id, onRejected = { reason -> toast(reason) }) } }) { Text("Approve") }
                    TextButton(onClick = { scope.launch { MockRepository.rejectRetailer(r.id, "Rejected by Chairman", onRejected = { reason -> toast(reason) }) } }) { Text("Reject", color = DangerRed) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Memo Verification (${pendingMemos.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingMemos.isEmpty()) Text("কোনো pending memo নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingMemos.take(30).forEach { order ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Text("${order.retailerName} · ${order.zone}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text(order.items, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                Text("৳${"%,.0f".format(order.amount)}", color = TextPrimary, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                val nearestDealer = remember(rmsDealers, order.zone) { rmsDealers.firstOrNull { it.zone == order.zone } ?: rmsDealers.firstOrNull() }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (nearestDealer == null) {
                        Text("কোনো dealer নেই — route করা যাচ্ছে না।", color = WarningAmber, style = MaterialTheme.typography.labelSmall)
                    } else {
                        TextButton(onClick = { MockRepository.advanceOrder(order.id, com.abm.erp.data.OrderStage.DEALER_ROUTED, nearestDealer.id) }) {
                            Text("Verify → ${nearestDealer.name}")
                        }
                    }
                    TextButton(onClick = { MockRepository.advanceOrder(order.id, com.abm.erp.data.OrderStage.REJECTED) }) { Text("Reject", color = DangerRed) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Retailer Collections (${pendingRetailerCollections.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingRetailerCollections.isEmpty()) Text("কোনো pending collection নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingRetailerCollections.forEach { c ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { viewingRetailerCollectionAppId = c.id }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.partyName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("৳${"%,.0f".format(c.amount)} · ${c.method}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { scope.launch { MockRepository.verifyCollection(c.id, onRejected = { r -> toast(r) }) } }) { Text("Verify") }
                    TextButton(onClick = { scope.launch { MockRepository.rejectCollection(c.id, onRejected = { r -> toast(r) }) } }) { Text("Reject", color = DangerRed) }
                }
                if (c.proofUri != null) {
                    Spacer(Modifier.height(6.dp))
                    coil.compose.AsyncImage(
                        model = c.proofUri, contentDescription = "লেনদেনের প্রমাণ",
                        modifier = Modifier.height(110.dp).fillMaxWidth(),
                        contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                    )
                } else {
                    Spacer(Modifier.height(4.dp))
                    Text("⚠ কোনো প্রমাণের ছবি সংযুক্ত করা হয়নি।", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                }
            }
        }
    }

    // v113-264 — the real "view before approve" dialogs. Each shows the
    // actual full record (every real field, or the real branded invoice
    // document via the same InvoiceDocumentBody used everywhere else in
    // the app — not a second, different-looking preview), with the same
    // Approve/Reject actions available right there too, so seeing and
    // deciding can happen in one place without needing the row's own
    // buttons as a separate step.
    viewingDealerAppId?.let { id ->
        val d = pendingDealers.firstOrNull { it.id == id }
        androidx.compose.ui.window.Dialog(onDismissRequest = { viewingDealerAppId = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                if (d == null) {
                    Column(Modifier.padding(16.dp)) { Text("এই আবেদনটি আর নেই।", color = TextSecondary) }
                } else {
                    Column(Modifier.padding(16.dp).heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                        Text("Dealer Add Application", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Spacer(Modifier.height(10.dp))
                        listOf(
                            "Name" to d.name, "Zone" to d.zone, "Phone" to d.phone.ifBlank { "—" },
                            "Address" to d.address.ifBlank { "—" }, "Classification" to d.classification,
                            "Credit Limit" to "৳${"%,.0f".format(d.creditLimit)}",
                            "Monthly Target" to "৳${"%,.0f".format(d.monthlyTarget)}",
                            "Created By" to d.createdBy.ifBlank { "—" }, "Created At" to "${d.createdAt}",
                        ).forEach { (label, value) ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Text(value, style = MaterialTheme.typography.bodySmall, color = TextPrimary, textAlign = TextAlign.End)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { scope.launch { MockRepository.approveDealer(d.id, onRejected = { r -> toast(r) }) }; viewingDealerAppId = null },
                                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            ) { Text("Approve") }
                            OutlinedButton(onClick = { scope.launch { MockRepository.rejectDealer(d.id, "Rejected", onRejected = { r -> toast(r) }) }; viewingDealerAppId = null }) { Text("Reject", color = DangerRed) }
                            TextButton(onClick = { viewingDealerAppId = null }) { Text("Close") }
                        }
                    }
                }
            }
        }
    }

    viewingInvoiceAppId?.let { id ->
        val inv = pendingInvoices.firstOrNull { it.id == id }
        androidx.compose.ui.window.Dialog(onDismissRequest = { viewingInvoiceAppId = null }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(modifier = Modifier.fillMaxSize(), color = com.abm.erp.theme.DashBg) {
                if (inv == null) {
                    Column(Modifier.padding(16.dp)) { Text("এই ইনভয়েসটি আর নেই।", color = TextSecondary) }
                } else {
                    Column(Modifier.fillMaxSize()) {
                        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(Space.md)) {
                            com.abm.erp.ui.invoice.InvoiceDocumentBody(invoice = inv, onQrPayloadReady = {})
                        }
                        Row(Modifier.fillMaxWidth().padding(Space.md), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { MockRepository.approveSalesInvoice(inv.id, onRejected = { r -> toast(r) }); viewingInvoiceAppId = null },
                                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen), modifier = Modifier.weight(1f),
                            ) { Text("Approve") }
                            OutlinedButton(
                                onClick = { if (!MockRepository.rejectSalesInvoice(inv.id, "Rejected")) toast("Reject করা যায়নি।"); viewingInvoiceAppId = null },
                                modifier = Modifier.weight(1f),
                            ) { Text("Reject", color = DangerRed) }
                        }
                        TextButton(onClick = { viewingInvoiceAppId = null }, modifier = Modifier.fillMaxWidth()) { Text("← ফিরে যান") }
                    }
                }
            }
        }
    }

    viewingCollectionAppId?.let { id ->
        val c = pendingCollections.firstOrNull { it.id == id }
        androidx.compose.ui.window.Dialog(onDismissRequest = { viewingCollectionAppId = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                if (c == null) {
                    Column(Modifier.padding(16.dp)) { Text("এই collection-টি আর নেই।", color = TextSecondary) }
                } else {
                    Column(Modifier.padding(16.dp).heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                        Text("Collection Verification", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Spacer(Modifier.height(10.dp))
                        listOf(
                            "Party" to c.partyName, "Amount" to "৳${"%,.0f".format(c.amount)}",
                            "Method" to c.method, "Date" to "${c.createdAt}",
                        ).forEach { (label, value) ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Text(value, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                            }
                        }
                        if (c.proofUri != null) {
                            Spacer(Modifier.height(8.dp))
                            coil.compose.AsyncImage(
                                model = c.proofUri, contentDescription = "লেনদেনের প্রমাণ",
                                modifier = Modifier.height(220.dp).fillMaxWidth(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                            )
                        } else {
                            Spacer(Modifier.height(6.dp))
                            Text("⚠ কোনো প্রমাণের ছবি সংযুক্ত করা হয়নি।", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { scope.launch { MockRepository.verifyCollection(c.id, onRejected = { r -> toast(r) }) }; viewingCollectionAppId = null },
                                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            ) { Text("Verify") }
                            OutlinedButton(onClick = { scope.launch { MockRepository.rejectCollection(c.id, onRejected = { r -> toast(r) }) }; viewingCollectionAppId = null }) { Text("Reject", color = DangerRed) }
                            TextButton(onClick = { viewingCollectionAppId = null }) { Text("Close") }
                        }
                    }
                }
            }
        }
    }

    viewingRetailerAppId?.let { id ->
        val r = pendingRetailers.firstOrNull { it.id == id }
        androidx.compose.ui.window.Dialog(onDismissRequest = { viewingRetailerAppId = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                if (r == null) {
                    Column(Modifier.padding(16.dp)) { Text("এই আবেদনটি আর নেই।", color = TextSecondary) }
                } else {
                    Column(Modifier.padding(16.dp).heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                        Text("Retailer Add Application", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                        if (r.photoUri != null) {
                            Spacer(Modifier.height(8.dp))
                            coil.compose.AsyncImage(
                                model = r.photoUri, contentDescription = "দোকানের ছবি",
                                modifier = Modifier.height(160.dp).fillMaxWidth(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        listOf(
                            "Name" to r.name, "Owner" to r.ownerName.ifBlank { "—" }, "Phone" to r.phone.ifBlank { "—" },
                            "Market" to r.market.ifBlank { "—" }, "Area" to r.area.ifBlank { "—" },
                            "Address" to r.address.ifBlank { "—" }, "Trade License" to r.tradeLicenseNo.ifBlank { "—" },
                        ).forEach { (label, value) ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Text(value, style = MaterialTheme.typography.bodySmall, color = TextPrimary, textAlign = TextAlign.End)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { scope.launch { MockRepository.approveRetailer(r.id, onRejected = { reason -> toast(reason) }) }; viewingRetailerAppId = null },
                                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            ) { Text("Approve") }
                            OutlinedButton(onClick = { scope.launch { MockRepository.rejectRetailer(r.id, "Rejected by Chairman", onRejected = { reason -> toast(reason) }) }; viewingRetailerAppId = null }) { Text("Reject", color = DangerRed) }
                            TextButton(onClick = { viewingRetailerAppId = null }) { Text("Close") }
                        }
                    }
                }
            }
        }
    }

    viewingRetailerCollectionAppId?.let { id ->
        val c = pendingRetailerCollections.firstOrNull { it.id == id }
        androidx.compose.ui.window.Dialog(onDismissRequest = { viewingRetailerCollectionAppId = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                if (c == null) {
                    Column(Modifier.padding(16.dp)) { Text("এই collection-টি আর নেই।", color = TextSecondary) }
                } else {
                    Column(Modifier.padding(16.dp).heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                        Text("Collection Verification", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Spacer(Modifier.height(10.dp))
                        listOf(
                            "Party" to c.partyName, "Amount" to "৳${"%,.0f".format(c.amount)}",
                            "Method" to c.method, "Date" to "${c.createdAt}",
                        ).forEach { (label, value) ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Text(value, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                            }
                        }
                        if (c.proofUri != null) {
                            Spacer(Modifier.height(8.dp))
                            coil.compose.AsyncImage(
                                model = c.proofUri, contentDescription = "লেনদেনের প্রমাণ",
                                modifier = Modifier.height(220.dp).fillMaxWidth(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                            )
                        } else {
                            Spacer(Modifier.height(6.dp))
                            Text("⚠ কোনো প্রমাণের ছবি সংযুক্ত করা হয়নি।", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { scope.launch { MockRepository.verifyCollection(c.id, onRejected = { r -> toast(r) }) }; viewingRetailerCollectionAppId = null },
                                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            ) { Text("Verify") }
                            OutlinedButton(onClick = { scope.launch { MockRepository.rejectCollection(c.id, onRejected = { r -> toast(r) }) }; viewingRetailerCollectionAppId = null }) { Text("Reject", color = DangerRed) }
                            TextButton(onClick = { viewingRetailerCollectionAppId = null }) { Text("Close") }
                        }
                    }
                }
            }
        }
    }

    if (showAddDealer) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showAddDealer = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(4.dp).heightIn(max = 560.dp)) {
                    com.abm.erp.ui.dealer.AddDealerForm(dealersVm) { showAddDealer = false }
                }
            }
        }
    }
    if (showAddRetailer) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showAddRetailer = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(4.dp).heightIn(max = 560.dp)) {
                    com.abm.erp.ui.dealer.AddRetailerForm(dealersVm, dealers) { showAddRetailer = false }
                }
            }
        }
    }
}

@Composable
private fun DmsApprovalsPanel() {
    val dealers by MockRepository.dealers.collectAsState()
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    val activeDealers = remember(dealers) { dealers.filter { !it.isDeleted && it.isActive } }
    // v113-265 — Retailer Cancellation, RMS's own former Chairman-tab
    // section, now here right beside Dealer's — its own separate section
    // (not blended together), per the person's own confirmed decision.
    val retailers by MockRepository.retailers.collectAsState()
    val activeRetailers = remember(retailers) { retailers.filter { !it.isDeleted && it.isActive } }

    fun toast(msg: String) = android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()

    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        DealerApprovalsShared()

        Spacer(Modifier.height(16.dp))
        Text("Dealer Cancellation", fontWeight = FontWeight.Bold, color = TextPrimary)
        Text("সক্রিয় dealer বাতিল করুন — soft delete, পুনরুদ্ধার Restore tab থেকে সম্ভব।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        var cancelQuery by remember { mutableStateOf("") }
        OutlinedTextField(value = cancelQuery, onValueChange = { cancelQuery = it }, placeholder = { Text("Dealer নাম খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        activeDealers.filter { cancelQuery.isBlank() || it.name.contains(cancelQuery, true) }.take(20).forEach { d ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(d.name, color = TextPrimary, modifier = Modifier.weight(1f))
                    TextButton(onClick = { scope.launch { MockRepository.deleteDealer(d.id, onRejected = { r -> toast(r) }) } }) { Text("Cancel", color = DangerRed) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Retailer Cancellation", fontWeight = FontWeight.Bold, color = TextPrimary)
        Text("সক্রিয় retailer বাতিল করুন — soft delete, পুনরুদ্ধার Restore tab থেকে সম্ভব।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        var retailerCancelQuery by remember { mutableStateOf("") }
        OutlinedTextField(value = retailerCancelQuery, onValueChange = { retailerCancelQuery = it }, placeholder = { Text("Retailer নাম খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        activeRetailers.filter { retailerCancelQuery.isBlank() || it.name.contains(retailerCancelQuery, true) }.take(20).forEach { r ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(r.name, color = TextPrimary, modifier = Modifier.weight(1f))
                    TextButton(onClick = { scope.launch { MockRepository.deleteRetailer(r.id, onRejected = { reason -> toast(reason) }) } }) { Text("Cancel", color = DangerRed) }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun DmsChairmanPanel(onNavigate: (String) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        androidx.compose.material3.ScrollableTabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Approvals") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Dealer Control") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Sales Rules") })
            Tab(selected = tab == 3, onClick = { tab = 3 }, text = { Text("Restore") })
            Tab(selected = tab == 4, onClick = { tab = 4 }, text = { Text("Courier API") })
            // v113-249 — the person's own direct confirmation: these are
            // genuinely DMS-related (dealer-territory GPS anomalies and
            // security events), so they belong directly in DMS's own
            // Chairman panel rather than only being reachable indirectly
            // through other modules' quick-links (Dashboard, Boardroom).
            // Reused directly from DealersScreen.kt (now internal rather
            // than private) — not a second implementation of the same
            // review lists.
            Tab(selected = tab == 5, onClick = { tab = 5 }, text = { Text("Location Alerts") })
            Tab(selected = tab == 6, onClick = { tab = 6 }, text = { Text("Security Events") })
        }
        when (tab) {
            0 -> DmsApprovalsPanel()
            1 -> {
                // v113-172 — moved from the central Chairman module's "parties" item
                // (dealer half — retailer half is now RMS's own Chairman tab).
                // v113-201 — was passed onNavigate = {} because this composable had
                // no parameter to forward one through: confirmed by tracing DmsHomeScreen's
                // "chairman" route, which called DmsChairmanPanel() with zero arguments.
                // The only two things ModuleBrowseList's onNavigate actually drives (its
                // own onNavigate calls, traced directly in ModuleBrowseFlow.kt) are the
                // "Add" button (dealer's addRoute = "dms?key=newdealer") and the QR-scan
                // FAB — both were silently inert here. Now wired to the real one.
                val dealers = com.abm.erp.core.rememberVisibleDealers()
                // v113-253 — same audit catch as the regular "list" drawer
                // item: ModuleBrowseList doesn't filter isDeleted itself,
                // and rememberVisibleDealers() isn't guaranteed to have
                // filtered it on every role path either.
                com.abm.erp.core.ModuleBrowseList(
                    config = com.abm.erp.core.rememberDealerBrowseConfig(
                        zones = remember(dealers) { dealers.map { it.zone }.filter { it.isNotBlank() }.distinct().sorted() },
                    ),
                    records = remember(dealers) { dealers.filter { !it.isDeleted } },
                    onBack = {},
                    onNavigate = onNavigate,
                )
            }
            // v113-221 — was "Product Control" (ChairmanProductControl) —
            // removed as a duplicate: Product now lives only in the
            // central Chairman module's own "Product" item, matching the
            // person's own principle of not showing the same control from
            // two places. This slot now carries the DMS-relevant subset of
            // the old central "Business Rule Engine" instead (the
            // sales/credit rules — the HR-relevant subset went to HR's
            // own Chairman panel the same way) — "একেক জায়গায় একেকটা
            // rules হবে", the person's own words.
            2 -> DmsBusinessRulesSection()
            3 -> Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
                Text("Soft-deleted রেকর্ড দেখা ও restore — hard delete এই অ্যাপে নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Spacer(Modifier.height(8.dp))
                com.abm.erp.ui.chairmanmodule.DmsInvoiceRestoreSection()
                Spacer(Modifier.height(8.dp))
                com.abm.erp.ui.chairmanmodule.DmsDealerRestoreSection()
                Spacer(Modifier.height(8.dp))
                com.abm.erp.ui.chairmanmodule.DmsProductRestoreSection()
                // v113-265 — Retailer Restore, RMS's own former separate
                // Chairman-tab section, now here — same real function
                // (RmsRetailerRestoreSection), just relocated alongside
                // Invoice/Dealer/Product Restore instead of a second
                // standalone Restore tab.
                Spacer(Modifier.height(8.dp))
                com.abm.erp.ui.chairmanmodule.RmsRetailerRestoreSection()
            }
            4 -> com.abm.erp.ui.courier.CourierApiConfigPanel()
            5 -> com.abm.erp.ui.dealer.LocationAlertsTab()
            else -> com.abm.erp.ui.dealer.SecurityEventsTab()
        }
    }
}

private data class DmsRuleDef(val key: String, val label: String, val type: com.abm.erp.data.BusinessRuleType, val default: Double)

private val DMS_RULES = listOf(
    DmsRuleDef("WEEKLY_DUE_PCT", "Weekly 50% Due Rule (Tuesday checkpoint %)", com.abm.erp.data.BusinessRuleType.PERCENTAGE, 50.0),
    DmsRuleDef("MAX_DISCOUNT_PCT", "Maximum Discount %", com.abm.erp.data.BusinessRuleType.PERCENTAGE, 15.0),
    DmsRuleDef("INVOICE_LIMIT", "Invoice Limit (needs extra approval above this)", com.abm.erp.data.BusinessRuleType.AMOUNT, 500000.0),
    DmsRuleDef("DEALER_CREDIT_LIMIT_DEFAULT", "Dealer Credit Limit — default for new dealers", com.abm.erp.data.BusinessRuleType.AMOUNT, 0.0),
    DmsRuleDef("MIN_CREDIT_LIMIT", "Minimum Credit Limit (floor for any dealer)", com.abm.erp.data.BusinessRuleType.AMOUNT, 0.0),
)

@Composable
private fun DmsBusinessRulesSection() {
    val rules by MockRepository.businessRules.collectAsState()
    var editingKey by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Text("Sales & Credit Rules", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("পরিবর্তন সাথে সাথে সারা ERP-এ প্রতিফলিত হবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(8.dp))
        DMS_RULES.forEach { def ->
            val current = rules.firstOrNull { it.key == def.key }
            val currentValue = current?.value ?: def.default
            Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), tonalElevation = 2.dp) {
                Column(Modifier.padding(10.dp)) {
                    Text(def.label, style = MaterialTheme.typography.titleSmall)
                    Text("বর্তমান মান: $currentValue${if (def.type == com.abm.erp.data.BusinessRuleType.PERCENTAGE) "%" else ""}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    TextButton(onClick = { editingKey = def.key }) { Text("সম্পাদনা করুন") }
                }
            }
        }
    }
    editingKey?.let { key ->
        val def = DMS_RULES.first { it.key == key }
        val current = rules.firstOrNull { it.key == key }?.value ?: def.default
        var newValue by remember { mutableStateOf(current.toString()) }
        androidx.compose.ui.window.Dialog(onDismissRequest = { editingKey = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(def.label, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newValue, onValueChange = { newValue = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("নতুন মান") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val v = newValue.toDoubleOrNull()
                            if (v != null) { MockRepository.setBusinessRule(def.key, def.label, def.type, v); editingKey = null }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("সংরক্ষণ করুন") }
                }
            }
        }
    }
}

@Composable
private fun DmsDashboard(dealers: List<com.abm.erp.data.Dealer>) {
    // v113-253 — a real audit catch: dealers (as passed into this whole
    // screen) isn't reliably isDeleted-filtered on every role path
    // visibleDealersFor takes (confirmed directly — only the profile-
    // linked branch filters it), so a soft-deleted dealer could inflate
    // this Dashboard's own real business numbers — the dealer count, the
    // total due, and both of the newly-added graphs below, all of which
    // read from dealers directly. Filtered once, here, rather than
    // scattering the same guard across every individual stat.
    val activeDealers = remember(dealers) { dealers.filter { !it.isDeleted } }
    val invoices by MockRepository.salesInvoices.collectAsState()
    val approvals by MockRepository.approvals.collectAsState()
    // v113-267 — real product photos for the Top Products KPI ring below,
    // the same real InventoryRepository.products list DmsAlertsTab already
    // reads, not a second/fabricated source.
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val totalDue = remember(activeDealers) { activeDealers.sumOf { it.dueBalance } }
    val pendingInvoices = remember(invoices) { invoices.count { it.status == "PENDING" && !it.isDeleted } }
    val pendingApprovals = remember(approvals) {
        approvals.count { it.status == com.abm.erp.data.ApprovalStatus.PENDING && it.entityType == "SalesInvoice" }
    }
    // v113-265 — the person's own confirmed decision: RMS's own separate
    // Dashboard removed, DMS's own gets Retailer numbers folded in
    // instead. Same real accessor RMS itself used.
    val activeRetailers = com.abm.erp.core.rememberVisibleRetailers()
    val retailerTotalDue = remember(activeRetailers) { activeRetailers.filter { !it.isDeleted }.sumOf { it.dueBalance } }

    // v113-263 — same real Export/Share/Print registration as Ledger, for
    // the module's own Dashboard (a summary screen, no per-row record) —
    // the exact same real numbers the cards below already show.
    com.abm.erp.core.RegisterModuleMenuContent(
        title = "DMS Overview",
        rows = listOf(
            "Dealer" to "${activeDealers.size}",
            "Total Due" to "৳${"%,.0f".format(totalDue)}",
            "Pending Invoice" to "$pendingInvoices",
            "Pending Approval" to "$pendingApprovals",
            "Retailer" to "${activeRetailers.count { !it.isDeleted }}",
            "Retailer Total Due" to "৳${"%,.0f".format(retailerTotalDue)}",
        ),
    )

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("DMS Overview", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(4.dp))
        Text(
            "আপনার cascade scope অনুযায়ী — অন্য এলাকার dealer/retailer এখানে গোনা হয় না।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(12.dp))
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            DmsStatRow("Dealer", "${activeDealers.size}", TextPrimary)
            DmsStatRow("Total Due", "৳${"%,.0f".format(totalDue)}", if (totalDue > 0) WarningAmber else SuccessGreen)
            DmsStatRow("Pending Invoice", "$pendingInvoices", if (pendingInvoices > 0) WarningAmber else SuccessGreen)
            DmsStatRow("Pending Approval", "$pendingApprovals", if (pendingApprovals > 0) WarningAmber else SuccessGreen)
        }
        Spacer(Modifier.height(12.dp))
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            DmsStatRow("Retailer", "${activeRetailers.count { !it.isDeleted }}", TextPrimary)
            DmsStatRow("Retailer Total Due", "৳${"%,.0f".format(retailerTotalDue)}", if (retailerTotalDue > 0) WarningAmber else SuccessGreen)
        }
        // v113-139 — person asked every mother-module dashboard to carry a KPI
        // graphic. Uses the SHARED DualSeriesBarChart and real invoice/collection
        // rows for the dealers in this user's own cascade scope — no sample data,
        // and no second charting implementation.
        val collections by MockRepository.partyCollections.collectAsState()
        val myDealerIds = remember(activeDealers) { activeDealers.map { it.id }.toSet() }
        val weekly = remember(invoices, collections, myDealerIds) {
            val today = java.time.LocalDate.now()
            val thisMonday = today.minusDays((today.dayOfWeek.value - 1).toLong())
            (4 downTo 0).map { w ->
                val start = thisMonday.minusWeeks(w.toLong())
                val end = start.plusDays(7)
                val sales = invoices.filter { !it.isDeleted && it.dealerId in myDealerIds && !it.createdAt.toLocalDate().isBefore(start) && it.createdAt.toLocalDate().isBefore(end) }
                    .sumOf { inv -> inv.lineItems.sumOf { it.lineTotal } }
                val col = collections.filter { it.status == "VERIFIED" && it.partyId in myDealerIds && !it.createdAt.toLocalDate().isBefore(start) && it.createdAt.toLocalDate().isBefore(end) }
                    .sumOf { it.amount }
                Triple("${start.dayOfMonth}/${start.monthValue}", sales, col)
            }
        }
        if (weekly.any { it.second > 0.0 || it.third > 0.0 }) {
            Spacer(Modifier.height(12.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Sales vs Collection — Last 5 Weeks", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                com.abm.erp.core.DualSeriesBarChart(weekly, "Sales", "Collection")
            }
        }

        // v113-251 — the person's own direct instruction: entering DMS
        // should show real graphical reports right on the Dashboard, not
        // just stat numbers and one chart. Reuses the exact bar-progress
        // visual already proven in TerritoryOverviewScreen's own Sales
        // Report tab and DealerSalesReportTab — same pattern, company-
        // wide scope here, not a new visual language invented for this
        // one screen.
        val myDealerIds30 = remember(activeDealers) { activeDealers.map { it.id }.toSet() }
        val last30Invoices = remember(invoices, myDealerIds30) {
            val cutoff = java.time.LocalDate.now().minusDays(29)
            invoices.filter { !it.isDeleted && it.dealerId in myDealerIds30 && !it.createdAt.toLocalDate().isBefore(cutoff) }
        }
        data class TopProduct(val productId: String, val name: String, val qty: Int, val value: Double, val photoUri: String?)
        val topProducts = remember(last30Invoices, products) {
            last30Invoices.flatMap { it.lineItems }
                .groupBy { it.productId }
                .map { (productId, lines) ->
                    val realProduct = products.firstOrNull { it.id == productId }
                    TopProduct(
                        productId = productId,
                        name = realProduct?.name ?: lines.first().name,
                        qty = lines.sumOf { it.qty },
                        value = lines.sumOf { it.lineTotal },
                        photoUri = realProduct?.photoUri,
                    )
                }
                .sortedByDescending { it.value }.take(6)
        }
        if (topProducts.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Top Products — Last 30 Days", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(12.dp))
                val maxVal = topProducts.maxOf { it.value }
                // v113-267 — the person's own direct request: a more
                // "professional" KPI look for product growth — real photo
                // + a colourful circular sales-share ring, not a thin bar.
                val ringColors = listOf(0xFFE85D4A, 0xFF2563EB, 0xFF1FA972, 0xFF9C6EFF, 0xFFDB2777, 0xFF0EA5A4)
                topProducts.forEachIndexed { idx, p ->
                    val pct = (p.value / maxVal).toFloat().coerceIn(0f, 1f)
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        ProductGrowthRing(
                            photoUri = p.photoUri,
                            percent = pct,
                            ringColor = Color(ringColors[idx % ringColors.size]),
                            size = 46.dp,
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, maxLines = 1)
                            Text("${p.qty} pcs · ৳${"%,.0f".format(p.value)}", fontSize = 11.sp, color = TextSecondary)
                        }
                        Text("${"%.0f".format(pct * 100)}%", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(ringColors[idx % ringColors.size]))
                    }
                }
            }
        }

        // Zone-wise due — where the risk actually concentrates, at a glance.
        val zoneDue = remember(activeDealers) {
            activeDealers.filter { it.zone.isNotBlank() }
                .groupBy { it.zone }
                .map { (zone, ds) -> zone to ds.sumOf { it.dueBalance } }
                .sortedByDescending { it.second }.take(6)
        }
        if (zoneDue.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Zone-wise Due", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                val maxDue = zoneDue.maxOf { it.second }.coerceAtLeast(1.0)
                zoneDue.forEach { (zone, due) ->
                    Column(Modifier.padding(vertical = 4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(zone, fontSize = 11.sp, color = TextPrimary, maxLines = 1, modifier = Modifier.weight(1f))
                            Text("৳${"%,.0f".format(due)}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = if (due > 0) WarningAmber else SuccessGreen)
                        }
                        Spacer(Modifier.height(3.dp))
                        Box(Modifier.fillMaxWidth().height(5.dp).background(com.abm.erp.theme.HairlineBorder, androidx.compose.foundation.shape.RoundedCornerShape(999.dp))) {
                            Box(
                                Modifier.fillMaxWidth((due / maxDue).toFloat().coerceIn(0f, 1f))
                                    .fillMaxHeight().background(if (due > 0) WarningAmber else SuccessGreen, androidx.compose.foundation.shape.RoundedCornerShape(999.dp)),
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun DmsStatRow(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Text(value, fontWeight = FontWeight.Bold, color = color)
    }
}

/**
 * v113-267 — the person's own direct request: a "professional" KPI look
 * for product growth — the real product photo (or a neutral placeholder
 * when none is set) with a colourful circular sales-share ring drawn
 * around it, `percent` full. Pure presentation — takes real numbers in,
 * doesn't compute anything itself.
 */
@Composable
private fun ProductGrowthRing(photoUri: String?, percent: Float, ringColor: androidx.compose.ui.graphics.Color, size: androidx.compose.ui.unit.Dp) {
    Box(Modifier.size(size), contentAlignment = androidx.compose.ui.Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            val strokeWidth = 3.5.dp.toPx()
            drawArc(
                color = ringColor.copy(alpha = 0.18f),
                startAngle = -90f, sweepAngle = 360f, useCenter = false,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth, cap = androidx.compose.ui.graphics.StrokeCap.Round),
            )
            drawArc(
                color = ringColor,
                startAngle = -90f, sweepAngle = 360f * percent.coerceIn(0f, 1f), useCenter = false,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth, cap = androidx.compose.ui.graphics.StrokeCap.Round),
            )
        }
        val innerSize = size - 12.dp
        if (!photoUri.isNullOrBlank()) {
            coil.compose.AsyncImage(
                model = photoUri, contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                modifier = Modifier.size(innerSize).clip(androidx.compose.foundation.shape.CircleShape),
            )
        } else {
            Box(
                Modifier.size(innerSize).clip(androidx.compose.foundation.shape.CircleShape).background(ringColor.copy(alpha = 0.15f)),
                contentAlignment = androidx.compose.ui.Alignment.Center,
            ) { Icon(Icons.Filled.Inventory2, contentDescription = null, tint = ringColor, modifier = Modifier.size(innerSize * 0.5f)) }
        }
    }
}

/** Shared "pick a dealer, then drill in" list — used by Ledger and Stock. */
@Composable
private fun DmsDealerPickerList(
    dealers: List<com.abm.erp.data.Dealer>,
    emptyText: String,
    subtitleFor: (com.abm.erp.data.Dealer) -> String,
    onPick: (com.abm.erp.data.Dealer) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(dealers, query) {
        if (query.isBlank()) dealers
        else dealers.filter { it.name.contains(query, true) || it.zone.contains(query, true) }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text("নাম বা এলাকা দিয়ে খুঁজুন…") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(10.dp))
        if (filtered.isEmpty()) Text(emptyText, color = TextSecondary)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { d ->
                ModuleDrillRow(d.name, subtitleFor(d)) { onPick(d) }
            }
        }
    }
}

/**
 * Approve — invoice/discount approvals for dealers, inside DMS where they belong
 * (Decision 2). ApprovalRequest rows (discount/over-limit) are actioned here; the
 * invoice's own ✓ Approve lives inline in the Invoice Workspace's history list
 * (v113-80), so this section points there rather than hosting a second copy.
 */
@Composable
private fun DmsApprove(
    dealers: List<com.abm.erp.data.Dealer>,
    salesVm: com.abm.erp.ui.sales.SalesChainViewModel,
    onNavigate: (String) -> Unit,
) {
    // v113-249 — the person's own direct, confirmed finding: this drawer
    // item — reachable by any role with real approve permission
    // (PermissionManager's own canApprove = role.ordinal >= ASM.ordinal,
    // not Chairman-only) — used to show only a passive count with a note
    // pointing elsewhere, while Chairman's own separate panel had the
    // real, actionable version of the exact same thing. Now calls the
    // same shared component Chairman's panel calls — one real
    // implementation, not two.
    Column(Modifier.fillMaxSize().padding(bottom = 12.dp).verticalScroll(rememberScrollState())) {
        com.abm.erp.core.ModuleApprovalSection(
            title = "Discount / limit অনুমোদনের অপেক্ষায়",
            entityTypes = setOf("SalesInvoice"),
        )
        Spacer(Modifier.height(12.dp))
        DealerApprovalsShared()
    }
}

// v113-249 — the person's own direct request: a real, live alerts view
// inside DMS — stock shortage (against Product's own reorderThreshold,
// now finally settable via Chairman's Product dialog) and due-over-limit
// dealers, in one place. Deliberately a live, always-current computed
// list rather than a persisted notification log — this app has no
// background/scheduled job infrastructure to reliably trigger periodic
// notification-creation, so a live view can never go stale or miss an
// event the way a notification-log approach could.
@Composable
private fun DmsAlertsTab(dealers: List<com.abm.erp.data.Dealer>, onNavigate: (String) -> Unit) {
    val allStockLines by MockRepository.allDealerStockLines().collectAsState(initial = emptyList())
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val reorderByProductId = remember(products) { products.filter { it.reorderThreshold > 0 }.associate { it.id to it.reorderThreshold } }
    // v113-253 — audit catch: overLimitDealers below already correctly
    // filters !isDeleted, but this one didn't — meaning a soft-deleted
    // (cancelled) dealer's leftover stock lines could still surface a
    // "shortage" alert with their name resolving fine, noise nobody
    // needs to act on since that dealer isn't actively supplied anymore.
    val dealerNameById = remember(dealers) { dealers.filter { !it.isDeleted }.associate { it.id to it.name } }

    data class ShortageRow(val dealerName: String, val dealerId: String, val productName: String, val qty: Int, val threshold: Double)
    val shortages = remember(allStockLines, reorderByProductId, dealerNameById) {
        allStockLines.mapNotNull { line ->
            val threshold = reorderByProductId[line.productId] ?: return@mapNotNull null
            if (line.qty >= threshold) return@mapNotNull null
            val dealerName = dealerNameById[line.dealerId] ?: return@mapNotNull null
            ShortageRow(dealerName, line.dealerId, line.productName, line.qty, threshold)
        }.sortedBy { it.qty }
    }

    val overLimitDealers = remember(dealers) {
        dealers.filter { !it.isDeleted && it.creditLimit > 0 && it.dueBalance > it.creditLimit }
            .sortedByDescending { it.dueBalance - it.creditLimit }
    }

    Column(Modifier.fillMaxSize().padding(bottom = 12.dp).verticalScroll(rememberScrollState())) {
        Text("Stock Shortage (${shortages.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        Text(
            "Product-এর Reorder Threshold-এর নিচে নেমে যাওয়া dealer stock — Chairman-এর Product সেটিংসে threshold নির্ধারণ করুন।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(6.dp))
        if (shortages.isEmpty()) {
            Text("কোনো shortage নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        } else {
            shortages.forEach { s ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { onNavigate("rich_dealer_detail/${s.dealerId}") }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(s.productName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(s.dealerName, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text("${s.qty} / ${s.threshold.toInt()}", color = DangerRed, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("Due Over Limit (${overLimitDealers.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        if (overLimitDealers.isEmpty()) {
            Text("কোনো dealer limit ছাড়ায়নি।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        } else {
            overLimitDealers.forEach { d ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { onNavigate("rich_dealer_detail/${d.id}") }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(d.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(d.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                            Text("Due ৳${"%,.0f".format(d.dueBalance)}", color = DangerRed, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            Text("Limit ৳${"%,.0f".format(d.creditLimit)}", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}
