package com.abm.erp.ui.dms

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import kotlinx.coroutines.launch
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.DocBar
import com.abm.erp.core.DocLabel
import com.abm.erp.core.DocLogoMark
import com.abm.erp.core.DocValue
import com.abm.erp.core.GlassCard
import com.abm.erp.core.Space
import com.abm.erp.core.TdGrid
import com.abm.erp.core.ThGrid
import com.abm.erp.core.rememberVisibleDealers
import com.abm.erp.data.MockRepository
import com.abm.erp.data.PermissionAction
import com.abm.erp.data.PermissionManager
import com.abm.erp.data.SalesInvoiceLineItem
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * v113-80 — DMS INVOICE WORKSPACE. The reference implementation of the person's
 * standing workspace contract (PROJECT_STATE v113-79): ONE full-screen workspace for
 * the whole invoice operation. Dealer identify (search OR code/QR autofill with geo
 * validation), dealer financial context (due / credit limit / available credit /
 * history), product add (search / category / code), offer rules, discount, commission,
 * return entry, stock availability, live summary with credit check, create, approve,
 * invoice QR payload, share — all inline. Helper actions are sheets/dialogs only;
 * nothing navigates away.
 *
 * Contract clause honoured hard: **no business logic redesigned, no duplicate
 * workflow.** Every write goes through the SAME engines the old tab used —
 * `createSalesInvoice`, `approveSalesInvoice`, `deleteSalesInvoice`,
 * `createSalesReturn`, `CodeRegistry.resolve` — with all their permission checks,
 * audit logs, Firestore sync and stock effects intact. What is new here is
 * arrangement only.
 *
 * Gift is present but disabled: its financial rule (does it reduce due? post to
 * ledger? need approval?) has never been defined by the person, and inventing a money
 * rule unasked is forbidden by the standing rules. The chip says so.
 */
@Composable
fun DmsInvoiceWorkspace(onNavigate: (String) -> Unit = {}, onViewingDocumentChange: (Boolean) -> Unit = {}) {
    val dealers = rememberVisibleDealers()
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val stockLevels by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
    val invoices by MockRepository.salesInvoices.collectAsState()
    val discountRules by MockRepository.discountRules.collectAsState()
    val scope = rememberCoroutineScope()

    // ---- workspace state ----
    // v113-305 — dealerQuery removed: the inline dealer search field it
    // backed is gone, replaced by the shared DealerSearchIcon which owns
    // its own query state inside its own dialog.
    var selectedDealerId by remember { mutableStateOf<String?>(null) }
    var productQuery by remember { mutableStateOf("") }
    var categoryFilter by remember { mutableStateOf<String?>(null) }
    var cart by remember { mutableStateOf(listOf<SalesInvoiceLineItem>()) }
    var dealerDiscount by remember { mutableStateOf("") }
    var commission by remember { mutableStateOf("") }
    // v113-249 — the person's own direct, sharp follow-up question: why
    // require a separate trip to the Courier screen afterward at all,
    // when the courier is already being chosen right here? Changed from
    // a free-text label (stored on the invoice but connected to nothing
    // real) to an actual picker against the real Couriers list, so a
    // real Shipment can be auto-booked and linked the moment the invoice
    // is created — not a second, manual step.
    val allCouriers by MockRepository.couriers.collectAsState()
    var selectedCourierId by remember { mutableStateOf<String?>(null) }
    // v113-249 — the person's own direct follow-up: a lot of delivery
    // happens via the company's own vehicle, not a third-party courier
    // at all. Vehicle already existed (real GPS-tracked company
    // vehicles), just never connected to a shipment/invoice — offered
    // here alongside real couriers, mutually exclusive with them.
    val allVehicles by MockRepository.vehicles.collectAsState()
    var selectedVehicleId by remember { mutableStateOf<String?>(null) }
    // v113-255 — real Pathao/RedX area-code state, resolved via the new
    // real picker dialogs rather than manual numeric entry — id kept for
    // the real API call, name kept only so the button label can show
    // something a person actually recognizes.
    var pathaoCityId by remember { mutableStateOf<String?>(null) }
    var pathaoCityName by remember { mutableStateOf<String?>(null) }
    var pathaoZoneId by remember { mutableStateOf<String?>(null) }
    var pathaoZoneName by remember { mutableStateOf<String?>(null) }
    var pathaoAreaId by remember { mutableStateOf<String?>(null) }
    var pathaoAreaName by remember { mutableStateOf<String?>(null) }
    var redxAreaId by remember { mutableStateOf<String?>(null) }
    var redxAreaName by remember { mutableStateOf<String?>(null) }
    var courierMenuOpen by remember { mutableStateOf(false) }
    var isSubmitting by remember { mutableStateOf(false) }
    var lastResult by remember { mutableStateOf<String?>(null) }
    var showAddProduct by remember { mutableStateOf(false) }
    // v113-264 — Gift, confirmed with the person directly: a plain text
    // note only, carried on the invoice, never affecting total/discount/
    // stock. `showGiftDialog` is the small entry sheet; `giftNote` is what
    // actually gets submitted with the invoice.
    var showGiftDialog by remember { mutableStateOf(false) }
    var giftNote by remember { mutableStateOf("") }
    // v113-350 — "DUE" | "CASH" | "COD"; the person's point 3.
    var paymentMethod by remember { mutableStateOf("DUE") }
    // v113-255 — the person's own direct instruction: shift Return/Credit
    // Note from a general, dealer-level record into something actually
    // linked to the specific invoice it corrects — was invoiceId=null
    // always, meaning "which invoice was this a correction for" was
    // never captured even though createSalesReturn's own real invoiceId
    // parameter already existed to carry it.
    var showReturnSheet by remember { mutableStateOf(false) }
    var returnForInvoiceId by remember { mutableStateOf<String?>(null) }
    // v113-199 — replaces the old shared top-of-page "Dealer/Product QR বা
    // কোড…" code box: person's confirmed design wants Dealer and Product add
    // as two separate, dedicated affordances, each living in its own
    // section rather than one shared box. These gate the inline
    // search/picker that opens directly under each section's own
    // "Add" button.
    // v113-305 — dealerPickerOpen removed for the same reason;
    // DealerSearchIcon manages its own open/closed state.
    var productPickerOpen by remember { mutableStateOf(false) }
    // v113-162 — person's request: creating and viewing/printing an invoice
    // should feel like one workspace, not a form that navigates away to a
    // different-looking screen. When set, the workspace shows the same
    // branded InvoiceDocumentBody used by the standalone InvoiceDocumentScreen,
    // inline, with its own action row — no navigation, no separate route.
    var viewingInvoiceId by remember { mutableStateOf<String?>(null) }
    // v113-211 — notifies the parent (DmsHomeScreen) whenever this
    // workspace enters/exits "viewing a finished invoice" mode, so it can
    // hide the outer module chrome only for exactly that state, and only
    // in this screen — every other DMS screen is completely unaffected.
    // Also resets on the way out (DisposableEffect) so navigating away
    // mid-view never leaves the chrome permanently hidden.
    LaunchedEffect(viewingInvoiceId) { onViewingDocumentChange(viewingInvoiceId != null) }
    DisposableEffect(Unit) { onDispose { onViewingDocumentChange(false) } }
    val context = LocalContext.current
    var docBusy by remember { mutableStateOf(false) }
    var qrPayloadForPdf by remember(viewingInvoiceId) { mutableStateOf<String?>(null) }

    val dealer = dealers.firstOrNull { it.id == selectedDealerId }
    val dealerInvoices = remember(invoices, selectedDealerId) {
        if (selectedDealerId == null) emptyList()
        else invoices.filter { !it.isDeleted && it.dealerId == selectedDealerId }.sortedByDescending { it.createdAt }
    }
    val subtotal = remember(cart) { cart.sumOf { it.lineTotal } }
    val discountPct = dealerDiscount.toDoubleOrNull() ?: 0.0
    val commissionPct = commission.toDoubleOrNull() ?: 0.0
    // v113-303 — item 8: this live preview used to compute the total with
    // its own unrounded Double formula, so the figure a person watched
    // while building the invoice could differ in the paisa from the one
    // actually stored and later validated by InvoiceCalculationEngine.
    // Now uses the exact same rounding the stored model itself applies
    // (SalesInvoice.total → netAfterDiscount → moneyRound), so what is
    // shown here is precisely what gets saved.
    val total = com.abm.erp.data.moneyRound(subtotal - com.abm.erp.data.moneyRound(subtotal * (discountPct / 100)))
    // v113-264 — the person's own direct question: if an invoice is a
    // draft, HOW does the user find it again to edit it? Traced the real
    // answer first (PROJECT_STATE) — before this, "Edit" only ever
    // surfaced inside a SPECIFIC dealer's own history list, which only
    // renders once that same dealer is re-selected as if starting a new
    // invoice. This is the real fix: every one of the current user's own
    // pending, still-editable invoices (same PENDING + unpaid condition
    // `updateSalesInvoice` itself enforces — matches exactly what the
    // per-dealer Edit button already checked, just not scoped to one
    // dealer), visible right here without selecting anyone first.
    val myPendingInvoices = remember(invoices, dealers) {
        val visibleIds = dealers.map { it.id }.toSet()
        invoices.filter { !it.isDeleted && it.status == "PENDING" && it.paidAmount <= 0.0 && it.dealerId in visibleIds }
            .sortedByDescending { it.createdAt }
    }
    // v113-313 — the person's own point 6: "দুইটা বাটন থাকবে একটা
    // ইন্টারফেসেই। একটা বাটন কে ক্লিক করলে... অ্যাপ্রুভাল পেন্ডিং
    // অপশনগুলো আসবে। সেগুলো এডিট করা যাবে। আরেকটা থাকবে যেটা অ্যাপ্রুভ
    // হয়েছে এবং ওইটার কপি ও প্রিন্ট আউট করা যাবে... অ্যাট লিস্ট এক
    // সপ্তাহের ইনভয়েস এর অপশন গুলো থাকবে।"
    //
    // The real reason this matters, in their own words: "ইনভয়েস যখন
    // আমরা অ্যাপ্রুভ করি দেন আমাদের কোডিং এ ইনভয়েস টা জেনারেট হবে
    // অটোমেটিক্যালি। এখন আমি জেনারেট হচ্ছে কিনা ইনভয়েস টা পরিপূর্ণ
    // দেখতে পারতেছি না।" — an approved invoice (and the QR generated at
    // approval) had nowhere to be viewed from at all. This is that place.
    //
    // One week, counted from the real createdAt, matching their own "অ্যাট
    // লিস্ট এক সপ্তাহের" — a floor, not a cap, so anything newer is
    // always included.
    val myApprovedInvoices = remember(invoices, dealers) {
        val visibleIds = dealers.map { it.id }.toSet()
        // v113-325 — the person's own correction: "Invoice er approve
        // korar por 90 days er deta thakbe." Was 7 days (v113-313, read
        // from their earlier "অ্যাট লিস্ট এক সপ্তাহের" as a floor); they
        // have now set the real figure at 90.
        val cutoff = java.time.LocalDateTime.now().minusDays(90)
        invoices.filter {
            !it.isDeleted && it.status != "PENDING" && it.dealerId in visibleIds && it.createdAt.isAfter(cutoff)
        }.sortedByDescending { it.createdAt }
    }
    var pendingInvoicesExpanded by remember { mutableStateOf(false) }
    // false = Pending (editable), true = Approved (view/print)
    var draftShowingApproved by remember { mutableStateOf(false) }
    // v113-298 — item 3 of the person's 14-point list: "Invoice er draft
    // gula show kora ba edit er jnno invoice UI te ase pase kno button
    // nei" — there was no button anywhere near the Invoice UI for
    // showing/editing drafts. Two real causes, both fixed here: (1) the
    // pending list only rendered at all when something was already
    // pending, so on an empty workspace there was genuinely no button to
    // find; (2) its own "✏ Edit" navigated to `sales?tab=2` — a
    // different screen entirely, which doesn't load that invoice either
    // — so editing never actually worked from here. This holds the
    // invoice currently being edited; non-null means the form below is
    // editing an existing invoice rather than creating a new one.
    var editingInvoiceId by remember { mutableStateOf<String?>(null) }
    // v113-328 — dealerId to dealerName for the stock-count sheet (option "গ").
    val overCredit = dealer != null && (dealer.dueBalance + total) > dealer.creditLimit && dealer.creditLimit > 0
    val canCreate = PermissionManager.canCurrentUser("bill", PermissionAction.CREATE)
    val canApprove = PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)

    // v113-162 — branded header, always visible in both modes, so entering this
    // workspace shows the real invoice branding from the first moment rather than
    // a generic form — matching the person's "click korar sathe sathe pura
    // invoice UI ashbe" request. Same colours/company-name source as
    // InvoiceDocumentBody's own header band, just without the QR/meta rows,
    // since those only make sense once a specific invoice exists.
    val invWsCompany = remember { MockRepository.companySettings() }
    Column(Modifier.fillMaxSize()) {
        // v113-199 — masthead restyled from an orange gradient banner to a
        // plain white header with a logo mark, matching the person's own
        // reference invoice template and the same InvoiceDocumentBody now
        // uses — colour spent only on the logo and the INVOICE label, not a
        // big colour wash. Same DocLogoMark/DocBar primitives as the printed
        // document, so the workspace and the final document read as one
        // continuous thing, not two different looks.
        Row(
            Modifier.fillMaxWidth().background(Color.White).padding(horizontal = Space.lg, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            DocLogoMark(size = 30.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(invWsCompany.companyName.ifBlank { "ABM Corporation" }, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(if (viewingInvoiceId == null) "New Invoice" else "Invoice", color = TextSecondary, fontSize = 10.sp)
            }
            Text("INVOICE", color = DarazOrange, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(HairlineBorder))

        if (viewingInvoiceId == null) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Spacer(Modifier.height(4.dp)) }

        // ── meta block: Invoice#/Date boxed, matching the reference's own meta table ──
        item {
            Row(Modifier.fillMaxWidth().background(Color.White).border(1.dp, HairlineBorder)) {
                Column(Modifier.weight(1f).padding(Space.md)) {
                    DocLabel("Invoice No")
                    DocValue("Draft")
                    Spacer(Modifier.height(Space.sm))
                    DocLabel("Date")
                    DocValue(java.time.LocalDate.now().toString())
                }
            }
        }

        // ── Pending Invoices — the real fix for "draft খুঁজে পাবো কোথায়":
        // every one of the current user's own still-editable invoices,
        // right here, no dealer selection needed first. Collapsed by
        // default (count only) so it costs little space; expands to the
        // real list on tap.
        // v113-298 — now rendered ALWAYS, not only when something is
        // pending: previously an empty pending list meant the whole
        // section (and therefore any draft-related button at all)
        // vanished, which is exactly the "no button anywhere" the person
        // reported. With nothing pending it now shows a real, honest
        // empty state instead of disappearing. ──
        item {
            val shownList = if (draftShowingApproved) myApprovedInvoices else myPendingInvoices
            val anyDrafts = myPendingInvoices.isNotEmpty()
            val draftAccent = if (!anyDrafts) TextSecondary else WarningAmber
            Column(
                Modifier.fillMaxWidth()
                    .background(if (!anyDrafts) Color.White else Color(0xFFFFF8E8), RoundedCornerShape(8.dp))
                    .border(1.dp, if (!anyDrafts) HairlineBorder else WarningAmber.copy(alpha = 0.4f), RoundedCornerShape(8.dp)),
            ) {
                Row(
                    Modifier.fillMaxWidth().clickable { pendingInvoicesExpanded = !pendingInvoicesExpanded }.padding(Space.md),
                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Drafts, contentDescription = null, tint = draftAccent, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Invoice Drafts ও তৈরি হওয়া Invoice",
                            fontWeight = FontWeight.Bold, color = TextPrimary,
                        )
                    }
                    Icon(if (pendingInvoicesExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, contentDescription = null, tint = TextSecondary)
                }
                if (pendingInvoicesExpanded) {
                    // v113-313 — the person's own "দুইটা বাটন থাকবে একটা
                    // ইন্টারফেসেই": Pending (editable) and Approved
                    // (view/print), switched right here rather than being
                    // two separate places to go looking.
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = Space.md),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        listOf(
                            Triple(false, "Approval Pending (${myPendingInvoices.size})", WarningAmber),
                            Triple(true, "তৈরি হয়েছে (${myApprovedInvoices.size})", SuccessGreen),
                        ).forEach { (isApprovedTab, label, tabColor) ->
                            val active = draftShowingApproved == isApprovedTab
                            Box(
                                Modifier.weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (active) tabColor.copy(alpha = 0.15f) else Color.Transparent)
                                    .border(1.dp, if (active) tabColor else HairlineBorder, RoundedCornerShape(8.dp))
                                    .clickable { draftShowingApproved = isApprovedTab }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    label, fontSize = 11.sp,
                                    fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                                    color = if (active) tabColor else TextSecondary,
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    if (shownList.isEmpty()) {
                        Text(
                            if (draftShowingApproved) "গত ৯০ দিনে approve হওয়া কোনো invoice নেই।"
                            else "এখন কোনো draft নেই — invoice জমা দিলে approval-এর আগ পর্যন্ত সেটা এখানে দেখা ও সম্পাদনা করা যাবে।",
                            fontSize = 11.sp, color = TextSecondary,
                            modifier = Modifier.padding(horizontal = Space.md).padding(bottom = Space.md),
                        )
                    } else {
                        Column(Modifier.fillMaxWidth().padding(horizontal = Space.md, vertical = 0.dp)) {
                            shownList.take(20).forEach { inv ->
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text("${inv.invoiceNo} — ${inv.dealerName}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, maxLines = 1)
                                        Text("৳${"%,.0f".format(inv.total)} · ${inv.createdAt.toLocalDate()}", fontSize = 10.sp, color = TextSecondary)
                                    }
                                    if (!draftShowingApproved) {
                                        // v113-298 — real editing: loads this
                                        // invoice's own actual saved values back
                                        // into the form below, so submitting
                                        // updates THIS invoice via the real
                                        // updateSalesInvoice instead of creating
                                        // a second, duplicate one.
                                        TextButton(onClick = {
                                            editingInvoiceId = inv.id
                                            selectedDealerId = inv.dealerId
                                            cart = inv.lineItems
                                            dealerDiscount = if (inv.dealerDiscountPct > 0) inv.dealerDiscountPct.toString() else ""
                                            commission = if (inv.commissionPct > 0) inv.commissionPct.toString() else ""
                                            pendingInvoicesExpanded = false
                                        }) { Text("✏ Edit", fontSize = 12.sp) }
                                    } else {
                                        // v113-313 — an approved invoice is
                                        // final: no Edit. What it needs is what
                                        // the person asked for — seeing the
                                        // generated document (with its
                                        // approval-time QR) and printing it.
                                        // "দেখুন" opens the real
                                        // InvoiceDocumentScreen, which already
                                        // carries its own Print/Share actions.
                                        com.abm.erp.core.StatusPill(inv.status)
                                    }
                                    TextButton(onClick = { viewingInvoiceId = inv.id }) {
                                        Text(if (draftShowingApproved) "দেখুন / প্রিন্ট" else "দেখুন", fontSize = 12.sp)
                                    }
                                }
                                if (inv.id != shownList.take(20).last().id) Divider()
                            }
                            if (shownList.size > 20) {
                                Text("আরও ${shownList.size - 20}টি আছে — dealer বেছে তাদের history থেকে দেখুন।", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.padding(vertical = 6.dp))
                            }
                        }
                    }
                }
            }
        }

        // ── Dealer — bar + boxed content, dedicated Add + Scan buttons
        // (v113-199 — replaces the old shared top-of-page code box; person's
        // confirmed design wants Dealer add as its own dedicated affordance). ──
        item {
            Column(Modifier.fillMaxWidth()) {
                DocBar("Dealer")
                Column(Modifier.fillMaxWidth().background(Color.White).border(1.dp, HairlineBorder).padding(Space.md)) {
                    if (dealer == null) {
                        // v113-305 — item 11 of the person's 14-point list:
                        // "Invoice theke suru kore Pura dms system e joto
                        // Deler sarch button ase oigaula akta akta Deler icon
                        // akare hbe" — every dealer search should collapse to
                        // a single icon that opens a box on tap, freeing
                        // screen space. This was an always-visible button
                        // plus, once opened, a permanently-expanded inline
                        // search field and result list pushing the rest of
                        // the invoice form down. Now one shared
                        // DealerSearchIcon (see core/DealerSearchIcon.kt) —
                        // the same component every other dealer-search
                        // surface in DMS now uses.
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            com.abm.erp.core.DealerSearchIcon(
                                dealers = dealers,
                                onPick = { d -> selectedDealerId = d.id },
                                emptyText = "আপনার এলাকায় মেলেনি।",
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("Dealer বাছুন", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = { onNavigate("universal_scanner") }) {
                                Icon(Icons.Filled.QrCodeScanner, contentDescription = "Scan", tint = TextPrimary)
                            }
                            // v113-264 — the person's own direct instruction:
                            // adding a brand-new dealer mid-invoice doesn't
                            // belong here — that's DMS's own Dealer Add
                            // workflow, a separate, real approval-gated
                            // process, not something to shortcut into from
                            // inside an in-progress invoice. Removed; dealer
                            // search + QR scan (both already real ways to
                            // find an EXISTING dealer) are what stays.
                        }
                    } else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                DocValue(dealer.name)
                                Text(dealer.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                            TextButton(onClick = { selectedDealerId = null }) { Text("বদলান") }
                        }
                        // v113-264 — the person's own direct instruction:
                        // this should live-track against the dealer's real
                        // ledger the same way the final printed invoice
                        // already does (Previous Due / This Invoice /
                        // Total Due), not just a single static "Outstanding
                        // Due" number — and it should update as the cart
                        // changes, not only after submitting. `total` is
                        // the exact same live cart total (subtotal minus
                        // discount) the Invoice Summary section below
                        // already computes — reused, not recalculated a
                        // second way.
                        // v113-314 — the person's own point 5: "যদি কোনো
                        // ডিলারের যে প্রিভিয়াস ডিউ এর সাথে মিল করে একদম
                        // লাইভ ডিউ টা এবং নতুন ইনভয়েস এর ভ্যালু টা
                        // ক্যালকুলেট করবে সেটা ঠিক আছে কিনা।"
                        //
                        // Traced the whole chain first. The arithmetic was
                        // already correct: creation posts nothing to due,
                        // approval posts exactly `domain.total` (the same
                        // moneyRound'd value shown here as "This Invoice"),
                        // and `dealer.dueBalance` is genuinely live via
                        // rememberVisibleDealers' own collectAsState.
                        //
                        // The real, visible defect was in the DISPLAY: all
                        // three figures used "%,.0f" — whole taka, each
                        // rounded independently — so the numbers on screen
                        // could fail to add up. Verified numerically: with
                        // Previous 0.50 and This 0.50, the screen read
                        // "৳0 + ৳0 = ৳1"; with 333.33 + 333.33 it read
                        // "৳333 + ৳333 = ৳667". That is exactly the
                        // "মিল করে" (adding up / matching) the person was
                        // asking about. Now shown to 2 decimals, so
                        // Previous + This always visibly equals Total.
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Previous Due", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("৳${"%,.2f".format(dealer.dueBalance)}", color = TextPrimary)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("This Invoice", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("৳${"%,.2f".format(total)}", color = TextPrimary)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Due (এই invoice সহ)", style = MaterialTheme.typography.labelSmall, color = TextSecondary, fontWeight = FontWeight.Bold)
                            Text("৳${"%,.2f".format(com.abm.erp.data.moneyRound(dealer.dueBalance + total))}", fontWeight = FontWeight.Bold, color = if (dealer.dueBalance + total > 0) WarningAmber else SuccessGreen)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Credit Limit", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("৳${"%,.2f".format(dealer.creditLimit)}", color = TextPrimary)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Available Credit", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("৳${"%,.2f".format((dealer.creditLimit - dealer.dueBalance).coerceAtLeast(0.0))}", color = TextPrimary)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("History (invoice)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${dealerInvoices.size} টি · ৳${"%,.0f".format(dealerInvoices.sumOf { it.total })}", color = TextPrimary)
                        }
                        // v113-346 — the person's own instruction: "invoice
                        // korar smy je Deler er stcok er biosyta ase ata
                        // cancel koro." The stock-count prompt that v113-328
                        // put here is gone. Raising an invoice and auditing a
                        // dealer's shelf are two different jobs, and mixing
                        // them invited a count to be entered casually mid-
                        // order. Stock counting now lives only where it
                        // belongs — the Stock screen — and goes through
                        // approval.
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // v113-264 — the person's own direct instruction:
                            // this button ("Full Details →", routing away to
                            // the dealer's own separate Ledger/Detail
                            // screen) was exactly the "clicking Ledger takes
                            // me away from the invoice I'm building" problem
                            // — not useful mid-invoice. Removed; the real
                            // due context is now live, inline, above
                            // (Previous/This/Total Due) instead of a
                            // navigation link to go look it up elsewhere.
                            TextButton(onClick = { returnForInvoiceId = null; showReturnSheet = true }) { Text("Damage/Return") }
                        }
                        // v113-141 — dealer location right inside the invoice workspace.
                        // v113-268 — the person's own direct request, backed by a real
                        // reference screenshot: this only ever used `address` as a text
                        // SEARCH query, even after Dealer gained real lat/lng capture
                        // (confirmed directly — Dealer.lat/lng already existed; the gap
                        // was this button never checking them). Now prioritises the real
                        // captured coordinate for a precise pin — the exact same
                        // `google.navigation:q=lat,lng` → `geo:lat,lng` → Toast chain
                        // Retailer's own equivalent button already proved — falling back
                        // to the address-text search only for a dealer with no GPS
                        // captured yet (older records, or one added before this).
                        if ((dealer.lat != null && dealer.lng != null) || dealer.address.isNotBlank()) {
                            val invNavContext = androidx.compose.ui.platform.LocalContext.current
                            Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Text(
                                    if (dealer.lat != null && dealer.lng != null) "📍 ${"%.5f".format(dealer.lat)}, ${"%.5f".format(dealer.lng)}" else "📍 ${dealer.address}",
                                    style = MaterialTheme.typography.labelSmall, color = TextSecondary, modifier = Modifier.weight(1f),
                                )
                                // v113-321 — was a hand-rolled copy of the same
                                // intent chain; now the one shared openMapsFor.
                                TextButton(onClick = {
                                    com.abm.erp.core.openMapsFor(invNavContext, dealer.lat, dealer.lng, dealer.address)
                                }) { Text("Map") }
                            }
                        }
                    }
                }
            }
        }

        // ── item table — bar + real bordered grid; "+ Add Product" is the
        // table's own last row (v113-199 — moved here from a separate
        // section above the cart, per the person's confirmed design: the
        // whole page is already the real invoice, and product-add lives
        // directly in the table it fills). ──
        item {
            Column(Modifier.fillMaxWidth()) {
                DocBar("Invoice Items")
                Column(Modifier.fillMaxWidth().border(1.dp, HairlineBorder)) {
                    Row(Modifier.fillMaxWidth().background(DarazOrange)) {
                        ThGrid("#", 0.08f); ThGrid("Item", 0.34f); ThGrid("Qty", 0.20f, TextAlign.End)
                        ThGrid("Rate", 0.19f, TextAlign.End); ThGrid("Amount", 0.19f, TextAlign.End)
                    }
                    cart.forEachIndexed { idx, line ->
                        Row(
                            Modifier.fillMaxWidth().background(if (idx % 2 == 1) Color(0xFFF7F8FA) else Color.White),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            TdGrid("%02d".format(idx + 1), 0.08f)
                            Column(Modifier.weight(0.34f).border(0.5.dp, HairlineBorder).padding(horizontal = 6.dp, vertical = 7.dp)) {
                                Text(line.name, color = TextPrimary, fontSize = 11.sp, maxLines = 1)
                            }
                            Row(Modifier.weight(0.20f).border(0.5.dp, HairlineBorder).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                                IconButton(onClick = { if (line.qty > 1) cart = cart.toMutableList().also { it[idx] = line.copy(qty = line.qty - 1) } }, modifier = Modifier.size(20.dp)) { Icon(Icons.Filled.RemoveCircleOutline, null, tint = TextSecondary, modifier = Modifier.size(14.dp)) }
                                Text("${line.qty}", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                                IconButton(onClick = { cart = cart.toMutableList().also { it[idx] = line.copy(qty = line.qty + 1) } }, modifier = Modifier.size(20.dp)) { Icon(Icons.Filled.AddCircleOutline, null, tint = TextSecondary, modifier = Modifier.size(14.dp)) }
                            }
                            // v113-330 — the person's own instruction:
                            // "Invoice e product er value jeta deoa thake
                            // oita to base value but sob party to r ak rate
                            // Hy na tai invoice korar smy value customize
                            // kore option thaka ucit."
                            //
                            // The unit price was fixed, read-only text taken
                            // from the product's `defaultUnitPrice`, so a
                            // dealer on a different rate could not be
                            // invoiced correctly at all. Now editable per
                            // line, per invoice.
                            //
                            // Set fresh every time, by their own decision
                            // when asked: nothing is remembered against the
                            // dealer, so a rate given once can never quietly
                            // become that dealer's permanent price.
                            //
                            // Blank is allowed while typing (clearing the
                            // field to retype shouldn't fight the person);
                            // it reads as 0 and the total updates honestly,
                            // rather than snapping back to the base price
                            // and hiding the edit.
                            Row(Modifier.weight(0.19f).border(0.5.dp, HairlineBorder).padding(horizontal = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                BasicTextField(
                                    value = if (line.unitPrice == 0.0) "" else "%.0f".format(line.unitPrice),
                                    onValueChange = { typed ->
                                        val cleaned = typed.filter { ch -> ch.isDigit() || ch == '.' }.take(9)
                                        cart = cart.toMutableList().also {
                                            it[idx] = line.copy(unitPrice = cleaned.toDoubleOrNull() ?: 0.0)
                                        }
                                    },
                                    textStyle = androidx.compose.ui.text.TextStyle(
                                        fontSize = 11.sp, color = TextPrimary,
                                        textAlign = TextAlign.End, fontWeight = FontWeight.SemiBold,
                                    ),
                                    singleLine = true,
                                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                        keyboardType = androidx.compose.ui.text.input.KeyboardType.Number,
                                    ),
                                    modifier = Modifier.weight(1f).padding(vertical = 7.dp),
                                    decorationBox = { inner ->
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("৳", fontSize = 10.sp, color = TextSecondary)
                                            Box(Modifier.weight(1f)) { inner() }
                                        }
                                    },
                                )
                            }
                            Row(Modifier.weight(0.19f).border(0.5.dp, HairlineBorder).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
                                Text("৳${"%,.0f".format(line.lineTotal)}", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                                IconButton(onClick = { cart = cart.filterIndexed { i, _ -> i != idx } }, modifier = Modifier.size(18.dp)) { Icon(Icons.Filled.Close, null, tint = DangerRed, modifier = Modifier.size(12.dp)) }
                            }
                        }
                    }
                    if (!productPickerOpen) {
                        // v113-275 — matching the same premium treatment
                        // as the product rows themselves below.
                        OutlinedButton(
                            onClick = { productPickerOpen = true }, modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF2563EB)),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF2563EB).copy(alpha = 0.4f)),
                            shape = RoundedCornerShape(10.dp),
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Add Product", fontWeight = FontWeight.SemiBold)
                        }
                    } else {
                        Column(Modifier.fillMaxWidth().background(Color(0xFFF7F8FA)).padding(Space.sm)) {
                            OutlinedTextField(
                                value = productQuery, onValueChange = { productQuery = it },
                                placeholder = { Text("Product নাম/SKU…") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                            )
                            val categories = remember(products) { products.filter { !it.isDeleted && it.isActive }.map { it.category }.distinct().sorted() }
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FilterChip(selected = categoryFilter == null, onClick = { categoryFilter = null }, label = { Text("সব") })
                                categories.forEach { c -> FilterChip(selected = categoryFilter == c, onClick = { categoryFilter = c }, label = { Text(c) }) }
                            }
                            val productMatches = remember(products, productQuery, categoryFilter) {
                                products.filter {
                                    !it.isDeleted && it.isActive &&
                                        (categoryFilter == null || it.category == categoryFilter) &&
                                        (productQuery.isBlank() || it.name.contains(productQuery, true) || it.sku.contains(productQuery, true))
                                }.take(6)
                            }
                            productMatches.forEach { p ->
                                val onHand = stockLevels.filter { it.productId == p.id }.sumOf { it.quantityOnHand }
                                // v113-275 — the person's own direct
                                // complaint: this still read as "সাদা
                                // সিধে" (plain white, simple) even with a
                                // photo added — a real card treatment
                                // (white surface distinct from the grey
                                // picker background, rounded border, a
                                // coloured ring around the photo matching
                                // the same "boxy premium" language already
                                // applied to Dealer List rows) for a more
                                // deliberately designed feel, not a bigger
                                // functional change.
                                Surface(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                                        .clickable {
                                            cart = cart + SalesInvoiceLineItem(p.id, p.name, p.unit, 1, p.defaultUnitPrice)
                                            productPickerOpen = false; productQuery = ""
                                        },
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color.White,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, HairlineBorder),
                                ) {
                                    Row(
                                        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            if (!p.photoUri.isNullOrBlank()) {
                                                coil.compose.AsyncImage(
                                                    model = p.photoUri, contentDescription = p.name,
                                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                                    modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)).border(1.5.dp, Color(0xFF2563EB).copy(alpha = 0.35f), RoundedCornerShape(8.dp)),
                                                )
                                            } else {
                                                Box(
                                                    Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF2563EB).copy(alpha = 0.08f)),
                                                    contentAlignment = Alignment.Center,
                                                ) { Icon(Icons.Filled.Inventory2, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(20.dp)) }
                                            }
                                            Spacer(Modifier.width(10.dp))
                                            Column {
                                            Text(p.name, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            Text(
                                                "৳${"%,.0f".format(p.defaultUnitPrice)}/${p.unit}",
                                                style = MaterialTheme.typography.labelSmall, color = Color(0xFF2563EB), fontWeight = FontWeight.Bold,
                                            )
                                            Text(
                                                if (onHand <= 0) "স্টক নেই" else "স্টক ${"%,.0f".format(onHand)}",
                                                style = MaterialTheme.typography.labelSmall, color = if (onHand <= 0) DangerRed else TextSecondary,
                                            )
                                        }
                                    }
                                    Box(
                                        Modifier.size(30.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF2563EB)),
                                        contentAlignment = Alignment.Center,
                                    ) { Icon(Icons.Filled.Add, contentDescription = "Add", tint = Color.White, modifier = Modifier.size(18.dp)) }
                                }
                            }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                // v113-141 — shown only if they genuinely hold inv-CREATE rights,
                                // unchanged from before.
                                if (com.abm.erp.data.PermissionManager.canCurrentUser("inv", com.abm.erp.data.PermissionAction.CREATE)) {
                                    TextButton(onClick = { showAddProduct = true }) { Text("+ New Product") }
                                }
                                TextButton(onClick = { productPickerOpen = false; productQuery = "" }) { Text("বন্ধ করুন") }
                            }
                        }
                    }
                }
            }
        }

        // ── Offer / Discount / Commission — the person's own direct
        // instruction: this was one big full-width bordered box; made
        // visibly smaller/compact here (tighter padding, smaller field
        // text) — same real fields, same real logic, just less space. ──
        item {
            Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(8.dp)).border(1.dp, HairlineBorder, RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 8.dp)) {
                Text("Offer · Discount · Commission", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                val activeOffers = remember(discountRules, selectedDealerId) {
                    discountRules.filter { it.isActive && (it.scope == "ALL" || it.scope == selectedDealerId) }
                }
                if (activeOffers.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        activeOffers.forEach { rule ->
                            AssistChip(
                                onClick = { dealerDiscount = rule.discountPct.toString() },
                                label = { Text("${rule.label} ${rule.discountPct}%", fontSize = 11.sp) },
                            )
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = dealerDiscount, onValueChange = { dealerDiscount = it },
                        label = { Text("Discount %", fontSize = 11.sp) }, singleLine = true,
                        textStyle = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f).height(52.dp),
                    )
                    OutlinedTextField(
                        value = commission, onValueChange = { commission = it },
                        label = { Text("Commission %", fontSize = 11.sp) }, singleLine = true,
                        textStyle = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f).height(52.dp),
                    )
                }
            }
        }

        // ── Courier / Vehicle / Gift — split out from Offer/Discount/
        // Commission above (a different concern; keeping them in one box
        // was part of why that box felt oversized) ──
        item {
            Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(8.dp)).border(1.dp, HairlineBorder, RoundedCornerShape(8.dp)).padding(Space.md)) {
                // v113-275 — the person's own direct instruction: this
                // doesn't need a big, full-width space — a small icon
                // button (a car/truck drawn on it) is enough; tapping it
                // opens the real courier/vehicle picker directly.
                // v113-297 — the person's own follow-up (item 2 of the
                // 14-point list): the icon-only trigger read as "গাড়ি
                // দেওয়া কিন্তু practical না" — the truck glyph alone
                // didn't communicate that a real courier is also a
                // choice, and the selection itself sat in a small label
                // off to the side. Reviewed four alternatives with the
                // person in a JSX mockup first; they chose Option A:
                // keep one single trigger, but make it a real full-width
                // row with the current selection as its own primary
                // label, a delivery-neutral parcel icon instead of a
                // truck, and a real chevron so it reads as openable.
                // Same DropdownMenu underneath, unchanged.
                val courierSelected = selectedCourierId != null || selectedVehicleId != null
                val courierAccent = Color(0xFF2563EB)
                Box {
                    Row(
                        Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (courierSelected) courierAccent.copy(alpha = 0.05f) else Color.White)
                            .border(1.dp, if (courierSelected) courierAccent else HairlineBorder, RoundedCornerShape(10.dp))
                            .clickable { courierMenuOpen = true }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            Icons.Filled.Inventory2, contentDescription = "Courier / গাড়ি বাছুন",
                            tint = if (courierSelected) courierAccent else TextSecondary,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            allCouriers.firstOrNull { it.id == selectedCourierId }?.name
                                ?: allVehicles.firstOrNull { it.id == selectedVehicleId }?.let { "নিজস্ব গাড়ি — ${it.registrationNo}" }
                                ?: "ডেলিভারি মাধ্যম বাছুন",
                            color = if (courierSelected) courierAccent else TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f),
                        )
                        Icon(
                            Icons.Filled.ExpandMore, contentDescription = null,
                            tint = TextSecondary, modifier = Modifier.size(18.dp),
                        )
                    }
                    DropdownMenu(expanded = courierMenuOpen, onDismissRequest = { courierMenuOpen = false }) {
                        DropdownMenuItem(text = { Text("কোনো courier/গাড়ি না") }, onClick = { selectedCourierId = null; selectedVehicleId = null; courierMenuOpen = false })
                        if (allCouriers.isNotEmpty()) {
                            Text("Courier", style = MaterialTheme.typography.labelSmall, color = TextSecondary, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
                            allCouriers.forEach { c ->
                                DropdownMenuItem(text = { Text(c.name) }, onClick = { selectedCourierId = c.id; selectedVehicleId = null; courierMenuOpen = false })
                            }
                        }
                        if (allVehicles.isNotEmpty()) {
                            Text("নিজস্ব গাড়ি", style = MaterialTheme.typography.labelSmall, color = TextSecondary, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
                            allVehicles.filter { it.isActive }.forEach { v ->
                                DropdownMenuItem(text = { Text("${v.registrationNo} — ${v.driverName.ifBlank { "চালক নেই" }}") }, onClick = { selectedVehicleId = v.id; selectedCourierId = null; courierMenuOpen = false })
                            }
                        }
                    }
                }
                if (selectedCourierId != null || selectedVehicleId != null) {
                    Spacer(Modifier.height(6.dp))
                    // v113-249 — the person's own direct, sharp catch: the
                    // dealer's address is dealer information, not courier
                    // information — it shouldn't be gated behind a
                    // courier/vehicle selection. It was already shown
                    // right after dealer selection above (📍, with a real
                    // map-navigation button) before this courier work ever
                    // started — this duplicate display here was
                    // unnecessary and confusing.
                    //
                    // v113-349 — the weight/condition fields are removed too,
                    // on the person's direct instruction: "koto kg condition
                    // vanga aisob ojotha jinis othe aisob jinis bad jabe".
                    // They existed for the courier API booking call deleted in
                    // v113-338; with no API to send them to, they were pure
                    // typing for nothing. Only the courier SELECTION stays —
                    // the invoice still records who carries it (v113-338's own
                    // scope: "sudu invoice e mention thakbe").
                    // v113-338 — the Pathao/RedX area-picker trigger is
                    // removed with the API integration; those codes only ever
                    // mattered for an API booking call that no longer happens.
                    // The dealer's own real address stays on the invoice,
                    // which is what a courier actually needs from it.
                }
                Spacer(Modifier.height(6.dp))
                // v113-264 — Gift, enabled: the person's own confirmed
                // scope — a plain manual note only ("এত পিস গিফট দেওয়া
                // হলো", "এটা damage"), no financial rule, never touches
                // total/discount/stock. Real, functional now instead of
                // permanently disabled.
                // v113-350 — payment method, the person's point 3: "Invoice e
                // due. Paid. cash on delevry method ase kina chek koro na
                // thakle koro." It did NOT exist — no field, no selector.
                // Three chips; COD explicitly says it never touches the due
                // ledger, so nobody picks it expecting a due entry.
                Text("Payment method", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = paymentMethod == "DUE", onClick = { paymentMethod = "DUE" }, label = { Text("Due (বাকি)") })
                    FilterChip(selected = paymentMethod == "CASH", onClick = { paymentMethod = "CASH" }, label = { Text("Paid (নগদ)") })
                    FilterChip(selected = paymentMethod == "COD", onClick = { paymentMethod = "COD" }, label = { Text("COD") })
                }
                if (paymentMethod == "COD") {
                    Text("COD: due ledger-এ কিছু যাবে না — delivery confirm হলে auto PAID।", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                }
                AssistChip(
                    onClick = { showGiftDialog = true },
                    leadingIcon = { Icon(Icons.Filled.CardGiftcard, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text(if (giftNote.isBlank()) "Gift / Note যোগ করুন" else "Gift: ${giftNote.take(30)}${if (giftNote.length > 30) "…" else ""}") },
                )
            }
        }

        // ── summary — boxed rows + ledger rule above Total, matching the
        // reference (no heavy gradient banner; no tax line since the real
        // model has none) ──
        item {
            Column(Modifier.fillMaxWidth().background(Color.White).border(1.dp, HairlineBorder).padding(Space.md)) {
                Text("Invoice Summary", fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(Space.sm))
                // v113-314 — same display fix as the Due card above: whole-
                // taka formatting meant Subtotal − Discount could visibly
                // fail to equal Total. The Discount row also showed only a
                // percentage, never the actual taka it removed, so there
                // was no way to check the arithmetic by eye at all. Both
                // now show real amounts at 2 decimals, using the same
                // moneyRound the stored invoice itself applies.
                val discountAmt = com.abm.erp.data.moneyRound(subtotal * (discountPct / 100))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Subtotal", color = TextSecondary); Text("৳${"%,.2f".format(subtotal)}", color = TextPrimary)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Discount ($discountPct%)", color = TextSecondary)
                    Text("−৳${"%,.2f".format(discountAmt)}", color = TextPrimary)
                }
                Spacer(Modifier.height(Space.xs))
                Box(Modifier.fillMaxWidth().height(1.dp).background(TextSecondary))
                Spacer(Modifier.height(Space.xs))
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Total", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("৳${"%,.2f".format(total)}", color = DarazOrange, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                }
                if (overCredit) {
                    Text(
                        "⚠ Credit limit ছাড়িয়ে যাবে (Due ৳${"%,.0f".format(dealer!!.dueBalance)} + এই invoice > limit ৳${"%,.0f".format(dealer.creditLimit)}) — জমা দিলে reject হবে।",
                        color = WarningAmber, style = MaterialTheme.typography.labelSmall,
                    )
                }
                if (!canCreate) {
                    Text("আপনার role-এ invoice create অনুমতি নেই।", color = DangerRed, style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(Space.sm))
                // v113-298 — when editing an existing draft (loaded via
                // the Draft section's own "✏ Edit"), submitting must
                // UPDATE that invoice through the real
                // updateSalesInvoice, not create a second duplicate one
                // via createSalesInvoice. Same branch shape
                // RmsMemoWorkspace's own edit flow already proved
                // (v113-270) — checked against that real implementation
                // rather than inventing a different pattern here.
                if (editingInvoiceId != null) {
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = Space.xs),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("✏ Draft সম্পাদনা করছেন", style = MaterialTheme.typography.labelSmall, color = WarningAmber, fontWeight = FontWeight.Bold)
                        TextButton(onClick = {
                            editingInvoiceId = null
                            cart = emptyList(); dealerDiscount = ""; commission = ""; selectedDealerId = null
                        }) { Text("বাতিল", fontSize = 12.sp) }
                    }
                }
                Button(
                    onClick = {
                        val d = dealer ?: return@Button
                        isSubmitting = true
                        lastResult = null
                        val editId = editingInvoiceId
                        if (editId != null) {
                            val ok = MockRepository.updateSalesInvoice(
                                invoiceId = editId, lineItems = cart,
                                dealerDiscountPct = discountPct, commissionPct = commissionPct,
                                courier = allCouriers.firstOrNull { it.id == selectedCourierId }?.name
                                    ?: allVehicles.firstOrNull { it.id == selectedVehicleId }?.registrationNo,
                                onRejected = { reason -> lastResult = "✖ $reason" },
                            )
                            if (ok) {
                                lastResult = "✔ Draft হালনাগাদ হয়েছে।"
                                editingInvoiceId = null
                                cart = emptyList(); dealerDiscount = ""; commission = ""; selectedCourierId = null; selectedVehicleId = null; paymentMethod = "DUE"
                                giftNote = ""
                                viewingInvoiceId = editId
                            } else if (lastResult == null) {
                                lastResult = "✖ হালনাগাদ হয়নি — কারণ জানা যায়নি, আবার চেষ্টা করুন।"
                            }
                            isSubmitting = false
                            return@Button
                        }
                        val ok = MockRepository.createSalesInvoice(
                            dealerId = d.id, dealerName = d.name, dealerZone = d.zone,
                            lineItems = cart, dealerDiscountPct = discountPct, commissionPct = commissionPct,
                            courier = allCouriers.firstOrNull { it.id == selectedCourierId }?.name
                                ?: allVehicles.firstOrNull { it.id == selectedVehicleId }?.registrationNo,
                            pathaoCityId = pathaoCityId, pathaoZoneId = pathaoZoneId, pathaoAreaId = pathaoAreaId, redxAreaId = redxAreaId,
                            signedByRole = null,
                            paymentMethod = paymentMethod,
                            giftNote = giftNote.trim().ifBlank { null },
                            onRejected = { reason -> lastResult = "✖ $reason" },
                        ) { created ->
                            lastResult = "✔ ${created.invoiceNo} তৈরি হয়েছে — Approve হলে courier-এ shipment auto-book হবে।"
                            com.abm.erp.core.SuccessBus.show("Invoice তৈরি সম্পন্ন", "${created.invoiceNo} · ৳${"%,.2f".format(created.total)}")
                            cart = emptyList(); dealerDiscount = ""; commission = ""; selectedCourierId = null; selectedVehicleId = null; paymentMethod = "DUE"
                            pathaoCityId = null; pathaoCityName = null; pathaoZoneId = null; pathaoZoneName = null; pathaoAreaId = null; pathaoAreaName = null; redxAreaId = null; redxAreaName = null
                            giftNote = ""
                            // v113-162 — show the finished, branded invoice immediately instead
                            // of just clearing the form. "← New Invoice" in view mode returns here.
                            viewingInvoiceId = created.id
                        }
                        if (!ok && lastResult == null) {
                            // onRejected already set a specific message for every real
                            // rejection path in createSalesInvoice — this is only a
                            // safety net if some future path returns false without
                            // calling it, so the user is never left with silence.
                            lastResult = "✖ তৈরি হয়নি — কারণ জানা যায়নি, আবার চেষ্টা করুন।"
                        }
                        isSubmitting = false
                    },
                    enabled = dealer != null && cart.isNotEmpty() && canCreate && !isSubmitting,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (isSubmitting) (if (editingInvoiceId != null) "হালনাগাদ হচ্ছে…" else "তৈরি হচ্ছে…") else if (editingInvoiceId != null) "Draft হালনাগাদ করুন" else "Invoice তৈরি করুন") }
                lastResult?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = if (it.startsWith("✔")) SuccessGreen else DangerRed) }
            }
        }

        // ── dealer's invoice history, approve + share, inline ──
        if (dealerInvoices.isNotEmpty()) {
            item { Text("এই dealer-এর Invoice (${dealerInvoices.size})", fontWeight = FontWeight.SemiBold, color = TextPrimary) }
            items(dealerInvoices.take(10), key = { it.id }) { inv ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(inv.invoiceNo, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        com.abm.erp.core.StatusPill(inv.status)
                    }
                    Text("৳${"%,.0f".format(inv.total)} · ${inv.createdAt.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    // v113-249 — the other half of the same fix: this is
                    // where a DMS/sales user actually asks "has this been
                    // shipped yet?" — the courier↔invoice connection means
                    // nothing if it only ever shows up on the courier
                    // screen and never here.
                    val allShipments by MockRepository.shipments.collectAsState()
                    val linkedShipment = remember(allShipments, inv.id) { allShipments.firstOrNull { it.invoiceId == inv.id } }
                    linkedShipment?.let { s ->
                        Text("🚚 Courier: ${s.status.name.replace("_", " ")}", style = MaterialTheme.typography.labelSmall, color = if (s.status == com.abm.erp.data.ShipmentStatus.DELIVERED) SuccessGreen else com.abm.erp.theme.ElectricCyan)
                    }
                    var rowError by remember(inv.id) { mutableStateOf<String?>(null) }
                    rowError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (inv.status == "PENDING" && canApprove) {
                            // was discarding its result entirely — now reports the real reason
                            TextButton(onClick = { MockRepository.approveSalesInvoice(inv.id, onRejected = { r -> rowError = r }) }) { Text("✓ Approve", color = SuccessGreen) }
                        }
                        // v113-142 — Edit where the mistake is actually noticed, instead of
                        // making the person hunt for it. Shown only for invoices genuinely
                        // still editable: PENDING with no payment applied — the exact
                        // condition updateSalesInvoice enforces, so the button never
                        // appears only to be refused. Routes to the sales screen's Invoice
                        // tab (verified: `sales?tab=2`), which already owns the real edit
                        // form — no second editing UI. Checked first that a
                        // `sales_chain?editInvoice=` route does NOT exist rather than
                        // shipping a button pointing at nothing.
                        if (inv.status == "PENDING" && inv.paidAmount <= 0.0) {
                            TextButton(onClick = { onNavigate("sales?tab=2") }) { Text("✏ Edit") }
                        }
                        // v113-255 — the actual invoice-linked correction
                        // path: shown once an invoice is APPROVED (the
                        // point PENDING-edit is no longer available),
                        // opening the same real return sheet but now
                        // carrying which specific invoice this correction
                        // is for.
                        if (inv.status == "APPROVED") {
                            TextButton(onClick = { returnForInvoiceId = inv.id; showReturnSheet = true }) { Text("↩ Return/Credit", color = WarningAmber) }
                        }
                        TextButton(onClick = { viewingInvoiceId = inv.id }) { Text("Print/Share") }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
        } else {
            // ── view mode: same branded document InvoiceDocumentScreen uses,
            // rendered inline — no navigation, no separate screen. ──
            val viewedInvoice = invoices.firstOrNull { it.id == viewingInvoiceId }
            if (viewedInvoice == null) {
                Column(Modifier.weight(1f).fillMaxWidth().padding(Space.lg)) {
                    Text("এই ইনভয়েসটি পাওয়া যায়নি।", color = TextSecondary)
                    TextButton(onClick = { viewingInvoiceId = null }) { Text("← ফিরে যান") }
                }
            } else {
                Column(Modifier.weight(1f).imePadding().verticalScroll(rememberScrollState()).padding(Space.md)) {
                    com.abm.erp.ui.invoice.InvoiceDocumentBody(invoice = viewedInvoice, onQrPayloadReady = { qrPayloadForPdf = it })
                    Spacer(Modifier.height(Space.lg))
                }
                Row(
                    Modifier.fillMaxWidth().padding(Space.md),
                    horizontalArrangement = Arrangement.spacedBy(Space.sm),
                ) {
                    Box(Modifier.weight(1f)) {
                        com.abm.erp.core.SecondaryButton("← New Invoice", onClick = { viewingInvoiceId = null })
                    }
                    Box(Modifier.weight(1f)) {
                        com.abm.erp.core.SecondaryButton("Share", onClick = {
                            // v113-354 — bespoke invoice document (see
                            // InvoiceDocumentScreen's Share note); old summary-image
                            // path kept as fallback.
                            scope.launch {
                                runCatching {
                                    val qr = qrPayloadForPdf?.takeIf { viewedInvoice.isApprovedOrLater }
                                        ?: com.abm.erp.data.QrRegistry.payloadForApproved("SalesInvoice", viewedInvoice.id, viewedInvoice.isApprovedOrLater)
                                    com.abm.erp.core.shareStyledDocumentImage(
                                        context, "Invoice ${viewedInvoice.invoiceNo}",
                                        com.abm.erp.core.renderInvoiceDocumentBitmap(viewedInvoice, qr),
                                    )
                                }.onFailure {
                                    val summary = "Invoice ${viewedInvoice.invoiceNo}\n${viewedInvoice.dealerName}\nTotal: ৳${"%,.2f".format(viewedInvoice.total)}\nStatus: ${viewedInvoice.status}\nPayment: ${when (viewedInvoice.paymentMethod) { "CASH" -> "Paid (নগদ)"; "COD" -> "Cash on Delivery"; else -> "Due (বাকি)" }}"
                                    runCatching { com.abm.erp.core.shareTextSummary(context, "Share invoice", summary) }
                                        .onFailure { android.widget.Toast.makeText(context, "Share করার মতো app পাওয়া যায়নি।", android.widget.Toast.LENGTH_LONG).show() }
                                }
                            }
                        }, icon = Icons.Filled.Share)
                    }
                    Box(Modifier.weight(1.2f)) {
                        com.abm.erp.core.PrimaryButton(
                            text = if (docBusy) "…" else "Print / PDF",
                            icon = Icons.Filled.Print,
                            loading = docBusy,
                            onClick = {
                                docBusy = true
                                scope.launch {
                                    runCatching {
                                        // v113-349 — QR only for an APPROVED invoice, through the one
                                        // shared gate. Fixes two real faults at once:
                                        //  1. A DRAFT's PDF minted a real QR (the person's report:
                                        //     "pending er invoice whatpp e share dile qr dekha jay").
                                        //  2. An approved invoice whose QR already existed REFUSED to
                                        //     print at all ("Reissue QR" toast) — with the payload now
                                        //     stored (v113-326) it is simply reused instead.
                                        // v113-354 — same gate as the Share path: the on-screen
                                        // control fills qrPayloadForPdf ungated (activeFor).
                                        val payload = qrPayloadForPdf?.takeIf { viewedInvoice.isApprovedOrLater }
                                            ?: com.abm.erp.data.QrRegistry.payloadForApproved(
                                                "SalesInvoice", viewedInvoice.id, viewedInvoice.isApprovedOrLater,
                                            )?.also { qrPayloadForPdf = it }
                                        if (payload == null && viewedInvoice.isApprovedOrLater) {
                                            // Approved but the payload predates v113-326 — only the
                                            // Chairman repair path may reissue (it revokes the printed copy).
                                            android.widget.Toast.makeText(
                                                context,
                                                "পুরনো QR — code সংরক্ষিত নেই। Chairman panel থেকে নতুন QR issue করলে PDF-এ QR আসবে।",
                                                android.widget.Toast.LENGTH_LONG,
                                            ).show()
                                        }
                                        // payload == null on a draft is the intended state: the PDF
                                        // renders with a DRAFT watermark and no QR, and still exports.
                                        run {
                                            val file = com.abm.erp.core.exportSalesInvoicePdf(context, viewedInvoice, payload)
                                            val uri = androidx.core.content.FileProvider.getUriForFile(
                                                context, "${context.packageName}.fileprovider", file,
                                            )
                                            val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                                type = "application/pdf"
                                                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(android.content.Intent.createChooser(i, "Invoice PDF"))
                                        }
                                    }.onFailure { e ->
                                        // v113-211 — surface the real exception in
                                        // debug/staging (same diagnostic discipline as
                                        // the earlier login investigation) instead of
                                        // only ever showing a generic message — if the
                                        // QR-isolation fix in exportSalesInvoicePdf
                                        // doesn't fully resolve this, the next report
                                        // carries the actual cause, not just "failed".
                                        com.abm.erp.config.AppLog.w("DmsInvoiceWorkspace", "PDF export/share failed", e)
                                        val msg = if (com.abm.erp.config.AppEnvironment.isDebugOrStaging) "PDF তৈরি করা যায়নি: ${e.javaClass.simpleName} — ${e.message}" else "PDF তৈরি করা যায়নি।"
                                        android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()
                                    }
                                    docBusy = false
                                }
                            },
                        )
                    }
                }
            }
        }
    }

    // ── helper sheets (contract: helpers are dialogs, never navigation) ──
    if (showGiftDialog) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showGiftDialog = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                var draft by remember { mutableStateOf(giftNote) }
                Column(Modifier.padding(16.dp)) {
                    Text("Gift / Note", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(
                        "টাকা বা স্টকের হিসাবে কোনো প্রভাব পড়বে না — শুধু invoice-এর সাথে সংরক্ষিত থাকবে। যেমনঃ \"২ পিস গিফট দেওয়া হলো\", \"১টা ড্যামেজড, বদলে দেওয়া হয়েছে\"।",
                        style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = draft, onValueChange = { draft = it },
                        placeholder = { Text("যেমনঃ ২ পিস ABM Tea Classic গিফট") },
                        minLines = 2, modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { giftNote = draft.trim(); showGiftDialog = false }) { Text("সংরক্ষণ করুন") }
                        if (giftNote.isNotBlank()) {
                            OutlinedButton(onClick = { giftNote = ""; showGiftDialog = false }) { Text("মুছে ফেলুন", color = DangerRed) }
                        }
                        TextButton(onClick = { showGiftDialog = false }) { Text("বাতিল") }
                    }
                }
            }
        }
    }
    if (showAddProduct) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showAddProduct = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                var pName by remember { mutableStateOf("") }
                var pSku by remember { mutableStateOf("") }
                var pUnit by remember { mutableStateOf("pcs") }
                var pCategory by remember { mutableStateOf("") }
                var pPrice by remember { mutableStateOf("") }
                var pError by remember { mutableStateOf<String?>(null) }
                Column(Modifier.padding(16.dp).imePadding()) {
                    Text("নতুন Product", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("যোগ করার সাথে সাথেই এই invoice-এ ব্যবহার করা যাবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    pError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = pName, onValueChange = { pName = it }, label = { Text("নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = pSku, onValueChange = { pSku = it }, label = { Text("SKU") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = pUnit, onValueChange = { pUnit = it }, label = { Text("Unit") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = pPrice, onValueChange = { pPrice = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("দাম") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = pCategory, onValueChange = { pCategory = it }, label = { Text("Category") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            pError = null
                            // Real addProduct — same engine the Inventory screen uses,
                            // with its real duplicate/permission/validation rejections
                            // surfaced here rather than a silent failure.
                            com.abm.erp.data.InventoryRepository.addProduct(
                                sku = pSku.trim(), name = pName.trim(), unit = pUnit.trim().ifBlank { "pcs" },
                                category = pCategory.trim(), reorderThreshold = 0.0,
                                defaultUnitPrice = pPrice.toDoubleOrNull() ?: 0.0,
                                onRejected = { r -> pError = r },
                                onCreated = { showAddProduct = false },
                            )
                        },
                        enabled = pName.isNotBlank() && pSku.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("যোগ করুন") }
                }
            }
        }
    }
    if (showReturnSheet && dealer != null) {
        DealerReturnSheet(dealer = dealer, cartHint = cart, invoiceId = returnForInvoiceId, onDismiss = { showReturnSheet = false; returnForInvoiceId = null }, scope = scope)
    }
    // v113-338 — the Pathao/RedX area-picker dialogs are removed with the
    // courier API integration: they existed only to fetch each partner's
    // own area list from their servers, which no longer happens. Nothing
    // else consumed them.
}

/**
 * Damage/Return helper — a sheet, not a page. Thin UI over the existing
 * `createSalesReturn` engine (which enforces the returnable-qty validation, restocking
 * and due reversal itself; nothing re-implemented here).
 */
@Composable
private fun DealerReturnSheet(
    dealer: com.abm.erp.data.Dealer,
    cartHint: List<SalesInvoiceLineItem>,
    invoiceId: String?,
    onDismiss: () -> Unit,
    scope: kotlinx.coroutines.CoroutineScope,
) {
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    var productId by remember { mutableStateOf<String?>(null) }
    var qty by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<String?>(null) }
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 520.dp)) {
                Text("Damage / Return — ${dealer.name}", fontWeight = FontWeight.Bold, color = TextPrimary)
                if (invoiceId != null) {
                    Text("এই নির্দিষ্ট invoice-এর correction হিসেবে link হবে।", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                }
                Spacer(Modifier.height(8.dp))
                // v113-255 — cartHint existed as a parameter but was never
                // actually used — when returning against a specific
                // invoice, its own real line items are what someone is
                // most likely correcting, so they're offered first as a
                // quick pick, with the full product browser underneath
                // for anything not on that invoice.
                if (invoiceId != null && cartHint.isNotEmpty()) {
                    Text("এই invoice-এর পণ্য", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Column(Modifier.heightIn(max = 100.dp).verticalScroll(rememberScrollState())) {
                        cartHint.forEach { line ->
                            Text(
                                "${line.name} (${line.qty})",
                                fontWeight = if (productId == line.productId) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.fillMaxWidth().clickable { productId = line.productId; qty = line.qty.toString() }.padding(vertical = 6.dp),
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("অথবা যেকোনো পণ্য", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                Column(Modifier.heightIn(max = 160.dp).verticalScroll(rememberScrollState())) {
                    products.filter { !it.isDeleted }.take(20).forEach { p ->
                        Text(
                            p.name,
                            fontWeight = if (productId == p.id) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().clickable { productId = p.id }.padding(vertical = 6.dp),
                        )
                    }
                }
                OutlinedTextField(value = qty, onValueChange = { qty = it }, label = { Text("Qty") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val p = products.firstOrNull { it.id == productId } ?: cartHint.firstOrNull { it.productId == productId }?.let { line ->
                            com.abm.erp.data.Product(id = line.productId, sku = "", name = line.name, unit = line.unit, category = "", reorderThreshold = 0.0, defaultUnitPrice = line.unitPrice)
                        } ?: return@Button
                        val q = qty.toIntOrNull() ?: return@Button
                        scope.launch {
                            result = null
                            val r = MockRepository.createSalesReturn(
                                invoiceId = invoiceId, partyType = com.abm.erp.data.PartyType.DEALER,
                                partyId = dealer.id, partyName = dealer.name,
                                lineItems = listOf(SalesInvoiceLineItem(p.id, p.name, p.unit, q, p.defaultUnitPrice)),
                                reason = reason,
                                onRejected = { rejectReason -> result = "✖ $rejectReason" },
                            )
                            if (r != null) result = "✔ Return ${r.returnNo} তৈরি — approve হলে stock/due ঠিক হবে।"
                            else if (result == null) result = "✖ Return তৈরি হয়নি — আবার চেষ্টা করুন।"
                        }
                    },
                    enabled = productId != null && (qty.toIntOrNull() ?: 0) > 0 && reason.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Return জমা দিন") }
                result?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = if (it.startsWith("✔")) SuccessGreen else DangerRed) }
            }
        }
    }
}
