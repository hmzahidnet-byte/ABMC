package com.abm.erp.ui.courier

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import kotlinx.coroutines.launch

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.GlassCard
import com.abm.erp.core.SubModuleGrid
import com.abm.erp.core.SubModuleItem
import com.abm.erp.core.BackToSubMenuLink
import com.abm.erp.data.MockRepository
import com.abm.erp.data.ShipmentStatus
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.ElectricCyan
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

/** v113-167 — Chairman-only: courier API base URL/key config, previously an
 * inline gate inside CourierScreen's "book" tab (correctly hidden from
 * non-Chairman already, but scattered rather than living in DMS's own
 * Chairman panel). Same dialog, same repository call, new home. */
@Composable
fun CourierApiConfigPanel() {
    val couriers by MockRepository.couriers.collectAsState()
    var configuringCourierId by remember { mutableStateOf<String?>(null) }
    // v113-250 — the real, previously-missing gap: there was no way to
    // add a new courier at all. Chairman-only, matching the permission
    // check inside addCourierPartner itself.
    var showAddCourier by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Courier API Config", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        Text(
            "Pathao / RedX / Steadfast — real credential দিলে real order তৈরি হবে (booking-এর সময়)। এখনো webhook সম্ভব না (এটা mobile app, public server না) — তাই delivery status update করতে হবে হাতে বা refresh করে।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(10.dp))
        Button(onClick = { showAddCourier = true }, modifier = Modifier.fillMaxWidth()) { Text("+ নতুন Courier যোগ করুন") }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(couriers, key = { it.id }) { c ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.name, color = TextPrimary)
                            Text(
                                if (c.hasApi) "Real API সংযুক্ত (${c.courierType})" else "Manual (no API)",
                                color = if (c.hasApi) SuccessGreen else TextSecondary, style = MaterialTheme.typography.labelSmall,
                            )
                        }
                        TextButton(onClick = { configuringCourierId = c.id }) { Text("API…") }
                    }
                }
            }
        }
    }

    configuringCourierId?.let { cid ->
        val courier = couriers.firstOrNull { it.id == cid }
        if (courier != null) {
            androidx.compose.ui.window.Dialog(onDismissRequest = { configuringCourierId = null }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                    var courierType by remember { mutableStateOf(courier.courierType) }
                    var typeMenuOpen by remember { mutableStateOf(false) }
                    var baseUrl by remember { mutableStateOf(courier.apiBaseUrl ?: "") }
                    var apiKey by remember { mutableStateOf(courier.apiKey ?: "") }
                    var apiSecretKey by remember { mutableStateOf(courier.apiSecretKey ?: "") }
                    var apiUsername by remember { mutableStateOf(courier.apiUsername ?: "") }
                    var apiPassword by remember { mutableStateOf(courier.apiPassword ?: "") }
                    var apiStoreId by remember { mutableStateOf(courier.apiStoreId ?: "") }
                    var cfgError by remember { mutableStateOf<String?>(null) }
                    // v113-249 — the person's own direct confirmation:
                    // they're a real merchant at Pathao/RedX/Steadfast and
                    // want the pasted key to actually call the real API.
                    // Each courier's real auth shape is genuinely
                    // different (confirmed directly against each one's
                    // own documentation before writing this) — so the
                    // fields shown change with the selected type, rather
                    // than one generic base-url/key pair pretending to
                    // cover all three.
                    Column(Modifier.padding(16.dp).heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                        Text("${courier.name} — API Config", fontWeight = FontWeight.Bold, color = TextPrimary)
                        cfgError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                        Spacer(Modifier.height(10.dp))
                        Box {
                            OutlinedButton(onClick = { typeMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("Courier Type: $courierType")
                            }
                            DropdownMenu(expanded = typeMenuOpen, onDismissRequest = { typeMenuOpen = false }) {
                                listOf("PATHAO", "REDX", "STEADFAST", "OTHER").forEach { t ->
                                    DropdownMenuItem(text = { Text(t) }, onClick = { courierType = t; typeMenuOpen = false })
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = baseUrl, onValueChange = { baseUrl = it },
                            label = { Text(if (courierType == "STEADFAST") "API Base URL (ফাঁকা রাখলে default ব্যবহার হবে)" else "API Base URL") },
                            singleLine = true, modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(8.dp))
                        when (courierType) {
                            "PATHAO" -> {
                                OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Client ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = apiSecretKey, onValueChange = { apiSecretKey = it }, label = { Text("Client Secret") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = apiUsername, onValueChange = { apiUsername = it }, label = { Text("Username (email)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = apiPassword, onValueChange = { apiPassword = it }, label = { Text("Password") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = apiStoreId, onValueChange = { apiStoreId = it }, label = { Text("Store ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "city_id/zone_id/area_id booking-এর সময় ম্যানুয়ালি দিতে হবে — এই app-এর নিজস্ব location আর Pathao-এর নিজস্ব code এখনো সংযুক্ত না।",
                                    style = MaterialTheme.typography.labelSmall, color = WarningAmber,
                                )
                            }
                            "REDX" -> {
                                OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Access Token") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = apiStoreId, onValueChange = { apiStoreId = it }, label = { Text("Pickup Store ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "delivery_area_id booking-এর সময় ম্যানুয়ালি দিতে হবে — এই app-এর নিজস্ব location আর RedX-এর নিজস্ব code এখনো সংযুক্ত না।",
                                    style = MaterialTheme.typography.labelSmall, color = WarningAmber,
                                )
                            }
                            "STEADFAST" -> {
                                OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Api-Key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = apiSecretKey, onValueChange = { apiSecretKey = it }, label = { Text("Secret-Key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(6.dp))
                                Text("ঠিকানা লিখলেই যথেষ্ট — কোনো area code লাগে না।", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                            }
                            else -> {
                                OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("API Key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(6.dp))
                                Text("এই courier type-এর জন্য real API call করা এখনো লেখা হয়নি — শুধু হাতে status আপডেট করা যাবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    cfgError = null
                                    val ok = MockRepository.setCourierApiConfig(
                                        cid, baseUrl, apiKey, onRejected = { r -> cfgError = r },
                                        courierType = courierType, apiSecretKey = apiSecretKey, apiUsername = apiUsername, apiPassword = apiPassword, apiStoreId = apiStoreId,
                                    )
                                    if (ok) configuringCourierId = null
                                },
                                modifier = Modifier.weight(1f),
                            ) { Text("সংরক্ষণ") }
                            OutlinedButton(
                                onClick = {
                                    cfgError = null
                                    val ok = MockRepository.setCourierApiConfig(cid, null, null, onRejected = { r -> cfgError = r })
                                    if (ok) configuringCourierId = null
                                },
                                modifier = Modifier.weight(1f),
                            ) { Text("মুছুন") }
                        }
                    }
                }
            }
        }
    }

    if (showAddCourier) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showAddCourier = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var newName by remember { mutableStateOf("") }
                var newType by remember { mutableStateOf("STEADFAST") }
                var newTypeMenuOpen by remember { mutableStateOf(false) }
                var addError by remember { mutableStateOf<String?>(null) }
                Column(Modifier.padding(16.dp)) {
                    Text("নতুন Courier", fontWeight = FontWeight.Bold, color = TextPrimary)
                    addError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("নাম (যেমন: Steadfast)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Box {
                        OutlinedButton(onClick = { newTypeMenuOpen = true }, modifier = Modifier.fillMaxWidth()) { Text("Type: $newType") }
                        DropdownMenu(expanded = newTypeMenuOpen, onDismissRequest = { newTypeMenuOpen = false }) {
                            listOf("PATHAO", "REDX", "STEADFAST", "OTHER").forEach { t ->
                                DropdownMenuItem(text = { Text(t) }, onClick = { newType = t; newTypeMenuOpen = false })
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            addError = null
                            val ok = MockRepository.addCourierPartner(newName, newType, onRejected = { r -> addError = r })
                            if (ok) { showAddCourier = false }
                        },
                        enabled = newName.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("যোগ করুন") }
                }
            }
        }
    }
}

class CourierViewModel : ViewModel() {
    val couriers = MockRepository.couriers
    val shipments = MockRepository.shipments
    fun bookShipment(
        courierId: String = "", dealerOrRetailer: String, invoiceId: String? = null, invoiceNo: String? = null,
        vehicleId: String? = null, deliveryAddress: String = "", weightKg: Double? = null, condition: String? = null,
        recipientPhone: String = "", codAmount: Double = 0.0,
        pathaoCityId: String? = null, pathaoZoneId: String? = null, pathaoAreaId: String? = null, redxDeliveryAreaId: String? = null,
        onResult: (success: Boolean, message: String?) -> Unit = { _, _ -> },
    ) = MockRepository.bookShipment(
        courierId, dealerOrRetailer, invoiceId, invoiceNo, vehicleId, deliveryAddress, weightKg, condition,
        recipientPhone, codAmount, pathaoCityId, pathaoZoneId, pathaoAreaId, redxDeliveryAreaId, onResult,
    )
    fun advanceShipmentStage(id: String, onRejected: (String) -> Unit = {}) = MockRepository.advanceShipmentStageManually(id, onRejected)
    fun setShipmentStatus(id: String, status: ShipmentStatus) = MockRepository.setShipmentStatus(id, status)

    // ---- Module 13: Vehicle Tracking ----
    val vehicles = MockRepository.vehicles
    val vehicleLocationPings = MockRepository.vehicleLocationPings
    fun createVehicle(registrationNo: String, vehicleType: String, driverName: String, driverPhone: String, onRejected: (String) -> Unit = {}) =
        MockRepository.createVehicle(registrationNo, vehicleType, driverName, driverPhone, onRejected)
    fun recordVehiclePing(vehicleId: String, lat: Double, lng: Double, speedKmh: Double) =
        MockRepository.recordVehiclePing(vehicleId, lat, lng, speedKmh)
    fun latestPingFor(vehicleId: String) = MockRepository.latestPingFor(vehicleId)
    fun canCreateVehicle() = com.abm.erp.data.PermissionManager.canCurrentUser("courier", com.abm.erp.data.PermissionAction.CREATE)
}

// v113-288 — the shared section-label chip used to break the Book
// Shipment form's own 10+ fields into clearly-labelled groups — same
// icon-chip visual language already established for Dealer Control/
// Restore this session, not a new style invented for this screen.
@Composable
private fun LogisticsSectionLabel(label: String, icon: ImageVector, accent: Color) {
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
        Box(
            Modifier.size(26.dp).clip(RoundedCornerShape(7.dp)).background(accent.copy(alpha = 0.14f)),
            contentAlignment = androidx.compose.ui.Alignment.Center,
        ) { Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(14.dp)) }
        Spacer(Modifier.width(8.dp))
        Text(label, fontWeight = FontWeight.Bold, color = accent, fontSize = 13.sp)
    }
}

@Composable
fun CourierScreen(vm: CourierViewModel = viewModel()) {
    val couriers by vm.couriers.collectAsState()
    val shipments by vm.shipments.collectAsState()
    // v113-315 — every state variable below this point that existed only
    // to drive the manual "Book Shipment" form (dealerText,
    // selectedCourier, selectedVehicleForBooking, allDealersForBooking,
    // deliveryAddressText, weightText, conditionText, recipientPhoneText,
    // codAmountText, the Pathao/RedX area ids and names,
    // showLocationPicker, bookingResultMsg, invoiceQuery,
    // selectedInvoiceId, selectedInvoice) has been removed along with
    // that form. Each was verified to have no remaining reader before
    // removal — Track Shipments and Vehicle Tracking never used any of
    // them.
    val allVehicles by MockRepository.vehicles.collectAsState()
    val allInvoices by MockRepository.salesInvoices.collectAsState()
    var statusMenuFor by remember { mutableStateOf<String?>(null) }
    // v113-256 — connects a shipment marked FAILED/RETURNED_TO_SENDER to
    // the real invoice-linked Return flow that actually reverses the
    // due-balance/stock effect — holds the shipment id whose "⚠ Return
    // তৈরি করুন" button was tapped, until the confirm dialog resolves it.
    var failedShipmentForReturn by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf<Int?>(null) }
    // v113-315 — the person's own direct instruction: "লজিস্টিক অপশনে
    // আমাদের কোনো বাটন এমনভাবে থাকা উচিত না যে বাটনটা দিয়ে আমরা কোনো
    // কিছু মডিফাই বা কোনো কিছু নতুন করে অ্যাড করতে পারি। কারণ আমি মনে
    // করি লজিস্টিক হলো ইনভয়েসের সাথে পরিপূর্ণ কানেক্টেড।"
    //
    // Verified first that this is already true in the backend: approving
    // an invoice with a courier or vehicle selected calls `bookShipment`
    // automatically (MockRepository, inside approveSalesInvoice), passing
    // the real invoice id/no, the dealer's own address and phone, weight,
    // condition and COD amount. So the manual "Book Shipment" screen was
    // a second, parallel way to create shipments that the invoice flow
    // already creates correctly — exactly the "কোনো কাজেরই না" they
    // described. Tile removed; Logistics is now view-and-track only.
    val subItems = listOf(
        SubModuleItem("track", "Track Shipments", "📍", 0xFF3DDC97, 0xFF1FA972, Icons.Filled.LocationOn),
        SubModuleItem("vehicle", "Vehicle Tracking", "🚛", 0xFF8A6DFF, 0xFF5B3FE0, Icons.Filled.AirportShuttle),
    )

    val inTransitCount = shipments.count { it.status == com.abm.erp.data.ShipmentStatus.IN_TRANSIT }
    val outForDeliveryCount = shipments.count { it.status == com.abm.erp.data.ShipmentStatus.OUT_FOR_DELIVERY }
    val deliveredCount = shipments.count { it.status == com.abm.erp.data.ShipmentStatus.DELIVERED }

    Column(Modifier.fillMaxSize()) {
        com.abm.erp.core.ModuleWorkspaceHeader("Courier & Logistics", "🚛", 0xFF8A6DFF, 0xFF5B3FE0, iconVector = Icons.Filled.LocalShipping, miniDashboard = {
            com.abm.erp.core.ModuleStat("Couriers", "${couriers.size}", TextPrimary)
            com.abm.erp.core.ModuleStat("In Transit", "$inTransitCount", if (inTransitCount > 0) WarningAmber else SuccessGreen)
            com.abm.erp.core.ModuleStat("Out for Delivery", "$outForDeliveryCount", TextPrimary)
            com.abm.erp.core.ModuleStat("Delivered", "$deliveredCount", SuccessGreen)
        }, quickActions = {
            AssistChip(onClick = { tab = 1 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.LocationOn, null, Modifier.size(16.dp)) }, label = { Text("Track") })
            AssistChip(onClick = { tab = 2 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.LocalShipping, null, Modifier.size(16.dp)) }, label = { Text("Vehicles") })
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("Shipment", "Courier", "DeliveryChallan"))
        })
        Column(Modifier.fillMaxSize().padding(16.dp)) {
        if (tab == null) {
            // v113-315 — "book" is gone; both remaining tiles map to their
            // real tabs directly. Tab 0 (the old manual booking form) is
            // no longer reachable from anywhere.
            SubModuleGrid(subItems) { key -> tab = if (key == "track") 1 else 2 }
        } else if (tab == 2) {
            BackToSubMenuLink(onClick = { tab = null })
            VehicleTrackingTab(vm)
        } else {
            BackToSubMenuLink(onClick = { tab = null })
            LazyColumn(Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // v113-315 — the manual "Book Shipment" form (276 lines: dealer/
        // invoice pickers, address, weight, condition, COD, Pathao/RedX
        // area pickers, courier-or-vehicle selection, submit) lived here.
        // Removed entirely, per "লজিস্টিক অপশনে আমাদের কোনো বাটন এমনভাবে
        // থাকা উচিত না যে বাটনটা দিয়ে আমরা কোনো কিছু মডিফাই বা কোনো কিছু
        // নতুন করে অ্যাড করতে পারি।" Every field it collected is already
        // captured on the invoice itself and passed to bookShipment
        // automatically at approval — so this was a duplicate entry path,
        // not a missing capability. Nothing was lost: Track Shipments
        // (below) still shows every shipment, including the ones the
        // invoice flow books.
    }
    }
}
}
    // v113-315 — the Pathao/RedX location-picker dialogs that lived here
    // existed only for the manual booking form and are removed with it.
    // The same real picker components remain in use by
    // DmsInvoiceWorkspace's own courier section, which is now the single
    // place a shipment's delivery area is ever chosen.
    // v113-256 — confirm dialog for the "⚠ Return তৈরি করুন" button: pulls
    // the shipment's own real linked invoice, offers its full line items
    // pre-selected (a courier failure/return-to-sender means none of it
    // was actually delivered — the default is "reverse all of it", not a
    // partial guess), then calls the same real createSalesReturn +
    // approveSalesReturn pair DealerReturnSheet already uses — one real
    // correction path, not a second one invented here.
    failedShipmentForReturn?.let { shipmentId ->
        val shipment = shipments.firstOrNull { it.id == shipmentId }
        val linkedInvoice = shipment?.invoiceId?.let { invId -> allInvoices.firstOrNull { it.id == invId } }
        if (shipment == null || linkedInvoice == null) {
            failedShipmentForReturn = null
        } else {
            var returnReason by remember(shipmentId) { mutableStateOf("Courier ${shipment.status.name.lowercase().replace("_", " ")} — কোনো পণ্য দেওয়া হয়নি") }
            var submitting by remember(shipmentId) { mutableStateOf(false) }
            var submitResult by remember(shipmentId) { mutableStateOf<String?>(null) }
            val returnScope = rememberCoroutineScope()
            androidx.compose.ui.window.Dialog(onDismissRequest = { failedShipmentForReturn = null }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp).heightIn(max = 480.dp).verticalScroll(rememberScrollState())) {
                        Text("Invoice ${linkedInvoice.invoiceNo} — সম্পূর্ণ Return", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("${linkedInvoice.dealerName} — ৳${"%,.0f".format(linkedInvoice.total)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Spacer(Modifier.height(8.dp))
                        linkedInvoice.lineItems.forEach { line -> Text("• ${line.name} (${line.qty})", style = MaterialTheme.typography.bodySmall) }
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = returnReason, onValueChange = { returnReason = it }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
                        submitResult?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = if (it.startsWith("✔")) SuccessGreen else DangerRed) }
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = {
                                submitting = true
                                returnScope.launch {
                                    val r = MockRepository.createSalesReturn(
                                        invoiceId = linkedInvoice.id, partyType = com.abm.erp.data.PartyType.DEALER,
                                        partyId = linkedInvoice.dealerId, partyName = linkedInvoice.dealerName,
                                        lineItems = linkedInvoice.lineItems, reason = returnReason,
                                        onRejected = { reason -> submitResult = "✖ $reason"; submitting = false },
                                    )
                                    if (r != null) {
                                        MockRepository.approveSalesReturn(r.id, onRejected = { reason -> submitResult = "✖ Return তৈরি হয়েছে কিন্তু approve ব্যর্থ: $reason" })
                                        submitResult = "✔ Return ${r.returnNo} তৈরি ও approve হয়েছে — due/stock ঠিক হয়ে গেছে।"
                                    }
                                    submitting = false
                                }
                            },
                            enabled = !submitting, modifier = Modifier.fillMaxWidth(),
                        ) { Text(if (submitting) "..." else "সম্পূর্ণ Return জমা দিন") }
                        TextButton(onClick = { failedShipmentForReturn = null }, modifier = Modifier.fillMaxWidth()) { Text("বন্ধ করুন") }
                    }
                }
            }
        }
    }
}

@Composable
private fun VehicleTrackingTab(vm: CourierViewModel) {
    val vehicles by vm.vehicles.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var pingFor by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        if (vm.canCreateVehicle()) {
            Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add Vehicle") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(vehicles, key = { it.id }) { v ->
                val latestPing by vm.latestPingFor(v.id).collectAsState(initial = null)
                // v113-249 — the person's own direct follow-up: Shipment
                // could already say "I'm on this vehicle," but this tab
                // never showed the reverse — which shipments a vehicle is
                // actually carrying right now. Doesn't depend on GPS at
                // all (the person's own confirmed constraint — no real
                // GPS hardware in the vehicles yet) — this is a separate,
                // simpler connection off Shipment.vehicleId directly.
                val shipments by vm.shipments.collectAsState()
                val activeShipments = remember(shipments, v.id) {
                    shipments.filter { it.vehicleId == v.id && it.status != ShipmentStatus.DELIVERED }
                }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        // v113-289 — same boxy-icon-chip identity treatment
                        // as Track Shipments and the rest of the app —
                        // real GPS-status colour (cyan once a ping exists,
                        // grey otherwise) instead of plain stacked text.
                        val hasPing = latestPing != null
                        Box(
                            Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background((if (hasPing) ElectricCyan else TextSecondary).copy(alpha = 0.14f)),
                            contentAlignment = androidx.compose.ui.Alignment.Center,
                        ) { Icon(Icons.Filled.LocalShipping, contentDescription = null, tint = if (hasPing) ElectricCyan else TextSecondary, modifier = Modifier.size(20.dp)) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${v.registrationNo} (${v.vehicleType})", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("Driver: ${v.driverName.ifBlank { "—" }} · ${v.driverPhone}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            latestPing?.let { p ->
                                Text("সর্বশেষ অবস্থান: ${"%.4f".format(p.lat)}, ${"%.4f".format(p.lng)} · ${"%.0f".format(p.speedKmh)} km/h", style = MaterialTheme.typography.labelSmall, color = ElectricCyan)
                            } ?: Text("এখনো কোনো GPS ping পাওয়া যায়নি।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        TextButton(onClick = { pingFor = v.id }) { Text("📍 Log position") }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Vehicle", entityId = v.id, entityLabel = v.registrationNo,
                            shareText = "Vehicle: ${v.registrationNo} (${v.vehicleType})\nDriver: ${v.driverName} · ${v.driverPhone}",
                            csvHeader = "RegistrationNo,Type,Driver,Phone",
                            csvRow = com.abm.erp.core.toCsvRow(v.registrationNo, v.vehicleType, v.driverName, v.driverPhone),
                        )
                    }
                    if (activeShipments.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Divider()
                        Spacer(Modifier.height(6.dp))
                        Text("এই গাড়িতে এখন যা যাচ্ছে (${activeShipments.size})", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        activeShipments.forEach { s ->
                            Text(
                                "• ${s.dealerOrRetailer}${s.invoiceNo?.let { " · $it" } ?: ""} — ${s.status.name.replace("_", " ")}",
                                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                            )
                        }
                    }
                }
            }
            if (vehicles.isEmpty()) item { Text("এখনো কোনো vehicle registered নেই।", color = TextSecondary) }
        }
    }

    if (showAdd) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showAdd = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var reg by remember { mutableStateOf("") }
                var type by remember { mutableStateOf("Truck") }
                var driver by remember { mutableStateOf("") }
                var phone by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp)) {
                    Text("Add Vehicle", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = reg, onValueChange = { reg = it }, label = { Text("Registration No.") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Truck", "Van", "Motorcycle").forEach { t -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) }) }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = driver, onValueChange = { driver = it }, label = { Text("Driver name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Driver phone") }, modifier = Modifier.fillMaxWidth())
                    var vehicleError by remember { mutableStateOf<String?>(null) }
                    vehicleError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { if (vm.createVehicle(reg, type, driver, phone, onRejected = { e -> vehicleError = e }) != null) showAdd = false }, enabled = reg.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Register Vehicle") }
                }
            }
        }
    }

    pingFor?.let { vehicleId ->
        androidx.compose.ui.window.Dialog(onDismissRequest = { pingFor = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                // v113-255 — the person's own direct instruction: shift
                // this from manual entry to real GPS. Same exact proven
                // pattern as SalesChainScreen's own tagLocationNow() —
                // FusedLocationProviderClient.lastLocation, permission-
                // checked, permission-launcher fallback if not yet
                // granted — not a new mechanism invented for this one
                // dialog. Manual lat/lng fields kept, but now pre-filled
                // by a real GPS fix rather than typed from nothing, and
                // still editable for the rare case a real fix is
                // unavailable (indoors, no signal) and a known position
                // needs to be logged anyway.
                var latText by remember { mutableStateOf("") }
                var lngText by remember { mutableStateOf("") }
                var speedText by remember { mutableStateOf("") }
                var gpsError by remember { mutableStateOf<String?>(null) }
                val gpsContext = androidx.compose.ui.platform.LocalContext.current

                fun hasLocationPermission() = androidx.core.content.ContextCompat.checkSelfPermission(
                    gpsContext, android.Manifest.permission.ACCESS_FINE_LOCATION,
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED

                fun fetchRealGps() {
                    val client = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(gpsContext)
                    try {
                        @Suppress("MissingPermission")
                        client.lastLocation.addOnSuccessListener { loc ->
                            if (loc != null) {
                                latText = loc.latitude.toString(); lngText = loc.longitude.toString(); gpsError = null
                            } else gpsError = "সাম্প্রতিক GPS fix নেই — খোলা জায়গায় গিয়ে আবার চেষ্টা করুন।"
                        }.addOnFailureListener { gpsError = it.message ?: "অবস্থান আনা যায়নি।" }
                    } catch (e: SecurityException) {
                        gpsError = "Location অনুমতি লাগবে।"
                    }
                }
                val gpsPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                    androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
                ) { granted -> if (granted) fetchRealGps() else gpsError = "Location অনুমতি দেওয়া হয়নি।" }

                Column(Modifier.padding(16.dp)) {
                    Text("Log Vehicle Position", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { if (hasLocationPermission()) fetchRealGps() else gpsPermissionLauncher.launch(android.Manifest.permission.ACCESS_FINE_LOCATION) },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("📍 এখনকার real GPS অবস্থান নিন") }
                    gpsError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = latText, onValueChange = { latText = it }, label = { Text("Latitude") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = lngText, onValueChange = { lngText = it }, label = { Text("Longitude") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = speedText, onValueChange = { speedText = it }, label = { Text("Speed (km/h)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val lat = latText.toDoubleOrNull() ?: return@Button
                            val lng = lngText.toDoubleOrNull() ?: return@Button
                            vm.recordVehiclePing(vehicleId, lat, lng, speedText.toDoubleOrNull() ?: 0.0)
                            pingFor = null
                        },
                        enabled = latText.toDoubleOrNull() != null && lngText.toDoubleOrNull() != null,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Save Position") }
                }
            }
        }
    }
}
