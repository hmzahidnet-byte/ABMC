package com.abm.erp.core

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.DashBg
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

/**
 * v113-85 — THE SHARED BROWSE-FLOW ENGINE.
 *
 * The person approved the DMS browse flow and said the other modules follow the same
 * pattern ("baki gulao eki pattern e"). Rather than copy DmsBrowseFlow.kt four times —
 * which would mean four places to fix every future bug, against his own standing
 * "one home per feature / no duplicates" rule — the pattern is defined ONCE here,
 * generic over the entity type, and each module supplies a small descriptor.
 *
 * What a module provides (`BrowseConfig`): how to turn its own record into a row
 * (title/subtitle/status/avatar seed), what its filter facets are, what the detail
 * screen's Basic Information block contains, its KPI cells, and which optional
 * drill-downs it has (ledger / activity calendar / QR card / product graph / 90-day).
 * Modules with no money ledger (HR employees, factory products) simply don't declare
 * those drill-downs, and the toolbar shows only what actually exists — no dead buttons.
 *
 * Screens, identical in structure to the approved DMS reference:
 *   List (search + facet chips + counts + avatar rows + toolbar + QR FAB)
 *     → Details (identity header + action row + tabs + Basic Information + KPIs)
 *       → Ledger / Activity Calendar / 90-Day Summary / Product Graph / QR ID Card
 */

// ── descriptor types ───────────────────────────────────────────────────────────

/** One row in a Basic Information block. */
data class BrowseInfoRow(val label: String, val value: String)

/** One KPI cell shown on the detail screen. */
data class BrowseKpi(val label: String, val value: String, val color: Color = TextPrimary)

/** One filter facet: a label plus the options and how to test a record against one. */
data class BrowseFacet<T>(
    val label: String,
    val options: List<String>,
    val matches: (T, String) -> Boolean,
)

/** A dated money/activity row — used by both the ledger table and the calendar. */
data class BrowseActivity(
    val date: LocalDate,
    val title: String,
    val kind: String,
    val amount: Double,
    /** true = money owed increases (debit); false = decreases (credit). null = neither. */
    val isDebit: Boolean? = null,
    val balanceAfter: Double? = null,
    val route: String? = null,
)

/** A product/category split slice, for the graph screen. */
data class BrowseSlice(val label: String, val amount: Double)

class BrowseConfig<T>(
    val moduleName: String,
    val entityLabel: String,
    val colorStart: Long,
    val colorEnd: Long,
    val idOf: (T) -> String,
    val titleOf: (T) -> String,
    val codeOf: (T) -> String,
    val subtitleOf: (T) -> String,
    val categoryOf: (T) -> String,
    val isActiveOf: (T) -> Boolean,
    val searchMatches: (T, String) -> Boolean,
    // v113-174 — person's request: list rows should show the real profile
    // photo (dealer shop/owner, retailer shop-front, employee headshot) when
    // one exists, instead of always the colored-initials avatar. Null means
    // no photo on this record — falls back to initials, same as before.
    val photoUriOf: (T) -> String? = { null },
    // v113-278 — the person's own direct request: Dealer/Retailer List
    // rows should show location, tappable straight to a precise Google
    // Maps pin — same real captured coordinate (Dealer.lat/lng gained
    // real capture parity with Retailer in v113-268) and the same real
    // google.navigation:q=lat,lng → geo:lat,lng → honest Toast chain
    // already proven in the Invoice workspace and HR Attendance, not a
    // new mechanism. Generic on BrowseConfig (default returns null, so
    // Employee/Product — which have no location concept — simply never
    // show the action) rather than hardcoded to Dealer/Retailer only.
    val locationOf: (T) -> Pair<Double, Double>? = { null },
    val facets: List<BrowseFacet<T>> = emptyList(),
    val infoRows: (T) -> List<BrowseInfoRow>,
    val kpis: (T) -> List<BrowseKpi> = { emptyList() },
    // v113-260 — the entityType string this record's audit-log/approval-
    // history entries are actually filed under (checked directly against
    // logAudit's real call sites project-wide, not assumed to always match
    // `entityLabel` — Employee's own logAudit entityType is "EmployeeProfile",
    // not "Employee", so this exists specifically so UniversalActionMenu's
    // Approval History / Activity Log genuinely find real records instead of
    // silently coming up empty from a label mismatch). Defaults to
    // `entityLabel`, which is correct for Dealer/Retailer/Product.
    val auditEntityType: String = entityLabel,
    // Drill-down capabilities. These are declared as flags + always-present composable
    // lambdas rather than nullable lambdas on purpose: calling a @Composable lambda
    // through `?.invoke()` makes the composable call conditional, which breaks Compose's
    // group structure. The flags decide whether the BUTTON shows; the lambdas are always
    // safely callable and simply return empty when the module has no such data.
    /** Enables the Ledger + Calendar drill-downs. */
    val hasLedger: Boolean = false,
    val activities: @Composable (T) -> List<BrowseActivity> = { emptyList() },
    /** Enables the Product Graph drill-down. */
    val hasGraph: Boolean = false,
    val slices: @Composable (T) -> List<BrowseSlice> = { emptyList() },
    /** Graph screen title + how a slice amount is printed (money for parties, quantity for stock). */
    val graphTitle: String = "Product Wise Sales",
    val sliceFormat: (Double) -> String = { "৳${"%,.0f".format(it)}" },
    /** Enables the 90-Day Summary drill-down. */
    val has90Day: Boolean = false,
    val summary90: @Composable (T) -> List<BrowseKpi> = { emptyList() },
    val enableQrCard: Boolean = true,
    /**
     * v113-87 — the QrRegistry entityType for this record type ("Dealer", "Retailer",
     * "Employee", "Product"), or null if this record type has no QR identity. Drives
     * the REAL QR ID Card: status lookup via QrRegistry.activeFor and issue/reissue via
     * QrRegistry.issue — the payload returned is what gets rendered, nothing invented.
     */
    val qrEntityType: String? = null,
    val addRoute: String? = null,
    /**
     * v113-146 — optional CSV import. Null means this entity has no import path yet,
     * and the button simply doesn't appear — no dead menu item. The lambda receives
     * the raw file text and returns a real per-row outcome, because only the module
     * knows which real create function each row belongs to (createDealer vs
     * createRetailer vs addProduct) and what its columns mean.
     */
    val importCsv: (suspend (String) -> CsvImport.ImportOutcome)? = null,
    /** Extra detail tabs beyond Overview, e.g. "Transactions". */
    val extraTabs: List<String> = emptyList(),
    /** Always callable (same reason as the drill-down lambdas above); no-op by default. */
    val extraTabContent: @Composable (T, Int, (String) -> Unit) -> Unit = { _, _, _ -> },
)

// ── shared chrome ──────────────────────────────────────────────────────────────

// v113-260 — real, generic content for UniversalActionMenu's Share/Print/
// Export-CSV/View-Details-fallback, built once here from `config.infoRows`
// (the exact same real per-record data the Basic Information card already
// shows) rather than re-derived per entity type. Works for any T this
// engine is configured for — Dealer/Retailer/Employee/Product today, and
// whatever else gets a BrowseConfig later — with zero extra wiring.
private fun <T> browseRecordShareText(config: BrowseConfig<T>, r: T): String =
    "${config.entityLabel}: ${config.titleOf(r)} (${config.codeOf(r)})\n" +
        config.infoRows(r).joinToString("\n") { "${it.label}: ${it.value}" }

private fun <T> browseRecordCsvHeader(config: BrowseConfig<T>): String = "Field,Value"

private fun <T> browseRecordCsvRow(config: BrowseConfig<T>, r: T): String =
    config.infoRows(r).joinToString("\n") { row -> "${escapeCsvField(row.label)},${escapeCsvField(row.value)}" }

@Composable
fun BrowseTopBar(title: String, subtitle: String? = null, colorStart: Long, colorEnd: Long, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}) {
    // v113-260 — same treatment as TaskHeader (core/SubModuleGrid.kt), same
    // confirmed reason: full display for the actual work, only the
    // module's own ☰/⋮ bar stays. Ran at 7 places (List/Detail/Ledger/
    // Graph/90-Day/Calendar/QR-card) plus the Carton scan screen;
    // `BackHandler` replaces the visible arrow's `onBack` wiring at every
    // one of them uniformly. The one real action in this header's
    // `actions` slot (List's own "+ Add" button) moved into
    // ModuleBrowseList's own content, right above the search field — not
    // silently dropped. `title`/`subtitle`/`colorStart`/`colorEnd`/
    // `actions` kept as real, unused parameters for the same reason as
    // TaskHeader — a signature change across every call site is riskier
    // than an inert parameter.
    androidx.activity.compose.BackHandler(onBack = onBack)
}

data class BrowseToolbarAction(val icon: ImageVector, val label: String, val onClick: () -> Unit)

@Composable
fun BrowseBottomToolbar(actions: List<BrowseToolbarAction>, accent: Long) {
    if (actions.isEmpty()) return
    Divider()
    Row(Modifier.fillMaxWidth().background(Color.White)) {
        actions.forEach { a ->
            Column(
                Modifier.weight(1f).clickable { a.onClick() }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(a.icon, contentDescription = a.label, tint = Color(accent), modifier = Modifier.size(18.dp))
                Text(a.label, fontSize = 9.sp, color = TextSecondary, maxLines = 1)
            }
        }
    }
}

@Composable
fun BrowseStatCell(label: String, value: String, color: Color = TextPrimary, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, fontSize = 10.sp, color = TextSecondary, maxLines = 1)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = color, maxLines = 1)
    }
}

/** Deterministic avatar colour — the same name always gets the same colour. */
fun browseAvatarColor(seed: String): Color = Color.hsl((seed.hashCode().toUInt() % 360u).toFloat(), 0.55f, 0.48f)

// v113-278 — the one real "open Google Maps at a precise coordinate"
// mechanism, now shared rather than copy-pasted a 4th time (already
// existed near-identically in DmsInvoiceWorkspace.kt and PayrollScreen's
// own AttendanceTab, both v113-268/269 — same real
// google.navigation:q=lat,lng → geo:lat,lng → honest Toast fallback
// chain here, reused by every BrowseConfig-powered List row that
// declares a real locationOf).
fun openMapsAt(context: android.content.Context, lat: Double, lng: Double) {
    try {
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("google.navigation:q=$lat,$lng"))
            .apply { setPackage("com.google.android.apps.maps") }
        context.startActivity(intent)
    } catch (e: Exception) {
        try {
            context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("geo:$lat,$lng")))
        } catch (e2: Exception) {
            android.widget.Toast.makeText(context, "Maps app পাওয়া যায়নি।", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
}

/**
 * v113-321 — the person's own instruction: "লোকেশনের যে সিস্টেমটা আছে
 * ওই সিস্টেমটা যেন পুরো অ্যাপ্লিকেশন জুড়ে একই সিস্টেম হয়... আমরা তো
 * লোকেশন লাইভ ট্র্যাকিং করতে চাচ্ছি।"
 *
 * `openMapsAt` above already existed but only covered the exact-GPS
 * case, so four screens (Invoice workspace, Payroll attendance, the
 * legacy Dealers screen, RMS memo) had each hand-rolled their own
 * near-identical copy — including their own address fallback, their own
 * try/catch nesting, and their own error text. Same intent chain
 * written four times means four places to drift.
 *
 * This is the one entry point for "show me where this is", covering the
 * real situation the app actually has: a party may have precise
 * coordinates, or only a typed address, or neither. Callers no longer
 * decide — they pass what they have and get consistent behaviour.
 *
 * Precise coordinates open turn-by-turn navigation (a real pin, not a
 * text search). Address-only falls back to a Maps search, which is
 * honestly approximate. Neither → a clear message rather than a dead
 * button.
 */
fun openMapsFor(
    context: android.content.Context,
    lat: Double?,
    lng: Double?,
    address: String? = null,
) {
    if (lat != null && lng != null) {
        openMapsAt(context, lat, lng)
        return
    }
    val query = address?.trim().orEmpty()
    if (query.isBlank()) {
        android.widget.Toast.makeText(context, "এর কোনো location সংরক্ষণ করা নেই।", android.widget.Toast.LENGTH_SHORT).show()
        return
    }
    try {
        context.startActivity(
            android.content.Intent(
                android.content.Intent.ACTION_VIEW,
                android.net.Uri.parse("geo:0,0?q=${android.net.Uri.encode(query)}"),
            ),
        )
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "Maps app পাওয়া যায়নি।", android.widget.Toast.LENGTH_SHORT).show()
    }
}

fun browseInitials(name: String): String =
    name.trim().split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() }.ifBlank { "?" }

// ── 1. List ────────────────────────────────────────────────────────────────────

@Composable
fun <T> ModuleBrowseList(
    config: BrowseConfig<T>,
    records: List<T>,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    // v113-273 — facetSelections kept (always empty now, harmlessly a
    // no-op in the `filtered` computation below) since config.facets
    // itself is still real per-entity data other things may read; only
    // the UI that ever SET it (showFilter's dialog, the FilterChips row)
    // removed, per the person's own direct instruction.
    var facetSelections by remember { mutableStateOf<Map<String, String?>>(emptyMap()) }
    var detailFor by remember { mutableStateOf<T?>(null) }
    var showMoreActions by remember { mutableStateOf(false) }
    var importOutcome by remember { mutableStateOf<CsvImport.ImportOutcome?>(null) }
    val importScope = androidx.compose.runtime.rememberCoroutineScope()
    val moreActionsContext = androidx.compose.ui.platform.LocalContext.current

    val filtered = remember(records, query, facetSelections) {
        records.filter { r ->
            (query.isBlank() || config.searchMatches(r, query)) &&
                config.facets.all { f ->
                    val sel = facetSelections[f.label]
                    sel == null || f.matches(r, sel)
                }
        }
    }
    val activeCount = remember(records) { records.count { config.isActiveOf(it) } }

    detailFor?.let { r ->
        ModuleBrowseDetail(config, r, onBack = { detailFor = null }, onNavigate = onNavigate)
        return
    }

    Column(Modifier.fillMaxSize().background(DashBg)) {
        BrowseTopBar("${config.entityLabel} List", null, config.colorStart, config.colorEnd, onBack)
        Column(Modifier.background(Color.White).padding(12.dp)) {
            // v113-310 — the full-width "নতুন X যোগ করুন" button that used
            // to sit here is gone. The person asked specifically for "একদম
            // ছোট একটা জায়গা নিয়ে একটা আইকন... নিচে দাও, নেভিগেশনের
            // ওইখানে" — a small icon in the bottom navigation corner, not
            // a full-width bar consuming a row above the search. It now
            // renders as a SmallFloatingActionButton beside the scanner
            // FAB (see the bottom of this same composable). Removing it
            // here rather than leaving both is what keeps it "একদম ছোট" —
            // otherwise restoring addRoute would have produced two Add
            // buttons on the same screen.
            // v113-273 — the person's own direct complaint: the full-width
            // "নাম, কোড, ফোন দিয়ে খুঁজুন…" field plus facet FilterChips
            // ("All Area"/"All Category"/"All Status") took up permanent
            // space for something used occasionally — collapsed to a
            // single small search button/chip. Tapping it reveals the
            // real field inline (same real `config.searchMatches`
            // filtering underneath, nothing lost) instead of it always
            // being expanded. Facet chips removed entirely, per the same
            // instruction — not just moved.
            var searchOpen by remember { mutableStateOf(false) }
            if (!searchOpen) {
                OutlinedButton(onClick = { searchOpen = true }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Search, null, tint = Color(config.colorStart), modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (query.isBlank()) "খুঁজুন…" else "\"$query\" — ফলাফল: ${filtered.size}")
                }
            } else {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("নাম, কোড, ফোন দিয়ে খুঁজুন…") },
                    leadingIcon = { Icon(Icons.Filled.Search, null, tint = TextSecondary) },
                    trailingIcon = {
                        IconButton(onClick = { searchOpen = false; query = "" }) { Icon(Icons.Filled.Close, "বন্ধ করুন", tint = TextSecondary) }
                    },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        Box(Modifier.weight(1f)) {
            if (filtered.isEmpty()) {
                Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(Modifier.height(40.dp))
                    Text("আপনার এলাকায় মিলে এমন কিছু নেই।", color = TextSecondary)
                }
            }
            LazyColumn(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filtered, key = { config.idOf(it) }) { r ->
                    // v113-273 — the person's own direct request: the row felt
                    // "খুবই সাদামাটা" (very plain) — a boxy (rounded-square,
                    // not circular), colourful, gently premium avatar
                    // treatment instead. Same real per-record hash colour
                    // (browseAvatarColor) already used, applied as a soft
                    // gradient + border for the "professional" look asked
                    // for, rather than a flat fill.
                    // v113-304 — item 10 of the 14-point list: "Deler list e
                    // list gulo border kore aldala alada radiant background
                    // HOA ucit" — each row should have its own border and its
                    // own distinct gradient background. Previously only the
                    // AVATAR carried the per-record colour; the row itself was
                    // a plain GlassCard (fixed grey border, flat surface), so
                    // every row looked identical. The row now carries the same
                    // real per-record accent as a soft left-to-right gradient
                    // wash plus a matching tinted border, so each row is
                    // visually its own card. Deliberately very low alpha
                    // (0.10 → 0.03) so names, codes and the Active/Inactive
                    // state stay fully legible — a "radiant" background, not a
                    // coloured block that fights the text.
                    val avatarAccent = browseAvatarColor(config.titleOf(r))
                    Row(
                        Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        avatarAccent.copy(alpha = 0.10f),
                                        avatarAccent.copy(alpha = 0.03f),
                                        Color.White,
                                    ),
                                ),
                            )
                            .border(1.dp, avatarAccent.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                            .clickable { detailFor = r }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                            val photoUri = config.photoUriOf(r)
                            if (!photoUri.isNullOrBlank()) {
                                coil.compose.AsyncImage(
                                    model = photoUri, contentDescription = null,
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                    modifier = Modifier.size(46.dp).clip(RoundedCornerShape(12.dp))
                                        .border(1.5.dp, avatarAccent, RoundedCornerShape(12.dp)),
                                )
                            } else {
                                Box(
                                    Modifier.size(46.dp).clip(RoundedCornerShape(12.dp))
                                        .background(Brush.linearGradient(listOf(avatarAccent.copy(alpha = 0.85f), avatarAccent))),
                                    contentAlignment = Alignment.Center,
                                ) { Text(browseInitials(config.titleOf(r)), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(config.titleOf(r), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextPrimary, maxLines = 1)
                                Spacer(Modifier.height(2.dp))
                                Box(
                                    Modifier.clip(RoundedCornerShape(4.dp)).background(avatarAccent.copy(alpha = 0.12f))
                                        .padding(horizontal = 6.dp, vertical = 1.dp),
                                ) { Text(config.codeOf(r), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = avatarAccent) }
                                Spacer(Modifier.height(2.dp))
                                Text(config.subtitleOf(r), fontSize = 11.sp, color = TextSecondary, maxLines = 1)
                            }
                            Text(
                                if (config.isActiveOf(r)) "Active" else "Inactive",
                                fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                color = if (config.isActiveOf(r)) SuccessGreen else DangerRed,
                            )
                            // v113-278 — the person's own direct request:
                            // location visible right on the List row,
                            // tappable straight to a precise Google Maps
                            // pin — only rendered when this record type
                            // actually has one (Dealer/Retailer do,
                            // Employee/Product don't — config.locationOf
                            // defaults to null for those, so nothing
                            // extra shows there).
                            val loc = config.locationOf(r)
                            if (loc != null) {
                                val mapContext = androidx.compose.ui.platform.LocalContext.current
                                IconButton(onClick = { openMapsAt(mapContext, loc.first, loc.second) }, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Filled.LocationOn, contentDescription = "${config.titleOf(r)}-এর লোকেশন দেখুন", tint = Color(0xFF2563EB), modifier = Modifier.size(20.dp))
                                }
                            }
                            // v113-260 — the person's own confirmed instruction: the
                            // SAME universal ⋮ menu (View Details/Preview/Correction
                            // Request/Approval History/Activity Log/Attachments/
                            // Export CSV/PDF/JPG/Share/Print) that already exists and
                            // works at ~17 other places in the app, now on every row
                            // here too — the most-used list screen shape in the whole
                            // app (Dealer/Retailer/Employee/Product, across all 5
                            // mother modules via this one shared engine) was the
                            // single biggest confirmed gap. Every item wired here is
                            // genuinely functional, not decorative: shareText/csvRow
                            // are built directly from `config.infoRows(r)` — the same
                            // real per-record data the Basic Information card already
                            // shows — so Export/Share/Print/View-Details/Preview carry
                            // real content for any entity type this engine supports,
                            // with no per-module wiring needed. `auditEntityType`
                            // (not `entityLabel`) is what Approval History/Activity
                            // Log actually query by — checked directly against every
                            // real logAudit(...) call site project-wide before using
                            // it, not assumed to match the display label.
                            UniversalActionMenu(
                                moduleReference = config.auditEntityType,
                                entityId = config.idOf(r),
                                entityLabel = "${config.entityLabel}: ${config.titleOf(r)}",
                                shareText = browseRecordShareText(config, r),
                                csvHeader = browseRecordCsvHeader(config),
                                csvRow = browseRecordCsvRow(config, r),
                            )
                    }
                }
            }
            // v113-310 — point 7 of the person's own list: "ডিলার অ্যাড
            // বাটনটা বর্তমানে অ্যাপ্রুভাল অপশনের মধ্যে আছে। কিন্তু
            // অ্যাপ্রুভাল অপশনের মধ্যে তো কোনো ডিলার বা রিটেইলার বাটন
            // থাকবে না... ডিলার লিস্টের মধ্যে একদম ছোট একটা জায়গা নিয়ে
            // একটা আইকন দিয়ে দাও... নিচে দাও, নেভিগেশনের ওইখানে দাও।"
            //
            // Placed beside the existing scanner FAB — the same bottom
            // navigation corner they pointed at — and only for configs
            // that genuinely have an add route (`addRoute` is null for
            // entity types with no add flow, so nothing appears there).
            // Deliberately the smaller of the two: adding is occasional,
            // scanning is the daily action.
            Row(
                Modifier.align(Alignment.BottomEnd).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                config.addRoute?.let { route ->
                    SmallFloatingActionButton(
                        onClick = { onNavigate(route) },
                        containerColor = Color.White,
                        contentColor = Color(config.colorStart),
                    ) { Icon(Icons.Filled.Add, contentDescription = "নতুন ${config.entityLabel} যোগ করুন") }
                }
                FloatingActionButton(
                    onClick = { onNavigate("universal_scanner") },
                    containerColor = Color(config.colorStart),
                ) { Icon(Icons.Filled.QrCodeScanner, contentDescription = "QR Scan", tint = Color.White) }
            }
        }

        // v113-273 — the person's own direct confirmation: Total/Active/
        // Inactive stays (genuinely useful), moved to the bottom as asked
        // — right above the toolbar, a fixed summary rather than
        // scrolling away with the list.
        Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 12.dp, vertical = 8.dp)) {
            BrowseStatCell("Total ${config.entityLabel}", "${records.size}", modifier = Modifier.weight(1f))
            BrowseStatCell("Active", "$activeCount", SuccessGreen, Modifier.weight(1f))
            BrowseStatCell("Inactive", "${records.size - activeCount}", DangerRed, Modifier.weight(1f))
        }

        // v113-273 — the person's own direct instruction: QR ID Card/
        // Product Graph/Calendar/Custom Filter removed from here — each
        // only ever opened a second "which record?" picker before
        // showing what one tap into that same record's own Detail screen
        // (which already has all of these as real tabs) would show
        // anyway. Genuinely redundant navigation, not a shortcut. "More"
        // (real Export/Share/Print for the current filtered list) is the
        // one genuinely list-level action here, so it's the only one left.
        val toolbar = buildList {
            add(BrowseToolbarAction(Icons.Filled.MoreHoriz, "More") { showMoreActions = true })
        }
        BrowseBottomToolbar(toolbar, config.colorStart)
    }

    if (showMoreActions) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showMoreActions = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                var actionError by remember { mutableStateOf<String?>(null) }
                Column(Modifier.padding(16.dp)) {
                    Text("More Actions", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("${filtered.size}টা ${config.entityLabel} — বর্তমান filter অনুযায়ী", fontSize = 11.sp, color = TextSecondary)
                    actionError?.let { Text(it, color = DangerRed, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
                    Spacer(Modifier.height(10.dp))
                    // v113-129 — three real actions, not placeholders: CSV export
                    // (real file write + real FileProvider share, same mechanism
                    // already proven for PDF exports elsewhere in this app), a real
                    // text share of the actual filtered counts, and a real Android
                    // print job via PrintManager on a genuinely generated PDF —
                    // no fabricated "coming soon" buttons.
                    // v113-146 — real CSV import, symmetric with the export below.
                    // Shown only when this entity actually has an import path.
                    if (config.importCsv != null) {
                        val importLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                            androidx.activity.result.contract.ActivityResultContracts.GetContent(),
                        ) { uri ->
                            if (uri != null) {
                                val text = CsvImport.readText(moreActionsContext, uri)
                                if (text == null) {
                                    actionError = "ফাইলটি পড়া যায়নি।"
                                } else {
                                    importScope.launch {
                                        importOutcome = config.importCsv.invoke(text)
                                    }
                                }
                            }
                        }
                        TextButton(
                            onClick = { importLauncher.launch("*/*") },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.Add, null, tint = Color(config.colorStart), modifier = Modifier.size(18.dp)); Spacer(Modifier.width(10.dp)); Text("Import ${config.entityLabel} (CSV)") } }
                    }
                    TextButton(
                        onClick = {
                            try {
                                val file = exportListAsCsv(
                                    moreActionsContext, config.entityLabel, filtered,
                                    listOf(
                                        "Code" to { r: T -> config.codeOf(r) },
                                        "Name" to { r: T -> config.titleOf(r) },
                                        "Detail" to { r: T -> config.subtitleOf(r) },
                                        "Category" to { r: T -> config.categoryOf(r) },
                                        "Status" to { r: T -> if (config.isActiveOf(r)) "Active" else "Inactive" },
                                    ),
                                )
                                shareStructuredCsv(moreActionsContext, file, "${config.entityLabel} List (${filtered.size})")
                                showMoreActions = false
                            } catch (e: Exception) {
                                actionError = "Export ব্যর্থ হয়েছে: ${e.message ?: "unknown error"}"
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.Download, null, tint = Color(config.colorStart), modifier = Modifier.size(18.dp)); Spacer(Modifier.width(10.dp)); Text("Export List (CSV/Excel)") } }
                    TextButton(
                        onClick = {
                            val activeN = filtered.count { config.isActiveOf(it) }
                            val summary = "${config.entityLabel} List — মোট ${filtered.size}, Active ${activeN}, Inactive ${filtered.size - activeN}\n" +
                                filtered.take(50).joinToString("\n") { "${config.codeOf(it)} · ${config.titleOf(it)}" } +
                                if (filtered.size > 50) "\n…আরও ${filtered.size - 50}টা" else ""
                            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                            moreActionsContext.startActivity(android.content.Intent.createChooser(intent, "${config.entityLabel} List Share"))
                            showMoreActions = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.Share, null, tint = Color(config.colorStart), modifier = Modifier.size(18.dp)); Spacer(Modifier.width(10.dp)); Text("Share List Summary") } }
                    TextButton(
                        onClick = {
                            try {
                                val file = exportBrowseListPdf(moreActionsContext, config.entityLabel, filtered, config.codeOf, config.titleOf, config.subtitleOf, config.isActiveOf)
                                printPdfFile(moreActionsContext, file, "${config.entityLabel} List")
                                showMoreActions = false
                            } catch (e: Exception) {
                                actionError = "Print ব্যর্থ হয়েছে: ${e.message ?: "unknown error"}"
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.Print, null, tint = Color(config.colorStart), modifier = Modifier.size(18.dp)); Spacer(Modifier.width(10.dp)); Text("Print List") } }
                }
            }
        }
    }

    // v113-146 — import result, reported row by row. A bulk import that says only
    // "12 imported" hides which 3 rows were skipped and why; every failure here
    // carries the real reason its create function gave (duplicate phone, blank
    // name, no permission…), so the person can fix the sheet and re-import.
    importOutcome?.let { outcome ->
        androidx.compose.ui.window.Dialog(onDismissRequest = { importOutcome = null }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 480.dp)) {
                    Text("Import ফলাফল", fontWeight = FontWeight.Bold, color = TextPrimary)
                    if (outcome.fatal != null) {
                        Text(outcome.fatal, color = DangerRed, fontSize = 12.sp)
                    } else {
                        Text(
                            "${outcome.total}টা row · ${outcome.succeeded}টা যোগ হয়েছে · ${outcome.failed}টা বাদ পড়েছে",
                            fontSize = 12.sp,
                            color = if (outcome.failed > 0) WarningAmber else SuccessGreen,
                        )
                        Spacer(Modifier.height(8.dp))
                        LazyColumn(Modifier.weight(1f, fill = false)) {
                            items(outcome.rows.filter { !it.ok }, key = { "r-${'$'}{it.line}" }) { r ->
                                Column(Modifier.padding(vertical = 3.dp)) {
                                    Text("Line ${'$'}{r.line}: ${'$'}{r.label}", fontSize = 11.sp, color = TextPrimary)
                                    Text(r.reason ?: "কারণ জানা যায়নি।", fontSize = 10.sp, color = DangerRed)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    TextButton(onClick = { importOutcome = null }, modifier = Modifier.fillMaxWidth()) { Text("বন্ধ করুন") }
                }
            }
        }
    }

}

// ── 2. Detail ──────────────────────────────────────────────────────────────────

@Composable
fun <T> ModuleBrowseDetail(
    config: BrowseConfig<T>,
    record: T,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    var sub by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf(0) }
    val activities = config.activities(record)

    when (sub) {
        "ledger" -> { ModuleBrowseLedger(config, record, activities) { sub = null }; return }
        "graph" -> { ModuleBrowseGraph(config, record) { sub = null }; return }
        "90d" -> { ModuleBrowse90Day(config, record) { sub = null }; return }
        "calendar" -> { ModuleBrowseCalendar(config, record, activities) { sub = null }; return }
    }

    val tabs = listOf("Overview") + config.extraTabs

    Column(Modifier.fillMaxSize().background(DashBg)) {
        BrowseTopBar("${config.entityLabel} Details", null, config.colorStart, config.colorEnd, onBack)
        Column(Modifier.background(Color.White).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // v113-283 — the person's own direct instruction: the
                // small tap-through QR icon (which only ever showed a
                // static material icon, never the actual code) is gone
                // from here — Chairman's own Dealer Control now owns
                // issue/reissue entirely (v113-282). What replaces it
                // below is a real, bigger status card, not a bigger
                // version of the same tap-through icon.
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)).background(DashBg),
                    contentAlignment = Alignment.Center,
                ) {
                    val recordPhoto = config.photoUriOf(record)
                    if (!recordPhoto.isNullOrBlank()) {
                        coil.compose.AsyncImage(
                            model = recordPhoto, contentDescription = config.titleOf(record),
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp)),
                        )
                    } else {
                        Icon(Icons.Filled.Person, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(24.dp))
                    }
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(config.titleOf(record), fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("${config.codeOf(record)} · ${config.categoryOf(record)}", fontSize = 11.sp, color = TextSecondary)
                    Text(config.subtitleOf(record), fontSize = 11.sp, color = TextSecondary, maxLines = 1)
                }
                Text(
                    if (config.isActiveOf(record)) "Active" else "Inactive",
                    fontSize = 10.sp, fontWeight = FontWeight.Bold,
                    color = if (config.isActiveOf(record)) SuccessGreen else DangerRed,
                )
                // v113-278 — same real location action as the List row,
                // for consistency once someone's already drilled into a
                // specific record's own Detail screen.
                config.locationOf(record)?.let { loc ->
                    val mapContext = androidx.compose.ui.platform.LocalContext.current
                    IconButton(onClick = { openMapsAt(mapContext, loc.first, loc.second) }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.LocationOn, contentDescription = "লোকেশন দেখুন", tint = Color(0xFF2563EB), modifier = Modifier.size(20.dp))
                    }
                }
                // v113-260 — same universal ⋮ menu as the List row, now also
                // on the Detail screen itself (the person's own confirmed
                // scope: "List row, Detail screen").
                UniversalActionMenu(
                    moduleReference = config.auditEntityType,
                    entityId = config.idOf(record),
                    entityLabel = "${config.entityLabel}: ${config.titleOf(record)}",
                    shareText = browseRecordShareText(config, record),
                    csvHeader = browseRecordCsvHeader(config),
                    csvRow = browseRecordCsvRow(config, record),
                )
                // v113-276 — the person's own direct instruction: the
                // module-level ⋮ (ModuleDrawerScaffold's own top button)
                // should offer this SAME record's rich actions too, not
                // just this inline one — same real data this screen's own
                // inline UniversalActionMenu call above already builds,
                // registered once more so the top-level ⋮ can render the
                // identical UniversalActionMenuBody.
                RegisterRecordActionMenu(
                    moduleReference = config.auditEntityType,
                    entityId = config.idOf(record),
                    entityLabel = "${config.entityLabel}: ${config.titleOf(record)}",
                    shareText = browseRecordShareText(config, record),
                    csvHeader = browseRecordCsvHeader(config),
                    csvRow = browseRecordCsvRow(config, record),
                )
            }
            Spacer(Modifier.height(12.dp)); Divider(); Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                if (config.hasLedger) BrowseDetailAction(Icons.Filled.MenuBook, "Ledger", config.colorStart) { sub = "ledger" }
                if (config.has90Day) BrowseDetailAction(Icons.Filled.TrendingUp, "90 Days", config.colorStart) { sub = "90d" }
                if (config.hasGraph) BrowseDetailAction(Icons.Filled.PieChart, "Graph", config.colorStart) { sub = "graph" }
                if (config.hasLedger) BrowseDetailAction(Icons.Filled.CalendarMonth, "Calendar", config.colorStart) { sub = "calendar" }
            }
            // v113-283 — the person's own direct instruction: no separate
            // "QR Card" action here anymore (issue/reissue is Chairman
            // Dealer Control-only now, v113-282) — a real, bigger status
            // card instead, right in the regular flow, not hidden behind
            // a tap-through. Deliberately status-only, not the actual
            // scannable pattern: the same real constraint
            // ModuleBrowseQrCard's own comment already explains — only a
            // token hash is ever stored, the real payload only exists
            // right after a fresh issue, so there is nothing safe to
            // re-render here without reissuing (a Chairman-only, and
            // destructive-to-the-old-code, action).
            if (config.enableQrCard) {
                Spacer(Modifier.height(10.dp))
                ModuleBrowseQrStatusCard(config, record)
            }
        }

        if (tabs.size > 1) {
            // v113-260 — the person's own direct report, with a screenshot:
            // the fixed-width TabRow divides the row equally across all
            // tabs, so a screen with 6-8 extraTabs (Status Control/Merge-
            // Transfer/Stock/Account/Complaint/Sales Report, etc.) gave
            // each tab so little width that its own label wrapped letter-
            // by-letter, vertically. Switched to ScrollableTabRow — each
            // tab takes only the width its own text needs, and the whole
            // row scrolls horizontally once there are more than fit, which
            // is the standard Material3 fix for this exact shape of
            // problem and matches the person's own "ছোট, বক্সে" request.
            ScrollableTabRow(selectedTabIndex = tab, containerColor = Color.White, edgePadding = 12.dp) {
                tabs.forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, fontSize = 12.sp, maxLines = 1, softWrap = false) })
                }
            }
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp)) {
            if (tab == 0) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Basic Information", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    config.infoRows(record).forEach { r ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(r.label, fontSize = 12.sp, color = TextSecondary)
                            Text(r.value, fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Medium, maxLines = 1)
                        }
                    }
                }
                val kpis = config.kpis(record)
                if (kpis.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth()) {
                            kpis.forEach { k -> BrowseStatCell(k.label, k.value, k.color, Modifier.weight(1f)) }
                        }
                    }
                }
            } else {
                config.extraTabContent(record, tab, onNavigate)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

/**
 * v113-283 — the real, bigger QR status view that replaced the small
 * tap-through icon in the regular Dealer/Retailer/Employee/Product
 * Detail flow. View-only by design (see the comment at its own call
 * site) — Issue/Reissue lives exclusively in Chairman's own Dealer
 * Control now (v113-282). Same real `QrRegistry.activeFor` check
 * `ModuleBrowseQrCard`/`DmsDealerControlQrSection` already use, not a
 * fourth implementation of the same lookup.
 */
@Composable
private fun <T> ModuleBrowseQrStatusCard(config: BrowseConfig<T>, record: T) {
    val entityType = config.qrEntityType ?: return
    var checked by remember(config.idOf(record)) { mutableStateOf(false) }
    var activeRow by remember(config.idOf(record)) { mutableStateOf<com.abm.erp.data.room.QrRegistryEntity?>(null) }
    LaunchedEffect(config.idOf(record)) {
        activeRow = com.abm.erp.data.QrRegistry.activeFor(entityType, config.idOf(record))
        checked = true
    }
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (activeRow != null) SuccessGreen.copy(alpha = 0.08f) else WarningAmber.copy(alpha = 0.08f),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (activeRow != null) SuccessGreen.copy(alpha = 0.35f) else WarningAmber.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(10.dp))
                    .background(if (activeRow != null) SuccessGreen.copy(alpha = 0.15f) else WarningAmber.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.QrCode2, contentDescription = null,
                    tint = if (activeRow != null) SuccessGreen else WarningAmber, modifier = Modifier.size(26.dp),
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    when { !checked -> "QR স্ট্যাটাস দেখা হচ্ছে…"; activeRow != null -> "QR Code ইস্যু করা আছে" else -> "কোনো QR Code ইস্যু করা নেই" },
                    fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 14.sp,
                )
                Text(
                    "Issue/Reissue শুধুমাত্র Chairman → Dealer Control থেকে করা যায়।",
                    style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                )
            }
        }
    }
}

@Composable
private fun BrowseDetailAction(icon: ImageVector, label: String, accent: Long, onClick: () -> Unit) {
    Column(Modifier.clickable { onClick() }.padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = label, tint = Color(accent), modifier = Modifier.size(18.dp))
        Text(label, fontSize = 9.sp, color = TextSecondary)
    }
}

// ── 3. Ledger ──────────────────────────────────────────────────────────────────

@Composable
fun <T> ModuleBrowseLedger(config: BrowseConfig<T>, record: T, activities: List<BrowseActivity>, onBack: () -> Unit) {
    val sorted = remember(activities) { activities.sortedBy { it.date } }
    val debit = sorted.filter { it.isDebit == true }.sumOf { it.amount }
    val credit = sorted.filter { it.isDebit == false }.sumOf { it.amount }

    // v113-263 — the person's own confirmed, concrete example: this exact
    // screen. A ledger has no single per-row record for UniversalActionMenu
    // to attach to, so this registers the whole table with the module's
    // own ⋮ instead — real rows built from the same real ledger entries
    // already rendered below, not fabricated.
    RegisterModuleMenuContent(
        title = "Ledger — ${config.titleOf(record)}",
        rows = buildList {
            add("Party" to "${config.titleOf(record)} (${config.codeOf(record)})")
            add("Total Debit" to "৳${"%,.0f".format(debit)}")
            add("Total Credit" to "৳${"%,.0f".format(credit)}")
            sorted.forEach { e ->
                add("${e.date} — ${e.title}" to (if (e.isDebit == true) "Dr ৳${"%,.0f".format(e.amount)}" else "Cr ৳${"%,.0f".format(e.amount)}"))
            }
            sorted.lastOrNull()?.balanceAfter?.let { add("Closing Balance" to "৳${"%,.0f".format(it)}") }
        },
    )

    Column(Modifier.fillMaxSize().background(DashBg)) {
        BrowseTopBar("Ledger", config.titleOf(record), config.colorStart, config.colorEnd, onBack)
        Column(Modifier.background(Color.White).padding(14.dp)) {
            Text("${config.titleOf(record)} (${config.codeOf(record)})", fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(
                if (sorted.isEmpty()) "কোনো এন্ট্রি নেই" else "${sorted.first().date} – ${sorted.last().date}",
                fontSize = 11.sp, color = TextSecondary,
            )
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth()) {
                BrowseStatCell("Total Debit", "৳${"%,.0f".format(debit)}", modifier = Modifier.weight(1f))
                BrowseStatCell("Total Credit", "৳${"%,.0f".format(credit)}", SuccessGreen, Modifier.weight(1f))
                BrowseStatCell("Entries", "${sorted.size}", modifier = Modifier.weight(1f))
            }
        }
        Row(Modifier.fillMaxWidth().background(DashBg).padding(horizontal = 12.dp, vertical = 6.dp)) {
            Text("Date", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.weight(1.1f))
            Text("Particulars", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.weight(2f))
            Text("Debit", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.weight(1f))
            Text("Credit", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.weight(1f))
            Text("Balance", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.weight(1.1f))
        }
        LazyColumn(Modifier.weight(1f)) {
            if (sorted.isEmpty()) {
                item { Text("কোনো ledger এন্ট্রি নেই।", color = TextSecondary, modifier = Modifier.padding(20.dp)) }
            }
            items(sorted) { e ->
                Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Text("${e.date.dayOfMonth} ${e.date.month.name.take(3)}", fontSize = 11.sp, color = TextPrimary, modifier = Modifier.weight(1.1f))
                    Text(e.title, fontSize = 11.sp, color = TextPrimary, maxLines = 2, modifier = Modifier.weight(2f))
                    Text(if (e.isDebit == true) "%,.0f".format(e.amount) else "-", fontSize = 11.sp, color = DangerRed, modifier = Modifier.weight(1f))
                    Text(if (e.isDebit == false) "%,.0f".format(e.amount) else "-", fontSize = 11.sp, color = SuccessGreen, modifier = Modifier.weight(1f))
                    Text(e.balanceAfter?.let { "%,.0f".format(it) } ?: "-", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary, modifier = Modifier.weight(1.1f))
                }
                Divider()
            }
        }
        sorted.lastOrNull()?.balanceAfter?.let {
            Row(Modifier.fillMaxWidth().background(Color.White).padding(12.dp), horizontalArrangement = Arrangement.End) {
                Text("Closing Balance: ৳${"%,.0f".format(it)}", fontWeight = FontWeight.Bold, color = TextPrimary)
            }
        }
    }
}

// ── 4. Graph ───────────────────────────────────────────────────────────────────

@Composable
fun <T> ModuleBrowseGraph(config: BrowseConfig<T>, record: T, onBack: () -> Unit) {
    val slices = config.slices(record).sortedByDescending { it.amount }
    val total = slices.sumOf { it.amount }
    val palette = listOf(Color(0xFF5B8DEF), Color(0xFFF5A623), Color(0xFF22A06B), Color(0xFFDC3626), Color(0xFF9AA5B4))

    Column(Modifier.fillMaxSize().background(DashBg)) {
        BrowseTopBar(config.graphTitle, config.titleOf(record), config.colorStart, config.colorEnd, onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp)) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Total", fontSize = 11.sp, color = TextSecondary)
                Text(config.sliceFormat(total), fontWeight = FontWeight.Bold, fontSize = 20.sp, color = TextPrimary)
            }
            Spacer(Modifier.height(12.dp))
            if (slices.isEmpty()) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("কোনো line item নেই — তাই ভাগ দেখানো যাচ্ছে না।", fontSize = 12.sp, color = TextSecondary)
                }
            } else {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Split", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    slices.take(5).forEachIndexed { i, s ->
                        val pct = if (total > 0) s.amount / total else 0.0
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(palette[i % palette.size]))
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(s.label, fontSize = 12.sp, color = TextPrimary, maxLines = 1)
                                    Text("${config.sliceFormat(s.amount)} (${"%.1f".format(pct * 100)}%)", fontSize = 11.sp, color = TextSecondary)
                                }
                                Spacer(Modifier.height(3.dp))
                                Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(999.dp)).background(DashBg)) {
                                    Box(Modifier.fillMaxWidth(pct.toFloat().coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(999.dp)).background(palette[i % palette.size]))
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ── 5. 90-Day Summary ──────────────────────────────────────────────────────────

@Composable
fun <T> ModuleBrowse90Day(config: BrowseConfig<T>, record: T, onBack: () -> Unit) {
    val cells = config.summary90(record)
    Column(Modifier.fillMaxSize().background(DashBg)) {
        BrowseTopBar("90 Days Summary — ${config.codeOf(record)}", config.titleOf(record), config.colorStart, config.colorEnd, onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp)) {
            if (cells.isEmpty()) {
                GlassCard(modifier = Modifier.fillMaxWidth()) { Text("এই ৯০ দিনে কোনো কার্যক্রম নেই।", fontSize = 12.sp, color = TextSecondary) }
            }
            cells.chunked(3).forEach { row ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth()) {
                        row.forEach { k -> BrowseStatCell(k.label, k.value, k.color, Modifier.weight(1f)) }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ── 6. Calendar ────────────────────────────────────────────────────────────────

@Composable
fun <T> ModuleBrowseCalendar(config: BrowseConfig<T>, record: T, activities: List<BrowseActivity>, onBack: () -> Unit) {
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selectedDay by remember { mutableStateOf(LocalDate.now()) }
    val byDay = remember(activities) { activities.groupBy { it.date } }

    Column(Modifier.fillMaxSize().background(DashBg)) {
        BrowseTopBar("Calendar View", config.titleOf(record), config.colorStart, config.colorEnd, onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(14.dp)) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    IconButton(onClick = { month = month.minusMonths(1) }) { Icon(Icons.Filled.ChevronLeft, "Previous", tint = TextPrimary) }
                    Text("${month.month.name.lowercase().replaceFirstChar { it.uppercase() }} ${month.year}", fontWeight = FontWeight.Bold, color = TextPrimary)
                    IconButton(onClick = { month = month.plusMonths(1) }) { Icon(Icons.Filled.ChevronRight, "Next", tint = TextPrimary) }
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth()) {
                    listOf("S", "M", "T", "W", "T", "F", "S").forEach {
                        Text(it, fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                    }
                }
                val firstDow = month.atDay(1).dayOfWeek.value % 7
                val cells = (0 until firstDow).map { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
                cells.chunked(7).forEach { week ->
                    Row(Modifier.fillMaxWidth()) {
                        week.forEach { day ->
                            Box(Modifier.weight(1f).padding(2.dp), contentAlignment = Alignment.Center) {
                                if (day != null) {
                                    val has = byDay.containsKey(day)
                                    val isSel = day == selectedDay
                                    Column(
                                        Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                                            .background(if (isSel) Color(config.colorStart) else Color.Transparent)
                                            .clickable { selectedDay = day }.padding(vertical = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                    ) {
                                        Text("${day.dayOfMonth}", fontSize = 11.sp, color = if (isSel) Color.White else TextPrimary)
                                        if (has) Box(Modifier.size(4.dp).clip(CircleShape).background(if (isSel) Color.White else Color(config.colorStart)))
                                    }
                                }
                            }
                        }
                        repeat(7 - week.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            val dayItems = byDay[selectedDay].orEmpty()
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("$selectedDay", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                Spacer(Modifier.height(6.dp))
                if (dayItems.isEmpty()) Text("এই দিনে কোনো কার্যক্রম নেই।", fontSize = 12.sp, color = TextSecondary)
                dayItems.forEach {
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${it.title} · ${it.kind}", fontSize = 12.sp, color = TextPrimary, maxLines = 1)
                        Text("৳${"%,.0f".format(it.amount)}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = if (it.isDebit == false) SuccessGreen else TextPrimary)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

