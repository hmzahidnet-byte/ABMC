package com.abm.erp.ui.hr

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.AttachmentType
import com.abm.erp.data.CascadeEngine
import com.abm.erp.data.EmployeeProfile
import com.abm.erp.data.HrPolicyEngine
import com.abm.erp.data.MockRepository
import com.abm.erp.data.SalaryEngine
import com.abm.erp.data.UserRole
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.DarazOrangeDark
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import java.time.LocalDate

/**
 * v113-394 — HR নীতি ও নথি।
 *
 * পাঁচটা জিনিস যা ছাড়া HRM "প্রপার" বলা যায় না:
 * প্রভিডেন্ট ফান্ড · ছুটির balance · নিয়োগপত্র · কর্মীর নথি · exit process।
 *
 * সবই একজন কর্মী বেছে নিয়ে — কারণ পাঁচটাই ব্যক্তিভিত্তিক, আর এক জায়গায়
 * থাকলে "এই লোকটার সব কাগজপত্র" এক পর্দাতেই পাওয়া যায়।
 */
@Composable
fun HrPolicyTab() {
    val employees by MockRepository.employeeProfiles.collectAsState()
    val live = remember(employees) { employees.filter { !it.isDeleted } }
    var pickedId by remember { mutableStateOf<String?>(null) }
    val emp = remember(live, pickedId) { live.firstOrNull { it.id == pickedId } ?: live.firstOrNull() }
    val isChairman = MockRepository.currentUser.role == UserRole.CHAIRMAN
    val canEdit = CascadeEngine.wingOf(MockRepository.currentUser.role) == CascadeEngine.Wing.OFFICE

    var msg by remember { mutableStateOf<String?>(null) }
    var ok by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().background(com.abm.erp.theme.DashBg)
            .verticalScroll(rememberScrollState()).imePadding().padding(12.dp),
    ) {
        if (live.isEmpty()) {
            Card { Text("কোনো employee নেই।", fontSize = 11.sp, color = TextSecondary) }
            return@Column
        }

        Card {
            Text("কার তথ্য", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(Modifier.height(6.dp))
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                live.take(15).forEach { e ->
                    val on = e.id == emp?.id
                    Box(
                        Modifier.clip(RoundedCornerShape(14.dp))
                            .background(if (on) DarazOrange else Color.White)
                            .border(1.dp, if (on) DarazOrange else HairlineBorder, RoundedCornerShape(14.dp))
                            .clickable { pickedId = e.id }
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                    ) {
                        Text(
                            e.fullName.take(12), fontSize = 10.5.sp, fontWeight = FontWeight.Bold,
                            color = if (on) Color.White else TextSecondary, maxLines = 1,
                        )
                    }
                }
            }
        }

        val target = emp ?: return@Column
        Spacer(Modifier.height(10.dp))
        PolicyCard(target, canEdit) { e -> ok = e.isBlank(); msg = if (e.isBlank()) "✔ নীতি সংরক্ষিত" else "✖ $e" }
        Spacer(Modifier.height(10.dp))
        PfCard(target)
        Spacer(Modifier.height(10.dp))
        LeaveBalanceCard(target)
        Spacer(Modifier.height(10.dp))
        LettersCard(target)
        Spacer(Modifier.height(10.dp))
        DocumentsCard(target) { e -> ok = e.isBlank(); msg = if (e.isBlank()) "✔ নথি যুক্ত হয়েছে" else "✖ $e" }
        if (isChairman) {
            Spacer(Modifier.height(10.dp))
            ExitCard(target) { e -> ok = e.isBlank(); msg = if (e.isBlank()) "✔ বিদায় সম্পন্ন" else "✖ $e" }
        }
        msg?.let {
            Spacer(Modifier.height(10.dp))
            Text(it, fontSize = 11.sp, color = if (ok) SuccessGreen else DangerRed, lineHeight = 16.sp)
        }
        Spacer(Modifier.height(24.dp))
    }
}

/* ── নীতি: PF % ও বার্ষিক ছুটি ─────────────────────────────────────────── */

@Composable
private fun PolicyCard(emp: EmployeeProfile, canEdit: Boolean, onDone: (String) -> Unit) {
    var pf by remember(emp.id, emp.pfPercent) { mutableStateOf(if (emp.pfPercent > 0) trim(emp.pfPercent) else "") }
    var leave by remember(emp.id, emp.annualLeaveDays) { mutableStateOf(if (emp.annualLeaveDays > 0) "${emp.annualLeaveDays}" else "") }

    Card {
        Head("নীতি", if (canEdit) "" else "শুধু Wing 1 বদলাতে পারে")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Num(pf, "PF % (বেসিকের)", Modifier.weight(1f), canEdit) { pf = it }
            Num(leave, "বার্ষিক ছুটি (দিন)", Modifier.weight(1f), canEdit) { leave = it }
        }
        if (canEdit) {
            Spacer(Modifier.height(8.dp))
            Big("নীতি সংরক্ষণ", true) {
                // v113-394 — PF ও ছুটি বেতনের গঠনের অংশ, তাই একই fun দিয়ে
                // সংরক্ষণ — দুটো আলাদা path থাকলে একটায় লিখে আরেকটায় ভুলে
                // যাওয়ার সুযোগ থাকত
                MockRepository.updateHrPolicy(
                    employeeId = emp.id,
                    pfPercent = pf.toDoubleOrNull() ?: 0.0,
                    annualLeaveDays = leave.toIntOrNull() ?: 0,
                    onResult = onDone,
                )
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(
            "PF শতাংশে রাখা — বেতন বাড়লে PF-ও আপনাআপনি বাড়ে। কোম্পানির অংশ সমান ধরা হয়।",
            fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
        )
    }
}

/* ── PF ─────────────────────────────────────────────────────────────────── */

@Composable
private fun PfCard(emp: EmployeeProfile) {
    val pf = remember(emp) { HrPolicyEngine.pfOf(emp) }
    Card {
        Head("প্রভিডেন্ট ফান্ড", if (pf.monthsServed > 0) "${pf.monthsServed} মাস" else "—")
        if (emp.pfPercent <= 0.0) {
            Text("এই কর্মীর PF নীতি বসানো হয়নি।", fontSize = 10.5.sp, color = TextSecondary)
            return@Card
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Mini("কর্মীর অংশ", "৳${num(pf.monthlyEmployee)}", Color(0xFF2563EB), Modifier.weight(1f))
            Mini("কোম্পানির", "৳${num(pf.monthlyCompany)}", SuccessGreen, Modifier.weight(1f))
            Mini("মাসিক মোট", "৳${num(pf.monthlyTotal)}", DarazOrangeDark, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(11.dp)).background(Color(0xFFFFF3EC))
                .border(1.5.dp, DarazOrange, RoundedCornerShape(11.dp)).padding(11.dp),
        ) {
            Text("জমা (আনুমানিক)", Modifier.weight(1f), fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text("৳${num(pf.accumulated)}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = DarazOrange)
        }
        Spacer(Modifier.height(5.dp))
        Text(
            "⚠ আনুমানিক — আজকের বেসিক × চাকরির মাস ধরে হিসাব। প্রতি মাসের আসল কর্তন " +
                "আলাদা করে রাখা হয় না, তাই বেতন বদলে থাকলে সংখ্যাটা একটু আলাদা হবে।",
            fontSize = 9.5.sp, color = WarningAmber, lineHeight = 14.sp,
        )
    }
}

/* ── ছুটির balance ─────────────────────────────────────────────────────── */

@Composable
private fun LeaveBalanceCard(emp: EmployeeProfile) {
    val leaves by MockRepository.leaveRequests.collectAsState()
    val b = remember(emp, leaves) { HrPolicyEngine.leaveBalanceOf(emp, leaves = leaves) }
    Card {
        Head("ছুটির balance", "${LocalDate.now().year}")
        if (b.entitled <= 0) {
            Text("বার্ষিক ছুটির নীতি বসানো হয়নি।", fontSize = 10.5.sp, color = TextSecondary)
            return@Card
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Mini("প্রাপ্য", "${b.entitled}", Color(0xFF2563EB), Modifier.weight(1f))
            Mini("নেওয়া", "${b.taken}", DarazOrangeDark, Modifier.weight(1f))
            Mini("বাকি", "${b.remaining}", if (b.remaining > 0) SuccessGreen else DangerRed, Modifier.weight(1f))
            if (b.pending > 0) Mini("অপেক্ষায়", "${b.pending}", WarningAmber, Modifier.weight(1f))
        }
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            repeat(b.entitled.coerceAtMost(30)) { i ->
                Box(
                    Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp))
                        .background(if (i < b.taken) DarazOrange else Color(0xFFE5E9EF)),
                )
            }
        }
        if (b.overTaken > 0) {
            Spacer(Modifier.height(6.dp))
            Text(
                "প্রাপ্যের চেয়ে ${b.overTaken} দিন বেশি নেওয়া হয়েছে — বেতন কাটার সিদ্ধান্ত Wing 1-এর।",
                fontSize = 9.5.sp, color = DangerRed, lineHeight = 14.sp,
            )
        }
        Spacer(Modifier.height(5.dp))
        Text(
            "শুধু কর্মদিবস গোনা হয় — শুক্রবার বা ঘোষিত ছুটি মাঝে পড়লে সেগুলো ছুটি হিসেবে ধরা হয় না।",
            fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
        )
    }
}

/* ── চিঠি ──────────────────────────────────────────────────────────────── */

@Composable
private fun LettersCard(emp: EmployeeProfile) {
    val context = LocalContext.current
    Card {
        Head("চিঠি", "PDF")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            LetterBtn(Icons.Filled.Description, "নিয়োগপত্র", Modifier.weight(1f)) {
                openPdf(context, com.abm.erp.core.exportEmployeeLetterPdf(context, emp, "APPOINTMENT"))
            }
            LetterBtn(Icons.Filled.VerifiedUser, "স্থায়ীকরণ", Modifier.weight(1f)) {
                openPdf(context, com.abm.erp.core.exportEmployeeLetterPdf(context, emp, "CONFIRMATION"))
            }
            LetterBtn(Icons.Filled.WorkspacePremium, "অভিজ্ঞতা", Modifier.weight(1f)) {
                openPdf(context, com.abm.erp.core.exportEmployeeLetterPdf(context, emp, "EXPERIENCE"))
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(
            "চিঠিতে বেতনের গঠন, PF ও ছুটির নীতি আপনাআপনি বসে — হাতে লিখতে হয় না, " +
                "তাই কাগজ আর অ্যাপ কখনো আলাদা কথা বলে না।",
            fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
        )
    }
}

/* ── নথি ───────────────────────────────────────────────────────────────── */

@Composable
private fun DocumentsCard(emp: EmployeeProfile, onDone: (String) -> Unit) {
    val context = LocalContext.current
    // grep করে আসল নাম নিলাম: `attachments` নামে কোনো StateFlow নেই,
    // আছে `attachmentsFor(module, entityId)` — যা ইতিমধ্যেই ছাঁকা Flow দেয়,
    // তাই এখানে আর filter করার দরকার নেই।
    val mine by MockRepository.attachmentsFor("EmployeeProfile", emp.id)
        .collectAsState(initial = emptyList())
    val docLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            MockRepository.uploadAttachment(
                context = context, moduleReference = "EmployeeProfile", entityId = emp.id,
                type = AttachmentType.DOCUMENT, localUri = uri.toString(),
                onRejected = { onDone(it) },
                onResult = { if (it != null) onDone("") },
            )
        }
    }

    Card {
        Head("কর্মীর নথি", "${mine.size}টি")
        if (mine.isEmpty()) {
            Text("NID, সার্টিফিকেট, ছবি — কিছুই যুক্ত করা হয়নি।", fontSize = 10.5.sp, color = TextSecondary)
        }
        mine.forEach { a ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(30.dp).clip(RoundedCornerShape(9.dp)).background(Color(0xFFEEF4FF)),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Description, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(15.dp)) }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(a.type.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(
                        "${a.uploadedBy} · ${if (a.uri.startsWith("file:")) "শুধু এই ফোনে" else "সংরক্ষিত"}",
                        fontSize = 9.sp,
                        // file:// মানে Storage-এ যায়নি — সৎভাবে বলা, নইলে
                        // কেউ ভাবত নথি নিরাপদে আছে
                        color = if (a.uri.startsWith("file:")) WarningAmber else TextSecondary,
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Big("নথি যোগ করুন", true) { docLauncher.launch("*/*") }
    }
}

/* ── Exit ──────────────────────────────────────────────────────────────── */

@Composable
private fun ExitCard(emp: EmployeeProfile, onDone: (String) -> Unit) {
    var reason by remember(emp.id) { mutableStateOf("") }
    var confirming by remember(emp.id) { mutableStateOf(false) }
    val lastDay = remember { LocalDate.now() }
    val settle = remember(emp, lastDay) { HrPolicyEngine.exitSettlement(emp, lastDay) }

    Card(accent = DangerRed.copy(alpha = 0.35f)) {
        Head("বিদায় প্রক্রিয়া", "$lastDay")
        if (emp.exitDate != null) {
            Text("এই কর্মী ইতিমধ্যে বিদায় নিয়েছেন — ${emp.exitDate}।", fontSize = 11.sp, color = TextSecondary)
            return@Card
        }

        listOf(
            "শেষ বেতন" to settle.finalSalary,
            "PF ফেরত" to settle.pfReturn,
            "অগ্রিম আদায়যোগ্য" to -settle.advanceOutstanding,
        ).forEach { (l, v) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                Text(l, Modifier.weight(1f), fontSize = 11.sp, color = TextSecondary)
                Text(
                    (if (v < 0) "−৳" else "৳") + num(kotlin.math.abs(v)),
                    fontSize = 11.5.sp, fontWeight = FontWeight.Bold,
                    color = if (v < 0) DangerRed else TextPrimary,
                )
            }
        }
        Divider(Modifier.padding(vertical = 7.dp))
        Row(Modifier.fillMaxWidth()) {
            Text("নিট প্রদেয়", Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(
                "৳${num(settle.netPayable)}", fontSize = 16.sp, fontWeight = FontWeight.Bold,
                color = if (settle.netPayable >= 0) DarazOrange else DangerRed,
            )
        }
        if (settle.unusedLeaveDays > 0) {
            Text(
                "অব্যবহৃত ছুটি ${settle.unusedLeaveDays} দিন — নগদায়ন করবেন কি না Wing 1-এর সিদ্ধান্ত।",
                fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
            )
        }

        if (settle.blockers.isNotEmpty()) {
            Spacer(Modifier.height(9.dp))
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFFFDECEA))
                    .border(1.dp, DangerRed, RoundedCornerShape(10.dp)).padding(10.dp),
            ) {
                Text("আগে এগুলো সারতে হবে", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DangerRed)
                settle.blockers.forEach {
                    Text("• $it", fontSize = 10.sp, color = DangerRed, lineHeight = 15.sp)
                }
            }
            Spacer(Modifier.height(5.dp))
            Text(
                "না সারলে তার দায়িত্বের জিনিসগুলো মালিকহীন হয়ে যাবে — cascade উপরের কাউকে " +
                    "ধরিয়ে দেবে ঠিকই, কিন্তু কেউ জানবেই না।",
                fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
            )
        }

        Spacer(Modifier.height(9.dp))
        OutlinedTextField(
            value = reason, onValueChange = { reason = it },
            label = { Text("বিদায়ের কারণ", fontSize = 10.sp) }, singleLine = true,
            textStyle = MaterialTheme.typography.bodySmall,
            modifier = Modifier.fillMaxWidth().height(56.dp),
        )
        Spacer(Modifier.height(8.dp))
        Big("বিদায় সম্পন্ন করুন", settle.canClose && reason.isNotBlank(), DangerRed) { confirming = true }
    }

    if (confirming) {
        AlertDialog(
            onDismissRequest = { confirming = false },
            title = { Text("বিদায় সম্পন্ন?") },
            text = {
                Text(
                    "${emp.fullName} — শেষ কর্মদিবস $lastDay।\n\n" +
                        "এর পর তিনি আর কোনো পদের দায়িত্বে থাকবেন না, লগইনও বন্ধ হবে। " +
                        "পুরনো মাসের হিসাব অক্ষত থাকবে।",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirming = false
                    HrPolicyEngine.completeExit(emp.id, lastDay, reason.trim(), onDone)
                }) { Text("হ্যাঁ, সম্পন্ন", color = DangerRed) }
            },
            dismissButton = { TextButton(onClick = { confirming = false }) { Text("না, থাক") } },
        )
    }
}

/* ── ছোট সহায়ক ─────────────────────────────────────────────────────────── */

private fun openPdf(context: android.content.Context, file: java.io.File) {
    runCatching {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            context, "${context.packageName}.fileprovider", file,
        )
        context.startActivity(
            Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            },
        )
    }.onFailure {
        com.abm.erp.config.AppLog.w("HrPolicyTab", "PDF খুলতে সমস্যা", it)
    }
}

@Composable
private fun LetterBtn(icon: ImageVector, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(11.dp)).background(Color(0xFFEEF4FF))
            .clickable { onClick() }.padding(vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = label, tint = Color(0xFF2563EB), modifier = Modifier.size(19.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2563EB), maxLines = 1)
    }
}

@Composable
private fun Num(value: String, label: String, modifier: Modifier = Modifier, enabled: Boolean, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { t -> onChange(t.filter { it.isDigit() || it == '.' }.take(6)) },
        label = { Text(label, fontSize = 9.5.sp) }, singleLine = true, enabled = enabled,
        textStyle = MaterialTheme.typography.bodySmall,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier.height(56.dp),
    )
}

@Composable
private fun Mini(label: String, value: String, ink: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFFF7F8FA)).padding(vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(label, fontSize = 8.5.sp, color = TextSecondary, maxLines = 1)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ink, maxLines = 1)
    }
}

@Composable
private fun Head(title: String, badge: String) {
    Row(Modifier.fillMaxWidth().padding(bottom = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        if (badge.isNotBlank()) Text(badge, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = DarazOrangeDark)
    }
}

@Composable
private fun Big(text: String, enabled: Boolean, tint: Color = DarazOrange, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
            .background(if (enabled) tint else Color(0xFFCBD5E1))
            .clickable(enabled = enabled) { onClick() }.padding(vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White) }
}

@Composable
private fun Card(accent: Color? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color.White)
            .border(1.dp, accent ?: HairlineBorder, RoundedCornerShape(13.dp)).padding(11.dp),
        content = content,
    )
}

private fun num(v: Double): String =
    if (kotlin.math.abs(v % 1.0) < 0.001) "%,.0f".format(v) else "%,.2f".format(v)

private fun trim(v: Double): String =
    if (kotlin.math.abs(v % 1.0) < 0.001) v.toInt().toString() else "%.2f".format(v).trimEnd('0').trimEnd('.')
