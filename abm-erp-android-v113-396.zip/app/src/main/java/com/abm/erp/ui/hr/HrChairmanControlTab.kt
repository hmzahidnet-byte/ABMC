package com.abm.erp.ui.hr

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.AttendanceEngine
import com.abm.erp.data.CascadeEngine
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.MockRepository
import com.abm.erp.data.SalaryEngine
import com.abm.erp.data.TargetEngine
import com.abm.erp.data.UserRole
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.DarazOrangeDark
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import kotlinx.coroutines.launch
import java.time.LocalDate

/**
 * v113-393 — Chairman-এর HR নিয়ন্ত্রণ কেন্দ্র।
 *
 * *"HR এ chairman drawer আরও icon based, আরও function লাগবে... কেননা এটা হবে
 * একটা ১০০% proper HRM software"* — তাই এখানে **শুধু HR-এর** জিনিস; DMS/FMS
 * আলাদা, DMS-এর মতোই।
 *
 * ছয়টা আইকন-tile, প্রতিটার নিচে **বর্তমান অবস্থা** — কোনটায় হাত দিতে হবে তা
 * খুলে না দেখেই বোঝা যায়। DMS-এর Chairman drawer-এ নেওয়া একই ধরন।
 *
 * সবচেয়ে বড় ফাঁক যা এখানে ভরা হলো: **জাতীয় টার্গেট বসানোর পর্দা**।
 * `TargetEngine.setNationalTarget()` v113-381-এ লেখা হয়েছিল, কিন্তু কেউ
 * ডাকত না — অর্থাৎ চেয়ারম্যান টার্গেট বসাতেই পারতেন না, ফলে বণ্টনের পাতা
 * চিরকাল খালি দেখাত।
 */
@Composable
fun HrChairmanControlTab() {
    val me = MockRepository.currentUser
    if (me.role != UserRole.CHAIRMAN) {
        Column(Modifier.fillMaxSize().background(com.abm.erp.theme.DashBg).padding(16.dp)) {
            Card { Text("এই অংশ কেবল Chairman-এর জন্য।", fontSize = 11.5.sp, color = DangerRed) }
        }
        return
    }

    var open by remember { mutableStateOf<String?>(null) }
    val employees by MockRepository.employeeProfiles.collectAsState()
    val allTargets by MockRepository.targets.collectAsState()
    val advances by MockRepository.employeeAdvances.collectAsState()
    val live = remember(employees) { employees.filter { !it.isDeleted } }

    val today = remember { LocalDate.now() }
    val pStart = remember(today) { today.withDayOfMonth(1) }
    val pEnd = remember(today) { today.withDayOfMonth(today.lengthOfMonth()) }
    val settings = remember(employees) { MockRepository.companySettings() }
    val holidays = remember(settings.holidaysRaw) { AttendanceEngine.parseHolidays(settings.holidaysRaw) }
    val nationals = remember(allTargets, pStart) { TargetEngine.nationalTargets(pStart, pEnd, allTargets) }
    val vacancies = remember(live, today) { CascadeEngine.vacanciesOn(today, live) }
    val noRate = remember(live) {
        live.count { CascadeEngine.wingOf(it.role) == CascadeEngine.Wing.FIELD && it.ownCommissionPct <= 0.0 }
    }
    val noLogin = remember(live) { live.count { it.mobile.isBlank() } }

    Column(
        Modifier.fillMaxSize().background(com.abm.erp.theme.DashBg)
            .verticalScroll(rememberScrollState()).imePadding().padding(12.dp),
    ) {
        when (open) {
            "target" -> NationalTargetPanel(pStart, pEnd) { open = null }
            "holiday" -> HolidayPanel(holidays, today) { open = null }
            "rates" -> CommissionRatePanel(live) { open = null }
            "login" -> LoginSetupPanel(live) { open = null }
            else -> {
                Text("Chairman — HR নিয়ন্ত্রণ", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Spacer(Modifier.height(3.dp))
                Text(
                    "শুধু HR-এর নিয়ন্ত্রণ এখানে — DMS ও FMS আলাদা।",
                    fontSize = 9.5.sp, color = TextSecondary,
                )
                Spacer(Modifier.height(10.dp))

                // প্রতিটা tile-এর নিচে বর্তমান অবস্থা — কোথায় হাত দিতে হবে
                // তা খুলে না দেখেই বোঝা যায়
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tile(
                        Icons.Filled.TrackChanges, "জাতীয় টার্গেট",
                        if (nationals.isEmpty()) "বসানো হয়নি" else "${nationals.size} product",
                        nationals.isEmpty(), Modifier.weight(1f),
                    ) { open = "target" }
                    Tile(
                        Icons.Filled.Campaign, "ছুটি ঘোষণা",
                        if (holidays.isEmpty()) "কিছু নেই" else "${holidays.size}টি",
                        false, Modifier.weight(1f),
                    ) { open = "holiday" }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tile(
                        Icons.Filled.LocalOffer, "কমিশনের হার",
                        if (noRate > 0) "$noRate জনের হার নেই" else "সবার বসানো",
                        noRate > 0, Modifier.weight(1f),
                    ) { open = "rates" }
                    Tile(
                        Icons.Filled.Lock, "লগইন ও PIN",
                        if (noLogin > 0) "$noLogin জনের নম্বর নেই" else "সবার আছে",
                        noLogin > 0, Modifier.weight(1f),
                    ) { open = "login" }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tile(
                        Icons.Filled.AccountTree, "চেইন ও ফাঁকা পদ",
                        if (vacancies.isEmpty()) "সব পূর্ণ" else "${vacancies.size}টি ফাঁকা",
                        vacancies.isNotEmpty(), Modifier.weight(1f),
                    ) { }
                    Tile(
                        Icons.Filled.AccountBalanceWallet, "অগ্রিম",
                        "৳${"%,.0f".format(advances.filter { it.status == "APPROVED" }.sumOf { it.outstanding })} বকেয়া",
                        false, Modifier.weight(1f),
                    ) { }
                }

                Spacer(Modifier.height(12.dp))
                Text(
                    "কমলা বর্ডার = এখানে হাত দিতে হবে। চেইন ও অগ্রিমের বিস্তারিত " +
                        "drawer-এর নিজস্ব পাতায়; এখানে শুধু অবস্থা দেখানো হয়।",
                    fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

/* ── ১. জাতীয় টার্গেট ─────────────────────────────────────────────────── */

@Composable
private fun NationalTargetPanel(pStart: LocalDate, pEnd: LocalDate, onBack: () -> Unit) {
    val products by InventoryRepository.products.collectAsState()
    val allTargets by MockRepository.targets.collectAsState()
    val nationals = remember(allTargets, pStart) { TargetEngine.nationalTargets(pStart, pEnd, allTargets) }
    val active = remember(products) { products.filter { !it.isDeleted && it.isActive } }
    var msg by remember { mutableStateOf<String?>(null) }
    var ok by remember { mutableStateOf(false) }

    PanelHeader("জাতীয় টার্গেট", "${pStart.month.name.take(3)} ${pStart.year}", onBack)

    Card {
        Text(
            "product ধরে ধরে বসান — টাকার অঙ্ক আপনা থেকে হিসাব হবে। " +
                "এটাই Wing 1-এর সবার টার্গেট, আর এখান থেকেই নিচে বণ্টন হবে।",
            fontSize = 10.sp, color = TextSecondary, lineHeight = 15.sp,
        )
    }
    Spacer(Modifier.height(8.dp))

    if (active.isEmpty()) {
        Card { Text("কোনো সক্রিয় product নেই — আগে product যোগ করুন।", fontSize = 11.sp, color = DangerRed) }
    }
    active.take(15).forEach { p ->
        val existing = nationals.firstOrNull { it.productId == p.id }
        var value by remember(p.id, existing?.targetValue) {
            mutableStateOf(existing?.targetValue?.let { if (it > 0) "%,.0f".format(it).replace(",", "") else "" } ?: "")
        }
        Card {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(p.name, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
                    Text(
                        "৳${"%,.0f".format(p.defaultUnitPrice)} / ${p.unit}" +
                            (value.toDoubleOrNull()?.let { " · আনুমানিক ৳${"%,.0f".format(it * p.defaultUnitPrice)}" } ?: ""),
                        fontSize = 9.5.sp, color = DarazOrangeDark, maxLines = 1,
                    )
                }
                OutlinedTextField(
                    value = value,
                    onValueChange = { t -> value = t.filter { it.isDigit() } },
                    label = { Text(p.unit, fontSize = 9.sp) },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodySmall,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.width(104.dp).height(56.dp),
                )
                Spacer(Modifier.width(6.dp))
                Box(
                    Modifier.size(34.dp).clip(RoundedCornerShape(17.dp))
                        .background(if (value.toDoubleOrNull() ?: 0.0 > 0) DarazOrange else Color(0xFFCBD5E1))
                        .clickable(enabled = (value.toDoubleOrNull() ?: 0.0) > 0) {
                            TargetEngine.setNationalTarget(
                                productId = p.id,
                                value = value.toDoubleOrNull() ?: 0.0,
                                periodStart = pStart,
                                periodEnd = pEnd,
                                reason = "Chairman কর্তৃক নির্ধারিত",
                                onResult = { r ->
                                    when (r) {
                                        is TargetEngine.Result.Ok -> { ok = true; msg = "✔ ${p.name} — সংরক্ষিত" }
                                        is TargetEngine.Result.Rejected -> { ok = false; msg = "✖ ${r.reason}" }
                                    }
                                },
                            )
                        },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Check, contentDescription = "সংরক্ষণ", tint = Color.White, modifier = Modifier.size(17.dp)) }
            }
        }
    }
    msg?.let { Note(it, ok) }
}

/* ── ২. ছুটি ঘোষণা ────────────────────────────────────────────────────── */

@Composable
private fun HolidayPanel(
    holidays: List<AttendanceEngine.Holiday>,
    today: LocalDate,
    onBack: () -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var offset by remember { mutableStateOf(0L) }
    var msg by remember { mutableStateOf<String?>(null) }
    var ok by remember { mutableStateOf(false) }
    val picked = remember(offset) { today.plusDays(offset) }

    PanelHeader("ছুটি ঘোষণা", "${holidays.size}টি", onBack)

    Card {
        Text(
            "ঘোষণামাত্র ওই দিন সবার ছুটি — কেউ অনুপস্থিতও নয়, লোকেশন ping-ও বন্ধ। " +
                "এক ক্লিকে গোটা কোম্পানির হাজিরার হিসাব বদলায়, তাই নাম বাধ্যতামূলক।",
            fontSize = 10.sp, color = TextSecondary, lineHeight = 15.sp,
        )
        Spacer(Modifier.height(9.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            StepDot(Icons.Filled.Remove) { offset -= 1 }
            Text(
                "$picked", Modifier.weight(1f), fontSize = 12.5.sp, fontWeight = FontWeight.Bold,
                color = TextPrimary, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            StepDot(Icons.Filled.Add, filled = true) { offset += 1 }
        }
        Spacer(Modifier.height(7.dp))
        OutlinedTextField(
            value = name, onValueChange = { name = it },
            label = { Text("ছুটির নাম (ঈদ, পূজা…)", fontSize = 10.sp) }, singleLine = true,
            textStyle = MaterialTheme.typography.bodySmall,
            modifier = Modifier.fillMaxWidth().height(56.dp),
        )
        Spacer(Modifier.height(8.dp))
        BigButton("ছুটি ঘোষণা করুন", name.isNotBlank()) {
            AttendanceEngine.declareHoliday(picked, name.trim()) { e ->
                ok = e.isBlank(); msg = if (e.isBlank()) "✔ ঘোষিত — ওই দিন সবার ছুটি" else "✖ $e"
                if (e.isBlank()) name = ""
            }
        }
    }
    Spacer(Modifier.height(8.dp))
    if (holidays.isNotEmpty()) {
        Card {
            Text("ঘোষিত ছুটি", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            holidays.forEach { h ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${h.date}", fontSize = 10.5.sp, color = TextSecondary, modifier = Modifier.width(86.dp))
                    Text(h.name, Modifier.weight(1f), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
                    Box(
                        Modifier.size(26.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFFFDECEA))
                            .clickable {
                                AttendanceEngine.removeHoliday(h.date) { e ->
                                    ok = e.isBlank(); msg = if (e.isBlank()) "✔ তুলে নেওয়া হয়েছে" else "✖ $e"
                                }
                            },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.Close, contentDescription = "তুলে নিন", tint = DangerRed, modifier = Modifier.size(13.dp)) }
                }
            }
        }
    }
    msg?.let { Note(it, ok) }
}

/* ── ৩. কমিশনের হার — সবার একসাথে ─────────────────────────────────────── */

@Composable
private fun CommissionRatePanel(live: List<com.abm.erp.data.EmployeeProfile>, onBack: () -> Unit) {
    var msg by remember { mutableStateOf<String?>(null) }
    var ok by remember { mutableStateOf(false) }
    val field = remember(live) {
        live.filter { CascadeEngine.wingOf(it.role) == CascadeEngine.Wing.FIELD }
            .sortedByDescending { CascadeEngine.rankOf(it.role) }
    }

    PanelHeader("কমিশনের হার", "${field.size} জন", onBack)
    Card {
        Text(
            "নিজের বিক্রিতে এক হার, অধীনস্থদের বিক্রিতে override হার। " +
                "SR-এর override শূন্য — তার নিচে কেউ নেই। Wing 1 বিক্রি করে না, তাই তালিকায় নেই।",
            fontSize = 10.sp, color = TextSecondary, lineHeight = 15.sp,
        )
    }
    Spacer(Modifier.height(8.dp))

    field.forEach { e ->
        var own by remember(e.id, e.ownCommissionPct) {
            mutableStateOf(if (e.ownCommissionPct > 0) trimNum(e.ownCommissionPct) else "")
        }
        var ovr by remember(e.id, e.overrideCommissionPct) {
            mutableStateOf(if (e.overrideCommissionPct > 0) trimNum(e.overrideCommissionPct) else "")
        }
        Card(accent = if (e.ownCommissionPct <= 0.0) WarningAmber.copy(alpha = 0.45f) else null) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(e.fullName, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
                    Text(
                        "${e.role.name} · ${CascadeEngine.geoKeyOf(e) ?: "এলাকা নেই"}",
                        fontSize = 9.5.sp, color = TextSecondary, maxLines = 1,
                    )
                }
                SmallNum(own, "নিজের %") { own = it }
                Spacer(Modifier.width(5.dp))
                SmallNum(ovr, "override %") { ovr = it }
                Spacer(Modifier.width(5.dp))
                Box(
                    Modifier.size(32.dp).clip(RoundedCornerShape(16.dp)).background(DarazOrange)
                        .clickable {
                            SalaryEngine.setStructure(
                                employeeId = e.id,
                                basePay = e.basePayMonthly,
                                ownPct = own.toDoubleOrNull() ?: 0.0,
                                overridePct = ovr.toDoubleOrNull() ?: 0.0,
                                taDa = e.taDaMonthly,
                                onResult = { err ->
                                    ok = err.isBlank()
                                    msg = if (err.isBlank()) "✔ ${e.fullName} — হার সংরক্ষিত" else "✖ $err"
                                },
                            )
                        },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Check, contentDescription = "সংরক্ষণ", tint = Color.White, modifier = Modifier.size(16.dp)) }
            }
        }
    }
    msg?.let { Note(it, ok) }
}

/* ── ৪. লগইন নম্বর ও PIN ──────────────────────────────────────────────── */

@Composable
private fun LoginSetupPanel(live: List<com.abm.erp.data.EmployeeProfile>, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf<String?>(null) }
    var ok by remember { mutableStateOf(false) }
    var pinFor by remember { mutableStateOf<String?>(null) }

    PanelHeader("লগইন ও PIN", "${live.size} জন", onBack)
    Card {
        Text(
            "মোবাইল নম্বরই লগইনের পরিচয় — তাই এটা সাধারণ প্রোফাইল-সম্পাদনায় নেই, " +
                "কেবল এখানে। দুজনের এক নম্বর হলে লগইনে কে আসবে তা অনিশ্চিত হয়ে যেত, " +
                "তাই ডুপ্লিকেট আটকানো আছে।",
            fontSize = 10.sp, color = TextSecondary, lineHeight = 15.sp,
        )
    }
    Spacer(Modifier.height(8.dp))

    live.forEach { e ->
        var mob by remember(e.id, e.mobile) { mutableStateOf(e.mobile) }
        Card(accent = if (e.mobile.isBlank()) WarningAmber.copy(alpha = 0.45f) else null) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(e.fullName, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
                    Text(
                        e.employeeCode.ifBlank { e.id.take(8).uppercase() } +
                            (if (e.userAccountId == null) " · অ্যাকাউন্ট নেই" else ""),
                        fontSize = 9.5.sp,
                        color = if (e.userAccountId == null) WarningAmber else TextSecondary,
                        maxLines = 1,
                    )
                }
                OutlinedTextField(
                    value = mob,
                    onValueChange = { t -> mob = t.filter { it.isDigit() }.take(14) },
                    label = { Text("নম্বর", fontSize = 9.sp) }, singleLine = true,
                    textStyle = MaterialTheme.typography.bodySmall,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.width(126.dp).height(56.dp),
                )
                Spacer(Modifier.width(5.dp))
                Box(
                    Modifier.size(32.dp).clip(RoundedCornerShape(16.dp)).background(DarazOrange)
                        .clickable {
                            scope.launch {
                                val err = MockRepository.chairmanSetLoginNumber(e.id, mob)
                                ok = err.isBlank()
                                msg = if (err.isBlank()) "✔ ${e.fullName} — নম্বর সংরক্ষিত" else "✖ $err"
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Check, contentDescription = "সংরক্ষণ", tint = Color.White, modifier = Modifier.size(16.dp)) }
                Spacer(Modifier.width(4.dp))
                Box(
                    Modifier.size(32.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFFEEF4FF))
                        .clickable { pinFor = e.id },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Lock, contentDescription = "PIN", tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp)) }
            }
        }
    }
    msg?.let { Note(it, ok) }

    val target = pinFor?.let { id -> live.firstOrNull { it.id == id } }
    if (target != null) {
        var pin by remember(target.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pinFor = null },
            title = { Text("PIN — ${target.fullName}") },
            text = {
                Column {
                    Text("নতুন ৪-৬ সংখ্যার PIN দিন, অথবা রিসেট করে অস্থায়ী PIN তৈরি করুন।", fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pin,
                        onValueChange = { t -> pin = t.filter { it.isDigit() }.take(6) },
                        label = { Text("নতুন PIN", fontSize = 10.sp) }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = pin.length in 4..6,
                    onClick = {
                        val id = target.id
                        pinFor = null
                        scope.launch {
                            val r = MockRepository.chairmanSetEmployeePin(id, pin)
                            ok = r.success
                            msg = if (r.success) "✔ PIN বসানো হয়েছে" else "✖ ${r.message}"
                        }
                    },
                ) { Text("PIN বসান", color = DarazOrange) }
            },
            dismissButton = {
                TextButton(onClick = {
                    val id = target.id
                    pinFor = null
                    scope.launch {
                        val r = MockRepository.chairmanResetEmployeePin(id)
                        ok = r.success
                        // অস্থায়ী PIN বার্তায় ফেরত আসে — কর্মীকে জানানোর
                        // একমাত্র পথ, তাই সেটাই দেখানো হয়
                        msg = if (r.success) "✔ ${r.message}" else "✖ ${r.message}"
                    }
                }) { Text("রিসেট", color = DangerRed) }
            },
        )
    }
}

/* ── ছোট সহায়ক ─────────────────────────────────────────────────────────── */

@Composable
private fun Tile(
    icon: ImageVector,
    label: String,
    state: String,
    alert: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(Color.White)
            .border(1.dp, if (alert) DarazOrange else HairlineBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() }.padding(11.dp),
    ) {
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFEEF4FF)),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, contentDescription = label, tint = Color(0xFF2563EB), modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.height(7.dp))
        Text(label, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 2, lineHeight = 14.sp)
        Text(
            state, fontSize = 9.5.sp,
            color = if (alert) DarazOrangeDark else TextSecondary, maxLines = 1,
        )
    }
}

@Composable
private fun PanelHeader(title: String, badge: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(30.dp).clip(RoundedCornerShape(15.dp)).background(Color.White).clickable { onBack() },
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Filled.ArrowBack, contentDescription = "ফিরে যান", tint = TextPrimary, modifier = Modifier.size(16.dp)) }
        Spacer(Modifier.width(9.dp))
        Text(title, Modifier.weight(1f), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Text(badge, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DarazOrangeDark)
    }
}

@Composable
private fun SmallNum(value: String, label: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { t -> onChange(t.filter { it.isDigit() || it == '.' }.take(5)) },
        label = { Text(label, fontSize = 8.5.sp) }, singleLine = true,
        textStyle = MaterialTheme.typography.bodySmall,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.width(74.dp).height(56.dp),
    )
}

@Composable
private fun StepDot(icon: ImageVector, filled: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.size(28.dp).clip(RoundedCornerShape(14.dp))
            .background(if (filled) DarazOrange else Color.White)
            .border(1.dp, if (filled) DarazOrange else HairlineBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) { Icon(icon, contentDescription = null, tint = if (filled) Color.White else TextSecondary, modifier = Modifier.size(15.dp)) }
}

@Composable
private fun BigButton(text: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
            .background(if (enabled) DarazOrange else Color(0xFFCBD5E1))
            .clickable(enabled = enabled) { onClick() }.padding(vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White) }
}

@Composable
private fun Note(text: String, ok: Boolean) {
    Spacer(Modifier.height(8.dp))
    Text(text, fontSize = 11.sp, color = if (ok) SuccessGreen else DangerRed, lineHeight = 16.sp)
    Spacer(Modifier.height(16.dp))
}

@Composable
private fun Card(accent: Color? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color.White)
            .border(1.dp, accent ?: HairlineBorder, RoundedCornerShape(13.dp))
            .padding(11.dp),
        content = content,
    )
    Spacer(Modifier.height(7.dp))
}

/** ২.০ → "2", ২.৫ → "2.5" — অপ্রয়োজনীয় দশমিক পড়তে বিরক্ত লাগে। */
private fun trimNum(v: Double): String =
    if (kotlin.math.abs(v % 1.0) < 0.001) v.toInt().toString() else "%.2f".format(v).trimEnd('0').trimEnd('.')
