package com.abm.erp.data

import java.time.LocalDate
import java.time.temporal.ChronoUnit

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * v113-394 — HR POLICY ENGINE
 *
 * তিনটে জিনিস, যেগুলো ছাড়া HRM-টা "প্রপার" বলা যায় না:
 *   · প্রভিডেন্ট ফান্ড
 *   · ছুটির balance — কার কত প্রাপ্য, কত নেওয়া হয়েছে, কত বাকি
 *   · Exit process — শেষ বেতন, অগ্রিম আদায়, PF ফেরত, একসাথে
 * ═════════════════════════════════════════════════════════════════════════════
 */
object HrPolicyEngine {

    // ─────────────────────────────────────────────────────────────────────────
    // প্রভিডেন্ট ফান্ড
    // ─────────────────────────────────────────────────────────────────────────

    data class PfSnapshot(
        val monthlyEmployee: Double,
        val monthlyCompany: Double,
        val monthsServed: Int,
        val accumulated: Double,
    ) {
        val monthlyTotal: Double get() = moneyRound(monthlyEmployee + monthlyCompany)
    }

    /**
     * PF-এর হিসাব।
     *
     * **আনুমানিক, আর সেটা লুকানো হয় না।** প্রতি মাসের আসল কর্তন আলাদা করে
     * সংরক্ষিত হয় না (বেতন প্রতি মাসে বদলাতে পারে), তাই এটা **আজকের বেসিক ×
     * চাকরির মাস** ধরে হিসাব করে। পর্দাতেও "আনুমানিক" লেখা থাকে — নইলে কেউ
     * এটাকে নিরীক্ষিত হিসাব ভেবে বসত।
     *
     * সঠিক হিসাব চাইলে প্রতি মাসের payroll সারিতে PF লিখে রাখতে হবে, ঠিক
     * যেভাবে বেতনের গঠন snapshot করা হয় — সেটা আলাদা কাজ।
     */
    fun pfOf(
        employee: EmployeeProfile,
        asOf: LocalDate = LocalDate.now(),
    ): PfSnapshot {
        if (employee.pfPercent <= 0.0 || employee.basePayMonthly <= 0.0) {
            return PfSnapshot(0.0, 0.0, 0, 0.0)
        }
        val share = moneyRound(employee.basePayMonthly * employee.pfPercent / 100.0)
        val start = employee.joiningDate
        val end = employee.exitDate?.takeIf { it.isBefore(asOf) } ?: asOf
        val months = if (start == null) 0 else ChronoUnit.MONTHS.between(start, end).toInt().coerceAtLeast(0)
        return PfSnapshot(
            monthlyEmployee = share,
            // কোম্পানির অংশ সমান — বাংলাদেশে প্রচলিত, আর আলাদা ঘর রাখলে
            // দুটো সংখ্যা একই থাকত অথচ দুবার লিখতে হতো
            monthlyCompany = share,
            monthsServed = months,
            accumulated = moneyRound(share * 2 * months),
        )
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ছুটির balance
    // ─────────────────────────────────────────────────────────────────────────

    data class LeaveBalance(
        val entitled: Int,
        val taken: Int,
        val pending: Int,
    ) {
        /** বাকি = প্রাপ্য − নেওয়া। মুলতুবি আবেদন এখান থেকে বাদ যায় না — অনুমোদনের আগে সেটা এখনো ছুটি নয়। */
        val remaining: Int get() = (entitled - taken).coerceAtLeast(0)
        val overTaken: Int get() = (taken - entitled).coerceAtLeast(0)
    }

    /**
     * এই বছরের ছুটির হিসাব।
     *
     * **শুধু কর্মদিবস গোনা হয়** — শুক্রবার বা ঘোষিত ছুটি মাঝে পড়লে সেগুলো
     * ছুটি হিসেবে ধরা হয় না। নইলে ঈদের সময় তিন দিনের ছুটি চাইলে দশ দিন
     * কেটে যেত, যা কর্মীর প্রতি অন্যায়।
     *
     * যোগদানের বছরে **আনুপাতিক** প্রাপ্যতা: জুলাইয়ে যোগ দিলে পুরো বছরের
     * ছুটি প্রাপ্য নয়, অর্ধেক।
     */
    fun leaveBalanceOf(
        employee: EmployeeProfile,
        year: Int = LocalDate.now().year,
        leaves: List<LeaveRequest> = MockRepository.leaveRequests.value,
        workingDays: List<String> = MockRepository.companySettings().workingDays,
        holidays: List<AttendanceEngine.Holiday> =
            AttendanceEngine.parseHolidays(MockRepository.companySettings().holidaysRaw),
    ): LeaveBalance {
        val yearStart = LocalDate.of(year, 1, 1)
        val yearEnd = LocalDate.of(year, 12, 31)

        val entitled = if (employee.annualLeaveDays <= 0) 0 else {
            val join = employee.joiningDate
            if (join == null || join.year < year) employee.annualLeaveDays
            else if (join.year > year) 0
            else {
                // যোগদানের বছর — বাকি মাসের অনুপাতে
                val monthsLeft = 12 - join.monthValue + 1
                (employee.annualLeaveDays * monthsLeft / 12).coerceAtLeast(0)
            }
        }

        val mine = leaves.filter {
            it.employeeId == employee.id &&
                !it.fromDate.isAfter(yearEnd) && !it.toDate.isBefore(yearStart)
        }
        fun days(r: LeaveRequest): Int =
            AttendanceEngine.workingDaysBetween(
                maxOf(r.fromDate, yearStart), minOf(r.toDate, yearEnd), workingDays, holidays,
            )

        return LeaveBalance(
            entitled = entitled,
            taken = mine.filter { it.status == LeaveStatus.APPROVED }.sumOf { days(it) },
            pending = mine.filter { it.status == LeaveStatus.PENDING }.sumOf { days(it) },
        )
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Exit process
    // ─────────────────────────────────────────────────────────────────────────

    data class ExitSettlement(
        val employeeId: String,
        val employeeName: String,
        val lastDay: LocalDate,
        val finalSalary: Double,
        val pfReturn: Double,
        val advanceOutstanding: Double,
        val unusedLeaveDays: Int,
        val blockers: List<String>,
    ) {
        /** কোম্পানি যা দেবে − কর্মী যা ফেরত দেবে। ঋণাত্মক হলে কর্মীর কাছে পাওনা থাকে। */
        val netPayable: Double get() = moneyRound(finalSalary + pfReturn - advanceOutstanding)
        val canClose: Boolean get() = blockers.isEmpty()
    }

    /**
     * বিদায়ের হিসাব — এক জায়গায়।
     *
     * `blockers` কেন দরকার: কেউ চলে যাওয়ার পর তার দায়িত্বে dealer বা route
     * পড়ে থাকলে সেগুলো **মালিকহীন হয়ে যায়** — cascade উপরের কাউকে ধরিয়ে
     * দেবে ঠিকই, কিন্তু কেউ জানবেই না। তাই বিদায় সম্পন্ন করার আগে সেগুলো
     * হস্তান্তর করতে বলা হয়। অগ্রিম বকেয়া থাকলেও একই — টাকা উদ্ধারের শেষ
     * সুযোগ এটাই।
     */
    fun exitSettlement(
        employee: EmployeeProfile,
        lastDay: LocalDate,
        employees: List<EmployeeProfile> = MockRepository.employeeProfiles.value.filter { !it.isDeleted },
        dealers: List<Dealer> = MockRepository.dealers.value,
        routes: List<SalesRoute> = MockRepository.salesRoutes.value,
        advances: List<EmployeeAdvance> = MockRepository.employeeAdvances.value,
    ): ExitSettlement {
        val blockers = mutableListOf<String>()

        val myDealers = dealers.count { !it.isDeleted && it.assignedEmployeeId == employee.id }
        if (myDealers > 0) blockers += "$myDealers জন dealer এখনো তার দায়িত্বে — হস্তান্তর করুন"

        val myRoutes = routes.count { it.assignedToEmployeeId == employee.id && it.isActive }
        if (myRoutes > 0) blockers += "$myRoutes টি route এখনো তার নামে — অন্য কাউকে দিন"

        val reports = CascadeEngine.directReportsOf(employee, lastDay, employees)
        if (reports.isNotEmpty()) blockers += "${reports.size} জন তার অধীনে — নতুন ম্যানেজার বসান"

        val adv = advances.filter { it.employeeId == employee.id && it.status == "APPROVED" }
        val outstanding = moneyRound(adv.sumOf { it.outstanding })

        val periodStart = lastDay.withDayOfMonth(1)
        val breakdown = SalaryEngine.compute(employee, periodStart, lastDay, employees = employees)
        val pf = pfOf(employee, lastDay)
        val leave = leaveBalanceOf(employee, lastDay.year)

        return ExitSettlement(
            employeeId = employee.id,
            employeeName = employee.fullName,
            lastDay = lastDay,
            finalSalary = breakdown.payable,
            pfReturn = pf.accumulated,
            advanceOutstanding = outstanding,
            unusedLeaveDays = leave.remaining,
            blockers = blockers,
        )
    }

    /**
     * বিদায় সম্পন্ন করা।
     *
     * `exitDate` **অবশ্যই বসাতে হয়** — v113-380-এ field-টা যোগ করা হয়েছিল
     * ঠিক এই জন্য, কিন্তু কোথাও বসানো হতো না। ফলে কেউ চলে গেলেও
     * `CascadeEngine.isActiveOn()` তাকে সক্রিয় ধরত, আর সে ফাঁকা পদের দায়িত্ব
     * পেয়ে যেত। **এটাই সবচেয়ে গুরুতর ফাঁক ছিল, কারণ হিসাব ভুল দেখাত।**
     */
    fun completeExit(
        employeeId: String,
        lastDay: LocalDate,
        reason: String,
        onResult: (String) -> Unit = {},
    ) {
        if (MockRepository.currentUser.role != UserRole.CHAIRMAN) {
            onResult("বিদায় সম্পন্ন কেবল Chairman করতে পারেন।")
            return
        }
        if (reason.isBlank()) {
            onResult("কারণ লিখুন — এটা চিরকাল রেকর্ডে থাকবে।")
            return
        }
        MockRepository.completeEmployeeExit(employeeId, lastDay, reason.trim(), onResult)
    }
}
