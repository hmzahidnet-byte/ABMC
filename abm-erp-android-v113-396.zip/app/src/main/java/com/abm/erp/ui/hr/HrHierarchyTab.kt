package com.abm.erp.ui.hr

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.CascadeEngine
import com.abm.erp.data.EmployeeProfile
import com.abm.erp.data.MockRepository
import com.abm.erp.data.UserRole
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.DarazOrangeDark
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import java.time.LocalDate

/**
 * v113-380 — Employee Hierarchy.
 *
 * এটা CascadeEngine-এর মুখ। নিজে কোনো নিয়ম জানে না — "কে কার উপরে", "পদ ফাঁকা
 * হলে কে" প্রতিটা প্রশ্ন engine-কেই জিজ্ঞেস করে। তাই এখানে যা দেখা যায় আর
 * টার্গেট/assign/approval যা মানে, দুটো কখনো আলাদা হতে পারে না।
 *
 * ডিজাইন r3-এর "১ · Hierarchy" স্ক্রিন: দুই wing আলাদা রঙে, Wing 1 জাতীয়
 * (পাশাপাশি), Wing 2 এলাকা ধরে ধাপে ধাপে। ফাঁকা পদ লাল ড্যাশ-বৃত্ত, নিচে কমলা
 * লেবেলে কে দায়িত্ব চালাচ্ছেন।
 */

private val WING1_TINT = Color(0xFFF3EEFF)
private val WING1_INK = Color(0xFF9C6EFF)
private val WING2_TINT = Color(0xFFE6F7F7)
private val WING2_INK = Color(0xFF0E9F9F)

@Composable
fun HrHierarchyTab(onOpenEmployee: (String) -> Unit = {}) {
    val employees by MockRepository.employeeProfiles.collectAsState()
    val today = remember { LocalDate.now() }
    val live = remember(employees) { employees.filter { !it.isDeleted } }

    // engine-ই সব হিসাব করে; এই স্ক্রিন শুধু ফল সাজায়
    val vacancies = remember(live, today) { CascadeEngine.vacanciesOn(today, live) }
    val office = remember(live, today) {
        CascadeEngine.OFFICE_ROLES.reversed().map { role ->
            role to live.firstOrNull { it.role == role && CascadeEngine.isActiveOn(it, today) }
        }
    }

    Column(
        Modifier.fillMaxSize().background(com.abm.erp.theme.DashBg)
            .verticalScroll(rememberScrollState()).padding(12.dp),
    ) {
        SummaryStrip(live, vacancies, today)
        Spacer(Modifier.height(10.dp))
        Wing1Card(office)
        Spacer(Modifier.height(10.dp))
        Wing2Card(live, today, onOpenEmployee)
        if (vacancies.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            VacancyCard(vacancies)
            Spacer(Modifier.height(10.dp))
            TenureCard(vacancies.first(), live)
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "DSM = সংযোগস্থল — field-এর সবার উপরে, office-এর সবার নিচে। " +
                "পদ ফাঁকা হলে দায়িত্ব আপনাআপনি উপরের স্তরে যায়, কেউ হাতে বসায় না।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary, lineHeight = 15.sp,
        )
        Spacer(Modifier.height(24.dp))
    }
}

/* ── উপরের সারাংশ ─────────────────────────────────────────────────────── */

@Composable
private fun SummaryStrip(
    live: List<EmployeeProfile>,
    vacancies: List<CascadeEngine.Vacancy>,
    today: LocalDate,
) {
    val active = live.count { CascadeEngine.isActiveOn(it, today) }
    val w1 = live.count { CascadeEngine.wingOf(it.role) == CascadeEngine.Wing.OFFICE && CascadeEngine.isActiveOn(it, today) }
    val w2 = active - w1
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        StatCell("সক্রিয়", "$active", Color(0xFF2563EB), Color(0xFFEEF4FF), Modifier.weight(1f))
        StatCell("Wing 1", "$w1", WING1_INK, WING1_TINT, Modifier.weight(1f))
        StatCell("Wing 2", "$w2", WING2_INK, WING2_TINT, Modifier.weight(1f))
        StatCell("ফাঁকা পদ", "${vacancies.size}", DangerRed, Color(0xFFFDECEA), Modifier.weight(1f))
    }
}

@Composable
private fun StatCell(label: String, value: String, ink: Color, bg: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(11.dp)).background(bg).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(label, fontSize = 8.5.sp, color = TextSecondary, maxLines = 1)
        Text(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = ink)
    }
}

/* ── Wing 1: জাতীয়, পাশাপাশি ──────────────────────────────────────────── */

@Composable
private fun Wing1Card(office: List<Pair<UserRole, EmployeeProfile?>>) {
    SectionCard(borderTint = WING1_INK.copy(alpha = 0.35f)) {
        SectionHeader("Wing 1 — Office", "জাতীয়", WING1_INK, WING1_TINT)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            office.forEach { (role, emp) ->
                Column(Modifier.width(58.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.size(36.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (emp == null) Color.White else WING1_TINT)
                            .border(
                                if (emp == null) 1.5.dp else 1.dp,
                                if (emp == null) DangerRed else WING1_INK.copy(alpha = 0.30f),
                                RoundedCornerShape(18.dp),
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            if (emp == null) Icons.Filled.Warning else Icons.Filled.Person,
                            contentDescription = role.name,
                            tint = if (emp == null) DangerRed else WING1_INK,
                            modifier = Modifier.size(17.dp),
                        )
                    }
                    Spacer(Modifier.height(3.dp))
                    Text(role.name, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
                    Text(
                        emp?.fullName?.take(8) ?: "ফাঁকা",
                        fontSize = 9.sp, color = if (emp == null) DangerRed else TextSecondary, maxLines = 1,
                    )
                }
            }
        }
    }
}

/* ── Wing 2: এলাকা ধরে, ধাপে ধাপে ─────────────────────────────────────── */

@Composable
private fun Wing2Card(live: List<EmployeeProfile>, today: LocalDate, onOpen: (String) -> Unit) {
    // পদক্রমে উপর থেকে নিচে সাজানো — DSM আগে, SR শেষে। একই স্তরে এলাকা ধরে।
    val ordered = remember(live, today) {
        live.filter { CascadeEngine.wingOf(it.role) == CascadeEngine.Wing.FIELD && CascadeEngine.isActiveOn(it, today) }
            .sortedWith(
                compareByDescending<EmployeeProfile> { CascadeEngine.rankOf(it.role) }
                    .thenBy { CascadeEngine.geoKeyOf(it) ?: "" },
            )
    }
    SectionCard(borderTint = WING2_INK.copy(alpha = 0.35f)) {
        SectionHeader("Wing 2 — Field", "এলাকা ভিত্তিক", WING2_INK, WING2_TINT)
        Spacer(Modifier.height(6.dp))
        if (ordered.isEmpty()) {
            Text("কোনো সক্রিয় field employee নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
        ordered.forEach { emp ->
            // ইন্ডেন্ট পদক্রম অনুযায়ী: DSM ০, RSM ১, ASM ২, TSM ৩, SR ৪
            val depth = (CascadeEngine.rankOf(UserRole.DSM) - CascadeEngine.rankOf(emp.role)).coerceAtLeast(0)
            EmployeeRow(emp, depth, onOpen)
        }
    }
}

@Composable
private fun EmployeeRow(emp: EmployeeProfile, depth: Int, onOpen: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(start = (depth * 12).dp, top = 3.dp, bottom = 3.dp)
            .clip(RoundedCornerShape(9.dp)).clickable { onOpen(emp.id) }.padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(32.dp).clip(RoundedCornerShape(16.dp)).background(WING2_TINT)
                .border(1.dp, WING2_INK.copy(alpha = 0.30f), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center,
        ) { Icon(Icons.Filled.Person, contentDescription = null, tint = WING2_INK, modifier = Modifier.size(16.dp)) }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(emp.role.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(
                    " · ${CascadeEngine.geoKeyOf(emp) ?: "এলাকা বসানো হয়নি"}",
                    fontSize = 10.sp, color = TextSecondary, maxLines = 1,
                )
            }
            Text(emp.fullName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
        }
        Icon(Icons.Filled.Info, contentDescription = "দেখুন", tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp))
    }
}

/* ── ফাঁকা পদ ও কে চালাচ্ছেন ──────────────────────────────────────────── */

@Composable
private fun VacancyCard(vacancies: List<CascadeEngine.Vacancy>) {
    SectionCard(borderTint = DangerRed.copy(alpha = 0.35f)) {
        SectionHeader("ফাঁকা পদ", "${vacancies.size}টি", DangerRed, Color(0xFFFDECEA))
        Spacer(Modifier.height(4.dp))
        vacancies.forEach { v ->
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(30.dp).clip(RoundedCornerShape(15.dp)).background(Color.White)
                        .border(1.5.dp, DangerRed, RoundedCornerShape(15.dp)),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Warning, contentDescription = null, tint = DangerRed, modifier = Modifier.size(15.dp)) }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "${v.role.name} · ${v.geoKey}",
                        fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary,
                    )
                    // engine-এর নিজের ভাষায় — স্ক্রিন আলাদা করে ব্যাখ্যা বানায় না,
                    // তাই audit log আর পর্দা একই কথা বলে
                    Text(
                        "দায়িত্বে: " + (v.coveredBy.employee?.let { "${it.fullName} (${it.role.name})" } ?: "কেউ পাওয়া যায়নি"),
                        fontSize = 9.5.sp, color = DarazOrangeDark, maxLines = 1,
                    )
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "কোনো কাজ মালিকহীন থাকে না — কাউকে না পাওয়া গেলে দায়িত্ব Chairman-এর।",
            fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
        )
    }
}

/* ── ছোট সহায়ক ─────────────────────────────────────────────────────────── */

@Composable
private fun SectionCard(borderTint: Color, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color.White)
            .border(1.dp, borderTint, RoundedCornerShape(13.dp)).padding(11.dp),
        content = content,
    )
}

@Composable
private fun SectionHeader(title: String, badge: String, ink: Color, tint: Color) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.weight(1f))
        Box(
            Modifier.clip(RoundedCornerShape(8.dp)).background(tint).padding(horizontal = 7.dp, vertical = 2.dp),
        ) { Text(badge, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = ink) }
    }
}


/**
 * v113-395 — দায়িত্বের ইতিহাস।
 *
 * `CascadeEngine.tenureTimeline()` v113-380-এ লেখা হয়েছিল, **কিন্তু কোনো
 * স্ক্রিন সেটা ডাকত না** — অর্থাৎ "গত মাসে এই পদের দায়িত্বে কে ছিল" প্রশ্নের
 * উত্তর কোডে ছিল, কিন্তু কেউ দেখতে পেত না।
 *
 * এটাই সেই প্রশ্নের উত্তরদাতা যা পুরনো মাসের বেতন বা কমিশন নিয়ে বিতর্ক
 * উঠলে লাগে: "ফেব্রুয়ারির ওই invoice কার অধীনে ছিল?" — এখানে দেখা যাবে,
 * তারিখ ধরে, কে কোন ভিত্তিতে (নিজের পদ / ভ্যাকেন্সি পূরণ / override)।
 *
 * প্রথম ফাঁকা পদটার ইতিহাস দেখানো হয় — কারণ ফাঁকা পদ নিয়েই প্রশ্ন ওঠে
 * বেশি, আর সবগুলোর টাইমলাইন একসাথে দেখালে পাতা ভরে যেত।
 */
@Composable
private fun TenureCard(vacancy: CascadeEngine.Vacancy, live: List<EmployeeProfile>) {
    val today = remember { LocalDate.now() }
    // গত ছয় মাস — এর বেশি পিছিয়ে গেলে তালিকা লম্বা হয়, আর বেতন নিয়ে
    // প্রশ্ন সাধারণত সাম্প্রতিক মাসগুলোর
    val timeline = remember(vacancy, live) {
        CascadeEngine.tenureTimeline(
            vacancy.role, vacancy.geoKey, today.minusMonths(6), today, live,
        )
    }
    SectionCard(borderTint = Color(0xFF2563EB).copy(alpha = 0.30f)) {
        SectionHeader(
            "দায়িত্বের ইতিহাস",
            "${vacancy.role.name} · ${vacancy.geoKey}",
            Color(0xFF2563EB), Color(0xFFEEF4FF),
        )
        Spacer(Modifier.height(4.dp))
        if (timeline.isEmpty()) {
            Text("গত ছয় মাসে কোনো পরিবর্তন নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
        timeline.forEach { t ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
                Column(Modifier.width(96.dp)) {
                    Text("${t.from}", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text(
                        t.to?.toString() ?: "চলমান",
                        fontSize = 9.sp,
                        color = if (t.to == null) SuccessGreen else TextSecondary,
                    )
                }
                Box(
                    Modifier.width(8.dp).height(8.dp).clip(RoundedCornerShape(4.dp))
                        .background(
                            when (t.holder.basis) {
                                CascadeEngine.HolderBasis.OWN_POST -> SuccessGreen
                                CascadeEngine.HolderBasis.VACANCY_COVER -> DarazOrangeDark
                                CascadeEngine.HolderBasis.OVERRIDE -> Color(0xFF9C6EFF)
                                CascadeEngine.HolderBasis.CHAIRMAN_FALLBACK -> DangerRed
                            },
                        ),
                )
                Spacer(Modifier.width(8.dp))
                // engine-এর নিজের ভাষায় — স্ক্রিন আলাদা ব্যাখ্যা বানায় না,
                // তাই পর্দা আর audit log সবসময় এক কথা বলে
                Text(
                    t.holder.auditLabel,
                    Modifier.weight(1f), fontSize = 10.5.sp, color = TextPrimary, lineHeight = 14.sp,
                )
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(
            "পুরনো মাসের বেতন বা কমিশন নিয়ে প্রশ্ন উঠলে এখানেই উত্তর — কে কোন সময়টায় " +
                "দায়িত্বে ছিল, আর কোন ভিত্তিতে।",
            fontSize = 9.sp, color = TextSecondary, lineHeight = 13.sp,
        )
    }
}
