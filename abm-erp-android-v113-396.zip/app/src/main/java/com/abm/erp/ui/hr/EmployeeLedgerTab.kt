package com.abm.erp.ui.hr

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.EmployeeLedger
import com.abm.erp.data.EmployeeProfile
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import java.time.LocalDate

/**
 * v113-393 — Employee Ledger tab।
 *
 * একজন কর্মীর সাথে কোম্পানির সব টাকার লেনদেন এক তালিকায়, **সাম্প্রতিক আগে** —
 * কেউ ledger খুললে সাধারণত "শেষ কী হলো" জানতে চায়, শুরু থেকে পড়তে নয়।
 *
 * ± মাস বদলানো যায়, কারণ বেতন নিয়ে প্রশ্ন সাধারণত **গত মাসের** হয়।
 */
@Composable
fun EmployeeLedgerTab(employee: EmployeeProfile) {
    var monthOffset by remember(employee.id) { mutableStateOf(0L) }
    val base = remember(monthOffset) { LocalDate.now().plusMonths(monthOffset) }
    val from = remember(base) { base.withDayOfMonth(1) }
    val to = remember(base) { base.withDayOfMonth(base.lengthOfMonth()) }

    val advances by MockRepository.employeeAdvances.collectAsState()
    val invoices by MockRepository.salesInvoices.collectAsState()
    val returns by MockRepository.salesReturns.collectAsState()
    val employees by MockRepository.employeeProfiles.collectAsState()

    val summary = remember(employee.id, from, advances, invoices, returns, employees) {
        EmployeeLedger.of(
            employee = employee, from = from, to = to,
            advances = advances, invoices = invoices, returns = returns,
            employees = employees.filter { !it.isDeleted },
        )
    }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp)) {
        // ── মাস বাছাই ──
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Nudge("‹") { monthOffset -= 1 }
            Text(
                "${from.month.name.take(3)} ${from.year}",
                Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            // ভবিষ্যতের মাসে যাওয়া আটকানো — ওখানে দেখানোর কিছু নেই, আর
            // খালি পাতা দেখে কেউ ভাববে হিসাব হারিয়ে গেছে
            Nudge("›", enabled = monthOffset < 0) { if (monthOffset < 0) monthOffset += 1 }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Stat("আয়", summary.earned, SuccessGreen, Color(0xFFE8F7F0), Modifier.weight(1f))
            Stat("কর্তন", summary.deducted, DangerRed, Color(0xFFFDECEA), Modifier.weight(1f))
            Stat("বকেয়া অগ্রিম", summary.advanceOutstanding, WarningAmber, Color(0xFFFFF7E6), Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))

        if (summary.rows.isEmpty()) {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Color.White)
                    .border(1.dp, HairlineBorder, RoundedCornerShape(13.dp)).padding(16.dp),
                contentAlignment = Alignment.Center,
            ) { Text("এই মাসে কোনো লেনদেন নেই।", fontSize = 11.sp, color = TextSecondary) }
        }

        summary.rows.forEach { r ->
            val ink = when (r.kind) {
                EmployeeLedger.Kind.EARNING -> SuccessGreen
                EmployeeLedger.Kind.DEDUCTION -> DangerRed
                EmployeeLedger.Kind.ADVANCE_TAKEN -> WarningAmber
                EmployeeLedger.Kind.ADVANCE_REPAID -> Color(0xFF2563EB)
            }
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(11.dp))
                    .background(Color.White).border(1.dp, HairlineBorder, RoundedCornerShape(11.dp))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(8.dp).clip(RoundedCornerShape(4.dp)).background(ink))
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(r.label, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = TextPrimary, maxLines = 1)
                    Text(r.detail, fontSize = 9.5.sp, color = TextSecondary, maxLines = 2, lineHeight = 13.sp)
                }
                // শূন্য অঙ্কের সারি = কারণ-বর্ণনা (কোন return কেন), তাই
                // সংখ্যা দেখানো হয় না — "৳0" লিখলে বিভ্রান্তিকর হতো
                if (kotlin.math.abs(r.amount) > 0.001) {
                    Text(
                        (if (r.amount > 0) "+৳" else "−৳") + num(kotlin.math.abs(r.amount)),
                        fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ink,
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                .background(Color(0xFFFFF3EC)).border(1.5.dp, DarazOrange, RoundedCornerShape(12.dp))
                .padding(11.dp),
        ) {
            Text("এই মাসের নিট", Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text("৳${num(summary.net)}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = DarazOrange)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "কমিশন গোনা হয় আদায়ের উপর — বাকিতে যাওয়া মালের কমিশন টাকা ওঠার পরেই যোগ হয়। " +
                "অগ্রিমের কিস্তি বেতন থেকে কাটে, তাই সেটাও এখানে।",
            fontSize = 9.5.sp, color = TextSecondary, lineHeight = 14.sp,
        )
        Spacer(Modifier.height(20.dp))
    }
}

/* ── ছোট সহায়ক ─────────────────────────────────────────────────────────── */

@Composable
private fun Nudge(glyph: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.size(30.dp).clip(RoundedCornerShape(15.dp))
            .background(if (enabled) Color.White else Color(0xFFF1F3F6))
            .border(1.dp, HairlineBorder, RoundedCornerShape(15.dp))
            .then(if (enabled) Modifier.clickable { onClick() } else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            glyph, fontSize = 16.sp, fontWeight = FontWeight.Bold,
            color = if (enabled) TextPrimary else Color(0xFFCBD5E1),
        )
    }
}

@Composable
private fun Stat(label: String, value: Double, ink: Color, bg: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(11.dp)).background(bg).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(label, fontSize = 8.5.sp, color = TextSecondary, maxLines = 1)
        Text("৳${num(value)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = ink, maxLines = 1)
    }
}

private fun num(v: Double): String =
    if (kotlin.math.abs(v % 1.0) < 0.001) "%,.0f".format(v) else "%,.2f".format(v)
