package com.abm.erp.data

import java.time.LocalDate

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * v113-393 — EMPLOYEE LEDGER
 *
 * *"আর employee ledger ও list এ রাখিও"* — একজন কর্মীর সাথে কোম্পানির সব
 * টাকার লেনদেন **এক তালিকায়, তারিখ ধরে**।
 *
 * ─── নতুন কোনো টেবিল বানানো হয়নি — ইচ্ছাকৃত ────────────────────────────────
 * প্রতিটা সারি ইতিমধ্যে কোথাও না কোথাও আছে: অগ্রিম `EmployeeAdvance`-এ,
 * কমিশন invoice+collection থেকে হিসাব হয়, return সমন্বয় `SalesReturn`-এ।
 * আলাদা ledger টেবিল বানালে **একই সত্য দুই জায়গায়** থাকত, আর একদিন দুটো
 * আলাদা হয়ে যেত — DMS-এ ঠিক এই ভুলেই dealer দুই উৎস থেকে পড়া হচ্ছিল
 * (v113-379)। তাই এই ফাইল কিছু **সংরক্ষণ করে না**, শুধু বিদ্যমান রেকর্ড
 * থেকে তালিকাটা **তৈরি করে দেখায়**।
 * ═════════════════════════════════════════════════════════════════════════════
 */
object EmployeeLedger {

    enum class Kind { EARNING, DEDUCTION, ADVANCE_TAKEN, ADVANCE_REPAID }

    data class Row(
        val date: LocalDate,
        val kind: Kind,
        val label: String,
        val detail: String,
        /** ধনাত্মক = কর্মীর পাওনা বাড়ল, ঋণাত্মক = কমল */
        val amount: Double,
    ) {
        val isCredit: Boolean get() = amount >= 0
    }

    data class Summary(
        val rows: List<Row>,
        val earned: Double,
        val deducted: Double,
        val advanceOutstanding: Double,
    ) {
        val net: Double get() = moneyRound(earned - deducted)
    }

    /**
     * একজনের পূর্ণ লেনদেন, একটা সময়সীমায়।
     *
     * ক্রম **সাম্প্রতিক আগে** — কেউ ledger খুললে সাধারণত "শেষ কী হলো" জানতে
     * চায়, শুরু থেকে পড়তে নয়।
     */
    fun of(
        employee: EmployeeProfile,
        from: LocalDate,
        to: LocalDate,
        advances: List<EmployeeAdvance> = MockRepository.employeeAdvances.value,
        invoices: List<SalesInvoice> = MockRepository.salesInvoices.value,
        returns: List<SalesReturn> = MockRepository.salesReturns.value,
        employees: List<EmployeeProfile> = MockRepository.employeeProfiles.value.filter { !it.isDeleted },
    ): Summary {
        val rows = mutableListOf<Row>()

        // ── অগ্রিম নেওয়া ও কিস্তি ──
        advances.filter { it.employeeId == employee.id }.forEach { a ->
            val taken = a.approvedAt?.toLocalDate() ?: a.requestedAt.toLocalDate()
            if (a.status == "APPROVED" || a.status == "CLOSED") {
                if (!taken.isBefore(from) && !taken.isAfter(to)) {
                    rows += Row(taken, Kind.ADVANCE_TAKEN, "অগ্রিম নেওয়া", a.reason, a.amount)
                }
                // কিস্তির প্রতিটা কিস্তির আলাদা তারিখ রাখা হয় না (repaid একটাই
                // যোগফল), তাই মোট আদায়টুকু এক সারিতে — ভুয়া তারিখ বানিয়ে
                // কয়েকটা সারি দেখানোর চেয়ে সৎ।
                if (a.repaid > 0) {
                    rows += Row(to, Kind.ADVANCE_REPAID, "অগ্রিম শোধ", "মোট আদায়", -a.repaid)
                }
            }
        }

        // ── কমিশন (আদায়ের উপর) ──
        val breakdown = SalaryEngine.compute(
            employee = employee, periodStart = from, periodEnd = to,
            employees = employees, invoices = invoices, returns = returns,
        )
        if (breakdown.basePay > 0) {
            rows += Row(to, Kind.EARNING, "বেসিক", "মাসিক", breakdown.basePay)
        }
        if (breakdown.ownCommission > 0) {
            rows += Row(
                to, Kind.EARNING, "কমিশন — নিজের বিক্রি",
                "আদায় ৳${"%,.0f".format(breakdown.ownSales)} × ${breakdown.ownCommissionPct}%",
                breakdown.ownCommission,
            )
        }
        if (breakdown.overrideCommission > 0) {
            rows += Row(
                to, Kind.EARNING, "কমিশন — অধীনস্থ",
                "আদায় ৳${"%,.0f".format(breakdown.teamSales)} × ${breakdown.overrideCommissionPct}%",
                breakdown.overrideCommission,
            )
        }
        if (breakdown.taDa > 0) rows += Row(to, Kind.EARNING, "TA/DA", "মাসিক", breakdown.taDa)

        // ── Return সমন্বয়, কারণসহ ──
        breakdown.returnReasons.forEach { reason ->
            rows += Row(to, Kind.DEDUCTION, "Return সমন্বয়", reason, 0.0)
        }
        if (breakdown.returnDeduction > 0) {
            rows += Row(to, Kind.DEDUCTION, "Return কর্তন", "মোট", -breakdown.returnDeduction)
        }

        val sorted = rows.sortedByDescending { it.date }
        return Summary(
            rows = sorted,
            earned = moneyRound(sorted.filter { it.amount > 0 && it.kind == Kind.EARNING }.sumOf { it.amount }),
            deducted = moneyRound(-sorted.filter { it.amount < 0 && it.kind == Kind.DEDUCTION }.sumOf { it.amount }),
            advanceOutstanding = moneyRound(
                advances.filter { it.employeeId == employee.id && it.status == "APPROVED" }.sumOf { it.outstanding },
            ),
        )
    }
}
