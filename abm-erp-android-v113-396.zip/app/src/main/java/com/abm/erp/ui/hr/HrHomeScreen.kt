package com.abm.erp.ui.hr

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abm.erp.core.ModuleDrawerItem
import com.abm.erp.core.ModuleDrawerScaffold
import com.abm.erp.data.MockRepository
import com.abm.erp.data.UserRole
import com.abm.erp.theme.TextSecondary

/**
 * HR — Employee Management System (sales-wing office HR). Mother module #3.
 *
 * Built to the person's HR draft. Everything here is **hosting** — the HR feature set
 * already exists as working code in `PayrollScreen`'s tabs, `EmployeeSetupScreen`,
 * `ComplaintBoxScreen`, and `VacancyTargetCenterScreen` (targets). No new schema, no
 * new repository function; this module gives them the one drawer-based home the draft
 * asks for, exactly the way DMS hosts the invoice/dealer tabs.
 *
 * `PayrollScreen(startTab = N)` is the hosting mechanism: with a non-null startTab it
 * renders its own compact `TaskHeader` + the one tab, never the full HRM dashboard —
 * that's the v113-71 TaskHeader behaviour, reused rather than re-implemented. Its
 * onBack returns the drawer selection to this module's own dashboard.
 *
 * The draft's card 9, "HR (Factory) Module", is deliberately a cross-reference, not a
 * copy: factory workforce lives inside FMS (ProductionScreen's Factory HRM tab), and
 * the person confirmed factory HR stays separate from office HR. Listing it here as a
 * drawer item would put one feature in two mother modules — against the one-home rule —
 * so this module simply doesn't list it, and FMS does.
 */
private val HR_COLOR_START = 0xFFDB2777
private val HR_COLOR_END = 0xFF9D174D

private val HR_ITEMS_BASE = listOf(
    ModuleDrawerItem("dashboard", "ড্যাশবোর্ড", Icons.Filled.Home, "সারসংক্ষেপ"),
    // — কর্মী ও কাঠামো —
    ModuleDrawerItem("employees", "কর্মী তালিকা", Icons.Filled.Groups, "সবার তালিকা · প্রোফাইল"),
    ModuleDrawerItem("hierarchy", "চেইন", Icons.Filled.AccountTree, "চেইন · ফাঁকা পদ · দায়িত্ব"),
    ModuleDrawerItem("add", "নতুন কর্মী", Icons.Filled.PersonAdd, "নিয়োগ · তথ্য · অনুমোদন"),
    ModuleDrawerItem("lifecycle", "পদোন্নতি · বদলি", Icons.Filled.Assignment, "স্কেল · এলাকা · পদ"),
    // — রোজকার —
    ModuleDrawerItem("attsummary", "হাজিরা", Icons.Filled.CalendarMonth, "মাসিক · ছুটি ঘোষণা"),
    ModuleDrawerItem("attendance", "দৈনিক হাজিরা", Icons.Filled.Schedule, "দিনভিত্তিক সাইন ইন"),
    ModuleDrawerItem("leave", "ছুটি", Icons.Filled.BeachAccess, "আবেদন · অনুমোদন"),
    ModuleDrawerItem("livemap", "লোকেশন", Icons.Filled.LocationOn, "৯–৫ · ২ ঘণ্টা পরপর"),
    ModuleDrawerItem("route", "রুট", Icons.Filled.Map, "মানচিত্র · outlet · ক্রম"),
    // — টাকা —
    ModuleDrawerItem("salary", "বেতন", Icons.Filled.Payments, "বেসিক · কমিশন · TA/DA · কর্তন"),
    ModuleDrawerItem("payroll", "পে-রোল", Icons.Filled.CreditCard, "মাসিক বেতন প্রক্রিয়া"),
    ModuleDrawerItem("advance", "অগ্রিম", Icons.Filled.AccountBalanceWallet, "ধার · কিস্তি · অনুমোদন"),
    // v113-394 — PF · ছুটির balance · চিঠি · নথি · বিদায়
    ModuleDrawerItem("policy", "নীতি ও নথি", Icons.Filled.Description, "PF · ছুটি · চিঠি · বিদায়"),
    // — লক্ষ্য ও মূল্যায়ন —
    ModuleDrawerItem("distribute", "টার্গেট বণ্টন", Icons.Filled.TrendingUp, "product ধরে · ১০০% বাধ্যতামূলক"),
    ModuleDrawerItem("target", "ভ্যাকেন্সি ও টার্গেট", Icons.Filled.TrackChanges, "পদ ফাঁকা · পুরনো টার্গেট"),
    ModuleDrawerItem("performance", "মূল্যায়ন", Icons.Filled.Insights, "অর্জন · র‍্যাঙ্কিং"),
    // — সিদ্ধান্ত ও রিপোর্ট —
    ModuleDrawerItem("hrapprove", "অনুমোদন", Icons.Filled.FactCheck, "ছুটি · অগ্রিম · নিয়োগ"),
    ModuleDrawerItem("complain", "অভিযোগ", Icons.Filled.MarkunreadMailbox, "সরাসরি চেয়ারম্যানকে"),
    ModuleDrawerItem("reports", "রিপোর্ট", Icons.Filled.InsertChart, "রিপোর্ট ও বিশ্লেষণ"),
)

// v113-167 — person's decision: every mother module gets one drawer item, always
// last, named "Chairman", visible ONLY to the Chairman role, hosting every
// Chairman-only-gated action for that module in one place instead of scattered
// across record rows. Actions with broader access (GM/MD/AGM too, like Invoice
// approve) are NOT moved here — they stay in their normal tab, same as Invoice.
private val HR_CHAIRMAN_ITEM = ModuleDrawerItem("chairman", "চেয়ারম্যান", Icons.Filled.Star, "নিয়োগ · অ্যাকাউন্ট · restore")

/**
 * v113-393 — Chairman-এর নীতি-নির্ধারণী নিয়ন্ত্রণ, পুরনো প্রশাসনিক panel-এর
 * পাশাপাশি। দুটো আলাদা কাজ, তাই আলাদা item: পুরনোটা নিয়োগ/অ্যাকাউন্ট/restore,
 * নতুনটা জাতীয় টার্গেট · ছুটি ঘোষণা · কমিশনের হার · লগইন ও PIN।
 */
private val HR_CHAIRMAN_CONTROL = ModuleDrawerItem("chctrl", "নিয়ন্ত্রণ", Icons.Filled.Tune, "টার্গেট · ছুটি · হার · লগইন")

@Composable
fun HrHomeScreen(
    startKey: String? = null,
    onBackToHome: () -> Unit = {},
    onNavigate: (String) -> Unit = {},
) {
    var selected by remember { mutableStateOf(startKey ?: "dashboard") }
    val isChairman = MockRepository.currentUser.role == UserRole.CHAIRMAN
    val items = if (isChairman) HR_ITEMS_BASE + HR_CHAIRMAN_CONTROL + HR_CHAIRMAN_ITEM else HR_ITEMS_BASE

    ModuleDrawerScaffold(
        moduleName = "HR",
        moduleSubtitle = "Employee Management System",
        colorStart = HR_COLOR_START,
        colorEnd = HR_COLOR_END,
        moduleIcon = Icons.Filled.Groups,
        items = items,
        selectedKey = selected,
        onSelect = { selected = it },
        onBackToHome = onBackToHome,
    ) { key ->
        // PayrollScreen's own tab indices, verified against its `when (tab)` block:
        // 0 attend · 1 payroll · 2 leave · 3 lifecycle · 4 directory · 5 empmgmt.
        val backToDash: () -> Unit = { selected = "dashboard" }
        when (key) {
            "dashboard" -> HrDashboardHost()
            // v113-85 — same approved browse pattern, employee-shaped (no ledger/graph:
            // employees aren't money-bearing parties here, so those would be empty).
            "employees" -> {
                val profiles = com.abm.erp.core.rememberVisibleEmployeeProfiles()
                com.abm.erp.core.ModuleBrowseList(
                    config = com.abm.erp.core.rememberEmployeeBrowseConfig(
                        departments = remember(profiles) { profiles.map { it.department }.filter { it.isNotBlank() }.distinct().sorted() },
                    ),
                    records = profiles,
                    onBack = backToDash,
                    onNavigate = onNavigate,
                )
            }
            "attendance" -> com.abm.erp.ui.hrm.PayrollScreen(startTab = 0, onBack = backToDash)
            "payroll" -> com.abm.erp.ui.hrm.PayrollScreen(startTab = 1, onBack = backToDash)
            "leave" -> com.abm.erp.ui.hrm.PayrollScreen(startTab = 2, onBack = backToDash)
            "lifecycle" -> com.abm.erp.ui.hrm.PayrollScreen(startTab = 3, onBack = backToDash)
            // v113-219 — this used to be a whole PayrollScreen tab
            // (startTab = 5, "Employee Management"'s "List" sub-tab).
            // That tab's own real functionality moved to Employee List's
            // "Manage" extraTab; this route is now just the "+ New
            // Employee (Draft)" form specifically — the other half of what
            // that old tab did, and the thing Employee List's own "+"
            // button (addRoute = "hr_module?key=add") actually needs.
            "add" -> Column(Modifier.fillMaxSize()) {
                com.abm.erp.core.TaskHeader("New Employee (Draft)", 0xFFDB2777, 0xFF9D174D, onBack = backToDash, iconVector = Icons.Filled.Groups)
                com.abm.erp.ui.hrm.NewEmployeeDraftForm(onDone = backToDash)
            }
            "hierarchy" -> HrHierarchyTab(onOpenEmployee = { onNavigate("rich_employee_detail/$it") })
            "distribute" -> HrTargetDistributionTab()
            "salary" -> HrSalaryStructureTab()
            "attsummary" -> HrAttendanceSummaryTab()
            "advance" -> HrFinanceTab()
            "policy" -> HrPolicyTab()
            "route" -> HrRoutePlanTab()
            "hrapprove" -> HrApproveTab(onNavigate = onNavigate)
            "livemap" -> HrLiveLocationTab()
            "target" -> com.abm.erp.ui.admin.VacancyTargetCenterScreen()
            "complain" -> com.abm.erp.ui.complaint.ComplaintBoxScreen()
            "performance" -> HrPerformanceTab()
            "reports" -> HrReportsTab()
            // v113-167 — Chairman-only consolidation: hiring approve/reject/return and
            // vacancy/target status control, previously reachable only via a separate
            // NavGraph route (hiring) or duplicated inline in the old Chairman module
            // (target). Same two working screens, reused as-is — not rewritten — since
            // they already correctly gate their action buttons to Chairman internally.
            "chctrl" -> if (isChairman) HrChairmanControlTab() else HrDashboardHost()
            "chairman" -> if (isChairman) HrChairmanPanel(onNavigate) else HrDashboardHost()
            else -> HrDashboardHost()
        }
    }
}

/** v113-167/172 — Chairman-only panel for HR: every Chairman-gated action for this module, one place. */
@Composable
private fun HrChairmanPanel(onNavigate: (String) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Hiring") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Vacancy & Target") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Account Control") })
            Tab(selected = tab == 3, onClick = { tab = 3 }, text = { Text("Company & Payroll") })
            Tab(selected = tab == 4, onClick = { tab = 4 }, text = { Text("Restore") })
        }
        when (tab) {
            0 -> com.abm.erp.ui.admin.HiringApprovalCenterScreen()
            1 -> com.abm.erp.ui.admin.VacancyTargetCenterScreen()
            2 -> com.abm.erp.ui.admin.EmployeeSetupScreen(onNavigate = onNavigate)
            // v113-221 — the person's own explicit relocation: fiscal
            // year/working days/holidays/policy notes and the HR-relevant
            // business rules (shift length, OT rate, attendance radius,
            // late-entry grace) all moved here from the old, oversized
            // central Company Settings + Business Rule Engine screens —
            // this is where they're actually used.
            3 -> com.abm.erp.ui.admin.CompanyPayrollSetupScreen()
            // v113-172 — moved from the central Chairman module's "master" Master
            // Controller — Task is an employee-assigned work item, HR's domain.
            else -> Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
                Text("Soft-deleted রেকর্ড দেখা ও restore — hard delete এই অ্যাপে নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Spacer(Modifier.height(8.dp))
                com.abm.erp.ui.chairmanmodule.HrTaskRestoreSection()
            }
        }
    }
}

/**
 * Compact HR dashboard. Deliberately NOT PayrollScreen(startTab = null) — that renders
 * the full old module dashboard (workspace header + tile grid), which inside the drawer
 * shell is precisely the "second dashboard before the task" clutter the TaskHeader fix
 * (v113-71) and the drawer redesign both exist to remove.
 */
@Composable
private fun HrDashboardHost() {
    val leaves by com.abm.erp.data.MockRepository.leaveRequests.collectAsState()
    val profiles by com.abm.erp.data.MockRepository.employeeProfiles.collectAsState()
    val today = java.time.LocalDate.now()
    val pendingLeaves = remember(leaves) { leaves.count { it.status == com.abm.erp.data.LeaveStatus.PENDING } }
    val onLeaveToday = remember(leaves) {
        leaves.count { it.status == com.abm.erp.data.LeaveStatus.APPROVED && !today.isBefore(it.fromDate) && !today.isAfter(it.toDate) }
    }
    com.abm.erp.core.RegisterModuleMenuContent(
        title = "HR Overview",
        rows = listOf(
            "Employee Profile" to "${profiles.size}",
            "Pending Leave" to "$pendingLeaves",
            "আজ ছুটিতে" to "$onLeaveToday",
        ),
    )
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("HR Overview", style = MaterialTheme.typography.titleMedium, color = com.abm.erp.theme.TextPrimary)
        Spacer(Modifier.height(12.dp))
        com.abm.erp.core.GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Employee Profile", color = TextSecondary)
                Text("${profiles.size}", color = com.abm.erp.theme.TextPrimary)
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Pending Leave", color = TextSecondary)
                Text("$pendingLeaves", color = if (pendingLeaves > 0) com.abm.erp.theme.WarningAmber else com.abm.erp.theme.SuccessGreen)
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("আজ ছুটিতে", color = TextSecondary)
                Text("$onLeaveToday", color = com.abm.erp.theme.TextPrimary)
            }
        }
        // v113-140 — KPI graphic for HR, same shared chart. Checked the real API
        // first: there is NO app-wide attendance StateFlow (only the per-employee
        // `attendanceRecordsFor(id)` query), so an attendance chart here would mean
        // inventing an aggregate that doesn't exist. Using the data HR genuinely
        // has at this level instead — real leave requests, approved vs pending, by
        // the week they were applied for.
        val hrWeekly = remember(leaves) {
            val t = java.time.LocalDate.now()
            val monday = t.minusDays((t.dayOfWeek.value - 1).toLong())
            (4 downTo 0).map { w ->
                val wkStart = monday.minusWeeks(w.toLong())
                val wkEnd = wkStart.plusDays(7)
                val inWeek = leaves.filter { !it.fromDate.isBefore(wkStart) && it.fromDate.isBefore(wkEnd) }
                Triple(
                    "${wkStart.dayOfMonth}/${wkStart.monthValue}",
                    inWeek.count { it.status == com.abm.erp.data.LeaveStatus.APPROVED }.toDouble(),
                    inWeek.count { it.status == com.abm.erp.data.LeaveStatus.PENDING }.toDouble(),
                )
            }
        }
        if (hrWeekly.any { it.second > 0.0 || it.third > 0.0 }) {
            Spacer(Modifier.height(12.dp))
            com.abm.erp.core.GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Leave — Approved vs Pending (Last 5 Weeks)", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold, color = com.abm.erp.theme.TextPrimary)
                Spacer(Modifier.height(10.dp))
                com.abm.erp.core.DualSeriesBarChart(hrWeekly, "Approved", "Pending")
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Attendance/Payroll/Leave-এর বিস্তারিত বাম মেনু থেকে খুলুন।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
    }
}

/**
 * v113-77 — Employee Performance, inside HR where the person's draft puts it.
 * Uses the existing `computeEmployeePerformance` (Foundation 2 §16) — real, per-
 * employee data from actual linked ledger/visit records, not the CRM tab's dealer
 * ranking (which is a different feature and stays where it is). Cascade-scoped: the
 * viewer only sees employees `visibleEmployeeProfilesFor` allows.
 */
@Composable
private fun HrPerformanceTab() {
    val profiles = com.abm.erp.core.rememberVisibleEmployeeProfiles()
    var selectedId by remember { mutableStateOf<String?>(null) }
    var perf by remember { mutableStateOf<com.abm.erp.data.MockRepository.EmployeePerformance?>(null) }

    LaunchedEffect(selectedId) {
        perf = selectedId?.let { com.abm.erp.data.MockRepository.computeEmployeePerformance(it) }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Employee Performance", style = MaterialTheme.typography.titleMedium, color = com.abm.erp.theme.TextPrimary)
        Spacer(Modifier.height(8.dp))
        androidx.compose.foundation.lazy.LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(profiles, key = { it.id }) { p ->
                com.abm.erp.core.ModuleDrillRow(p.fullName, p.department) { selectedId = p.id }
            }
        }
    }

    val currentPerf = perf
    val currentId = selectedId
    if (currentId != null && currentPerf != null) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { selectedId = null; perf = null }) {
            androidx.compose.material3.Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        profiles.firstOrNull { it.id == currentId }?.fullName ?: "",
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Spacer(Modifier.height(10.dp))
                    HrPerfRow("Retailer Coverage", "${currentPerf.retailerCoverage}")
                    HrPerfRow("Sales (90d)", "৳${"%,.0f".format(currentPerf.salesValue90Days)}")
                    HrPerfRow("Collection (90d)", "৳${"%,.0f".format(currentPerf.collectionValue90Days)}")
                    HrPerfRow("Collection Efficiency", "${"%.0f".format(currentPerf.collectionEfficiencyPct)}%")
                    HrPerfRow("Visit Compliance (30d)", "${"%.0f".format(currentPerf.visitCompliancePct)}%")
                    HrPerfRow("Inactive Retailer", "${currentPerf.inactiveRetailerCount}")
                    HrPerfRow("New Retailer (this month)", "${currentPerf.newRetailersThisMonth}")
                }
            }
        }
    }
}

@Composable
private fun HrPerfRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextSecondary)
        Text(value, color = com.abm.erp.theme.TextPrimary)
    }
}

/** v113-77 — HR-scoped one-page report from existing flows. */
@Composable
private fun HrReportsTab() {
    val leaves by com.abm.erp.data.MockRepository.leaveRequests.collectAsState()
    val payroll by com.abm.erp.data.MockRepository.payroll.collectAsState()
    val profiles = com.abm.erp.core.rememberVisibleEmployeeProfiles()
    val today = java.time.LocalDate.now()
    val monthLeaves = remember(leaves) { leaves.filter { it.fromDate.month == today.month && it.fromDate.year == today.year } }
    val totalPayroll = remember(payroll) { payroll.sumOf { it.basePay + it.commission } }
    val totalOvertime = remember(payroll) { payroll.sumOf { it.overtimePay } }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("HR Report — ${today.month} ${today.year}", style = MaterialTheme.typography.titleMedium, color = com.abm.erp.theme.TextPrimary)
        Spacer(Modifier.height(10.dp))
        com.abm.erp.core.GlassCard(modifier = Modifier.fillMaxWidth()) {
            HrPerfRow("Employee Profile", "${profiles.size}")
            HrPerfRow("এই মাসের Leave আবেদন", "${monthLeaves.size}")
            HrPerfRow("Approved Leave", "${monthLeaves.count { it.status == com.abm.erp.data.LeaveStatus.APPROVED }}")
            HrPerfRow("Payroll (base+commission)", "৳${"%,.0f".format(totalPayroll)}")
            HrPerfRow("Overtime", "৳${"%,.0f".format(totalOvertime)}")
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "বিস্তারিত attendance/payroll/leave নিজ নিজ ট্যাবে — এটা এক-নজরের সারাংশ।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
    }
}
