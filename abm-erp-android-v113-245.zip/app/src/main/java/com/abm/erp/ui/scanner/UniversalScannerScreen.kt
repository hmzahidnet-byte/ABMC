package com.abm.erp.ui.scanner

import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.data.CodeRegistry
import com.abm.erp.data.resolveRegistered
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.*
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

/**
 * Universal QR Scanner — ONE scan button, ONE central resolver, real
 * detail for all 6 required types. Previously scanning lived only inside
 * DealersScreen (Dealer/Retailer only, Employee/Carton just showed a
 * toast telling the person to go look elsewhere, Production Batch and
 * Warehouse/Delivery weren't recognized as types at all).
 */
@Composable
fun UniversalScannerScreen(onNavigate: (String) -> Unit = {}) {
    val context = LocalContext.current
    var resolved by remember { mutableStateOf<CodeRegistry.ResolveResult?>(null) }
    var lastScannedRaw by remember { mutableStateOf("") }

    var secureDenial by remember { mutableStateOf<String?>(null) }
    var offlineVerified by remember { mutableStateOf(false) }
    val scanScope = androidx.compose.runtime.rememberCoroutineScope()

    // v113-138 — QR is a universal action, so tapping the QR button anywhere should
    // open the camera itself, not a landing page with another button on it. The
    // camera now launches automatically on first entry; the screen underneath stays
    // as the RESULT view (and lets the person re-scan without going back out).
    var autoLaunched by rememberSaveable { mutableStateOf(false) }
    val scanLauncher = androidx.activity.compose.rememberLauncherForActivityResult(ScanContract()) { result ->
        val code = result?.contents ?: return@rememberLauncherForActivityResult
        lastScannedRaw = code
        secureDenial = null
        offlineVerified = false

        if (com.abm.erp.data.QrRegistry.isSecurePayload(code)) {
            // Secure path: the payload is one of ours, so it must pass full registry
            // validation — company isolation, token, status, expiry, permission. A
            // failure here never falls through to the legacy matcher; that would
            // defeat the point of revocation.
            resolved = null
            scanScope.launch {
                val online = com.abm.erp.util.NetworkStatus.isOnline(context)
                when (val res = com.abm.erp.data.QrRegistry.resolve(code, online)) {
                    is com.abm.erp.data.QrRegistry.Resolution.Allowed -> {
                        offlineVerified = res.offlineVerified
                        resolved = CodeRegistry.resolveRegistered(res.entityType, res.entityId)
                    }
                    is com.abm.erp.data.QrRegistry.Resolution.Denied -> {
                        secureDenial = res.reason
                    }
                }
            }
        } else {
            // Legacy path: a code printed before the secure registry existed, or a
            // supplier's own barcode. Still resolved so old tags keep working, but it
            // is labelled as unverified in the UI rather than presented as trusted.
            resolved = CodeRegistry.resolve(code)
            val r = resolved
            if (r is CodeRegistry.ResolveResult.Found) {
                MockRepository.logAudit(r.type.name, r.id, "QR_SCANNED_LEGACY", reason = "Unregistered code scanned by ${MockRepository.currentUser.name}")
            }
        }
    }

    LaunchedEffect(Unit) {
        if (!autoLaunched) { autoLaunched = true; scanLauncher.launch(abmScanOptions()) }
    }

    // v113-229 — the person's own explicit, direct complaint: scanning
    // Dealer/Retailer/Employee/Product used to always show a small,
    // bespoke "card" (a few lines of text and 2-3 buttons) instead of the
    // same rich, consistent design every List screen's own detail view
    // already has (Info, Ledger, 90-Day, Graph, Calendar, QR, extraTabs).
    // Those four types already have real BrowseConfigs built and proven
    // elsewhere (Dealer/Retailer/Employee/Product List) — reused directly
    // here via the same generic ModuleBrowseDetail, rather than building
    // a second, different-looking view of the same data. When one of
    // these resolves successfully, it now takes over the full screen,
    // exactly like tapping into that same record from its own List would.
    val r = if (secureDenial != null) null else resolved
    if (r is CodeRegistry.ResolveResult.Found && r.type in setOf(CodeRegistry.CodeType.DEALER, CodeRegistry.CodeType.RETAILER, CodeRegistry.CodeType.EMPLOYEE, CodeRegistry.CodeType.PRODUCT, CodeRegistry.CodeType.CARTON)) {
        RichScanDetailScreen(r, onNavigate) { resolved = null }
        return
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Universal QR Scanner", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(6.dp))
        Text("Employee, Retailer, Dealer, Product/Carton, Production Batch, Warehouse/Delivery, Invoice, Collection — সব এক জায়গা থেকে স্ক্যান করুন।", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { scanLauncher.launch(abmScanOptions()) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("📷 আবার স্ক্যান করুন") }
        Spacer(Modifier.height(16.dp))

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            // A secure-registry denial takes precedence over everything: the record is not
            // shown, only the reason. Blueprint/Part 2 — never open a record because a
            // visible id happened to match.
            secureDenial?.let { reason ->
                com.abm.erp.core.WorkspaceErrorState(reason) { secureDenial = null }
            }
            if (offlineVerified && secureDenial == null && resolved != null) {
                Text(
                    "⚠ অফলাইন যাচাই — এই ডিভাইসে সংরক্ষিত তথ্য দিয়ে মিলানো হয়েছে; সার্ভারে বাতিল হয়েছে কিনা এখন নিশ্চিত করা যায়নি।",
                    color = com.abm.erp.theme.StatusAmber,
                    style = MaterialTheme.typography.labelSmall,
                )
                Spacer(Modifier.height(8.dp))
            }
            when (val r = if (secureDenial != null) null else resolved) {
                null -> if (secureDenial == null) Text("স্ক্যান করার জন্য উপরের বাটনে চাপুন।", color = TextSecondary)
                is CodeRegistry.ResolveResult.Invalid -> Text("অবৈধ কোড।", color = DangerRed)
                is CodeRegistry.ResolveResult.NotFound -> Text("কোনো মিলে যাওয়া রেকর্ড পাওয়া যায়নি: $lastScannedRaw", color = DangerRed)
                is CodeRegistry.ResolveResult.Ambiguous -> {
                    Text("⚠ এই কোড একাধিক রেকর্ডের সাথে মিলছে — ডেটা সমস্যা, Chairman-কে জানান।", color = DangerRed, fontWeight = FontWeight.Bold)
                    r.matches.forEach { (type, id) -> Text("• $type — $id", color = TextSecondary) }
                }
                is CodeRegistry.ResolveResult.Found -> ScanResultCard(r, onNavigate)
            }
        }
    }
}

@Composable
private fun RichScanDetailScreen(result: CodeRegistry.ResolveResult.Found, onNavigate: (String) -> Unit, onBack: () -> Unit) {
    val currentUser = MockRepository.currentUser
    // Same territory/permission validation ScanResultCard's own dealer/
    // retailer/employee branches already did — kept identical, just
    // scoped to these four types since the other types still go through
    // ScanResultCard's own full check.
    val (allowed, denyReason) = remember(result.id, result.type) {
        when (result.type) {
            CodeRegistry.CodeType.DEALER ->
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("dealer", com.abm.erp.data.PermissionAction.VIEW)) false to "Dealer তথ্য দেখার অনুমতি নেই।"
                else if (result.id !in MockRepository.visibleDealerIds(currentUser.employeeId)) false to "এই Dealer আপনার এলাকার বাইরে — অ্যাক্সেস নেই।"
                else true to null
            CodeRegistry.CodeType.RETAILER ->
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("dealer", com.abm.erp.data.PermissionAction.VIEW)) false to "Retailer তথ্য দেখার অনুমতি নেই।"
                else if (result.id !in MockRepository.visibleRetailerIds(currentUser.employeeId)) false to "এই Retailer আপনার এলাকার বাইরে — অ্যাক্সেস নেই।"
                else true to null
            CodeRegistry.CodeType.EMPLOYEE ->
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("hr", com.abm.erp.data.PermissionAction.VIEW)) false to "Employee তথ্য দেখার অনুমতি নেই।"
                else if (result.id !in MockRepository.visibleEmployeeIds(currentUser.employeeId)) false to "এই Employee আপনার hierarchy-র বাইরে — অ্যাক্সেস নেই।"
                else true to null
            CodeRegistry.CodeType.PRODUCT ->
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("inv", com.abm.erp.data.PermissionAction.VIEW)) false to "Product তথ্য দেখার অনুমতি নেই।"
                else true to null
            else -> true to null
        }
    }
    if (!allowed) {
        MockRepository.logAudit(result.type.name, result.id, "SCAN_ACCESS_DENIED", reason = denyReason)
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            com.abm.erp.core.WorkspaceErrorState(denyReason ?: "অ্যাক্সেস নেই।", onBack)
        }
        return
    }

    when (result.type) {
        CodeRegistry.CodeType.DEALER -> {
            val dealers by MockRepository.dealers.collectAsState()
            val dealer = dealers.firstOrNull { it.id == result.id }
            if (dealer == null) { com.abm.erp.core.WorkspaceErrorState("এই Dealer আর নেই — মুছে ফেলা হয়ে থাকতে পারে।", onBack); return }
            val zones = remember(dealers) { dealers.map { it.zone }.filter { it.isNotBlank() }.distinct().sorted() }
            com.abm.erp.core.ModuleBrowseDetail(com.abm.erp.core.rememberDealerBrowseConfig(zones), dealer, onBack, onNavigate)
        }
        CodeRegistry.CodeType.RETAILER -> {
            val retailers by MockRepository.retailers.collectAsState()
            val retailer = retailers.firstOrNull { it.id == result.id }
            if (retailer == null) { com.abm.erp.core.WorkspaceErrorState("এই Retailer আর নেই — মুছে ফেলা হয়ে থাকতে পারে।", onBack); return }
            val markets = remember(retailers) { retailers.map { it.market }.filter { it.isNotBlank() }.distinct().sorted() }
            com.abm.erp.core.ModuleBrowseDetail(com.abm.erp.core.rememberRetailerBrowseConfig(markets), retailer, onBack, onNavigate)
        }
        CodeRegistry.CodeType.EMPLOYEE -> {
            val profiles by MockRepository.employeeProfiles.collectAsState()
            val emp = profiles.firstOrNull { it.id == result.id }
            if (emp == null) { com.abm.erp.core.WorkspaceErrorState("এই Employee আর নেই — মুছে ফেলা হয়ে থাকতে পারে।", onBack); return }
            val departments = remember(profiles) { profiles.map { it.department }.filter { it.isNotBlank() }.distinct().sorted() }
            com.abm.erp.core.ModuleBrowseDetail(com.abm.erp.core.rememberEmployeeBrowseConfig(departments), emp, onBack, onNavigate)
        }
        CodeRegistry.CodeType.PRODUCT -> {
            val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
            val product = products.firstOrNull { it.id == result.id }
            if (product == null) { com.abm.erp.core.WorkspaceErrorState("এই Product আর নেই — মুছে ফেলা হয়ে থাকতে পারে।", onBack); return }
            val categories = remember(products) { products.map { it.category }.filter { it.isNotBlank() }.distinct().sorted() }
            com.abm.erp.core.ModuleBrowseDetail(com.abm.erp.core.rememberProductBrowseConfig(categories), product, onBack, onNavigate)
        }
        CodeRegistry.CodeType.CARTON -> CartonScanDetail(result.id, result.extra, onBack)
        else -> {}
    }
}

@Composable
private fun ScanResultCard(result: CodeRegistry.ResolveResult.Found, onNavigate: (String) -> Unit) {
    val currentUser = MockRepository.currentUser
    // Real territory + permission validation — was completely missing
    // before: any resolved code's details were shown regardless of
    // whether this employee was even authorized to view that module, or
    // whether the specific record was inside their assigned territory.
    val (allowed, denyReason) = remember(result.id, result.type) {
        when (result.type) {
            CodeRegistry.CodeType.DEALER -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("dealer", com.abm.erp.data.PermissionAction.VIEW)) false to "Dealer তথ্য দেখার অনুমতি নেই।"
                else if (result.id !in MockRepository.visibleDealerIds(currentUser.employeeId)) false to "এই Dealer আপনার এলাকার বাইরে — অ্যাক্সেস নেই।"
                else true to null
            }
            CodeRegistry.CodeType.RETAILER -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("dealer", com.abm.erp.data.PermissionAction.VIEW)) false to "Retailer তথ্য দেখার অনুমতি নেই।"
                else if (result.id !in MockRepository.visibleRetailerIds(currentUser.employeeId)) false to "এই Retailer আপনার এলাকার বাইরে — অ্যাক্সেস নেই।"
                else true to null
            }
            CodeRegistry.CodeType.EMPLOYEE -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("hr", com.abm.erp.data.PermissionAction.VIEW)) false to "Employee তথ্য দেখার অনুমতি নেই।"
                else if (result.id !in MockRepository.visibleEmployeeIds(currentUser.employeeId)) false to "এই Employee আপনার hierarchy-র বাইরে — অ্যাক্সেস নেই।"
                else true to null
            }
            CodeRegistry.CodeType.CARTON, CodeRegistry.CodeType.PRODUCTION_BATCH -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("prod", com.abm.erp.data.PermissionAction.VIEW)) false to "Production তথ্য দেখার অনুমতি নেই।"
                else true to null
            }
            CodeRegistry.CodeType.WAREHOUSE_TRANSFER -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("stock", com.abm.erp.data.PermissionAction.VIEW)) false to "Warehouse তথ্য দেখার অনুমতি নেই।"
                else true to null
            }
            CodeRegistry.CodeType.INVOICE, CodeRegistry.CodeType.COLLECTION -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("bill", com.abm.erp.data.PermissionAction.VIEW)) false to "এই তথ্য দেখার অনুমতি নেই।"
                else true to null
            }
            CodeRegistry.CodeType.PRODUCT -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("inv", com.abm.erp.data.PermissionAction.VIEW)) false to "Product তথ্য দেখার অনুমতি নেই।"
                else true to null
            }
            CodeRegistry.CodeType.DELIVERY -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("stock", com.abm.erp.data.PermissionAction.VIEW)) false to "Delivery তথ্য দেখার অনুমতি নেই।"
                else true to null
            }
            CodeRegistry.CodeType.UNKNOWN -> true to null
        }
    }
    if (!allowed) {
        MockRepository.logAudit(result.type.name, result.id, "SCAN_ACCESS_DENIED", reason = denyReason)
        Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
            Text(denyReason ?: "অ্যাক্সেস নেই।", color = DangerRed, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
        }
        return
    }
    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            when (result.type) {
                CodeRegistry.CodeType.EMPLOYEE -> EmployeeScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.RETAILER -> RetailerScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.DEALER -> DealerScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.CARTON -> {} // v113-230 — now handled by RichScanDetailScreen before this card is ever reached; CartonScanDetail's signature changed to a full-screen one (needs onBack), which this small embedded card doesn't have.
                CodeRegistry.CodeType.PRODUCTION_BATCH -> ProductionBatchScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.WAREHOUSE_TRANSFER -> WarehouseTransferScanDetail(result.id)
                CodeRegistry.CodeType.INVOICE -> InvoiceScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.COLLECTION -> CollectionScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.PRODUCT -> ProductScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.DELIVERY -> DeliveryScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.UNKNOWN -> Text("অজানা কোড টাইপ।", color = TextSecondary)
            }
        }
    }
}

@Composable
private fun EmployeeScanDetail(employeeId: String, onNavigate: (String) -> Unit) {
    val profiles by MockRepository.employeeProfiles.collectAsState()
    val emp = profiles.firstOrNull { it.id == employeeId }
    var attendanceSummary by remember(employeeId) { mutableStateOf<Pair<Int, Int>?>(null) } // present, absent
    LaunchedEffect(employeeId) { attendanceSummary = MockRepository.attendanceSummary(employeeId) }
    Text("👤 Employee", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(emp?.fullName ?: employeeId, style = MaterialTheme.typography.titleMedium)
    Text("${emp?.designation ?: ""} — ${emp?.department ?: ""}", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
    Text("Employee Code: ${emp?.employeeCode ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    attendanceSummary?.let { (present, absent) ->
        Text("Attendance: $present দিন উপস্থিত, $absent দিন অনুপস্থিত", style = MaterialTheme.typography.bodySmall)
    } ?: com.abm.erp.core.WorkspaceLoadingState("Attendance লোড হচ্ছে…")
    Spacer(Modifier.height(8.dp))
    Text("Connected workflow", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TextButton(onClick = { onNavigate("hrm") }) { Text("Attendance") }
        TextButton(onClick = { onNavigate("hrm") }) { Text("Payroll") }
        TextButton(onClick = { onNavigate("enterprise_audit_center") }) { Text("Activity") }
    }
}

@Composable
private fun RetailerScanDetail(retailerId: String, onNavigate: (String) -> Unit) {
    val retailers by MockRepository.retailers.collectAsState()
    val orders by MockRepository.orders.collectAsState()
    val retailer = retailers.firstOrNull { it.id == retailerId }
    val latestOrder = orders.filter { it.retailerId == retailerId }.maxByOrNull { it.loggedAt }
    Text("🏪 Retailer", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(retailer?.name ?: retailerId, style = MaterialTheme.typography.titleMedium)
    Text("Code: ${retailer?.retailerCode ?: "—"} — Due: ৳${"%,.0f".format(retailer?.dueBalance ?: 0.0)}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    if (latestOrder != null) {
        Text("সর্বশেষ অর্ডার: ${latestOrder.orderNo} — ৳${"%,.0f".format(latestOrder.amount)} (${latestOrder.stage})", style = MaterialTheme.typography.bodySmall)
    } else {
        Text("কোনো সাম্প্রতিক অর্ডার পাওয়া যায়নি।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
    }
    Spacer(Modifier.height(8.dp))
    Text("Connected workflow", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TextButton(onClick = { onNavigate("sales") }) { Text("Order/Invoice") }
        TextButton(onClick = { onNavigate("dealers") }) { Text("Collection") }
        TextButton(onClick = { onNavigate("statement/RETAILER/$retailerId") }) { Text("Statement") }
    }
}

@Composable
private fun DealerScanDetail(dealerId: String, onNavigate: (String) -> Unit) {
    val dealers by MockRepository.dealers.collectAsState()
    val dealer = dealers.firstOrNull { it.id == dealerId }
    val ledger by remember(dealerId) { MockRepository.partyLedgerFor(com.abm.erp.data.PartyType.DEALER, dealerId) }.collectAsState(initial = emptyList())
    val latestLedgerEntries = ledger.sortedByDescending { it.createdAt }.take(5)
    Text("🏢 Dealer Dashboard", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(dealer?.name ?: dealerId, style = MaterialTheme.typography.titleMedium)
    Text("Code: ${dealer?.dealerCode ?: "—"} — Due: ৳${"%,.0f".format(dealer?.dueBalance ?: 0.0)}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Text("সর্বশেষ লেজার এন্ট্রি:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    if (latestLedgerEntries.isEmpty()) Text("কোনো এন্ট্রি নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
    latestLedgerEntries.forEach { Text("• ${it.type} ৳${"%,.0f".format(it.amount)} — ${it.reason}", style = MaterialTheme.typography.bodySmall) }
    Spacer(Modifier.height(8.dp))
    Text("Connected workflow", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TextButton(onClick = { onNavigate("sales") }) { Text("Invoice") }
        TextButton(onClick = { onNavigate("dealers") }) { Text("Collection") }
        // Opens THIS dealer's statement, not the generic ledger module.
        TextButton(onClick = { onNavigate("statement/DEALER/$dealerId") }) { Text("Statement") }
    }
}

@Composable
private fun CartonScanDetail(cartonId: String, cartonCode: String?, onBack: () -> Unit) {
    // v113-230 — visual upgrade to match the person's own explicit request:
    // the same polished style as Dealer/Employee/Product's own detail view
    // (branded gradient header, clean white card body, QR), even though
    // Carton's own DATA is genuinely different (a physical tracking
    // journey — packed/warehouse/dispatch/delivered — not a money-bearing
    // party's history), so it isn't a ModuleBrowseDetail/BrowseConfig
    // underneath (Ledger/Graph/90-Day genuinely have nothing to show for
    // a carton) — same visual language, honest about having different
    // content. Full journey shown (whichever stages actually happened),
    // plus exactly one contextual action for wherever it is right now —
    // unchanged from the real, working v113-216 logic, just re-presented.
    val cartons by MockRepository.cartons.collectAsState()
    val carton = cartons.firstOrNull { it.id == cartonId }
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var success by remember { mutableStateOf(false) }
    var showQr by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(DashBg)) {
        com.abm.erp.core.BrowseTopBar("Carton Details", carton?.cartonCode ?: cartonCode, 0xFFE85D4A, 0xFFC03A2B, onBack)
        if (carton == null) {
            Column(Modifier.padding(16.dp)) {
                Text(cartonCode ?: cartonId, style = MaterialTheme.typography.titleMedium)
                Text("এই Carton খুঁজে পাওয়া যায়নি — এটা কি একটা পুরনো/manual code, real QR না?", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            return
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(Color.White).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(8.dp)).background(DashBg)
                        .clickable { showQr = true },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.QrCode2, "QR", tint = TextPrimary, modifier = Modifier.size(26.dp)) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(carton.cartonCode, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("${carton.productName} · ${"%,.1f".format(carton.quantityInside)} ${carton.unit}", fontSize = 11.sp, color = TextSecondary)
                }
                val statusColor = when (carton.status) {
                    "DELIVERED" -> SuccessGreen
                    "DISPATCHED" -> WarningAmber
                    "WAREHOUSE_RECEIVED" -> com.abm.erp.theme.StatusBlue
                    else -> TextSecondary
                }
                Text(carton.status, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = statusColor)
            }
            Spacer(Modifier.height(12.dp)); Divider(); Spacer(Modifier.height(10.dp))

            Surface(tonalElevation = 2.dp, shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Basic Information", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    listOf(
                        "Carton Code" to carton.cartonCode,
                        "Product" to carton.productName,
                        "Quantity" to "${"%,.1f".format(carton.quantityInside)} ${carton.unit}",
                        "Batch" to (carton.batchCode ?: "এখনো নির্ধারিত হয়নি (QC pending)"),
                        "Status" to carton.status,
                    ).forEach { (label, value) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(label, fontSize = 12.sp, color = TextSecondary)
                            Text(value, fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Medium, maxLines = 1)
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Surface(tonalElevation = 2.dp, shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("যাত্রা (Journey)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    Text("📦 Packed — ${carton.packedBy}, ${carton.packedAt.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    carton.warehouseReceivedAt?.let { Text("🏭 Warehouse — ${carton.warehouseReceivedBy}, ${it.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                    carton.dispatchedAt?.let { Text("🚚 Dispatched → ${carton.dispatchedTo} — ${carton.dispatchedBy}, ${it.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                    carton.deliveredAt?.let { Text("✅ Delivered — ${carton.deliveredBy}, ${it.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                }
            }
            error?.let { Spacer(Modifier.height(10.dp)); Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
            if (success) { Spacer(Modifier.height(10.dp)); Text("✓ Updated হয়েছে।", color = SuccessGreen, style = MaterialTheme.typography.labelSmall) }
            Spacer(Modifier.height(14.dp))

            when (carton.status) {
                "PACKED" -> {
                    val warehouses by com.abm.erp.data.InventoryRepository.warehouses.collectAsState()
                    var expanded by remember { mutableStateOf(false) }
                    var selectedWarehouseId by remember { mutableStateOf<String?>(null) }
                    val selectedWarehouse = warehouses.firstOrNull { it.id == selectedWarehouseId }
                    Box {
                        OutlinedButton(onClick = { expanded = true }) { Text(selectedWarehouse?.name ?: "Warehouse বেছে নিন") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            warehouses.forEach { w -> DropdownMenuItem(text = { Text(w.name) }, onClick = { selectedWarehouseId = w.id; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Button(
                        enabled = !busy && selectedWarehouseId != null,
                        onClick = {
                            busy = true; error = null; success = false
                            scope.launch {
                                val ok = MockRepository.receiveCartonAtWarehouse(carton.id, selectedWarehouseId!!, onRejected = { e -> error = e })
                                busy = false; success = ok
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("✓ Warehouse Receive") }
                }
                "WAREHOUSE_RECEIVED" -> {
                    var dispatchedTo by remember { mutableStateOf("") }
                    OutlinedTextField(value = dispatchedTo, onValueChange = { dispatchedTo = it }, label = { Text("কোথায় পাঠানো হচ্ছে (dealer/route/vehicle)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Button(
                        enabled = !busy && dispatchedTo.isNotBlank(),
                        onClick = {
                            busy = true; error = null; success = false
                            scope.launch {
                                val ok = MockRepository.dispatchCarton(carton.id, dispatchedTo, onRejected = { e -> error = e })
                                busy = false; success = ok
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("🚚 Dispatch") }
                }
                "DISPATCHED" -> {
                    Button(
                        enabled = !busy,
                        onClick = {
                            busy = true; error = null; success = false
                            scope.launch {
                                val ok = MockRepository.deliverCarton(carton.id, onRejected = { e -> error = e })
                                busy = false; success = ok
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("✓ Mark Delivered") }
                }
                "DELIVERED" -> Text("এই carton-এর যাত্রা সম্পূর্ণ — manufacturing → warehouse → dispatch → delivery।", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
            }
        }
    }
    if (showQr) {
        com.abm.erp.core.RecordQrDialog(code = carton.cartonCode, title = carton.cartonCode, subtitle = carton.productName, onDismiss = { showQr = false })
    }
}

@Composable
private fun ProductionBatchScanDetail(planId: String, onNavigate: (String) -> Unit) {
    val plans by MockRepository.productionPlans.collectAsState()
    val qc by MockRepository.qualityInspections.collectAsState()
    val plan = plans.firstOrNull { it.id == planId }
    val qcRecords = qc.filter { it.productionPlanId == planId }
    Text("🏭 Production Batch", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(plan?.batchNumber ?: planId, style = MaterialTheme.typography.titleMedium)
    Text("Product: ${plan?.productId ?: "—"} — Planned: ${plan?.plannedQuantity ?: 0.0} ${plan?.unit ?: ""}", style = MaterialTheme.typography.bodySmall)
    Text("Status: ${plan?.status ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Text("QC Inspections: ${qcRecords.size}টি", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    qcRecords.take(3).forEach { Text("• ${it.result}${it.testParameters?.let { p -> " — $p" } ?: ""}", style = MaterialTheme.typography.bodySmall) }
    Spacer(Modifier.height(8.dp))
    Text("Connected workflow", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TextButton(onClick = { onNavigate("production") }) { Text("QC") }
        TextButton(onClick = { onNavigate("production_warehouse") }) { Text("Transfer") }
        TextButton(onClick = { onNavigate("inventory") }) { Text("Warehouse") }
    }
}

@Composable
private fun WarehouseTransferScanDetail(transferId: String) {
    val transfers by MockRepository.warehouseTransfers.collectAsState()
    val transfer = transfers.firstOrNull { it.id == transferId }
    Text("🚚 Warehouse / Delivery", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(transfer?.transferNumber ?: transferId, style = MaterialTheme.typography.titleMedium)
    Text("${transfer?.sourceWarehouseId ?: "—"} → ${transfer?.destinationWarehouseId ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Text("Status: ${transfer?.status ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(4.dp))
    Text("${transfer?.lines?.size ?: 0}টি লাইন-আইটেম", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
}

@Composable
private fun InvoiceScanDetail(invoiceId: String, onNavigate: (String) -> Unit) {
    val invoices by MockRepository.salesInvoices.collectAsState()
    val invoice = invoices.firstOrNull { it.id == invoiceId }
    Text("🧾 Invoice", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(invoice?.invoiceNo ?: invoiceId, style = MaterialTheme.typography.titleMedium)
    Text(invoice?.dealerName ?: "—", style = MaterialTheme.typography.bodySmall)
    Text("৳${"%,.0f".format(invoice?.total ?: 0.0)} — Status: ${invoice?.status ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Text("Connected workflow", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TextButton(onClick = { onNavigate("invoice_doc/$invoiceId") }) { Text("Open Invoice") }
        TextButton(onClick = { onNavigate("inventory") }) { Text("Stock") }
        TextButton(onClick = { onNavigate("ledger") }) { Text("Ledger") }
        TextButton(onClick = { onNavigate("billing") }) { Text("Delivery") }
    }
}

@Composable
private fun CollectionScanDetail(collectionId: String, onNavigate: (String) -> Unit) {
    val collections by MockRepository.partyCollections.collectAsState()
    val collection = collections.firstOrNull { it.id == collectionId }
    Text("💵 Collection", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(collection?.collectionNo ?: collectionId, style = MaterialTheme.typography.titleMedium)
    Text(collection?.partyName ?: "—", style = MaterialTheme.typography.bodySmall)
    Text("৳${"%,.0f".format(collection?.amount ?: 0.0)} — Status: ${collection?.status ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Button(onClick = { onNavigate("dealers") }) { Text("Dealer/Retailer workspace খুলুন") }
}

@Composable
private fun ProductScanDetail(productId: String, onNavigate: (String) -> Unit) {
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val product = products.firstOrNull { it.id == productId }
    Text("📦 Product", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(product?.name ?: productId, style = MaterialTheme.typography.titleMedium)
    Text("SKU: ${product?.sku ?: "—"} — ৳${"%,.0f".format(product?.defaultUnitPrice ?: 0.0)}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Button(onClick = { onNavigate("inventory") }) { Text("Inventory workspace খুলুন") }
}

@Composable
private fun DeliveryScanDetail(challanId: String, onNavigate: (String) -> Unit) {
    val challans by MockRepository.deliveryChallans.collectAsState()
    val challan = challans.firstOrNull { it.id == challanId }
    Text("🚛 Delivery", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(challan?.challanNo ?: challanId, style = MaterialTheme.typography.titleMedium)
    Text(challan?.partyName ?: "—", style = MaterialTheme.typography.bodySmall)
    Text("Vehicle: ${challan?.vehicleNo?.ifBlank { "—" } ?: "—"} — Driver: ${challan?.driverName?.ifBlank { "—" } ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Button(onClick = { onNavigate("billing") }) { Text("Billing workspace খুলুন") }
}

/**
 * v113-138 — one shared scan configuration for the whole app.
 * `setOrientationLocked(false)` previously let the scanner flip to landscape when
 * the phone tilted, which is wrong for a QR held in front of you — locked to the
 * app's portrait orientation instead. Defined once here so every entry point
 * (dashboard, invoice, memo, collection, browse-list FAB) opens an identical
 * scanner rather than each configuring its own.
 */
private fun abmScanOptions(): ScanOptions = ScanOptions()
    .setPrompt("QR/Barcode স্ক্যান করুন")
    .setBeepEnabled(true)
    .setOrientationLocked(true)
