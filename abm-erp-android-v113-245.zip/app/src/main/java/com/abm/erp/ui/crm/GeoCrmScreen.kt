package com.abm.erp.ui.crm

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.abm.erp.core.*
import com.abm.erp.data.CampaignChannel
import com.abm.erp.data.CrmRepository
import com.abm.erp.data.Dealer
import com.abm.erp.data.Lead
import com.abm.erp.data.LeadStatus
import com.abm.erp.data.MockRepository
import com.abm.erp.data.assignCustomerComplaint
import com.abm.erp.data.createCustomerComplaint
import com.abm.erp.data.rejectCustomerComplaint
import com.abm.erp.data.resolveCustomerComplaint
import com.abm.erp.data.setCustomerComplaintStatus
import com.abm.erp.location.LocationTracker
import com.abm.erp.theme.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

class GeoCrmViewModel : ViewModel() {
    val routes = MockRepository.routes
    val campaigns = MockRepository.campaigns
    val orders = MockRepository.orders
    val dealers = MockRepository.dealers
    val currentUser get() = MockRepository.currentUser
    fun recordGpsPing(userId: String, userName: String, lat: Double, lng: Double, spoofed: Boolean) =
        MockRepository.recordGpsPing(userId, userName, lat, lng, spoofed)
    fun broadcastCampaign(channel: CampaignChannel, message: String, zone: String, onRejected: (String) -> Unit = {}) =
        MockRepository.broadcastCampaign(channel, message, zone, onRejected)

    // ---- Module 6: CRM — Lead/Opportunity/Communication History ----
    val leads = CrmRepository.leads
    val opportunities = CrmRepository.opportunities
    val callLogs = CrmRepository.callLogs
    val meetingLogs = CrmRepository.meetingLogs
    val followUps = CrmRepository.followUps
    fun createLead(name: String, phone: String, source: String, onRejected: (String) -> Unit = {}) = CrmRepository.createLead(name, phone, source, currentUser.name, onRejected)
    fun updateLeadStatus(id: String, status: LeadStatus) = CrmRepository.updateLeadStatus(id, status)
    fun duplicateLead(id: String, onRejected: (String) -> Unit = {}) = CrmRepository.duplicateLead(id, onRejected)
    fun deleteLead(id: String) = CrmRepository.deleteLead(id)
    fun createOpportunity(leadId: String?, title: String, value: Double, onRejected: (String) -> Unit = {}) = CrmRepository.createOpportunity(leadId, title, value, currentUser.name, onRejected)
    fun updateOpportunityStage(id: String, stage: String) = CrmRepository.updateOpportunityStage(id, stage)
    fun logCall(leadId: String?, contactName: String, phone: String, minutes: Int, notes: String) = CrmRepository.logCall(leadId, null, null, contactName, phone, minutes, notes)
    fun logMeeting(title: String, attendees: String, notes: String) = CrmRepository.logMeeting(title, attendees, notes)
    fun createFollowUp(leadId: String?, note: String, dueInDays: Long) = CrmRepository.createFollowUp(leadId, note, java.time.LocalDateTime.now().plusDays(dueInDays))
    val salesRoutes = MockRepository.salesRoutes
    fun routeComplianceToday(route: com.abm.erp.data.SalesRoute) = MockRepository.routeComplianceToday(route)
    fun missedOutletsToday(route: com.abm.erp.data.SalesRoute) = MockRepository.missedOutletsToday(route)
    fun setFollowUpDone(id: String, done: Boolean) = CrmRepository.setFollowUpDone(id, done)
}

@Composable
fun GeoCrmScreen(startTab: Int? = null, onBack: () -> Unit = {}, vm: GeoCrmViewModel = viewModel()) {
    val routes by vm.routes.collectAsState()
    val campaigns by vm.campaigns.collectAsState()
    val orders by vm.orders.collectAsState()
    val dealers by vm.dealers.collectAsState()
    var tab by remember { mutableStateOf<Int?>(startTab) }
    var crmDivision by remember { mutableStateOf<String?>(null) }
    var profileFor by remember { mutableStateOf<String?>(null) }

    val subItems = listOf(
        SubModuleItem("retailerList", "Retailer List", "🏪", 0xFFFF7A45, 0xFFE0521E, Icons.Filled.Store),
        SubModuleItem("dealerList", "Dealer List", "🏢", 0xFFB45CFF, 0xFF7A2EE0, Icons.Filled.Business),
        SubModuleItem("route", "Route Audit", "🗺️", 0xFF00C2E0, 0xFF0093B8, Icons.Filled.Route),
        SubModuleItem("engage", "Engagement Hub", "📣", 0xFFFF7A9C, 0xFFE0416A, Icons.Filled.Campaign),
        SubModuleItem("leads", "Leads", "🎯", 0xFF4E9CFF, 0xFF2E6FE0, Icons.Filled.GpsFixed),
        SubModuleItem("opportunities", "Opportunities", "💼", 0xFF3DDC97, 0xFF1FA972, Icons.Filled.BusinessCenter),
        SubModuleItem("comms", "Communication Log", "📞", 0xFFFFB020, 0xFFE08A00, Icons.Filled.Call),
        SubModuleItem("performance", "Performance", "📊", 0xFF9C6EFF, 0xFF6E3EDB, Icons.Filled.BarChart),
        // v113-77 — "Customer Complaints" tile removed: dealer complaints live in DMS →
        // Complain now (Decision 1: everything about a dealer inside DMS). Tab index 8 is
        // kept in the dispatch below as a redirect so existing deep links don't misfire.
        SubModuleItem("liveTracking", "Live Tracking", "🛰️", 0xFF00E0A0, 0xFF00A878, Icons.Filled.Satellite),
    )

    val retailersForMini by MockRepository.retailers.collectAsState()
    val visitsForMini by MockRepository.visitLogs.collectAsState()
    val todayForMini = java.time.LocalDate.now()
    val visitsToday = visitsForMini.count { it.checkInAt.toLocalDate() == todayForMini }
    val retailersCoveredToday = visitsForMini.filter { it.checkInAt.toLocalDate() == todayForMini }.map { it.partyId }.distinct().size

    Column(Modifier.fillMaxSize()) {
        if (startTab == null) {
        com.abm.erp.core.ModuleWorkspaceHeader("Geo CRM Workspace", "🗺️", 0xFF00C2E0, 0xFF0093B8, iconVector = Icons.Filled.Map, miniDashboard = {
            com.abm.erp.core.ModuleStat("Retailers", "${retailersForMini.size}", TextPrimary)
            com.abm.erp.core.ModuleStat("Dealers", "${dealers.size}", TextPrimary)
            com.abm.erp.core.ModuleStat("Visits Today", "$visitsToday", if (visitsToday > 0) SuccessGreen else WarningAmber)
            com.abm.erp.core.ModuleStat("Covered", "$retailersCoveredToday", TextPrimary)
            com.abm.erp.core.ModuleStat("Campaigns", "${campaigns.size}", TextPrimary)
        }, quickActions = {
            AssistChip(onClick = { tab = 2 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.Route, null, Modifier.size(16.dp)) }, label = { Text("Route Audit") })
            AssistChip(onClick = { tab = 4 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.GpsFixed, null, Modifier.size(16.dp)) }, label = { Text("Leads") })
            AssistChip(onClick = { tab = 9 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.Satellite, null, Modifier.size(16.dp)) }, label = { Text("Live Tracking") })
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("VisitLog", "Retailer", "Dealer", "Lead", "Opportunity"))
        })
        } else {
            val taskKey = when (tab) { 0 -> "route"; 1 -> "engage"; 2 -> "retailerList"; 3 -> "dealerList"; 4 -> "leads"; 5 -> "opportunities"; 7 -> "performance"; 8 -> "complaints"; 9 -> "liveTracking"; else -> "comms" }
            val taskTitle = subItems.firstOrNull { it.key == taskKey }?.label ?: "CRM"
            com.abm.erp.core.TaskHeader(taskTitle, 0xFF00C2E0, 0xFF0093B8, onBack = onBack, iconVector = Icons.Filled.Map)
        }
        Column(Modifier.fillMaxSize().padding(16.dp)) {

        if (tab == null) {
            SubModuleGrid(subItems) { key -> tab = when (key) { "retailerList" -> 2; "dealerList" -> 3; "route" -> 0; "engage" -> 1; "leads" -> 4; "opportunities" -> 5; "performance" -> 7; "complaints" -> 8; "liveTracking" -> 9; else -> 6 }; crmDivision = null }
        } else if (tab == 0) {
            if (startTab == null) if (startTab == null) BackToSubMenuLink(onClick = { tab = null }); RouteAuditTab(routes, vm)
        } else if (tab == 1) {
            if (startTab == null) BackToSubMenuLink(onClick = { tab = null }); EngagementHubTab(campaigns, vm)
        } else if (tab == 2 || tab == 3) {
            // Retailer/Dealer List — বিভাগ আগে বেছে নিতে হবে, একসাথে সব
            // দেখালে Chairman প্যানেলেরও মাথা ঘুরে যাবে (user-এর নিজের ভাষায়)
            if (crmDivision == null) {
                if (startTab == null) BackToSubMenuLink(onClick = { tab = null })
                Text(if (tab == 2) "Retailer List — বিভাগ বেছে নিন" else "Dealer List — বিভাগ বেছে নিন", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                com.abm.erp.data.DIVISION_DISTRICTS.keys.chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                        row.forEach { div ->
                            OutlinedButton(onClick = { crmDivision = div }, modifier = Modifier.weight(1f)) { Text(div, style = MaterialTheme.typography.labelSmall) }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            } else if (profileFor != null) {
                CrmProfileDetail(tab = tab, profileFor = profileFor!!, orders = orders, dealers = dealers, onBack = { profileFor = null })
            } else {
                BackToSubMenuLink(onClick = { crmDivision = null })
                Text("$crmDivision — ${if (tab == 2) "Retailer List" else "Dealer List"}", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                if (tab == 2) {
                    val names = orders.filter { it.channel == "retail" && it.zone == crmDivision }.map { it.retailerName }.distinct()
                    if (names.isEmpty()) Text("এই এলাকায় এখনো কোনো এন্ট্রি নেই।", color = TextSecondary)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(names) { name ->
                            GlassCard(modifier = Modifier.fillMaxWidth().clickable { profileFor = name }) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(30.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Brush.linearGradient(listOf(Color(0xFFFF5E9C), Color(0xFFC2185B)))), contentAlignment = Alignment.Center) {
                                            Text(name.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                        Spacer(Modifier.width(8.dp))
                                        Text(name, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    }
                                    Text("৳${orders.filter { it.retailerName == name }.sumOf { it.amount }.toInt()}", color = SuccessGreen)
                                }
                            }
                        }
                    }
                } else {
                    val myDealers = dealers.filter { it.zone == crmDivision }
                    if (myDealers.isEmpty()) Text("এই এলাকায় কোনো ডিলার নেই।", color = TextSecondary)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(myDealers) { d ->
                            GlassCard(modifier = Modifier.fillMaxWidth().clickable { profileFor = d.id }) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.size(30.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Brush.linearGradient(listOf(Color(0xFFFF5E9C), Color(0xFFC2185B)))), contentAlignment = Alignment.Center) {
                                            Text(d.name.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                        Spacer(Modifier.width(8.dp))
                                        Text(d.name, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    }
                                    Text("Due ৳${d.dueBalance.toInt()}", color = DangerRed)
                                }
                            }
                        }
                    }
                }
            }
        } else if (tab == 4) {
            if (startTab == null) BackToSubMenuLink(onClick = { tab = null }); LeadsTab(vm)
        } else if (tab == 5) {
            if (startTab == null) BackToSubMenuLink(onClick = { tab = null }); OpportunitiesTab(vm)
        } else if (tab == 6) {
            if (startTab == null) BackToSubMenuLink(onClick = { tab = null }); CommunicationLogTab(vm)
        } else if (tab == 7) {
            if (startTab == null) BackToSubMenuLink(onClick = { tab = null }); PerformanceTab(dealers)
        } else if (tab == 8) {
            // v113-77 — dealer complaints moved to DMS -> Complain (one home per feature).
            // This tab points there instead of rendering a second copy; the tab index is
            // kept so nothing that deep-links to CRM tab 8 breaks before the old suite
            // navigation is finally retired.
            if (startTab == null) BackToSubMenuLink(onClick = { tab = null })
            Text("Dealer Complaints এখন DMS মডিউলের \"Complain\" অংশে।", color = TextSecondary)
        } else if (tab == 9) {
            if (startTab == null) BackToSubMenuLink(onClick = { tab = null }); LiveTrackingTab()
        }
    }
    }
}

/** Full overlapping-header detail dashboard — matches HR's Attendance detail pattern, now brought to CRM. */
@Composable
private fun CrmProfileDetail(tab: Int?, profileFor: String, orders: List<com.abm.erp.data.RetailOrder>, dealers: List<com.abm.erp.data.Dealer>, onBack: () -> Unit) {
    val roseStart = Color(0xFFFF5E9C)
    val roseEnd = Color(0xFFC2185B)
    val isDealer = tab != 2
    val dealer = dealers.firstOrNull { it.id == profileFor }
    val displayName = dealer?.name ?: profileFor
    val myOrders = orders.filter { it.retailerName == profileFor }
    val total = myOrders.sumOf { it.amount }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(roseStart, roseEnd)), androidx.compose.foundation.shape.RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)).padding(18.dp)) {
            Column {
                Text("←", color = Color.White, fontSize = 16.sp, modifier = Modifier.clickable(onClick = onBack))
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color.White.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                        Text(displayName.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(displayName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(if (isDealer) "Dealer" else "Retailer", color = Color(0xFFFFE0EC), fontSize = 11.sp)
                    }
                }
            }
        }
        LazyColumn(Modifier.fillMaxSize().offset(y = (-16).dp), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    if (isDealer && dealer != null) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                Text("৳${dealer.dueBalance.toInt()}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = DangerRed)
                                Text("Due balance", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                Text("${dealer.stockUnits}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = roseStart)
                                Text("Units in stock", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                    } else {
                        Text("৳${total.toInt()}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = roseStart, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth())
                        Text("Total value · ${myOrders.size} orders", style = MaterialTheme.typography.labelSmall, color = TextSecondary, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            if (!isDealer) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text("Product mix", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Spacer(Modifier.height(8.dp))
                        val productTotals = remember(myOrders) {
                            val totals = linkedMapOf<String, Int>()
                            myOrders.forEach { o ->
                                o.items.split(",").forEach { part ->
                                    val m = Regex("""^(.+?)\s*x(\d+)""", RegexOption.IGNORE_CASE).find(part.trim())
                                    if (m != null) {
                                        val (pname, qty) = m.destructured
                                        totals[pname.trim()] = (totals[pname.trim()] ?: 0) + qty.toInt()
                                    }
                                }
                            }
                            totals
                        }
                        val totalQty = productTotals.values.sum().coerceAtLeast(1)
                        val ringColors = listOf(roseStart, roseEnd, Color(0xFFFFB020), Color(0xFF3DDC97), Color(0xFF00B4B4))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.foundation.Canvas(modifier = Modifier.size(64.dp)) {
                                var startAngle = -90f
                                if (productTotals.isEmpty()) {
                                    drawArc(color = Color(0xFFE5E9F0), startAngle = 0f, sweepAngle = 360f, useCenter = true)
                                } else {
                                    productTotals.entries.forEachIndexed { i, (_, qty) ->
                                        val sweep = (qty.toFloat() / totalQty) * 360f
                                        drawArc(color = ringColors[i % ringColors.size], startAngle = startAngle, sweepAngle = sweep, useCenter = true)
                                        startAngle += sweep
                                    }
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                if (productTotals.isEmpty()) Text("এখনো কোনো product breakdown নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                productTotals.entries.forEachIndexed { i, (pname, qty) ->
                                    val pct = (qty.toFloat() / totalQty) * 100
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("● $pname", style = MaterialTheme.typography.labelSmall, color = ringColors[i % ringColors.size])
                                        Text("${pct.toInt()}%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = TextSecondary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Order history", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    if (myOrders.isEmpty()) Text("এখনো কোনো অর্ডার নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    myOrders.forEach { o ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(o.items, style = MaterialTheme.typography.labelSmall, color = TextPrimary)
                            Text("৳${o.amount.toInt()}", style = MaterialTheme.typography.labelSmall, color = SuccessGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveGpsTrackingCard(vm: GeoCrmViewModel) {
    val context = LocalContext.current
    val activity = context as? android.app.Activity
    var tracking by remember { mutableStateOf(false) }
    var pingCount by remember { mutableStateOf(0) }
    var lastSpoofWarning by remember { mutableStateOf(false) }
    var trackingError by remember { mutableStateOf<String?>(null) }

    fun hasFineLocationPermission() =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            tracking = true; trackingError = null
        } else {
            // shouldShowRequestPermissionRationale is false both before the first-ever
            // request AND after a permanent ("Don't ask again") denial — since this
            // callback only fires after a request just happened, false here means
            // permanent denial, which the system permission dialog can't fix a second
            // time; the person has to go to phone Settings directly.
            val permanentlyDenied = activity != null &&
                !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.ACCESS_FINE_LOCATION)
            trackingError = if (permanentlyDenied)
                "Location permission is permanently denied. Open phone Settings → Apps → ABM ERP → Permissions → Location, allow it, then come back and tap Start."
            else
                "Location permission was denied — tap Start again and allow it to record GPS checkpoints."
        }
    }

    if (tracking && hasFineLocationPermission()) {
        LaunchedEffect(Unit) {
            try {
                LocationTracker(context).liveLocation().collect { fix ->
                    vm.recordGpsPing(vm.currentUser.id, vm.currentUser.name, fix.lat, fix.lng, fix.spoofed)
                    pingCount += 1
                    lastSpoofWarning = fix.spoofed
                }
            } catch (e: Exception) {
                trackingError = e.message ?: "GPS tracking stopped unexpectedly."
                tracking = false
            }
        }
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Live GPS tracking", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Text(
            if (tracking) "Tracking active — $pingCount checkpoint(s) recorded this session"
            else "Tap start to record real device location as breadcrumbs for today's route",
            style = MaterialTheme.typography.bodySmall, color = TextSecondary,
        )
        if (tracking && lastSpoofWarning) {
            Text("⚠ Last fix flagged as a mock/spoofed location", color = DangerRed, style = MaterialTheme.typography.labelSmall)
        }
        trackingError?.let {
            Spacer(Modifier.height(6.dp))
            Text("⚠ $it", color = DangerRed, style = MaterialTheme.typography.labelSmall)
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                trackingError = null
                if (tracking) {
                    tracking = false
                } else if (hasFineLocationPermission()) {
                    tracking = true
                } else {
                    permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = if (tracking) DangerRed else SuccessGreen),
        ) {
            Text(if (tracking) "Stop tracking" else "Start tracking")
        }
    }
}

@Composable
private fun PresenceHeartbeatCard() {
    val context = LocalContext.current
    var backgroundGranted by remember { mutableStateOf(com.abm.erp.presence.PresenceHeartbeatService.isBackgroundLocationGranted(context)) }
    var heartbeatOn by remember { mutableStateOf(false) }
    var heartbeatError by remember { mutableStateOf<String?>(null) }

    // Android 13+ আলাদা করে notification permission চায়, নাহলে persistent notification-টাই দেখা যাবে না
    val notifPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) heartbeatError = "Notification permission ছাড়া background tracking-এর status দেখা যাবে না, কিন্তু tracking তবুও চলবে।"
    }
    // ধাপ ১: foreground location (যদি আগে থেকে না থাকে)
    val foregroundPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) { heartbeatError = "Location permission ছাড়া এটা চালু করা যাবে না।"; return@rememberLauncherForActivityResult }
        backgroundGranted = com.abm.erp.presence.PresenceHeartbeatService.isBackgroundLocationGranted(context)
        if (!backgroundGranted) heartbeatError = "এখন phone Settings → Apps → ABM ERP → Permissions → Location-এ গিয়ে \"Allow all the time\" বেছে নিন, তারপর আবার চাপুন।"
    }
    // ধাপ ২: background location — Android 10+ এ এটা আলাদা, Settings থেকেই দিতে হয়, in-app dialog দিয়ে না
    val backgroundPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        backgroundGranted = granted
        if (!granted) heartbeatError = "Background location অনুমতি ছাড়া heartbeat চলবে না — শুধু app খোলা অবস্থায় GPS Track কাজ করবে।"
    }

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Live Presence Heartbeat", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Text(
            if (heartbeatOn) "চালু আছে — app বন্ধ থাকলেও প্রতি ৩০ মিনিটে একবার GPS চেক হবে, attendance-এর জন্য।"
            else "শুধু সকালে একবার লগইনে GPS চেক যথেষ্ট না — এটা চালু করলে সারাদিন track হবে, সত্যিই এলাকায় আছেন কিনা যাচাই হবে।",
            style = MaterialTheme.typography.bodySmall, color = TextSecondary,
        )
        heartbeatError?.let {
            Spacer(Modifier.height(6.dp))
            Text("⚠ $it", color = DangerRed, style = MaterialTheme.typography.labelSmall)
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                heartbeatError = null
                if (heartbeatOn) {
                    com.abm.erp.presence.PresenceHeartbeatService.stop(context)
                    heartbeatOn = false
                    return@Button
                }
                val hasFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (!hasFine) { foregroundPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION); return@Button }
                if (!backgroundGranted) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        backgroundPermissionLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                    }
                    return@Button
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                com.abm.erp.presence.PresenceHeartbeatService.start(context)
                heartbeatOn = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = if (heartbeatOn) DangerRed else SuccessGreen),
        ) {
            Text(if (heartbeatOn) "Stop heartbeat" else "Start heartbeat")
        }
    }
}

@Composable
private fun RouteAuditTab(routes: List<com.abm.erp.data.FieldEmployeeRoute>, vm: GeoCrmViewModel) {
    // v113-204 — same crash class just fixed in PayrollScreen.kt (see that
    // file's note for the full trace): EMPLOYEE_DIRECTORY is an orphaned
    // synthetic mock list using old pre-real-seeding ids ("CHAIR-1" etc.),
    // never matching a real logged-in user's actual employeeId. `.first`
    // threw for every real user; `firstOrNull` + empty fallback is accurate
    // here too (no synthetic cascade to show for an id outside this list).
    val myCascade = remember {
        val me = com.abm.erp.data.EMPLOYEE_DIRECTORY.firstOrNull { it.id == vm.currentUser.employeeId }
        if (me != null) com.abm.erp.data.findMyCascade(me).filter { it.role.name in setOf("SR", "TSM", "ASM") } else emptyList()
    }
    val activeNow = myCascade.filter { it.id.hashCode() % 3 != 2 }
    val marketGroups = activeNow.groupBy { it.geo.district ?: it.geo.division ?: "N/A" }.mapValues { it.value.size }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            val salesRoutesNow by vm.salesRoutes.collectAsState()
            if (salesRoutesNow.isNotEmpty()) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Route Compliance (today)", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    salesRoutesNow.forEach { route ->
                        val compliance = (vm.routeComplianceToday(route) * 100).toInt()
                        val missed = vm.missedOutletsToday(route)
                        Text("${route.name}: $compliance% covered" + if (missed.isNotEmpty()) " · ${missed.size} missed" else "", style = MaterialTheme.typography.bodySmall, color = if (compliance < 70) WarningAmber else SuccessGreen)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("🟢 এখন কাজ করছেন — ${vm.currentUser.zone}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("${activeNow.size}", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                    Spacer(Modifier.width(6.dp))
                    Text("/ ${myCascade.size} জন", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                Spacer(Modifier.height(8.dp))
                marketGroups.forEach { (market, count) ->
                    Text("📍 $market — $count জন সক্রিয়", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                }
            }
        }
        item { LiveGpsTrackingCard(vm) }
        item { PresenceHeartbeatCard() }
        items(routes) { r ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(r.employeeName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text("${r.date} · ${r.breadcrumbs.size} GPS checkpoints", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(10.dp))
                BreadcrumbTrace(r.breadcrumbs.map { it.lat to it.lng })
                Spacer(Modifier.height(6.dp))
                r.breadcrumbs.forEach { p ->
                    Text(
                        "• ${p.timestamp.toLocalTime()} — (${"%.3f".format(p.lat)}, ${"%.3f".format(p.lng)})" +
                            if (p.spoofed) "  ⚠ spoofed" else "",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (p.spoofed) DangerRed else TextSecondary,
                    )
                }
            }
        }
    }
}

/** Minimal breadcrumb trace renderer: normalizes lat/lng points into a canvas polyline. Swap for a real Maps SDK overlay in production. */
@Composable
private fun BreadcrumbTrace(points: List<Pair<Double, Double>>) {
    if (points.size < 2) return
    val lats = points.map { it.first }
    val lngs = points.map { it.second }
    val minLat = lats.min(); val maxLat = lats.max()
    val minLng = lngs.min(); val maxLng = lngs.max()

    Canvas(modifier = Modifier.fillMaxWidth().height(100.dp)) {
        val path = points.map { (lat, lng) ->
            val nx = if (maxLng == minLng) 0.5f else ((lng - minLng) / (maxLng - minLng)).toFloat()
            val ny = if (maxLat == minLat) 0.5f else 1f - ((lat - minLat) / (maxLat - minLat)).toFloat()
            Offset(nx * size.width, ny * size.height)
        }
        for (i in 0 until path.size - 1) {
            drawLine(ElectricCyan, path[i], path[i + 1], strokeWidth = 4f)
        }
        path.forEach { drawCircle(DeepIndigo, radius = 6f, center = it) }
    }
}

@Composable
private fun EngagementHubTab(campaigns: List<com.abm.erp.data.EngagementCampaign>, vm: GeoCrmViewModel) {
    var channel by remember { mutableStateOf(CampaignChannel.SMS) }
    var message by remember { mutableStateOf("") }
    var zone by remember { mutableStateOf("Barisal") }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Broadcast promotion / discount alert", style = MaterialTheme.typography.titleMedium)
                var broadcastError by remember { mutableStateOf<String?>(null) }
                broadcastError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                Spacer(Modifier.height(10.dp))
                DualControlDropdown(
                    "Channel",
                    DualControlValue(channel.name, FieldSource.HUMAN),
                    CampaignChannel.values().map { it.name },
                    onManualSelect = { channel = CampaignChannel.valueOf(it) }
                )
                Spacer(Modifier.height(10.dp))
                DualControlTextField(
                    "Message (Bengali robo-call script / SMS / email body)",
                    DualControlValue(message, FieldSource.HUMAN), { message = it }
                )
                Spacer(Modifier.height(10.dp))
                DualControlTextField("Target zone", DualControlValue(zone, FieldSource.HUMAN), { zone = it })
                Spacer(Modifier.height(14.dp))
                ManualSubmitBar("Broadcast now") {
                    if (message.isNotBlank()) {
                        vm.broadcastCampaign(channel, message, zone, onRejected = { e -> broadcastError = e })
                        message = ""
                    }
                }
            }
        }
        item { Text("Sent campaigns", style = MaterialTheme.typography.titleMedium) }
        items(campaigns.reversed()) { c ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("${c.channel.name} → ${c.targetZone}", fontWeight = FontWeight.SemiBold, color = ElectricCyan)
                Text(c.message, style = MaterialTheme.typography.bodyMedium)
                Text("Delivered to ${c.sentCount} shops", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun LeadsTab(vm: GeoCrmViewModel) {
    val leads by vm.leads.collectAsState()
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "Name,Phone,Source,Status\n"
                    val rows = leads.joinToString("\n") { l -> com.abm.erp.core.toCsvRow(l.name, l.phone, l.source, l.status) }
                    val file = java.io.File(context.getExternalFilesDir(null), "leads_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Leads (${leads.size})\n" + leads.take(20).joinToString("\n") { "${it.name} — ${it.source} (${it.status})" }
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                    try { context.startActivity(android.content.Intent.createChooser(intent, "Leads")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                },
            )
        }
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Lead") }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(leads) { l ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(l.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${l.source} · ${l.phone}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Row {
                            com.abm.erp.core.StatusPill(l.status.name)
                            com.abm.erp.core.UniversalActionMenu(
                                moduleReference = "Lead", entityId = l.id, entityLabel = l.name,
                                shareText = "Lead: ${l.name}\nSource: ${l.source}\nPhone: ${l.phone}\nStatus: ${l.status}",
                                onDuplicate = { onError -> vm.duplicateLead(l.id, onRejected = onError) },
                                csvHeader = "Name,Phone,Source,Status",
                                csvRow = com.abm.erp.core.toCsvRow(l.name, l.phone, l.source, l.status),
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        com.abm.erp.data.LeadStatus.values().forEach { st ->
                            FilterChip(selected = l.status == st, onClick = { vm.updateLeadStatus(l.id, st) }, label = { Text(st.name, style = MaterialTheme.typography.labelSmall) })
                        }
                    }
                }
            }
            if (leads.isEmpty()) item { Text("এখনো কোনো Lead নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var name by remember { mutableStateOf("") }
                var phone by remember { mutableStateOf("") }
                var source by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp)) {
                    Text("New Lead", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = source, onValueChange = { source = it }, label = { Text("Source (market visit, referral...)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    var leadError by remember { mutableStateOf<String?>(null) }
                    leadError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Button(onClick = { if (vm.createLead(name, phone, source, onRejected = { r -> leadError = r }) != null) showNew = false }, enabled = name.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Create Lead") }
                }
            }
        }
    }
}

@Composable
private fun OpportunitiesTab(vm: GeoCrmViewModel) {
    val opportunities by vm.opportunities.collectAsState()
    val leads by vm.leads.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    val stages = listOf("PROSPECTING", "NEGOTIATION", "WON", "LOST")

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Opportunity") }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(opportunities) { o ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${o.title} — ৳${"%,.0f".format(o.estimatedValue)}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Opportunity", entityId = o.id, entityLabel = o.title,
                            shareText = "Opportunity: ${o.title}\nValue: ৳${o.estimatedValue}\nStage: ${o.stage}",
                            csvHeader = "Title,Value,Stage",
                            csvRow = com.abm.erp.core.toCsvRow(o.title, o.estimatedValue, o.stage),
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        stages.forEach { s -> FilterChip(selected = o.stage == s, onClick = { vm.updateOpportunityStage(o.id, s) }, label = { Text(s, style = MaterialTheme.typography.labelSmall) }) }
                    }
                }
            }
            if (opportunities.isEmpty()) item { Text("এখনো কোনো Opportunity নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var title by remember { mutableStateOf("") }
                var valueText by remember { mutableStateOf("") }
                var selectedLead by remember { mutableStateOf<com.abm.erp.data.Lead?>(null) }
                var expanded by remember { mutableStateOf(false) }
                Column(Modifier.padding(16.dp)) {
                    Text("New Opportunity", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = valueText, onValueChange = { valueText = it }, label = { Text("Estimated value (৳)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedLead?.name ?: "Link a lead (optional)") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            leads.forEach { l -> DropdownMenuItem(text = { Text(l.name) }, onClick = { selectedLead = l; expanded = false }) }
                        }
                    }
                    var oppError by remember { mutableStateOf<String?>(null) }
                    oppError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { if (vm.createOpportunity(selectedLead?.id, title, valueText.toDoubleOrNull() ?: 0.0, onRejected = { e -> oppError = e }) != null) showNew = false },
                        enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth(),
                    ) { Text("Create Opportunity") }
                }
            }
        }
    }
}

@Composable
private fun CommunicationLogTab(vm: GeoCrmViewModel) {
    var sub by remember { mutableStateOf(0) }
    val calls by vm.callLogs.collectAsState()
    val meetings by vm.meetingLogs.collectAsState()
    val followUps by vm.followUps.collectAsState()
    var showNewCall by remember { mutableStateOf(false) }
    var showNewMeeting by remember { mutableStateOf(false) }
    var showNewFollowUp by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = sub) {
            Tab(selected = sub == 0, onClick = { sub = 0 }, text = { Text("Calls") })
            Tab(selected = sub == 1, onClick = { sub = 1 }, text = { Text("Meetings") })
            Tab(selected = sub == 2, onClick = { sub = 2 }, text = { Text("Follow-ups") })
        }
        Spacer(Modifier.height(10.dp))
        when (sub) {
            0 -> {
                Button(onClick = { showNewCall = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Log Call") }
                Spacer(Modifier.height(8.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(calls) { c ->
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column { Text("${c.contactName} — ${c.durationMinutes} min", fontWeight = FontWeight.SemiBold); Text(c.notes, style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                                com.abm.erp.core.UniversalActionMenu(
                                    moduleReference = "CallLog", entityId = c.id, entityLabel = c.contactName,
                                    shareText = "Call: ${c.contactName} (${c.phone})\nDuration: ${c.durationMinutes} min\nNotes: ${c.notes}",
                                    csvHeader = "Contact,Phone,DurationMin,Notes", csvRow = com.abm.erp.core.toCsvRow(c.contactName, c.phone, c.durationMinutes, c.notes),
                                )
                            }
                        }
                    }
                    if (calls.isEmpty()) item { Text("এখনো কোনো call log নেই।", color = TextSecondary) }
                }
            }
            1 -> {
                Button(onClick = { showNewMeeting = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Log Meeting") }
                Spacer(Modifier.height(8.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(meetings) { m ->
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column { Text(m.title, fontWeight = FontWeight.SemiBold); Text("Attendees: ${m.attendees}", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                                com.abm.erp.core.UniversalActionMenu(
                                    moduleReference = "MeetingLog", entityId = m.id, entityLabel = m.title,
                                    shareText = "Meeting: ${m.title}\nAttendees: ${m.attendees}\nNotes: ${m.notes}",
                                    csvHeader = "Title,Attendees,Notes", csvRow = com.abm.erp.core.toCsvRow(m.title, m.attendees, m.notes),
                                )
                            }
                        }
                    }
                    if (meetings.isEmpty()) item { Text("এখনো কোনো meeting log নেই।", color = TextSecondary) }
                }
            }
            else -> {
                val overdueCount = followUps.count { !it.done && it.dueDate.isBefore(java.time.LocalDateTime.now()) }
                if (overdueCount > 0) {
                    GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), borderColor = DangerRed.copy(alpha = 0.7f)) {
                        Text("⚠ $overdueCount missed follow-up${if (overdueCount > 1) "s" else ""} — এখনই attend করুন", color = DangerRed, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    }
                }
                Button(onClick = { showNewFollowUp = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add Follow-up") }
                Spacer(Modifier.height(8.dp))
                val upcoming = remember(followUps) {
                    val today = java.time.LocalDate.now()
                    followUps.filter { !it.done && !it.dueDate.toLocalDate().isBefore(today) && it.dueDate.toLocalDate().isBefore(today.plusDays(7)) }
                        .groupBy { it.dueDate.toLocalDate() }.toSortedMap()
                }
                if (upcoming.isNotEmpty()) {
                    GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                        Text("Visit Calendar (পরবর্তী ৭ দিন)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        upcoming.forEach { (date, items) ->
                            Text(date.toString(), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelMedium, color = Sky)
                            items.forEach { Text("  • ${it.note}", style = MaterialTheme.typography.bodySmall) }
                            Spacer(Modifier.height(4.dp))
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(followUps) { f ->
                        val isOverdue = !f.done && f.dueDate.isBefore(java.time.LocalDateTime.now())
                        GlassCard(modifier = Modifier.fillMaxWidth(), borderColor = if (isOverdue) DangerRed.copy(alpha = 0.7f) else GlassBorder) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text(f.note, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        (if (isOverdue) "⚠ Overdue — " else "Due: ") + f.dueDate.toLocalDate().toString(),
                                        style = MaterialTheme.typography.labelSmall, color = if (isOverdue) DangerRed else TextSecondary,
                                    )
                                }
                                Row {
                                    Checkbox(checked = f.done, onCheckedChange = { vm.setFollowUpDone(f.id, it) })
                                    com.abm.erp.core.UniversalActionMenu(
                                        moduleReference = "FollowUp", entityId = f.id, entityLabel = f.note,
                                        shareText = "Follow-up: ${f.note}\nDue: ${f.dueDate.toLocalDate()}\nDone: ${f.done}",
                                        csvHeader = "Note,DueDate,Done", csvRow = com.abm.erp.core.toCsvRow(f.note, f.dueDate.toLocalDate(), f.done),
                                    )
                                }
                            }
                        }
                    }
                    if (followUps.isEmpty()) item { Text("এখনো কোনো follow-up নেই।", color = TextSecondary) }
                }
            }
        }
    }

    if (showNewCall) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNewCall = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var contactName by remember { mutableStateOf("") }
                var phone by remember { mutableStateOf("") }
                var minutesText by remember { mutableStateOf("") }
                var notes by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp)) {
                    Text("Log Call", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = contactName, onValueChange = { contactName = it }, label = { Text("Contact name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = minutesText, onValueChange = { minutesText = it }, label = { Text("Duration (minutes)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { vm.logCall(null, contactName, phone, minutesText.toIntOrNull() ?: 0, notes); showNewCall = false }, enabled = contactName.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Save Call Log") }
                }
            }
        }
    }
    if (showNewMeeting) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNewMeeting = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var title by remember { mutableStateOf("") }
                var attendees by remember { mutableStateOf("") }
                var notes by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp)) {
                    Text("Log Meeting", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = attendees, onValueChange = { attendees = it }, label = { Text("Attendees") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { vm.logMeeting(title, attendees, notes); showNewMeeting = false }, enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Save Meeting Log") }
                }
            }
        }
    }
    if (showNewFollowUp) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNewFollowUp = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var note by remember { mutableStateOf("") }
                var daysText by remember { mutableStateOf("3") }
                Column(Modifier.padding(16.dp)) {
                    Text("Add Follow-up", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Note") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = daysText, onValueChange = { daysText = it }, label = { Text("Due in how many days") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { vm.createFollowUp(null, note, daysText.toLongOrNull() ?: 3); showNewFollowUp = false }, enabled = note.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Save Follow-up") }
                }
            }
        }
    }
}

/**
 * CRM Excellence — Customer Ranking, Territory/Route Performance, Officer
 * Performance. All figures come from already-loaded real repository data
 * (Dealer.salesLast90Days/dueBalance, VisitLog, PartyCollection) — nothing
 * fabricated. Territory/Route grouping uses Dealer.zone (the real field
 * already used elsewhere for area filters) since a dedicated route
 * assignment per dealer isn't tracked separately from zone in this model.
 */
@Composable
private fun PerformanceTab(dealers: List<com.abm.erp.data.Dealer>) {
    val visits by MockRepository.visitLogs.collectAsState()
    val collections by MockRepository.partyCollections.collectAsState()

    val ranked = remember(dealers) {
        dealers.filter { !it.isDeleted }.sortedByDescending { it.salesLast90Days }.take(10)
    }
    val byZone = remember(dealers) {
        dealers.filter { !it.isDeleted }.groupBy { it.zone }
            .mapValues { (_, list) -> list.sumOf { it.salesLast90Days } to list.sumOf { it.dueBalance } }
            .entries.sortedByDescending { it.value.first }
    }
    val byOfficer = remember(visits, collections) {
        val visitCounts = visits.groupingBy { it.employeeName }.eachCount()
        val collectionSums = collections.groupBy { it.collectedBy }.mapValues { (_, list) -> list.sumOf { it.amount } }
        (visitCounts.keys + collectionSums.keys).distinct().map { name ->
            Triple(name, visitCounts[name] ?: 0, collectionSums[name] ?: 0.0)
        }.sortedByDescending { it.third }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Performance", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Customer Ranking (90-day sales)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (ranked.isEmpty()) {
                Text("এখনো কোনো dealer sales data নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            } else {
                ranked.forEachIndexed { i, d ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${i + 1}. ${d.name}", style = MaterialTheme.typography.bodySmall)
                        Text("৳${"%,.0f".format(d.salesLast90Days)}", style = MaterialTheme.typography.bodySmall, color = ElectricCyan)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Territory/Route Performance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (byZone.isEmpty()) {
                Text("এখনো কোনো territory data নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            } else {
                byZone.forEach { (zone, pair) ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(zone, style = MaterialTheme.typography.bodySmall)
                        Text("৳${"%,.0f".format(pair.first)} · Due ৳${"%,.0f".format(pair.second)}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Officer Performance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (byOfficer.isEmpty()) {
                Text("এখনো কোনো visit/collection data নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            } else {
                byOfficer.forEach { (name, visitCount, collectionSum) ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(name, style = MaterialTheme.typography.bodySmall)
                        Text("$visitCount visits · ৳${"%,.0f".format(collectionSum)} collected", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                }
            }
        }
    }
}

/**
 * v86, Module 15 — Customer Complaint workflow UI. Real create/assign/
 * resolve/reject actions against MockRepository (no placeholder buttons),
 * with search+status filter and empty state.
 */
@Composable
fun LiveTrackingTab(filterEmployeeIds: Set<String>? = null) {
    LaunchedEffect(Unit) { MockRepository.startLiveLocationListener() }
    val liveLocations by MockRepository.liveLocations.collectAsState()
    val visible = remember(liveLocations, filterEmployeeIds) {
        if (filterEmployeeIds == null) liveLocations else liveLocations.filter { it.employeeId in filterEmployeeIds }
    }
    Column(Modifier.fillMaxSize().padding(top = 8.dp)) {
        Text("Live Tracking", style = MaterialTheme.typography.titleMedium)
        Text(
            "যাদের Live Location চালু আছে তাদের বর্তমান অবস্থান — প্রতি ২০ সেকেন্ডে আপডেট হয়।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(8.dp))
        if (visible.isEmpty()) {
            Text("কেউ এখন Live Tracking চালু করেনি।", style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.padding(top = 20.dp))
        } else {
            LazyColumn {
                items(visible.sortedBy { it.employeeName }) { loc ->
                    Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), tonalElevation = 2.dp) {
                        Column(Modifier.padding(10.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text(loc.employeeName, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    if (loc.isStale) "🔴 ${loc.staleSeconds}s আগে (বন্ধ হতে পারে)" else "🟢 লাইভ",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (loc.isStale) DangerRed else SuccessGreen,
                                )
                            }
                            Text("Lat: ${"%.5f".format(loc.lat)}, Lng: ${"%.5f".format(loc.lng)}", style = MaterialTheme.typography.bodySmall)
                            loc.speedMetersPerSecond?.let { Text("গতি: ${"%.1f".format(it * 3.6)} km/h", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun CustomerComplaintsTab(dealers: List<com.abm.erp.data.Dealer>) {
    val complaints by MockRepository.customerComplaints.collectAsState()
    // Decision 4 (v113-73) — the "New Complaint" dealer chooser below is a *selection*
    // surface, the same class as the invoice picker, so it must be cascade-scoped: you
    // should not be able to file a complaint against a dealer outside your territory.
    // The `dealers` parameter is left untouched on purpose — it also feeds this tab's
    // counts/analytics, and changing those would be a business-number change nobody asked
    // for. Only the chooser is scoped.
    val selectableDealers = com.abm.erp.core.rememberVisibleDealers()
    var showNew by remember { mutableStateOf(false) }
    var statusFilter by remember { mutableStateOf<com.abm.erp.data.CustomerComplaintStatus?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    val filtered = remember(complaints, statusFilter, searchQuery) {
        complaints.filter { c ->
            // v113-77 fix — since v113-75, `customerComplaints` holds BOTH dealer and
            // retailer records (discriminated by partyType), because
            // createRetailerComplaint writes into this same collection. Without this
            // guard, RMS's retailer complaints would leak into DMS's dealer list —
            // caught during the pre-compile review, not by a build (this sandbox can't
            // run one). DEALER is the explicit default so pre-v113-75 records (which
            // have no partyType written) still match correctly.
            c.partyType == com.abm.erp.data.PartyType.DEALER &&
                (statusFilter == null || c.status == statusFilter) &&
                (searchQuery.isBlank() || c.dealerName.contains(searchQuery, ignoreCase = true) || c.complaintNo.contains(searchQuery, ignoreCase = true) || c.description.contains(searchQuery, ignoreCase = true))
        }
    }

    Column(Modifier.fillMaxSize()) {
        Text("Customer Complaints", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(10.dp))
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Complaint") }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = searchQuery, onValueChange = { searchQuery = it }, placeholder = { Text("Search dealer/complaint no/description…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            FilterChip(selected = statusFilter == null, onClick = { statusFilter = null }, label = { Text("All") })
            com.abm.erp.data.CustomerComplaintStatus.values().forEach { s ->
                FilterChip(selected = statusFilter == s, onClick = { statusFilter = s }, label = { Text(s.name) })
            }
        }
        Spacer(Modifier.height(10.dp))
        if (filtered.isEmpty()) {
            Text("এই ফিল্টারে কোনো complaint নেই।", color = TextSecondary, modifier = Modifier.padding(top = 16.dp))
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filtered, key = { it.id }) { c ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("${c.complaintNo} — ${c.dealerName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                Text(c.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                Text("${c.category} · ${c.priority}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                            Text(
                                c.status.name,
                                color = when (c.status) {
                                    com.abm.erp.data.CustomerComplaintStatus.RESOLVED, com.abm.erp.data.CustomerComplaintStatus.CLOSED -> SuccessGreen
                                    com.abm.erp.data.CustomerComplaintStatus.REJECTED -> DangerRed
                                    com.abm.erp.data.CustomerComplaintStatus.NEW -> WarningAmber
                                    else -> Sky
                                },
                                fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall,
                            )
                            com.abm.erp.core.UniversalActionMenu(
                                moduleReference = "CustomerComplaint", entityId = c.id, entityLabel = c.complaintNo,
                                shareText = "${c.complaintNo} — ${c.dealerName}\n${c.description}\n${c.category} · ${c.status}",
                                csvHeader = "ComplaintNo,Dealer,Category,Priority,Status", csvRow = com.abm.erp.core.toCsvRow(c.complaintNo, c.dealerName, c.category, c.priority, c.status),
                            )
                        }
                        if (c.assignedEmployeeName != null) {
                            Text("Assigned: ${c.assignedEmployeeName}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        if (c.resolutionNote != null) {
                            Text("Note: ${c.resolutionNote}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        if (c.status != com.abm.erp.data.CustomerComplaintStatus.RESOLVED && c.status != com.abm.erp.data.CustomerComplaintStatus.CLOSED && c.status != com.abm.erp.data.CustomerComplaintStatus.REJECTED) {
                            Spacer(Modifier.height(6.dp))
                            var showAssign by remember { mutableStateOf(false) }
                            var showResolve by remember { mutableStateOf(false) }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (c.status == com.abm.erp.data.CustomerComplaintStatus.NEW) {
                                    TextButton(onClick = { showAssign = true }) { Text("Assign") }
                                }
                                if (c.status == com.abm.erp.data.CustomerComplaintStatus.ASSIGNED) {
                                    TextButton(onClick = { MockRepository.setCustomerComplaintStatus(c.id, com.abm.erp.data.CustomerComplaintStatus.INVESTIGATING) }) { Text("Start Investigating") }
                                }
                                TextButton(onClick = { showResolve = true }) { Text("Resolve/Close") }
                                TextButton(onClick = { MockRepository.rejectCustomerComplaint(c.id, "Rejected by ${MockRepository.currentUser.name}") }) { Text("Reject", color = DangerRed) }
                            }
                            if (showAssign) {
                                var empName by remember { mutableStateOf("") }
                                Dialog(onDismissRequest = { showAssign = false }) {
                                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                        Column(Modifier.padding(16.dp)) {
                                            Text("Assign Complaint", style = MaterialTheme.typography.titleMedium)
                                            Spacer(Modifier.height(8.dp))
                                            OutlinedTextField(value = empName, onValueChange = { empName = it }, label = { Text("Employee name") }, modifier = Modifier.fillMaxWidth())
                                            var assignError by remember { mutableStateOf<String?>(null) }
                                            assignError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                            Spacer(Modifier.height(10.dp))
                                            Button(
                                                onClick = {
                                                    if (empName.isNotBlank()) {
                                                        val ok = MockRepository.assignCustomerComplaint(c.id, empName, empName, onRejected = { reason -> assignError = reason })
                                                        if (ok) showAssign = false
                                                    }
                                                },
                                                modifier = Modifier.fillMaxWidth(),
                                            ) { Text("Assign") }
                                        }
                                    }
                                }
                            }
                            if (showResolve) {
                                var note by remember { mutableStateOf("") }
                                var resolveError by remember { mutableStateOf<String?>(null) }
                                Dialog(onDismissRequest = { showResolve = false }) {
                                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                        Column(Modifier.padding(16.dp)) {
                                            Text("Resolve Complaint", style = MaterialTheme.typography.titleMedium)
                                            Spacer(Modifier.height(8.dp))
                                            OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Resolution note (required)") }, modifier = Modifier.fillMaxWidth())
                                            resolveError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                            Spacer(Modifier.height(10.dp))
                                            Button(
                                                onClick = {
                                                    val ok = MockRepository.resolveCustomerComplaint(c.id, note, onRejected = { reason -> resolveError = reason })
                                                    if (ok) showResolve = false
                                                },
                                                enabled = note.isNotBlank(), modifier = Modifier.fillMaxWidth(),
                                            ) { Text("Resolve") }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNew) {
        var selectedDealerId by remember { mutableStateOf<String?>(null) }
        var description by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("QUALITY") }
        Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
                    Text("New Complaint", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Dealer", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Column(Modifier.heightIn(max = 140.dp).verticalScroll(rememberScrollState())) {
                        if (selectableDealers.isEmpty()) {
                            Text("আপনার এলাকায় কোনো dealer নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        selectableDealers.forEach { d ->
                            Text(d.name, fontWeight = if (selectedDealerId == d.id) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.fillMaxWidth().clickable { selectedDealerId = d.id }.padding(vertical = 6.dp))
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("QUALITY", "QUANTITY", "DELIVERY", "BILLING", "OTHER").forEach { cat ->
                            FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat, style = MaterialTheme.typography.labelSmall) })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                    var complaintError by remember { mutableStateOf<String?>(null) }
                    complaintError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val d = selectableDealers.firstOrNull { it.id == selectedDealerId }
                            if (d != null && description.isNotBlank()) {
                                val created = MockRepository.createCustomerComplaint(d.id, d.name, description, category, onRejected = { e -> complaintError = e })
                                if (created != null) showNew = false
                            }
                        },
                        enabled = selectedDealerId != null && description.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Submit") }
                }
            }
        }
    }
}
