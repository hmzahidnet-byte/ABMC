package com.abm.erp.data

import java.time.LocalDate
import java.time.LocalDateTime
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

// ---------- Multi-tenant / roles ----------
// Real chain of command: SR -> TSM -> ASM -> RSM -> DSM -> NSM -> AGM -> GM -> MD -> CHAIRMAN.
// Each designation's module access is enforced in MockRepository.allowedModules(); zone/geo
// scoping (which district/division a person's data is limited to) lives on AppUser.zone.
enum class UserRole { SR, TSM, ASM, RSM, DSM, NSM, AGM, GM, MD, CHAIRMAN }

/** Cross-device sync's own visible status — shown as a small badge so the person always knows whether their last action has actually left the phone. */
enum class SyncStatus { PENDING, SYNCED, FAILED }

// ============================================================
// Foundation 2 — Employee Hierarchy & Authority Control.
// EMPLOYEE_DIRECTORY (OrgDirectory.kt) is procedurally-generated
// placeholder data (one synthetic SR/TSM/ASM per district, identical
// target/achieved figures) — it was never a real, persisted employee
// record system. EmployeeProfile below is the real thing: genuinely
// created, edited, and persisted per actual hired employee, with a
// real reporting chain and approval authority. It starts empty (no
// fabricated employees) — onboarding below creates real records.
// Existing EMPLOYEE_DIRECTORY-dependent screens are left as-is for
// now (11 call-sites; migrating them is a larger follow-up), which is
// an honest, stated limitation rather than a silent gap.
// ============================================================
/** Office vs factory workforce. Drives which module's HR screens a person appears in. */
enum class EmployeeType { OFFICE, FACTORY }

enum class EmployeeStatus { DRAFT, ACTIVE, PROBATION, CONFIRMED, ON_LEAVE, SUSPENDED, RESIGNED, TERMINATED, RETIRED, INACTIVE }
enum class EmployeeOnboardingStatus { DRAFT, SUBMITTED, HR_REVIEW, MANAGER_REVIEW, ROLE_ASSIGNMENT, TERRITORY_ASSIGNMENT, ACCOUNT_ACTIVATION, ACTIVE, REJECTED, PENDING_CHAIRMAN_APPROVAL, RETURNED_FOR_CORRECTION }

// Phase 3 — Employee Area/Territory Selection. A real, multi-row
// assignment table (separate from EmployeeProfile.territoryId, which
// stays as the single "current primary" quick-reference field) so an
// employee can hold several concurrent areas (primary + secondary +
// temporary coverage) and so history is preserved when a transfer closes
// one assignment and opens another, rather than overwriting in place.
enum class AreaAssignmentType { PRIMARY, SECONDARY, TEMPORARY }
enum class AreaAssignmentStatus { VACANT, ASSIGNED, TEMPORARILY_COVERED, INACTIVE }

// Phase 4 — Performance Appraisal. Scores marked "manual" are explicitly
// human-entered (supervisorScore, hrScore, manager comment); everything
// else (salesAchievement, collectionAchievement, dealerVisits,
// retailerVisits, newDealerAcquisition, newRetailerAcquisition,
// returnRate, complaintRate) is computed from actual ERP records at
// generation time — never a placeholder default presented as real data.
enum class RecognitionType { EMPLOYEE_OF_THE_MONTH, BEST_COLLECTION, BEST_SALES, BEST_ATTENDANCE, BEST_TERRITORY_GROWTH, SPECIAL_RECOGNITION }

data class EmployeeAppraisal(
    val id: String,
    val employeeId: String,
    val companyId: String = "",
    val periodStart: LocalDate,
    val periodEnd: LocalDate,
    // Real, computed-from-ERP-data fields.
    val salesTarget: Double = 0.0,
    val salesAchievement: Double = 0.0,
    val collectionTarget: Double = 0.0,
    val collectionAchievement: Double = 0.0,
    val attendancePresentDays: Int = 0,
    val attendanceTotalDays: Int = 0,
    val punctualityLateDays: Int = 0,
    val dealerVisits: Int = 0,
    val retailerVisits: Int = 0,
    val newDealerAcquisition: Int = 0,
    val newRetailerAcquisition: Int = 0,
    val returnRatePct: Double = 0.0,
    val complaintCount: Int = 0,
    // Explicitly manual fields — clearly labelled as such wherever shown, never blended silently with the computed ones above.
    val supervisorScore: Double? = null, // 0-100, manual
    val hrScore: Double? = null, // 0-100, manual
    val managerComment: String? = null,
    val employeeAcknowledged: Boolean = false,
    val employeeAcknowledgedAt: LocalDateTime? = null,
    // finalScore/rating are only computed once BOTH supervisorScore and
    // hrScore have actually been entered — never fabricated from partial data.
    val finalScore: Double? = null,
    val rating: String? = null, // "Outstanding" | "Exceeds Expectations" | "Meets Expectations" | "Needs Improvement" | "Unsatisfactory"
    val recognitions: List<RecognitionType> = emptyList(),
    val generatedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class EmployeeAreaAssignment(
    val id: String,
    val employeeId: String,
    val companyId: String = "",
    val divisionId: String? = null,
    val divisionName: String? = null,
    val districtId: String? = null,
    val districtName: String? = null,
    val upazilaId: String? = null,
    val upazilaName: String? = null,
    val unionId: String? = null,
    val unionName: String? = null,
    val marketName: String? = null,
    val routeId: String? = null,
    val assignmentType: AreaAssignmentType = AreaAssignmentType.PRIMARY,
    val startDate: LocalDate = LocalDate.now(),
    val endDate: LocalDate? = null,
    val assignedBy: String = "",
    val approvalStatus: String = "APPROVED", // DRAFT | PENDING_APPROVAL | APPROVED | REJECTED
    val isActive: Boolean = true, // false once closed (transfer/end date reached)
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class EmployeeProfile(
    val id: String,
    val employeeCode: String = "", // human-readable Employee ID, e.g. "EMP-1001"
    val userAccountId: String? = null, // links to an actual login account, if/when one exists — null until Account Activation stage
    val fullName: String,
    val mobile: String = "",
    val email: String = "",
    val department: String = "", // "Sales" | "Accounts" | "Warehouse" | "Production" | "HR" | ...
    /**
     * Where this person actually works. `department` is free text and cannot be relied on to
     * separate factory staff from office staff — a typo or a different word breaks it — so the
     * split is an explicit field instead.
     *
     * Defaults to OFFICE: every existing employee keeps behaving exactly as before, and a
     * person only counts as factory staff once someone deliberately marks them so.
     */
    val employeeType: EmployeeType = EmployeeType.OFFICE,
    val designation: String = "", // human title, e.g. "Sales Officer" — role: UserRole below carries the permission tier
    val role: UserRole,
    val grade: String = "",
    val employmentType: String = "PERMANENT", // PERMANENT | CONTRACT | INTERN
    val joiningDate: LocalDate? = null,
    val status: EmployeeStatus = EmployeeStatus.DRAFT,
    val statusReason: String? = null,
    val companyId: String = "",
    val branch: String = "", // kept as backward-compatible display text — Part K: authoritative reference is branchId below
    val region: String = "",
    val area: String = "",
    val territoryId: String? = null,
    val routeId: String? = null,
    // Part K — nullable authoritative reference IDs. Do not derive authorization from these names; Foundation 2 permission engine + territoryId/routeId remain the actual authority source. These are validated master references only.
    val branchId: String? = null,
    val departmentId: String? = null,
    val divisionId: String? = null,
    val districtId: String? = null,
    val upazilaId: String? = null,
    val unionId: String? = null,
    val directManagerId: String? = null,
    val secondaryManagerId: String? = null, // dotted-line
    val functionalManagerId: String? = null,
    val reportingEffectiveFrom: LocalDate? = null,
    val reportingEffectiveTo: LocalDate? = null,
    val tempManagerId: String? = null,
    val tempAssignmentFrom: LocalDate? = null,
    val tempAssignmentTo: LocalDate? = null,
    // Approval authority — Section 8. Every limit defaults to 0 (no
    // authority) rather than an arbitrary number; real limits are set
    // explicitly per employee, never inferred or hardcoded per role.
    val approvalAuthorityLevel: Int = 0,
    val financialApprovalLimit: Double = 0.0,
    val creditOverrideLimit: Double = 0.0,
    val discountApprovalLimitPct: Double = 0.0,
    val stockAdjustmentApprovalLimit: Double = 0.0,
    val purchaseApprovalLimit: Double = 0.0,
    val leaveApprovalAuthority: Boolean = false,
    val attendanceCorrectionAuthority: Boolean = false,
    val dataAccessScope: String = "SELF", // SELF | TERRITORY | AREA | REGION | COMPANY — Section 5 visibility scope
    val onboardingStatus: EmployeeOnboardingStatus = EmployeeOnboardingStatus.DRAFT,
    val rejectReason: String? = null,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val updatedBy: String = "",
    val updatedAt: LocalDateTime? = null,
    val isDeleted: Boolean = false,
    val deletedAt: LocalDateTime? = null,
    val deletedBy: String? = null,
    // Phase 2 — practical Employee Add fields.
    val nationalId: String? = null,
    val dateOfBirth: LocalDate? = null,
    val workLocation: String? = null,
    val emergencyContactName: String? = null,
    val emergencyContactPhone: String? = null,
    val profilePhotoUri: String? = null,
    val basePayMonthly: Double = 0.0, // simple salary-structure reference; detailed payroll components live in PayrollLine at run time
    // Permission Control Center — which Template (a RoleDefinition whose
    // roleKey is a template id) this employee should resolve through
    // instead of their raw UserRole default. Null = use role default only.
    val assignedTemplateKey: String? = null,
) {
    /** A resigned/terminated/inactive employee must not retain active access (Section 11) — real, derived, never stored redundantly. */
    val hasActiveAccess: Boolean get() = status !in setOf(EmployeeStatus.RESIGNED, EmployeeStatus.TERMINATED, EmployeeStatus.RETIRED, EmployeeStatus.INACTIVE, EmployeeStatus.SUSPENDED) && onboardingStatus == EmployeeOnboardingStatus.ACTIVE
}

// Foundation 2, Section 10 — Employee Transfer Workflow. A transfer is a
// proposed change working through its own staged approval before it takes
// effect — kept as its own real entity (not just overwriting the live
// EmployeeProfile fields directly) so "historical transactions must remain
// unchanged" and "previous assignments must remain visible in history"
// are both naturally true: the old assignment is never touched until the
// transfer actually completes.
enum class TransferStage { DRAFT, HR_REVIEW, CURRENT_MANAGER_APPROVAL, NEW_MANAGER_APPROVAL, EFFECTIVE_DATE_PENDING, COMPLETED, REJECTED }

data class TransferRequest(
    val id: String,
    val employeeId: String,
    val employeeName: String,
    val transferType: String, // BRANCH | DEPARTMENT | TERRITORY | ROUTE | MANAGER_CHANGE | PROMOTION | DEMOTION | TEMPORARY | PERMANENT
    val fromValue: String,
    val toValue: String,
    val newManagerId: String? = null,
    val effectiveDate: LocalDate,
    val reason: String = "",
    val retailerHandoverToEmployeeId: String? = null, // null = retain own retailers rather than reassign
    val stage: TransferStage = TransferStage.DRAFT,
    val rejectReason: String? = null,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// Foundation 2, Section 12 — Delegation (distinct from the simple
// tempManagerId field on EmployeeProfile, which only covers "who is my
// acting manager"). Delegation is broader: a specific person can act with
// a bounded subset of another specific person's authority for a
// bounded time, independent of the reporting chain — e.g. an Accounts
// Manager delegating approval authority to a peer while on leave.
data class Delegation(
    val id: String,
    val delegatorId: String,
    val delegatorName: String,
    val delegateId: String,
    val delegateName: String,
    val scope: String, // e.g. "APPROVAL", "LEAVE_APPROVAL", "ALL"
    val financialLimit: Double = 0.0, // capped at min(this, delegator's own limit) — never exceeds the delegator's own authority
    val startDate: LocalDate,
    val endDate: LocalDate,
    val reason: String = "",
    val isActive: Boolean = true,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// v89, Foundation 3, Section 1 — "Do not overwrite retailer location
// silently. Every location change must create history." One row per
// coordinate change, capturing the OLD values before they're replaced.
data class RetailerLocationHistory(
    val id: String,
    val retailerId: String,
    val previousLat: Double?,
    val previousLng: Double?,
    val previousAccuracyMeters: Double?,
    val newLat: Double,
    val newLng: Double,
    val newAccuracyMeters: Double?,
    val changeReason: String,
    val changedBy: String,
    val changedAt: LocalDateTime = LocalDateTime.now(),
    val distanceFromPreviousMeters: Double? = null,
    val revisionNumber: Int,
)

// v89, Foundation 3, Section 16 — Employee Location Snapshot. Only
// captured during authorized field activity (an active visit/route), not
// continuous background tracking — "Avoid continuous high-frequency
// tracking unless explicitly required."
data class EmployeeLocationSnapshot(
    val id: String,
    val employeeId: String,
    val employeeName: String,
    val lat: Double,
    val lng: Double,
    val accuracyMeters: Float?,
    val provider: String?,
    val batteryPct: Int? = null,
    val mockSuspected: Boolean = false,
    val deviceId: String? = null,
    val visitId: String? = null,
    val routeId: String? = null,
    val capturedAt: LocalDateTime = LocalDateTime.now(),
    val syncStatus: String = "SYNCED", // PENDING | SYNCED | FAILED — Section 18 offline support
)

// v89, Foundation 3, Section 21 — Location Alerts. Reuses the existing
// NotificationEntry delivery mechanism (Section 21 explicitly says "Use
// existing notification system") — this is the structured evidence record
// behind an alert, not a parallel notification channel.
enum class LocationAlertType {
    RETAILER_LOCATION_CHANGED, WEAK_GPS, OUTSIDE_RADIUS, EXPIRED_LOCATION_USED, MOCK_LOCATION_SUSPECTED,
    IMPOSSIBLE_TRAVEL, REPEATED_SUSPICIOUS_VISITS, LOCATION_UNAVAILABLE, OFFLINE_PENDING_TOO_LONG,
    LOCATION_PERMISSION_DISABLED, GPS_DISABLED,
}
enum class LocationAlertSeverity { INFO, WARNING, CRITICAL }

data class LocationAlert(
    val id: String,
    val type: LocationAlertType,
    val severity: LocationAlertSeverity,
    val employeeId: String? = null,
    val retailerId: String? = null,
    val visitId: String? = null,
    val message: String,
    val evidenceJson: String? = null,
    val isReviewed: Boolean = false,
    val reviewedBy: String? = null,
    val reviewedAt: LocalDateTime? = null,
    val reviewAction: String? = null, // VERIFY | REJECT | RECAPTURE | WARNING_ACCEPTED | OVERRIDE_APPROVED | ESCALATED
    val reviewComment: String? = null,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// v89, Foundation 3, Section 19 — lightweight device trust, not full
// device-management security ("Do not build full device-management
// security yet. Only support location evidence and trusted-device
// awareness.").
data class TrustedDevice(
    val id: String,
    val deviceId: String,
    val employeeId: String,
    val firstRegisteredAt: LocalDateTime = LocalDateTime.now(),
    val lastActiveAt: LocalDateTime = LocalDateTime.now(),
    val status: String = "APPROVED", // APPROVED | UNAPPROVED | BLOCKED
    val osVersion: String = "",
    val appVersion: String = "",
    val lastLocationAt: LocalDateTime? = null,
    val mockSuspicionCount: Int = 0,
    val failedVerificationCount: Int = 0,
)

// Foundation 6 — Executive Command Center domain models.
data class ExecutiveException(
    val id: String, val type: String, val severity: String, val source: String, val companyId: String = "",
    val branch: String = "", val territoryId: String? = null, val responsiblePerson: String = "", val message: String,
    val impact: String = "", val recommendedAction: String = "", val status: String = "NEW",
    val assignedReviewer: String? = null, val resolutionNote: String? = null, val dedupKey: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(), val updatedAt: LocalDateTime = LocalDateTime.now(),
)

data class ManagementAction(
    val id: String, val title: String, val sourceExceptionId: String? = null, val assignedTo: String,
    val priority: String = "NORMAL", val dueDate: LocalDate? = null, val status: String = "OPEN",
    val comment: String = "", val evidence: String = "", val completionNote: String? = null,
    val createdBy: String = "", val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class DecisionQueryLog(val id: String, val question: String, val matchedIntent: String?, val askedBy: String, val resultSummary: String, val createdAt: LocalDateTime = LocalDateTime.now())

// Bangladesh Offline Administrative Location Master.
data class AdministrativeLocation(
    val id: String, val officialCode: String? = null, val sourceCode: String = "", val type: String = "",
    val nameEn: String = "", val nameBn: String = "", val normalizedName: String = "", val parentId: String? = null,
    val countryCode: String = "BD", val divisionId: String? = null, val districtId: String? = null, val upazilaId: String? = null,
    val unionOrMunicipalityId: String? = null, val wardId: String? = null, val latitude: Double? = null, val longitude: Double? = null,
    val polygon: List<Pair<Double, Double>> = emptyList(), val sourceName: String = "", val sourceUrl: String = "", val sourceVersion: String = "",
    val effectiveFrom: LocalDate? = null, val effectiveTo: LocalDate? = null, val active: Boolean = true, val verified: Boolean = false,
    val createdAt: LocalDateTime = LocalDateTime.now(), val updatedAt: LocalDateTime = LocalDateTime.now(), val syncStatus: String = "SYNCED",
)

data class CompanyMarket(
    val id: String, val name: String, val parentAdminId: String, val latitude: Double? = null, val longitude: Double? = null,
    val source: String = "COMPANY_CREATED", val verificationStatus: String = "UNVERIFIED", val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// Part A — real credential storage domain model.
data class UserAccount(
    val id: String, val employeeProfileId: String, val companyId: String, val pinHash: String, val pinSalt: String,
    val pinIterations: Int = 120_000, val pinSetAt: LocalDateTime = LocalDateTime.now(), val pinExpiresAt: LocalDateTime? = null,
    val failedAttempts: Int = 0, val lockedUntil: LocalDateTime? = null, val active: Boolean = true, val locked: Boolean = false,
    val mustChangePinOnNextLogin: Boolean = false, val createdAt: LocalDateTime = LocalDateTime.now(), val updatedAt: LocalDateTime = LocalDateTime.now(),
)

data class Company(
    val id: String,
    val name: String, // e.g. "ABM Corporation"
    val address: String = "",
    val logoUrl: String? = null,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class AppUser(
    val id: String,
    val name: String,
    val role: UserRole,
    val companyId: String,
    val zone: String, // geo scope label, e.g. "Rangpur district" or "All Bangladesh · Board" for Chairman
    val employeeId: String, // links to the richer Employee record in OrgDirectory.kt
    val territoryId: String? = null, // links to Territory.id (see below) — zone stays as the human-readable label
    val phone: String = "",
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ---------- Territory ----------
// Formalizes the division/district/market "zone" strings scattered across
// Employee/Dealer/Retailer/RetailOrder into one real, referenceable entity.
// v87, Retailer Management Excellence — Section 3 duplicate detection result.
data class RetailerDuplicateMatch(val retailerId: String, val retailerCode: String, val name: String, val phone: String, val confidence: String) // confidence: EXACT | PROBABLE | POSSIBLE

data class RetailerPerformance(
    val salesLast30Days: Double,
    val salesLast60Days: Double,
    val salesLast90Days: Double,
    val avgOrderValue: Double,
    val orderCount30Days: Int,
    val orderFrequencyDays: Double?, // average days between orders, null if <2 orders
    val collectionEfficiencyPct: Double, // collected / (collected+due) over last 90 days
    val creditUtilizationPct: Double,
    val outstandingAgeingDays: Long?, // days since the oldest unpaid ledger debit, null if no due
    val visitToOrderConversionPct: Double, // orders / visits over last 90 days
    val trendPct: Double, // (last30 - previous30) / previous30 * 100
    val isGrowing: Boolean,
)

data class RetailerActivityFlag(val label: String, val severity: String) // severity: INFO | WARNING | CRITICAL

data class Territory(
    val id: String,
    val division: String,
    val district: String? = null,
    val market: String? = null,
    val parentTerritoryId: String? = null, // market -> district -> division chain
    val zoneName: String? = null, // DSM-tier multi-division zone label, e.g. "Northern Zone"
    val country: String = "Bangladesh", // Route & Territory Management's full hierarchy: Country > Division > District > Upazila > Territory > Area > Route > Beat
    val upazila: String? = null,
    val area: String? = null,
    val beat: String? = null, // finest-grained level — matches SalesRoute's "beat plan" concept, formalized here as a territory-hierarchy leaf
    // v90, Foundation 4 — Territory Master + Polygon Geofence. "Do not
    // depend only on district names" — polygon is the real boundary when
    // present; district/upazila remain the human-readable admin hierarchy
    // for search/reporting, not the enforcement mechanism.
    val code: String = "",
    val polygon: List<Pair<Double, Double>> = emptyList(), // ordered (lat, lng) vertices; empty = no polygon defined for this territory yet
    val polygonVersion: Int = 0,
    val defaultVisitRadiusMeters: Double = 100.0,
    val isActive: Boolean = true,
    val effectiveFrom: LocalDate? = null,
    val effectiveTo: LocalDate? = null,
    val assignedManagerIds: List<String> = emptyList(),
    val assignedOfficerIds: List<String> = emptyList(),
)

// ---------- Role & Permissions ----------
// Replaces the hardcoded-only ROLE_MODULES map (ModuleAccess.kt) with a real,
// per-module capability structure — ROLE_MODULES stays as the simple "can
// even see this tile" check, this is the finer-grained CRUD/approve layer
// used by the Foundation Layer's Role-Based Permission step.
data class ModulePermission(
    val moduleKey: String,
    val canView: Boolean = true,
    val canCreate: Boolean = false,
    val canEdit: Boolean = false,
    val canApprove: Boolean = false,
    val canDelete: Boolean = false,
    val canExport: Boolean = false,
)

data class RoleDefinition(
    val roleKey: String, // UserRole.name for built-in roles, or any custom role string
    val label: String,
    val modulePermissions: List<ModulePermission> = emptyList(),
)


// ---------- Permission Control Center ----------
// Templates reuse RoleDefinition/ModulePermission directly — roleKey is
// already documented as accepting "any custom role string", so a
// Template IS a RoleDefinition whose roleKey is a template id rather than
// a UserRole.name. No parallel storage invented. isBuiltIn distinguishes
// the 10 real-role definitions (never deletable) from Chairman-created
// custom templates (TSM/ASM/RSM/NSM/HR/Accounts/Warehouse/Factory/Admin/
// Custom starting points, then freely editable/duplicable/deletable).
enum class AccessLevel { HIDE, VIEW_ONLY, FULL_ACCESS }

fun AccessLevel.toModulePermission(moduleKey: String): ModulePermission = when (this) {
    AccessLevel.HIDE -> ModulePermission(moduleKey, canView = false)
    AccessLevel.VIEW_ONLY -> ModulePermission(moduleKey, canView = true)
    AccessLevel.FULL_ACCESS -> ModulePermission(moduleKey, canView = true, canCreate = true, canEdit = true, canApprove = true, canDelete = true, canExport = true)
}

/** Individual employee override — takes priority over whatever template/role the employee would otherwise resolve to, for this one moduleKey only. */
data class EmployeePermissionOverride(
    val id: String,
    val employeeId: String,
    val companyId: String = "",
    val moduleKey: String,
    val accessLevel: AccessLevel,
    val setBy: String = "",
    val setByName: String = "",
    val setAt: LocalDateTime = LocalDateTime.now(),
)


// ---------- Chairman-Controlled Vacancy & Target Management ----------
enum class VacancyStatus { DRAFT, PENDING_CHAIRMAN_APPROVAL, OPEN, ON_HOLD, FROZEN, FILLED, CANCELLED, CLOSED }

data class Vacancy(
    val id: String,
    val companyId: String = "",
    val designation: String,
    val department: String,
    val territoryId: String? = null,
    val requestedBy: String = "",
    val requestedByName: String = "",
    val reason: String? = null,
    val status: VacancyStatus = VacancyStatus.DRAFT,
    val approvedBy: String? = null,
    val filledByEmployeeId: String? = null,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

enum class TargetScopeType { COMPANY, REGION, ZONE, AREA, TEAM, EMPLOYEE, DEALER, RETAILER, PRODUCT }
enum class TargetPeriodType { DAILY, WEEKLY, MONTHLY, QUARTERLY, YEARLY, CUSTOM }
enum class TargetType { SALES_AMOUNT, SALES_QUANTITY, COLLECTION, DUE_RECOVERY, NEW_DEALER, NEW_RETAILER, PRODUCT_WISE_SALES, MARKET_VISIT, ATTENDANCE, ORDER_BOOKING, INVOICE_COUNT }

data class Target(
    val id: String,
    val companyId: String = "",
    val scopeType: TargetScopeType,
    val scopeId: String, // employeeId/dealerId/retailerId/productId/regionName/zoneName/areaName/teamId, matching scopeType
    val parentTargetId: String? = null, // hierarchical distribution — Company target -> Region -> Area -> Team -> Employee
    val periodType: TargetPeriodType,
    val periodStart: LocalDate,
    val periodEnd: LocalDate,
    val targetType: TargetType,
    val targetValue: Double,
    val achievedValue: Double = 0.0,
    val isOverride: Boolean = false, // Chairman confirmed despite the unusual-vs-history warning
    val overrideReason: String? = null,
    val status: String = "ACTIVE", // ACTIVE | PAUSED | CANCELLED
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

/** Every edit creates a new history row rather than overwriting — "Target changes must never overwrite history". */
data class TargetChangeLog(
    val id: String,
    val targetId: String,
    val oldValue: Double?,
    val newValue: Double?,
    val reason: String,
    val changedBy: String = "",
    val changedByName: String = "",
    val changedAt: LocalDateTime = LocalDateTime.now(),
)

// ---------- Sales chain ----------

enum class OrderStage { SO_LOGGED, ASM_VERIFIED, DEALER_ROUTED, FULFILLED, REJECTED }

data class RetailOrder(
    val id: String,
    val orderNo: String, // human-readable sequential number for display — the id itself is a random UUID (avoids Firestore hotspotting at scale)
    val retailerName: String,
    val loggedBySoId: String,
    val zone: String,
    val items: String,          // e.g. "ABM Masala Tea x40 ctn" — kept as the human summary and still populated
    /** Structured lines (v71). Empty for orders taken before the memo redesign. */
    val lineItems: List<SalesInvoiceLineItem> = emptyList(),
    val amount: Double,
    var stage: OrderStage = OrderStage.SO_LOGGED,
    var routedDealerId: String? = null,
    val loggedAt: LocalDateTime = LocalDateTime.now(),
    // Ground-level SR data collection: shop photo, live GPS tag, and a
    // printable QR code unique to this retailer — scan it later to pull the
    // shop's record back up instantly.
    val retailerPhotoUri: String? = null,
    val retailerLat: Double? = null,
    val retailerLng: Double? = null,
    val channel: String = "retail", // "retail" | "wholesale" — sales-type chain of command, separate from designation chain
    val anonymous: Boolean = false, // shopkeeper declined to give name/photo — item+amount only, so the sale isn't lost
    val photoPurpose: String? = null, // "Shop photo" | "Product damaged" | "Other issue"
    val retailerQrCode: String? = null,
    val retailerId: String? = null, // links to the real Retailer entity (Data Design step) — retailerName stays for display/backward-compat
)

data class Dealer(
    val id: String,
    val name: String,
    val zone: String, // kept as backward-compatible display text only — Part J: authoritative location now lives in the fields below
    var dueBalance: Double,
    var salesLast90Days: Double,
    val pin: String = "0000", // legacy plaintext field — kept only to detect never-migrated dealers; verification now uses pinHash/pinSalt below
    val pinHash: String? = null,
    val pinSalt: String? = null,
    val pinIterations: Int = 120_000,
    var stockUnits: Int = 0, // দোকানে এখন কতগুলো কার্টন/ইউনিট আছে — SR-এর retail order এই স্টকের বিপরীতেই verify হয়, company-এর central stock-এর বিপরীতে না
    val phone: String = "",
    val address: String = "",
    val territoryId: String? = null,
    // Part J — nullable authoritative Bangladesh Location Master references. Unresolved legacy dealers simply have these as null; zone string is never overwritten to force a match.
    val divisionId: String? = null,
    val districtId: String? = null,
    val upazilaId: String? = null,
    val unionId: String? = null,
    val wardId: String? = null,
    val routeId: String? = null,
    val legacyAddressResolved: Boolean = false,
    val dedupKey: String = "", // normalized name+phone key — Foundation Layer's Data Integrity step checks this before insert
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val deletedAt: LocalDateTime? = null,
    val deletedBy: String? = null,
    val classification: String = "B", // "A" | "B" | "C" — Dealer Classification (DMS)
    val creditLimit: Double = 0.0, // 0 = no explicit limit set yet — Credit Limit enforcement checks this before invoicing
    // v86, Module 3 — Weekly 50% Due Rule
    val monthlyTarget: Double = 0.0,
    val weeklyPaidAmount: Double = 0.0,
    val weekStartEpochDay: Long = 0,
    val creditStatus: String = "ACTIVE",
    val creditStatusReason: String? = null,
    val creditStatusChangedBy: String? = null,
    val creditStatusChangedAt: LocalDateTime? = null,
    val promiseToPayDate: LocalDateTime? = null,
    val promiseToPayAmount: Double = 0.0,
    val promiseNote: String? = null,
    // Phase 1 — practical Dealer Add/Approval fields.
    val dealerCode: String = "", // e.g. "ABM-DLR-00001" — sequential, human-readable, distinct from the internal UUID-based id
    val proprietorName: String = "",
    val altPhone: String = "",
    val nationalId: String? = null,
    val email: String? = null,
    val marketName: String? = null, // Market/Bazar
    val lat: Double? = null,
    val lng: Double? = null,
    val assignedEmployeeId: String? = null, // assigned SR/employee
    val assignedManagerId: String? = null,
    val openingBalance: Double = 0.0,
    val paymentTermsDays: Int = 0,
    val tradeLicenseNumber: String? = null,
    val notes: String? = null,
    // Rich status — kept alongside the existing `isActive` boolean (never
    // removed; too much existing code reads it) so both stay in sync
    // whenever status changes. status is the authoritative workflow state;
    // isActive is simply true only when status == "ACTIVE".
    val status: String = "DRAFT", // DRAFT | SUBMITTED | PENDING_APPROVAL | APPROVED | REJECTED | SUSPENDED | PAUSED | TERMINATED | ACTIVE — the last four (ACTIVE/PAUSED/SUSPENDED/TERMINATED) are also the Chairman lifecycle-control states (v113-201, setDealerLifecycleStatus), all reversible via ACTIVE
    val approvedBy: String? = null,
    val approvedByName: String? = null,
    val approvedAtEpochMillis: Long? = null,
    val approvalComment: String? = null,
    val previousStatus: String? = null,
    val resolvedApprovalPath: String? = null,
    val photoUri: String? = null, // v113-147 — dealer shop/owner photo
)

// ---------- Retailer ----------
// Previously only a free-text name inside RetailOrder — now its own
// referenceable entity so duplicate-prevention, soft-delete, and audit can
// actually apply to it (was the single biggest Data Design gap).
data class Retailer(
    val id: String,
    val retailerCode: String = "", // unique human-readable code, e.g. "RTL-1001"
    val name: String,
    val ownerName: String = "",
    val phone: String = "",
    val altPhone: String = "",
    val email: String = "",
    val address: String = "",
    val district: String = "",
    val upazila: String = "",
    val union_: String = "", // trailing underscore avoids clashing with Kotlin's `union` naming conventions
    val market: String = "",
    val area: String = "",
    val postalCode: String = "",
    val territoryId: String? = null,
    val dealerId: String? = null,
    val lat: Double? = null,
    val lng: Double? = null,
    val gpsAccuracyMeters: Double? = null,
    val geoCapturedAt: LocalDateTime? = null,
    val photoUri: String? = null, // shop front/signboard photo
    val ownerPhotoUri: String? = null,
    val tradeLicenseNo: String = "",
    val nidRef: String = "", // National ID reference — access-gated in UI/permissions, not exposed to unauthorized roles
    val qrCode: String? = null,
    val dedupKey: String = "", // normalized name+lat/lng (or name+phone) key
    val classification: String = "B", // A | B | C retailer category (business tiering) — distinct from outletCategory below (shop type)
    val businessStatus: String = "ACTIVE", // PROSPECT | ACTIVE | INACTIVE | SUSPENDED | CLOSED
    val statusReason: String? = null,
    val openingDate: LocalDate? = null,
    val officerId: String? = null, // assigned sales officer (Employee.id)
    val officerName: String = "",
    val paymentTermsDays: Int = 0,
    val allowedCreditDays: Int = 0,
    val lastCollectionDate: LocalDateTime? = null,
    val lastOrderDate: LocalDateTime? = null,
    val lastVisitDate: LocalDateTime? = null,
    val nextPlannedVisit: LocalDateTime? = null,
    val preferredProducts: String = "", // comma-separated product names — a real preference tag list, not a foreign-key catalog (keeps this from becoming a second product-catalog source of truth)
    val notes: String = "",
    val tags: String = "",
    // v113-203 — self-service Retailer login, mirrors Dealer's pin/pinHash/
    // pinSalt/pinIterations fields exactly (see Dealer above).
    val pinHash: String? = null,
    val pinSalt: String? = null,
    val pinIterations: Int = 120_000,
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val updatedBy: String = "",
    val updatedAt: LocalDateTime? = null,
    val deletedAt: LocalDateTime? = null,
    val deletedBy: String? = null,
    var dueBalance: Double = 0.0, // Retailer Due
    val creditLimit: Double = 0.0, // Retailer Credit Limit — 0 = not set
    val creditHold: Boolean = false, // v87 - Credit Control: manager-set hold, independent of automatic Weekly-Due-style checks
    val creditHoldReason: String? = null,
    val outletCategory: String = "General Store", // Outlet Category
    val outletType: String = "Retail", // Outlet Type — "Retail" | "Wholesale" | "Pharmacy" | "Super Shop" ...
    val routeId: String? = null, // Outlet Route Assignment — links to a beat/route
    val onboardingStatus: String = "ACTIVE", // DRAFT | SUBMITTED | DUPLICATE_CHECK | LOCATION_PENDING | PENDING_APPROVAL | REJECTED | ACTIVE — legacy rows created before this workflow default straight to ACTIVE
    val rejectReason: String? = null,
    val standardDiscountPct: Double = 0.0, // per-retailer default billing discount
    val commissionPct: Double = 0.0, // scheme/referral commission rate, if applicable
    // v89, Foundation 3 — Retailer Location Master (Section 1). lat/lng/
    // gpsAccuracyMeters/geoCapturedAt/photoUri above already existed from
    // Foundation 1; these are the genuinely new fields this foundation
    // requires. Altitude is deliberately NOT included — this app has never
    // captured altitude anywhere and fabricating a field no device call
    // ever populates would violate "Do not claim GPS accuracy that is not
    // available from the device."
    val locationProvider: String? = null, // "gps" | "network" | "fused" | "manual" — whatever Location.getProvider() actually returned, or "manual"/"imported"/"manager_corrected" for non-GPS captures
    val locationCapturedByEmployeeId: String? = null,
    val locationCapturedDeviceId: String? = null,
    val locationCaptureMethod: String = "GPS", // GPS | NETWORK | MANUAL_PIN | IMPORTED | MANAGER_CORRECTED
    val locationVerificationStatus: String = "NOT_CAPTURED", // mirrors LocationVerification.VerificationStatus
    val locationVerificationScore: Int? = null,
    val locationVerifiedBy: String? = null,
    val locationVerifiedAt: LocalDateTime? = null,
    val locationVerificationComment: String? = null,
    val geofenceRadiusMeters: Double? = null, // null = use the company/territory default, not a fabricated per-retailer number
    val lastLocationUpdateReason: String? = null,
    val locationRevision: Int = 0, // bumped on every real coordinate change — "Every location change must create history"
) {
    /** v87 - Retailer Master Profile: real credit-availability, derived (not stored) from creditLimit/dueBalance per "do not store calculated fields redundantly". */
    val availableCredit: Double get() = (creditLimit - dueBalance).coerceAtLeast(0.0)
}

// v87 — Retailer promotional package/offer/scheme.
data class RetailerOffer(
    val id: String,
    val retailerId: String,
    val title: String,
    val description: String = "",
    val discountPct: Double = 0.0,
    val validFrom: LocalDate = LocalDate.now(),
    val validTo: LocalDate,
    val isActive: Boolean = true,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
) {
    val isCurrentlyValid: Boolean get() = isActive && !LocalDate.now().isBefore(validFrom) && !LocalDate.now().isAfter(validTo)
}

// v87 — Retailer damage/breakage claim, with approval and real stock write-off.
data class RetailerDamageReport(
    val id: String,
    val retailerId: String,
    val productName: String,
    val quantity: Double,
    val estimatedValue: Double,
    val reason: String,
    val photoUri: String? = null,
    val status: String = "PENDING", // PENDING | APPROVED | REJECTED
    val approvedBy: String? = null,
    val reportedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ---------- Module 4/7/8 shared: which party a record is about ----------
enum class PartyType { DEALER, RETAILER, SUPPLIER }

// ---------- Sales Management (Module 4): Quotation ----------
data class Quotation(
    val id: String,
    val quotationNo: String,
    val partyType: PartyType,
    val partyId: String,
    val partyName: String,
    val lineItems: List<SalesInvoiceLineItem>,
    val validUntil: LocalDateTime,
    val status: String = "DRAFT", // DRAFT | SENT | CONVERTED | EXPIRED | CANCELLED
    val convertedInvoiceId: String? = null,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
) {
    val subTotal: Double get() = lineItems.sumOf { it.lineTotal }
}

// ---------- Sales Management (Module 4): Delivery Challan ----------
data class DeliveryChallan(
    val id: String,
    val challanNo: String,
    val invoiceId: String? = null,
    val partyType: PartyType,
    val partyId: String,
    val partyName: String,
    val lineItems: List<SalesInvoiceLineItem>,
    val vehicleNo: String = "",
    val driverName: String = "",
    val deliveredBy: String = "",
    val status: String = "PENDING", // PENDING | DISPATCHED | DELIVERED
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
)

// ---------- Sales Management (Module 4): Sales Return ----------
data class SalesReturn(
    val id: String,
    val returnNo: String,
    val invoiceId: String? = null,
    val partyType: PartyType,
    val partyId: String,
    val partyName: String,
    val lineItems: List<SalesInvoiceLineItem>,
    val reason: String = "",
    val refundAmount: Double = 0.0,
    val status: String = "PENDING", // PENDING | APPROVED | REJECTED
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
)

// ---------- Dealer/Retailer Ledger (Module 7/8) ----------
// Distinct from the company-wide LedgerEntry (Accounts module) — this is
// per-party running balance: every invoice/collection/return posts one row
// here, so "Dealer Ledger"/"Retailer Ledger" is a real statement, not just
// today's dueBalance snapshot.
data class PartyLedgerEntry(
    val id: String,
    val partyType: PartyType,
    val partyId: String,
    val type: String, // "DEBIT" (due increases — invoice) | "CREDIT" (due decreases — collection/return)
    val amount: Double,
    val reason: String,
    val referenceId: String = "", // the invoice/collection/return id this posting came from
    val balanceAfter: Double = 0.0,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ---------- Dealer/Retailer Collection (Module 7/8/10) ----------
data class PartyCollection(
    val id: String,
    val collectionNo: String = "",
    val partyType: PartyType,
    val partyId: String,
    val partyName: String,
    val amount: Double,
    val method: String = "CASH", // CASH | BANK | MOBILE_BANKING | CHEQUE
    val proofUri: String? = null,
    val status: String = "PENDING", // PENDING | VERIFIED | REJECTED
    val collectedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val verifiedBy: String? = null,
    val verifiedAt: LocalDateTime? = null,
    val allocatedInvoiceId: String? = null,
)

// ---------- Sales Management (Module 4): Discount Rules ----------
data class DiscountRule(
    val id: String,
    val label: String,
    val scope: String = "ALL", // "ALL" | a specific dealerId/retailerId — simple targeting
    val minQty: Double = 0.0,
    val discountPct: Double = 0.0,
    val isActive: Boolean = true,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ---------- Route & Territory (SFA / Module 8's Outlet Route Assignment) ----------
data class SalesRoute(
    val id: String,
    val name: String,
    val territoryId: String? = null,
    val assignedToEmployeeId: String = "",
    val outletIds: List<String> = emptyList(), // Retailer ids on this beat, visit order matters
    val isActive: Boolean = true,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ---------- Outlet/Dealer Visit History (Module 7/8/9) ----------
/** Real-time Live Tracking — current position only, overwritten each update (never accumulated as history, unlike VisitLog's breadcrumb trail). */
data class LiveLocation(
    val employeeId: String,
    val employeeName: String,
    val lat: Double,
    val lng: Double,
    val speedMetersPerSecond: Float? = null,
    val updatedAtEpochMillis: Long = 0,
) {
    val staleSeconds: Long get() = (System.currentTimeMillis() - updatedAtEpochMillis) / 1000
    val isStale: Boolean get() = staleSeconds > 120 // no update in 2 minutes — likely offline/tracking stopped
}

// ==========================================================
// Section 8 — Expense workflow. Was completely missing from this
// codebase (no model/entity/DAO/anything) despite being referenced
// across multiple earlier sections. Real submit -> approve/reject ->
// ledger-posting workflow, matching the same tiered-approval pattern
// used everywhere else in this app.
// ==========================================================
enum class ExpenseStatus { PENDING, APPROVED, REJECTED }
enum class ExpensePaymentMethod { CASH, BANK }

data class Expense(
    val id: String,
    val expenseNo: String,
    val companyId: String = "",
    val category: String, // e.g. "Utility Bill", "Office Supplies", "Transport", "Maintenance"
    val amount: Double,
    val description: String = "",
    val paymentMethod: ExpensePaymentMethod = ExpensePaymentMethod.CASH,
    val submittedBy: String = "",
    val submittedByEmployeeId: String = "",
    val status: ExpenseStatus = ExpenseStatus.PENDING,
    val approvedBy: String? = null,
    val rejectReason: String? = null,
    val attachmentUri: String? = null,
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val approvedAt: LocalDateTime? = null,
)

// ==========================================================
// Section 1 — Data Correction & Reversal Workflow
// ==========================================================
enum class CorrectionType { EDIT, DELETE }
enum class CorrectionRequestStatus { SUBMITTED, MANAGER_REVIEW, PROCESSING, CHAIRMAN_APPROVED, REJECTED, APPLIED }

/**
 * Never edits a finalized record directly — always a request that, once
 * Chairman-approved, produces BOTH a reversal entry (undoing the
 * original) and a corrected replacement entry, so the original history
 * is never lost, only superseded.
 */
data class CorrectionRequest(
    val id: String,
    val companyId: String = "",
    val module: String, // "Invoice" | "Collection" | "Attendance" | "Dealer" | "Retailer" | "Production" | "Warehouse" | "Stock" | "Payroll"
    val recordId: String,
    val correctionType: CorrectionType,
    val reason: String,
    val proposedChangeJson: String, // packed field->newValue proposal, applied only after Chairman approval
    val originalValueJson: String = "", // real captured snapshot of the value BEFORE correction, taken at submission time — this is what makes "preserve original history" actually true rather than implied
    val requestedBy: String = "",
    val requestedByName: String = "",
    val managerReviewedBy: String? = null,
    val managerComment: String? = null,
    val chairmanApprovedBy: String? = null,
    val chairmanComment: String? = null,
    val status: CorrectionRequestStatus = CorrectionRequestStatus.SUBMITTED,
    val reversalEntryId: String? = null,
    val correctedEntryId: String? = null,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ==========================================================
// Section 2 — Accounting Period Lock
// ==========================================================
enum class PeriodLockScope { MONTH, QUARTER, YEAR }

data class AccountingPeriodLock(
    val id: String,
    val companyId: String = "",
    val scope: PeriodLockScope,
    val periodStart: LocalDate,
    val periodEnd: LocalDate,
    val lockedBy: String = "",
    val lockedByName: String = "",
    val isLocked: Boolean = true,
    val lockedAt: LocalDateTime = LocalDateTime.now(),
    val unlockedBy: String? = null,
    val unlockedAt: LocalDateTime? = null,
)

// ==========================================================
// Section 3 — Central Number Series Engine
// ==========================================================
data class NumberSeriesConfig(
    val id: String, // = seriesKey, e.g. "INVOICE", "DEALER", "PRODUCTION_BATCH"
    val companyId: String = "",
    val companyPrefix: String = "ABM",
    val branchPrefix: String? = null,
    val useFinancialYear: Boolean = true,
    val fiscalYearStartMonth: Int = 7, // 1=January..12=December. Default 7 (July) matches Bangladesh's standard July–June fiscal year — configurable per company, not hardcoded as calendar year.
    val currentRunningNumber: Long = 0,
    val padWidth: Int = 5,
)

// ==========================================================
// Section 4 — Data Ownership Transfer
// ==========================================================
enum class OwnershipTransferScope { DEALER, RETAILER, DUE, COLLECTION_RESPONSIBILITY, TARGET, ROUTE, PENDING_TASK, FOLLOW_UP, VISIT }

data class OwnershipTransferRecord(
    val id: String,
    val companyId: String = "",
    val scope: OwnershipTransferScope,
    val entityId: String, // the dealer/retailer/target/route id being transferred
    val fromEmployeeId: String?,
    val toEmployeeId: String,
    val reason: String, // e.g. "resignation", "area change"
    val transferredBy: String = "",
    val transferredAt: LocalDateTime = LocalDateTime.now(),
)

// ==========================================================
// Section 9 — Business Rule Engine. A single, generic key-value store
// the Chairman edits directly, rather than these values being baked
// into code (a percentage in an if-check, a radius constant, a limit
// literal). Every consumer reads through businessRuleDouble()/
// businessRuleInt() below, which fall back to the same default the
// hardcoded version used — so this is a strict upgrade (configurable
// now, same behavior if never touched) not a behavior change.
// ==========================================================
enum class BusinessRuleType { PERCENTAGE, AMOUNT, DISTANCE_METERS, MINUTES, COUNT }

data class BusinessRule(
    val key: String, // e.g. "WEEKLY_DUE_PCT", "MAX_DISCOUNT_PCT", "ATTENDANCE_RADIUS_M", "LATE_ENTRY_GRACE_MIN", "STOCK_APPROVAL_THRESHOLD", "INVOICE_LIMIT", "DEALER_CREDIT_LIMIT_DEFAULT"
    val label: String,
    val type: BusinessRuleType,
    val value: Double,
    val companyId: String = "",
    val updatedBy: String = "",
    val updatedByName: String = "",
    val updatedAt: LocalDateTime = LocalDateTime.now(),
)

// ==========================================================
// Section 10 — Company Settings Center. One central config record per
// company, editable only by the Chairman, feeding every policy area
// listed (Financial Year already lives on NumberSeriesConfig; the rest
// live here).
// ==========================================================
data class Holiday(val date: LocalDate, val name: String)

data class CompanySettings(
    val id: String, // = companyId
    val companyName: String = "",
    val companyAddress: String = "",
    val companyPhone: String = "",
    val companyEmail: String = "",
    // v113-221 — the person's own explicit request: a real company logo,
    // uploaded once from the (now-simplified) Company Info screen, that
    // reflects everywhere the company's identity already shows up
    // (invoice/memo headers, main dashboard) instead of the app staying
    // permanently branded "ABM ERP" regardless of who's actually running it.
    val companyLogoUri: String? = null,
    val fiscalYearStartMonth: Int = 7, // 1=January..12=December — single source of truth for Financial Year, read by generateNumber() when creating any series' config
    val taxVatNumber: String = "",
    val vatPct: Double = 0.0,
    val currencyCode: String = "BDT",
    val currencySymbol: String = "৳",
    val numberFormatPattern: String = "#,##0.00",
    val workingDays: List<String> = listOf("SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY"), // Bangladesh standard work-week default
    val holidaysRaw: String = "", // packed "epochDay:name;epochDay:name"
    val attendancePolicyNote: String = "",
    val payrollPolicyNote: String = "",
    val invoicePolicyNote: String = "",
    val dealerPolicyNote: String = "",
    val targetPolicyNote: String = "",
    val updatedBy: String = "",
    val updatedAt: LocalDateTime = LocalDateTime.now(),
) {
    val holidays: List<Holiday> get() = holidaysRaw.split(";").filter { it.isNotBlank() }.mapNotNull { part ->
        val kv = part.split(":", limit = 2)
        if (kv.size == 2) kv[0].toLongOrNull()?.let { Holiday(LocalDate.ofEpochDay(it), kv[1]) } else null
    }
}

data class VisitLog(
    val id: String,
    val partyType: PartyType,
    val partyId: String,
    val employeeId: String,
    val employeeName: String,
    val lat: Double,
    val lng: Double,
    val photoUri: String? = null,
    val purpose: String = "", // "Routine visit" | "Collection" | "Order" | "Display check"
    val checkInAt: LocalDateTime = LocalDateTime.now(),
    val checkOutAt: LocalDateTime? = null,
    // v89, Foundation 3 — real check-in/check-out verification fields.
    // "lat"/"lng" above remain the check-in coordinate for backward
    // compatibility with every existing caller; checkOutLat/Lng are new
    // and separate, since check-out can genuinely happen from a
    // different spot than check-in.
    val routeId: String? = null,
    val checkInAccuracyMeters: Float? = null,
    val checkInProvider: String? = null,
    val checkInMockSuspected: Boolean = false,
    val checkInDistanceFromRetailerMeters: Double? = null,
    val checkOutLat: Double? = null,
    val checkOutLng: Double? = null,
    val checkOutAccuracyMeters: Float? = null,
    val checkOutMockSuspected: Boolean = false,
    val checkOutDistanceFromRetailerMeters: Double? = null,
    val deviceId: String? = null,
    val verificationResult: String = "PENDING", // LocationVerification.VisitVerificationResult name, or "PENDING" before check-out
    val verificationScore: Int = 0,
    val overrideReason: String? = null,
    val overrideBy: String? = null,
    val orderCreatedId: String? = null,
    val collectionCreatedId: String? = null,
    val complaintCreatedId: String? = null,
    val notes: String = "",
) {
    /** Real visit duration once checked out (Section 6) — derived, never stored redundantly. */
    val durationMinutes: Long? get() = checkOutAt?.let { java.time.Duration.between(checkInAt, it).toMinutes() }
}

// ================= Universal Attachment System (Global Rule) =================
// One shared attachment table for the whole app — any module/entity attaches
// a photo/PDF/document/audio/video through this SAME structure instead of
// each module inventing its own upload field, matching how Audit Log/Party
// Ledger already unify similar cross-cutting concerns.
enum class AttachmentType { PHOTO, PDF, DOCUMENT, AUDIO, VIDEO }

data class Attachment(
    val id: String,
    val moduleReference: String, // e.g. "Retailer", "Dealer", "Task", "SalesInvoice", "Complaint"
    val entityId: String,
    val type: AttachmentType,
    val uri: String,
    val lat: Double? = null,
    val lng: Double? = null,
    val uploadedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ================= Universal Action Menu support (Global Rule) =================
// Every "Duplicate" action clones a record via this generic result rather
// than each module writing its own bespoke clone function.
data class DuplicateResult(val newId: String, val label: String)

// ---------- Dealer Invoicing (Sales Chain) ----------
// Sales-type chain of command (separate from designation chain): invoicing
// starts at Dealer/Depot level, never at Retailer/Wholesale. SR cannot
// create these (see MockRepository.canInvoice) — TSM and above can. Named
// distinctly from the existing VoiceInvoice/InvoiceLineItem (Billing
// module's separate "Voice Billing" feature) to avoid a naming collision.
data class SalesInvoiceLineItem(val productId: String, val name: String, val unit: String, val qty: Int, val unitPrice: Double, val discountPct: Double = 0.0, val batchCode: String? = null) {
    val lineTotal: Double get() = qty * unitPrice * (1 - discountPct / 100)
}

// v86, Module 4 — Sales Order stage: Draft -> Submitted -> Approved -> (Partially Delivered/Delivered) -> Invoiced -> Cancelled.
// Reuses SalesInvoiceLineItem rather than inventing a parallel line-item type.
data class SalesOrder(
    val id: String,
    val orderNo: String,
    val dealerId: String,
    val dealerName: String,
    val dealerZone: String,
    val lineItems: List<SalesInvoiceLineItem>,
    val dealerDiscountPct: Double = 0.0,
    val status: String = "DRAFT", // DRAFT | SUBMITTED | APPROVED | PARTIALLY_DELIVERED | DELIVERED | INVOICED | CANCELLED
    val convertedToInvoiceId: String? = null,
    val deliveredQtyByProduct: Map<String, Int> = emptyMap(), // real partial-delivery tracking, keyed by productId
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val approvedBy: String? = null,
    val approvedAt: LocalDateTime? = null,
    val isDeleted: Boolean = false,
) {
    val subTotal: Double get() = lineItems.sumOf { it.lineTotal }
    val netAfterDiscount: Double get() = subTotal * (1 - dealerDiscountPct / 100)
}

data class SalesInvoice(
    val id: String,
    val invoiceNo: String,
    val dealerId: String,
    val dealerName: String,
    val dealerZone: String,
    val lineItems: List<SalesInvoiceLineItem>,
    val dealerDiscountPct: Double = 0.0,
    val commissionPct: Double = 0.0,
    val courier: String? = null,
    val signedByRole: String? = null, // optional virtual signature — the designation of whoever created it
    val createdBy: String,
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val status: String = "PENDING", // "PENDING" | "PARTIALLY_PAID" | "PAID" | "CANCELLED"
    val paidAmount: Double = 0.0, // v86 Module 5 — sum of collection allocations applied to this invoice
    /**
     * Party balance captured at the moment this invoice was created.
     *
     * Stored rather than recomputed on open, because a printed bill must keep showing the
     * figures it was printed with. Recomputing from today's dealer balance would make an
     * old invoice silently disagree with the paper copy in the dealer's file.
     * These are a record of a moment; they never feed a calculation.
     */
    val previousDueSnapshot: Double = 0.0,
    val closingDueSnapshot: Double = 0.0,
    val isDeleted: Boolean = false,
    val deletedAt: LocalDateTime? = null,
    val deletedBy: String? = null,
    val warehouseId: String = "",
    val stockReserved: Boolean = false,
) {
    val subTotal: Double get() = lineItems.sumOf { it.lineTotal }
    val dealerDiscountAmt: Double get() = subTotal * (dealerDiscountPct / 100)
    val netAfterDiscount: Double get() = subTotal - dealerDiscountAmt
    val commissionAmt: Double get() = netAfterDiscount * (commissionPct / 100)
    val total: Double get() = netAfterDiscount
}

// ---------- Geotagged CRM ----------

data class GpsPing(val lat: Double, val lng: Double, val timestamp: LocalDateTime, val spoofed: Boolean = false)

data class FieldEmployeeRoute(
    val employeeId: String,
    val employeeName: String,
    val date: LocalDate,
    val breadcrumbs: List<GpsPing>,
)

enum class CampaignChannel { ROBOCALL_BN, SMS, EMAIL }

data class EngagementCampaign(
    val id: String,
    val channel: CampaignChannel,
    val message: String,
    val targetZone: String,
    val sentCount: Int = 0,
)

// ---------- HRM & Payroll ----------

data class PayrollLine(
    val employeeId: String,
    val employeeName: String,
    val basePay: Double,
    val targetAmount: Double,
    val achievedAmount: Double,
    val commissionRate: Double,     // e.g. 0.02 = 2%
    val unapprovedAbsenceDays: Int,
    val dailyWage: Double,
    val overtimeMinutes: Int = 0, // Factory HR — real total from AttendanceRecordEntity.overtimeMinutes for this payroll period
    val overtimePay: Double = 0.0, // pre-computed at close-of-period (rate can change over time; this locks in what was actually paid)
    val attendanceDaysPresent: Int = 0,
    val attendanceDaysAbsent: Int = 0,
) {
    val achievementPct: Double get() = if (targetAmount == 0.0) 0.0 else (achievedAmount / targetAmount) * 100
    val scalingFactor: Double get() = (achievementPct / 100).coerceIn(0.5, 1.5) // 50%-150% curve
    val commission: Double get() = achievedAmount * commissionRate
    val absencePenalty: Double get() = unapprovedAbsenceDays * dailyWage
    val netPayable: Double get() = (basePay * scalingFactor) + commission - absencePenalty + overtimePay
}

// ---------- Credit risk, billing, payments ----------

enum class RiskBand { GREEN, YELLOW, RED }

data class InvoiceLineItem(val name: String, var qty: Double, var unit: String, var unitPrice: Double, var discountPct: Double) {
    val lineTotal: Double get() = qty * unitPrice * (1 - discountPct / 100)
}

data class VoiceInvoice(
    val id: String,
    val dealerId: String,
    val items: MutableList<InvoiceLineItem>,
    var previousDue: Double,
) {
    val subtotal: Double get() = items.sumOf { it.lineTotal }
    val netOutstanding: Double get() = subtotal + previousDue
}

enum class PaymentVerificationStatus { PENDING_VERIFICATION, VERIFIED, REJECTED }

data class PaymentProof(
    val id: String,
    val dealerId: String,
    val amount: Double,
    val proofRef: String, // slip photo / txn id reference
    var status: PaymentVerificationStatus = PaymentVerificationStatus.PENDING_VERIFICATION,
)

// ---------- Factory / production ----------

data class RawMaterialLot(
    val id: String,
    val materialName: String, // "Raw Leaves", "CMC Thickener", "Packaging"
    val qtyKg: Double,
    val costPerKg: Double,
    val purchasedOn: LocalDate,
)

// Phase 6 — Manufacturing HR. Shift/worker assignment kept as its own
// simple model rather than overloading EmployeeAreaAssignment (that one
// is Bangladesh-geography-based; this is production-line/machine-based —
// different axes entirely).
enum class ManufacturingSkill { OPERATOR, HELPER, MIXER, PACKING_OPERATOR, QUALITY_CONTROL, WAREHOUSE_HANDLER, MAINTENANCE }
// Phase 7 — Production-to-Warehouse workflow. Core chain: ProductionPlan
// -> RawMaterialIssue -> (existing ProductionBatch) -> QualityInspection
// -> FinishedGoodsReceipt -> WarehouseTransfer(+Lines) -> DispatchRecord
// -> WarehouseReceipt -> reconciliation (computed from WarehouseReceipt
// fields, not a separate stored entity — the discrepancy is always
// dispatched vs accepted+damaged+missing, derivable at read time).
enum class ProductionPlanStatus { DRAFT, APPROVED, IN_PRODUCTION, COMPLETED, PARTIALLY_COMPLETED, CANCELLED }
enum class QcResult { PENDING, PASSED, CONDITIONALLY_PASSED, FAILED, HOLD, REWORK_REQUIRED }
enum class TransferStatus { DRAFT, SUBMITTED, APPROVED, PICKING, DISPATCHED, IN_TRANSIT, PARTIALLY_RECEIVED, RECEIVED, REJECTED, CANCELLED, RECONCILED }

data class ProductionPlan(
    val id: String,
    val planNumber: String,
    val companyId: String = "",
    val productId: String,
    val variant: String? = null,
    val plannedQuantity: Double,
    val unit: String = "kg",
    val batchNumber: String,
    val productionDate: LocalDate,
    val manufacturingUnitId: String = "",
    val productionLine: String? = null,
    val shiftType: ShiftType = ShiftType.GENERAL,
    val supervisorEmployeeId: String? = null,
    val status: ProductionPlanStatus = ProductionPlanStatus.DRAFT,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class RawMaterialIssue(
    val id: String,
    val productionPlanId: String,
    val companyId: String = "",
    val materialProductId: String,
    val warehouseId: String? = null,
    val binLocation: String? = null,
    val batchCode: String? = null,
    val issuedQuantity: Double,
    val consumedQuantity: Double = 0.0,
    val returnedQuantity: Double = 0.0,
    val wastedQuantity: Double = 0.0,
    val issuedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class QualityInspection(
    val id: String,
    val productionPlanId: String? = null,
    val batchId: String? = null,
    val transferId: String? = null,
    val companyId: String = "",
    val inspector: String = "",
    val testParameters: String? = null,
    val result: QcResult = QcResult.PENDING,
    val sampleQuantity: Double = 0.0,
    val rejectedQuantity: Double = 0.0,
    val comment: String? = null,
    val attachmentUri: String? = null,
    val createdAt: LocalDateTime = LocalDateTime.now(),
) {
    /** Failed or held goods must not become available for sale — enforced at every read site that lists sellable finished-goods stock. */
    val isSellable: Boolean get() = result == QcResult.PASSED || result == QcResult.CONDITIONALLY_PASSED
}

data class PackingRecord(
    val id: String,
    val productionPlanId: String,
    val companyId: String = "",
    val bulkQuantityReceived: Double,
    val packingSize: Double,
    val numberOfPacks: Int,
    val numberOfCartons: Int = 0,
    val looseQuantity: Double = 0.0,
    val damagedPacks: Int = 0,
    val wastageQuantity: Double = 0.0,
    val finalAcceptedQuantity: Double = 0.0,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
) {
    /** Input bulk quantity = packed accepted + damaged + process loss + remaining — any mismatch beyond this tolerance blocks completion (checked by the repository function, not silently accepted here). */
    val reconciliationDelta: Double get() = bulkQuantityReceived - (finalAcceptedQuantity + (damagedPacks * packingSize) + wastageQuantity)
}

// v113-216 — the person's own decision after discussing the QR-conflict
// question directly: not a separate batch QR, and not raw-material QR —
// a per-CARTON QR, since a carton is the real physical unit that actually
// moves through manufacturing -> warehouse -> distribution, distinct from
// the product's own fixed identity QR (that one stays exactly as-is,
// unchanged, still used at Dealer/invoice level). Confirmed as the "full
// version" (real scan-triggered status transitions at each stage), not a
// lighter create-only version.
//
// This also completes something that turned out to be a genuine gap
// hiding in plain sight: "Carton" was already a recognised type in both
// QrRegistry (permission checks) and CodeRegistry (code resolution) —
// but neither had any real Carton record to resolve to. CodeRegistry's
// own "Carton" branch was quietly resolving to a ProductionPlan by its
// batchNumber instead — a stand-in, not a real carton. This is the real
// model that stand-in should have pointed to all along.
enum class CartonStatus { PACKED, WAREHOUSE_RECEIVED, DISPATCHED, DELIVERED }

data class Carton(
    val id: String,
    val cartonCode: String, // human-scannable code, "CTN-" prefixed to match the scanner's own existing prefix convention (CodeRegistry.kt)
    val companyId: String = "",
    val productionPlanId: String,
    val productId: String,
    val productName: String, // denormalized at creation time — avoids a second lookup on every scan, same pattern PartyCollection/RetailOrder already use for partyName/retailerName
    val batchCode: String? = null, // filled in once confirmFinishedGoods assigns one for this same productionPlanId — packing happens before the batch code exists
    val quantityInside: Double,
    val unit: String,
    val status: String = CartonStatus.PACKED.name,
    val packedBy: String = "",
    val packedAt: LocalDateTime = LocalDateTime.now(),
    val warehouseId: String? = null,
    val warehouseReceivedBy: String? = null,
    val warehouseReceivedAt: LocalDateTime? = null,
    val dispatchedTo: String? = null, // free-text: dealer/route/vehicle — whatever the dispatching person actually knows at that moment
    val dispatchedBy: String? = null,
    val dispatchedAt: LocalDateTime? = null,
    val deliveredBy: String? = null,
    val deliveredAt: LocalDateTime? = null,
)

data class FinishedGoodsReceipt(
    val id: String,
    val productionPlanId: String,
    val companyId: String = "",
    val productId: String,
    val batchCode: String,
    val manufacturingDate: LocalDate,
    val expiryDate: LocalDate? = null,
    val quantity: Double,
    val unit: String = "kg",
    val warehouseId: String = "",
    val unitCost: Double = 0.0,
    val qcStatus: QcResult = QcResult.PENDING,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class WarehouseTransferLine(
    val id: String,
    val transferId: String,
    val productId: String,
    val batchCode: String? = null,
    val quantity: Double,
    val unit: String = "kg",
    val cartons: Int = 0,
    val loosePacks: Double = 0.0,
    val dispatchedQuantity: Double = 0.0,
    val receivedQuantity: Double = 0.0,
    val damagedQuantity: Double = 0.0,
    val missingQuantity: Double = 0.0,
    val excessQuantity: Double = 0.0,
    val acceptedQuantity: Double = 0.0,
)

data class WarehouseTransfer(
    val id: String,
    val transferNumber: String,
    val companyId: String = "",
    val sourceWarehouseId: String,
    val destinationWarehouseId: String,
    val lines: List<WarehouseTransferLine> = emptyList(),
    val requestedBy: String = "",
    val approvedBy: String? = null,
    val vehicle: String? = null,
    val driver: String? = null,
    val dispatchDate: LocalDateTime? = null,
    val expectedDeliveryDate: LocalDate? = null,
    val notes: String? = null,
    val status: TransferStatus = TransferStatus.DRAFT,
    val dispatchChallanNumber: String? = null,
    val dispatchedBy: String? = null,
    val dispatchedAt: LocalDateTime? = null,
    val attachmentUri: String? = null,
    val createdAt: LocalDateTime = LocalDateTime.now(),
) {
    /** Section J reconciliation — always derived from the line data actually recorded at receiving, never a separately-tracked and potentially-stale number. */
    val hasDiscrepancy: Boolean get() = lines.any { it.missingQuantity > 0 || it.excessQuantity > 0 }
}

data class WarehouseReceipt(
    val id: String,
    val transferId: String,
    val companyId: String = "",
    val receivingWarehouseId: String,
    val binLocation: String? = null,
    val receiver: String = "",
    val comment: String? = null,
    val proofUri: String? = null,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class ManufacturingWorkerAssignment(
    val id: String,
    val employeeId: String,
    val companyId: String = "",
    val manufacturingUnitId: String = "",
    val productionLine: String? = null,
    val machine: String? = null,
    val section: String? = null,
    val shiftType: ShiftType = ShiftType.GENERAL,
    val supervisorEmployeeId: String? = null,
    val skills: List<ManufacturingSkill> = emptyList(),
    val startDate: LocalDate = LocalDate.now(),
    val endDate: LocalDate? = null,
    val isActive: Boolean = true,
    val assignedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class ProductionBatch(
    val id: String,
    val cycleType: String, // "Spray Dryer 30kg" / "Drum Dryer 30kg"
    val inputKg: Double,
    val outputKg: Double,
    var gatepassReceived: Boolean = false,
)

// ---------- Universal Search ----------
data class UniversalSearchResult(
    val moduleReference: String, // matches UniversalActionMenu's moduleReference convention
    val entityId: String,
    val title: String,
    val subtitle: String,
    val navRoute: String? = null, // matches a Dest.route in NavGraph, if this result type has its own screen
)

/**
 * Universal Search — Deep-Link support. A destination screen (currently
 * DealersScreen for Dealer/Retailer) checks this once on entry and, if it
 * matches, opens that exact record's detail view then clears it — a plain
 * in-memory handoff rather than a NavGraph route argument, so it doesn't
 * require adding parameters to every one of the 20 existing routes.
 */
object PendingSearchNavigation {
    private val _pending = MutableStateFlow<Pair<String, String>?>(null) // moduleReference to entityId
    val pending: StateFlow<Pair<String, String>?> = _pending.asStateFlow()

    fun request(moduleReference: String, entityId: String) { _pending.value = moduleReference to entityId }
    fun consume(moduleReference: String): String? {
        val current = _pending.value ?: return null
        if (current.first != moduleReference) return null
        _pending.value = null
        return current.second
    }
}

// ---------- BI / advisory ----------

data class PrescriptionCard(
    val id: String,
    val title: String,
    val body: String,
    val severity: RiskBand,
)

data class BoardroomQuery(val question: String, val answer: String, val mode: String = "analysis", val askedAt: LocalDateTime = LocalDateTime.now())

// ---------- Task Manager ----------

enum class TaskStatus { PENDING, IN_PROGRESS, COMPLETED, CANCELLED }

data class TaskItem(
    val id: String,
    val title: String,
    val assignee: String,
    var done: Boolean = false,
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
    val deletedAt: LocalDateTime? = null,
    val deletedBy: String? = null,
    val status: TaskStatus = TaskStatus.PENDING, // Task & Activity Management — 4-state status, `done` stays as a derived quick-check (true only when status == COMPLETED)
    val parentTaskId: String? = null, // Sub Tasks — null means this is a top-level task
)

// ---------- Approvals ----------
// Generic approval-request inbox: leave, discount, expense, etc. Distinct
// from the Sales Chain's order verification (SO_LOGGED -> ASM_VERIFIED),
// which is its own dedicated flow — this is for everything else that needs
// a "someone above me signs off" step.

enum class ApprovalType { LEAVE, DISCOUNT, EXPENSE, OTHER }
enum class ApprovalStatus { PENDING, APPROVED, REJECTED }

data class ApprovalRequest(
    val id: String,
    val type: ApprovalType,
    val fromEmployee: String,
    val detail: String,
    var status: ApprovalStatus = ApprovalStatus.PENDING,
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val entityType: String = "", // which structure this approval is about, e.g. "SalesInvoice", "Dealer" — Cascade Approval step needs this link
    val entityId: String = "",
    val level: Int = 1, // multi-level cascade position — Foundation Layer's Cascade Approval step increments this on each hand-off
    val approvedBy: String? = null,
    val approvedAt: LocalDateTime? = null,
    val rejectReason: String? = null,
    val assignedToEmployeeId: String? = null, // Forward/Reassign target — null means "whoever matches the current cascade level/role"
    val escalated: Boolean = false, // Escalate — flags this for the NEXT tier up regardless of normal cascade order
)

// ---------- Backup & Recovery ----------
enum class BackupStatus { IN_PROGRESS, COMPLETED, FAILED, RESTORED }

data class BackupMetadata(
    val id: String,
    val companyId: String,
    val version: String = "v1",
    val collectionsIncluded: Int,
    val fileUrl: String,
    val fileSizeBytes: Long = 0,
    val triggeredBy: String,
    val status: BackupStatus = BackupStatus.COMPLETED,
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val restoredAt: LocalDateTime? = null,
    val restoredBy: String? = null,
)

// ---------- Courier & Logistics ----------

data class CourierPartner(val id: String, val name: String, val hasApi: Boolean, val apiBaseUrl: String? = null, val apiKey: String? = null)

enum class ShipmentStatus { PICKED_UP, IN_TRANSIT, OUT_FOR_DELIVERY, DELIVERED }

data class Shipment(
    val id: String,
    val courierId: String,
    val dealerOrRetailer: String,
    val trackingId: String?,
    var status: ShipmentStatus = ShipmentStatus.PICKED_UP,
)

// ---------- Stock category (Production vs Store split) ----------
// "Company-wide stock across both categories is mainly the Admin/Chairman's
// concern — SR/ASM/TSM mostly only touch the Store side (dealer fulfillment)."
enum class StockCategory { PRODUCTION, STORE, RAW_MATERIAL, WORK_IN_PROGRESS, IN_TRANSIT, DAMAGED_HOLD_RETURNED }

// v86, Module 6 — Stock-Count workflow: Draft -> Submitted -> Approved -> Adjusted.
data class StockCountLine(
    val productId: String,
    val productName: String,
    val batchCode: String? = null, // Batch Wise support — null means this line isn't tracked at batch granularity
    val systemQty: Double,
    val countedQty: Double,
    val systemCartons: Int = 0, // Carton Wise support
    val countedCartons: Int = 0,
) {
    val varianceQty: Double get() = countedQty - systemQty
    val varianceCartons: Int get() = countedCartons - systemCartons
    val variancePct: Double get() = if (systemQty == 0.0) (if (countedQty == 0.0) 0.0 else 100.0) else (varianceQty / systemQty) * 100
    val hasVariance: Boolean get() = varianceQty != 0.0 || varianceCartons != 0
}

data class StockCount(
    val id: String,
    val countNo: String,
    val warehouseId: String,
    val warehouseName: String,
    val lines: List<StockCountLine>,
    val status: String = "DRAFT", // DRAFT | SUBMITTED | APPROVED | ADJUSTED
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val approvedBy: String? = null,
    val approvedAt: LocalDateTime? = null,
)

// ---------- Accounts / Ledger ----------
// NSM+ only — a running record of money in/out, company-wide. Distinct from
// Billing's per-dealer due balance (that's receivables tracking); this is
// the general ledger view: every recorded inflow/outflow with a category.
enum class LedgerEntryType { IN, OUT }

data class LedgerEntry(
    val id: String,
    val type: LedgerEntryType,
    val category: String, // e.g. "Dealer Payment", "Raw Material Purchase", "Payroll", "Utility Bill"
    val description: String,
    val amount: Double,
    val recordedBy: String,
    val division: String? = null, // যিনি entry করেছেন তার বিভাগ — geo-scoped ভিউয়ের জন্য; null মানে company-wide/central entry
    val recordedAt: LocalDateTime = LocalDateTime.now(),
)

// ================= Module 11: Accounts & Finance =================
// A real double-entry layer sitting alongside the existing single-entry
// LedgerEntry above (which stays, unchanged, for the quick IN/OUT recording
// already used elsewhere in the app). Vouchers are the authoritative source
// for the new Trial Balance / P&L / Balance Sheet reports this module adds.

enum class AccountType { ASSET, LIABILITY, EQUITY, INCOME, EXPENSE }

data class ChartOfAccount(
    val id: String,
    val code: String, // e.g. "1000" Cash, "2000" Accounts Payable — conventional numbering by type band
    val name: String,
    val type: AccountType,
    val parentId: String? = null,
    val isActive: Boolean = true,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

enum class VoucherType { PAYMENT, RECEIPT, JOURNAL, CONTRA }

data class VoucherLine(
    val accountId: String,
    val accountName: String,
    val debit: Double = 0.0,
    val credit: Double = 0.0,
    val costCenter: String? = null,
    val isReconciled: Boolean = false, // v86 - Bank Reconciliation basic support (JSON-packed, no migration)
)

data class Voucher(
    val id: String,
    val voucherNo: String,
    val type: VoucherType,
    val voucherDate: LocalDateTime = LocalDateTime.now(),
    val narration: String = "",
    val lines: List<VoucherLine>,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
) {
    val totalDebit: Double get() = lines.sumOf { it.debit }
    val totalCredit: Double get() = lines.sumOf { it.credit }
    /** Core double-entry integrity rule — every voucher's debits must equal its credits before it's allowed to post. */
    val isBalanced: Boolean get() = kotlin.math.abs(totalDebit - totalCredit) < 0.01
}

/** One row of the Trial Balance report — a single account's net debit/credit position across every posted voucher. */
data class TrialBalanceRow(val account: ChartOfAccount, val totalDebit: Double, val totalCredit: Double) {
    val netDebit: Double get() = (totalDebit - totalCredit).coerceAtLeast(0.0)
    val netCredit: Double get() = (totalCredit - totalDebit).coerceAtLeast(0.0)
}

// ================= Module 5: Purchase Management =================

data class Supplier(
    val id: String,
    val name: String,
    val phone: String = "",
    val address: String = "",
    var dueBalance: Double = 0.0, // Supplier Due — what WE owe them
    val creditLimit: Double = 0.0, // credit terms they've extended to us
    val dedupKey: String = "",
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val deletedAt: LocalDateTime? = null,
    val deletedBy: String? = null,
)

data class PurchaseLineItem(val productId: String, val name: String, val unit: String, val qty: Double, val unitCost: Double) {
    val lineTotal: Double get() = qty * unitCost
}

// v86, Module 7 — Purchase Requisition: the missing first step of
// "Purchase Request -> Approval -> Purchase Order -> GRN -> ...". Reuses
// PurchaseLineItem (unitCost simply isn't meaningful yet at request stage,
// defaults to 0) rather than inventing a parallel line-item type.
data class SupplierQuote(val supplierId: String, val supplierName: String, val quotedAmount: Double, val notes: String = "")

data class PurchaseRequest(
    val id: String,
    val requestNo: String,
    val lineItems: List<PurchaseLineItem>,
    val requiredByDate: LocalDateTime? = null,
    val reason: String = "",
    val status: String = "PENDING", // PENDING | APPROVED | REJECTED | CONVERTED (a PO was created from it)
    val convertedToPoId: String? = null,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val approvedBy: String? = null,
    val approvedAt: LocalDateTime? = null,
    val rejectReason: String? = null,
    val isDeleted: Boolean = false,
    val supplierQuotes: List<SupplierQuote> = emptyList(), // v86 - RFQ: real supplier quotes recorded for comparison before PO conversion
)

data class PurchaseOrder(
    val id: String,
    val poNo: String,
    val supplierId: String,
    val supplierName: String,
    val lineItems: List<PurchaseLineItem>,
    val status: String = "DRAFT", // DRAFT | SENT | PARTIALLY_RECEIVED | RECEIVED | CANCELLED
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
) {
    val subTotal: Double get() = lineItems.sumOf { it.lineTotal }
}

// Goods Received Note — confirms what actually arrived against a PO (may
// differ from what was ordered); this is what actually triggers stock-in
// and the supplier due balance increase, not the PO itself.
data class GoodsReceivedNote(
    val id: String,
    val grnNo: String,
    val purchaseOrderId: String,
    val supplierId: String,
    val supplierName: String,
    val receivedItems: List<PurchaseLineItem>,
    val warehouseId: String,
    val receivedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
) {
    val totalValue: Double get() = receivedItems.sumOf { it.lineTotal }
}

data class PurchaseReturn(
    val id: String,
    val returnNo: String,
    val purchaseOrderId: String? = null,
    val supplierId: String,
    val supplierName: String,
    val lineItems: List<PurchaseLineItem>,
    val reason: String = "",
    val refundAmount: Double = 0.0,
    val status: String = "PENDING",
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
)

// ================= Module 3: Inventory extras =================

data class ProductCategory(val id: String, val name: String, val isActive: Boolean = true)
data class ProductBrand(val id: String, val name: String, val isActive: Boolean = true)

// A stock-in event with an expiry date creates one of these; stockOut/damage
// consumes from the oldest non-expired lot first (FEFO — first-expiry-first-out).
data class InventoryLot(
    val id: String,
    val productId: String,
    val warehouseId: String,
    val batchCode: String,
    val qtyRemaining: Double,
    val expiryDate: LocalDateTime? = null,
    val receivedAt: LocalDateTime = LocalDateTime.now(),
)

data class DamageReport(
    val id: String,
    val productId: String,
    val productName: String,
    val warehouseId: String,
    val qty: Double,
    val reason: String,
    val reportedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class StockTransfer(
    val id: String,
    val productId: String,
    val productName: String,
    val fromWarehouseId: String,
    val toWarehouseId: String,
    val qty: Double,
    val status: String = "COMPLETED", // this app's warehouses are all company-owned, so transfers post immediately
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ================= Module 2: Manufacturing & Production extras =================

data class BomLine(val rawMaterialName: String, val qtyPerUnit: Double, val unit: String)

// Bill of Materials — "to make 1 unit of finished product X, you need these raw materials".
data class BillOfMaterials(
    val id: String,
    val finishedProductName: String,
    val lines: List<BomLine>,
    val laborCostPerUnit: Double = 0.0,
    val overheadCostPerUnit: Double = 0.0,
    val isActive: Boolean = true,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class ProductionOrder(
    val id: String,
    val orderNo: String,
    val bomId: String,
    val finishedProductName: String,
    val targetQty: Double,
    val status: String = "PLANNED", // PLANNED | IN_PROGRESS | COMPLETED | CANCELLED
    val scheduledDate: LocalDateTime,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class QualityCheck(
    val id: String,
    val batchId: String,
    val result: String, // "PASS" | "FAIL"
    val notes: String = "",
    val checkedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class ProductionLoss(
    val id: String,
    val batchId: String,
    val qtyLost: Double,
    val reason: String,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class MachineLog(
    val id: String,
    val machineName: String,
    val batchId: String? = null,
    val hoursUsed: Double,
    val notes: String = "",
    val recordedAt: LocalDateTime = LocalDateTime.now(),
)

// ================= Module 6: CRM (Lead/Opportunity/Communication History) =================

enum class LeadStatus { NEW, CONTACTED, QUALIFIED, VISIT_PLANNED, NEGOTIATION, CONVERTED, LOST }

// v86, Module 15 — Customer Complaints. Deliberately a SEPARATE model from
// FirebaseSync.kt's ComplaintRecord: that one is the internal, anonymous
// employee-to-Chairman grievance box (fromRole/fromName/anonymous fields
// make that clear). This is the customer/dealer PRODUCT complaint workflow
// the spec asks for — different data, different audience, different
// lifecycle. Conflating them would leak internal grievances into a
// dealer-facing timeline or vice-versa.
enum class CustomerComplaintStatus { NEW, ASSIGNED, INVESTIGATING, RESOLVED, CLOSED, REJECTED }

data class CustomerComplaint(
    val id: String,
    val complaintNo: String,
    val dealerId: String,
    val dealerName: String,
    val productId: String? = null,
    val productName: String? = null,
    val invoiceId: String? = null,
    val invoiceNo: String? = null,
    val category: String = "OTHER", // e.g. "QUALITY" | "QUANTITY" | "DELIVERY" | "BILLING" | "OTHER"
    val description: String,
    val priority: String = "NORMAL", // "LOW" | "NORMAL" | "HIGH" | "URGENT"
    val status: CustomerComplaintStatus = CustomerComplaintStatus.NEW,
    val assignedEmployeeId: String? = null,
    val assignedEmployeeName: String? = null,
    val resolutionNote: String? = null,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val resolvedAt: LocalDateTime? = null,
    val isDeleted: Boolean = false,
    // v113-75 — RMS retailer complaints, additive. See CustomerComplaintEntity for why
    // this isn't a generic partyId/partyName shape.
    val partyType: PartyType = PartyType.DEALER,
    val retailerId: String? = null,
    val retailerName: String? = null,
)

data class Lead(
    val id: String,
    val name: String,
    val phone: String = "",
    val source: String = "", // e.g. "Market visit", "Referral", "Cold call"
    val status: LeadStatus = LeadStatus.NEW,
    val assignedTo: String = "",
    val notes: String = "",
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
)

data class Opportunity(
    val id: String,
    val leadId: String? = null,
    val title: String,
    val estimatedValue: Double = 0.0,
    val stage: String = "PROSPECTING", // PROSPECTING | NEGOTIATION | WON | LOST
    val assignedTo: String = "",
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class CustomerSegment(val id: String, val name: String, val criteria: String = "")

/** Communication History — a call, tied optionally to a Lead or an existing Dealer/Retailer. */
data class CallLog(
    val id: String,
    val leadId: String? = null,
    val partyType: PartyType? = null,
    val partyId: String? = null,
    val contactName: String = "",
    val phone: String = "",
    val durationMinutes: Int = 0,
    val notes: String = "",
    val loggedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class MeetingLog(
    val id: String,
    val title: String,
    val attendees: String = "",
    val notes: String = "",
    val meetingDate: LocalDateTime = LocalDateTime.now(),
    val loggedBy: String = "",
)

data class FollowUp(
    val id: String,
    val leadId: String? = null,
    val note: String = "",
    val dueDate: LocalDateTime,
    val done: Boolean = false,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ================= Module 12: HR & Payroll extras =================

enum class LeaveType { CASUAL, SICK, EARNED, UNPAID }
enum class ShiftType { MORNING, EVENING, NIGHT, GENERAL }
enum class LeaveStatus { PENDING, APPROVED, REJECTED }

data class LeaveRequest(
    val id: String,
    val employeeId: String,
    val employeeName: String,
    val type: LeaveType,
    val fromDate: LocalDate,
    val toDate: LocalDate,
    val reason: String = "",
    val status: LeaveStatus = LeaveStatus.PENDING,
    val createdAt: LocalDateTime = LocalDateTime.now(),
) {
    val days: Long get() = java.time.temporal.ChronoUnit.DAYS.between(fromDate, toDate) + 1
}

/** Increment / Promotion / Transfer / Exit — one shared "employee lifecycle event" shape, distinguished by type, matching how Approval/Audit already unify similar concepts elsewhere in this app. */
data class EmployeeLifecycleEvent(
    val id: String,
    val employeeId: String,
    val employeeName: String,
    val type: String, // "INCREMENT" | "PROMOTION" | "TRANSFER" | "EXIT"
    val oldValue: String = "",
    val newValue: String = "",
    val effectiveDate: LocalDate,
    val notes: String = "",
    val recordedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ================= Module 14: Communication Hub =================

data class ChatMessage(
    val id: String,
    val channelId: String, // "general", "dept-sales", "dept-accounts" ... or a "dm-<id1>-<id2>" direct-message key
    val senderId: String,
    val senderName: String,
    val message: String,
    val attachmentUri: String? = null,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class Announcement(
    val id: String,
    val title: String,
    val body: String,
    val postedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
)

data class Circular(
    val id: String,
    val title: String,
    val body: String,
    val department: String? = null, // null = company-wide
    val postedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
)

// ================= Module 13: Logistics — Vehicle Tracking =================

data class Vehicle(
    val id: String,
    val registrationNo: String,
    val vehicleType: String = "Truck", // Truck | Van | Motorcycle
    val driverName: String = "",
    val driverPhone: String = "",
    val isActive: Boolean = true,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class VehicleLocationPing(
    val id: String,
    val vehicleId: String,
    val lat: Double,
    val lng: Double,
    val speedKmh: Double = 0.0,
    val recordedAt: LocalDateTime = LocalDateTime.now(),
)

// ================= Module 16: AI & Automation — Sales Forecast =================

/** Simple moving-average-based projection — not a full ML model, but a real computed number from actual historical sales rather than static/canned text. */
data class SalesForecastResult(
    val scopeName: String, // e.g. dealer name or zone name
    val last90DaySales: Double,
    val dailyAverage: Double,
    val projectedNext30Days: Double,
    val trend: String, // "GROWING" | "STABLE" | "DECLINING"
)

// ================= AI Framework additions (Module 16) =================

data class BusinessHealthScore(
    val score: Int, // 0-100
    val label: String, // "Excellent" | "Good" | "Fair" | "Poor"
    val salesTrendComponent: Int,
    val collectionComponent: Int,
    val stockHealthComponent: Int,
    val riskComponent: Int,
)

data class RiskAlert(
    val id: String,
    val severity: RiskBand,
    val category: String, // "Dealer Credit" | "Inventory" | "Collection" | "Approval Backlog"
    val message: String,
)

data class DemandForecastRow(val productName: String, val avgDailyDemand: Double, val projectedNext30Days: Double)

/** Universal Action Menu's "Activity Log" — the read-side domain shape for AuditLogEntity, mirrors logAudit()'s write side. */
data class AuditLogEntry(
    val id: String,
    val entityType: String,
    val entityId: String,
    val action: String,
    val performedBy: String,
    val performedByRole: String,
    val oldValueJson: String? = null,
    val newValueJson: String? = null,
    val reason: String? = null, // v88 fix, Foundation 2 Section 18 — was only ever embedded inside newValueJson as free text; now a real, separately queryable field
    val relatedApprovalId: String? = null, // v88 fix — "Related approval reference" was missing entirely
    val deviceId: String? = null, // Section 11 — which physical device performed this
    val gpsLat: Double? = null, // Section 11 — where, if location was available at the time
    val gpsLng: Double? = null,
    val syncStatus: String = "PENDING", // "PENDING" | "SYNCED" | "FAILED" — real sync-confirmation state, not assumed
    val timestamp: LocalDateTime = LocalDateTime.now(),
)

// ---------- Notification Framework ----------
// A persisted in-app notification record — connects business events
// (approval, collection, dealer/retailer registration, leave, etc.) to a
// real inbox entry, distinct from the live-computed alerts (low stock,
// vacancy) NotificationsScreen already surfaces from other tables directly.
// Actual OS push delivery to a specific device still needs the Cloud
// Functions deploy (pending Blaze plan, per SETUP_FIREBASE.md) — this is
// the client-side half: the record gets created and synced regardless,
// ready for a Cloud Function to also push it once deployed.
enum class NotificationCategory { APPROVAL, COLLECTION, PAYMENT, SALES_ORDER, DELIVERY, PRODUCTION, LOW_STOCK, ATTENDANCE, LEAVE, COMPLAINT, DEALER_REGISTRATION, RETAILER_REGISTRATION, INVOICE, PURCHASE_ORDER, GOODS_RECEIPT, QUALITY_CHECK, STOCK_TRANSFER, HELPDESK, TASK, ALERT }

data class NotificationEntry(
    val id: String,
    val category: NotificationCategory,
    val title: String,
    val body: String,
    val targetEmployeeId: String? = null, // null = broadcast to whoever's permission scope covers it
    // v113-224 — the person's own explicit request for the Notice board:
    // "text or photo". createNotification is called from dozens of places
    // across this app for ordinary system alerts, so this stays optional
    // and unused by every one of them — only the Chairman Notice Board's
    // own send flow actually populates it.
    val imageUri: String? = null,
    val isRead: Boolean = false,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)
