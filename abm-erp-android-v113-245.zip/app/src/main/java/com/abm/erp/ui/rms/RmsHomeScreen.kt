package com.abm.erp.ui.rms

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.core.ModuleDrawerItem
import com.abm.erp.core.ModuleDrawerScaffold
import com.abm.erp.core.rememberVisibleDealers
import com.abm.erp.core.rememberVisibleRetailers
import com.abm.erp.data.MockRepository
import com.abm.erp.data.createRetailerComplaint
import com.abm.erp.data.rejectCollection
import com.abm.erp.data.verifyCollection
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import kotlinx.coroutines.launch

/**
 * RMS — Retailer Management System. Mother module #2.
 *
 * Same shell as DMS, deliberately different options — per the person's draft and his
 * follow-up corrections:
 *  - QR Center / Universal Features / Cascade & Geo Rule are **not** drawer items.
 *    Those are back-end logic (QR resolve, permission scope, sync); there is nothing
 *    to display, so nothing is displayed.
 *  - Settings and Help & Support removed as unnecessary.
 *  - Retailer Stock added: retailer stock must be tracked, otherwise proper sales
 *    reporting is impossible. It is **independent of dealer stock** — the app keeps
 *    four separate stock worlds: Dealer, Retailer, Factory, Warehouse (the last two
 *    get built inside FMS).
 *  - Approvals here are small-scale: retailer memo approval is done by the TSM of
 *    that geo area, not the multi-level cascade a dealer invoice goes through.
 */
private val RMS_COLOR_START = 0xFF0EA5A4
private val RMS_COLOR_END = 0xFF0F766E

private val RMS_ITEMS_BASE = listOf(
    ModuleDrawerItem("dashboard", "Dashboard", Icons.Filled.Home, "সারসংক্ষেপ"),
    ModuleDrawerItem("order", "Order (Memo)", Icons.Filled.Description, "Memo / Order Create"),
    ModuleDrawerItem("relation", "Relation (CRM)", Icons.Filled.Forum, "Connect & Grow Relation"),
    ModuleDrawerItem("list", "List", Icons.Filled.ListAlt, "Retailer History & Analysis"),
    ModuleDrawerItem("add", "Retailer Add", Icons.Filled.PersonAdd, "Add New Retailer"),
    ModuleDrawerItem("stock", "Retailer Stock", Icons.Filled.Inventory2, "Retailer Stock Control"),
    ModuleDrawerItem("complaint", "Complaint", Icons.Filled.ReportProblem, "Customer Complaints"),
    ModuleDrawerItem("finance", "Finance", Icons.Filled.Payments, "Due & Collection"),
    ModuleDrawerItem("approve", "Approvals", Icons.Filled.FactCheck, "TSM memo approval"),
    ModuleDrawerItem("report", "Report", Icons.Filled.InsertChart, "Reports & Analytics"),
)

// v113-172 — same reorganization as HR/DMS: Retailer Control (moved from the
// central Chairman module's "parties" item, retailer half) and Retailer
// Restore (moved from the old "master" Master Controller) now live here.
private val RMS_CHAIRMAN_ITEM = ModuleDrawerItem("chairman", "Chairman", Icons.Filled.Star, "Approvals · Retailer Control · Restore")

@Composable
fun RmsHomeScreen(
    startKey: String? = null,
    onBackToHome: () -> Unit = {},
    onNavigate: (String) -> Unit = {},
) {
    var selected by remember { mutableStateOf(startKey ?: "dashboard") }
    val dealersVm: com.abm.erp.ui.dealer.DealersScreenViewModel = viewModel()
    val retailers = rememberVisibleRetailers()
    val dealers = rememberVisibleDealers()
    val orders by MockRepository.orders.collectAsState()
    val isChairman = MockRepository.currentUser.role == com.abm.erp.data.UserRole.CHAIRMAN
    val items = if (isChairman) RMS_ITEMS_BASE + RMS_CHAIRMAN_ITEM else RMS_ITEMS_BASE
    // v113-211 — same full-screen-document request as DMS's Invoice
    // workspace, same reasoning and same mechanism.
    var fullScreenDocument by remember { mutableStateOf(false) }

    ModuleDrawerScaffold(
        moduleName = "RMS",
        moduleSubtitle = "Retailer Management System",
        colorStart = RMS_COLOR_START,
        colorEnd = RMS_COLOR_END,
        moduleIcon = Icons.Filled.Store,
        items = items,
        selectedKey = selected,
        onSelect = { selected = it },
        onBackToHome = onBackToHome,
        hideTopBar = fullScreenDocument && selected == "order",
    ) { key ->
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            when (key) {
                "dashboard" -> RmsDashboard(retailers)
                // v113-80 — workspace contract: the whole memo operation in one screen,
                // linked to a real Retailer record (which is what makes the v113-75
                // retailer-stock pipeline actually run). Legacy free-text RetailerTab
                // keeps serving the old Sales suite until the strip-down.
                "order" -> RmsMemoWorkspace(onNavigate, onViewingDocumentChange = { fullScreenDocument = it })
                // v113-85 — same approved browse pattern as DMS, via the shared engine.
                "list" -> com.abm.erp.core.ModuleBrowseList(
                    config = com.abm.erp.core.rememberRetailerBrowseConfig(
                        markets = remember(retailers) { retailers.map { it.market }.filter { it.isNotBlank() }.distinct().sorted() },
                    ),
                    records = retailers,
                    onBack = { selected = "dashboard" },
                    onNavigate = onNavigate,
                )
                "add" -> com.abm.erp.ui.dealer.AddRetailerForm(dealersVm, dealers) { selected = "list" }
                "approve" -> RmsApprove(orders, dealers)
                "stock" -> RmsRetailerStockPicker(retailers, onNavigate)
                "complaint" -> RmsComplaintsTab(retailers)
                "finance" -> com.abm.erp.core.CollectionWorkspace(
                    partyType = com.abm.erp.data.PartyType.RETAILER, partyLabel = "Retailer",
                    parties = remember(retailers) { retailers.map { com.abm.erp.core.CollectionParty(it.id, it.name, it.market.orEmpty(), it.dueBalance) } },
                    onNavigate = onNavigate,
                )
                "relation" -> com.abm.erp.core.PartyCampaignSection(
                    audienceLabel = "Retailer",
                    zones = remember(retailers) { retailers.mapNotNull { it.market }.filter { it.isNotBlank() }.distinct().sorted() },
                )
                "report" -> RmsReportTab(retailers, orders)
                "chairman" -> if (isChairman) RmsChairmanPanel(onNavigate) else RmsDashboard(retailers)
                else -> RmsDashboard(retailers)
            }
        }
    }
}

@Composable
private fun RmsChairmanPanel(onNavigate: (String) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Approvals") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Retailer Control") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Restore") })
        }
        when (tab) {
            0 -> RmsApprovalsPanel()
            1 -> {
                // v113-172 — moved from the central Chairman module's "parties" item
                // (retailer half — dealer half is DMS's own Chairman tab).
                // v113-201 — same missing-parameter bug as DMS's Dealer Control tab
                // (see that file's v113-201 note for the full trace); fixed the same way.
                val retailers = rememberVisibleRetailers()
                com.abm.erp.core.ModuleBrowseList(
                    config = com.abm.erp.core.rememberRetailerBrowseConfig(
                        markets = remember(retailers) { retailers.map { it.market }.filter { it.isNotBlank() }.distinct().sorted() },
                    ),
                    records = retailers,
                    onBack = {},
                    onNavigate = onNavigate,
                )
            }
            else -> Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
                Text("Soft-deleted রেকর্ড দেখা ও restore — hard delete এই অ্যাপে নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Spacer(Modifier.height(8.dp))
                com.abm.erp.ui.chairmanmodule.RmsRetailerRestoreSection()
            }
        }
    }
}

/**
 * v113-179 — same pattern as DMS's DmsApprovalsPanel: Retailer Add pending
 * approval + Retailer Cancellation, one clean approval-focused view instead
 * of scattered inline actions. Reuses the existing approveRetailer/
 * rejectRetailer/deleteRetailer functions (broader GM/MD/AGM/Chairman tier,
 * unchanged) — previously only reachable via the legacy DealersScreen.
 */
@Composable
private fun RmsApprovalsPanel() {
    val retailers by MockRepository.retailers.collectAsState()
    val collections by MockRepository.partyCollections.collectAsState()
    val orders by MockRepository.orders.collectAsState()
    val dealers by MockRepository.dealers.collectAsState()
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    val pendingRetailers = remember(retailers) { retailers.filter { !it.isDeleted && !it.isActive && it.onboardingStatus == "PENDING_APPROVAL" } }
    val activeRetailers = remember(retailers) { retailers.filter { !it.isDeleted && it.isActive } }
    // v113-202 — was missing entirely: verifyCollection/rejectCollection in
    // CollectionsEngine.kt already fully support PartyType.RETAILER (traced
    // the actual function body, not assumed) — RMS's own Approvals panel
    // simply never surfaced a way to reach them, unlike DMS's identical
    // "Dealer Collections" section a few lines below in DmsHomeScreen.kt.
    // Same functions, same pattern, just the retailer half of it.
    val pendingCollections = remember(collections) { collections.filter { it.status == "PENDING" && it.partyType == com.abm.erp.data.PartyType.RETAILER } }
    // v113-207 — the biggest gap found this pass: verifying a Memo and
    // routing it to a dealer (advanceOrder, OrderStage.SO_LOGGED →
    // DEALER_ROUTED) lived ONLY in SalesChainScreen.kt's AsmVerifyTab — a
    // completely different module — with not even a pointer inside RMS
    // itself (unlike DMS, which at least had an explanatory count card).
    // Same logic copied here verbatim from AsmVerifyTab: nearest dealer by
    // matching zone, falling back to any dealer if none match exactly.
    val pendingMemos = remember(orders) { orders.filter { it.stage == com.abm.erp.data.OrderStage.SO_LOGGED } }

    fun toast(msg: String) = android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()

    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Text("Retailer Add (${pendingRetailers.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingRetailers.isEmpty()) Text("কোনো pending retailer নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingRetailers.forEach { r ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(r.market.orEmpty(), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { scope.launch { MockRepository.approveRetailer(r.id, onRejected = { reason -> toast(reason) }) } }) { Text("Approve") }
                    TextButton(onClick = { scope.launch { MockRepository.rejectRetailer(r.id, "Rejected by Chairman", onRejected = { reason -> toast(reason) }) } }) { Text("Reject", color = DangerRed) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Memo Verification (${pendingMemos.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingMemos.isEmpty()) Text("কোনো pending memo নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingMemos.take(30).forEach { order ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Text("${order.retailerName} · ${order.zone}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text(order.items, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                Text("৳${"%,.0f".format(order.amount)}", color = TextPrimary, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                val nearestDealer = remember(dealers, order.zone) { dealers.firstOrNull { it.zone == order.zone } ?: dealers.firstOrNull() }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (nearestDealer == null) {
                        Text("কোনো dealer নেই — route করা যাচ্ছে না।", color = WarningAmber, style = MaterialTheme.typography.labelSmall)
                    } else {
                        TextButton(onClick = { MockRepository.advanceOrder(order.id, com.abm.erp.data.OrderStage.DEALER_ROUTED, nearestDealer.id) }) {
                            Text("Verify → ${nearestDealer.name}")
                        }
                    }
                    TextButton(onClick = { MockRepository.advanceOrder(order.id, com.abm.erp.data.OrderStage.REJECTED) }) { Text("Reject", color = DangerRed) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Retailer Cancellation", fontWeight = FontWeight.Bold, color = TextPrimary)
        Text("সক্রিয় retailer বাতিল করুন — soft delete, পুনরুদ্ধার Restore tab থেকে সম্ভব।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        var cancelQuery by remember { mutableStateOf("") }
        OutlinedTextField(value = cancelQuery, onValueChange = { cancelQuery = it }, placeholder = { Text("Retailer নাম খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        activeRetailers.filter { cancelQuery.isBlank() || it.name.contains(cancelQuery, true) }.take(20).forEach { r ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(r.name, color = TextPrimary, modifier = Modifier.weight(1f))
                    TextButton(onClick = { scope.launch { MockRepository.deleteRetailer(r.id, onRejected = { reason -> toast(reason) }) } }) { Text("Cancel", color = DangerRed) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Retailer Collections (${pendingCollections.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingCollections.isEmpty()) Text("কোনো pending collection নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingCollections.forEach { c ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.partyName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("৳${"%,.0f".format(c.amount)} · ${c.method}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { scope.launch { MockRepository.verifyCollection(c.id, onRejected = { r -> toast(r) }) } }) { Text("Verify") }
                    TextButton(onClick = { scope.launch { MockRepository.rejectCollection(c.id, onRejected = { r -> toast(r) }) } }) { Text("Reject", color = DangerRed) }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun RmsDashboard(retailers: List<com.abm.erp.data.Retailer>) {
    val orders by MockRepository.orders.collectAsState()
    val visits by MockRepository.visitLogs.collectAsState()
    val today = java.time.LocalDate.now()
    val totalDue = remember(retailers) { retailers.sumOf { it.dueBalance } }
    val todayOrders = remember(orders) { orders.count { it.loggedAt.toLocalDate() == today } }
    val todayVisits = remember(visits) { visits.count { it.checkInAt.toLocalDate() == today } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("RMS Overview", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(4.dp))
        Text(
            "আপনার cascade scope অনুযায়ী — অন্য এলাকার retailer এখানে গোনা হয় না।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(12.dp))
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            RmsStatRow("Retailer", "${retailers.size}", TextPrimary)
            RmsStatRow("Total Due", "৳${"%,.0f".format(totalDue)}", if (totalDue > 0) WarningAmber else SuccessGreen)
            RmsStatRow("আজকের Memo", "$todayOrders", TextPrimary)
            RmsStatRow("আজকের Visit", "$todayVisits", TextPrimary)
        }
        // v113-140 — KPI graphic for RMS, same shared chart as DMS/Chairman.
        // Retailer-shaped series: Memo (RetailOrder) vs verified Collection, both
        // restricted to the retailers already in this user's cascade scope.
        val rmsCollections by MockRepository.partyCollections.collectAsState()
        val rmsWeekly = remember(orders, rmsCollections, retailers) {
            // RetailOrder.retailerId is NULLABLE (orders taken before the retailer
            // link existed carry only retailerName) — matching this file's own
            // existing fallback rather than dropping those older orders silently.
            val myNames = retailers.map { it.name }.toSet()
            val myIds = retailers.map { it.id }.toSet()
            val t = java.time.LocalDate.now()
            val monday = t.minusDays((t.dayOfWeek.value - 1).toLong())
            (4 downTo 0).map { w ->
                val start = monday.minusWeeks(w.toLong())
                val end = start.plusDays(7)
                val memo = orders.filter { o ->
                    (o.retailerId?.let { it in myIds } ?: (o.retailerName in myNames)) &&
                        !o.loggedAt.toLocalDate().isBefore(start) && o.loggedAt.toLocalDate().isBefore(end)
                }.sumOf { it.amount }
                val col = rmsCollections.filter { it.status == "VERIFIED" && it.partyId in myIds && !it.createdAt.toLocalDate().isBefore(start) && it.createdAt.toLocalDate().isBefore(end) }
                    .sumOf { it.amount }
                Triple("${start.dayOfMonth}/${start.monthValue}", memo, col)
            }
        }
        if (rmsWeekly.any { it.second > 0.0 || it.third > 0.0 }) {
            Spacer(Modifier.height(12.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Memo vs Collection — Last 5 Weeks", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                com.abm.erp.core.DualSeriesBarChart(rmsWeekly, "Memo", "Collection")
            }
        }
    }
}

@Composable
private fun RmsStatRow(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Text(value, fontWeight = FontWeight.Bold, color = color)
    }
}

/**
 * v113-75 — retailer picker → drill into RetailerStockScreen. Same "search then pick"
 * shape as DMS's dealer picker lists, so both mother modules behave consistently.
 */
@Composable
private fun RmsRetailerStockPicker(
    retailers: List<com.abm.erp.data.Retailer>,
    onNavigate: (String) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(retailers, query) {
        if (query.isBlank()) retailers
        else retailers.filter { it.name.contains(query, true) || it.market.orEmpty().contains(query, true) }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text("নাম বা market দিয়ে খুঁজুন…") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(10.dp))
        // v113-136 (Phase 13) — list-level empty states use the shared
        // WorkspaceEmptyState so all five modules present "nothing here" the same
        // way (icon chip + one sentence), instead of a bare left-aligned Text.
        if (filtered.isEmpty()) com.abm.erp.core.WorkspaceEmptyState("আপনার এলাকায় কোনো retailer নেই।")
        androidx.compose.foundation.lazy.LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { r ->
                com.abm.erp.core.ModuleDrillRow(r.name, r.market.orEmpty()) {
                    onNavigate("retailer_stock/${r.id}")
                }
            }
        }
    }
}

/**
 * v113-75 — RMS's Complaint card. Mirrors CRM's CustomerComplaintsTab, filtered to
 * `partyType == RETAILER` instead of dealer complaints, and uses
 * `createRetailerComplaint` (v113-75) rather than `createCustomerComplaint`.
 */
@Composable
private fun RmsComplaintsTab(retailers: List<com.abm.erp.data.Retailer>) {
    val allComplaints by MockRepository.customerComplaints.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    var statusFilter by remember { mutableStateOf<com.abm.erp.data.CustomerComplaintStatus?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    val filtered = remember(allComplaints, statusFilter, searchQuery) {
        allComplaints.filter { c ->
            c.partyType == com.abm.erp.data.PartyType.RETAILER &&
                (statusFilter == null || c.status == statusFilter) &&
                (searchQuery.isBlank() || c.retailerName.orEmpty().contains(searchQuery, ignoreCase = true) || c.complaintNo.contains(searchQuery, ignoreCase = true) || c.description.contains(searchQuery, ignoreCase = true))
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text("Customer Complaints", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Button(onClick = { showNew = true }) { Text("+ New") }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = searchQuery, onValueChange = { searchQuery = it }, placeholder = { Text("খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = statusFilter == null, onClick = { statusFilter = null }, label = { Text("সব") })
            com.abm.erp.data.CustomerComplaintStatus.values().forEach { s ->
                FilterChip(selected = statusFilter == s, onClick = { statusFilter = s }, label = { Text(s.name) })
            }
        }
        Spacer(Modifier.height(10.dp))
        if (filtered.isEmpty()) com.abm.erp.core.WorkspaceEmptyState("কোনো retailer complaint নেই।")
        androidx.compose.foundation.lazy.LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered, key = { it.id }) { c ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(c.complaintNo, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        com.abm.erp.core.StatusPill(c.status.name)
                    }
                    Text(c.retailerName.orEmpty(), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(c.description, style = MaterialTheme.typography.bodySmall)
                    com.abm.erp.core.WaitingAge(c.createdAt)
                }
            }
        }
    }

    if (showNew) {
        var selectedRetailerId by remember { mutableStateOf<String?>(null) }
        var description by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("QUALITY") }
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
                    Text("New Complaint", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Retailer", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Column(Modifier.heightIn(max = 140.dp).verticalScroll(rememberScrollState())) {
                        if (retailers.isEmpty()) {
                            Text("আপনার এলাকায় কোনো retailer নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        retailers.forEach { r ->
                            Text(
                                r.name,
                                fontWeight = if (selectedRetailerId == r.id) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.fillMaxWidth().clickable { selectedRetailerId = r.id }.padding(vertical = 6.dp),
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("QUALITY", "QUANTITY", "DELIVERY", "BILLING", "OTHER").forEach { cat ->
                            FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat, style = MaterialTheme.typography.labelSmall) })
                        }
                    }
                    var complaintError by remember { mutableStateOf<String?>(null) }
                    complaintError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val r = retailers.firstOrNull { it.id == selectedRetailerId }
                            if (r != null && description.isNotBlank()) {
                                val created = MockRepository.createRetailerComplaint(r.id, r.name, description, category, onRejected = { e -> complaintError = e })
                                if (created != null) showNew = false
                            }
                        },
                        enabled = selectedRetailerId != null && description.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Submit") }
                }
            }
        }
    }
}

/**
 * Retailer memo approval — v113-77, the gate is now REAL, per the person's rule:
 * "Geo rule wise oi arear TSM-e korbe" — only the TSM whose geo covers the order's
 * zone approves; not any TSM, not the dealer-invoice cascade. Chairman passes as the
 * universal observer/actor. Everyone else sees the list read-only with the reason
 * stated, and `advanceOrder` has no extra hidden gate — this is the UI-level
 * enforcement of a rule that previously only existed as a warning label.
 */
@Composable
private fun RmsApprove(
    orders: List<com.abm.erp.data.RetailOrder>,
    dealers: List<com.abm.erp.data.Dealer>,
) {
    val me = MockRepository.currentUser
    // v113-217 — same real-data-resolution class of bug as the Ledger and
    // MainDashboard fixes earlier this session: myEntry was always null
    // for every real TSM account (EMPLOYEE_DIRECTORY never matches a real
    // employeeId), so `isTsm && myEntry != null` was always false and
    // approvableOrders always fell to emptyList() — a real TSM could never
    // see a single memo to approve here, regardless of their actual
    // assigned territory. Resolved via the real employeeProfiles ->
    // territoryId -> Territory chain (market/district/division), same
    // fields Territory already carries, in place of the old synthetic
    // geo's market/district/division/zoneDivisions.
    val myProfileForApprove by MockRepository.employeeProfiles.collectAsState()
    val territoriesForApprove by MockRepository.territories.collectAsState()
    val myTerritory = remember(myProfileForApprove, territoriesForApprove, me.id) {
        val profile = myProfileForApprove.firstOrNull { it.userAccountId == me.id }
        territoriesForApprove.firstOrNull { it.id == profile?.territoryId }
    }
    val isChairman = me.role == com.abm.erp.data.UserRole.CHAIRMAN
    val isTsm = me.role == com.abm.erp.data.UserRole.TSM

    // A TSM's approvable orders: those whose zone falls inside his own territory.
    val approvableOrders = remember(orders, myTerritory, isChairman) {
        when {
            isChairman -> orders
            isTsm && myTerritory != null -> {
                val myAreas = listOfNotNull(myTerritory.market, myTerritory.district, myTerritory.division).filter { it.isNotBlank() }
                orders.filter { o -> myAreas.any { area -> o.zone.contains(area, ignoreCase = true) || area.contains(o.zone, ignoreCase = true) } }
            }
            else -> emptyList()
        }
    }

    Column(Modifier.fillMaxSize()) {
        when {
            isChairman || (isTsm && approvableOrders.isNotEmpty()) -> {
                Text(
                    if (isChairman) "Chairman — সব এলাকার memo।" else "আপনার এলাকার memo — geo rule অনুযায়ী শুধু এগুলোই আপনি approve করবেন।",
                    style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                )
                Spacer(Modifier.height(8.dp))
                com.abm.erp.ui.sales.AsmVerifyTab(approvableOrders, dealers)
            }
            isTsm -> Text("আপনার এলাকায় approve করার মতো কোনো memo নেই।", color = TextSecondary)
            else -> Text(
                "Retailer memo শুধু সেই এলাকার TSM approve করে (geo rule)। আপনার role: ${me.role}।",
                color = WarningAmber, style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}


/** v113-77 — retailer-scoped one-page report, computed from the already-scoped lists. */
@Composable
private fun RmsReportTab(
    retailers: List<com.abm.erp.data.Retailer>,
    orders: List<com.abm.erp.data.RetailOrder>,
) {
    val visits by MockRepository.visitLogs.collectAsState()
    val today = java.time.LocalDate.now()
    val monthStart = today.withDayOfMonth(1)
    val monthOrders = remember(orders) { orders.filter { !it.loggedAt.toLocalDate().isBefore(monthStart) } }
    val monthAmount = remember(monthOrders) { monthOrders.sumOf { it.amount } }
    val monthVisits = remember(visits) {
        visits.count { it.partyType == com.abm.erp.data.PartyType.RETAILER && !it.checkInAt.toLocalDate().isBefore(monthStart) }
    }
    val activeCount = remember(retailers) { retailers.count { !it.isDeleted } }
    val dueTotal = remember(retailers) { retailers.sumOf { it.dueBalance } }
    val topRetailers = remember(orders) {
        orders.filter { it.retailerId != null }
            .groupBy { it.retailerId to it.retailerName }
            .mapValues { (_, list) -> list.sumOf { it.amount } }
            .entries.sortedByDescending { it.value }.take(5)
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Retailer Report — ${today.month} ${today.year}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
        Spacer(Modifier.height(10.dp))
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            RmsStatRow("Retailer", "$activeCount", TextPrimary)
            RmsStatRow("এই মাসের Memo", "${monthOrders.size}", TextPrimary)
            RmsStatRow("এই মাসের Memo Amount", "৳${"%,.0f".format(monthAmount)}", TextPrimary)
            RmsStatRow("এই মাসের Visit", "$monthVisits", TextPrimary)
            RmsStatRow("Total Due", "৳${"%,.0f".format(dueTotal)}", if (dueTotal > 0) WarningAmber else SuccessGreen)
        }
        Spacer(Modifier.height(12.dp))
        Text("Top Retailer (memo amount)", fontWeight = FontWeight.SemiBold, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        if (topRetailers.isEmpty()) Text("এখনো তথ্য নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        topRetailers.forEach { entry ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(entry.key.second, color = TextPrimary)
                    Text("৳${"%,.0f".format(entry.value)}", fontWeight = FontWeight.Bold, color = TextPrimary)
                }
            }
            Spacer(Modifier.height(6.dp))
        }
        Spacer(Modifier.height(24.dp))
    }
}
