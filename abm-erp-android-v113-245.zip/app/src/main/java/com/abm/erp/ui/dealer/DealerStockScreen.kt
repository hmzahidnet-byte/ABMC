package com.abm.erp.ui.dealer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.Space
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.*

/**
 * Dealer Stock — what a specific dealer is holding.
 *
 * Two figures, deliberately shown separately rather than merged into one number:
 *
 * 1. **Total Units** — `Dealer.stockUnits`, the trusted aggregate that has existed since the
 *    original baseline and that several other flows already depend on. Always complete.
 * 2. **Product Breakdown** — new, from `DealerStockLineEntity`, tracking stock **per product**
 *    from the day this shipped onward. It is not backfilled from history (see the entity's
 *    doc comment for why), so it may legitimately show less than the total — that gap is
 *    "arrived before product-wise tracking existed," not a bug, and the screen says so.
 *
 * Showing a merged, seemingly-precise number here would be more comfortable to look at and
 * actively misleading. Reached from DMS's "Dealer Stock" suite function.
 */
@Composable
fun DealerStockScreen(dealerId: String, onBack: () -> Unit) {
    val dealers by MockRepository.dealers.collectAsState()
    val dealer = dealers.firstOrNull { it.id == dealerId }

    if (dealer == null) {
        Column(Modifier.fillMaxSize().padding(Space.xl), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(70.dp))
            com.abm.erp.core.WorkspaceEmptyState("এই ডিলার পাওয়া যায়নি।", iconVector = Icons.Filled.Business)
            Spacer(Modifier.height(Space.lg))
            com.abm.erp.core.SecondaryButton("← ফিরে যান", onClick = onBack)
        }
        return
    }

    Column(Modifier.fillMaxSize().background(DashBg)) {
        Column(
            Modifier.fillMaxWidth()
                .background(Brush.linearGradient(listOf(Color(0xFFB45CFF), Color(0xFF7A2EE0))))
                .padding(horizontal = Space.md, vertical = 12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text("Dealer Stock", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(dealer.name, color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                }
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(Space.md)) {
            DealerStockContent(dealer)
        }
    }
}

// v113-232 — the person's own explicit request: Dealer's own click-into
// detail view should show its stock report right there, the same way
// invoice/QR/graph already do — "ডিলার লিস্টে ক্লিক করার পরে... ডিলারের
// স্টক রিপোর্টগুলো দিলে ভালো হয় না?" DealerStockScreen already existed,
// fully real and already well-built (the honest trusted-total-vs-
// product-breakdown distinction below is original, unchanged) — the only
// gap was that it lived as a separate destination, not reachable from
// the Dealer's own detail view at all. Extracted its content (without
// its own header, which would have duplicated ModuleBrowseDetail's own)
// so both the original standalone screen (DMS's own "Dealer Stock" suite
// function, unchanged) and the new "Stock" extraTab on Dealer's own
// detail view (ModuleBrowseConfigs.kt) share the exact same real content,
// not two different views of the same data. Deliberately has NO
// weight/scroll modifiers of its own — this function is pure content,
// wrapped by whichever caller embeds it. The original standalone screen
// wraps it in its own weighted+scrollable Column (its outer Column
// isn't scrollable, so this content needs to be); the new extraTab does
// NOT re-wrap it, because ModuleBrowseDetail's own tab-content Column is
// already weighted AND already scrollable — nesting a second
// weight(1f)+verticalScroll inside that would hit Compose's classic
// "vertically scrollable component measured with unbounded height"
// crash. Checked ModuleBrowseFlow.kt's real rendering structure directly
// before writing this, rather than assuming the same wrapper would be
// safe to reuse verbatim in a different container.
@Composable
fun DealerStockContent(dealer: com.abm.erp.data.Dealer) {
    val lines by remember(dealer.id) { MockRepository.dealerStockLinesFor(dealer.id) }
        .collectAsState(initial = emptyList())
    val trackedTotal = lines.sumOf { it.qty }
    val untracked = (dealer.stockUnits - trackedTotal).coerceAtLeast(0)

    Column {

        // ── the trusted total ──
        com.abm.erp.core.PremiumCard(padding = Space.lg) {
            Text("Total Units (trusted aggregate)", fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text("${dealer.stockUnits}", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(Modifier.height(4.dp))
            Text(
                "সমস্ত ইনভয়েস ও রিটার্ন থেকে হিসাব করা — সবসময় সম্পূর্ণ।",
                fontSize = 10.sp, color = TextSecondary,
            )
        }

        Spacer(Modifier.height(Space.md))

        // ── the honest gap disclosure ──
        if (untracked > 0) {
            com.abm.erp.core.PremiumCard(padding = Space.md) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Info, null, tint = StatusAmber, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(Space.sm))
                    Column {
                        Text(
                            "$untracked ইউনিট পণ্য-ভিত্তিক হিসাবে নেই",
                            fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            "এই ফিচার চালু হওয়ার আগে যা এসেছিল, তার পণ্য-ভিত্তিক তথ্য নেই — মোট সংখ্যায় আছে, ভাঙা তালিকায় নেই।",
                            fontSize = 9.sp, color = TextSecondary,
                        )
                    }
                }
            }
            Spacer(Modifier.height(Space.md))
        }

        // ── product breakdown ──
        com.abm.erp.core.SectionTitle("Product Breakdown (${lines.size})")
        if (lines.isEmpty()) {
            com.abm.erp.core.WorkspaceEmptyState(
                "এখনো কোনো পণ্য-ভিত্তিক রেকর্ড নেই — নতুন ইনভয়েস বা রিটার্ন থেকে যোগ হবে।",
                iconVector = Icons.Filled.Inventory,
            )
        } else {
            val maxQty = lines.maxOf { it.qty }.coerceAtLeast(1)
            Column(verticalArrangement = Arrangement.spacedBy(Space.sm)) {
                lines.sortedByDescending { it.qty }.forEach { line ->
                    com.abm.erp.core.PremiumCard(padding = Space.md) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(line.productName, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, maxLines = 1, modifier = Modifier.weight(1f))
                            Text(
                                "${line.qty}",
                                fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                color = if (line.qty < 0) StatusRed else TextPrimary,
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                        Box(Modifier.fillMaxWidth().height(5.dp).background(HairlineBorder, RoundedCornerShape(999.dp))) {
                            Box(
                                Modifier
                                    .fillMaxWidth((line.qty.toFloat() / maxQty).coerceIn(0f, 1f))
                                    .fillMaxHeight()
                                    .background(if (line.qty < 0) StatusRed else Color(0xFFB45CFF), RoundedCornerShape(999.dp)),
                            )
                        }
                        if (line.qty < 0) {
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "নেতিবাচক সংখ্যা — সম্ভবত রিটার্ন এর তুলনায় কম আগমন রেকর্ড হয়েছে, যাচাই করুন।",
                                fontSize = 9.sp, color = StatusRed,
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(Space.xxl))
    }
}
