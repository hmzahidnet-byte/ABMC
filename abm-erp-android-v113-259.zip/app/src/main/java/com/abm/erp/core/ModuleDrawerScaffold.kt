package com.abm.erp.core

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.theme.DashBg
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * v113-74 — the shell every "mother module" uses (DMS, RMS, HR, FMS, Chairman, AI).
 *
 * The person's rule, restated from the drafts:
 *  - the Home Dashboard shows exactly six mother modules and nothing else;
 *  - entering one opens a left drawer listing only *that* module's options;
 *  - picking an option closes the drawer, so the option gets the whole screen —
 *    that is the entire point ("phone er display ta onek boro pabo");
 *  - one module's drawer never lists another module's items. To switch modules you
 *    go back to Home. This keeps the UI clean and is why there is no cross-module
 *    shortcut anywhere in here.
 *
 * Only the *shell* is shared. Each module passes its own item list, its own colours
 * and its own content — the options are deliberately different per module.
 *
 * Performance: this renders on every module entry, so the drawer body is a plain
 * Column in a scroll container (item counts are ~8–10, a LazyColumn would cost more
 * than it saves) and no work happens in composition beyond drawing. Target is a
 * steady 90Hz minimum, 120Hz where the panel allows.
 */
data class ModuleDrawerItem(
    val key: String,
    val label: String,
    val icon: ImageVector,
    /** Optional short line under the label, e.g. "Direct Invoice + Auto Data". */
    val hint: String = "",
)

@Composable
fun ModuleDrawerScaffold(
    moduleName: String,
    moduleSubtitle: String,
    colorStart: Long,
    colorEnd: Long,
    moduleIcon: ImageVector,
    items: List<ModuleDrawerItem>,
    selectedKey: String,
    onSelect: (String) -> Unit,
    onBackToHome: () -> Unit,
    // v113-211 — the person's own request: when viewing a completed
    // invoice/memo, the document itself should fill the whole screen
    // rather than sitting under this module's own "hamburger + name +
    // Home" bar. Defaults to false (unchanged for every other screen in
    // every module) — only the specific workspace that owns a "viewing a
    // finished document" state opts into this, and only while that state
    // is active. The content itself already carries its own "← ফিরে যান"
    // exit affordance (confirmed directly in DmsInvoiceWorkspace before
    // relying on it here), so hiding this bar never strands the person.
    hideTopBar: Boolean = false,
    // v113-259 — three additions from the same discussion as the
    // TaskHeader/BrowseTopBar removal:
    // 1. `homeKey` — the drawer key this module actually lands on
    //    (DMS uses "list" since v113-249; every other module uses
    //    "dashboard"). With TaskHeader/BrowseTopBar's own back arrows gone,
    //    this bar's own real back mechanism — the phone's back gesture,
    //    intercepted below — needs to know which key counts as "home" to
    //    return to, rather than assuming "dashboard" everywhere.
    // 2. `primaryListKey`/`primaryListLabel` — an optional shortcut in the
    //    ⋮ menu straight to the module's own primary list, the person's
    //    own second confirmed item for this menu.
    // 3. `summaryRows` — an optional, lazily-computed (only when the
    //    person actually opens the menu, not on every recomposition) set
    //    of this module's own real KPI rows, enabling a real
    //    Export/Share/Print action in the same menu — the person's first
    //    confirmed item. Null (the default) means the module hasn't wired
    //    one up yet and the menu item simply doesn't appear — no dead
    //    button.
    homeKey: String = "dashboard",
    primaryListKey: String? = null,
    primaryListLabel: String = "List",
    summaryRows: (() -> List<Pair<String, String>>)? = null,
    content: @Composable (String) -> Unit,
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val start = Color(colorStart)
    val end = Color(colorEnd)

    // v113-259 — the module-level "always works" back mechanism. Every
    // drawer-selected screen used to have its own header with a back arrow
    // wired to `onSelect(homeKey)` (TaskHeader) or its own local-state
    // reset (BrowseTopBar's List/Detail/etc chain, unaffected by this —
    // those keep their own inner BackHandlers, which Compose gives
    // priority over this outer one while they're active). Plain drawer
    // items that never had a header at all (Dashboard's own sibling tabs
    // like Alerts, Approve, Finance) had NO quick way back except
    // reopening the drawer — this is the real fix for those, and it
    // harmlessly overlaps with the inner ones for the rest.
    androidx.activity.compose.BackHandler(enabled = selectedKey != homeKey) { onSelect(homeKey) }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = DashBg) {
                Column(
                    Modifier.fillMaxWidth()
                        .background(Brush.linearGradient(listOf(start, end)))
                        .padding(18.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(moduleIcon, contentDescription = null, tint = Color.White)
                        Spacer(Modifier.width(10.dp))
                        Text(moduleName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(moduleSubtitle, color = Color(0xFFE8ECFF), fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    items.forEach { item ->
                        val selected = item.key == selectedKey
                        Row(
                            Modifier.fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 3.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (selected) start.copy(alpha = 0.12f) else Color.Transparent)
                                .clickable {
                                    onSelect(item.key)
                                    // Close on pick — this is what frees the whole screen for the task.
                                    scope.launch { drawerState.close() }
                                }
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                item.icon, contentDescription = null,
                                tint = if (selected) start else TextSecondary,
                                modifier = Modifier.size(20.dp),
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    item.label,
                                    color = if (selected) start else TextPrimary,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                )
                                if (item.hint.isNotBlank()) {
                                    Text(item.hint, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                }
                            }
                        }
                    }
                }
                Divider()
                Row(
                    Modifier.fillMaxWidth().clickable { onBackToHome() }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("← Home", color = TextSecondary, style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.weight(1f))
                    Text(
                        "অন্য মডিউলে যেতে Home-এ ফিরুন",
                        style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                    )
                }
            }
        },
    ) {
        Column(Modifier.fillMaxSize()) {
            // v113-251 — the person's own direct instruction: the module
            // name repeating in this bar on every single screen inside it
            // was pure redundancy (you already know which module you're
            // in — you tapped into it) — and the two-line text block plus
            // a "Home" text button cost real vertical space on a phone
            // screen. Slimmed to exactly what a bar here needs to do:
            // open the drawer (☰, left) and reach Home (⋮, right, inside
            // a real dropdown so this bar has room to carry more later
            // without growing again) — nothing else, so the actual
            // content underneath gets the space back. Same drawer, same
            // colors, same "close on pick" behavior — only this specific
            // repeating pattern changes, not the module's own design
            // language.
            var overflowOpen by remember { mutableStateOf(false) }
            var showSummarySheet by remember { mutableStateOf(false) }
            if (!hideTopBar) {
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.horizontalGradient(listOf(start, end)))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { scope.launch { drawerState.open() } }) {
                    Icon(Icons.Filled.Menu, contentDescription = "Options", tint = Color.White)
                }
                Spacer(Modifier.weight(1f))
                Box {
                    IconButton(onClick = { overflowOpen = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "আরও", tint = Color.White)
                    }
                    DropdownMenu(expanded = overflowOpen, onDismissRequest = { overflowOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("🏠 Home") },
                            onClick = { overflowOpen = false; onBackToHome() },
                        )
                        // v113-259 — the person's own confirmed second item:
                        // a direct shortcut to this module's own primary
                        // list from anywhere inside it, not just from the
                        // drawer.
                        if (primaryListKey != null) {
                            DropdownMenuItem(
                                text = { Text("📋 $primaryListLabel") },
                                onClick = { overflowOpen = false; onSelect(primaryListKey) },
                            )
                        }
                        // v113-259 — the person's own confirmed first item:
                        // export/share/print this module's own KPI summary.
                        // Only appears once a module actually wires up
                        // `summaryRows` with its own real data — no dead
                        // button for modules that haven't yet.
                        if (summaryRows != null) {
                            DropdownMenuItem(
                                text = { Text("📤 Summary Export / Share / Print") },
                                onClick = { overflowOpen = false; showSummarySheet = true },
                            )
                        }
                    }
                }
            }
            }
            if (showSummarySheet && summaryRows != null) {
                ModuleSummarySheet(moduleName, summaryRows, onDismiss = { showSummarySheet = false })
            }
            content(selectedKey)
        }
    }
}

/**
 * Used where a mother module lists its own records for the person to drill into
 * (e.g. DMS → Ledger → pick a dealer). Kept here so both DMS and RMS draw the same
 * row rather than each inventing one.
 */
@Composable
fun ModuleDrillRow(title: String, subtitle: String, onClick: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                if (subtitle.isNotBlank()) {
                    Text(subtitle, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextSecondary)
        }
    }
}

/**
 * v113-259 — the module-home ⋮ "Summary Export/Share/Print" sheet. Same
 * pattern as ModuleBrowseList's own "More Actions" dialog (v113-129): a
 * real preview of what will be exported, then three real actions using the
 * same proven CSV-write/FileProvider-share/PrintManager mechanisms —
 * nothing fabricated, nothing that only looks like it works.
 */
@Composable
private fun ModuleSummarySheet(moduleName: String, summaryRows: () -> List<Pair<String, String>>, onDismiss: () -> Unit) {
    val rows = remember(moduleName) { summaryRows() }
    val context = androidx.compose.ui.platform.LocalContext.current
    var error by remember { mutableStateOf<String?>(null) }
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 480.dp).verticalScroll(rememberScrollState())) {
                Text("$moduleName — সারসংক্ষেপ", fontWeight = FontWeight.Bold, color = TextPrimary)
                error?.let { Text(it, color = com.abm.erp.theme.DangerRed, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
                Spacer(Modifier.height(8.dp))
                rows.forEach { (label, value) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(label, fontSize = 12.sp, color = TextSecondary)
                        Text(value, fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                    }
                }
                Spacer(Modifier.height(12.dp))
                TextButton(
                    onClick = {
                        try {
                            val file = exportModuleSummaryCsv(context, moduleName, rows)
                            shareStructuredCsv(context, file, "$moduleName Summary")
                        } catch (e: Exception) { error = e.message ?: "Export ব্যর্থ হয়েছে।" }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Row(verticalAlignment = Alignment.CenterVertically) { Text("⬇ Export (CSV)") } }
                TextButton(
                    onClick = {
                        try {
                            shareTextSummary(context, "$moduleName Summary", moduleSummaryText(moduleName, rows))
                        } catch (e: Exception) { error = e.message ?: "Share ব্যর্থ হয়েছে।" }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("📤 Share") }
                TextButton(
                    onClick = {
                        try {
                            val file = exportModuleSummaryPdf(context, moduleName, rows)
                            printPdfFile(context, file, "$moduleName Summary")
                        } catch (e: Exception) { error = e.message ?: "Print ব্যর্থ হয়েছে।" }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("🖨 Print") }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("বন্ধ করুন") }
            }
        }
    }
}

/**
 * Honest placeholder. Used only where the draft asks for something this codebase does
 * not have yet (e.g. Retailer Stock, Gift entry). It states plainly what is missing
 * instead of showing a fake screen that looks finished.
 */
@Composable
fun NotBuiltYet(what: String, detail: String = "") {
    Column(Modifier.fillMaxWidth().padding(24.dp)) {
        Text("$what — এখনো বানানো হয়নি", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        Text(
            detail.ifBlank { "এই অংশটা draft-এ আছে কিন্তু কোডে এখনো নেই। পরের ব্যাচে বানানো হবে।" },
            style = MaterialTheme.typography.bodySmall, color = TextSecondary,
        )
    }
}
