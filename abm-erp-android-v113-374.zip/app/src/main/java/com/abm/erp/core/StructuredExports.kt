package com.abm.erp.core

import android.content.Context
import com.abm.erp.data.SalesInvoice
import java.io.File

/**
 * Task D — structured business-document export. Unlike the generic
 * title/body fallback in UniversalActionMenu.kt, this draws an actual
 * invoice layout: company header, reference, date, dealer, a real
 * line-item table (name/qty/unit price/discount/line total), subtotal,
 * discount amount, grand total, status and a footer — using ONLY fields
 * that genuinely exist on SalesInvoice. No fabricated line items or totals.
 *
 * This is the first of the requested structured templates to be
 * completed; Dealer Statement, Purchase Order, Production Sheet,
 * Voucher/Ledger record and Payslip still use the generic fallback as of
 * this version (see the v82 continuation report's honest gap list).
 */
fun exportSalesInvoicePdf(
    context: Context,
    invoice: SalesInvoice,
    /**
     * v113-87 — a REGISTRY payload from `QrRegistry.issue("SalesInvoice", id)`, issued by
     * the caller inside its own coroutine (this fn stays non-suspend for Canvas work).
     * The old hardcoded "INVOICE:<id>" string was scannable by NOTHING — the secure path
     * rejects non-registry payloads and the legacy CodeRegistry matcher knows invoiceNo,
     * not a prefixed id — so a broken QR was printed on every bill. Null now prints an
     * honest line instead of a dead code.
     */
    qrPayload: String? = null,
): File {
    // v113-359 — REAL multi-page. The old single page silently dropped rows
    // past y>700f (v113-356 at least made it say so). Now the item loop opens
    // a fresh page and reprints the column header, so a 40-line invoice prints
    // all 40 lines and the totals still land under the last one.
    val pdfDocument = android.graphics.pdf.PdfDocument()
    var pdfPageNo = 1
    var page = pdfDocument.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, pdfPageNo).create())
    var canvas = page.canvas

    // v113-212 — full redesign to match the on-screen InvoiceDocumentBody
    // this session already rebuilt (v113-198): white page, colour spent
    // only on the logo mark / "INVOICE" label / table header / total
    // figure, not a filled banner — plus the grid table, ledger-style
    // totals rule, In Words, and ABM-mark logo the on-screen version has.
    // Same `orange` hex as DarazOrange (0xFFF85606, confirmed directly
    // against theme/Color.kt before assuming they already matched).
    val orange = android.graphics.Color.rgb(0xF8, 0x56, 0x06)
    val orangeDark = android.graphics.Color.rgb(0xC2, 0x3F, 0x00)
    val navy = android.graphics.Color.rgb(0x1B, 0x24, 0x30)
    val gray = android.graphics.Color.rgb(0x64, 0x74, 0x8B)
    val lightGray = android.graphics.Color.rgb(0xF7, 0xF8, 0xFA)
    val borderGray = android.graphics.Color.rgb(0xD5, 0xDB, 0xE3)
    val statusColor = when (invoice.status) {
        "PAID" -> android.graphics.Color.rgb(0x22, 0xA0, 0x6B)
        "CANCELLED" -> android.graphics.Color.rgb(0xE2, 0x4A, 0x3B)
        "PARTIALLY_PAID" -> android.graphics.Color.rgb(0xF5, 0xA6, 0x23)
        else -> android.graphics.Color.rgb(0x2E, 0x6F, 0xE0)
    }

    val logoTextPaint = android.graphics.Paint().apply { textSize = 9f; isFakeBoldText = true; color = android.graphics.Color.WHITE; textAlign = android.graphics.Paint.Align.CENTER }
    val companyNamePaint = android.graphics.Paint().apply { textSize = 15f; isFakeBoldText = true; color = navy }
    val taglinePaint = android.graphics.Paint().apply { textSize = 8f; color = gray }
    val docTitlePaint = android.graphics.Paint().apply { textSize = 17f; isFakeBoldText = true; color = orange; textAlign = android.graphics.Paint.Align.RIGHT }
    val labelPaint = android.graphics.Paint().apply { textSize = 8f; isFakeBoldText = true; color = gray }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f; color = navy }
    val boldBodyPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true; color = navy }
    val headerTextPaint = android.graphics.Paint().apply { textSize = 9.5f; isFakeBoldText = true; color = android.graphics.Color.WHITE }
    val footerPaint = android.graphics.Paint().apply { textSize = 9f; color = gray }
    val italicFooterPaint = android.graphics.Paint().apply { textSize = 9f; color = gray; textSkewX = -0.2f; textAlign = android.graphics.Paint.Align.RIGHT }
    val fillPaint = android.graphics.Paint()
    val linePaint = android.graphics.Paint().apply { color = borderGray; strokeWidth = 1f }
    val ruleDarkPaint = android.graphics.Paint().apply { color = navy; strokeWidth = 1.2f }
    val cellBorderPaint = android.graphics.Paint().apply { color = borderGray; strokeWidth = 0.7f; style = android.graphics.Paint.Style.STROKE }

    val left = 40f
    val right = 555f
    val width = right - left

    // ---- masthead — white page, logo mark, orange INVOICE label ----
    val company = com.abm.erp.data.MockRepository.companySettings()
    fillPaint.color = orange
    canvas.drawRoundRect(android.graphics.RectF(left, 30f, left + 32f, 62f), 5f, 5f, fillPaint)
    canvas.drawText("ABM", left + 16f, 50f, logoTextPaint)
    canvas.drawText(company.companyName.ifBlank { "ABM Corporation" }, left + 42f, 46f, companyNamePaint)
    canvas.drawText(
        listOfNotNull(company.companyAddress.ifBlank { null }, company.companyPhone.ifBlank { null })
            .joinToString(" · ").ifBlank { "Enterprise. Control. Growth." },
        left + 42f, 58f, taglinePaint,
    )
    canvas.drawText("INVOICE", right, 48f, docTitlePaint)
    canvas.drawRect(left, 72f, right, 74.5f, fillPaint)
    linePaint.color = android.graphics.Color.rgb(0xFF, 0xD9, 0xC4)
    canvas.drawRect(left, 74.5f, right, 76f, linePaint)
    linePaint.color = borderGray

    // ---- meta box: Invoice No / Date (left) + QR (right), one bordered box ----
    var y = 90f
    canvas.drawRect(android.graphics.RectF(left, y, right, y + 90f), cellBorderPaint)
    canvas.drawLine(right - 74f, y, right - 74f, y + 90f, linePaint)
    canvas.drawText("INVOICE NO", left + 12f, y + 20f, labelPaint)
    canvas.drawText(invoice.invoiceNo, left + 12f, y + 36f, boldBodyPaint)
    canvas.drawText("DATE", left + 12f, y + 58f, labelPaint)
    canvas.drawText(invoice.createdAt.toLocalDate().toString(), left + 12f, y + 74f, bodyPaint)
    // v113-211 — QR isolated in its own try/catch so a QR failure degrades
    // to an honest note instead of failing the whole document.
    if (qrPayload != null) {
        try {
            val qrBitmap = com.abm.erp.util.QrCodeGenerator.generate(qrPayload, 200)
            canvas.drawBitmap(qrBitmap, null, android.graphics.RectF(right - 64f, y + 10f, right - 10f, y + 64f), null)
            val centerPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; textSize = 7.5f }
            canvas.drawText("Scan to verify", right - 37f, y + 78f, centerPaint)
        } catch (e: Exception) {
            com.abm.erp.config.AppLog.w("StructuredExports", "QR generation failed for invoice PDF", e)
            val centerPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; textSize = 7.5f }
            canvas.drawText("QR could not", right - 37f, y + 40f, centerPaint)
            canvas.drawText("be generated", right - 37f, y + 52f, centerPaint)
        }
    } else {
        val centerPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; textSize = 7.5f }
        canvas.drawText("QR not issued", right - 37f, y + 46f, centerPaint)
    }
    y += 100f

    // ---- Dealer — orange bar + bordered box, matching the on-screen DocBar pattern ----
    fillPaint.color = orange
    canvas.drawRect(left, y, right, y + 20f, fillPaint)
    canvas.drawText("DEALER", left + 10f, y + 14f, headerTextPaint)
    y += 20f
    canvas.drawRect(android.graphics.RectF(left, y, right, y + 56f), cellBorderPaint)
    canvas.drawLine(left + width / 2, y, left + width / 2, y + 56f, linePaint)
    canvas.drawText(invoice.dealerName, left + 12f, y + 20f, boldBodyPaint)
    canvas.drawText(invoice.dealerZone, left + 12f, y + 36f, footerPaint)
    canvas.drawText("PAYMENT TERMS", left + width / 2 + 12f, y + 18f, labelPaint)
    canvas.drawText(if (invoice.status == "PAID") "Paid" else "Credit", left + width / 2 + 12f, y + 34f, boldBodyPaint)
    canvas.drawText("Courier: ${invoice.courier?.ifBlank { null } ?: "—"}", left + width / 2 + 12f, y + 48f, footerPaint)
    y += 70f

    // ---- item table — real grid (both horizontal and vertical rules), orange header ----
    val colX = floatArrayOf(left, left + 34f, left + 290f, left + 350f, left + 420f, right)
    fillPaint.color = orange
    canvas.drawRect(left, y, right, y + 22f, fillPaint)
    canvas.drawText("#", colX[0] + 8f, y + 15f, headerTextPaint)
    canvas.drawText("Item / Product", colX[1] + 8f, y + 15f, headerTextPaint)
    canvas.drawText("Qty", colX[2] + 8f, y + 15f, headerTextPaint)
    canvas.drawText("Rate", colX[3] + 8f, y + 15f, headerTextPaint)
    canvas.drawText("Amount", colX[4] + 8f, y + 15f, headerTextPaint)
    for (i in 0..5) canvas.drawLine(colX[i], y, colX[i], y + 22f, android.graphics.Paint().apply { color = android.graphics.Color.WHITE; strokeWidth = 0.5f; alpha = 90 })
    y += 22f

    // v113-359 — the header-drawing above is reused verbatim when a new page
    // starts, so every page's table looks like the first one's.
    fun drawItemTableHeader() {
        fillPaint.color = orange
        canvas.drawRect(left, y, right, y + 22f, fillPaint)
        canvas.drawText("#", colX[0] + 8f, y + 15f, headerTextPaint)
        canvas.drawText("Item / Product", colX[1] + 8f, y + 15f, headerTextPaint)
        canvas.drawText("Qty", colX[2] + 8f, y + 15f, headerTextPaint)
        canvas.drawText("Rate", colX[3] + 8f, y + 15f, headerTextPaint)
        canvas.drawText("Amount", colX[4] + 8f, y + 15f, headerTextPaint)
        y += 22f
    }
    // Closes the current page (watermark + page number) and opens the next.
    fun startNextPage() {
        when {
            invoice.status == "CANCELLED" -> drawDocumentWatermark(canvas, "CANCELLED")
            !invoice.isApprovedOrLater -> drawDocumentWatermark(canvas, "DRAFT")
        }
        canvas.drawText("Invoice ${invoice.invoiceNo} — Page $pdfPageNo", left, 820f, footerPaint)
        pdfDocument.finishPage(page)
        pdfPageNo++
        page = pdfDocument.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, pdfPageNo).create())
        canvas = page.canvas
        y = 50f
        canvas.drawText("${invoice.invoiceNo} (continued)", left, y, footerPaint)
        y += 20f
        drawItemTableHeader()
    }
    invoice.lineItems.forEachIndexed { idx, item ->
        // 700f leaves room for the totals block; on a continuation page only the
        // rows and the closing rule need to fit, so the same limit is safe.
        if (y > 700f) startNextPage()
        val rowH = 24f
        if (idx % 2 == 1) { fillPaint.color = lightGray; canvas.drawRect(left, y, right, y + rowH, fillPaint) }
        canvas.drawText("%02d".format(idx + 1), colX[0] + 8f, y + 16f, bodyPaint)
        canvas.drawText(item.name.take(28), colX[1] + 8f, y + 16f, bodyPaint)
        canvas.drawText("${item.qty}", colX[2] + 8f, y + 16f, bodyPaint)
        canvas.drawText("৳${"%.0f".format(item.unitPrice)}", colX[3] + 8f, y + 16f, bodyPaint)
        canvas.drawText("৳${"%.0f".format(item.lineTotal)}", colX[4] + 8f, y + 16f, boldBodyPaint)
        for (i in 0..5) canvas.drawLine(colX[i], y, colX[i], y + rowH, cellBorderPaint)
        canvas.drawLine(left, y + rowH, right, y + rowH, cellBorderPaint)
        y += rowH
    }
    canvas.drawLine(left, y, right, y, cellBorderPaint) // closes the table's bottom edge
    y += 16f
    // v113-359 — totals must not collide with the page edge either; if the rows
    // ended low, push the whole totals/signature block to a fresh page.
    if (y > 560f) startNextPage()

    // ---- totals — plain rows, ledger double-rule above Total, no tax line, no heavy banner ----
    val totalsX = right - 200f
    canvas.drawText("Subtotal", totalsX, y, footerPaint)
    canvas.drawText("৳${"%,.0f".format(invoice.subTotal)}", right, y, android.graphics.Paint(bodyPaint).apply { textAlign = android.graphics.Paint.Align.RIGHT })
    y += 16f
    if (invoice.dealerDiscountPct > 0) {
        canvas.drawText("Discount (${invoice.dealerDiscountPct}%)", totalsX, y, footerPaint)
        canvas.drawText("− ৳${"%,.0f".format(invoice.dealerDiscountAmt)}", right, y, android.graphics.Paint(bodyPaint).apply { textAlign = android.graphics.Paint.Align.RIGHT })
        y += 16f
    }
    y += 4f
    canvas.drawLine(totalsX, y, right, y, ruleDarkPaint)
    y += 3f
    canvas.drawLine(totalsX, y, right, y, ruleDarkPaint)
    y += 20f
    canvas.drawText("TOTAL", totalsX, y, android.graphics.Paint(boldBodyPaint).apply { textSize = 12f })
    canvas.drawText(
        "৳${"%,.0f".format(invoice.netAfterDiscount)}", right, y,
        android.graphics.Paint().apply { textSize = 19f; isFakeBoldText = true; color = orange; textAlign = android.graphics.Paint.Align.RIGHT },
    )
    y += 24f

    // ---- In Words — same amountInWords() the on-screen invoice already uses, not a duplicate ----
    canvas.drawText(
        "In Words: ${com.abm.erp.core.amountInWords(invoice.netAfterDiscount)}", right, y,
        android.graphics.Paint(italicFooterPaint).apply { textSkewX = -0.2f },
    )
    y += 30f

    // ---- Party balance (same source and fallback rule as the on-screen invoice) ----
    // v113-354 — extracted to invoiceBalanceView (the v113-213 additive
    // pending rule lives inside it) so this PDF and the bespoke PNG
    // (renderInvoiceDocumentBitmap) can never disagree on these figures.
    val bal = invoiceBalanceView(invoice)
    val prevDue = bal.previousDue
    val otherPendingSum = bal.otherPendingSum
    val totalDue = bal.totalDue
    val balanceBoxH = if (otherPendingSum > 0) 72f else 56f
    fillPaint.color = lightGray
    canvas.drawRoundRect(android.graphics.RectF(left, y, left + 340f, y + balanceBoxH), 4f, 4f, fillPaint)
    var balanceY = y + 18f
    canvas.drawText("Previous Due (Approved)", left + 12f, balanceY, footerPaint)
    canvas.drawText("৳${"%,.0f".format(prevDue)}", left + 240f, balanceY, bodyPaint)
    if (otherPendingSum > 0) {
        balanceY += 16f
        val amberPaint = android.graphics.Paint(bodyPaint).apply { color = android.graphics.Color.rgb(0xF5, 0xA6, 0x23) }
        canvas.drawText("Pending (other invoices)", left + 12f, balanceY, android.graphics.Paint(footerPaint).apply { color = android.graphics.Color.rgb(0xF5, 0xA6, 0x23) })
        canvas.drawText("৳${"%,.0f".format(otherPendingSum)}", left + 240f, balanceY, amberPaint)
    }
    balanceY += 16f
    canvas.drawText("This Invoice", left + 12f, balanceY, footerPaint)
    canvas.drawText("৳${"%,.0f".format(invoice.total)}", left + 240f, balanceY, bodyPaint)
    balanceY += 16f
    // v113-356 — label matched to the bespoke PNG's own wording; the number
    // was already identical (invoiceBalanceView), only the word differed.
    canvas.drawText(if (otherPendingSum > 0) "Closing Due (incl. pending)" else "Closing Due", left + 12f, balanceY, boldBodyPaint)
    canvas.drawText("৳${"%,.0f".format(totalDue)}", left + 240f, balanceY, boldBodyPaint)

    // status badge, right-aligned beside the balance box
    val statusFillPaint = android.graphics.Paint().apply { color = statusColor }
    canvas.drawRoundRect(android.graphics.RectF(right - 100f, y + 6f, right, y + 26f), 10f, 10f, statusFillPaint)
    val statusTextPaint = android.graphics.Paint().apply { textSize = 9.5f; isFakeBoldText = true; color = android.graphics.Color.WHITE; textAlign = android.graphics.Paint.Align.CENTER }
    canvas.drawText(invoice.status, right - 50f, y + 20f, statusTextPaint)
    y += balanceBoxH + 20f

    // ---- Signature area ----
    canvas.drawLine(left, y, left + 150f, y, linePaint)
    canvas.drawLine(left + 190f, y, left + 340f, y, linePaint)
    canvas.drawLine(left + 380f, y, right, y, linePaint)
    y += 14f
    canvas.drawText("Prepared By (${invoice.createdBy})", left, y, footerPaint)
    canvas.drawText("Checked By", left + 190f, y, footerPaint)
    canvas.drawText("Authorized By${invoice.signedByRole?.let { " ($it)" } ?: ""}", left + 380f, y, footerPaint)
    y += 26f

    // ---- Thank you footer, matching the on-screen document ----
    val centerFooterPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; isFakeBoldText = true }
    canvas.drawText("Thank you for your business!", left + width / 2, y, centerFooterPaint)

    // v113-350 — the payment method belongs on the paper: a dealer holding a
    // COD bill must see it says COD.
    canvas.drawText("Payment: ${when (invoice.paymentMethod) { "CASH" -> "Paid (নগদ)"; "COD" -> "Cash on Delivery"; else -> "Due (বাকি)" }}", left, 800f, footerPaint)
    canvas.drawText("Generated ${java.time.LocalDateTime.now()} — ${company.companyName.ifBlank { "ABM ERP" }}", left, 815f, footerPaint)

    // v113-349 — a non-approved document must announce itself.
    when {
        invoice.status == "CANCELLED" -> drawDocumentWatermark(canvas, "CANCELLED")
        !invoice.isApprovedOrLater -> drawDocumentWatermark(canvas, "DRAFT")
    }
    if (pdfPageNo > 1) canvas.drawText("Invoice ${invoice.invoiceNo} — Page $pdfPageNo of $pdfPageNo", left, 820f, footerPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "invoice_${invoice.invoiceNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/**
 * v113-349 — diagonal watermark for a document that is not (or no longer) a
 * live business paper. Drawn LAST so it sits over the content: a draft or a
 * cancelled invoice must be impossible to mistake for a real bill when the
 * PDF lands in someone's WhatsApp. Translucent so the content stays readable.
 */
private fun drawDocumentWatermark(canvas: android.graphics.Canvas, text: String, textSize: Float = 96f) {
    val paint = android.graphics.Paint().apply {
        color = android.graphics.Color.argb(46, 220, 38, 38)
        this.textSize = textSize
        isFakeBoldText = true
        isAntiAlias = true
        textAlign = android.graphics.Paint.Align.CENTER
    }
    canvas.save()
    canvas.rotate(-30f, canvas.width / 2f, canvas.height / 2f)
    canvas.drawText(text, canvas.width / 2f, canvas.height / 2f, paint)
    canvas.restore()
}

/**
 * v113-153 — the memo's PDF, same drawing mechanism as exportSalesInvoicePdf (same
 * PdfDocument/Canvas approach, so the two look like siblings when printed side by
 * side), but built only from RetailOrder's own real fields. No dealer-style discount
 * row, no due-snapshot section — a retail order carries neither in this app's data
 * model, and inventing them would misrepresent what the memo actually is.
 */
fun exportRetailOrderPdf(
    context: Context,
    order: com.abm.erp.data.RetailOrder,
    qrPayload: String? = null,
): File {
    // v113-359 — real multi-page, same machinery as the invoice exporter.
    val pdfDocument = android.graphics.pdf.PdfDocument()
    var pdfPageNo = 1
    var page = pdfDocument.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, pdfPageNo).create())
    var canvas = page.canvas

    // v113-212 — same redesign as exportSalesInvoicePdf above, matching the
    // on-screen MemoDocumentBody (also rebuilt at v113-200). Memo's own
    // real distinctions preserved exactly, not flattened to match Invoice:
    // "Retailer" not "Dealer", no discount/subtotal row (a memo carries
    // neither in this app's data model), a standalone independent due box
    // rather than previous+this+total, and its own real signature chain
    // (Logged By SO / Verified By ASM / Retailer Signature).
    val orange = android.graphics.Color.rgb(0xF8, 0x56, 0x06)
    val navy = android.graphics.Color.rgb(0x1B, 0x24, 0x30)
    val gray = android.graphics.Color.rgb(0x64, 0x74, 0x8B)
    val lightGray = android.graphics.Color.rgb(0xF7, 0xF8, 0xFA)
    val borderGray = android.graphics.Color.rgb(0xD5, 0xDB, 0xE3)
    val statusColor = when (order.stage) {
        com.abm.erp.data.OrderStage.FULFILLED -> android.graphics.Color.rgb(0x22, 0xA0, 0x6B)
        com.abm.erp.data.OrderStage.REJECTED -> android.graphics.Color.rgb(0xE2, 0x4A, 0x3B)
        com.abm.erp.data.OrderStage.DEALER_ROUTED -> android.graphics.Color.rgb(0xF5, 0xA6, 0x23)
        else -> android.graphics.Color.rgb(0x2E, 0x6F, 0xE0)
    }

    val logoTextPaint = android.graphics.Paint().apply { textSize = 9f; isFakeBoldText = true; color = android.graphics.Color.WHITE; textAlign = android.graphics.Paint.Align.CENTER }
    val companyNamePaint = android.graphics.Paint().apply { textSize = 15f; isFakeBoldText = true; color = navy }
    val taglinePaint = android.graphics.Paint().apply { textSize = 8f; color = gray }
    val docTitlePaint = android.graphics.Paint().apply { textSize = 17f; isFakeBoldText = true; color = orange; textAlign = android.graphics.Paint.Align.RIGHT }
    val labelPaint = android.graphics.Paint().apply { textSize = 8f; isFakeBoldText = true; color = gray }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f; color = navy }
    val boldBodyPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true; color = navy }
    val headerTextPaint = android.graphics.Paint().apply { textSize = 9.5f; isFakeBoldText = true; color = android.graphics.Color.WHITE }
    val footerPaint = android.graphics.Paint().apply { textSize = 9f; color = gray }
    val italicFooterPaint = android.graphics.Paint().apply { textSize = 9f; color = gray; textSkewX = -0.2f; textAlign = android.graphics.Paint.Align.RIGHT }
    val fillPaint = android.graphics.Paint()
    val linePaint = android.graphics.Paint().apply { color = borderGray; strokeWidth = 1f }
    val ruleDarkPaint = android.graphics.Paint().apply { color = navy; strokeWidth = 1.2f }
    val cellBorderPaint = android.graphics.Paint().apply { color = borderGray; strokeWidth = 0.7f; style = android.graphics.Paint.Style.STROKE }

    val left = 40f
    val right = 555f
    val width = right - left

    // ---- masthead ----
    val company = com.abm.erp.data.MockRepository.companySettings()
    fillPaint.color = orange
    canvas.drawRoundRect(android.graphics.RectF(left, 30f, left + 32f, 62f), 5f, 5f, fillPaint)
    canvas.drawText("ABM", left + 16f, 50f, logoTextPaint)
    canvas.drawText(company.companyName.ifBlank { "ABM Corporation" }, left + 42f, 46f, companyNamePaint)
    canvas.drawText(
        listOfNotNull(company.companyAddress.ifBlank { null }, company.companyPhone.ifBlank { null })
            .joinToString(" · ").ifBlank { "Enterprise. Control. Growth." },
        left + 42f, 58f, taglinePaint,
    )
    canvas.drawText("MEMO", right, 48f, docTitlePaint)
    canvas.drawRect(left, 72f, right, 74.5f, fillPaint)
    linePaint.color = android.graphics.Color.rgb(0xFF, 0xD9, 0xC4)
    canvas.drawRect(left, 74.5f, right, 76f, linePaint)
    linePaint.color = borderGray

    // ---- meta box: Memo No / Date (left) + QR (right) ----
    var y = 90f
    canvas.drawRect(android.graphics.RectF(left, y, right, y + 90f), cellBorderPaint)
    canvas.drawLine(right - 74f, y, right - 74f, y + 90f, linePaint)
    canvas.drawText("MEMO NO", left + 12f, y + 20f, labelPaint)
    canvas.drawText(order.orderNo, left + 12f, y + 36f, boldBodyPaint)
    canvas.drawText("DATE", left + 12f, y + 58f, labelPaint)
    canvas.drawText(order.loggedAt.toLocalDate().toString(), left + 12f, y + 74f, bodyPaint)
    // v113-211 — QR isolated in its own try/catch, same reasoning as the invoice.
    if (qrPayload != null) {
        try {
            val qrBitmap = com.abm.erp.util.QrCodeGenerator.generate(qrPayload, 200)
            canvas.drawBitmap(qrBitmap, null, android.graphics.RectF(right - 64f, y + 10f, right - 10f, y + 64f), null)
            val centerPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; textSize = 7.5f }
            canvas.drawText("Scan to verify", right - 37f, y + 78f, centerPaint)
        } catch (e: Exception) {
            com.abm.erp.config.AppLog.w("StructuredExports", "QR generation failed for memo PDF", e)
            val centerPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; textSize = 7.5f }
            canvas.drawText("QR could not", right - 37f, y + 40f, centerPaint)
            canvas.drawText("be generated", right - 37f, y + 52f, centerPaint)
        }
    } else {
        val centerPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; textSize = 7.5f }
        canvas.drawText("QR not issued", right - 37f, y + 46f, centerPaint)
    }
    y += 100f

    // ---- Retailer — orange bar + bordered box ----
    val loggedByName = com.abm.erp.data.MockRepository.demoAccounts.values
        .firstOrNull { it.id == order.loggedBySoId }?.name ?: order.loggedBySoId
    fillPaint.color = orange
    canvas.drawRect(left, y, right, y + 20f, fillPaint)
    canvas.drawText("RETAILER", left + 10f, y + 14f, headerTextPaint)
    y += 20f
    canvas.drawRect(android.graphics.RectF(left, y, right, y + 56f), cellBorderPaint)
    canvas.drawLine(left + width / 2, y, left + width / 2, y + 56f, linePaint)
    canvas.drawText(order.retailerName, left + 12f, y + 20f, boldBodyPaint)
    canvas.drawText(order.zone, left + 12f, y + 36f, footerPaint)
    canvas.drawText("LOGGED BY", left + width / 2 + 12f, y + 18f, labelPaint)
    canvas.drawText(loggedByName, left + width / 2 + 12f, y + 34f, boldBodyPaint)
    canvas.drawText(if (order.channel == "wholesale") "Wholesale" else "Retail", left + width / 2 + 12f, y + 48f, footerPaint)
    y += 70f

    // ---- item table (or free-text summary for pre-v71 memos) ----
    if (order.lineItems.isNotEmpty()) {
        val colX = floatArrayOf(left, left + 34f, left + 310f, left + 380f, left + 460f, right)
        fillPaint.color = orange
        canvas.drawRect(left, y, right, y + 22f, fillPaint)
        canvas.drawText("#", colX[0] + 8f, y + 15f, headerTextPaint)
        canvas.drawText("Item / Product", colX[1] + 8f, y + 15f, headerTextPaint)
        canvas.drawText("Qty", colX[2] + 8f, y + 15f, headerTextPaint)
        canvas.drawText("Rate", colX[3] + 8f, y + 15f, headerTextPaint)
        canvas.drawText("Amount", colX[4] + 8f, y + 15f, headerTextPaint)
        y += 22f
        fun drawMemoTableHeader() {
            fillPaint.color = orange
            canvas.drawRect(left, y, right, y + 22f, fillPaint)
            canvas.drawText("#", colX[0] + 8f, y + 15f, headerTextPaint)
            canvas.drawText("Item / Product", colX[1] + 8f, y + 15f, headerTextPaint)
            canvas.drawText("Qty", colX[2] + 8f, y + 15f, headerTextPaint)
            canvas.drawText("Rate", colX[3] + 8f, y + 15f, headerTextPaint)
            canvas.drawText("Amount", colX[4] + 8f, y + 15f, headerTextPaint)
            y += 22f
        }
        fun startNextMemoPage() {
            when {
                order.stage == com.abm.erp.data.OrderStage.REJECTED -> drawDocumentWatermark(canvas, "REJECTED")
                !order.isApprovedOrLater -> drawDocumentWatermark(canvas, "DRAFT")
            }
            canvas.drawText("Memo ${order.orderNo} — Page $pdfPageNo", left, 820f, footerPaint)
            pdfDocument.finishPage(page)
            pdfPageNo++
            page = pdfDocument.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, pdfPageNo).create())
            canvas = page.canvas
            y = 50f
            canvas.drawText("${order.orderNo} (continued)", left, y, footerPaint)
            y += 20f
            drawMemoTableHeader()
        }
        order.lineItems.forEachIndexed { idx, item ->
            if (y > 700f) startNextMemoPage()
            val rowH = 24f
            if (idx % 2 == 1) { fillPaint.color = lightGray; canvas.drawRect(left, y, right, y + rowH, fillPaint) }
            canvas.drawText("%02d".format(idx + 1), colX[0] + 8f, y + 16f, bodyPaint)
            canvas.drawText(item.name.take(30), colX[1] + 8f, y + 16f, bodyPaint)
            canvas.drawText("${item.qty}", colX[2] + 8f, y + 16f, bodyPaint)
            canvas.drawText("৳${"%.0f".format(item.unitPrice)}", colX[3] + 8f, y + 16f, bodyPaint)
            canvas.drawText("৳${"%.0f".format(item.lineTotal)}", colX[4] + 8f, y + 16f, boldBodyPaint)
            for (i in 0..5) canvas.drawLine(colX[i], y, colX[i], y + rowH, cellBorderPaint)
            canvas.drawLine(left, y + rowH, right, y + rowH, cellBorderPaint)
            y += rowH
        }
        canvas.drawLine(left, y, right, y, cellBorderPaint)
        y += 16f
        if (y > 600f) startNextMemoPage()
    } else {
        canvas.drawText("ITEMS", left, y, labelPaint)
        canvas.drawText(order.items.ifBlank { "—" }.take(80), left, y + 16f, bodyPaint)
        y += 40f
    }

    // ---- total — plain, ledger rule, no discount/subtotal (a memo carries neither) ----
    val totalsX = right - 200f
    canvas.drawLine(totalsX, y, right, y, ruleDarkPaint)
    y += 3f
    canvas.drawLine(totalsX, y, right, y, ruleDarkPaint)
    y += 20f
    canvas.drawText("TOTAL", totalsX, y, android.graphics.Paint(boldBodyPaint).apply { textSize = 12f })
    canvas.drawText(
        "৳${"%,.0f".format(order.amount)}", right, y,
        android.graphics.Paint().apply { textSize = 19f; isFakeBoldText = true; color = orange; textAlign = android.graphics.Paint.Align.RIGHT },
    )
    y += 24f

    // ---- In Words — same amountInWords() the on-screen memo already uses ----
    canvas.drawText("In Words: ${com.abm.erp.core.amountInWords(order.amount)}", right, y, italicFooterPaint)
    y += 30f

    // ---- Retailer's standing due — explicitly independent, not "previous+this+total" ----
    val retailer = com.abm.erp.data.MockRepository.retailers.value.firstOrNull { it.id == order.retailerId }
    if (retailer != null) {
        fillPaint.color = lightGray
        canvas.drawRoundRect(android.graphics.RectF(left, y, left + 340f, y + 42f), 4f, 4f, fillPaint)
        canvas.drawText("Retailer's Current Due", left + 12f, y + 18f, footerPaint)
        canvas.drawText("৳${"%,.0f".format(retailer.dueBalance)}", left + 220f, y + 18f, boldBodyPaint)
        canvas.drawText("* Independent of this memo — billing happens at Dealer level.", left + 12f, y + 34f, footerPaint)
        y += 58f
    }

    // ---- Stage badge ----
    val statusFillPaint = android.graphics.Paint().apply { color = statusColor }
    canvas.drawRoundRect(android.graphics.RectF(left, y, left + 130f, y + 22f), 11f, 11f, statusFillPaint)
    val statusTextPaint = android.graphics.Paint().apply { textSize = 9.5f; isFakeBoldText = true; color = android.graphics.Color.WHITE; textAlign = android.graphics.Paint.Align.CENTER }
    canvas.drawText(order.stage.name, left + 65f, y + 15f, statusTextPaint)
    y += 50f

    // ---- Signature area — the real SO → ASM → Retailer chain, not Invoice's Prepared/Checked/Authorized ----
    canvas.drawLine(left, y, left + 150f, y, linePaint)
    canvas.drawLine(left + 190f, y, left + 340f, y, linePaint)
    canvas.drawLine(left + 380f, y, right, y, linePaint)
    y += 14f
    canvas.drawText("Logged By ($loggedByName)", left, y, footerPaint)
    canvas.drawText("Verified By (ASM)", left + 190f, y, footerPaint)
    canvas.drawText("Retailer Signature", left + 380f, y, footerPaint)
    y += 26f

    val centerFooterPaint = android.graphics.Paint(footerPaint).apply { textAlign = android.graphics.Paint.Align.CENTER; isFakeBoldText = true }
    canvas.drawText("Thank you for your business!", left + width / 2, y, centerFooterPaint)

    canvas.drawText("Generated ${java.time.LocalDateTime.now()} — ${company.companyName.ifBlank { "ABM ERP" }}", left, 815f, footerPaint)

    // v113-349 — same rule for the memo.
    when {
        order.stage == com.abm.erp.data.OrderStage.REJECTED -> drawDocumentWatermark(canvas, "REJECTED")
        !order.isApprovedOrLater -> drawDocumentWatermark(canvas, "DRAFT")
    }
    if (pdfPageNo > 1) canvas.drawText("Memo ${order.orderNo} — Page $pdfPageNo of $pdfPageNo", left, 820f, footerPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "memo_${order.orderNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/** Shared FileProvider-share step for every structured PDF below — one place to get the MIME type/authority/error-safety right instead of repeating it at each call site. */
fun shareStructuredPdf(context: Context, file: File, label: String) {
    val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(android.content.Intent.createChooser(intent, label))
}

/**
 * v113-129 — "Export List (Excel/CSV)" for the browse-list's real "More Actions"
 * panel. Reuses the exact CSV field-escaping already proven correct in
 * UniversalActionMenu.kt (`escapeCsvField`/`toCsvRow`) and the exact same real
 * FileProvider mechanism `shareStructuredPdf` above already uses for PDFs — a new
 * file format through an already-working share pipeline, not an untested one.
 * `columns` is (header label, per-record value) so every module's existing
 * `infoRows` field list can feed this directly with no per-entity special-casing.
 */
fun <T> exportListAsCsv(context: Context, entityLabel: String, records: List<T>, columns: List<Pair<String, (T) -> String>>): File {
    val header = columns.joinToString(",") { escapeCsvField(it.first) }
    val rows = records.joinToString("\n") { r -> columns.joinToString(",") { escapeCsvField(it.second(r)) } }
    val file = File(context.getExternalFilesDir(null), "${entityLabel}_list_${System.currentTimeMillis()}.csv")
    file.writeText("$header\n$rows")
    return file
}

/** Same real FileProvider share step as shareStructuredPdf, for the CSV file exportListAsCsv just wrote — one real, working mechanism for both file types rather than a second untested one. */
fun shareStructuredCsv(context: Context, file: File, label: String) {
    val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "text/csv"
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(android.content.Intent.createChooser(intent, label))
}

/**
 * v113-129 — "Print List" for the browse-list's More Actions panel. A real,
 * simple multi-page list PDF (code · name · detail · status per row), built with
 * the same raw android.graphics.pdf.PdfDocument API every other export in this
 * file already uses — paginates for real once a page fills, rather than silently
 * dropping rows past the first page.
 */
fun <T> exportBrowseListPdf(
    context: Context, entityLabel: String, records: List<T>,
    codeOf: (T) -> String, titleOf: (T) -> String, subtitleOf: (T) -> String, isActiveOf: (T) -> Boolean,
): File {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    val pageWidth = 595; val pageHeight = 842 // A4 at 72dpi
    val titlePaint = android.graphics.Paint().apply { textSize = 16f; isFakeBoldText = true }
    val rowPaint = android.graphics.Paint().apply { textSize = 10f }
    val rowsPerPage = 45
    var pageNum = 1
    var rowIndex = 0
    val chunks = records.chunked(rowsPerPage)
    if (chunks.isEmpty()) {
        val page = pdfDocument.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create())
        page.canvas.drawText("$entityLabel List — কোনো রেকর্ড নেই", 40f, 60f, titlePaint)
        pdfDocument.finishPage(page)
    }
    for (chunk in chunks) {
        val page = pdfDocument.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        val canvas = page.canvas
        canvas.drawText("$entityLabel List (${records.size}) — page $pageNum/${chunks.size}", 40f, 40f, titlePaint)
        var y = 70f
        for (r in chunk) {
            canvas.drawText("${codeOf(r)} · ${titleOf(r)} — ${subtitleOf(r)} [${if (isActiveOf(r)) "Active" else "Inactive"}]", 40f, y, rowPaint)
            y += 16f
            rowIndex++
        }
        canvas.drawText("Generated ${java.time.LocalDateTime.now()} — ABM ERP", 40f, 815f, rowPaint)
        pdfDocument.finishPage(page)
        pageNum++
    }
    val file = File(context.getExternalFilesDir(null), "${entityLabel}_list_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/**
 * v113-129 — hands an already-written PDF file to Android's real print
 * subsystem (android.print.PrintManager), so "Print" opens the device's actual
 * print dialog (any installed printer app, PDF-to-file, etc.) instead of only
 * ever being a share-sheet in disguise. PrintDocumentAdapter here wraps a file
 * that's already fully rendered, so onWrite just streams it — no re-rendering.
 */
fun printPdfFile(context: Context, file: File, jobName: String) {
    val printManager = context.getSystemService(Context.PRINT_SERVICE) as android.print.PrintManager
    val adapter = object : android.print.PrintDocumentAdapter() {
        override fun onLayout(oldAttributes: android.print.PrintAttributes?, newAttributes: android.print.PrintAttributes, cancellationSignal: android.os.CancellationSignal?, callback: LayoutResultCallback, extras: android.os.Bundle?) {
            if (cancellationSignal?.isCanceled == true) { callback.onLayoutCancelled(); return }
            val info = android.print.PrintDocumentInfo.Builder(file.name).setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build()
            callback.onLayoutFinished(info, true)
        }
        override fun onWrite(pages: Array<out android.print.PageRange>?, destination: android.os.ParcelFileDescriptor, cancellationSignal: android.os.CancellationSignal?, callback: WriteResultCallback) {
            try {
                java.io.FileInputStream(file).use { input -> java.io.FileOutputStream(destination.fileDescriptor).use { output -> input.copyTo(output) } }
                callback.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
            } catch (e: Exception) {
                callback.onWriteFailed(e.message)
            }
        }
    }
    printManager.print(jobName, adapter, android.print.PrintAttributes.Builder().build())
}

/** Shared PDF-page bootstrap (company header + document title) reused by every structured template below, so each function only draws its own body content. */
private fun newInvoiceStylePage(title: String): Triple<android.graphics.pdf.PdfDocument, android.graphics.pdf.PdfDocument.Page, Float> {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas
    val headerPaint = android.graphics.Paint().apply { textSize = 20f; isFakeBoldText = true }
    val subHeaderPaint = android.graphics.Paint().apply { textSize = 12f; color = android.graphics.Color.DKGRAY }
    // v113-351 — was hardcoded "Mohona ERP", the wrong brand, on every PDF
    // built through this page factory. Real company name now.
    val pdfCompanyName = runCatching { com.abm.erp.data.MockRepository.companySettings().companyName }.getOrNull()?.ifBlank { null } ?: "ABM Corporation"
    canvas.drawText(pdfCompanyName, 40f, 45f, headerPaint)
    canvas.drawText(title, 40f, 67f, subHeaderPaint)
    return Triple(pdfDocument, page, 97f)
}

/**
 * Dealer Statement — Dealer profile + real PartyLedgerEntry history. Uses
 * MockRepository.partyLedgerFor's already-loaded Flow value at call time
 * (passed in as a plain List so this stays a non-suspend, non-Compose
 * function callable from anywhere).
 */
fun exportDealerStatementPdf(context: Context, dealer: com.abm.erp.data.Dealer, ledger: List<com.abm.erp.data.PartyLedgerEntry>): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("DEALER STATEMENT")
    val canvas = page.canvas
    val labelPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Dealer: ${dealer.name}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Zone: ${dealer.zone}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Classification: ${dealer.classification}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Current Due: ৳${"%.2f".format(dealer.dueBalance)}", 40f, y, totalPaint); y += 28f

    canvas.drawText("Date", 40f, y, labelPaint)
    canvas.drawText("Reason", 140f, y, labelPaint)
    canvas.drawText("Type", 380f, y, labelPaint)
    canvas.drawText("Amount", 460f, y, labelPaint)
    y += 6f
    canvas.drawLine(40f, y, 555f, y, bodyPaint)
    y += 16f
    if (ledger.isEmpty()) {
        canvas.drawText("Data unavailable — no ledger entries recorded yet.", 40f, y, bodyPaint)
    } else {
        ledger.forEach { entry ->
            if (y > 780f) return@forEach
            canvas.drawText("${entry.createdAt.toLocalDate()}", 40f, y, bodyPaint)
            canvas.drawText(entry.reason.take(30), 140f, y, bodyPaint)
            canvas.drawText(entry.type, 380f, y, bodyPaint)
            canvas.drawText("৳${"%.2f".format(entry.amount)}", 460f, y, bodyPaint)
            y += 16f
        }
    }
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "dealer_statement_${dealer.name.take(12)}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

fun exportPurchaseOrderPdf(context: Context, po: com.abm.erp.data.PurchaseOrder): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("PURCHASE ORDER")
    val canvas = page.canvas
    val labelPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("PO No: ${po.poNo}", 40f, y, bodyPaint)
    canvas.drawText("Date: ${po.createdAt.toLocalDate()}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Supplier: ${po.supplierName}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Status: ${po.status}", 40f, y, bodyPaint); y += 28f

    canvas.drawText("Item", 40f, y, labelPaint)
    canvas.drawText("Qty", 300f, y, labelPaint)
    canvas.drawText("Unit Cost", 370f, y, labelPaint)
    canvas.drawText("Amount", 480f, y, labelPaint)
    y += 6f
    canvas.drawLine(40f, y, 555f, y, bodyPaint)
    y += 16f
    po.lineItems.forEach { item ->
        if (y > 760f) return@forEach
        canvas.drawText(item.name.take(30), 40f, y, bodyPaint)
        canvas.drawText("${item.qty}", 300f, y, bodyPaint)
        canvas.drawText("৳${"%.2f".format(item.unitCost)}", 370f, y, bodyPaint)
        canvas.drawText("৳${"%.2f".format(item.lineTotal)}", 480f, y, bodyPaint)
        y += 18f
    }
    y += 12f
    canvas.drawLine(350f, y, 555f, y, bodyPaint)
    y += 22f
    canvas.drawText("Total:", 400f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(po.subTotal)}", 480f, y, totalPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "purchase_order_${po.poNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/** Production Sheet — ProductionOrder has no line-item breakdown in the current data model (BOM is a separate lookup by bomId this function doesn't join against), so this stays a header-level sheet rather than fabricating a materials table. */
fun exportProductionOrderPdf(context: Context, order: com.abm.erp.data.ProductionOrder): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("PRODUCTION SHEET")
    val canvas = page.canvas
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Order No: ${order.orderNo}", 40f, y, bodyPaint)
    canvas.drawText("Scheduled: ${order.scheduledDate.toLocalDate()}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Finished Product: ${order.finishedProductName}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Target Quantity: ${order.targetQty}", 40f, y, totalPaint); y += 22f
    canvas.drawText("Status: ${order.status}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Created by: ${order.createdBy.ifBlank { "Data unavailable" }}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("BOM Reference: ${order.bomId}", 40f, y, bodyPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "production_sheet_${order.orderNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

fun exportVoucherPdf(context: Context, voucher: com.abm.erp.data.Voucher): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("${voucher.type} VOUCHER")
    val canvas = page.canvas
    val labelPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Voucher No: ${voucher.voucherNo}", 40f, y, bodyPaint)
    canvas.drawText("Date: ${voucher.voucherDate.toLocalDate()}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Narration: ${voucher.narration.ifBlank { "Data unavailable" }}", 40f, y, bodyPaint); y += 28f

    canvas.drawText("Account", 40f, y, labelPaint)
    canvas.drawText("Debit", 350f, y, labelPaint)
    canvas.drawText("Credit", 460f, y, labelPaint)
    y += 6f
    canvas.drawLine(40f, y, 555f, y, bodyPaint)
    y += 16f
    voucher.lines.forEach { line ->
        if (y > 780f) return@forEach
        canvas.drawText(line.accountName.take(35), 40f, y, bodyPaint)
        canvas.drawText(if (line.debit > 0) "৳${"%.2f".format(line.debit)}" else "-", 350f, y, bodyPaint)
        canvas.drawText(if (line.credit > 0) "৳${"%.2f".format(line.credit)}" else "-", 460f, y, bodyPaint)
        y += 16f
    }
    y += 12f
    canvas.drawLine(300f, y, 555f, y, bodyPaint)
    y += 22f
    canvas.drawText("Total:", 250f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(voucher.totalDebit)}", 350f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(voucher.totalCredit)}", 460f, y, totalPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "voucher_${voucher.voucherNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/** Payslip — PayrollLine has no employee address/designation/period fields in the current model, so those are shown as "Data unavailable" rather than fabricated; every number shown (base pay, achievement%, commission, absence penalty, net payable) is a real stored/derived field. */
fun exportPayslipPdf(context: Context, line: com.abm.erp.data.PayrollLine): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("PAYSLIP")
    val canvas = page.canvas
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Employee: ${line.employeeName}", 40f, y, bodyPaint)
    canvas.drawText("ID: ${line.employeeId}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Pay Period: Data unavailable (not tracked per-line yet)", 40f, y, bodyPaint); y += 28f

    canvas.drawText("Base Pay:", 40f, y, bodyPaint)
    canvas.drawText("৳${"%.2f".format(line.basePay)}", 300f, y, bodyPaint); y += 18f
    canvas.drawText("Target vs Achieved:", 40f, y, bodyPaint)
    canvas.drawText("৳${"%.2f".format(line.targetAmount)} / ৳${"%.2f".format(line.achievedAmount)} (${"%.0f".format(line.achievementPct)}%)", 300f, y, bodyPaint); y += 18f
    canvas.drawText("Commission:", 40f, y, bodyPaint)
    canvas.drawText("৳${"%.2f".format(line.commission)}", 300f, y, bodyPaint); y += 18f
    canvas.drawText("Unapproved Absence Days:", 40f, y, bodyPaint)
    canvas.drawText("${line.unapprovedAbsenceDays} (−৳${"%.2f".format(line.absencePenalty)})", 300f, y, bodyPaint); y += 24f
    canvas.drawLine(40f, y, 555f, y, bodyPaint); y += 20f
    canvas.drawText("Net Payable:", 40f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(line.netPayable)}", 300f, y, totalPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "payslip_${line.employeeId}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

// ============================================================
// v113-263 — the person's own confirmed, concrete example: a Ledger
// screen (or any "whole screen" view with no single per-row record — a
// report, a summary — that UniversalActionMenu's per-record model
// doesn't fit) needs its own real Export/Share/Print, reachable from the
// module's own always-present ⋮, not a bespoke button built once per
// real label/value rows in, a real file/share/print action out — same
// proven FileProvider-share/PrintManager mechanism already used
// throughout this file, applied to whatever a screen registers via
// `RegisterModuleMenuContent` (core/ModuleDrawerScaffold.kt).
// ============================================================

/** Plain "Label: Value" text, one line per row — used for Share and as a plain-text fallback. */

/**
 * v113-350 — the person's point 3: shared/exported pictures were invisible —
 * written only to app-private storage (cacheDir / getExternalFilesDir), which
 * the gallery never scans. Not a Room matter at all (Room is the database;
 * images are files) — the app simply never told MediaStore about them. Every
 * image the app produces now ALSO lands in the device gallery under
 * Pictures/ABM ERP. minSdk 26 < Q, so both branches are real:
 *  - API 29+ — MediaStore insert with RELATIVE_PATH (no permission needed)
 *  - API 26–28 — legacy Pictures/ABM ERP file + MediaScanner broadcast
 * Best-effort by design: a gallery failure must never break the share/export
 * that produced the image, so callers ignore the return.
 */
fun publishImageToGallery(context: Context, bitmap: android.graphics.Bitmap, displayName: String): Boolean = try {
    if (android.os.Build.VERSION.SDK_INT >= 29) {
        val values = android.content.ContentValues().apply {
            put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "$displayName.png")
            put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ABM ERP")
        }
        val uri = context.contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri != null) {
            context.contentResolver.openOutputStream(uri)?.use { out -> bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out) }
            true
        } else false
    } else {
        @Suppress("DEPRECATION")
        val dir = java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_PICTURES), "ABM ERP").apply { if (!exists()) mkdirs() }
        val f = java.io.File(dir, "$displayName.png")
        java.io.FileOutputStream(f).use { out -> bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out) }
        context.sendBroadcast(android.content.Intent(android.content.Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, android.net.Uri.fromFile(f)))
        true
    }
} catch (e: Exception) {
    com.abm.erp.config.AppLog.w("StructuredExports", "gallery publish failed (share/export unaffected)", e)
    false
}

fun moduleSummaryText(title: String, rows: List<Pair<String, String>>): String =
    "$title (${java.time.LocalDate.now()})\n\n" + rows.joinToString("\n") { (label, value) -> "$label: $value" }

/**
 * v113-335 — the person reported Share STILL sending text after v113-331.
 * They were right, and my earlier fix was too narrow: I changed only the
 * Share item inside `UniversalActionMenu`. A project-wide grep then found
 * roughly twenty screens — Ledger, Reports, Payroll, Purchase,
 * Production, Chairman Hub, Boardroom, Notifications, Billing, Helpdesk,
 * Comms, Market, Tasks, GeoCRM and the browse list — each with its own
 * hand-rolled `ACTION_SEND` + `text/plain` block. Fixing one of twenty
 * and calling the feature done was the real mistake.
 *
 * This renders the summary as an image and shares that, which is what
 * was asked for: "text akare msg send na hoy... oi screen er main dwtar
 * view tai hbe."
 *
 * Falls back to plain text only if image generation genuinely fails
 * (no storage, render error) — sharing something beats sharing nothing,
 * and that fallback is exactly the previous behaviour.
 */
fun shareTextSummary(context: Context, title: String, text: String) {
    try {
        val bitmap = renderSummaryBitmap(title, text)
        publishImageToGallery(context, bitmap, "${title.replace(' ', '_')}_${System.currentTimeMillis()}")
        // v113-337 — the person's requirement: "Chobi banate kno vabei
        // bertho HOA jabe na" — image generation must not fail, ever.
        //
        // Writes to cacheDir, not getExternalFilesDir. External storage can
        // genuinely be unavailable (emulated storage unmounted, or
        // getExternalFilesDir returning null on some devices), and a null
        // there was one real way this whole path could collapse to text.
        // cacheDir is internal, always present, and needs no permission.
        //
        // The directory is also created if missing rather than assumed, so
        // a first-run device with no cache dir yet cannot fail here either.
        val dir = File(context.cacheDir, "shares").apply { if (!exists()) mkdirs() }
        // v113-358 — was .jpg/JPEG while the gallery copy above is already PNG;
        // one share produced two different formats of the same picture. PNG for
        // both, matching the person's own v113-350 choice (no recompression).
        val file = File(dir, "share_${System.currentTimeMillis()}.png")
        java.io.FileOutputStream(file).use { out ->
            bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
        }
        val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            putExtra(android.content.Intent.EXTRA_SUBJECT, title)
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(android.content.Intent.createChooser(intent, title))
    } catch (e: Exception) {
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_SUBJECT, title)
            putExtra(android.content.Intent.EXTRA_TEXT, text)
        }
        context.startActivity(android.content.Intent.createChooser(intent, title))
    }
}

/**
 * Renders a summary to a bitmap sized to its real content, wrapping long
 * lines at word boundaries. Same approach as `renderRecordBitmap` in
 * UniversalActionMenu (v113-331), kept here so every screen's Share can
 * reach it without depending on that file's private helpers.
 */
/**
 * v113-351 — THE styled document renderer (mock-up Style A — orange, the
 * person's own choice), shared by every share/export image in the app.
 * Replaces the plain drawText-only bitmap that made shared "images" look
 * like text on white — their exact complaint: "pic akare text send hoy."
 *
 * Layout, matching the approved JSX mock-up:
 *   header — company name (bold, dark) + timestamp right-aligned in orange
 *   3px orange rule
 *   body — each line parsed:
 *     "label: value"  → label grey left, value bold right (profile rows)
 *     "a | b | c"     → zebra table row, columns spread across the width
 *     anything else   → plain paragraph text, word-wrapped
 *   footer — "Generated … · <company>"  (the old renderer footer said
 *   "Mohona ERP" — the WRONG BRAND, a leftover; now the real company name)
 *
 * Bespoke templates (invoice grid with totals, ledger running balance,
 * profile with QR) ride on top per-screen in later batches; this shared
 * layer is what makes all ~50 generic sites styled at once.
 */
internal fun renderStyledDocumentBitmap(title: String, body: String): android.graphics.Bitmap {
    val width = 800
    val leftPad = 32f
    val orange = android.graphics.Color.parseColor("#F85606")
    val orangeDeep = android.graphics.Color.parseColor("#C74100")
    val textPrimary = android.graphics.Color.parseColor("#1E2430")
    val textSecondary = android.graphics.Color.parseColor("#6B7280")
    val zebra = android.graphics.Color.parseColor("#FAFAFB")
    val hairline = android.graphics.Color.parseColor("#E3E6EB")
    val companyName = runCatching { com.abm.erp.data.MockRepository.companySettings().companyName }.getOrNull()
        ?.ifBlank { null } ?: "ABM Corporation"

    val bodyPaint = android.graphics.Paint().apply { color = textPrimary; textSize = 22f; isAntiAlias = true }
    val labelPaint = android.graphics.Paint().apply { color = textSecondary; textSize = 21f; isAntiAlias = true }
    val valuePaint = android.graphics.Paint().apply { color = textPrimary; textSize = 22f; isFakeBoldText = true; isAntiAlias = true; textAlign = android.graphics.Paint.Align.RIGHT }
    val maxTextWidth = (width - 64).toFloat()

    data class Line(val kind: Int, val a: String = "", val b: String = "", val cols: List<String> = emptyList())
    val parsed = buildList {
        body.split("\n").forEach { raw ->
            val t = raw.trimEnd()
            when {
                t.isBlank() -> add(Line(0))
                t.contains(" | ") -> add(Line(3, cols = t.split(" | ").map { it.trim() }))
                // label: value — only when the label part is short enough to be a label,
                // so a sentence containing a colon stays a paragraph.
                t.contains(": ") && t.indexOf(": ") in 1..28 && !t.startsWith("http") ->
                    add(Line(2, a = t.substringBefore(": ").trim(), b = t.substringAfter(": ").trim()))
                else -> {
                    var remaining = t
                    while (remaining.isNotEmpty()) {
                        val fits = bodyPaint.breakText(remaining, true, maxTextWidth, null)
                        if (fits <= 0) { add(Line(1, a = remaining)); break }
                        val slice = remaining.take(fits)
                        val cut = if (fits < remaining.length) slice.lastIndexOf(' ').takeIf { it > 0 } ?: fits else fits
                        add(Line(1, a = remaining.take(cut).trimEnd()))
                        remaining = remaining.drop(cut).trimStart()
                    }
                }
            }
        }
    }

    val lineHeight = 34f
    val headerHeight = 118f
    val bottomPadding = 64f
    // v113-337's guarantees carry over unchanged: hard cap so a 100k-line body
    // can't OOM, floor so empty content can't make an invalid bitmap, and a
    // final "… আরও N লাইন" row when capped.
    val maxHeight = 12_000
    val neededHeight = (headerHeight + parsed.size * lineHeight + bottomPadding).toInt()
    val truncated = neededHeight > maxHeight
    val visibleLines = if (truncated) ((maxHeight - headerHeight - bottomPadding - lineHeight) / lineHeight).toInt().coerceAtLeast(1) else parsed.size
    val shown = if (truncated) parsed.take(visibleLines) + Line(1, a = "… আরও ${parsed.size - visibleLines} লাইন আছে") else parsed
    val height = (headerHeight + shown.size * lineHeight + bottomPadding).toInt().coerceIn(400, maxHeight)

    val bitmap = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)

    // header
    val companyPaint = android.graphics.Paint().apply { color = textPrimary; textSize = 30f; isFakeBoldText = true; isAntiAlias = true }
    val titlePaint = android.graphics.Paint().apply { color = orange; textSize = 26f; isFakeBoldText = true; isAntiAlias = true; textAlign = android.graphics.Paint.Align.RIGHT }
    val metaPaint = android.graphics.Paint().apply { color = textSecondary; textSize = 17f; isAntiAlias = true; textAlign = android.graphics.Paint.Align.RIGHT }
    canvas.drawText(companyName, leftPad, 52f, companyPaint)
    val now = java.time.LocalDateTime.now()
    canvas.drawText(title.take(38), width - leftPad, 48f, titlePaint)
    canvas.drawText("${now.toLocalDate()} ${"%02d:%02d".format(now.hour, now.minute)}", width - leftPad, 76f, metaPaint)
    val rulePaint = android.graphics.Paint().apply { color = orange }
    canvas.drawRect(0f, 92f, width.toFloat(), 95f, rulePaint)

    // body
    var y = headerHeight
    val zebraPaint = android.graphics.Paint().apply { color = zebra }
    val hairPaint = android.graphics.Paint().apply { color = hairline; strokeWidth = 1f }
    var tableRowIndex = 0
    shown.forEach { line ->
        when (line.kind) {
            2 -> {
                canvas.drawText(line.a, leftPad, y, labelPaint)
                canvas.drawText(line.b.take(52), width - leftPad, y, valuePaint)
            }
            3 -> {
                if (tableRowIndex % 2 == 1) canvas.drawRect(leftPad - 8f, y - 24f, width - leftPad + 8f, y + 8f, zebraPaint)
                canvas.drawLine(leftPad - 8f, y + 8f, width - leftPad + 8f, y + 8f, hairPaint)
                val n = line.cols.size.coerceAtLeast(1)
                // first column left-aligned and wider; the rest right-aligned
                val firstW = (width - 2 * leftPad) * 0.44f
                canvas.drawText(line.cols[0].take(30), leftPad, y, bodyPaint)
                if (n > 1) {
                    val restW = (width - 2 * leftPad - firstW) / (n - 1)
                    line.cols.drop(1).forEachIndexed { i, c ->
                        canvas.drawText(c.take(16), leftPad + firstW + restW * (i + 1), y, valuePaint)
                    }
                }
                tableRowIndex++
            }
            1 -> canvas.drawText(line.a, leftPad, y, bodyPaint)
        }
        if (line.kind != 3) tableRowIndex = 0
        y += lineHeight
    }

    // footer
    val footerPaint = android.graphics.Paint().apply { color = textSecondary; textSize = 15f; isAntiAlias = true }
    canvas.drawLine(leftPad, (height - 44).toFloat(), (width - leftPad), (height - 44).toFloat(), hairPaint)
    canvas.drawText("Generated $now · $companyName", leftPad, (height - 22).toFloat(), footerPaint)
    val deepPaint = android.graphics.Paint().apply { color = orangeDeep; textSize = 15f; isFakeBoldText = true; isAntiAlias = true; textAlign = android.graphics.Paint.Align.RIGHT }
    canvas.drawText("ABM ERP", width - leftPad, (height - 22).toFloat(), deepPaint)
    return bitmap
}

private fun renderSummaryBitmap(title: String, body: String): android.graphics.Bitmap =
    // v113-351 — delegates to the shared styled renderer; the old plain
    // white-text bitmap (with its wrong "Mohona ERP" brand) is gone.
    renderStyledDocumentBitmap(title, body)

/** Real CSV file — two columns (Field, Value), same write-and-return-File shape as exportListAsCsv. */
fun exportModuleSummaryCsv(context: Context, title: String, rows: List<Pair<String, String>>): File {
    val header = "${escapeCsvField("Field")},${escapeCsvField("Value")}"
    val body = rows.joinToString("\n") { (label, value) -> "${escapeCsvField(label)},${escapeCsvField(value)}" }
    val safeName = title.filter { it.isLetterOrDigit() }.take(40).ifBlank { "summary" }
    val file = File(context.getExternalFilesDir(null), "${safeName}_${System.currentTimeMillis()}.csv")
    file.writeText("$header\n$body")
    return file
}

/** Real, paginated summary PDF — same raw PdfDocument mechanism as every other export in this file. */
fun exportModuleSummaryPdf(context: Context, title: String, rows: List<Pair<String, String>>): File {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    val pageWidth = 595; val pageHeight = 842 // A4 at 72dpi
    val titlePaint = android.graphics.Paint().apply { textSize = 16f; isFakeBoldText = true }
    val rowPaint = android.graphics.Paint().apply { textSize = 11f }
    val rowsPerPage = 32
    val chunks = if (rows.isEmpty()) listOf(emptyList()) else rows.chunked(rowsPerPage)
    var pageNum = 1
    for (chunk in chunks) {
        val page = pdfDocument.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        val canvas = page.canvas
        canvas.drawText("$title — page $pageNum/${chunks.size}", 40f, 50f, titlePaint)
        canvas.drawText("${java.time.LocalDate.now()}", 40f, 70f, rowPaint)
        var y = 100f
        chunk.forEach { (label, value) ->
            canvas.drawText("$label:", 40f, y, rowPaint)
            canvas.drawText(value, 300f, y, rowPaint)
            y += 20f
        }
        canvas.drawText("Generated ${java.time.LocalDateTime.now()} — ABM ERP", 40f, 815f, rowPaint)
        pdfDocument.finishPage(page)
        pageNum++
    }
    val safeName = title.filter { it.isLetterOrDigit() }.take(40).ifBlank { "summary" }
    val file = File(context.getExternalFilesDir(null), "${safeName}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

// ─────────────────────────────────────────────────────────────────────────────
// v113-354 — Bespoke document templates (open item 1), Style A — orange, at
// exactly 2× the PDF exporters' coordinates (approved: "PDF-এর হুবহু ২× স্কেল
// copy", height grows with content). Four renderers share one masthead /
// footer / watermark so they can never drift apart:
//   renderInvoiceDocumentBitmap  — grid, totals, due box, status+payment pill
//   renderMemoDocumentBitmap     — memo's own fields only + stage strip
//   renderLedgerStatementBitmap  — Dr/Cr/Balance zebra + closing highlight
//   renderPartyProfileBitmap     — photo + QR side by side, rows, 3 stat cards
// QR rule everywhere: the caller passes a payload obtained ONLY through
// QrRegistry.payloadForApproved (or an entity-stored code that itself is
// issued at approval) — null draws no QR and, on invoice/memo, a watermark.
// Comments here are line comments only, deliberately: this file's history
// includes a nested block-comment trap (v113-347).
// ─────────────────────────────────────────────────────────────────────────────

private const val DOC_W = 1190
private const val DOC_L = 80f
private const val DOC_R = 1110f
private const val DOC_IW = DOC_R - DOC_L
private const val DOC_MAX_H = 12_000

private val docOrange = android.graphics.Color.rgb(0xF8, 0x56, 0x06)
private val docOrangeDark = android.graphics.Color.rgb(0xC2, 0x3F, 0x00)
private val docPeach = android.graphics.Color.rgb(0xFF, 0xD9, 0xC4)
private val docNavy = android.graphics.Color.rgb(0x1B, 0x24, 0x30)
private val docGray = android.graphics.Color.rgb(0x64, 0x74, 0x8B)
private val docLightGray = android.graphics.Color.rgb(0xF7, 0xF8, 0xFA)
private val docBorder = android.graphics.Color.rgb(0xD5, 0xDB, 0xE3)
private val docGreen = android.graphics.Color.rgb(0x22, 0xA0, 0x6B)
private val docRed = android.graphics.Color.rgb(0xE2, 0x4A, 0x3B)
private val docAmber = android.graphics.Color.rgb(0xF5, 0xA6, 0x23)
private val docBlue = android.graphics.Color.rgb(0x2E, 0x6F, 0xE0)

private fun docPaint(
    size: Float,
    bold: Boolean = false,
    color: Int = docNavy,
    align: android.graphics.Paint.Align = android.graphics.Paint.Align.LEFT,
    italic: Boolean = false,
) = android.graphics.Paint().apply {
    textSize = size
    isFakeBoldText = bold
    this.color = color
    isAntiAlias = true
    textAlign = align
    if (italic) textSkewX = -0.2f
}

private fun docFill(color: Int) = android.graphics.Paint().apply { this.color = color }

private fun docStroke(color: Int = docBorder, w: Float = 1.4f) =
    android.graphics.Paint().apply { this.color = color; strokeWidth = w; style = android.graphics.Paint.Style.STROKE }

private fun docLinePaint(color: Int = docBorder, w: Float = 1.4f) =
    android.graphics.Paint().apply { this.color = color; strokeWidth = w }

private fun docMoney(v: Double): String = "৳" + "%,.2f".format(v)

// Same mapping as exportSalesInvoicePdf's statusColor, extended with the
// party lifecycle states the profile card shows.
private fun docStatusColor(status: String): Int = when (status) {
    "PAID", "ACTIVE", "APPROVED", "FULFILLED" -> docGreen
    "CANCELLED", "REJECTED", "TERMINATED", "SUSPENDED" -> docRed
    "PARTIALLY_PAID", "PENDING", "PENDING_APPROVAL", "SUBMITTED", "PAUSED", "DRAFT" -> docAmber
    else -> docBlue
}

private fun docCompany(): Pair<String, String> {
    val c = runCatching { com.abm.erp.data.MockRepository.companySettings() }.getOrNull()
    val name = c?.companyName?.ifBlank { null } ?: "ABM Corporation"
    val meta = listOfNotNull(c?.companyAddress?.ifBlank { null }, c?.companyPhone?.ifBlank { null })
        .joinToString(" · ").ifBlank { "Enterprise. Control. Growth." }
    return name to meta
}

// Masthead — identical across all four templates. Returns the first free y.
private fun drawDocMasthead(canvas: android.graphics.Canvas, docTitle: String): Float {
    val company = docCompany()
    canvas.drawRoundRect(android.graphics.RectF(DOC_L, 60f, DOC_L + 64f, 124f), 10f, 10f, docFill(docOrange))
    canvas.drawText("ABM", DOC_L + 32f, 100f, docPaint(18f, bold = true, color = android.graphics.Color.WHITE, align = android.graphics.Paint.Align.CENTER))
    canvas.drawText(company.first.take(34), DOC_L + 84f, 92f, docPaint(30f, bold = true))
    canvas.drawText(company.second.take(64), DOC_L + 84f, 116f, docPaint(16f, color = docGray))
    canvas.drawText(docTitle.take(20), DOC_R, 96f, docPaint(34f, bold = true, color = docOrange, align = android.graphics.Paint.Align.RIGHT))
    canvas.drawRect(DOC_L, 144f, DOC_R, 149f, docFill(docOrange))
    canvas.drawRect(DOC_L, 149f, DOC_R, 152f, docFill(docPeach))
    return 180f
}

private fun drawDocFooter(canvas: android.graphics.Canvas, heightPx: Int, paymentLabel: String?) {
    val h = heightPx.toFloat()
    canvas.drawLine(DOC_L, h - 92f, DOC_R, h - 92f, docLinePaint())
    if (paymentLabel != null) {
        canvas.drawText("Payment: $paymentLabel", DOC_L, h - 58f, docPaint(18f, color = docGray))
    }
    val now = java.time.LocalDateTime.now()
    canvas.drawText(
        "Generated ${now.toLocalDate()} ${"%02d:%02d".format(now.hour, now.minute)} — ${docCompany().first}",
        DOC_L, h - 30f, docPaint(18f, color = docGray),
    )
    canvas.drawText("ABM ERP", DOC_R, h - 30f, docPaint(18f, bold = true, color = docOrangeDark, align = android.graphics.Paint.Align.RIGHT))
}

// Draws the registry QR into the given square. Returns false (and logs) if
// generation fails so the caller can draw an honest note instead — same
// isolation rule as the PDF's v113-211 QR try/catch.
private fun drawDocQr(canvas: android.graphics.Canvas, payload: String, left: Float, top: Float, size: Float): Boolean = try {
    val qr = com.abm.erp.util.QrCodeGenerator.generate(payload, 300)
    canvas.drawBitmap(qr, null, android.graphics.RectF(left, top, left + size, top + size), null)
    true
} catch (e: Exception) {
    com.abm.erp.config.AppLog.w("StructuredExports", "QR draw failed on styled document", e)
    false
}

// v113-354 — the Previous/Pending/Total Due math, extracted verbatim from
// exportSalesInvoicePdf (v113-213 additive pending rule included) so the PDF
// and the PNG document can never disagree on these figures.
internal data class InvoiceBalanceView(val previousDue: Double, val otherPendingSum: Double, val totalDue: Double)

internal fun invoiceBalanceView(invoice: SalesInvoice): InvoiceBalanceView {
    val liveDue = com.abm.erp.data.MockRepository.dealers.value.firstOrNull { it.id == invoice.dealerId }?.dueBalance ?: 0.0
    val hasSnapshot = invoice.closingDueSnapshot > 0.0 || invoice.previousDueSnapshot > 0.0
    val prevDue = if (hasSnapshot) invoice.previousDueSnapshot else (liveDue - invoice.total).coerceAtLeast(0.0)
    val approvedTotalDue = if (hasSnapshot) invoice.closingDueSnapshot else liveDue
    val otherPendingSum = com.abm.erp.data.MockRepository.salesInvoices.value
        .filter { it.dealerId == invoice.dealerId && it.status == "PENDING" && it.id != invoice.id && !it.isDeleted }
        .sumOf { it.total }
    return InvoiceBalanceView(prevDue, otherPendingSum, approvedTotalDue + otherPendingSum)
}

private fun docPaymentLabel(method: String?): String = when (method) {
    "CASH" -> "Paid (নগদ)"
    "COD" -> "Cash on Delivery"
    else -> "Due (বাকি)"
}

// ---- 1. Invoice ----
fun renderInvoiceDocumentBitmap(invoice: SalesInvoice, qrPayload: String?): android.graphics.Bitmap {
    val bal = invoiceBalanceView(invoice)
    val boxH = if (bal.otherPendingSum > 0) 176f else 144f
    val hasDisc = invoice.dealerDiscountPct > 0
    val fixedTop = 604f
    val below = 238f + (if (hasDisc) 32f else 0f) + boxH + 56f + 28f + 52f + 130f
    val maxRows = ((DOC_MAX_H - fixedTop - below) / 48f).toInt().coerceAtLeast(1)
    val overflow = invoice.lineItems.size > maxRows
    val rows = if (overflow) invoice.lineItems.take(maxRows - 1) else invoice.lineItems
    val rowCount = rows.size + (if (overflow) 1 else 0)
    val height = (fixedTop + rowCount * 48f + below).toInt().coerceAtLeast(400)

    val bitmap = android.graphics.Bitmap.createBitmap(DOC_W, height, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)
    var y = drawDocMasthead(canvas, "INVOICE")

    // meta box — number/date left, QR walled off right
    canvas.drawRect(android.graphics.RectF(DOC_L, y, DOC_R, y + 180f), docStroke())
    canvas.drawLine(DOC_R - 148f, y, DOC_R - 148f, y + 180f, docLinePaint())
    canvas.drawText("INVOICE NO", DOC_L + 24f, y + 40f, docPaint(16f, bold = true, color = docGray))
    canvas.drawText(invoice.invoiceNo.take(22), DOC_L + 24f, y + 72f, docPaint(22f, bold = true))
    canvas.drawText("DATE", DOC_L + 24f, y + 116f, docPaint(16f, bold = true, color = docGray))
    canvas.drawText(invoice.createdAt.toLocalDate().toString(), DOC_L + 24f, y + 148f, docPaint(22f))
    val qrCenter = DOC_R - 74f
    if (qrPayload != null) {
        if (drawDocQr(canvas, qrPayload, DOC_R - 128f, y + 20f, 108f)) {
            canvas.drawText("Scan to verify", qrCenter, y + 156f, docPaint(15f, color = docGray, align = android.graphics.Paint.Align.CENTER))
        } else {
            canvas.drawText("QR could not", qrCenter, y + 84f, docPaint(15f, color = docGray, align = android.graphics.Paint.Align.CENTER))
            canvas.drawText("be generated", qrCenter, y + 106f, docPaint(15f, color = docGray, align = android.graphics.Paint.Align.CENTER))
        }
    } else {
        canvas.drawText("QR issued on", qrCenter, y + 84f, docPaint(15f, color = docGray, align = android.graphics.Paint.Align.CENTER))
        canvas.drawText("approval only", qrCenter, y + 106f, docPaint(15f, color = docGray, align = android.graphics.Paint.Align.CENTER))
    }
    y += 200f

    // dealer bar + box
    canvas.drawRect(DOC_L, y, DOC_R, y + 40f, docFill(docOrange))
    canvas.drawText("DEALER", DOC_L + 20f, y + 28f, docPaint(19f, bold = true, color = android.graphics.Color.WHITE))
    y += 40f
    canvas.drawRect(android.graphics.RectF(DOC_L, y, DOC_R, y + 112f), docStroke())
    canvas.drawLine(DOC_L + DOC_IW / 2f, y, DOC_L + DOC_IW / 2f, y + 112f, docLinePaint())
    canvas.drawText(invoice.dealerName.take(34), DOC_L + 24f, y + 40f, docPaint(22f, bold = true))
    canvas.drawText(invoice.dealerZone.take(40), DOC_L + 24f, y + 72f, docPaint(18f, color = docGray))
    canvas.drawText("PAYMENT TERMS", DOC_L + DOC_IW / 2f + 24f, y + 36f, docPaint(16f, bold = true, color = docGray))
    canvas.drawText(if (invoice.status == "PAID") "Paid" else "Credit", DOC_L + DOC_IW / 2f + 24f, y + 68f, docPaint(22f, bold = true))
    canvas.drawText("Courier: ${invoice.courier?.ifBlank { null } ?: "—"}", DOC_L + DOC_IW / 2f + 24f, y + 96f, docPaint(18f, color = docGray))
    y += 140f

    // item grid
    val colX = floatArrayOf(DOC_L, DOC_L + 68f, DOC_L + 580f, DOC_L + 700f, DOC_L + 840f, DOC_R)
    canvas.drawRect(DOC_L, y, DOC_R, y + 44f, docFill(docOrange))
    val headPaint = docPaint(19f, bold = true, color = android.graphics.Color.WHITE)
    canvas.drawText("#", colX[0] + 16f, y + 30f, headPaint)
    canvas.drawText("Item / Product", colX[1] + 16f, y + 30f, headPaint)
    canvas.drawText("Qty", colX[2] + 16f, y + 30f, headPaint)
    canvas.drawText("Rate", colX[3] + 16f, y + 30f, headPaint)
    canvas.drawText("Amount", colX[4] + 16f, y + 30f, headPaint)
    y += 44f
    val cellStroke = docLinePaint(w = 1f)
    rows.forEachIndexed { idx, item ->
        val rowH = 48f
        if (idx % 2 == 1) canvas.drawRect(DOC_L, y, DOC_R, y + rowH, docFill(docLightGray))
        canvas.drawText("%02d".format(idx + 1), colX[0] + 16f, y + 32f, docPaint(22f))
        canvas.drawText(item.name.take(38), colX[1] + 16f, y + 32f, docPaint(22f))
        canvas.drawText("${item.qty}", colX[2] + 16f, y + 32f, docPaint(22f))
        canvas.drawText(docMoney(item.unitPrice), colX[3] + 16f, y + 32f, docPaint(22f))
        canvas.drawText(docMoney(item.lineTotal), colX[4] + 16f, y + 32f, docPaint(22f, bold = true))
        for (x in colX) canvas.drawLine(x, y, x, y + rowH, cellStroke)
        canvas.drawLine(DOC_L, y + rowH, DOC_R, y + rowH, cellStroke)
        y += rowH
    }
    if (overflow) {
        canvas.drawText(
            "… আরও ${invoice.lineItems.size - rows.size} items (PDF/CSV-এ সম্পূর্ণ তালিকা)",
            colX[1] + 16f, y + 32f, docPaint(20f, color = docGray, italic = true),
        )
        y += 48f
    }
    canvas.drawLine(DOC_L, y, DOC_R, y, docLinePaint())
    y += 42f

    // totals — ledger double rule above TOTAL, same figures as the PDF
    val tx = DOC_R - 400f
    canvas.drawText("Subtotal", tx, y, docPaint(18f, color = docGray))
    canvas.drawText(docMoney(invoice.subTotal), DOC_R, y, docPaint(22f, align = android.graphics.Paint.Align.RIGHT))
    y += 32f
    if (hasDisc) {
        canvas.drawText("Discount (${invoice.dealerDiscountPct}%)", tx, y, docPaint(18f, color = docGray))
        canvas.drawText("− " + docMoney(invoice.dealerDiscountAmt), DOC_R, y, docPaint(22f, align = android.graphics.Paint.Align.RIGHT))
        y += 32f
    }
    y += 8f
    val ruleDark = docLinePaint(docNavy, 2.4f)
    canvas.drawLine(tx, y, DOC_R, y, ruleDark)
    y += 6f
    canvas.drawLine(tx, y, DOC_R, y, ruleDark)
    y += 42f
    canvas.drawText("TOTAL", tx, y, docPaint(24f, bold = true))
    canvas.drawText(docMoney(invoice.netAfterDiscount), DOC_R, y, docPaint(38f, bold = true, color = docOrange, align = android.graphics.Paint.Align.RIGHT))
    y += 48f
    canvas.drawText(
        "In Words: ${com.abm.erp.core.amountInWords(invoice.netAfterDiscount)}".take(110),
        DOC_R, y, docPaint(18f, color = docGray, align = android.graphics.Paint.Align.RIGHT, italic = true),
    )
    y += 60f

    // balance box + status & payment pills
    canvas.drawRoundRect(android.graphics.RectF(DOC_L, y, DOC_L + 680f, y + boxH), 8f, 8f, docFill(docLightGray))
    var by = y + 40f
    canvas.drawText("Previous Due (Approved)", DOC_L + 24f, by, docPaint(18f, color = docGray))
    canvas.drawText(docMoney(bal.previousDue), DOC_L + 620f, by, docPaint(22f, align = android.graphics.Paint.Align.RIGHT))
    if (bal.otherPendingSum > 0) {
        by += 32f
        canvas.drawText("Pending (other invoices)", DOC_L + 24f, by, docPaint(18f, color = docAmber))
        canvas.drawText(docMoney(bal.otherPendingSum), DOC_L + 620f, by, docPaint(22f, color = docAmber, align = android.graphics.Paint.Align.RIGHT))
    }
    by += 32f
    canvas.drawText("This Invoice", DOC_L + 24f, by, docPaint(18f, color = docGray))
    canvas.drawText(docMoney(invoice.total), DOC_L + 620f, by, docPaint(22f, align = android.graphics.Paint.Align.RIGHT))
    by += 36f
    canvas.drawText(if (bal.otherPendingSum > 0) "Closing Due (incl. pending)" else "Closing Due", DOC_L + 24f, by, docPaint(19f, bold = true))
    canvas.drawText(docMoney(bal.totalDue), DOC_L + 620f, by, docPaint(24f, bold = true, color = docOrangeDark, align = android.graphics.Paint.Align.RIGHT))
    canvas.drawRoundRect(android.graphics.RectF(DOC_R - 200f, y + 12f, DOC_R, y + 52f), 20f, 20f, docFill(docStatusColor(invoice.status)))
    canvas.drawText(invoice.status.take(14), DOC_R - 100f, y + 39f, docPaint(19f, bold = true, color = android.graphics.Color.WHITE, align = android.graphics.Paint.Align.CENTER))
    canvas.drawRoundRect(android.graphics.RectF(DOC_R - 200f, y + 64f, DOC_R, y + 104f), 20f, 20f, docFill(android.graphics.Color.WHITE))
    canvas.drawRoundRect(android.graphics.RectF(DOC_R - 200f, y + 64f, DOC_R, y + 104f), 20f, 20f, docStroke(w = 1.6f))
    canvas.drawText(docPaymentLabel(invoice.paymentMethod).take(18), DOC_R - 100f, y + 91f, docPaint(18f, bold = true, align = android.graphics.Paint.Align.CENTER))
    y += boxH + 56f

    // signatures
    canvas.drawLine(DOC_L, y, DOC_L + 300f, y, docLinePaint())
    canvas.drawLine(DOC_L + 380f, y, DOC_L + 680f, y, docLinePaint())
    canvas.drawLine(DOC_L + 760f, y, DOC_R, y, docLinePaint())
    y += 28f
    canvas.drawText("Prepared By (${invoice.createdBy})".take(30), DOC_L, y, docPaint(18f, color = docGray))
    canvas.drawText("Checked By", DOC_L + 380f, y, docPaint(18f, color = docGray))
    canvas.drawText("Authorized By${invoice.signedByRole?.let { " ($it)" } ?: ""}".take(30), DOC_L + 760f, y, docPaint(18f, color = docGray))
    y += 52f
    canvas.drawText("Thank you for your business!", DOC_L + DOC_IW / 2f, y, docPaint(19f, bold = true, color = docGray, align = android.graphics.Paint.Align.CENTER))

    drawDocFooter(canvas, height, docPaymentLabel(invoice.paymentMethod))
    when {
        invoice.status == "CANCELLED" -> drawDocumentWatermark(canvas, "CANCELLED", 192f)
        !invoice.isApprovedOrLater -> drawDocumentWatermark(canvas, "DRAFT", 192f)
    }
    return bitmap
}

// ---- 2. Memo (RetailOrder) — its own template: no discount/due/courier,
// because RetailOrder carries none of those; a stage strip instead of a
// paid/due pill, because a memo's real state IS its stage. ----
fun renderMemoDocumentBitmap(order: com.abm.erp.data.RetailOrder, qrPayload: String?): android.graphics.Bitmap {
    // Legacy orders (pre-v71) have no structured lines — the human summary
    // string becomes one honest row instead of a fabricated breakdown.
    val displayRows: List<Triple<String, String, String>> =
        if (order.lineItems.isNotEmpty()) order.lineItems.map { Triple(it.name, "${it.qty}", docMoney(it.lineTotal)) }
        else listOf(Triple(order.items.ifBlank { "Items" }, "—", docMoney(order.amount)))
    val fixedTop = 604f
    val below = 366f
    val maxRows = ((DOC_MAX_H - fixedTop - below) / 48f).toInt().coerceAtLeast(1)
    val overflow = displayRows.size > maxRows
    val rows = if (overflow) displayRows.take(maxRows - 1) else displayRows
    val rowCount = rows.size + (if (overflow) 1 else 0)
    val height = (fixedTop + rowCount * 48f + below).toInt().coerceAtLeast(400)

    val bitmap = android.graphics.Bitmap.createBitmap(DOC_W, height, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)
    var y = drawDocMasthead(canvas, "RETAIL MEMO")

    canvas.drawRect(android.graphics.RectF(DOC_L, y, DOC_R, y + 180f), docStroke())
    canvas.drawLine(DOC_R - 148f, y, DOC_R - 148f, y + 180f, docLinePaint())
    canvas.drawText("MEMO NO", DOC_L + 24f, y + 40f, docPaint(16f, bold = true, color = docGray))
    canvas.drawText(order.orderNo.take(22), DOC_L + 24f, y + 72f, docPaint(22f, bold = true))
    canvas.drawText("LOGGED", DOC_L + 24f, y + 116f, docPaint(16f, bold = true, color = docGray))
    canvas.drawText(
        "${order.loggedAt.toLocalDate()} ${"%02d:%02d".format(order.loggedAt.hour, order.loggedAt.minute)}",
        DOC_L + 24f, y + 148f, docPaint(22f),
    )
    val qrCenter = DOC_R - 74f
    if (qrPayload != null) {
        if (drawDocQr(canvas, qrPayload, DOC_R - 128f, y + 20f, 108f)) {
            canvas.drawText("Scan to verify", qrCenter, y + 156f, docPaint(15f, color = docGray, align = android.graphics.Paint.Align.CENTER))
        } else {
            canvas.drawText("QR could not", qrCenter, y + 84f, docPaint(15f, color = docGray, align = android.graphics.Paint.Align.CENTER))
            canvas.drawText("be generated", qrCenter, y + 106f, docPaint(15f, color = docGray, align = android.graphics.Paint.Align.CENTER))
        }
    } else {
        canvas.drawText("QR issued when", qrCenter, y + 84f, docPaint(15f, color = docGray, align = android.graphics.Paint.Align.CENTER))
        canvas.drawText("dealer-routed", qrCenter, y + 106f, docPaint(15f, color = docGray, align = android.graphics.Paint.Align.CENTER))
    }
    y += 200f

    canvas.drawRect(DOC_L, y, DOC_R, y + 40f, docFill(docOrange))
    canvas.drawText("RETAILER", DOC_L + 20f, y + 28f, docPaint(19f, bold = true, color = android.graphics.Color.WHITE))
    y += 40f
    canvas.drawRect(android.graphics.RectF(DOC_L, y, DOC_R, y + 112f), docStroke())
    canvas.drawLine(DOC_L + DOC_IW / 2f, y, DOC_L + DOC_IW / 2f, y + 112f, docLinePaint())
    canvas.drawText(order.retailerName.take(34), DOC_L + 24f, y + 40f, docPaint(22f, bold = true))
    canvas.drawText(order.zone.take(40), DOC_L + 24f, y + 72f, docPaint(18f, color = docGray))
    canvas.drawText("LOGGED BY (SR)", DOC_L + DOC_IW / 2f + 24f, y + 36f, docPaint(16f, bold = true, color = docGray))
    canvas.drawText(order.loggedBySoId.take(24), DOC_L + DOC_IW / 2f + 24f, y + 68f, docPaint(22f, bold = true))
    canvas.drawText("Channel: ${order.channel}", DOC_L + DOC_IW / 2f + 24f, y + 96f, docPaint(18f, color = docGray))
    y += 140f

    val colX = floatArrayOf(DOC_L, DOC_L + 68f, DOC_L + 640f, DOC_L + 800f, DOC_R)
    canvas.drawRect(DOC_L, y, DOC_R, y + 44f, docFill(docOrange))
    val headPaint = docPaint(19f, bold = true, color = android.graphics.Color.WHITE)
    canvas.drawText("#", colX[0] + 16f, y + 30f, headPaint)
    canvas.drawText("Item / Product", colX[1] + 16f, y + 30f, headPaint)
    canvas.drawText("Qty", colX[2] + 16f, y + 30f, headPaint)
    canvas.drawText("Amount", colX[3] + 16f, y + 30f, headPaint)
    y += 44f
    val cellStroke = docLinePaint(w = 1f)
    rows.forEachIndexed { idx, (name, qty, amount) ->
        val rowH = 48f
        if (idx % 2 == 1) canvas.drawRect(DOC_L, y, DOC_R, y + rowH, docFill(docLightGray))
        canvas.drawText("%02d".format(idx + 1), colX[0] + 16f, y + 32f, docPaint(22f))
        canvas.drawText(name.take(46), colX[1] + 16f, y + 32f, docPaint(22f))
        canvas.drawText(qty, colX[2] + 16f, y + 32f, docPaint(22f))
        canvas.drawText(amount, colX[3] + 16f, y + 32f, docPaint(22f, bold = true))
        for (x in colX) canvas.drawLine(x, y, x, y + rowH, cellStroke)
        canvas.drawLine(DOC_L, y + rowH, DOC_R, y + rowH, cellStroke)
        y += rowH
    }
    if (overflow) {
        canvas.drawText(
            "… আরও ${displayRows.size - rows.size} items",
            colX[1] + 16f, y + 32f, docPaint(20f, color = docGray, italic = true),
        )
        y += 48f
    }
    canvas.drawLine(DOC_L, y, DOC_R, y, docLinePaint())
    y += 48f

    val tx = DOC_R - 400f
    val ruleDark = docLinePaint(docNavy, 2.4f)
    canvas.drawLine(tx, y, DOC_R, y, ruleDark)
    y += 6f
    canvas.drawLine(tx, y, DOC_R, y, ruleDark)
    y += 42f
    canvas.drawText("ORDER TOTAL", tx, y, docPaint(24f, bold = true))
    canvas.drawText(docMoney(order.amount), DOC_R, y, docPaint(38f, bold = true, color = docOrange, align = android.graphics.Paint.Align.RIGHT))
    y += 60f

    // stage strip — the memo's real lifecycle
    val stages = listOf("SO_LOGGED", "ASM_VERIFIED", "DEALER_ROUTED", "FULFILLED")
    val reached = stages.indexOf(order.stage.name)
    val segW = DOC_IW / stages.size
    stages.forEachIndexed { i, s ->
        val done = reached >= 0 && i <= reached
        canvas.drawRect(
            android.graphics.RectF(DOC_L + i * segW + 4f, y, DOC_L + (i + 1) * segW - 4f, y + 44f),
            docFill(if (done) docOrange else docLightGray),
        )
        canvas.drawText(
            s.replace("_", " "), DOC_L + i * segW + segW / 2f, y + 29f,
            docPaint(16f, bold = true, color = if (done) android.graphics.Color.WHITE else docGray, align = android.graphics.Paint.Align.CENTER),
        )
    }
    y += 80f
    val routedName = order.routedDealerId?.let { id ->
        com.abm.erp.data.MockRepository.dealers.value.firstOrNull { it.id == id }?.name
    } ?: "—"
    canvas.drawText("Routed dealer: $routedName".take(52), DOC_L, y, docPaint(18f, color = docGray))

    drawDocFooter(canvas, height, null)
    when {
        order.stage == com.abm.erp.data.OrderStage.REJECTED -> drawDocumentWatermark(canvas, "REJECTED", 192f)
        !order.isApprovedOrLater -> drawDocumentWatermark(canvas, "DRAFT", 192f)
    }
    return bitmap
}

// ---- 3. Ledger / Party Statement ----
fun renderLedgerStatementBitmap(
    partyName: String,
    partyMeta: String,
    fromLabel: String,
    toLabel: String,
    opening: Double,
    entries: List<com.abm.erp.data.PartyLedgerEntry>,
    totalDebit: Double,
    totalCredit: Double,
    closing: Double,
): android.graphics.Bitmap {
    val nonRow = 742f
    val maxRows = ((DOC_MAX_H - nonRow) / 46f).toInt().coerceAtLeast(1)
    val overflow = entries.size > maxRows
    val rows = if (overflow) entries.take(maxRows - 1) else entries
    val rowCount = rows.size + (if (overflow) 1 else 0)
    val height = (nonRow + rowCount * 46f).toInt().coerceAtLeast(400)

    val bitmap = android.graphics.Bitmap.createBitmap(DOC_W, height, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)
    var y = drawDocMasthead(canvas, "STATEMENT")

    canvas.drawRect(android.graphics.RectF(DOC_L, y, DOC_R, y + 120f), docStroke())
    val split = DOC_L + DOC_IW * 0.55f
    canvas.drawLine(split, y, split, y + 120f, docLinePaint())
    canvas.drawText("PARTY", DOC_L + 24f, y + 36f, docPaint(16f, bold = true, color = docGray))
    canvas.drawText(partyName.take(28), DOC_L + 24f, y + 70f, docPaint(26f, bold = true))
    canvas.drawText(partyMeta.take(40), DOC_L + 24f, y + 100f, docPaint(18f, color = docGray))
    canvas.drawText("PERIOD", split + 24f, y + 36f, docPaint(16f, bold = true, color = docGray))
    canvas.drawText("$fromLabel → $toLabel", split + 24f, y + 68f, docPaint(20f))
    canvas.drawText("Opening Balance: ${docMoney(opening)}", split + 24f, y + 100f, docPaint(18f, color = docGray))
    y += 148f

    val debitR = DOC_L + 768f
    val creditR = DOC_L + 944f
    val balR = DOC_R - 16f
    canvas.drawRect(DOC_L, y, DOC_R, y + 44f, docFill(docOrange))
    val headPaint = docPaint(19f, bold = true, color = android.graphics.Color.WHITE)
    val headPaintR = docPaint(19f, bold = true, color = android.graphics.Color.WHITE, align = android.graphics.Paint.Align.RIGHT)
    canvas.drawText("Date", DOC_L + 16f, y + 30f, headPaint)
    canvas.drawText("Particulars", DOC_L + 206f, y + 30f, headPaint)
    canvas.drawText("Debit", debitR, y + 30f, headPaintR)
    canvas.drawText("Credit", creditR, y + 30f, headPaintR)
    canvas.drawText("Balance", balR, y + 30f, headPaintR)
    y += 44f
    rows.forEachIndexed { idx, e ->
        val rowH = 46f
        if (idx % 2 == 1) canvas.drawRect(DOC_L, y, DOC_R, y + rowH, docFill(docLightGray))
        canvas.drawText(e.createdAt.toLocalDate().toString(), DOC_L + 16f, y + 31f, docPaint(20f, color = docGray))
        canvas.drawText(e.reason.take(34), DOC_L + 206f, y + 31f, docPaint(20f))
        if (e.type == "DEBIT") {
            canvas.drawText(docMoney(e.amount), debitR, y + 31f, docPaint(20f, align = android.graphics.Paint.Align.RIGHT))
            canvas.drawText("—", creditR, y + 31f, docPaint(20f, color = docBorder, align = android.graphics.Paint.Align.RIGHT))
        } else {
            canvas.drawText("—", debitR, y + 31f, docPaint(20f, color = docBorder, align = android.graphics.Paint.Align.RIGHT))
            canvas.drawText(docMoney(e.amount), creditR, y + 31f, docPaint(20f, color = docGreen, align = android.graphics.Paint.Align.RIGHT))
        }
        canvas.drawText(docMoney(e.balanceAfter), balR, y + 31f, docPaint(20f, bold = true, align = android.graphics.Paint.Align.RIGHT))
        canvas.drawLine(DOC_L, y + rowH, DOC_R, y + rowH, docLinePaint(w = 1f))
        y += rowH
    }
    if (overflow) {
        canvas.drawText(
            "… আরও ${entries.size - rows.size} লাইন (CSV/PDF-এ সম্পূর্ণ)",
            DOC_L + 206f, y + 31f, docPaint(20f, color = docGray, italic = true),
        )
        y += 46f
    }
    canvas.drawLine(DOC_L, y, DOC_R, y, docLinePaint())
    y += 8f
    canvas.drawRect(DOC_L, y, DOC_R, y + 48f, docFill(android.graphics.Color.rgb(0xEE, 0xF1, 0xF5)))
    canvas.drawText("Period Total", DOC_L + 16f, y + 32f, docPaint(20f, bold = true))
    canvas.drawText(docMoney(totalDebit), debitR, y + 32f, docPaint(20f, bold = true, align = android.graphics.Paint.Align.RIGHT))
    canvas.drawText(docMoney(totalCredit), creditR, y + 32f, docPaint(20f, bold = true, color = docGreen, align = android.graphics.Paint.Align.RIGHT))
    y += 88f
    canvas.drawRoundRect(android.graphics.RectF(DOC_L, y, DOC_R, y + 96f), 10f, 10f, docFill(android.graphics.Color.rgb(0xFF, 0xF3, 0xEC)))
    canvas.drawRoundRect(android.graphics.RectF(DOC_L, y, DOC_R, y + 96f), 10f, 10f, docStroke(docOrange, 2f))
    canvas.drawText("CLOSING BALANCE", DOC_L + 28f, y + 40f, docPaint(18f, bold = true, color = docOrangeDark))
    canvas.drawText("Approved postings only · pending invoices excluded", DOC_L + 28f, y + 72f, docPaint(17f, color = docGray))
    canvas.drawText(docMoney(closing), DOC_R - 28f, y + 64f, docPaint(44f, bold = true, color = docOrange, align = android.graphics.Paint.Align.RIGHT))

    drawDocFooter(canvas, height, null)
    return bitmap
}

// ---- 4. Party profile (dealer/retailer) ----
data class DocStatCard(val label: String, val value: String, val sub: String, val accent: Boolean = false)

fun renderPartyProfileBitmap(
    context: Context,
    docTitle: String,
    name: String,
    code: String,
    status: String,
    photoUri: String?,
    qrPayload: String?,
    rows: List<Pair<String, String>>,
    cards: List<DocStatCard>,
): android.graphics.Bitmap {
    val height = (180f + 300f + rows.size * 46f + 30f + 130f + 130f).toInt().coerceAtLeast(400)
    val bitmap = android.graphics.Bitmap.createBitmap(DOC_W, height, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)
    var y = drawDocMasthead(canvas, docTitle)

    // photo left — real photo center-cropped, or an honest initial-avatar
    // fallback when photoUri is null or unreadable (never a lying blank box)
    canvas.drawRect(android.graphics.RectF(DOC_L, y, DOC_L + 260f, y + 260f), docStroke())
    val photo = photoUri?.let { uriStr ->
        runCatching {
            context.contentResolver.openInputStream(android.net.Uri.parse(uriStr))
                ?.use { android.graphics.BitmapFactory.decodeStream(it) }
        }.getOrNull()
    }
    if (photo != null) {
        val side = minOf(photo.width, photo.height)
        val srcL = (photo.width - side) / 2
        val srcT = (photo.height - side) / 2
        canvas.drawBitmap(
            photo,
            android.graphics.Rect(srcL, srcT, srcL + side, srcT + side),
            android.graphics.RectF(DOC_L + 2f, y + 2f, DOC_L + 258f, y + 258f),
            null,
        )
    } else {
        canvas.drawCircle(DOC_L + 130f, y + 120f, 70f, docFill(docOrange))
        canvas.drawText(
            name.trim().take(1).ifBlank { "?" }, DOC_L + 130f, y + 147f,
            docPaint(76f, bold = true, color = android.graphics.Color.WHITE, align = android.graphics.Paint.Align.CENTER),
        )
        canvas.drawText("ছবি নেই", DOC_L + 130f, y + 232f, docPaint(17f, color = docGray, align = android.graphics.Paint.Align.CENTER))
    }

    canvas.drawText(name.take(26), DOC_L + 300f, y + 48f, docPaint(34f, bold = true))
    canvas.drawText(code.take(24), DOC_L + 300f, y + 84f, docPaint(20f, color = docOrangeDark))
    canvas.drawRoundRect(android.graphics.RectF(DOC_L + 300f, y + 104f, DOC_L + 450f, y + 142f), 19f, 19f, docFill(docStatusColor(status)))
    canvas.drawText(status.take(12), DOC_L + 375f, y + 130f, docPaint(18f, bold = true, color = android.graphics.Color.WHITE, align = android.graphics.Paint.Align.CENTER))

    canvas.drawRect(android.graphics.RectF(DOC_R - 220f, y, DOC_R, y + 220f), docStroke())
    if (qrPayload != null && drawDocQr(canvas, qrPayload, DOC_R - 200f, y + 20f, 180f)) {
        canvas.drawText("Scan for record", DOC_R - 110f, y + 250f, docPaint(17f, color = docGray, align = android.graphics.Paint.Align.CENTER))
    } else {
        canvas.drawText("QR pending", DOC_R - 110f, y + 104f, docPaint(17f, color = docGray, align = android.graphics.Paint.Align.CENTER))
        canvas.drawText("approval", DOC_R - 110f, y + 128f, docPaint(17f, color = docGray, align = android.graphics.Paint.Align.CENTER))
    }
    y += 300f

    rows.forEach { (label, value) ->
        canvas.drawText(label.take(24), DOC_L, y, docPaint(20f, color = docGray))
        canvas.drawText(value.take(44), DOC_R, y, docPaint(22f, bold = true, align = android.graphics.Paint.Align.RIGHT))
        canvas.drawLine(DOC_L, y + 14f, DOC_R, y + 14f, docLinePaint(android.graphics.Color.rgb(0xED, 0xF0, 0xF4), 1f))
        y += 46f
    }
    y += 30f

    val cardW = (DOC_IW - 40f) / 3f
    cards.take(3).forEachIndexed { i, c ->
        val x = DOC_L + i * (cardW + 20f)
        canvas.drawRoundRect(android.graphics.RectF(x, y, x + cardW, y + 130f), 10f, 10f, docFill(docLightGray))
        canvas.drawRoundRect(android.graphics.RectF(x, y, x + cardW, y + 130f), 10f, 10f, docStroke())
        canvas.drawText(c.label.take(16), x + 20f, y + 36f, docPaint(17f, bold = true, color = docGray))
        canvas.drawText(c.value.take(14), x + 20f, y + 88f, docPaint(34f, bold = true, color = if (c.accent) docOrange else docNavy))
        canvas.drawText(c.sub.take(20), x + 20f, y + 114f, docPaint(16f, color = docGray))
    }

    drawDocFooter(canvas, height, null)
    return bitmap
}

// Shares a bespoke document bitmap: gallery copy (Pictures/ABM ERP) + PNG in
// cacheDir for FileProvider + ACTION_SEND. PNG, per the person's own choice
// (v113-350): edits don't hide in recompression. Callers keep their own
// fallback to shareTextSummary — something must always go out.
fun shareStyledDocumentImage(context: Context, label: String, bitmap: android.graphics.Bitmap) {
    publishImageToGallery(context, bitmap, "${label.replace(' ', '_')}_${System.currentTimeMillis()}")
    val dir = File(context.cacheDir, "shares").apply { if (!exists()) mkdirs() }
    val file = File(dir, "share_${System.currentTimeMillis()}.png")
    java.io.FileOutputStream(file).use { out -> bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out) }
    val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "image/png"
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        putExtra(android.content.Intent.EXTRA_SUBJECT, label)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(android.content.Intent.createChooser(intent, label))
}
