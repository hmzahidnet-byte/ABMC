package com.abm.erp.config

import com.abm.erp.BuildConfig

/**
 * Part S — Release Configuration. Centralizes the DEBUG/STAGING/PRODUCTION
 * distinction instead of scattering `BuildConfig.DEBUG` checks across the
 * codebase. Every "is this feature allowed" question in Parts D/E/H/I
 * routes through this object.
 */
enum class Environment { DEBUG, STAGING, PRODUCTION }

object AppEnvironment {
    val current: Environment = when (BuildConfig.APP_ENVIRONMENT) {
        "PRODUCTION" -> Environment.PRODUCTION
        "STAGING" -> Environment.STAGING
        else -> Environment.DEBUG
    }

    // v113-192 — added after a real debugging dead-end: a fix was shipped
    // (v113-191), the person genuinely reinstalled, and the bug still
    // reproduced identically — with no way, from inside the app itself, to
    // confirm whether the new code had actually taken effect on the device
    // (no version/build indicator existed anywhere in the UI). This one
    // constant, shown small on the login screen below, is the single
    // source of truth to check going forward: bump it with every shipped
    // zip, and a glance at the login screen answers "did my install
    // actually pick up the new build" without guessing or re-deriving it
    // from behavior alone.
    const val BUILD_TAG = "v113-374"
    val isProduction: Boolean get() = current == Environment.PRODUCTION
    val isDebugOrStaging: Boolean get() = !isProduction

    // Part S — production must disable all of these, centrally, not per-file.
    val demoAccountsAllowed: Boolean get() = !isProduction
    val demoOtpAllowed: Boolean get() = current == Environment.DEBUG // stricter than staging — mock OTP never in staging either, only local debug
    val simulatedDeviceApprovalAllowed: Boolean get() = current == Environment.DEBUG
    val staticRecoveryCodeAllowed: Boolean get() = false // never allowed in any build — Part E removes it outright regardless of environment
    val seedDemoDataAllowed: Boolean get() = !isProduction
    val debugLoggingEnabled: Boolean get() = !isProduction
}
