package com.abm.erp.presence

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.abm.erp.MainActivity
import com.abm.erp.data.MockRepository
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

/**
 * "Live Presence Heartbeat" — runs as a foreground service (Android requires
 * this for any background location access, plus a persistent notification
 * the person can always see and dismiss-by-stopping) and periodically pulls
 * one GPS fix, feeding it to MockRepository.recordPresenceCheckIn — which
 * both extends the existing route-breadcrumb trail (GeoCrmScreen) AND writes
 * today's attendance record, which is what "Login = Auto Attendance" and
 * payroll's absencePenalty ultimately read.
 *
 * Deliberately NOT started automatically at login — see the toggle on
 * GeoCrmScreen. Requesting background location is a heavier ask than
 * foreground-only, so it's opt-in, not forced.
 */
class PresenceHeartbeatService : Service() {
    private val fusedLocationClient by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private var locationCallback: LocationCallback? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        startLocationUpdates()
        return START_STICKY
    }

    @SuppressLint("MissingPermission") // caller (the toggle in GeoCrmScreen) only starts this service after confirming both location permissions are granted
    private fun startLocationUpdates() {
        val request = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, HEARTBEAT_INTERVAL_MS)
            .setMinUpdateIntervalMillis(HEARTBEAT_INTERVAL_MS)
            .build()
        val callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                val user = MockRepository.currentUser
                MockRepository.recordPresenceCheckIn(user.employeeId, user.name, loc.latitude, loc.longitude, loc.isFromMockProvider)
            }
        }
        locationCallback = callback
        try {
            fusedLocationClient.requestLocationUpdates(request, callback, mainLooper)
        } catch (e: SecurityException) {
            stopSelf() // permission wasn't actually granted — don't keep a broken foreground service alive
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(CHANNEL_ID, "Attendance tracking", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ABM ERP is tracking your location")
            .setContentText("Used for attendance and territory verification while you're on duty.")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        locationCallback?.let { fusedLocationClient.removeLocationUpdates(it) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val NOTIFICATION_ID = 4201
        private const val CHANNEL_ID = "presence_heartbeat"
        private const val HEARTBEAT_INTERVAL_MS = 30 * 60 * 1000L // ৩০ মিনিট

        fun start(context: Context) {
            val intent = Intent(context, PresenceHeartbeatService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, PresenceHeartbeatService::class.java))
        }

        fun isBackgroundLocationGranted(context: Context): Boolean {
            val fine = androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
            val background = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_BACKGROUND_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
            } else true // pre-Android 10, foreground permission covers background too
            return fine && background
        }
    }
}
