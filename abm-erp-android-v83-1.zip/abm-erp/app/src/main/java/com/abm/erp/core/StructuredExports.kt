package com.abm.erp.core

import android.content.Context
import com.abm.erp.data.SalesInvoice
import java.io.File

/**
 * Task D — structured business-document export. Unlike the generic
 * title/body fallback in UniversalActionMenu.kt, this draws an actual
 * invoice layout: company header, reference, date, dealer, a real
 * line-item table (name/qty/unit price/discount/line total), subtotal,
 * discount amount, grand total, status and a footer — using ONLY fields
 * that genuinely exist on SalesInvoice. No fabricated line items or totals.
 *
 * This is the first of the requested structured templates to be
 * completed; Dealer Statement, Purchase Order, Production Sheet,
 * Voucher/Ledger record and Payslip still use the generic fallback as of
 * this version (see the v82 continuation report's honest gap list).
 */
fun exportSalesInvoicePdf(context: Context, invoice: SalesInvoice): File {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas

    val headerPaint = android.graphics.Paint().apply { textSize = 20f; isFakeBoldText = true }
    val subHeaderPaint = android.graphics.Paint().apply { textSize = 12f; color = android.graphics.Color.DKGRAY }
    val labelPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }

    var y = 45f
    canvas.drawText("Mohona ERP", 40f, y, headerPaint)
    y += 22f
    canvas.drawText("SALES INVOICE", 40f, y, subHeaderPaint)
    y += 30f
    canvas.drawText("Invoice No: ${invoice.invoiceNo}", 40f, y, bodyPaint)
    canvas.drawText("Date: ${invoice.createdAt.toLocalDate()}", 350f, y, bodyPaint)
    y += 18f
    canvas.drawText("Dealer: ${invoice.dealerName} (${invoice.dealerZone})", 40f, y, bodyPaint)
    y += 18f
    canvas.drawText("Status: ${invoice.status}", 40f, y, bodyPaint)
    y += 28f

    // Line-item table header
    canvas.drawText("Item", 40f, y, labelPaint)
    canvas.drawText("Qty", 280f, y, labelPaint)
    canvas.drawText("Unit Price", 350f, y, labelPaint)
    canvas.drawText("Disc%", 440f, y, labelPaint)
    canvas.drawText("Amount", 500f, y, labelPaint)
    y += 6f
    canvas.drawLine(40f, y, 555f, y, bodyPaint)
    y += 16f

    invoice.lineItems.forEach { item ->
        if (y > 760f) return@forEach // page-overflow guard — this fallback simply stops adding rows rather than crashing; multi-page support is a future refinement
        canvas.drawText(item.name.take(28), 40f, y, bodyPaint)
        canvas.drawText("${item.qty}", 280f, y, bodyPaint)
        canvas.drawText("৳${"%.2f".format(item.unitPrice)}", 350f, y, bodyPaint)
        canvas.drawText("${item.discountPct}%", 440f, y, bodyPaint)
        canvas.drawText("৳${"%.2f".format(item.lineTotal)}", 500f, y, bodyPaint)
        y += 18f
    }

    y += 10f
    canvas.drawLine(300f, y, 555f, y, bodyPaint)
    y += 20f
    canvas.drawText("Subtotal:", 400f, y, bodyPaint)
    canvas.drawText("৳${"%.2f".format(invoice.subTotal)}", 500f, y, bodyPaint)
    y += 18f
    canvas.drawText("Discount (${invoice.dealerDiscountPct}%):", 400f, y, bodyPaint)
    canvas.drawText("৳${"%.2f".format(invoice.dealerDiscountAmt)}", 500f, y, bodyPaint)
    y += 22f
    canvas.drawText("Grand Total:", 400f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(invoice.netAfterDiscount)}", 500f, y, totalPaint)
    y += 40f
    canvas.drawText("Created by ${invoice.createdBy} — generated ${java.time.LocalDateTime.now()}", 40f, 800f, subHeaderPaint)

    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "invoice_${invoice.invoiceNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/** Shared FileProvider-share step for every structured PDF below — one place to get the MIME type/authority/error-safety right instead of repeating it at each call site. */
fun shareStructuredPdf(context: Context, file: File, label: String) {
    val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(android.content.Intent.createChooser(intent, label))
}

/** Shared PDF-page bootstrap (company header + document title) reused by every structured template below, so each function only draws its own body content. */
private fun newInvoiceStylePage(title: String): Triple<android.graphics.pdf.PdfDocument, android.graphics.pdf.PdfDocument.Page, Float> {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas
    val headerPaint = android.graphics.Paint().apply { textSize = 20f; isFakeBoldText = true }
    val subHeaderPaint = android.graphics.Paint().apply { textSize = 12f; color = android.graphics.Color.DKGRAY }
    canvas.drawText("Mohona ERP", 40f, 45f, headerPaint)
    canvas.drawText(title, 40f, 67f, subHeaderPaint)
    return Triple(pdfDocument, page, 97f)
}

/**
 * Dealer Statement — Dealer profile + real PartyLedgerEntry history. Uses
 * MockRepository.partyLedgerFor's already-loaded Flow value at call time
 * (passed in as a plain List so this stays a non-suspend, non-Compose
 * function callable from anywhere).
 */
fun exportDealerStatementPdf(context: Context, dealer: com.abm.erp.data.Dealer, ledger: List<com.abm.erp.data.PartyLedgerEntry>): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("DEALER STATEMENT")
    val canvas = page.canvas
    val labelPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Dealer: ${dealer.name}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Zone: ${dealer.zone}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Classification: ${dealer.classification}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Current Due: ৳${"%.2f".format(dealer.dueBalance)}", 40f, y, totalPaint); y += 28f

    canvas.drawText("Date", 40f, y, labelPaint)
    canvas.drawText("Reason", 140f, y, labelPaint)
    canvas.drawText("Type", 380f, y, labelPaint)
    canvas.drawText("Amount", 460f, y, labelPaint)
    y += 6f
    canvas.drawLine(40f, y, 555f, y, bodyPaint)
    y += 16f
    if (ledger.isEmpty()) {
        canvas.drawText("Data unavailable — no ledger entries recorded yet.", 40f, y, bodyPaint)
    } else {
        ledger.forEach { entry ->
            if (y > 780f) return@forEach
            canvas.drawText("${entry.createdAt.toLocalDate()}", 40f, y, bodyPaint)
            canvas.drawText(entry.reason.take(30), 140f, y, bodyPaint)
            canvas.drawText(entry.type, 380f, y, bodyPaint)
            canvas.drawText("৳${"%.2f".format(entry.amount)}", 460f, y, bodyPaint)
            y += 16f
        }
    }
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "dealer_statement_${dealer.name.take(12)}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

fun exportPurchaseOrderPdf(context: Context, po: com.abm.erp.data.PurchaseOrder): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("PURCHASE ORDER")
    val canvas = page.canvas
    val labelPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("PO No: ${po.poNo}", 40f, y, bodyPaint)
    canvas.drawText("Date: ${po.createdAt.toLocalDate()}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Supplier: ${po.supplierName}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Status: ${po.status}", 40f, y, bodyPaint); y += 28f

    canvas.drawText("Item", 40f, y, labelPaint)
    canvas.drawText("Qty", 300f, y, labelPaint)
    canvas.drawText("Unit Cost", 370f, y, labelPaint)
    canvas.drawText("Amount", 480f, y, labelPaint)
    y += 6f
    canvas.drawLine(40f, y, 555f, y, bodyPaint)
    y += 16f
    po.lineItems.forEach { item ->
        if (y > 760f) return@forEach
        canvas.drawText(item.name.take(30), 40f, y, bodyPaint)
        canvas.drawText("${item.qty}", 300f, y, bodyPaint)
        canvas.drawText("৳${"%.2f".format(item.unitCost)}", 370f, y, bodyPaint)
        canvas.drawText("৳${"%.2f".format(item.lineTotal)}", 480f, y, bodyPaint)
        y += 18f
    }
    y += 12f
    canvas.drawLine(350f, y, 555f, y, bodyPaint)
    y += 22f
    canvas.drawText("Total:", 400f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(po.subTotal)}", 480f, y, totalPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "purchase_order_${po.poNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/** Production Sheet — ProductionOrder has no line-item breakdown in the current data model (BOM is a separate lookup by bomId this function doesn't join against), so this stays a header-level sheet rather than fabricating a materials table. */
fun exportProductionOrderPdf(context: Context, order: com.abm.erp.data.ProductionOrder): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("PRODUCTION SHEET")
    val canvas = page.canvas
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Order No: ${order.orderNo}", 40f, y, bodyPaint)
    canvas.drawText("Scheduled: ${order.scheduledDate.toLocalDate()}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Finished Product: ${order.finishedProductName}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Target Quantity: ${order.targetQty}", 40f, y, totalPaint); y += 22f
    canvas.drawText("Status: ${order.status}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Created by: ${order.createdBy.ifBlank { "Data unavailable" }}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("BOM Reference: ${order.bomId}", 40f, y, bodyPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "production_sheet_${order.orderNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

fun exportVoucherPdf(context: Context, voucher: com.abm.erp.data.Voucher): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("${voucher.type} VOUCHER")
    val canvas = page.canvas
    val labelPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Voucher No: ${voucher.voucherNo}", 40f, y, bodyPaint)
    canvas.drawText("Date: ${voucher.voucherDate.toLocalDate()}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Narration: ${voucher.narration.ifBlank { "Data unavailable" }}", 40f, y, bodyPaint); y += 28f

    canvas.drawText("Account", 40f, y, labelPaint)
    canvas.drawText("Debit", 350f, y, labelPaint)
    canvas.drawText("Credit", 460f, y, labelPaint)
    y += 6f
    canvas.drawLine(40f, y, 555f, y, bodyPaint)
    y += 16f
    voucher.lines.forEach { line ->
        if (y > 780f) return@forEach
        canvas.drawText(line.accountName.take(35), 40f, y, bodyPaint)
        canvas.drawText(if (line.debit > 0) "৳${"%.2f".format(line.debit)}" else "-", 350f, y, bodyPaint)
        canvas.drawText(if (line.credit > 0) "৳${"%.2f".format(line.credit)}" else "-", 460f, y, bodyPaint)
        y += 16f
    }
    y += 12f
    canvas.drawLine(300f, y, 555f, y, bodyPaint)
    y += 22f
    canvas.drawText("Total:", 250f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(voucher.totalDebit)}", 350f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(voucher.totalCredit)}", 460f, y, totalPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "voucher_${voucher.voucherNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/** Payslip — PayrollLine has no employee address/designation/period fields in the current model, so those are shown as "Data unavailable" rather than fabricated; every number shown (base pay, achievement%, commission, absence penalty, net payable) is a real stored/derived field. */
fun exportPayslipPdf(context: Context, line: com.abm.erp.data.PayrollLine): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("PAYSLIP")
    val canvas = page.canvas
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Employee: ${line.employeeName}", 40f, y, bodyPaint)
    canvas.drawText("ID: ${line.employeeId}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Pay Period: Data unavailable (not tracked per-line yet)", 40f, y, bodyPaint); y += 28f

    canvas.drawText("Base Pay:", 40f, y, bodyPaint)
    canvas.drawText("৳${"%.2f".format(line.basePay)}", 300f, y, bodyPaint); y += 18f
    canvas.drawText("Target vs Achieved:", 40f, y, bodyPaint)
    canvas.drawText("৳${"%.2f".format(line.targetAmount)} / ৳${"%.2f".format(line.achievedAmount)} (${"%.0f".format(line.achievementPct)}%)", 300f, y, bodyPaint); y += 18f
    canvas.drawText("Commission:", 40f, y, bodyPaint)
    canvas.drawText("৳${"%.2f".format(line.commission)}", 300f, y, bodyPaint); y += 18f
    canvas.drawText("Unapproved Absence Days:", 40f, y, bodyPaint)
    canvas.drawText("${line.unapprovedAbsenceDays} (−৳${"%.2f".format(line.absencePenalty)})", 300f, y, bodyPaint); y += 24f
    canvas.drawLine(40f, y, 555f, y, bodyPaint); y += 20f
    canvas.drawText("Net Payable:", 40f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(line.netPayable)}", 300f, y, totalPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "payslip_${line.employeeId}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}
