package com.abm.erp.ui.purchase

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.BackToSubMenuLink
import com.abm.erp.core.GlassCard
import com.abm.erp.core.ModuleGradientHeader
import com.abm.erp.core.SubModuleGrid
import com.abm.erp.core.SubModuleItem
import com.abm.erp.data.*
import com.abm.erp.theme.*

/**
 * Module 5 — Purchase Management. PurchaseRepository (data layer) already
 * existed with full Supplier/PO/GRN/Return/Payment logic and its own
 * permission-gated + audit-logged functions; this file is the missing UI.
 */
class PurchaseViewModel : ViewModel() {
    val suppliers = PurchaseRepository.suppliers
    val purchaseOrders = PurchaseRepository.purchaseOrders
    val goodsReceivedNotes = PurchaseRepository.goodsReceivedNotes
    val purchaseReturns = PurchaseRepository.purchaseReturns
    val warehouses = InventoryRepository.warehouses
    val currentUser get() = MockRepository.currentUser

    fun createSupplier(name: String, phone: String, address: String, creditLimit: Double) =
        PurchaseRepository.createSupplier(name, phone, address, creditLimit)
    fun deleteSupplier(id: String) = PurchaseRepository.deleteSupplier(id)
    fun duplicateSupplier(id: String) = PurchaseRepository.duplicateSupplier(id)
    fun restoreSupplier(id: String) = PurchaseRepository.restoreSupplier(id)
    fun duplicatePurchaseOrder(id: String) = PurchaseRepository.duplicatePurchaseOrder(id)

    fun createPurchaseOrder(supplierId: String, supplierName: String, lineItems: List<PurchaseLineItem>) =
        PurchaseRepository.createPurchaseOrder(supplierId, supplierName, lineItems)
    fun updatePurchaseOrderStatus(id: String, status: String) = PurchaseRepository.updatePurchaseOrderStatus(id, status)

    fun receiveGoods(poId: String, supplierId: String, supplierName: String, items: List<PurchaseLineItem>, warehouseId: String) =
        PurchaseRepository.receiveGoods(poId, supplierId, supplierName, items, warehouseId)

    fun createPurchaseReturn(poId: String?, supplierId: String, supplierName: String, items: List<PurchaseLineItem>, reason: String) =
        PurchaseRepository.createPurchaseReturn(poId, supplierId, supplierName, items, reason)
    fun approvePurchaseReturn(id: String) = PurchaseRepository.approvePurchaseReturn(id)
    fun rejectPurchaseReturn(id: String) = PurchaseRepository.rejectPurchaseReturn(id)

    fun createSupplierPayment(supplierId: String, amount: Double, method: String) =
        PurchaseRepository.createSupplierPayment(supplierId, amount, method)

    fun canCreate() = PermissionManager.canCurrentUser("stock", PermissionAction.CREATE)
    fun canApprove() = PermissionManager.canCurrentUser("stock", PermissionAction.APPROVE)
    fun canDelete() = PermissionManager.canCurrentUser("stock", PermissionAction.DELETE)
}

@Composable
fun PurchaseScreen(vm: PurchaseViewModel = viewModel()) {
    var tab by remember { mutableStateOf<Int?>(null) }
    val subItems = listOf(
        SubModuleItem("suppliers", "Suppliers", "🏢", 0xFF8A6DFF, 0xFF5B3FE0),
        SubModuleItem("po", "Purchase Orders", "📝", 0xFF4E9CFF, 0xFF2E6FE0),
        SubModuleItem("grn", "GRN (Receive Goods)", "📥", 0xFF3DDC97, 0xFF1FA972),
        SubModuleItem("return", "Purchase Return", "↩️", 0xFFE85D4A, 0xFFC03A2B),
        SubModuleItem("payment", "Supplier Payment", "💳", 0xFFFFB020, 0xFFE08A00),
    )
    Column(Modifier.fillMaxSize()) {
        ModuleGradientHeader("Purchase Management", "🛍️", 0xFF8A6DFF, 0xFF5B3FE0)
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            if (tab == null) {
                SubModuleGrid(subItems) { key -> tab = when (key) { "suppliers" -> 0; "po" -> 1; "grn" -> 2; "return" -> 3; else -> 4 } }
            } else {
                BackToSubMenuLink(onClick = { tab = null })
                when (tab) {
                    0 -> SuppliersTab(vm)
                    1 -> PurchaseOrdersTab(vm)
                    2 -> GrnTab(vm)
                    3 -> PurchaseReturnTab(vm)
                    else -> SupplierPaymentTab(vm)
                }
            }
        }
    }
}

@Composable
private fun SuppliersTab(vm: PurchaseViewModel) {
    val suppliers by vm.suppliers.collectAsState()
    var showAdd by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "Name,Due,CreditLimit\n"
                    val rows = suppliers.joinToString("\n") { s -> com.abm.erp.core.toCsvRow(s.name, s.dueBalance, s.creditLimit) }
                    val file = java.io.File(context.getExternalFilesDir(null), "suppliers_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Suppliers (${suppliers.size})\n" + suppliers.take(20).joinToString("\n") { "${it.name} — Due ৳${it.dueBalance}" }
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                    try { context.startActivity(android.content.Intent.createChooser(intent, "Suppliers")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                },
            )
        }
        if (vm.canCreate()) {
            Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add Supplier") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(suppliers, key = { it.id }) { s ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(s.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("We owe: ৳${"%,.0f".format(s.dueBalance)}" + if (s.creditLimit > 0) " / limit ৳${"%,.0f".format(s.creditLimit)}" else "", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Row {
                            if (vm.canDelete()) {
                                TextButton(onClick = { vm.deleteSupplier(s.id) }) { Text("Delete", color = DangerRed) }
                            }
                            com.abm.erp.core.UniversalActionMenu(
                                moduleReference = "Supplier", entityId = s.id, entityLabel = s.name,
                                shareText = "Supplier: ${s.name}\nDue: ৳${s.dueBalance}",
                                isDeleted = s.isDeleted,
                                onDuplicate = { vm.duplicateSupplier(s.id) },
                                onArchive = { vm.deleteSupplier(s.id) },
                                canArchive = vm.canDelete(),
                                archiveBlockedReasonOverride = if (s.dueBalance > 0) "এই সাপ্লায়ারের কাছে আমাদের বকেয়া ৳${"%,.0f".format(s.dueBalance)} আছে — বকেয়া মেটানো না হওয়া পর্যন্ত archive করা যাবে না।" else null,
                                onRestore = { vm.restoreSupplier(s.id) },
                                csvHeader = "Name,Due,CreditLimit",
                                csvRow = com.abm.erp.core.toCsvRow(s.name, s.dueBalance, s.creditLimit),
                            )
                        }
                    }
                }
            }
            if (suppliers.isEmpty()) item { Text("এখনো কোনো সাপ্লায়ার নেই।", color = TextSecondary) }
        }
    }

    if (showAdd) {
        Dialog(onDismissRequest = { showAdd = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var name by remember { mutableStateOf("") }
                var phone by remember { mutableStateOf("") }
                var address by remember { mutableStateOf("") }
                var creditLimitText by remember { mutableStateOf("") }
                var error by remember { mutableStateOf<String?>(null) }
                Column(Modifier.padding(16.dp)) {
                    Text("Supplier Registration", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Supplier name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = creditLimitText, onValueChange = { creditLimitText = it }, label = { Text("Credit limit they extend to us (৳, optional)") }, modifier = Modifier.fillMaxWidth())
                    error?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 6.dp)) }
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = {
                            val created = vm.createSupplier(name, phone, address, creditLimitText.toDoubleOrNull() ?: 0.0)
                            if (created == null) error = "তৈরি করা যায়নি — একই নাম+ফোনে সাপ্লায়ার আগে থেকেই আছে।" else showAdd = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Register Supplier") }
                }
            }
        }
    }
}

@Composable
private fun PoLineItemBuilder(items: MutableList<PurchaseLineItem>) {
    var name by remember { mutableStateOf("") }
    var qtyText by remember { mutableStateOf("") }
    var costText by remember { mutableStateOf("") }

    Column {
        items.forEachIndexed { idx, item ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${item.name} × ${item.qty} @ ৳${item.unitCost}", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { items.removeAt(idx) }) { Text("✕", color = DangerRed) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Item") }, modifier = Modifier.weight(2f))
            OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Qty") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = costText, onValueChange = { costText = it }, label = { Text("৳ cost") }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Button(
            onClick = {
                val qty = qtyText.toDoubleOrNull() ?: return@Button
                val cost = costText.toDoubleOrNull() ?: return@Button
                if (name.isBlank()) return@Button
                items.add(PurchaseLineItem(productId = "", name = name, unit = "pcs", qty = qty, unitCost = cost))
                name = ""; qtyText = ""; costText = ""
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("+ Add item") }
    }
}

@Composable
private fun PurchaseOrdersTab(vm: PurchaseViewModel) {
    val orders by vm.purchaseOrders.collectAsState()
    val suppliers by vm.suppliers.collectAsState()
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        if (vm.canCreate()) {
            Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Purchase Order") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(orders) { po ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${po.poNo} — ${po.supplierName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("৳${"%,.0f".format(po.subTotal)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Row {
                            Text(po.status, color = when (po.status) { "RECEIVED" -> SuccessGreen; "CANCELLED" -> DangerRed; else -> WarningAmber }, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            val context = androidx.compose.ui.platform.LocalContext.current
                            TextButton(onClick = {
                                try {
                                    val file = com.abm.erp.core.exportPurchaseOrderPdf(context, po)
                                    com.abm.erp.core.shareStructuredPdf(context, file, "PO ${po.poNo}")
                                } catch (e: Exception) {
                                    android.widget.Toast.makeText(context, "PO PDF তৈরি ব্যর্থ হয়েছে: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                                }
                            }) { Text("📄", style = MaterialTheme.typography.labelSmall) }
                            com.abm.erp.core.UniversalActionMenu(
                                moduleReference = "PurchaseOrder", entityId = po.id, entityLabel = po.poNo,
                                shareText = "PO ${po.poNo} — ${po.supplierName}\nTotal: ৳${po.subTotal}\nStatus: ${po.status}",
                                onDuplicate = { vm.duplicatePurchaseOrder(po.id) },
                                csvHeader = "PONo,Supplier,SubTotal,Status",
                                csvRow = com.abm.erp.core.toCsvRow(po.poNo, po.supplierName, po.subTotal, po.status),
                            )
                        }
                    }
                    if (po.status == "DRAFT") {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.updatePurchaseOrderStatus(po.id, "SENT") }) { Text("Send to Supplier") }
                            OutlinedButton(onClick = { vm.updatePurchaseOrderStatus(po.id, "CANCELLED") }) { Text("Cancel", color = DangerRed) }
                        }
                    }
                }
            }
            if (orders.isEmpty()) item { Text("এখনো কোনো Purchase Order নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var selectedSupplier by remember { mutableStateOf<Supplier?>(null) }
                var expanded by remember { mutableStateOf(false) }
                val lineItems = remember { mutableStateListOf<PurchaseLineItem>() }
                Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
                    Text("New Purchase Order", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedSupplier?.name ?: "Select supplier") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            suppliers.forEach { s -> DropdownMenuItem(text = { Text(s.name) }, onClick = { selectedSupplier = s; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    PoLineItemBuilder(lineItems)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val s = selectedSupplier ?: return@Button
                            if (lineItems.isEmpty()) return@Button
                            vm.createPurchaseOrder(s.id, s.name, lineItems.toList())
                            showNew = false
                        },
                        enabled = selectedSupplier != null && lineItems.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Create Purchase Order") }
                }
            }
        }
    }
}

@Composable
private fun GrnTab(vm: PurchaseViewModel) {
    val grns by vm.goodsReceivedNotes.collectAsState()
    val orders by vm.purchaseOrders.collectAsState()
    val warehouses by vm.warehouses.collectAsState()
    val sentOrders = orders.filter { it.status in setOf("SENT", "PARTIALLY_RECEIVED") }
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        if (vm.canCreate()) {
            Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth(), enabled = sentOrders.isNotEmpty()) { Text("+ Receive Goods (GRN)") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(grns) { g ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${g.grnNo} — ${g.supplierName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("৳${"%,.0f".format(g.totalValue)} · received by ${g.receivedBy}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "GRN", entityId = g.id, entityLabel = g.grnNo,
                            shareText = "GRN ${g.grnNo} — ${g.supplierName}\nValue: ৳${g.totalValue}",
                            csvHeader = "GRNNo,Supplier,TotalValue,ReceivedBy", csvRow = com.abm.erp.core.toCsvRow(g.grnNo, g.supplierName, g.totalValue, g.receivedBy),
                        )
                    }
                }
            }
            if (grns.isEmpty()) item { Text("এখনো কোনো GRN নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var selectedPo by remember { mutableStateOf<PurchaseOrder?>(null) }
                var poExpanded by remember { mutableStateOf(false) }
                var selectedWarehouse by remember { mutableStateOf<String?>(null) }
                var whExpanded by remember { mutableStateOf(false) }
                Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
                    Text("Goods Received Note", style = MaterialTheme.typography.titleMedium)
                    Text("PO-তে থাকা সব item পুরোপুরি গ্রহণ করা হচ্ছে ধরে নেওয়া হবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(Modifier.height(10.dp))
                    Box {
                        OutlinedButton(onClick = { poExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedPo?.poNo ?: "Select Purchase Order") }
                        DropdownMenu(expanded = poExpanded, onDismissRequest = { poExpanded = false }) {
                            sentOrders.forEach { po -> DropdownMenuItem(text = { Text("${po.poNo} — ${po.supplierName}") }, onClick = { selectedPo = po; poExpanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Box {
                        OutlinedButton(onClick = { whExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(warehouses.firstOrNull { it.id == selectedWarehouse }?.name ?: "Select warehouse")
                        }
                        DropdownMenu(expanded = whExpanded, onDismissRequest = { whExpanded = false }) {
                            warehouses.forEach { w -> DropdownMenuItem(text = { Text(w.name) }, onClick = { selectedWarehouse = w.id; whExpanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val po = selectedPo ?: return@Button
                            val wh = selectedWarehouse ?: return@Button
                            vm.receiveGoods(po.id, po.supplierId, po.supplierName, po.lineItems, wh)
                            showNew = false
                        },
                        enabled = selectedPo != null && selectedWarehouse != null,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm Receipt — Stock In") }
                }
            }
        }
    }
}

@Composable
private fun PurchaseReturnTab(vm: PurchaseViewModel) {
    val returns by vm.purchaseReturns.collectAsState()
    val suppliers by vm.suppliers.collectAsState()
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Purchase Return") }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(returns) { r ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${r.returnNo} — ${r.supplierName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("৳${"%,.0f".format(r.refundAmount)} · ${r.reason}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text(r.status, color = when (r.status) { "APPROVED" -> SuccessGreen; "REJECTED" -> DangerRed; else -> WarningAmber }, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                    }
                    if (r.status == "PENDING" && vm.canApprove()) {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.approvePurchaseReturn(r.id) }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) { Text("Approve") }
                            OutlinedButton(onClick = { vm.rejectPurchaseReturn(r.id) }) { Text("Reject", color = DangerRed) }
                        }
                    }
                }
            }
            if (returns.isEmpty()) item { Text("এখনো কোনো Purchase Return নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var selectedSupplier by remember { mutableStateOf<Supplier?>(null) }
                var expanded by remember { mutableStateOf(false) }
                var reason by remember { mutableStateOf("") }
                val lineItems = remember { mutableStateListOf<PurchaseLineItem>() }
                Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
                    Text("New Purchase Return", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedSupplier?.name ?: "Select supplier") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            suppliers.forEach { s -> DropdownMenuItem(text = { Text(s.name) }, onClick = { selectedSupplier = s; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    PoLineItemBuilder(lineItems)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val s = selectedSupplier ?: return@Button
                            vm.createPurchaseReturn(null, s.id, s.name, lineItems.toList(), reason)
                            showNew = false
                        },
                        enabled = selectedSupplier != null && lineItems.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Submit Return") }
                }
            }
        }
    }
}

@Composable
private fun SupplierPaymentTab(vm: PurchaseViewModel) {
    val suppliers by vm.suppliers.collectAsState()
    var selectedSupplier by remember { mutableStateOf<Supplier?>(null) }
    var expanded by remember { mutableStateOf(false) }
    var amountText by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("BANK") }
    var message by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        Text("Pay a Supplier", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedSupplier?.name ?: "Select supplier") }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                suppliers.forEach { s -> DropdownMenuItem(text = { Text("${s.name} (due ৳${"%,.0f".format(s.dueBalance)})") }, onClick = { selectedSupplier = s; expanded = false }) }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("Amount (৳)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("CASH", "BANK", "MOBILE_BANKING", "CHEQUE").forEach { m -> FilterChip(selected = method == m, onClick = { method = m }, label = { Text(m) }) }
        }
        Spacer(Modifier.height(12.dp))
        message?.let { Text(it, color = SuccessGreen, modifier = Modifier.padding(bottom = 8.dp)) }
        Button(
            onClick = {
                val s = selectedSupplier ?: return@Button
                val amt = amountText.toDoubleOrNull() ?: return@Button
                vm.createSupplierPayment(s.id, amt, method)
                message = "✓ ৳${"%,.0f".format(amt)} ${s.name}-কে পরিশোধ রেকর্ড হয়েছে"
                amountText = ""
            },
            enabled = selectedSupplier != null && amountText.toDoubleOrNull() != null,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Record Payment") }
    }
}
