package com.abm.erp.data

import android.content.Context

/**
 * Device-local (SharedPreferences) session state — everything here lives
 * only on THIS phone, never synced. Was previously private inside
 * LoginScreen.kt; moved here so ABMApplication.onCreate() can also read the
 * saved company code at cold start (needed to point FirebaseSync at the
 * right tenant before any screen has even opened).
 */
private const val SESSION_PREFS = "abm_session"
private const val KEY_LAST_EMPLOYEE_ID = "last_employee_id"
private const val KEY_DEVICE_ID = "device_id"
private const val KEY_COMPANY_CODE = "company_code"
private const val KEY_LANGUAGE = "language"

fun saveLastLoggedInEmployee(context: Context, employeeId: String) {
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE)
        .edit().putString(KEY_LAST_EMPLOYEE_ID, employeeId).apply()
}

fun getLastLoggedInEmployee(context: Context): String? =
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).getString(KEY_LAST_EMPLOYEE_ID, null)

/** Foundation Layer — Session Management: called on ordinary logout so the next app open requires a full PIN/biometric login again instead of auto-resuming this employee's session. */
fun clearLastLoggedInEmployee(context: Context) {
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).edit().remove(KEY_LAST_EMPLOYEE_ID).apply()
}

/** This phone's own stable identity — created once, kept until app uninstall. Used by Trusted Devices/Login Activity Log. */
fun getOrCreateDeviceId(context: Context): String {
    val prefs = context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE)
    val existing = prefs.getString(KEY_DEVICE_ID, null)
    if (existing != null) return existing
    val fresh = "DEV-" + (100000..999999).random()
    prefs.edit().putString(KEY_DEVICE_ID, fresh).apply()
    return fresh
}

/** Multi-tenant: which company's data this device is scoped to — entered once at the Company Code screen, remembered after. */
fun getSavedCompanyCode(context: Context): String? =
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).getString(KEY_COMPANY_CODE, null)

fun saveCompanyCode(context: Context, code: String) {
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).edit().putString(KEY_COMPANY_CODE, code).apply()
}

fun getSavedLanguage(context: Context): String =
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).getString(KEY_LANGUAGE, "bn") ?: "bn"

fun saveLanguage(context: Context, lang: String) {
    context.getSharedPreferences(SESSION_PREFS, Context.MODE_PRIVATE).edit().putString(KEY_LANGUAGE, lang).apply()
}
