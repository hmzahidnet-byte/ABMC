package com.abm.erp.ui.advisory

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.MockRepository
import com.abm.erp.data.RiskBand
import com.abm.erp.theme.*
import java.util.Locale

private enum class AiMode { ASSISTANT, ANALYSIS }

/** Thin MVVM wrapper — delegates straight to the MockRepository/FirebaseSync singletons (repository pattern already owns the real logic); this just gives the screen a lifecycle-scoped access point instead of calling the singletons directly. */
class BoardroomViewModel : ViewModel() {
    val history = MockRepository.boardroomHistory
    val usageCount = FirebaseSync.aiUsageThisMonth
    fun prescriptions() = MockRepository.computePrescriptions()
    val aiMonthlyCap = FirebaseSync.AI_MONTHLY_CAP
    fun tryConsumeAiUsage() = FirebaseSync.tryConsumeAiUsage()
    fun askAssistant(q: String) = MockRepository.askAssistant(q)
    fun askAnalysis(q: String) = MockRepository.askAnalysis(q)

    // ---- Module 16: AI & Automation — Sales Forecast ----
    val dealers = MockRepository.dealers
    fun forecastForDealer(dealer: com.abm.erp.data.Dealer) = MockRepository.computeSalesForecast(dealer)
    fun forecastForZone(zone: String) = MockRepository.computeZoneForecast(zone)

    // ---- Module 16: Business Health Score / Risk Detection / Demand-Collection-Production Forecast ----
    fun businessHealthScore() = MockRepository.computeBusinessHealthScore()
    fun riskAlerts() = MockRepository.computeRiskAlerts()
    fun demandForecast() = MockRepository.computeDemandForecast()
    fun collectionForecast30d() = MockRepository.computeCollectionForecast()
    fun productionForecast30d() = MockRepository.computeProductionForecast()
    fun inventoryForecast() = MockRepository.computeInventoryForecast()
    fun smartRecommendations() = MockRepository.smartBusinessRecommendations()
}

@Composable
fun BoardroomScreen(vm: BoardroomViewModel = viewModel()) {
    val history by vm.history.collectAsState()
    val usageCount by vm.usageCount.collectAsState()
    val dealers by vm.dealers.collectAsState()
    var question by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(AiMode.ASSISTANT) }
    var micError by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (text != null) question = text
        }
    }
    val micPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            micError = null
            launchSpeechRecognizer(context, speechLauncher) { micError = it }
        } else {
            micError = "Microphone permission was denied — type your question instead."
        }
    }

    fun submit() {
        if (question.isBlank()) return
        if (!vm.tryConsumeAiUsage()) {
            question = ""
            return // cap hit — the banner below already explains this
        }
        if (mode == AiMode.ASSISTANT) vm.askAssistant(question) else vm.askAnalysis(question)
        question = ""
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("AI Assistant", style = MaterialTheme.typography.headlineSmall)
            Text("Two ways to use it — get things done, or just understand what's happening.", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { mode = AiMode.ASSISTANT },
                    colors = ButtonDefaults.buttonColors(containerColor = if (mode == AiMode.ASSISTANT) Sky else Color(0xFFF0F2F6), contentColor = if (mode == AiMode.ASSISTANT) Color.White else TextSecondary),
                    modifier = Modifier.weight(1f),
                ) { Text("🎙️ Assistant") }
                Button(
                    onClick = { mode = AiMode.ANALYSIS },
                    colors = ButtonDefaults.buttonColors(containerColor = if (mode == AiMode.ANALYSIS) Sky else Color(0xFFF0F2F6), contentColor = if (mode == AiMode.ANALYSIS) Color.White else TextSecondary),
                    modifier = Modifier.weight(1f),
                ) { Text("📊 Analysis") }
            }
        }

        item {
            Text(
                "This month's usage: $usageCount/${vm.aiMonthlyCap}",
                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                modifier = Modifier.fillMaxWidth(),
            )
            if (usageCount >= vm.aiMonthlyCap) {
                Text("⚠ Monthly AI limit reached for this company — resets next month.", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
            }
        }

        item {
            GlassCard(
                borderColor = if (mode == AiMode.ASSISTANT) Color(0xFFB45CFF).copy(alpha = 0.4f) else ElectricCyan.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    if (mode == AiMode.ASSISTANT)
                        "🎙️ Speak or type an instruction (log an order, update vacancy, post a notice) — recognized actions show here; completing them needs Firebase Blaze."
                    else
                        "📊 Ask about margin, stock, dues, or the ledger — read-only, nothing changes.",
                    style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                )
            }
        }

        items(history.filter { it.mode == mode.name.lowercase() }.reversed()) { qa ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(qa.question, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(6.dp))
                Text(qa.answer, style = MaterialTheme.typography.bodyMedium)
            }
        }

        item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = {
                        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                        if (granted) launchSpeechRecognizer(context, speechLauncher) { micError = it }
                        else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }) {
                        Icon(Icons.Filled.Mic, contentDescription = "Voice input", tint = if (mode == AiMode.ASSISTANT) Color(0xFFB45CFF) else ElectricCyan)
                    }
                    OutlinedTextField(
                        value = question,
                        onValueChange = { question = it },
                        placeholder = { Text(if (mode == AiMode.ASSISTANT) "যা করাতে চান বলুন বা লিখুন…" else "Ask about margin, stock, dues…") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyan, unfocusedBorderColor = GlassBorder),
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(onClick = { submit() }) {
                        Icon(Icons.Filled.Send, contentDescription = "Ask", tint = ElectricCyan)
                    }
                }
                micError?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = DangerRed, modifier = Modifier.padding(start = 48.dp)) }
            }
        }

        if (mode == AiMode.ANALYSIS) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Daily prescription feed", style = MaterialTheme.typography.titleMedium)
                    val context = androidx.compose.ui.platform.LocalContext.current
                    val prescriptionsForExport = vm.prescriptions()
                    com.abm.erp.core.ModuleActionBar(
                        onExport = {
                            val header = "Title,Body,Severity\n"
                            val rows = prescriptionsForExport.joinToString("\n") { p -> com.abm.erp.core.toCsvRow(p.title, p.body, p.severity) }
                            val file = java.io.File(context.getExternalFilesDir(null), "prescriptions_${System.currentTimeMillis()}.csv")
                            file.writeText(header + rows)
                            android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                        },
                        onShare = {
                            val summary = "Boardroom Prescriptions\n" + prescriptionsForExport.take(20).joinToString("\n") { "${it.title}: ${it.body}" }
                            val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, summary) }
                            try { context.startActivity(Intent.createChooser(intent, "Prescriptions")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                        },
                    )
                }
            }
            val prescriptionList = vm.prescriptions()
            if (prescriptionList.isEmpty()) {
                item { Text("এই মুহূর্তে কোনো risk signal নেই — সব ঠিক আছে।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
            }
            items(prescriptionList) { p ->
                val color = when (p.severity) { RiskBand.RED -> DangerRed; RiskBand.YELLOW -> WarningAmber; RiskBand.GREEN -> SuccessGreen }
                GlassCard(borderColor = color.copy(alpha = 0.6f), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(p.title, fontWeight = FontWeight.Bold, color = color, modifier = Modifier.weight(1f))
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Prescription", entityId = p.id, entityLabel = p.title,
                            shareText = "${p.title}\n${p.body}\nSeverity: ${p.severity}",
                            csvHeader = "Title,Body,Severity", csvRow = com.abm.erp.core.toCsvRow(p.title, p.body, p.severity),
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(p.body, style = MaterialTheme.typography.bodyMedium)
                }
            }
            item {
                val health = vm.businessHealthScore()
                Text("Business Health Score", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("${health.score}/100", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = when { health.score >= 65 -> SuccessGreen; health.score >= 45 -> WarningAmber; else -> DangerRed })
                        Text(health.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Sales ${health.salesTrendComponent}/25 · Collection ${health.collectionComponent}/25 · Stock ${health.stockHealthComponent}/25 · Risk ${health.riskComponent}/25", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
            item {
                Spacer(Modifier.height(10.dp))
                Text("Smart Recommendations", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                vm.smartRecommendations().forEach { rec ->
                    GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
                        Text(rec, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Spacer(Modifier.height(6.dp))
                val invForecast = vm.inventoryForecast()
                if (invForecast.isNotEmpty()) {
                    Text("Inventory Forecast — days until stockout", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    invForecast.take(5).forEach { (name, days) ->
                        GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                Text(if (days >= 999) "N/A" else "$days days left", color = if (days < 7) DangerRed else WarningAmber, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            item {
                Spacer(Modifier.height(10.dp))
                Text("Risk Alerts", style = MaterialTheme.typography.titleMedium)
            }
            items(vm.riskAlerts()) { r ->
                GlassCard(borderColor = (if (r.severity == RiskBand.RED) DangerRed else WarningAmber).copy(alpha = 0.6f), modifier = Modifier.fillMaxWidth()) {
                    Text(r.category, fontWeight = FontWeight.Bold, color = if (r.severity == RiskBand.RED) DangerRed else WarningAmber, style = MaterialTheme.typography.labelMedium)
                    Text(r.message, style = MaterialTheme.typography.bodySmall)
                }
            }
            item {
                Spacer(Modifier.height(10.dp))
                val collectionF = vm.collectionForecast30d()
                val productionF = vm.productionForecast30d()
                Text("Collection & Production Forecast (30d)", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Projected Collection", style = MaterialTheme.typography.bodySmall)
                        Text("৳${"%,.0f".format(collectionF)}", color = SuccessGreen, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(4.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Projected Production Output", style = MaterialTheme.typography.bodySmall)
                        Text("${"%,.0f".format(productionF)} units", color = ElectricCyan, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Spacer(Modifier.height(10.dp))
                Text("Demand Forecast — top 5 products", style = MaterialTheme.typography.titleMedium)
            }
            items(vm.demandForecast().take(5)) { row ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(row.productName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("${"%,.1f".format(row.projectedNext30Days)} units/30d", color = ElectricCyan, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Spacer(Modifier.height(6.dp))
                Text("Sales Forecast — top 5 dealers by 90-day sales", style = MaterialTheme.typography.titleMedium)
                Text("দৈনিক গড় বিক্রয় থেকে সরল projection — বাস্তব দৈনিক time-series নেই বলে এটা full ML forecast না, কিন্তু আসল ডেটা থেকে হিসাব করা।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            items(dealers.sortedByDescending { it.salesLast90Days }.take(5)) { d ->
                val forecast = vm.forecastForDealer(d)
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(forecast.scopeName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("Daily avg: ৳${"%,.0f".format(forecast.dailyAverage)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("৳${"%,.0f".format(forecast.projectedNext30Days)} / 30d", color = ElectricCyan, fontWeight = FontWeight.Bold)
                            Text(forecast.trend, style = MaterialTheme.typography.labelSmall, color = when (forecast.trend) { "GROWING" -> SuccessGreen; "DECLINING" -> DangerRed; else -> WarningAmber })
                        }
                    }
                }
            }
        }
    }
}

/** Launches Android's own on-device speech recognizer UI — no server round-trip, works fully offline-capable on most devices, free. */
private fun launchSpeechRecognizer(
    context: android.content.Context,
    launcher: androidx.activity.result.ActivityResultLauncher<Intent>,
    onError: (String) -> Unit,
) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale("bn", "BD").toString())
        putExtra(RecognizerIntent.EXTRA_PROMPT, "বলুন…")
    }
    try {
        launcher.launch(intent)
    } catch (e: android.content.ActivityNotFoundException) {
        onError("এই ডিভাইসে speech recognition সমর্থিত না — টাইপ করুন।")
    }
}
