package com.abm.erp.data

import java.time.LocalDate
import java.time.LocalDateTime
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

// ---------- Multi-tenant / roles ----------
// Real chain of command: SR -> TSM -> ASM -> RSM -> DSM -> NSM -> AGM -> GM -> MD -> CHAIRMAN.
// Each designation's module access is enforced in MockRepository.allowedModules(); zone/geo
// scoping (which district/division a person's data is limited to) lives on AppUser.zone.
enum class UserRole { SR, TSM, ASM, RSM, DSM, NSM, AGM, GM, MD, CHAIRMAN }

/** Cross-device sync's own visible status — shown as a small badge so the person always knows whether their last action has actually left the phone. */
enum class SyncStatus { PENDING, SYNCED, FAILED }

data class Company(
    val id: String,
    val name: String, // e.g. "ABM Corporation"
    val address: String = "",
    val logoUrl: String? = null,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class AppUser(
    val id: String,
    val name: String,
    val role: UserRole,
    val companyId: String,
    val zone: String, // geo scope label, e.g. "Rangpur district" or "All Bangladesh · Board" for Chairman
    val employeeId: String, // links to the richer Employee record in OrgDirectory.kt
    val territoryId: String? = null, // links to Territory.id (see below) — zone stays as the human-readable label
    val phone: String = "",
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ---------- Territory ----------
// Formalizes the division/district/market "zone" strings scattered across
// Employee/Dealer/Retailer/RetailOrder into one real, referenceable entity.
data class Territory(
    val id: String,
    val division: String,
    val district: String? = null,
    val market: String? = null,
    val parentTerritoryId: String? = null, // market -> district -> division chain
    val zoneName: String? = null, // DSM-tier multi-division zone label, e.g. "Northern Zone"
    val country: String = "Bangladesh", // Route & Territory Management's full hierarchy: Country > Division > District > Upazila > Territory > Area > Route > Beat
    val upazila: String? = null,
    val area: String? = null,
    val beat: String? = null, // finest-grained level — matches SalesRoute's "beat plan" concept, formalized here as a territory-hierarchy leaf
)

// ---------- Role & Permissions ----------
// Replaces the hardcoded-only ROLE_MODULES map (ModuleAccess.kt) with a real,
// per-module capability structure — ROLE_MODULES stays as the simple "can
// even see this tile" check, this is the finer-grained CRUD/approve layer
// used by the Foundation Layer's Role-Based Permission step.
data class ModulePermission(
    val moduleKey: String,
    val canView: Boolean = true,
    val canCreate: Boolean = false,
    val canEdit: Boolean = false,
    val canApprove: Boolean = false,
    val canDelete: Boolean = false,
    val canExport: Boolean = false,
)

data class RoleDefinition(
    val roleKey: String, // UserRole.name for built-in roles, or any custom role string
    val label: String,
    val modulePermissions: List<ModulePermission> = emptyList(),
)

// ---------- Sales chain ----------

enum class OrderStage { SO_LOGGED, ASM_VERIFIED, DEALER_ROUTED, FULFILLED, REJECTED }

data class RetailOrder(
    val id: String,
    val orderNo: String, // human-readable sequential number for display — the id itself is a random UUID (avoids Firestore hotspotting at scale)
    val retailerName: String,
    val loggedBySoId: String,
    val zone: String,
    val items: String,          // e.g. "ABM Masala Tea x40 ctn"
    val amount: Double,
    var stage: OrderStage = OrderStage.SO_LOGGED,
    var routedDealerId: String? = null,
    val loggedAt: LocalDateTime = LocalDateTime.now(),
    // Ground-level SR data collection: shop photo, live GPS tag, and a
    // printable QR code unique to this retailer — scan it later to pull the
    // shop's record back up instantly.
    val retailerPhotoUri: String? = null,
    val retailerLat: Double? = null,
    val retailerLng: Double? = null,
    val channel: String = "retail", // "retail" | "wholesale" — sales-type chain of command, separate from designation chain
    val anonymous: Boolean = false, // shopkeeper declined to give name/photo — item+amount only, so the sale isn't lost
    val photoPurpose: String? = null, // "Shop photo" | "Product damaged" | "Other issue"
    val retailerQrCode: String? = null,
    val retailerId: String? = null, // links to the real Retailer entity (Data Design step) — retailerName stays for display/backward-compat
)

data class Dealer(
    val id: String,
    val name: String,
    val zone: String,
    var dueBalance: Double,
    var salesLast90Days: Double,
    val pin: String = "0000",
    var stockUnits: Int = 0, // দোকানে এখন কতগুলো কার্টন/ইউনিট আছে — SR-এর retail order এই স্টকের বিপরীতেই verify হয়, company-এর central stock-এর বিপরীতে না
    val phone: String = "",
    val address: String = "",
    val territoryId: String? = null,
    val dedupKey: String = "", // normalized name+phone key — Foundation Layer's Data Integrity step checks this before insert
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val deletedAt: LocalDateTime? = null,
    val deletedBy: String? = null,
    val classification: String = "B", // "A" | "B" | "C" — Dealer Classification (DMS)
    val creditLimit: Double = 0.0, // 0 = no explicit limit set yet — Credit Limit enforcement checks this before invoicing
)

// ---------- Retailer ----------
// Previously only a free-text name inside RetailOrder — now its own
// referenceable entity so duplicate-prevention, soft-delete, and audit can
// actually apply to it (was the single biggest Data Design gap).
data class Retailer(
    val id: String,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val territoryId: String? = null,
    val dealerId: String? = null,
    val lat: Double? = null,
    val lng: Double? = null,
    val photoUri: String? = null,
    val qrCode: String? = null,
    val dedupKey: String = "", // normalized name+lat/lng (or name+phone) key
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val deletedAt: LocalDateTime? = null,
    val deletedBy: String? = null,
    var dueBalance: Double = 0.0, // Retailer Due
    val creditLimit: Double = 0.0, // Retailer Credit Limit — 0 = not set
    val outletCategory: String = "General Store", // Outlet Category
    val outletType: String = "Retail", // Outlet Type — "Retail" | "Wholesale" | "Pharmacy" | "Super Shop" ...
    val routeId: String? = null, // Outlet Route Assignment — links to a beat/route
)

// ---------- Module 4/7/8 shared: which party a record is about ----------
enum class PartyType { DEALER, RETAILER, SUPPLIER }

// ---------- Sales Management (Module 4): Quotation ----------
data class Quotation(
    val id: String,
    val quotationNo: String,
    val partyType: PartyType,
    val partyId: String,
    val partyName: String,
    val lineItems: List<SalesInvoiceLineItem>,
    val validUntil: LocalDateTime,
    val status: String = "DRAFT", // DRAFT | SENT | CONVERTED | EXPIRED | CANCELLED
    val convertedInvoiceId: String? = null,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
) {
    val subTotal: Double get() = lineItems.sumOf { it.lineTotal }
}

// ---------- Sales Management (Module 4): Delivery Challan ----------
data class DeliveryChallan(
    val id: String,
    val challanNo: String,
    val invoiceId: String? = null,
    val partyType: PartyType,
    val partyId: String,
    val partyName: String,
    val lineItems: List<SalesInvoiceLineItem>,
    val vehicleNo: String = "",
    val driverName: String = "",
    val deliveredBy: String = "",
    val status: String = "PENDING", // PENDING | DISPATCHED | DELIVERED
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
)

// ---------- Sales Management (Module 4): Sales Return ----------
data class SalesReturn(
    val id: String,
    val returnNo: String,
    val invoiceId: String? = null,
    val partyType: PartyType,
    val partyId: String,
    val partyName: String,
    val lineItems: List<SalesInvoiceLineItem>,
    val reason: String = "",
    val refundAmount: Double = 0.0,
    val status: String = "PENDING", // PENDING | APPROVED | REJECTED
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
)

// ---------- Dealer/Retailer Ledger (Module 7/8) ----------
// Distinct from the company-wide LedgerEntry (Accounts module) — this is
// per-party running balance: every invoice/collection/return posts one row
// here, so "Dealer Ledger"/"Retailer Ledger" is a real statement, not just
// today's dueBalance snapshot.
data class PartyLedgerEntry(
    val id: String,
    val partyType: PartyType,
    val partyId: String,
    val type: String, // "DEBIT" (due increases — invoice) | "CREDIT" (due decreases — collection/return)
    val amount: Double,
    val reason: String,
    val referenceId: String = "", // the invoice/collection/return id this posting came from
    val balanceAfter: Double = 0.0,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ---------- Dealer/Retailer Collection (Module 7/8/10) ----------
data class PartyCollection(
    val id: String,
    val partyType: PartyType,
    val partyId: String,
    val partyName: String,
    val amount: Double,
    val method: String = "CASH", // CASH | BANK | MOBILE_BANKING | CHEQUE
    val proofUri: String? = null,
    val status: String = "PENDING", // PENDING | VERIFIED | REJECTED
    val collectedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val verifiedBy: String? = null,
    val verifiedAt: LocalDateTime? = null,
)

// ---------- Sales Management (Module 4): Discount Rules ----------
data class DiscountRule(
    val id: String,
    val label: String,
    val scope: String = "ALL", // "ALL" | a specific dealerId/retailerId — simple targeting
    val minQty: Double = 0.0,
    val discountPct: Double = 0.0,
    val isActive: Boolean = true,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ---------- Route & Territory (SFA / Module 8's Outlet Route Assignment) ----------
data class SalesRoute(
    val id: String,
    val name: String,
    val territoryId: String? = null,
    val assignedToEmployeeId: String = "",
    val outletIds: List<String> = emptyList(), // Retailer ids on this beat, visit order matters
    val isActive: Boolean = true,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ---------- Outlet/Dealer Visit History (Module 7/8/9) ----------
data class VisitLog(
    val id: String,
    val partyType: PartyType,
    val partyId: String,
    val employeeId: String,
    val employeeName: String,
    val lat: Double,
    val lng: Double,
    val photoUri: String? = null,
    val purpose: String = "", // "Routine visit" | "Collection" | "Order" | "Display check"
    val checkInAt: LocalDateTime = LocalDateTime.now(),
    val checkOutAt: LocalDateTime? = null,
)

// ================= Universal Attachment System (Global Rule) =================
// One shared attachment table for the whole app — any module/entity attaches
// a photo/PDF/document/audio/video through this SAME structure instead of
// each module inventing its own upload field, matching how Audit Log/Party
// Ledger already unify similar cross-cutting concerns.
enum class AttachmentType { PHOTO, PDF, DOCUMENT, AUDIO, VIDEO }

data class Attachment(
    val id: String,
    val moduleReference: String, // e.g. "Retailer", "Dealer", "Task", "SalesInvoice", "Complaint"
    val entityId: String,
    val type: AttachmentType,
    val uri: String,
    val lat: Double? = null,
    val lng: Double? = null,
    val uploadedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ================= Universal Action Menu support (Global Rule) =================
// Every "Duplicate" action clones a record via this generic result rather
// than each module writing its own bespoke clone function.
data class DuplicateResult(val newId: String, val label: String)

// ---------- Dealer Invoicing (Sales Chain) ----------
// Sales-type chain of command (separate from designation chain): invoicing
// starts at Dealer/Depot level, never at Retailer/Wholesale. SR cannot
// create these (see MockRepository.canInvoice) — TSM and above can. Named
// distinctly from the existing VoiceInvoice/InvoiceLineItem (Billing
// module's separate "Voice Billing" feature) to avoid a naming collision.
data class SalesInvoiceLineItem(val productId: String, val name: String, val unit: String, val qty: Int, val unitPrice: Double, val discountPct: Double = 0.0) {
    val lineTotal: Double get() = qty * unitPrice * (1 - discountPct / 100)
}

data class SalesInvoice(
    val id: String,
    val invoiceNo: String,
    val dealerId: String,
    val dealerName: String,
    val dealerZone: String,
    val lineItems: List<SalesInvoiceLineItem>,
    val dealerDiscountPct: Double = 0.0,
    val commissionPct: Double = 0.0,
    val courier: String? = null,
    val signedByRole: String? = null, // optional virtual signature — the designation of whoever created it
    val createdBy: String,
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val status: String = "PENDING", // "PENDING" | "PAID" | "CANCELLED" — full unification with VoiceInvoice is a Backend Architecture step, this field just stops data loss now
    val isDeleted: Boolean = false,
    val deletedAt: LocalDateTime? = null,
    val deletedBy: String? = null,
) {
    val subTotal: Double get() = lineItems.sumOf { it.lineTotal }
    val dealerDiscountAmt: Double get() = subTotal * (dealerDiscountPct / 100)
    val netAfterDiscount: Double get() = subTotal - dealerDiscountAmt
    val commissionAmt: Double get() = netAfterDiscount * (commissionPct / 100)
    val total: Double get() = netAfterDiscount
}

// ---------- Geotagged CRM ----------

data class GpsPing(val lat: Double, val lng: Double, val timestamp: LocalDateTime, val spoofed: Boolean = false)

data class FieldEmployeeRoute(
    val employeeId: String,
    val employeeName: String,
    val date: LocalDate,
    val breadcrumbs: List<GpsPing>,
)

enum class CampaignChannel { ROBOCALL_BN, SMS, EMAIL }

data class EngagementCampaign(
    val id: String,
    val channel: CampaignChannel,
    val message: String,
    val targetZone: String,
    val sentCount: Int = 0,
)

// ---------- HRM & Payroll ----------

data class PayrollLine(
    val employeeId: String,
    val employeeName: String,
    val basePay: Double,
    val targetAmount: Double,
    val achievedAmount: Double,
    val commissionRate: Double,     // e.g. 0.02 = 2%
    val unapprovedAbsenceDays: Int,
    val dailyWage: Double,
) {
    val achievementPct: Double get() = if (targetAmount == 0.0) 0.0 else (achievedAmount / targetAmount) * 100
    val scalingFactor: Double get() = (achievementPct / 100).coerceIn(0.5, 1.5) // 50%-150% curve
    val commission: Double get() = achievedAmount * commissionRate
    val absencePenalty: Double get() = unapprovedAbsenceDays * dailyWage
    val netPayable: Double get() = (basePay * scalingFactor) + commission - absencePenalty
}

// ---------- Credit risk, billing, payments ----------

enum class RiskBand { GREEN, YELLOW, RED }

data class InvoiceLineItem(val name: String, var qty: Double, var unit: String, var unitPrice: Double, var discountPct: Double) {
    val lineTotal: Double get() = qty * unitPrice * (1 - discountPct / 100)
}

data class VoiceInvoice(
    val id: String,
    val dealerId: String,
    val items: MutableList<InvoiceLineItem>,
    var previousDue: Double,
) {
    val subtotal: Double get() = items.sumOf { it.lineTotal }
    val netOutstanding: Double get() = subtotal + previousDue
}

enum class PaymentVerificationStatus { PENDING_VERIFICATION, VERIFIED, REJECTED }

data class PaymentProof(
    val id: String,
    val dealerId: String,
    val amount: Double,
    val proofRef: String, // slip photo / txn id reference
    var status: PaymentVerificationStatus = PaymentVerificationStatus.PENDING_VERIFICATION,
)

// ---------- Factory / production ----------

data class RawMaterialLot(
    val id: String,
    val materialName: String, // "Raw Leaves", "CMC Thickener", "Packaging"
    val qtyKg: Double,
    val costPerKg: Double,
    val purchasedOn: LocalDate,
)

data class ProductionBatch(
    val id: String,
    val cycleType: String, // "Spray Dryer 30kg" / "Drum Dryer 30kg"
    val inputKg: Double,
    val outputKg: Double,
    var gatepassReceived: Boolean = false,
)

// ---------- Universal Search ----------
data class UniversalSearchResult(
    val moduleReference: String, // matches UniversalActionMenu's moduleReference convention
    val entityId: String,
    val title: String,
    val subtitle: String,
    val navRoute: String? = null, // matches a Dest.route in NavGraph, if this result type has its own screen
)

/**
 * Universal Search — Deep-Link support. A destination screen (currently
 * DealersScreen for Dealer/Retailer) checks this once on entry and, if it
 * matches, opens that exact record's detail view then clears it — a plain
 * in-memory handoff rather than a NavGraph route argument, so it doesn't
 * require adding parameters to every one of the 20 existing routes.
 */
object PendingSearchNavigation {
    private val _pending = MutableStateFlow<Pair<String, String>?>(null) // moduleReference to entityId
    val pending: StateFlow<Pair<String, String>?> = _pending.asStateFlow()

    fun request(moduleReference: String, entityId: String) { _pending.value = moduleReference to entityId }
    fun consume(moduleReference: String): String? {
        val current = _pending.value ?: return null
        if (current.first != moduleReference) return null
        _pending.value = null
        return current.second
    }
}

// ---------- BI / advisory ----------

data class PrescriptionCard(
    val id: String,
    val title: String,
    val body: String,
    val severity: RiskBand,
)

data class BoardroomQuery(val question: String, val answer: String, val mode: String = "analysis", val askedAt: LocalDateTime = LocalDateTime.now())

// ---------- Task Manager ----------

enum class TaskStatus { PENDING, IN_PROGRESS, COMPLETED, CANCELLED }

data class TaskItem(
    val id: String,
    val title: String,
    val assignee: String,
    var done: Boolean = false,
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
    val deletedAt: LocalDateTime? = null,
    val deletedBy: String? = null,
    val status: TaskStatus = TaskStatus.PENDING, // Task & Activity Management — 4-state status, `done` stays as a derived quick-check (true only when status == COMPLETED)
    val parentTaskId: String? = null, // Sub Tasks — null means this is a top-level task
)

// ---------- Approvals ----------
// Generic approval-request inbox: leave, discount, expense, etc. Distinct
// from the Sales Chain's order verification (SO_LOGGED -> ASM_VERIFIED),
// which is its own dedicated flow — this is for everything else that needs
// a "someone above me signs off" step.

enum class ApprovalType { LEAVE, DISCOUNT, EXPENSE, OTHER }
enum class ApprovalStatus { PENDING, APPROVED, REJECTED }

data class ApprovalRequest(
    val id: String,
    val type: ApprovalType,
    val fromEmployee: String,
    val detail: String,
    var status: ApprovalStatus = ApprovalStatus.PENDING,
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val entityType: String = "", // which structure this approval is about, e.g. "SalesInvoice", "Dealer" — Cascade Approval step needs this link
    val entityId: String = "",
    val level: Int = 1, // multi-level cascade position — Foundation Layer's Cascade Approval step increments this on each hand-off
    val approvedBy: String? = null,
    val approvedAt: LocalDateTime? = null,
    val rejectReason: String? = null,
    val assignedToEmployeeId: String? = null, // Forward/Reassign target — null means "whoever matches the current cascade level/role"
    val escalated: Boolean = false, // Escalate — flags this for the NEXT tier up regardless of normal cascade order
)

// ---------- Backup & Recovery ----------
enum class BackupStatus { IN_PROGRESS, COMPLETED, FAILED, RESTORED }

data class BackupMetadata(
    val id: String,
    val companyId: String,
    val version: String = "v1",
    val collectionsIncluded: Int,
    val fileUrl: String,
    val fileSizeBytes: Long = 0,
    val triggeredBy: String,
    val status: BackupStatus = BackupStatus.COMPLETED,
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val restoredAt: LocalDateTime? = null,
    val restoredBy: String? = null,
)

// ---------- Courier & Logistics ----------

data class CourierPartner(val id: String, val name: String, val hasApi: Boolean)

enum class ShipmentStatus { PICKED_UP, IN_TRANSIT, OUT_FOR_DELIVERY, DELIVERED }

data class Shipment(
    val id: String,
    val courierId: String,
    val dealerOrRetailer: String,
    val trackingId: String?,
    var status: ShipmentStatus = ShipmentStatus.PICKED_UP,
)

// ---------- Stock category (Production vs Store split) ----------
// "Company-wide stock across both categories is mainly the Admin/Chairman's
// concern — SR/ASM/TSM mostly only touch the Store side (dealer fulfillment)."
enum class StockCategory { PRODUCTION, STORE }

// ---------- Accounts / Ledger ----------
// NSM+ only — a running record of money in/out, company-wide. Distinct from
// Billing's per-dealer due balance (that's receivables tracking); this is
// the general ledger view: every recorded inflow/outflow with a category.
enum class LedgerEntryType { IN, OUT }

data class LedgerEntry(
    val id: String,
    val type: LedgerEntryType,
    val category: String, // e.g. "Dealer Payment", "Raw Material Purchase", "Payroll", "Utility Bill"
    val description: String,
    val amount: Double,
    val recordedBy: String,
    val division: String? = null, // যিনি entry করেছেন তার বিভাগ — geo-scoped ভিউয়ের জন্য; null মানে company-wide/central entry
    val recordedAt: LocalDateTime = LocalDateTime.now(),
)

// ================= Module 11: Accounts & Finance =================
// A real double-entry layer sitting alongside the existing single-entry
// LedgerEntry above (which stays, unchanged, for the quick IN/OUT recording
// already used elsewhere in the app). Vouchers are the authoritative source
// for the new Trial Balance / P&L / Balance Sheet reports this module adds.

enum class AccountType { ASSET, LIABILITY, EQUITY, INCOME, EXPENSE }

data class ChartOfAccount(
    val id: String,
    val code: String, // e.g. "1000" Cash, "2000" Accounts Payable — conventional numbering by type band
    val name: String,
    val type: AccountType,
    val parentId: String? = null,
    val isActive: Boolean = true,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

enum class VoucherType { PAYMENT, RECEIPT, JOURNAL, CONTRA }

data class VoucherLine(
    val accountId: String,
    val accountName: String,
    val debit: Double = 0.0,
    val credit: Double = 0.0,
)

data class Voucher(
    val id: String,
    val voucherNo: String,
    val type: VoucherType,
    val voucherDate: LocalDateTime = LocalDateTime.now(),
    val narration: String = "",
    val lines: List<VoucherLine>,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
) {
    val totalDebit: Double get() = lines.sumOf { it.debit }
    val totalCredit: Double get() = lines.sumOf { it.credit }
    /** Core double-entry integrity rule — every voucher's debits must equal its credits before it's allowed to post. */
    val isBalanced: Boolean get() = kotlin.math.abs(totalDebit - totalCredit) < 0.01
}

/** One row of the Trial Balance report — a single account's net debit/credit position across every posted voucher. */
data class TrialBalanceRow(val account: ChartOfAccount, val totalDebit: Double, val totalCredit: Double) {
    val netDebit: Double get() = (totalDebit - totalCredit).coerceAtLeast(0.0)
    val netCredit: Double get() = (totalCredit - totalDebit).coerceAtLeast(0.0)
}

// ================= Module 5: Purchase Management =================

data class Supplier(
    val id: String,
    val name: String,
    val phone: String = "",
    val address: String = "",
    var dueBalance: Double = 0.0, // Supplier Due — what WE owe them
    val creditLimit: Double = 0.0, // credit terms they've extended to us
    val dedupKey: String = "",
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val deletedAt: LocalDateTime? = null,
    val deletedBy: String? = null,
)

data class PurchaseLineItem(val productId: String, val name: String, val unit: String, val qty: Double, val unitCost: Double) {
    val lineTotal: Double get() = qty * unitCost
}

data class PurchaseOrder(
    val id: String,
    val poNo: String,
    val supplierId: String,
    val supplierName: String,
    val lineItems: List<PurchaseLineItem>,
    val status: String = "DRAFT", // DRAFT | SENT | PARTIALLY_RECEIVED | RECEIVED | CANCELLED
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
) {
    val subTotal: Double get() = lineItems.sumOf { it.lineTotal }
}

// Goods Received Note — confirms what actually arrived against a PO (may
// differ from what was ordered); this is what actually triggers stock-in
// and the supplier due balance increase, not the PO itself.
data class GoodsReceivedNote(
    val id: String,
    val grnNo: String,
    val purchaseOrderId: String,
    val supplierId: String,
    val supplierName: String,
    val receivedItems: List<PurchaseLineItem>,
    val warehouseId: String,
    val receivedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
) {
    val totalValue: Double get() = receivedItems.sumOf { it.lineTotal }
}

data class PurchaseReturn(
    val id: String,
    val returnNo: String,
    val purchaseOrderId: String? = null,
    val supplierId: String,
    val supplierName: String,
    val lineItems: List<PurchaseLineItem>,
    val reason: String = "",
    val refundAmount: Double = 0.0,
    val status: String = "PENDING",
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
)

// ================= Module 3: Inventory extras =================

data class ProductCategory(val id: String, val name: String, val isActive: Boolean = true)
data class ProductBrand(val id: String, val name: String, val isActive: Boolean = true)

// A stock-in event with an expiry date creates one of these; stockOut/damage
// consumes from the oldest non-expired lot first (FEFO — first-expiry-first-out).
data class InventoryLot(
    val id: String,
    val productId: String,
    val warehouseId: String,
    val batchCode: String,
    val qtyRemaining: Double,
    val expiryDate: LocalDateTime? = null,
    val receivedAt: LocalDateTime = LocalDateTime.now(),
)

data class DamageReport(
    val id: String,
    val productId: String,
    val productName: String,
    val warehouseId: String,
    val qty: Double,
    val reason: String,
    val reportedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class StockTransfer(
    val id: String,
    val productId: String,
    val productName: String,
    val fromWarehouseId: String,
    val toWarehouseId: String,
    val qty: Double,
    val status: String = "COMPLETED", // this app's warehouses are all company-owned, so transfers post immediately
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ================= Module 2: Manufacturing & Production extras =================

data class BomLine(val rawMaterialName: String, val qtyPerUnit: Double, val unit: String)

// Bill of Materials — "to make 1 unit of finished product X, you need these raw materials".
data class BillOfMaterials(
    val id: String,
    val finishedProductName: String,
    val lines: List<BomLine>,
    val laborCostPerUnit: Double = 0.0,
    val overheadCostPerUnit: Double = 0.0,
    val isActive: Boolean = true,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class ProductionOrder(
    val id: String,
    val orderNo: String,
    val bomId: String,
    val finishedProductName: String,
    val targetQty: Double,
    val status: String = "PLANNED", // PLANNED | IN_PROGRESS | COMPLETED | CANCELLED
    val scheduledDate: LocalDateTime,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class QualityCheck(
    val id: String,
    val batchId: String,
    val result: String, // "PASS" | "FAIL"
    val notes: String = "",
    val checkedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class ProductionLoss(
    val id: String,
    val batchId: String,
    val qtyLost: Double,
    val reason: String,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class MachineLog(
    val id: String,
    val machineName: String,
    val batchId: String? = null,
    val hoursUsed: Double,
    val notes: String = "",
    val recordedAt: LocalDateTime = LocalDateTime.now(),
)

// ================= Module 6: CRM (Lead/Opportunity/Communication History) =================

enum class LeadStatus { NEW, CONTACTED, QUALIFIED, CONVERTED, LOST }

data class Lead(
    val id: String,
    val name: String,
    val phone: String = "",
    val source: String = "", // e.g. "Market visit", "Referral", "Cold call"
    val status: LeadStatus = LeadStatus.NEW,
    val assignedTo: String = "",
    val notes: String = "",
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
)

data class Opportunity(
    val id: String,
    val leadId: String? = null,
    val title: String,
    val estimatedValue: Double = 0.0,
    val stage: String = "PROSPECTING", // PROSPECTING | NEGOTIATION | WON | LOST
    val assignedTo: String = "",
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class CustomerSegment(val id: String, val name: String, val criteria: String = "")

/** Communication History — a call, tied optionally to a Lead or an existing Dealer/Retailer. */
data class CallLog(
    val id: String,
    val leadId: String? = null,
    val partyType: PartyType? = null,
    val partyId: String? = null,
    val contactName: String = "",
    val phone: String = "",
    val durationMinutes: Int = 0,
    val notes: String = "",
    val loggedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class MeetingLog(
    val id: String,
    val title: String,
    val attendees: String = "",
    val notes: String = "",
    val meetingDate: LocalDateTime = LocalDateTime.now(),
    val loggedBy: String = "",
)

data class FollowUp(
    val id: String,
    val leadId: String? = null,
    val note: String = "",
    val dueDate: LocalDateTime,
    val done: Boolean = false,
    val createdBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ================= Module 12: HR & Payroll extras =================

enum class LeaveType { CASUAL, SICK, EARNED, UNPAID }
enum class LeaveStatus { PENDING, APPROVED, REJECTED }

data class LeaveRequest(
    val id: String,
    val employeeId: String,
    val employeeName: String,
    val type: LeaveType,
    val fromDate: LocalDate,
    val toDate: LocalDate,
    val reason: String = "",
    val status: LeaveStatus = LeaveStatus.PENDING,
    val createdAt: LocalDateTime = LocalDateTime.now(),
) {
    val days: Long get() = java.time.temporal.ChronoUnit.DAYS.between(fromDate, toDate) + 1
}

/** Increment / Promotion / Transfer / Exit — one shared "employee lifecycle event" shape, distinguished by type, matching how Approval/Audit already unify similar concepts elsewhere in this app. */
data class EmployeeLifecycleEvent(
    val id: String,
    val employeeId: String,
    val employeeName: String,
    val type: String, // "INCREMENT" | "PROMOTION" | "TRANSFER" | "EXIT"
    val oldValue: String = "",
    val newValue: String = "",
    val effectiveDate: LocalDate,
    val notes: String = "",
    val recordedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

// ================= Module 14: Communication Hub =================

data class ChatMessage(
    val id: String,
    val channelId: String, // "general", "dept-sales", "dept-accounts" ... or a "dm-<id1>-<id2>" direct-message key
    val senderId: String,
    val senderName: String,
    val message: String,
    val attachmentUri: String? = null,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class Announcement(
    val id: String,
    val title: String,
    val body: String,
    val postedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
)

data class Circular(
    val id: String,
    val title: String,
    val body: String,
    val department: String? = null, // null = company-wide
    val postedBy: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val isDeleted: Boolean = false,
)

// ================= Module 13: Logistics — Vehicle Tracking =================

data class Vehicle(
    val id: String,
    val registrationNo: String,
    val vehicleType: String = "Truck", // Truck | Van | Motorcycle
    val driverName: String = "",
    val driverPhone: String = "",
    val isActive: Boolean = true,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)

data class VehicleLocationPing(
    val id: String,
    val vehicleId: String,
    val lat: Double,
    val lng: Double,
    val speedKmh: Double = 0.0,
    val recordedAt: LocalDateTime = LocalDateTime.now(),
)

// ================= Module 16: AI & Automation — Sales Forecast =================

/** Simple moving-average-based projection — not a full ML model, but a real computed number from actual historical sales rather than static/canned text. */
data class SalesForecastResult(
    val scopeName: String, // e.g. dealer name or zone name
    val last90DaySales: Double,
    val dailyAverage: Double,
    val projectedNext30Days: Double,
    val trend: String, // "GROWING" | "STABLE" | "DECLINING"
)

// ================= AI Framework additions (Module 16) =================

data class BusinessHealthScore(
    val score: Int, // 0-100
    val label: String, // "Excellent" | "Good" | "Fair" | "Poor"
    val salesTrendComponent: Int,
    val collectionComponent: Int,
    val stockHealthComponent: Int,
    val riskComponent: Int,
)

data class RiskAlert(
    val id: String,
    val severity: RiskBand,
    val category: String, // "Dealer Credit" | "Inventory" | "Collection" | "Approval Backlog"
    val message: String,
)

data class DemandForecastRow(val productName: String, val avgDailyDemand: Double, val projectedNext30Days: Double)

/** Universal Action Menu's "Activity Log" — the read-side domain shape for AuditLogEntity, mirrors logAudit()'s write side. */
data class AuditLogEntry(
    val id: String,
    val entityType: String,
    val entityId: String,
    val action: String,
    val performedBy: String,
    val performedByRole: String,
    val oldValueJson: String? = null,
    val newValueJson: String? = null,
    val timestamp: LocalDateTime = LocalDateTime.now(),
)

// ---------- Notification Framework ----------
// A persisted in-app notification record — connects business events
// (approval, collection, dealer/retailer registration, leave, etc.) to a
// real inbox entry, distinct from the live-computed alerts (low stock,
// vacancy) NotificationsScreen already surfaces from other tables directly.
// Actual OS push delivery to a specific device still needs the Cloud
// Functions deploy (pending Blaze plan, per SETUP_FIREBASE.md) — this is
// the client-side half: the record gets created and synced regardless,
// ready for a Cloud Function to also push it once deployed.
enum class NotificationCategory { APPROVAL, COLLECTION, PAYMENT, SALES_ORDER, DELIVERY, PRODUCTION, LOW_STOCK, ATTENDANCE, LEAVE, COMPLAINT, DEALER_REGISTRATION, RETAILER_REGISTRATION, INVOICE, PURCHASE_ORDER, GOODS_RECEIPT, QUALITY_CHECK, STOCK_TRANSFER, HELPDESK, TASK }

data class NotificationEntry(
    val id: String,
    val category: NotificationCategory,
    val title: String,
    val body: String,
    val targetEmployeeId: String? = null, // null = broadcast to whoever's permission scope covers it
    val isRead: Boolean = false,
    val createdAt: LocalDateTime = LocalDateTime.now(),
)
