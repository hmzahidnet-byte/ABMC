package com.abm.erp.core

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.theme.TextPrimary

data class SubModuleItem(val key: String, val label: String, val icon: String, val colorStart: Long, val colorEnd: Long)

/**
 * The colorful animated header every module screen can open with — same
 * visual language established on HR (Attendance) and CRM (profile detail),
 * now available as one shared component so every module gets its own
 * distinct, non-overlapping color identity without copy-pasting the same
 * ~15 lines everywhere.
 */
@Composable
fun ModuleGradientHeader(title: String, icon: String, colorStart: Long, colorEnd: Long) {
    val infinite = rememberInfiniteTransition(label = "moduleHeaderPulse")
    val iconScale by infinite.animateFloat(
        initialValue = 1f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(animation = tween(1400, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
        label = "iconScale",
    )
    Box(
        Modifier.fillMaxWidth()
            .background(Brush.linearGradient(listOf(Color(colorStart), Color(colorEnd))), RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
            .padding(18.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 22.sp, modifier = Modifier.graphicsLayer(scaleX = iconScale, scaleY = iconScale))
            Spacer(Modifier.width(10.dp))
            Text(title, color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 17.sp)
        }
    }
}

/**
 * The reusable "sub-menu of colorful tiles" every module's own screen opens
 * into — same visual language as the Dashboard's main module grid, just one
 * level deeper. Approved on Sales Chain first; same component reused for
 * every other module so the pattern stays identical everywhere.
 */
@Composable
fun SubModuleGrid(items: List<SubModuleItem>, onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        val rows = items.chunked(4)
        rows.forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 18.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { item -> SubModuleTile(item, onClick = { onSelect(item.key) }) }
                repeat(4 - row.size) { Spacer(Modifier.width(54.dp)) }
            }
        }
    }
}

@Composable
private fun SubModuleTile(item: SubModuleItem, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.9f else 1f, label = "tileScale")
    Column(
        modifier = Modifier
            .width(64.dp)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(54.dp)
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .background(Brush.linearGradient(listOf(Color(item.colorStart), Color(item.colorEnd))), RoundedCornerShape(17.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Text(item.icon, fontSize = 22.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(item.label, style = MaterialTheme.typography.labelSmall, color = TextPrimary, textAlign = TextAlign.Center, maxLines = 2)
    }
}

/** Standard "← Back" link used at the top of every sub-view, to return to that module's tile grid. */
@Composable
fun BackToSubMenuLink(onClick: () -> Unit) {
    Text(
        "← Back", color = TextPrimary, fontSize = 13.sp,
        modifier = Modifier.clickable(onClick = onClick).padding(bottom = 12.dp),
    )
}
