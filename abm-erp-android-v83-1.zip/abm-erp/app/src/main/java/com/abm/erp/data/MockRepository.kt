package com.abm.erp.data

import android.content.Context
import com.abm.erp.data.room.AppDatabase
import com.abm.erp.data.room.ApprovalRequestEntity
import com.abm.erp.data.room.AttendanceRecordEntity
import com.abm.erp.data.room.BoardroomQueryEntity
import com.abm.erp.data.room.Converters
import com.abm.erp.data.room.CourierPartnerEntity
import com.abm.erp.data.room.DealerEntity
import com.abm.erp.data.room.EngagementCampaignEntity
import com.abm.erp.data.room.FieldEmployeeRouteEntity
import com.abm.erp.data.room.AuditLogEntity
import com.abm.erp.data.room.LedgerEntryEntity
import com.abm.erp.data.room.PaymentProofEntity
import com.abm.erp.data.room.PayrollLineEntity
import com.abm.erp.data.room.ProductionBatchEntity
import com.abm.erp.data.room.RawMaterialLotEntity
import com.abm.erp.data.room.RetailOrderEntity
import com.abm.erp.data.room.InvoiceEntity
import com.abm.erp.data.room.ShipmentEntity
import com.abm.erp.data.room.TaskItemEntity
import com.abm.erp.data.room.QuotationEntity
import com.abm.erp.data.room.DeliveryChallanEntity
import com.abm.erp.data.room.SalesReturnEntity
import com.abm.erp.data.room.PartyLedgerEntryEntity
import com.abm.erp.data.room.PartyCollectionEntity
import com.abm.erp.data.room.DiscountRuleEntity
import com.abm.erp.data.room.SalesRouteEntity
import com.abm.erp.data.room.VisitLogEntity
import com.abm.erp.data.room.AttachmentEntity
import com.abm.erp.data.room.BillOfMaterialsEntity
import com.abm.erp.data.room.EmployeeLifecycleEventEntity
import com.abm.erp.data.room.LeaveRequestEntity
import com.abm.erp.data.room.MachineLogEntity
import com.abm.erp.data.room.NotificationEntryEntity
import com.abm.erp.data.room.ProductionLossEntity
import com.abm.erp.data.room.ProductionOrderEntity
import com.abm.erp.data.room.QualityCheckEntity
import com.abm.erp.data.room.RetailerEntity
import com.abm.erp.data.room.RoleDefinitionEntity
import com.abm.erp.data.room.TerritoryEntity
import com.abm.erp.data.room.VehicleEntity
import com.abm.erp.data.room.VehicleLocationPingEntity

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneOffset

/**
 * Single source of truth for the whole app, now backed by a real on-device
 * Room database instead of an in-memory list. The public API (every val and
 * fun below) is intentionally identical to the original in-memory version,
 * so no UI Composable needs to change: only what's *inside* these functions
 * changed, from list mutation to real DB reads/writes.
 *
 * Call MockRepository.init(context) once, from ABMApplication.onCreate,
 * before any Composable reads from it.
 */
object MockRepository {

    private lateinit var db: AppDatabase
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ---- Cross-device sync status — visible "Pending/Synced/Failed" indicator ----
    private var pendingSyncCount = java.util.concurrent.atomic.AtomicInteger(0)
    private val _syncStatus = MutableStateFlow(SyncStatus.SYNCED)
    val syncStatus: StateFlow<SyncStatus> = _syncStatus.asStateFlow()

    /** Every push call routes its Firestore Task through here so the badge reflects real in-flight state, even with several pushes overlapping. */
    private fun trackSync(task: com.google.android.gms.tasks.Task<Void>) {
        pendingSyncCount.incrementAndGet()
        _syncStatus.value = SyncStatus.PENDING
        task.addOnCompleteListener {
            val remaining = pendingSyncCount.decrementAndGet()
            if (!it.isSuccessful) { _syncStatus.value = SyncStatus.FAILED; return@addOnCompleteListener }
            if (remaining <= 0) _syncStatus.value = SyncStatus.SYNCED
        }
    }

    fun init(context: Context) {
        if (::db.isInitialized) return
        db = AppDatabase.getInstance(context)
        seedIfEmpty()
        wireFlows()
    }

    // ================= Cross-device sync (Sales Chain / Dealer / HR) =================
    // Same idea as FirebaseSync's Complaint Box, but merged straight into Room
    // instead of a separate parallel StateFlow — this way every existing
    // screen keeps reading MockRepository.orders/dealers/payroll exactly as
    // before, with zero UI changes. A write on any device pushes here
    // (fire-and-forget, never blocks the local save); a listener on every
    // device pulls remote changes back into its own Room via the same
    // upsert() calls the local code already uses.
    private val firestoreDb by lazy { com.google.firebase.firestore.FirebaseFirestore.getInstance() }
    private var syncCompanyId: String? = null
    private var ordersListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var dealersListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var attendanceListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var payrollListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var salesInvoicesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var ledgerListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var auditLogListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var campaignsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var tasksListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var approvalsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var shipmentsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var couriersListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var retailersListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var territoriesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var roleDefinitionsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

    private fun syncCollection(name: String) =
        firestoreDb.collection("companies").document(syncCompanyId ?: "_unset").collection(name)

    /** Call once the company code is known (mirrors FirebaseSync.startCompanyScopedListeners). Safe to call again; re-attaches nothing if it's the same company. */
    fun startCrossDeviceSync(companyId: String) {
        if (companyId == syncCompanyId) return
        syncCompanyId = companyId
        listenRetailOrdersRemote()
        listenDealersRemote()
        listenAttendanceRemote()
        listenPayrollRemote()
        listenSalesInvoicesRemote()
        listenLedgerRemote()
        listenCampaignsRemote()
        listenTasksRemote()
        listenApprovalsRemote()
        listenShipmentsRemote()
        listenCouriersRemote()
        listenAuditLogRemote()
        listenMarketSummaryRemote()
        listenRetailersRemote()
        listenTerritoriesRemote()
        listenRoleDefinitionsRemote()
        listenQuotationsRemote()
        listenDeliveryChallansRemote()
        listenSalesReturnsRemote()
        listenPartyLedgerRemote()
        listenPartyCollectionsRemote()
        listenDiscountRulesRemote()
        listenSalesRoutesRemote()
        listenVisitLogsRemote()
        listenLeaveRequestsRemote()
        listenLifecycleEventsRemote()
        listenVehiclesRemote()
        listenVehiclePingsRemote()
        listenNotificationsRemote()
        listenBomRemote()
        listenProductionOrdersRemote()
        listenQualityChecksRemote()
        listenProductionLossesRemote()
        listenMachineLogsRemote()
    }

    private fun listenBomRemote() {
        syncCollection("billOfMaterials").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "billOfMaterials sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.BillOfMaterialsEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.billOfMaterialsDao().upsertAll(list) }
        }
    }

    private fun listenProductionOrdersRemote() {
        syncCollection("productionOrders").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "productionOrders sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.ProductionOrderEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.productionOrderDao().upsertAll(list) }
        }
    }

    private fun listenQualityChecksRemote() {
        syncCollection("qualityChecks").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "qualityChecks sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.QualityCheckEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.qualityCheckDao().upsertAll(list) }
        }
    }

    private fun listenProductionLossesRemote() {
        syncCollection("productionLosses").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "productionLosses sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.ProductionLossEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.productionLossDao().upsertAll(list) }
        }
    }

    private fun listenMachineLogsRemote() {
        syncCollection("machineLogs").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "machineLogs sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.MachineLogEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.machineLogDao().upsertAll(list) }
        }
    }

    private fun listenRetailOrdersRemote() {
        ordersListenerReg?.remove()
        ordersListenerReg = syncCollection("retailOrders").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "retailOrders sync listener error", err); return@addSnapshotListener }
            snap?.documentChanges?.forEach { change ->
                val e = change.document.toObject(RetailOrderEntity::class.java)
                scope.launch { db.retailOrderDao().upsert(e) }
            }
        }
    }

    private fun listenDealersRemote() {
        dealersListenerReg?.remove()
        dealersListenerReg = syncCollection("dealers").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "dealers sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(DealerEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.dealerDao().upsertAll(list) }
        }
    }

    // ---- Retailer / Territory / RoleDefinition (Data Design step's new structures) ----
    // Same shape as every other collection above: listen -> upsert locally,
    // and a matching push* function below for whenever a create/edit flow is
    // wired to call it (Foundation Layer's Data Integrity + RBAC steps).
    private fun listenRetailersRemote() {
        retailersListenerReg?.remove()
        retailersListenerReg = syncCollection("retailers").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "retailers sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.RetailerEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { list.forEach { db.retailerDao().upsert(it) } }
        }
    }

    private fun listenTerritoriesRemote() {
        territoriesListenerReg?.remove()
        territoriesListenerReg = syncCollection("territories").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "territories sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.TerritoryEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.territoryDao().upsertAll(list) }
        }
    }

    private fun listenRoleDefinitionsRemote() {
        roleDefinitionsListenerReg?.remove()
        roleDefinitionsListenerReg = syncCollection("roleDefinitions").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "roleDefinitions sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.RoleDefinitionEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.roleDefinitionDao().upsertAll(list) }
        }
    }

    // ---- Module 4/7/8 listeners (Sales Mgmt, DMS, Retailer/Outlet) ----
    private var quotationsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var deliveryChallansListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var salesReturnsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var partyLedgerListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var partyCollectionsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var discountRulesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var salesRoutesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var visitLogsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

    private fun listenQuotationsRemote() {
        quotationsListenerReg?.remove()
        quotationsListenerReg = syncCollection("quotations").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "quotations sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(QuotationEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.quotationDao().upsertAll(list) }
        }
    }

    private fun listenDeliveryChallansRemote() {
        deliveryChallansListenerReg?.remove()
        deliveryChallansListenerReg = syncCollection("deliveryChallans").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "deliveryChallans sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(DeliveryChallanEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.deliveryChallanDao().upsertAll(list) }
        }
    }

    private fun listenSalesReturnsRemote() {
        salesReturnsListenerReg?.remove()
        salesReturnsListenerReg = syncCollection("salesReturns").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "salesReturns sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(SalesReturnEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.salesReturnDao().upsertAll(list) }
        }
    }

    private fun listenPartyLedgerRemote() {
        partyLedgerListenerReg?.remove()
        partyLedgerListenerReg = syncCollection("partyLedger").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "partyLedger sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(PartyLedgerEntryEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.partyLedgerDao().upsertAll(list) }
        }
    }

    private fun listenPartyCollectionsRemote() {
        partyCollectionsListenerReg?.remove()
        partyCollectionsListenerReg = syncCollection("partyCollections").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "partyCollections sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(PartyCollectionEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.partyCollectionDao().upsertAll(list) }
        }
    }

    private fun listenDiscountRulesRemote() {
        discountRulesListenerReg?.remove()
        discountRulesListenerReg = syncCollection("discountRules").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "discountRules sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(DiscountRuleEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.discountRuleDao().upsertAll(list) }
        }
    }

    private fun listenSalesRoutesRemote() {
        salesRoutesListenerReg?.remove()
        salesRoutesListenerReg = syncCollection("salesRoutes").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "salesRoutes sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(SalesRouteEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.salesRouteDao().upsertAll(list) }
        }
    }

    private fun listenVisitLogsRemote() {
        visitLogsListenerReg?.remove()
        visitLogsListenerReg = syncCollection("visitLogs").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "visitLogs sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(VisitLogEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.visitLogDao().upsertAll(list) }
        }
    }

    private var leaveRequestsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var lifecycleEventsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

    private fun listenLeaveRequestsRemote() {
        leaveRequestsListenerReg?.remove()
        leaveRequestsListenerReg = syncCollection("leaveRequests").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "leaveRequests sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.LeaveRequestEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.leaveRequestDao().upsertAll(list) }
        }
    }

    private fun listenLifecycleEventsRemote() {
        lifecycleEventsListenerReg?.remove()
        lifecycleEventsListenerReg = syncCollection("employeeLifecycleEvents").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "employeeLifecycleEvents sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.EmployeeLifecycleEventEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.employeeLifecycleEventDao().upsertAll(list) }
        }
    }

    private var vehiclesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var vehiclePingsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

    private fun listenVehiclesRemote() {
        vehiclesListenerReg?.remove()
        vehiclesListenerReg = syncCollection("vehicles").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "vehicles sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.VehicleEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.vehicleDao().upsertAll(list) }
        }
    }

    private fun listenVehiclePingsRemote() {
        vehiclePingsListenerReg?.remove()
        vehiclePingsListenerReg = syncCollection("vehicleLocationPings").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "vehicleLocationPings sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.VehicleLocationPingEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.vehicleLocationPingDao().upsertAll(list) }
        }
    }

    private fun pushRetailer(e: com.abm.erp.data.room.RetailerEntity) {
        val task = syncCollection("retailers").document(e.id).set(e)
        task.addOnFailureListener { android.util.Log.w("MockRepository", "pushRetailer failed", it) }
        trackSync(task)
    }

    private fun pushTerritory(e: com.abm.erp.data.room.TerritoryEntity) {
        syncCollection("territories").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("MockRepository", "pushTerritory failed", it) }
    }

    private fun pushRoleDefinition(e: com.abm.erp.data.room.RoleDefinitionEntity) {
        syncCollection("roleDefinitions").document(e.role).set(e)
            .addOnFailureListener { android.util.Log.w("MockRepository", "pushRoleDefinition failed", it) }
    }

    private fun listenAttendanceRemote() {
        attendanceListenerReg?.remove()
        attendanceListenerReg = syncCollection("attendance").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "attendance sync listener error", err); return@addSnapshotListener }
            snap?.documentChanges?.forEach { change ->
                val e = change.document.toObject(AttendanceRecordEntity::class.java)
                scope.launch { db.attendanceDao().upsert(e) }
            }
        }
    }

    private fun listenPayrollRemote() {
        payrollListenerReg?.remove()
        payrollListenerReg = syncCollection("payroll").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "payroll sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(PayrollLineEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.payrollDao().upsertAll(list) }
        }
    }

    private fun listenSalesInvoicesRemote() {
        salesInvoicesListenerReg?.remove()
        salesInvoicesListenerReg = syncCollection("salesInvoices").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "salesInvoices sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(InvoiceEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.invoiceDao().upsertAll(list) }
        }
    }

    private fun listenLedgerRemote() {
        ledgerListenerReg?.remove()
        ledgerListenerReg = syncCollection("ledger").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "ledger sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(LedgerEntryEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.ledgerDao().upsertAll(list) }
        }
    }

    private fun listenCampaignsRemote() {
        campaignsListenerReg?.remove()
        campaignsListenerReg = syncCollection("campaigns").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "campaigns sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(EngagementCampaignEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.engagementCampaignDao().upsertAll(list) }
        }
    }

    private fun listenTasksRemote() {
        tasksListenerReg?.remove()
        tasksListenerReg = syncCollection("tasks").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "tasks sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(TaskItemEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.taskDao().upsertAll(list) }
        }
    }

    private fun listenApprovalsRemote() {
        approvalsListenerReg?.remove()
        approvalsListenerReg = syncCollection("approvals").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "approvals sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(ApprovalRequestEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.approvalDao().upsertAll(list) }
        }
    }

    private fun listenShipmentsRemote() {
        shipmentsListenerReg?.remove()
        shipmentsListenerReg = syncCollection("shipments").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "shipments sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(ShipmentEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.shipmentDao().upsertAll(list) }
        }
    }

    private fun listenCouriersRemote() {
        couriersListenerReg?.remove()
        couriersListenerReg = syncCollection("couriers").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "couriers sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(CourierPartnerEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.courierDao().upsertAll(list) }
        }
    }

    /** Fire-and-forget push — same resilience rule as the rest of the app: a failed push logs and moves on, never blocks or crashes the local save that already succeeded in Room. */
    private fun pushRetailOrder(e: RetailOrderEntity) {
        syncCollection("retailOrders").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("MockRepository", "pushRetailOrder failed", it) }
    }

    private fun pushDealer(e: DealerEntity) {
        syncCollection("dealers").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("MockRepository", "pushDealer failed", it) }
    }

    /**
     * Stock and due-balance are shared counters — two phones could adjust the
     * SAME dealer within seconds of each other. A full-document push here
     * would silently overwrite whichever write lands second (the exact
     * "money/stock conflict" risk flagged earlier). Firestore's atomic
     * increment() avoids that: both increments land, in whatever order they
     * arrive, with no lost update.
     */
    private fun pushDealerIncrement(dealerId: String, stockDelta: Int, dueDelta: Double) {
        val updates = mutableMapOf<String, Any>()
        if (stockDelta != 0) updates["stockUnits"] = com.google.firebase.firestore.FieldValue.increment(stockDelta.toLong())
        if (dueDelta != 0.0) updates["dueBalance"] = com.google.firebase.firestore.FieldValue.increment(dueDelta)
        if (updates.isEmpty()) return
        val task = syncCollection("dealers").document(dealerId).set(updates, com.google.firebase.firestore.SetOptions.merge())
        task.addOnFailureListener { android.util.Log.w("MockRepository", "pushDealerIncrement failed", it) }
        trackSync(task)
    }

    private fun pushAttendance(e: AttendanceRecordEntity) {
        syncCollection("attendance").document("${e.employeeId}_${e.dateEpochDay}").set(e)
            .addOnFailureListener { android.util.Log.w("MockRepository", "pushAttendance failed", it) }
    }

    private fun pushPayroll(e: PayrollLineEntity) {
        syncCollection("payroll").document(e.employeeId).set(e)
            .addOnFailureListener { android.util.Log.w("MockRepository", "pushPayroll failed", it) }
    }

    private fun pushSalesInvoice(e: InvoiceEntity) {
        val task = syncCollection("salesInvoices").document(e.id).set(e)
        task.addOnFailureListener { android.util.Log.w("MockRepository", "pushSalesInvoice failed", it) }
        trackSync(task)
    }

    private fun pushLedgerEntry(e: LedgerEntryEntity) {
        syncCollection("ledger").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("MockRepository", "pushLedgerEntry failed", it) }
    }

    /**
     * The one shared audit-trail writer — every module calls this instead of
     * building its own logging. oldValue/newValue are passed as whatever
     * domain object was affected; their .toString() becomes the JSON-ish
     * snapshot (simple, readable, no serialization library needed for an
     * audit trail whose job is "what changed", not machine-parsing).
     */
    fun logAudit(entityType: String, entityId: String, action: String, oldValue: Any? = null, newValue: Any? = null) {
        scope.launch {
            val entry = AuditLogEntity(
                id = java.util.UUID.randomUUID().toString(),
                entityType = entityType, entityId = entityId, action = action,
                performedBy = currentUser.name, performedByRole = currentUser.role.name,
                oldValueJson = oldValue?.toString(), newValueJson = newValue?.toString(),
                timestampEpochMillis = System.currentTimeMillis(),
            )
            db.auditLogDao().upsert(entry)
            pushAuditLog(entry)
        }
    }

    private fun pushAuditLog(e: AuditLogEntity) {
        syncCollection("auditLog").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("MockRepository", "pushAuditLog failed", it) }
    }

    private fun listenAuditLogRemote() {
        auditLogListenerReg?.remove()
        auditLogListenerReg = syncCollection("auditLog").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "auditLog sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(AuditLogEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.auditLogDao().upsertAll(list) }
        }
    }

    // ---- Market Analysis's pre-computed summary — the hourlyMarketSummary Cloud Function writes here so the screen doesn't have to sum every dealer itself ----
    data class ZoneSummary(val zone: String, val salesLast90Days: Double, val dueBalance: Double)
    private val _marketSummary = MutableStateFlow<List<ZoneSummary>>(emptyList())
    val marketSummary: StateFlow<List<ZoneSummary>> = _marketSummary.asStateFlow()
    private var marketSummaryListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

    private fun listenMarketSummaryRemote() {
        marketSummaryListenerReg?.remove()
        marketSummaryListenerReg = syncCollection("orgState").document("marketSummary").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "marketSummary listener error", err); return@addSnapshotListener }
            val byZone = snap?.get("byZone") as? Map<*, *> ?: return@addSnapshotListener
            _marketSummary.value = byZone.entries.mapNotNull { (k, v) ->
                val zoneData = v as? Map<*, *> ?: return@mapNotNull null
                ZoneSummary(
                    zone = k as? String ?: return@mapNotNull null,
                    salesLast90Days = (zoneData["salesLast90Days"] as? Number)?.toDouble() ?: 0.0,
                    dueBalance = (zoneData["dueBalance"] as? Number)?.toDouble() ?: 0.0,
                )
            }
        }
    }

    private fun pushCampaign(e: EngagementCampaignEntity) {
        syncCollection("campaigns").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("MockRepository", "pushCampaign failed", it) }
    }

    private fun pushTask(e: TaskItemEntity) {
        val task = syncCollection("tasks").document(e.id).set(e)
        task.addOnFailureListener { android.util.Log.w("MockRepository", "pushTask failed", it) }
        trackSync(task)
    }

    private fun pushApproval(e: ApprovalRequestEntity) {
        syncCollection("approvals").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("MockRepository", "pushApproval failed", it) }
    }

    private fun pushShipment(e: ShipmentEntity) {
        syncCollection("shipments").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("MockRepository", "pushShipment failed", it) }
    }

    // ---- Company / users (kept simple/in-memory: rarely change, not core business data) ----
    val companies = listOf(Company("C-1", "ABM Corporation"))
    private val _activeCompanyId = MutableStateFlow(companies.first().id)
    val activeCompanyId: StateFlow<String> = _activeCompanyId.asStateFlow()
    fun switchCompany(id: String) = _activeCompanyId.update { id }

    // ---- Session / login ----
    // Small demo directory matching the design prototype's PIN accounts, so this first
    // Kotlin pass behaves identically to what's already been validated in the JSX design.
    // A real login later replaces this map with a backend call + secure on-device session.
    // Mutable (StateFlow, not a plain val) because Chairman can reset anyone's PIN from the
    // Account & Access Control screen — the old PIN must stop working immediately.
    private val _demoAccounts = MutableStateFlow(
        mapOf(
            "12345" to AppUser("U-CHAIR", "Zahid Hossain", UserRole.CHAIRMAN, "C-1", "All Bangladesh · Board", "CHAIR-1"),
            "11111" to AppUser("U-SR-BARISHAL", "Rafiq Hasan", UserRole.SR, "C-1", "Barishal district ▸ Notun Bazar", "SR-Barishal"),
            "22222" to AppUser("U-RSM-KHULNA", "Kabir Ahmed", UserRole.RSM, "C-1", "Khulna division (all districts)", "RSM-Khulna"),
            "33333" to AppUser("U-ASM-RANGPUR", "Mahmudul Islam", UserRole.ASM, "C-1", "Rangpur district", "ASM-Rangpur"),
            "44444" to AppUser("U-NSM", "Anwar Kabir", UserRole.NSM, "C-1", "All divisions (national)", "NSM-1"),
            "55555" to AppUser("U-AGM", "Farida Yasmin", UserRole.AGM, "C-1", "All divisions · HQ", "AGM-1"),
            "66666" to AppUser("U-GM", "Shafiqul Islam", UserRole.GM, "C-1", "All divisions · HQ", "GM-1"),
            "77777" to AppUser("U-MD", "Nasrin Chowdhury", UserRole.MD, "C-1", "All Bangladesh · HQ", "MD-1"),
        )
    )
    val demoAccountsFlow: StateFlow<Map<String, AppUser>> = _demoAccounts.asStateFlow()
    val demoAccounts: Map<String, AppUser> get() = _demoAccounts.value

    /** Chairman-only: invalidates oldPin, returns a fresh random 5-digit PIN for the same person. Never a weak/guessable one. */
    fun resetPin(oldPin: String): String {
        var newPin: String
        do { newPin = (10000..99999).random().toString() } while (isWeakPin(newPin))
        _demoAccounts.update { current ->
            val user = current[oldPin] ?: return@update current
            (current - oldPin) + (newPin to user)
        }
        return newPin
    }

    // ---- Device lockout: 3 wrong PIN attempts locks this device until the
    // Chairman's own PIN unlocks it (either on the lock screen itself, or
    // from the Account & Access Control screen once someone IS logged in). ----
    private val _deviceLocked = MutableStateFlow(false)
    val deviceLocked: StateFlow<Boolean> = _deviceLocked.asStateFlow()
    private val _failedAttempts = MutableStateFlow(0)
    val failedAttempts: StateFlow<Int> = _failedAttempts.asStateFlow()

    fun recordFailedPinAttempt() {
        _failedAttempts.update { it + 1 }
        if (_failedAttempts.value >= 3) _deviceLocked.value = true
    }

    fun unlockDevice() {
        _deviceLocked.value = false
        _failedAttempts.value = 0
    }

    /** True only for the literal Chairman PIN "12345" account — used to gate the unlock pad. */
    fun isChairmanPin(code: String): Boolean = demoAccounts[code]?.role == UserRole.CHAIRMAN

    /** Chairman নিজেই device-locked হলে ব্যবহারযোগ্য recovery code — আসল অ্যাপে এটা secure, hash করে রাখা একটা কোড হবে। */
    const val BREAK_GLASS_RECOVERY_CODE = "ABM-RECOVERY-2026"

    /** Super Admin — the platform owner, not part of any single company. Separate login path entirely (see LoginScreen's "Super Admin?" link). */

    private val _currentUser = MutableStateFlow(demoAccounts.getValue("12345"))
    val currentUserFlow: StateFlow<AppUser> = _currentUser.asStateFlow()
    val currentUser: AppUser get() = _currentUser.value

    /** Called by LoginScreen once a PIN or biometric prompt succeeds. */
    fun completeLogin(user: AppUser) {
        _currentUser.value = user
        logAudit("Session", user.employeeId, "LOGIN")
        // Crashlytics: tag reports with who/which company hit them — makes a
        // crash report actionable instead of anonymous.
        com.google.firebase.crashlytics.FirebaseCrashlytics.getInstance().apply {
            setUserId(user.id)
            setCustomKey("company_id", user.companyId)
            setCustomKey("role", user.role.name)
        }
        // FCM: if a push token arrived before we knew who was logging in
        // (e.g. right after install), attach it to this employee now.
        com.abm.erp.notifications.FcmTokenHolder.pendingToken?.let { registerFcmToken(it) }
        com.google.firebase.messaging.FirebaseMessaging.getInstance().token
            .addOnSuccessListener { registerFcmToken(it) }
        // Role security: seed the directory once, then ask the Cloud Function
        // to bind this device's own auth token to the employee's real role —
        // this is what lets Firestore rules check request.auth.token.role
        // instead of just "is anyone logged in".
        seedEmployeeRolesToFirestore()
        claimUserRole(user.id)
    }

    /**
     * Foundation Layer — Session Management: ordinary logout (as opposed to
     * an admin-triggered forceLogoutEmployee). Clears the device's
     * "remember me" employee id so the next app open needs a full PIN/
     * biometric login again, and records the Logout in the audit trail
     * before the session reference is gone. Deliberately does NOT clear
     * the saved Company Code or this device's Trusted Device status —
     * those are device-tenant scoping and re-trust state, not per-session
     * state, and clearing them on every ordinary logout would force a
     * device-approval re-request on next login for no reason.
     */
    fun logout(context: android.content.Context) {
        logAudit("Session", currentUser.employeeId, "LOGOUT")
        clearLastLoggedInEmployee(context)
    }

    /**
     * Pushes the whole static EMPLOYEE_DIRECTORY's role/geo (not the mock
     * target/achieved/insight fields — only what security decisions need)
     * into Firestore so the Cloud Function has something authoritative to
     * look employees up against. Safe to call on every login: it's just
     * upserts, and only actually costs a write the first time or if the
     * directory itself changes.
     */
    private fun seedEmployeeRolesToFirestore() {
        val batch = com.google.firebase.firestore.FirebaseFirestore.getInstance().batch()
        val col = syncCollection("employeeRoles")
        EMPLOYEE_DIRECTORY.forEach { emp ->
            val doc = col.document(emp.id)
            batch.set(doc, mapOf(
                "role" to emp.role.name,
                "division" to (emp.geo.division ?: ""),
                "district" to (emp.geo.district ?: ""),
            ))
        }
        batch.commit().addOnFailureListener { android.util.Log.w("MockRepository", "seedEmployeeRolesToFirestore failed", it) }
    }

    /** Calls the setUserRoleClaim Cloud Function, then refreshes the ID token so the new custom claims take effect immediately (same session, no re-login needed). */
    private fun claimUserRole(employeeId: String) {
        val data = hashMapOf("employeeId" to employeeId, "companyId" to (syncCompanyId ?: ""))
        com.google.firebase.functions.FirebaseFunctions.getInstance()
            .getHttpsCallable("setUserRoleClaim")
            .call(data)
            .addOnSuccessListener {
                com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.getIdToken(true)
                    ?.addOnFailureListener { e -> android.util.Log.w("MockRepository", "ID token refresh failed", e) }
            }
            .addOnFailureListener { android.util.Log.w("MockRepository", "claimUserRole failed — Cloud Function may not be deployed yet, app still works with the existing rules", it) }
    }

    /** Stores the device's push token against this employee so the backend can target notifications later. */
    fun registerFcmToken(token: String) {
        scope.launch {
            try {
                com.google.firebase.firestore.FirebaseFirestore.getInstance()
                    .collection("companies").document(currentUser.companyId)
                    .collection("fcmTokens").document(currentUser.employeeId)
                    .set(mapOf("token" to token, "updatedAtMillis" to System.currentTimeMillis()))
            } catch (e: Exception) {
                android.util.Log.w("MockRepository", "registerFcmToken failed", e)
            }
        }
    }

    // ---- Per-employee vacancy (not per-tier): which specific people in
    // EMPLOYEE_DIRECTORY are currently marked vacant. Chairman-only control,
    // exposed on the Vacant Positions screen. Now backed by Firestore via
    // FirebaseSync, so a toggle on the Chairman's phone reaches every other
    // device — that's the whole point, a local-only list can't do that.
    // Falls back to a local-only Set if Firebase isn't configured yet. ----
    val vacantEmployeeIds: StateFlow<Set<String>> get() = FirebaseSync.vacantEmployeeIds
    fun toggleVacant(employeeId: String) = FirebaseSync.toggleVacant(employeeId)

    // ---- Sales chain ----
    lateinit var orders: StateFlow<List<RetailOrder>>
        private set

    fun advanceOrder(id: String, next: OrderStage, dealerId: String? = null) {
        scope.launch {
            db.retailOrderDao().advance(id, next.name, dealerId)
            val updated = db.retailOrderDao().getAll().first().firstOrNull { it.id == id }
            if (updated != null) pushRetailOrder(updated)
            if (next == OrderStage.FULFILLED) {
                val targetDealerId = dealerId ?: updated?.routedDealerId
                if (targetDealerId != null) {
                    val qty = extractQuantity(updated?.items)
                    db.dealerDao().adjustStock(targetDealerId, -qty)
                    pushDealerIncrement(targetDealerId, stockDelta = -qty, dueDelta = 0.0)
                }
            }
        }
    }

    /** Best-effort quantity parse from free-text items like "ABM Masala Tea x40 ctn" — falls back to a small default when no number is found. */
    private fun extractQuantity(items: String?): Int =
        items?.let { Regex("""x(\d+)""", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1)?.toIntOrNull() } ?: 10

    /** Approving a dealer's bulk/procurement request pulls from the COMPANY's central stock and adds to that dealer's own stock — this is the OTHER half of the stock rule (dealer bulk order verifies against company stock, not itself). */
    fun fulfillBulkRequest(dealerId: String, qty: Int) {
        scope.launch { db.dealerDao().adjustStock(dealerId, qty) }
        pushDealerIncrement(dealerId, stockDelta = qty, dueDelta = 0.0)
        // company-side warehouse stock deduction happens via InventoryRepository once that module's real stock-out flow is wired — noted for the Warehouse module work.
    }

    /** Sales-type chain of command (separate from designation chain): Retailer/Wholesale orders never generate an invoice; invoicing starts at Dealer/Depot level. SR takes retail orders only — cannot invoice. TSM and above can. */
    fun canInvoice(role: UserRole): Boolean = role != UserRole.SR

    lateinit var salesInvoices: StateFlow<List<SalesInvoice>>
        private set

    /** Creates the invoice (auto-saves immediately, no separate save step) and updates the dealer's due balance + stock in the same action. */
    /**
     * Correction after the fact — same invoice document, same invoiceNo,
     * new content. Reverses the old due-balance/stock effect and applies the
     * new one, so editing an invoice 2 days later never double-counts.
     */
    fun updateSalesInvoice(
        invoiceId: String, lineItems: List<SalesInvoiceLineItem>,
        dealerDiscountPct: Double, commissionPct: Double, courier: String?,
    ) {
        scope.launch {
            val old = db.invoiceDao().getAllSales().first().firstOrNull { it.id == invoiceId } ?: return@launch
            val oldItems = Converters.unpackSalesInvoiceItems(old.lineItemsRaw)
            val oldSubTotal = oldItems.sumOf { it.lineTotal }
            val oldNet = oldSubTotal * (1 - old.dealerDiscountPct / 100)
            oldItems.forEach { db.dealerDao().adjustStock(old.dealerId, -it.qty) } // reverse old stock arrival
            db.dealerDao().adjustDueBalance(old.dealerId, -oldNet) // reverse old due-balance effect

            val newSubTotal = lineItems.sumOf { it.lineTotal }
            val newNet = newSubTotal * (1 - dealerDiscountPct / 100)
            val updatedInvoice = old.copy(
                lineItemsRaw = Converters.packSalesInvoiceItems(lineItems),
                dealerDiscountPct = dealerDiscountPct, commissionPct = commissionPct, courier = courier,
            )
            db.invoiceDao().upsert(updatedInvoice)
            syncCollection("salesInvoices").document(updatedInvoice.id).set(updatedInvoice)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push updated invoice failed", it) }
            db.dealerDao().adjustDueBalance(old.dealerId, newNet)
            lineItems.forEach { db.dealerDao().adjustStock(old.dealerId, it.qty) }
            val oldQtyTotal = oldItems.sumOf { it.qty }
            val newQtyTotal = lineItems.sumOf { it.qty }
            pushDealerIncrement(old.dealerId, stockDelta = newQtyTotal - oldQtyTotal, dueDelta = newNet - oldNet)
            logAudit("SalesInvoice", old.id, "UPDATE", oldValue = old, newValue = updatedInvoice)
        }
    }

    /**
     * Invoice-module permission enforcement example (PRIORITY 1 deliverable).
     * Blocked at the repository layer, not just the UI — even a tampered
     * client calling this directly gets refused if the role lacks canApprove
     * on "bill". Returns false + logs a DENY audit entry on refusal.
     */
    fun approveSalesInvoice(invoiceId: String): Boolean {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)) {
            logAudit("SalesInvoice", invoiceId, "DENY", oldValue = currentUser.role.name, newValue = "APPROVE")
            return false
        }
        scope.launch {
            val existing = db.invoiceDao().getAllSales().first().firstOrNull { it.id == invoiceId } ?: return@launch
            val updated = existing.copy(status = "APPROVED")
            db.invoiceDao().upsert(updated)
            syncCollection("salesInvoices").document(invoiceId).update("status", "APPROVED")
                .addOnFailureListener { android.util.Log.w("MockRepository", "push invoice-approve failed", it) }
            logAudit("SalesInvoice", existing.id, "APPROVE", oldValue = existing.status, newValue = "APPROVED")
            createNotification(NotificationCategory.APPROVAL, "Invoice Approved", "${existing.invoiceNo} — ${existing.dealerName} অনুমোদিত হয়েছে")
        }
        return true
    }

    /** Soft delete — same permission-gate pattern as approveSalesInvoice, but checks canDelete on "bill". */
    fun deleteSalesInvoice(invoiceId: String): Boolean {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.DELETE)) {
            logAudit("SalesInvoice", invoiceId, "DENY", oldValue = currentUser.role.name, newValue = "DELETE")
            return false
        }
        scope.launch {
            val existing = db.invoiceDao().getAllSales().first().firstOrNull { it.id == invoiceId } ?: return@launch
            db.invoiceDao().upsert(existing.copy(isDeleted = true, deletedAtEpochMillis = System.currentTimeMillis(), deletedBy = currentUser.name))
            syncCollection("salesInvoices").document(invoiceId)
                .update(mapOf("isDeleted" to true, "deletedAtEpochMillis" to System.currentTimeMillis(), "deletedBy" to currentUser.name))
                .addOnFailureListener { android.util.Log.w("MockRepository", "push invoice-delete failed", it) }
            logAudit("SalesInvoice", existing.id, "DELETE", oldValue = false, newValue = true)
        }
        return true
    }

    /** Restore — same permission-gate as delete (canDelete implies can undo it too). */
    fun restoreSalesInvoice(invoiceId: String): Boolean {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.DELETE)) {
            logAudit("SalesInvoice", invoiceId, "DENY", oldValue = currentUser.role.name, newValue = "RESTORE")
            return false
        }
        scope.launch {
            db.invoiceDao().restore(invoiceId)
            syncCollection("salesInvoices").document(invoiceId)
                .update(mapOf("isDeleted" to false, "deletedAtEpochMillis" to null, "deletedBy" to null))
                .addOnFailureListener { android.util.Log.w("MockRepository", "push invoice-restore failed", it) }
            logAudit("SalesInvoice", invoiceId, "RESTORE")
        }
        return true
    }

    fun createSalesInvoice(
        dealerId: String, dealerName: String, dealerZone: String, lineItems: List<SalesInvoiceLineItem>,
        dealerDiscountPct: Double, commissionPct: Double, courier: String?, signedByRole: String?,
    ): Boolean {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.CREATE)) {
            logAudit("SalesInvoice", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return false
        }
        if (lineItems.isEmpty() || lineItems.any { it.qty <= 0 || it.unitPrice < 0 }) {
            android.util.Log.w("MockRepository", "createSalesInvoice rejected: empty or invalid line items")
            return false
        }
        // Foundation Layer/Module 7 — Credit Limit enforcement: a dealer with
        // creditLimit > 0 can't be invoiced past it. creditLimit == 0 means
        // "no explicit limit configured yet" (most dealers today), so it's
        // not blocked — this only bites once a Chairman/GM sets a real cap.
        val subTotal = lineItems.sumOf { it.lineTotal }
        val net = subTotal * (1 - dealerDiscountPct / 100)
        val dealer = dealers.value.firstOrNull { it.id == dealerId }
        if (dealer != null && dealer.creditLimit > 0 && dealer.dueBalance + net > dealer.creditLimit) {
            logAudit("SalesInvoice", "(new)", "DENY", oldValue = "credit limit ৳${dealer.creditLimit}", newValue = "would reach ৳${dealer.dueBalance + net}")
            return false
        }
        scope.launch {
            val invoiceNo = "INV-${1000 + db.invoiceDao().countByType("SALES") + 1}"
            val entity = InvoiceEntity(
                id = java.util.UUID.randomUUID().toString(), invoiceNo = invoiceNo, type = "SALES", dealerId = dealerId, dealerName = dealerName,
                dealerZone = dealerZone, lineItemsRaw = Converters.packSalesInvoiceItems(lineItems),
                dealerDiscountPct = dealerDiscountPct, commissionPct = commissionPct, courier = courier,
                signedByRole = signedByRole, createdBy = currentUser.name, createdAtEpochMillis = System.currentTimeMillis(),
            )
            db.invoiceDao().upsert(entity)
            syncCollection("salesInvoices").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push new invoice failed", it) }
            db.dealerDao().adjustDueBalance(dealerId, net)
            lineItems.forEach { db.dealerDao().adjustStock(dealerId, it.qty) } // invoiced stock arrives at the dealer
            pushDealerIncrement(dealerId, stockDelta = lineItems.sumOf { it.qty }, dueDelta = net)
            postPartyLedgerEntry(PartyType.DEALER, dealerId, "DEBIT", net, "Sales Invoice $invoiceNo", entity.id)
            logAudit("SalesInvoice", entity.id, "CREATE", newValue = entity)
            createNotification(NotificationCategory.INVOICE, "New Invoice", "$invoiceNo — $dealerName (৳${"%,.0f".format(net)})")
        }
        return true
    }

    fun logNewOrder(
        retailerName: String, items: String, amount: Double, zone: String,
        photoUri: String? = null, lat: Double? = null, lng: Double? = null,
        channel: String = "retail", anonymous: Boolean = false, photoPurpose: String? = null,
    ) {
        scope.launch {
            val nextNum = 100 + db.retailOrderDao().count() + 1
            val entity = RetailOrderEntity(
                id = java.util.UUID.randomUUID().toString(),
                orderNo = "ORD-$nextNum",
                retailerName = retailerName,
                loggedBySoId = currentUser.id,
                zone = zone,
                items = items,
                amount = amount,
                stage = OrderStage.SO_LOGGED.name,
                routedDealerId = null,
                loggedAtEpochMillis = System.currentTimeMillis(),
                retailerPhotoUri = photoUri,
                retailerLat = lat,
                retailerLng = lng,
                retailerQrCode = com.abm.erp.util.QrCodeGenerator.retailerCode(retailerName, zone),
                channel = channel, anonymous = anonymous, photoPurpose = photoPurpose,
            )
            db.retailOrderDao().upsert(entity)
            pushRetailOrder(entity)
            createNotification(NotificationCategory.SALES_ORDER, "New Sales Order", "${entity.orderNo} — $retailerName (৳${"%,.0f".format(amount)})")
        }
    }

    lateinit var dealers: StateFlow<List<Dealer>>
        private set

    // ================= Universal Attachment System (Global Rule) =================
    /** Any module calls this the same way — a photo/PDF/document/audio/video tagged to any entity, with GPS+timestamp+uploader captured automatically. */
    fun uploadAttachment(moduleReference: String, entityId: String, type: AttachmentType, uri: String, lat: Double? = null, lng: Double? = null): Attachment {
        val attachment = Attachment(
            id = java.util.UUID.randomUUID().toString(), moduleReference = moduleReference, entityId = entityId,
            type = type, uri = uri, lat = lat, lng = lng, uploadedBy = currentUser.name,
        )
        scope.launch {
            val entity = attachment.toEntity()
            db.attachmentDao().upsert(entity)
            syncCollection("attachments").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push attachment failed", it) }
            logAudit("Attachment", attachment.id, "CREATE", newValue = "$moduleReference/$entityId: $type")
        }
        return attachment
    }

    fun attachmentsFor(moduleReference: String, entityId: String): Flow<List<Attachment>> =
        db.attachmentDao().getForEntity(moduleReference, entityId).map { list -> list.map { it.toDomain() } }

    /** Universal Action Menu: Activity Log — every module's card opens the SAME audit trail, filtered to just this record, instead of a bespoke history view per module. */
    fun activityLogFor(entityType: String, entityId: String): Flow<List<AuditLogEntry>> =
        db.auditLogDao().getForEntity(entityType, entityId).map { list -> list.map { it.toDomain() } }

    /** Universal Action Menu: Approval History — reuses ApprovalRequest.entityType/entityId (Foundation Layer's Cascade Approval fields) rather than a new table. */
    fun approvalHistoryFor(entityType: String, entityId: String): List<ApprovalRequest> =
        approvals.value.filter { it.entityType == entityType && it.entityId == entityId }

    // ================= Universal Action Menu: Duplicate (Global Rule) =================
    /** "Duplicate" clones a Dealer/Retailer/Product's editable fields into a brand-new record (new id, dedup-checked exactly like a fresh registration) — never a raw id copy, which would violate the very dedup rule Duplicate is meant to route around. */
    fun duplicateDealer(dealerId: String): DuplicateResult? {
        val d = dealers.value.firstOrNull { it.id == dealerId } ?: return null
        val created = createDealer("${d.name} (copy)", d.zone, d.phone, d.address) ?: return null
        return DuplicateResult(created.id, created.name)
    }

    fun duplicateRetailer(retailerId: String): DuplicateResult? {
        val r = retailers.value.firstOrNull { it.id == retailerId } ?: return null
        val created = createRetailer(name = "${r.name} (copy)", phone = r.phone, address = r.address, dealerId = r.dealerId, outletCategory = r.outletCategory, outletType = r.outletType) ?: return null
        return DuplicateResult(created.id, created.name)
    }

    fun duplicateTask(taskId: String): DuplicateResult? {
        val t = tasks.value.firstOrNull { it.id == taskId } ?: return null
        val newId = java.util.UUID.randomUUID().toString()
        val newTitle = "${t.title} (copy)"
        scope.launch {
            val entity = com.abm.erp.data.room.TaskItemEntity(id = newId, title = newTitle, assignee = t.assignee, done = false, createdAtEpochMillis = System.currentTimeMillis())
            db.taskDao().upsert(entity)
            syncCollection("tasks").document(newId).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push task-duplicate failed", it) }
            logAudit("Task", newId, "CREATE", newValue = entity.toDomain())
        }
        return DuplicateResult(newId, newTitle)
    }

    fun duplicateQuotation(quotationId: String): DuplicateResult? {
        val q = quotations.value.firstOrNull { it.id == quotationId } ?: return null
        val created = createQuotation(q.partyType, q.partyId, q.partyName, q.lineItems, LocalDateTime.now().plusDays(7)) ?: return null
        return DuplicateResult(created.id, created.quotationNo)
    }

    // ================= AI Framework (Module 16) =================
    /**
     * Business Health Score — a single 0-100 number blended from four real,
     * currently-available signals: sales momentum, collection health (due
     * vs sales ratio), stock health (low-stock proportion), and open risk
     * count. Not a black-box ML model — a transparent weighted blend, which
     * is the honest, buildable version of "Business Health Score" today.
     */
    fun computeBusinessHealthScore(): BusinessHealthScore {
        val dealersNow = dealers.value
        val totalSales = dealersNow.sumOf { it.salesLast90Days }
        val totalDue = dealersNow.sumOf { it.dueBalance }
        val collectionRatio = if (totalSales <= 0.0) 0.5 else (1.0 - (totalDue / totalSales)).coerceIn(0.0, 1.0)
        val stockLevelsNow = InventoryRepository.stockLevels.value
        val lowStockRatio = if (stockLevelsNow.isEmpty()) 0.0 else stockLevelsNow.count { it.isLowStock }.toDouble() / stockLevelsNow.size
        val stockHealth = (1.0 - lowStockRatio).coerceIn(0.0, 1.0)
        val redDealers = dealersNow.count { riskBand(it) == RiskBand.RED }
        val riskHealth = if (dealersNow.isEmpty()) 1.0 else (1.0 - (redDealers.toDouble() / dealersNow.size)).coerceIn(0.0, 1.0)
        val salesTrend = if (totalSales > 0) 0.7 else 0.4 // no daily time-series yet to compute a real trend slope — neutral-positive default when there's any sales activity at all

        val salesComponent = (salesTrend * 25).toInt()
        val collectionComponent = (collectionRatio * 25).toInt()
        val stockComponent = (stockHealth * 25).toInt()
        val riskComponent = (riskHealth * 25).toInt()
        val total = salesComponent + collectionComponent + stockComponent + riskComponent
        val label = when { total >= 85 -> "Excellent"; total >= 65 -> "Good"; total >= 45 -> "Fair"; else -> "Poor" }
        return BusinessHealthScore(total, label, salesComponent, collectionComponent, stockComponent, riskComponent)
    }

    /** Risk Detection — scans dealers/inventory/approvals for anything needing attention right now, surfaced as a flat alert list instead of the person having to check every module separately. */
    fun computeRiskAlerts(): List<RiskAlert> {
        val alerts = mutableListOf<RiskAlert>()
        dealers.value.filter { riskBand(it) == RiskBand.RED }.forEach {
            alerts.add(RiskAlert(java.util.UUID.randomUUID().toString(), RiskBand.RED, "Dealer Credit", "${it.name} due (৳${"%,.0f".format(it.dueBalance)}) is dangerously high vs 90-day sales"))
        }
        InventoryRepository.stockLevels.value.filter { it.isLowStock }.take(5).forEach {
            alerts.add(RiskAlert(java.util.UUID.randomUUID().toString(), RiskBand.YELLOW, "Inventory", "${it.productName} at ${it.warehouseName} is at/below reorder level"))
        }
        val pendingApprovalsCount = approvals.value.count { it.status == ApprovalStatus.PENDING }
        if (pendingApprovalsCount > 5) {
            alerts.add(RiskAlert(java.util.UUID.randomUUID().toString(), RiskBand.YELLOW, "Approval Backlog", "$pendingApprovalsCount approvals pending — may be stalling operations"))
        }
        return alerts
    }

    /** Demand Forecast — per-product projected 30-day demand from actual stock movement history (OUT-type movements = real consumption/sales), not a canned number. */
    fun computeDemandForecast(): List<DemandForecastRow> {
        val movements = InventoryRepository.movements.value
        return movements.filter { it.type == MovementType.OUT }
            .groupBy { it.productName }
            .map { (name, list) ->
                val total = list.sumOf { it.quantity }
                val daily = total / 90.0 // approximating over the same 90-day window used elsewhere in this app
                DemandForecastRow(name, daily, daily * 30)
            }
            .sortedByDescending { it.projectedNext30Days }
    }

    /** Collection Forecast — projected 30-day cash collection, extrapolated from verified PartyCollection history. */
    fun computeCollectionForecast(): Double {
        val verified = partyCollections.value.filter { it.status == "VERIFIED" }
        if (verified.isEmpty()) return 0.0
        val oldestDate = verified.minOf { it.createdAt }
        val daysSpan = java.time.temporal.ChronoUnit.DAYS.between(oldestDate, LocalDateTime.now()).coerceAtLeast(1)
        val dailyAvg = verified.sumOf { it.amount } / daysSpan
        return dailyAvg * 30
    }

    /** Production Forecast — projected 30-day finished-goods output, extrapolated from completed Production Orders' actual target quantities. */
    fun computeProductionForecast(): Double {
        val completed = productionOrders.value.filter { it.status == "COMPLETED" }
        if (completed.isEmpty()) return 0.0
        val oldestDate = completed.minOf { it.createdAt }
        val daysSpan = java.time.temporal.ChronoUnit.DAYS.between(oldestDate, LocalDateTime.now()).coerceAtLeast(1)
        val dailyAvg = completed.sumOf { it.targetQty } / daysSpan
        return dailyAvg * 30
    }

    /** Inventory Forecast — projected days-until-stockout per low-stock item, from actual consumption rate (StockMovement OUT history), not a canned number. */
    fun computeInventoryForecast(): List<Pair<String, Int>> {
        val stockLevelsNow = InventoryRepository.stockLevels.value
        val demandRows = computeDemandForecast().associateBy { it.productName }
        return stockLevelsNow.filter { it.isLowStock }.map { level ->
            val dailyDemand = demandRows[level.productName]?.avgDailyDemand ?: 0.0
            val daysLeft = if (dailyDemand <= 0.0) 999 else (level.quantityOnHand / dailyDemand).toInt()
            level.productName to daysLeft
        }.sortedBy { it.second }
    }

    /** Smart Business Recommendation — a short, prioritized action list synthesized from the other AI Framework signals (health score, risk alerts, forecasts) rather than a separate hardcoded tip list. */
    fun smartBusinessRecommendations(): List<String> {
        val recs = mutableListOf<String>()
        val health = computeBusinessHealthScore()
        if (health.collectionComponent < 15) recs.add("Collection component কম (${health.collectionComponent}/25) — বকেয়া দ্রুত আদায়ের উপর জোর দিন।")
        if (health.stockHealthComponent < 15) recs.add("Stock health কম (${health.stockHealthComponent}/25) — low-stock item গুলো এখনই re-order করুন।")
        val inactiveDealersNow = inactiveDealers()
        if (inactiveDealersNow.isNotEmpty()) recs.add("${inactiveDealersNow.size} জন dealer ৯০ দিনে কোনো sales করেননি — visit/follow-up প্ল্যান করুন।")
        val coverage = outletCoverageRatio()
        if (coverage < 0.7) recs.add("Outlet coverage মাত্র ${(coverage * 100).toInt()}% — বাকি outlet-গুলো visit-এর আওতায় আনুন।")
        val pendingApprovalsCount = approvals.value.count { it.status == ApprovalStatus.PENDING }
        if (pendingApprovalsCount > 5) recs.add("$pendingApprovalsCount টা approval আটকে আছে — escalate/forward করে দ্রুত সমাধান করুন।")
        if (recs.isEmpty()) recs.add("সবকিছু স্বাভাবিক দেখাচ্ছে — এখন কোনো জরুরি action প্রয়োজন নেই।")
        return recs
    }

    /** Dealer & Retailer Analytics — Credit Utilization: how much of the credit limit is currently used up (0.0–1.0+); no limit set returns 0.0 (nothing to utilize against). */
    fun creditUtilization(dealer: Dealer): Double = if (dealer.creditLimit <= 0) 0.0 else (dealer.dueBalance / dealer.creditLimit).coerceAtLeast(0.0)
    fun creditUtilization(retailer: Retailer): Double = if (retailer.creditLimit <= 0) 0.0 else (retailer.dueBalance / retailer.creditLimit).coerceAtLeast(0.0)

    /** Inactive Dealer Detection — no sales activity recorded in the trailing window; a real "last order date" would sharpen this further once per-order dealer timestamps are tracked historically. */
    fun inactiveDealers(): List<Dealer> = dealers.value.filter { it.salesLast90Days <= 0.0 && it.isActive && !it.isDeleted }

    /** Inactive Outlet Detection — same idea for Retailer/Outlet, using visit recency instead of sales (retailers don't carry their own 90-day sales figure). */
    fun inactiveRetailers(sinceDays: Long = 60): List<Retailer> {
        val cutoff = LocalDateTime.now().minusDays(sinceDays)
        val visitedRecently = visitLogs.value.filter { it.partyType == PartyType.RETAILER && it.checkInAt.isAfter(cutoff) }.map { it.partyId }.toSet()
        return retailers.value.filter { it.isActive && !it.isDeleted && it.id !in visitedRecently }
    }

    /** Module 9 (SFA) — Route Compliance: what fraction of a beat's assigned outlets were actually visited today. */
    fun routeComplianceToday(route: SalesRoute): Double {
        if (route.outletIds.isEmpty()) return 1.0
        val todayStart = LocalDateTime.now().toLocalDate().atStartOfDay()
        val visitedToday = visitLogs.value.filter { it.partyType == PartyType.RETAILER && it.checkInAt.isAfter(todayStart) }.map { it.partyId }.toSet()
        return route.outletIds.count { it in visitedToday }.toDouble() / route.outletIds.size
    }

    /** Missed Outlet Detection — which of a beat's assigned outlets were NOT visited today. */
    fun missedOutletsToday(route: SalesRoute): List<Retailer> {
        val todayStart = LocalDateTime.now().toLocalDate().atStartOfDay()
        val visitedToday = visitLogs.value.filter { it.partyType == PartyType.RETAILER && it.checkInAt.isAfter(todayStart) }.map { it.partyId }.toSet()
        val missedIds = route.outletIds.filter { it !in visitedToday }.toSet()
        return retailers.value.filter { it.id in missedIds }
    }

    /** Coverage Tracking — company-wide: what fraction of ALL registered outlets have been visited at least once in the trailing window. */
    fun outletCoverageRatio(sinceDays: Long = 30): Double {
        val activeRetailers = retailers.value.filter { it.isActive && !it.isDeleted }
        if (activeRetailers.isEmpty()) return 1.0
        val cutoff = LocalDateTime.now().minusDays(sinceDays)
        val visited = visitLogs.value.filter { it.partyType == PartyType.RETAILER && it.checkInAt.isAfter(cutoff) }.map { it.partyId }.toSet()
        return activeRetailers.count { it.id in visited }.toDouble() / activeRetailers.size
    }


    // ---- Notification Framework ----
    lateinit var notifications: StateFlow<List<NotificationEntry>>
        private set
    private var notificationsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

    private fun listenNotificationsRemote() {
        notificationsListenerReg?.remove()
        notificationsListenerReg = syncCollection("notifications").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("MockRepository", "notifications sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.NotificationEntryEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.notificationEntryDao().upsertAll(list) }
        }
    }

    /** Connects a business event to the notification inbox — every module that fires one of these calls THIS same function instead of building its own alert plumbing. */
    fun createNotification(category: NotificationCategory, title: String, body: String, targetEmployeeId: String? = null) {
        scope.launch {
            val entity = com.abm.erp.data.room.NotificationEntryEntity(
                id = java.util.UUID.randomUUID().toString(), category = category.name, title = title, body = body,
                targetEmployeeId = targetEmployeeId, isRead = false, createdAtEpochMillis = System.currentTimeMillis(),
            )
            db.notificationEntryDao().upsert(entity)
            syncCollection("notifications").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push notification failed", it) }
        }
    }

    fun markNotificationRead(id: String) {
        scope.launch {
            db.notificationEntryDao().markRead(id)
            syncCollection("notifications").document(id).update("isRead", true)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push notification-read failed", it) }
        }
    }

    /**
     * Universal Search — one search box across every core entity instead of
     * each module needing its own. Pure in-memory substring match over what's
     * already loaded via StateFlow (no extra Firestore/Room query), so it
     * works fully offline too, consistent with the rest of this app.
     */
    fun universalSearch(query: String): List<UniversalSearchResult> {
        if (query.isBlank()) return emptyList()
        val q = query.trim().lowercase()
        val results = mutableListOf<UniversalSearchResult>()
        dealers.value.filter { !it.isDeleted && (it.name.lowercase().contains(q) || it.phone.contains(q) || it.zone.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("Dealer", it.id, it.name, "${it.zone} · Due ৳${"%,.0f".format(it.dueBalance)}", "dealers")) }
        retailers.value.filter { !it.isDeleted && (it.name.lowercase().contains(q) || it.phone.contains(q) || it.outletCategory.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("Retailer", it.id, it.name, "${it.outletCategory}/${it.outletType}", "dealers")) }
        salesInvoices.value.filter { !it.isDeleted && (it.invoiceNo.lowercase().contains(q) || it.dealerName.lowercase().contains(q) || it.status.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("SalesInvoice", it.id, it.invoiceNo, "${it.dealerName} · ৳${"%,.0f".format(it.total)}", "sales")) }
        tasks.value.filter { !it.isDeleted && (it.title.lowercase().contains(q) || it.assignee.lowercase().contains(q) || it.status.name.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("Task", it.id, it.title, it.assignee, "tasks")) }
        CrmRepository.leads.value.filter { !it.isDeleted && (it.name.lowercase().contains(q) || it.phone.contains(q) || it.status.name.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("Lead", it.id, it.name, "${it.source} · ${it.status}", "crm")) }
        approvals.value.filter { it.detail.lowercase().contains(q) || it.fromEmployee.lowercase().contains(q) || it.status.name.lowercase().contains(q) }
            .forEach { results.add(UniversalSearchResult("ApprovalRequest", it.id, it.type.name, it.detail, "approvals")) }
        InventoryRepository.products.value.filter { !it.isDeleted && (it.name.lowercase().contains(q) || it.sku.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("Product", it.id, it.name, "${it.sku} · ৳${it.defaultUnitPrice}", "inventory")) }
        PurchaseRepository.suppliers.value.filter { !it.isDeleted && (it.name.lowercase().contains(q) || it.phone.contains(q)) }
            .forEach { results.add(UniversalSearchResult("Supplier", it.id, it.name, "Due ৳${"%,.0f".format(it.dueBalance)}", "purchase")) }
        PurchaseRepository.purchaseOrders.value.filter { it.poNo.lowercase().contains(q) || it.supplierName.lowercase().contains(q) || it.status.lowercase().contains(q) }
            .forEach { results.add(UniversalSearchResult("PurchaseOrder", it.id, it.poNo, "${it.supplierName} · ${it.status}", "purchase")) }
        // Better sorting — an exact (case-insensitive) title match belongs above a mere substring match, then alphabetical within each group.
        val sorted = results.sortedWith(compareByDescending<UniversalSearchResult> { it.title.equals(query.trim(), ignoreCase = true) }.thenBy { it.title.lowercase() })
        return sorted.take(50) // enough for a phone screen without loading every match on a broad query
    }

    /**
     * CRM — Dealer Health Score (0-100), composed only from real, already-computed signals:
     * risk band (payment behavior), credit utilization, and recent visit coverage.
     * No fabricated inputs — if a signal is unavailable (e.g. no visits logged yet),
     * that component simply doesn't penalize the score rather than assuming the worst.
     */
    fun dealerHealthScore(dealer: Dealer): Int {
        val riskComponent = when (riskBand(dealer)) { RiskBand.GREEN -> 50; RiskBand.YELLOW -> 30; RiskBand.RED -> 10 }
        val utilization = creditUtilization(dealer)
        val creditComponent = (30 * (1 - utilization.coerceIn(0.0, 1.0))).toInt()
        val recentVisit = visitLogs.value.any { it.partyType == PartyType.DEALER && it.partyId == dealer.id && it.checkInAt.isAfter(LocalDateTime.now().minusDays(30)) }
        val visitComponent = if (recentVisit) 20 else 10
        return (riskComponent + creditComponent + visitComponent).coerceIn(0, 100)
    }

    /** Retailer Health Score (0-100) — Retailer has no salesLast90Days field like Dealer, so this honestly uses only the two signals that DO exist: credit utilization and recent visit coverage, weighted proportionally rather than pretending a third signal exists. */
    fun retailerHealthScore(retailer: Retailer): Int {
        val utilization = creditUtilization(retailer)
        val creditComponent = (60 * (1 - utilization.coerceIn(0.0, 1.0))).toInt()
        val recentVisit = visitLogs.value.any { it.partyType == PartyType.RETAILER && it.partyId == retailer.id && it.checkInAt.isAfter(LocalDateTime.now().minusDays(30)) }
        val visitComponent = if (recentVisit) 40 else 20
        return (creditComponent + visitComponent).coerceIn(0, 100)
    }

    fun riskBand(dealer: Dealer): RiskBand {
        val ratio = if (dealer.salesLast90Days == 0.0) 1.0 else dealer.dueBalance / dealer.salesLast90Days
        return when {
            ratio < 0.3 -> RiskBand.GREEN
            ratio < 0.6 -> RiskBand.YELLOW
            else -> RiskBand.RED
        }
    }

    /**
     * Module 16 — Sales Forecast. A real computed projection (simple daily-
     * average extrapolation over the last 90 days), not canned/static text.
     * Genuine ML forecasting needs a real historical time-series this
     * prototype doesn't yet capture per-day — this is the honest, currently
     * buildable version: still a live number pulled from actual dueBalance/
     * salesLast90Days data, not a hardcoded string.
     */
    fun computeSalesForecast(dealer: Dealer): SalesForecastResult {
        val dailyAvg = dealer.salesLast90Days / 90.0
        val projected30d = dailyAvg * 30
        val trend = when {
            dealer.salesLast90Days <= 0.0 -> "STABLE"
            dailyAvg * 30 > dealer.salesLast90Days * 0.4 -> "GROWING"
            dailyAvg * 30 < dealer.salesLast90Days * 0.2 -> "DECLINING"
            else -> "STABLE"
        }
        return SalesForecastResult(dealer.name, dealer.salesLast90Days, dailyAvg, projected30d, trend)
    }

    fun computeZoneForecast(zone: String): SalesForecastResult {
        val zoneDealers = dealers.value.filter { it.zone == zone }
        val total90d = zoneDealers.sumOf { it.salesLast90Days }
        val dailyAvg = total90d / 90.0
        val projected30d = dailyAvg * 30
        return SalesForecastResult(zone, total90d, dailyAvg, projected30d, if (total90d > 0) "STABLE" else "STABLE")
    }

    fun isOrderLocked(dealerId: String): Boolean =
        dealers.value.find { it.id == dealerId }?.let { riskBand(it) == RiskBand.RED } ?: false

    /**
     * Foundation Layer — Data Integrity: Duplicate Prevention (Dealer).
     * Normalizes name+phone into one key so "Barisal Central Dealer" and
     * "barisal central dealer " (trailing space, different case) collide on
     * the same dedup check instead of silently becoming two records.
     */
    private fun dedupKeyFor(name: String, phone: String): String =
        (name.trim().lowercase() + "|" + phone.trim().filter { it.isDigit() })

    /** Invalid-data guard shared by every create-function below — a blank name or an obviously-too-short phone is rejected before it ever reaches Room/Firestore. */
    private fun isValidContactInput(name: String, phone: String): Boolean =
        name.isNotBlank() && (phone.isBlank() || phone.filter { it.isDigit() }.length >= 6)

    /**
     * Creates a new Dealer with full Foundation Layer enforcement: action
     * permission (canCreate on "dealer"), basic input validation, and a
     * duplicate-prevention check against name+phone before the insert.
     * Returns null on any rejection so the UI can show why.
     */
    fun createDealer(name: String, zone: String, phone: String = "", address: String = "", territoryId: String? = null): Dealer? {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.CREATE)) {
            logAudit("Dealer", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return null
        }
        if (!isValidContactInput(name, phone)) {
            android.util.Log.w("MockRepository", "createDealer rejected: invalid name/phone")
            return null
        }
        val dedupKey = dedupKeyFor(name, phone)
        var created: Dealer? = null
        runBlocking(Dispatchers.IO) {
            if (db.dealerDao().countByDedupKey(dedupKey) > 0) {
                android.util.Log.w("MockRepository", "createDealer rejected: duplicate name+phone")
                return@runBlocking
            }
            val dealer = Dealer(
                id = "D-${java.util.UUID.randomUUID().toString().take(8)}", name = name, zone = zone,
                dueBalance = 0.0, salesLast90Days = 0.0, phone = phone, address = address, territoryId = territoryId,
                dedupKey = dedupKey, createdBy = currentUser.name,
            )
            val entity = dealer.toEntity()
            db.dealerDao().upsert(entity)
            pushDealer(entity)
            logAudit("Dealer", dealer.id, "CREATE", newValue = dealer)
            createNotification(NotificationCategory.DEALER_REGISTRATION, "New Dealer Registered", "${dealer.name} — ${dealer.zone}")
            created = dealer
        }
        return created
    }

    fun deleteDealer(dealerId: String): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.DELETE)) {
            logAudit("Dealer", dealerId, "DENY", oldValue = currentUser.role.name, newValue = "DELETE")
            return false
        }
        scope.launch {
            val before = dealers.value.firstOrNull { it.id == dealerId } ?: return@launch
            val now = System.currentTimeMillis()
            db.dealerDao().softDelete(dealerId, now, currentUser.name)
            syncCollection("dealers").document(dealerId)
                .update(mapOf("isDeleted" to true, "deletedAtEpochMillis" to now, "deletedBy" to currentUser.name))
                .addOnFailureListener { android.util.Log.w("MockRepository", "push dealer-delete failed", it) }
            logAudit("Dealer", dealerId, "DELETE", oldValue = before)
        }
        return true
    }

    fun restoreDealer(dealerId: String): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.DELETE)) {
            logAudit("Dealer", dealerId, "DENY", oldValue = currentUser.role.name, newValue = "RESTORE")
            return false
        }
        scope.launch {
            db.dealerDao().restore(dealerId)
            syncCollection("dealers").document(dealerId)
                .update(mapOf("isDeleted" to false, "deletedAtEpochMillis" to null, "deletedBy" to null))
                .addOnFailureListener { android.util.Log.w("MockRepository", "push dealer-restore failed", it) }
            logAudit("Dealer", dealerId, "RESTORE")
        }
        return true
    }

    // ---- Retailer (Data Design's own entity — see Models.kt) ----
    lateinit var retailers: StateFlow<List<Retailer>>
        private set

    /**
     * Creates a Retailer with the same enforcement pattern as createDealer,
     * PLUS referential integrity: a non-null dealerId must actually exist
     * (a Retailer can't be routed to a Dealer that isn't real).
     */
    fun createRetailer(name: String, phone: String = "", address: String = "", territoryId: String? = null, dealerId: String? = null, lat: Double? = null, lng: Double? = null, outletCategory: String = "General Store", outletType: String = "Retail", routeId: String? = null): Retailer? {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.CREATE)) {
            logAudit("Retailer", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return null
        }
        if (!isValidContactInput(name, phone)) {
            android.util.Log.w("MockRepository", "createRetailer rejected: invalid name/phone")
            return null
        }
        if (dealerId != null && dealers.value.none { it.id == dealerId }) {
            android.util.Log.w("MockRepository", "createRetailer rejected: referential integrity — dealerId '$dealerId' doesn't exist")
            return null
        }
        val dedupKey = dedupKeyFor(name, phone.ifBlank { "$lat,$lng" })
        var created: Retailer? = null
        runBlocking(Dispatchers.IO) {
            if (db.retailerDao().countByDedupKey(dedupKey) > 0) {
                android.util.Log.w("MockRepository", "createRetailer rejected: duplicate name+phone/location")
                return@runBlocking
            }
            val retailer = Retailer(
                id = "RTL-${java.util.UUID.randomUUID().toString().take(8)}", name = name, phone = phone, address = address,
                territoryId = territoryId, dealerId = dealerId, lat = lat, lng = lng, dedupKey = dedupKey, createdBy = currentUser.name,
                outletCategory = outletCategory, outletType = outletType, routeId = routeId,
            )
            val entity = retailer.toEntity()
            db.retailerDao().upsert(entity)
            pushRetailer(entity)
            logAudit("Retailer", retailer.id, "CREATE", newValue = retailer)
            createNotification(NotificationCategory.RETAILER_REGISTRATION, "New Outlet Registered", "${retailer.name} — ${retailer.outletCategory}")
            created = retailer
        }
        return created
    }

    fun deleteRetailer(retailerId: String): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.DELETE)) {
            logAudit("Retailer", retailerId, "DENY", oldValue = currentUser.role.name, newValue = "DELETE")
            return false
        }
        scope.launch {
            val now = System.currentTimeMillis()
            db.retailerDao().softDelete(retailerId, now, currentUser.name)
            syncCollection("retailers").document(retailerId)
                .update(mapOf("isDeleted" to true, "deletedAtEpochMillis" to now, "deletedBy" to currentUser.name))
                .addOnFailureListener { android.util.Log.w("MockRepository", "push retailer-delete failed", it) }
            logAudit("Retailer", retailerId, "DELETE")
        }
        return true
    }

    fun restoreRetailer(retailerId: String): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.DELETE)) {
            logAudit("Retailer", retailerId, "DENY", oldValue = currentUser.role.name, newValue = "RESTORE")
            return false
        }
        scope.launch {
            db.retailerDao().restore(retailerId)
            syncCollection("retailers").document(retailerId)
                .update(mapOf("isDeleted" to false, "deletedAtEpochMillis" to null, "deletedBy" to null))
                .addOnFailureListener { android.util.Log.w("MockRepository", "push retailer-restore failed", it) }
            logAudit("Retailer", retailerId, "RESTORE")
        }
        return true
    }

    // ================= Module 4/7/8: Sales Mgmt, Dealer (DMS), Retailer/Outlet =================

    lateinit var quotations: StateFlow<List<Quotation>>
        private set
    lateinit var deliveryChallans: StateFlow<List<DeliveryChallan>>
        private set
    lateinit var salesReturns: StateFlow<List<SalesReturn>>
        private set
    lateinit var partyCollections: StateFlow<List<PartyCollection>>
        private set
    lateinit var discountRules: StateFlow<List<DiscountRule>>
        private set
    lateinit var salesRoutes: StateFlow<List<SalesRoute>>
        private set
    lateinit var visitLogs: StateFlow<List<VisitLog>>
        private set

    /** Every Dealer/Retailer money movement posts through here — one running ledger per party, not just today's dueBalance snapshot. */
    /** Not private — PurchaseRepository (Module 5) posts Supplier-side ledger entries through this too, so there's one shared ledger-posting function instead of a duplicate. */
    fun postPartyLedgerEntry(partyType: PartyType, partyId: String, type: String, amount: Double, reason: String, referenceId: String) {
        scope.launch {
            val balanceAfter = when (partyType) {
                PartyType.DEALER -> dealers.value.firstOrNull { it.id == partyId }?.dueBalance ?: 0.0
                PartyType.RETAILER -> retailers.value.firstOrNull { it.id == partyId }?.dueBalance ?: 0.0
                PartyType.SUPPLIER -> PurchaseRepository.suppliers.value.firstOrNull { it.id == partyId }?.dueBalance ?: 0.0
            }
            val entry = PartyLedgerEntryEntity(
                id = java.util.UUID.randomUUID().toString(), partyType = partyType.name, partyId = partyId,
                type = type, amount = amount, reason = reason, referenceId = referenceId,
                balanceAfter = balanceAfter, createdAtEpochMillis = System.currentTimeMillis(),
            )
            db.partyLedgerDao().upsert(entry)
            syncCollection("partyLedger").document(entry.id).set(entry)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push partyLedger failed", it) }
        }
    }

    fun partyLedgerFor(partyType: PartyType, partyId: String): Flow<List<PartyLedgerEntry>> =
        db.partyLedgerDao().getForParty(partyType.name, partyId).map { list -> list.map { it.toDomain() } }

    fun visitLogsFor(partyType: PartyType, partyId: String): Flow<List<VisitLog>> =
        db.visitLogDao().getForParty(partyType.name, partyId).map { list -> list.map { it.toDomain() } }

    // ---- Quotation (Module 4) ----
    fun createQuotation(partyType: PartyType, partyId: String, partyName: String, lineItems: List<SalesInvoiceLineItem>, validUntil: LocalDateTime): Quotation? {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.CREATE)) {
            logAudit("Quotation", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return null
        }
        val quotation = Quotation(
            id = java.util.UUID.randomUUID().toString(), quotationNo = "QUO-${(1000..9999).random()}",
            partyType = partyType, partyId = partyId, partyName = partyName, lineItems = lineItems,
            validUntil = validUntil, createdBy = currentUser.name,
        )
        scope.launch {
            val entity = quotation.toEntity()
            db.quotationDao().upsert(entity)
            syncCollection("quotations").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push quotation failed", it) }
            logAudit("Quotation", quotation.quotationNo, "CREATE", newValue = quotation)
        }
        return quotation
    }

    /** Converts a DRAFT/SENT quotation into a real SalesInvoice (Dealer-party only — matches createSalesInvoice's own scope) and marks the quotation CONVERTED so it can't be double-used. */
    fun convertQuotationToInvoice(quotationId: String, dealerZone: String, dealerDiscountPct: Double = 0.0, commissionPct: Double = 0.0): Boolean {
        val quotation = quotations.value.firstOrNull { it.id == quotationId } ?: return false
        if (quotation.status !in setOf("DRAFT", "SENT")) return false
        if (quotation.partyType != PartyType.DEALER) return false // Sales Invoice today is dealer-level only, matches canInvoice()
        val created = createSalesInvoice(
            dealerId = quotation.partyId, dealerName = quotation.partyName, dealerZone = dealerZone,
            lineItems = quotation.lineItems, dealerDiscountPct = dealerDiscountPct, commissionPct = commissionPct,
            courier = null, signedByRole = currentUser.role.name,
        )
        if (!created) return false
        scope.launch {
            val newInvoiceId = db.invoiceDao().getAllSales().first().maxByOrNull { it.createdAtEpochMillis }?.id ?: ""
            db.quotationDao().setStatus(quotationId, "CONVERTED", newInvoiceId)
            syncCollection("quotations").document(quotationId).update(mapOf("status" to "CONVERTED", "convertedInvoiceId" to newInvoiceId))
                .addOnFailureListener { android.util.Log.w("MockRepository", "push quotation-convert failed", it) }
            logAudit("Quotation", quotation.quotationNo, "UPDATE", oldValue = "DRAFT/SENT", newValue = "CONVERTED -> $newInvoiceId")
        }
        return true
    }

    fun cancelQuotation(quotationId: String) {
        scope.launch {
            db.quotationDao().setStatus(quotationId, "CANCELLED")
            syncCollection("quotations").document(quotationId).update("status", "CANCELLED")
                .addOnFailureListener { android.util.Log.w("MockRepository", "push quotation-cancel failed", it) }
            logAudit("Quotation", quotationId, "UPDATE", newValue = "CANCELLED")
        }
    }

    // ---- Delivery Challan (Module 4) ----
    fun createDeliveryChallan(invoiceId: String?, partyType: PartyType, partyId: String, partyName: String, lineItems: List<SalesInvoiceLineItem>, vehicleNo: String, driverName: String): DeliveryChallan? {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.CREATE)) {
            logAudit("DeliveryChallan", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return null
        }
        val challan = DeliveryChallan(
            id = java.util.UUID.randomUUID().toString(), challanNo = "DC-${(1000..9999).random()}",
            invoiceId = invoiceId, partyType = partyType, partyId = partyId, partyName = partyName,
            lineItems = lineItems, vehicleNo = vehicleNo, driverName = driverName, deliveredBy = currentUser.name,
            createdBy = currentUser.name,
        )
        scope.launch {
            val entity = challan.toEntity()
            db.deliveryChallanDao().upsert(entity)
            syncCollection("deliveryChallans").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push deliveryChallan failed", it) }
            logAudit("DeliveryChallan", challan.challanNo, "CREATE", newValue = challan)
        }
        return challan
    }

    fun updateChallanStatus(challanId: String, status: String) {
        scope.launch {
            db.deliveryChallanDao().setStatus(challanId, status)
            syncCollection("deliveryChallans").document(challanId).update("status", status)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push challan-status failed", it) }
            logAudit("DeliveryChallan", challanId, "UPDATE", newValue = status)
            if (status == "DELIVERED") {
                val challan = deliveryChallans.value.firstOrNull { it.id == challanId }
                createNotification(NotificationCategory.DELIVERY, "Delivered", "${challan?.challanNo ?: challanId} — ${challan?.partyName ?: ""}")
            }
        }
    }

    // ---- Sales Return (Module 4) ----
    fun createSalesReturn(invoiceId: String?, partyType: PartyType, partyId: String, partyName: String, lineItems: List<SalesInvoiceLineItem>, reason: String): SalesReturn? {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.CREATE)) {
            logAudit("SalesReturn", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return null
        }
        val refund = lineItems.sumOf { it.lineTotal }
        val salesReturn = SalesReturn(
            id = java.util.UUID.randomUUID().toString(), returnNo = "SR-${(1000..9999).random()}",
            invoiceId = invoiceId, partyType = partyType, partyId = partyId, partyName = partyName,
            lineItems = lineItems, reason = reason, refundAmount = refund, createdBy = currentUser.name,
        )
        scope.launch {
            val entity = salesReturn.toEntity()
            db.salesReturnDao().upsert(entity)
            syncCollection("salesReturns").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push salesReturn failed", it) }
            logAudit("SalesReturn", salesReturn.returnNo, "CREATE", newValue = salesReturn)
        }
        return salesReturn
    }

    /** Approving a return reduces the party's due balance (they're credited back) and restores stock. Requires the same DELETE-tier permission as reversing a sale — it's undoing revenue, not routine data entry. */
    fun approveSalesReturn(returnId: String): Boolean {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)) {
            logAudit("SalesReturn", returnId, "DENY", oldValue = currentUser.role.name, newValue = "APPROVE")
            return false
        }
        val salesReturn = salesReturns.value.firstOrNull { it.id == returnId } ?: return false
        scope.launch {
            db.salesReturnDao().setStatus(returnId, "APPROVED")
            syncCollection("salesReturns").document(returnId).update("status", "APPROVED")
                .addOnFailureListener { android.util.Log.w("MockRepository", "push return-approve failed", it) }
            if (salesReturn.partyType == PartyType.DEALER) {
                db.dealerDao().adjustDueBalance(salesReturn.partyId, -salesReturn.refundAmount)
                salesReturn.lineItems.forEach { db.dealerDao().adjustStock(salesReturn.partyId, -it.qty) }
                pushDealerIncrement(salesReturn.partyId, stockDelta = -salesReturn.lineItems.sumOf { it.qty }, dueDelta = -salesReturn.refundAmount)
            }
            postPartyLedgerEntry(salesReturn.partyType, salesReturn.partyId, "CREDIT", salesReturn.refundAmount, "Sales Return ${salesReturn.returnNo}", returnId)
            logAudit("SalesReturn", salesReturn.returnNo, "APPROVE", newValue = "due -৳${salesReturn.refundAmount}")
        }
        return true
    }

    fun rejectSalesReturn(returnId: String) {
        scope.launch {
            db.salesReturnDao().setStatus(returnId, "REJECTED")
            syncCollection("salesReturns").document(returnId).update("status", "REJECTED")
                .addOnFailureListener { android.util.Log.w("MockRepository", "push return-reject failed", it) }
            logAudit("SalesReturn", returnId, "REJECT")
        }
    }

    // ---- Collection (Module 7/8/10 — Dealer/Retailer Collection) ----
    fun createCollection(partyType: PartyType, partyId: String, partyName: String, amount: Double, method: String, proofUri: String? = null): PartyCollection {
        val collection = PartyCollection(
            id = java.util.UUID.randomUUID().toString(), partyType = partyType, partyId = partyId, partyName = partyName,
            amount = amount, method = method, proofUri = proofUri, collectedBy = currentUser.name,
        )
        scope.launch {
            if (amount <= 0) {
                android.util.Log.w("MockRepository", "createCollection skipped: non-positive amount")
                return@launch
            }
            val entity = collection.toEntity()
            db.partyCollectionDao().upsert(entity)
            syncCollection("partyCollections").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push collection failed", it) }
            logAudit("Collection", collection.id, "CREATE", newValue = collection)
        }
        return collection
    }

    /** Verifying a collection is what actually reduces the due balance — an unverified collection is just a claim, not yet trusted money. Requires APPROVE permission (same tier as approving an invoice). */
    fun verifyCollection(collectionId: String): Boolean {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)) {
            logAudit("Collection", collectionId, "DENY", oldValue = currentUser.role.name, newValue = "VERIFY")
            return false
        }
        val collection = partyCollections.value.firstOrNull { it.id == collectionId } ?: return false
        scope.launch {
            val now = System.currentTimeMillis()
            db.partyCollectionDao().setStatus(collectionId, "VERIFIED", currentUser.name, now)
            syncCollection("partyCollections").document(collectionId)
                .update(mapOf("status" to "VERIFIED", "verifiedBy" to currentUser.name, "verifiedAtEpochMillis" to now))
                .addOnFailureListener { android.util.Log.w("MockRepository", "push collection-verify failed", it) }
            if (collection.partyType == PartyType.DEALER) {
                db.dealerDao().adjustDueBalance(collection.partyId, -collection.amount)
                pushDealerIncrement(collection.partyId, stockDelta = 0, dueDelta = -collection.amount)
            } else {
                db.retailerDao().adjustDueBalance(collection.partyId, -collection.amount)
                syncCollection("retailers").document(collection.partyId)
                    .update("dueBalance", com.google.firebase.firestore.FieldValue.increment(-collection.amount))
                    .addOnFailureListener { android.util.Log.w("MockRepository", "push retailer-due-decrement failed", it) }
            }
            postPartyLedgerEntry(collection.partyType, collection.partyId, "CREDIT", collection.amount, "Collection verified", collectionId)
            logAudit("Collection", collectionId, "APPROVE", newValue = "due -৳${collection.amount}")
            createNotification(NotificationCategory.COLLECTION, "Collection Verified", "${collection.partyName}: ৳${"%,.0f".format(collection.amount)} ${collection.method}")
        }
        return true
    }

    fun rejectCollection(collectionId: String) {
        scope.launch {
            db.partyCollectionDao().setStatus(collectionId, "REJECTED", currentUser.name, System.currentTimeMillis())
            syncCollection("partyCollections").document(collectionId).update("status", "REJECTED")
                .addOnFailureListener { android.util.Log.w("MockRepository", "push collection-reject failed", it) }
            logAudit("Collection", collectionId, "REJECT")
        }
    }

    // ---- Discount Rules (Module 4) ----
    fun createDiscountRule(label: String, scope0: String, minQty: Double, discountPct: Double): DiscountRule {
        val rule = DiscountRule(id = java.util.UUID.randomUUID().toString(), label = label, scope = scope0, minQty = minQty, discountPct = discountPct, createdBy = currentUser.name)
        scope.launch {
            val entity = rule.toEntity()
            db.discountRuleDao().upsert(entity)
            syncCollection("discountRules").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push discountRule failed", it) }
            logAudit("DiscountRule", rule.id, "CREATE", newValue = rule)
        }
        return rule
    }

    /** Best-matching applicable discount for a quantity+party combo — specific-party rules win over "ALL" rules. */
    fun applicableDiscountPct(partyId: String, qty: Double): Double =
        discountRules.value.filter { it.isActive && qty >= it.minQty && (it.scope == partyId || it.scope == "ALL") }
            .maxByOrNull { if (it.scope == partyId) 1 else 0 }?.discountPct ?: 0.0

    // ---- Route & Territory (Module 8's Outlet Route Assignment / SFA beat plan) ----
    fun createRoute(name: String, territoryId: String?, assignedToEmployeeId: String, outletIds: List<String>): SalesRoute {
        val route = SalesRoute(id = java.util.UUID.randomUUID().toString(), name = name, territoryId = territoryId, assignedToEmployeeId = assignedToEmployeeId, outletIds = outletIds)
        scope.launch {
            val entity = route.toEntity()
            db.salesRouteDao().upsert(entity)
            syncCollection("salesRoutes").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push salesRoute failed", it) }
            logAudit("SalesRoute", route.id, "CREATE", newValue = route)
        }
        return route
    }

    fun assignOutletToRoute(routeId: String, retailerId: String) {
        scope.launch {
            val route = salesRoutes.value.firstOrNull { it.id == routeId } ?: return@launch
            val updated = route.copy(outletIds = route.outletIds + retailerId)
            val entity = updated.toEntity()
            db.salesRouteDao().upsert(entity)
            syncCollection("salesRoutes").document(routeId).update("outletIdsRaw", entity.outletIdsRaw)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push route-assign failed", it) }
            logAudit("SalesRoute", routeId, "UPDATE", newValue = "added outlet $retailerId")
        }
    }

    // ---- Visit History (Module 7/8/9 — Dealer/Outlet Visit History) ----
    fun recordVisitCheckIn(partyType: PartyType, partyId: String, lat: Double, lng: Double, photoUri: String? = null, purpose: String = "Routine visit"): VisitLog {
        // Module 9 — Distance Validation: flag (don't block) a check-in that's
        // far from the outlet's registered GPS — GPS drift/poor signal happens,
        // so this is logged for audit visibility rather than hard-rejected.
        val registeredLatLng = if (partyType == PartyType.RETAILER) {
            retailers.value.firstOrNull { it.id == partyId }?.let { it.lat to it.lng }
        } else null
        val annotatedPurpose = if (registeredLatLng?.first != null && registeredLatLng.second != null) {
            val withinFence = isWithinGeoFence(lat, lng, registeredLatLng.first!!, registeredLatLng.second!!)
            if (!withinFence) "$purpose ⚠ outlet-এর নিবন্ধিত অবস্থান থেকে দূরে" else purpose
        } else purpose
        val visit = VisitLog(
            id = java.util.UUID.randomUUID().toString(), partyType = partyType, partyId = partyId,
            employeeId = currentUser.employeeId, employeeName = currentUser.name, lat = lat, lng = lng,
            photoUri = photoUri, purpose = annotatedPurpose,
        )
        scope.launch {
            val entity = visit.toEntity()
            db.visitLogDao().upsert(entity)
            syncCollection("visitLogs").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push visitLog failed", it) }
            logAudit("Visit", visit.id, "CREATE", newValue = visit)
        }
        return visit
    }

    fun recordVisitCheckOut(visitId: String) {
        scope.launch {
            val now = System.currentTimeMillis()
            db.visitLogDao().setCheckOut(visitId, now)
            syncCollection("visitLogs").document(visitId).update("checkOutAtEpochMillis", now)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push visit-checkout failed", it) }
        }
    }

    // ---- POS Billing (Module 4) — walk-in sale, reuses the unified invoices table with type="POS" ----
    fun createPosSale(customerName: String, lineItems: List<SalesInvoiceLineItem>): Boolean {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.CREATE)) {
            logAudit("PosSale", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return false
        }
        scope.launch {
            val invoiceNo = "POS-${1000 + db.invoiceDao().countByType("POS") + 1}"
            val entity = InvoiceEntity(
                id = java.util.UUID.randomUUID().toString(), invoiceNo = invoiceNo, type = "POS",
                dealerId = "", dealerName = customerName.ifBlank { "Walk-in Customer" }, dealerZone = currentUser.zone,
                lineItemsRaw = Converters.packSalesInvoiceItems(lineItems), status = "PAID", // POS sales are paid at the counter, unlike dealer credit invoices
                createdBy = currentUser.name, createdAtEpochMillis = System.currentTimeMillis(),
            )
            db.invoiceDao().upsert(entity)
            syncCollection("salesInvoices").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push POS sale failed", it) }
            logAudit("PosSale", invoiceNo, "CREATE", newValue = entity)
        }
        return true
    }

    // ---- Geotagged CRM ----
    lateinit var routes: StateFlow<List<FieldEmployeeRoute>>
        private set

    /**
     * Module 9 (SFA) — Geo-Fencing / Distance Validation: haversine
     * great-circle distance in meters between two lat/lng points. Used to
     * check a field visit actually happened near the outlet's registered
     * location, rather than trusting the GPS tag blindly.
     */
    fun distanceMeters(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val earthRadiusMeters = 6_371_000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lng2 - lng1)
        val a = kotlin.math.sin(dLat / 2) * kotlin.math.sin(dLat / 2) +
            kotlin.math.cos(Math.toRadians(lat1)) * kotlin.math.cos(Math.toRadians(lat2)) *
            kotlin.math.sin(dLng / 2) * kotlin.math.sin(dLng / 2)
        val c = 2 * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1 - a))
        return earthRadiusMeters * c
    }

    /** True if a check-in point falls within radiusMeters of the outlet's registered GPS — the "Geo Fencing" / "Distance Validation" check. Returns true (never blocks) if the outlet has no registered location yet. */
    fun isWithinGeoFence(partyLat: Double?, partyLng: Double?, checkLat: Double, checkLng: Double, radiusMeters: Double = 200.0): Boolean {
        if (partyLat == null || partyLng == null) return true
        return distanceMeters(partyLat, partyLng, checkLat, checkLng) <= radiusMeters
    }

    lateinit var campaigns: StateFlow<List<EngagementCampaign>>
        private set

    fun broadcastCampaign(channel: CampaignChannel, message: String, zone: String) {
        scope.launch {
            val entity = EngagementCampaignEntity(
                id = java.util.UUID.randomUUID().toString(),
                channel = channel.name,
                message = message,
                targetZone = zone,
                sentCount = (40..200).random(),
            )
            db.engagementCampaignDao().upsert(entity)
            pushCampaign(entity)
        }
    }

    /** Appends one real GPS fix to the employee's route for today. Called every ~15s while live tracking is on. */
    fun recordGpsPing(employeeId: String, employeeName: String, lat: Double, lng: Double, spoofed: Boolean) {
        scope.launch {
            val today = LocalDate.now().toEpochDay()
            val existing = db.fieldEmployeeRouteDao().getForEmployeeAndDate(employeeId, today)
            val existingBreadcrumbs = existing?.let { Converters.unpackBreadcrumbs(it.breadcrumbsRaw) } ?: emptyList()
            // Attendance Exception — notify only on the FIRST spoofed ping of the day per employee, not every ping (PresenceHeartbeatService pings every 30-60 min; notifying each time would spam the inbox).
            if (spoofed && existingBreadcrumbs.none { it.spoofed }) {
                createNotification(NotificationCategory.ATTENDANCE, "GPS Spoofing Detected", "$employeeName — mock location detected during duty hours")
            }
            val updated = existingBreadcrumbs + GpsPing(lat, lng, LocalDateTime.now(), spoofed)
            db.fieldEmployeeRouteDao().upsertAll(
                listOf(
                    FieldEmployeeRouteEntity(
                        employeeId = employeeId,
                        employeeName = employeeName,
                        dateEpochDay = today,
                        breadcrumbsRaw = Converters.packBreadcrumbs(updated),
                    )
                )
            )
        }
    }

    /**
     * Called by PresenceHeartbeatService (background, every 30-60 min) and
     * also usable for the "Login = Auto Attendance" first-check-of-the-day
     * case. Records a breadcrumb (reusing recordGpsPing) AND marks today's
     * attendance valid if the fix falls within the employee's assigned
     * division (using the same approximate check as the login-time anomaly
     * alert) — this is what payroll's absencePenalty ultimately reads.
     */
    fun recordPresenceCheckIn(employeeId: String, employeeName: String, lat: Double, lng: Double, spoofed: Boolean) {
        recordGpsPing(employeeId, employeeName, lat, lng, spoofed)
        scope.launch {
            val division = EMPLOYEE_DIRECTORY.firstOrNull { it.id == employeeId }?.geo?.division
            val withinArea = !spoofed && !com.abm.erp.util.LocationAnomalyChecker.isAnomalous(division, lat, lng)
            val record = AttendanceRecordEntity(
                employeeId = employeeId, dateEpochDay = LocalDate.now().toEpochDay(),
                checkedIn = true, gpsValid = withinArea,
            )
            db.attendanceDao().upsert(record)
            pushAttendance(record)
        }
    }

    /**
     * The "daily absence sweep" — triggered when Payroll opens (lazy, not a
     * true midnight cron job, since exact-alarm background scheduling on
     * Android has real battery-optimization friction; this is the more
     * reliable trade-off for this stage). For each payroll line, gap-fills
     * the last 30 days: any day with no attendance record at all becomes an
     * explicit "absent" one, then unapprovedAbsenceDays is recomputed from
     * real data — this is what finally makes payroll's automatic deduction
     * (netPayable's absencePenalty) reflect actual attendance instead of
     * static seed numbers.
     */
    fun refreshPayrollAbsences() {
        scope.launch {
            val today = LocalDate.now().toEpochDay()
            val cycleStart = today - 30
            payroll.value.forEach { line ->
                for (day in cycleStart until today) {
                    if (db.attendanceDao().getForDay(line.employeeId, day) == null) {
                        val record = AttendanceRecordEntity(employeeId = line.employeeId, dateEpochDay = day, checkedIn = false, gpsValid = false)
                        db.attendanceDao().upsert(record)
                        pushAttendance(record)
                    }
                }
                val absences = db.attendanceDao().countAbsences(line.employeeId)
                db.payrollDao().updateAbsenceDays(line.employeeId, absences)
                db.payrollDao().getAll().first().firstOrNull { it.employeeId == line.employeeId }?.let { pushPayroll(it) }
            }
        }
    }

    // ---- HRM & Payroll ----
    lateinit var payroll: StateFlow<List<PayrollLine>>
        private set

    // ---- Module 12: HR & Payroll extras — Leave / Increment / Promotion / Transfer / Exit ----
    lateinit var leaveRequests: StateFlow<List<LeaveRequest>>
        private set
    lateinit var employeeLifecycleEvents: StateFlow<List<EmployeeLifecycleEvent>>
        private set

    fun applyLeave(employeeId: String, employeeName: String, type: LeaveType, fromDate: LocalDate, toDate: LocalDate, reason: String): LeaveRequest? {
        if (toDate.isBefore(fromDate)) return null
        val leave = LeaveRequest(id = java.util.UUID.randomUUID().toString(), employeeId = employeeId, employeeName = employeeName, type = type, fromDate = fromDate, toDate = toDate, reason = reason)
        scope.launch {
            val entity = leave.toEntity()
            db.leaveRequestDao().upsert(entity)
            syncCollection("leaveRequests").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push leaveRequest failed", it) }
            logAudit("LeaveRequest", leave.id, "CREATE", newValue = leave)
            createNotification(NotificationCategory.LEAVE, "Leave Applied", "${leave.employeeName}: ${leave.type} ${leave.fromDate} → ${leave.toDate}")
        }
        return leave
    }

    /** Approving/rejecting leave needs the same tier as any other approval — enforced here, not just hidden in the UI. */
    fun setLeaveStatus(id: String, status: LeaveStatus): Boolean {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) {
            logAudit("LeaveRequest", id, "DENY", oldValue = currentUser.role.name, newValue = status)
            return false
        }
        val leave = leaveRequests.value.firstOrNull { it.id == id }
        scope.launch {
            db.leaveRequestDao().setStatus(id, status.name)
            syncCollection("leaveRequests").document(id).update("status", status.name)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push leave-status failed", it) }
            logAudit("LeaveRequest", id, if (status == LeaveStatus.APPROVED) "APPROVE" else "REJECT")
            if (leave != null) createNotification(NotificationCategory.LEAVE, "Leave ${status.name}", leave.employeeName, leave.employeeId)
        }
        return true
    }

    /** Increment / Promotion / Transfer / Exit — one shared recorder, distinguished by `type`, matching EmployeeLifecycleEvent's own doc comment. Admin-tier action (same as Reset PIN / Force Logout). */
    fun recordLifecycleEvent(employeeId: String, employeeName: String, type: String, oldValue: String, newValue: String, effectiveDate: LocalDate, notes: String): Boolean {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) {
            logAudit("EmployeeLifecycleEvent", employeeId, "DENY", oldValue = currentUser.role.name, newValue = type)
            return false
        }
        val event = EmployeeLifecycleEvent(
            id = java.util.UUID.randomUUID().toString(), employeeId = employeeId, employeeName = employeeName, type = type,
            oldValue = oldValue, newValue = newValue, effectiveDate = effectiveDate, notes = notes, recordedBy = currentUser.name,
        )
        scope.launch {
            val entity = event.toEntity()
            db.employeeLifecycleEventDao().upsert(entity)
            syncCollection("employeeLifecycleEvents").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push lifecycleEvent failed", it) }
            logAudit("EmployeeLifecycleEvent", employeeName, type, oldValue = oldValue, newValue = newValue)
        }
        return true
    }

    // ---- Credit / billing / payments ----
    lateinit var invoices: StateFlow<List<VoiceInvoice>>
        private set

    fun updateInvoiceItem(invoiceId: String, index: Int, item: InvoiceLineItem) {
        scope.launch {
            val existing = db.invoiceDao().getAllVoice().first().firstOrNull { it.id == invoiceId } ?: return@launch
            val items = Converters.unpackInvoiceItems(existing.lineItemsRaw).also { it[index] = item }
            db.invoiceDao().update(existing.copy(lineItemsRaw = Converters.packInvoiceItems(items)))
        }
    }

    lateinit var payments: StateFlow<List<PaymentProof>>
        private set

    fun setPaymentStatus(id: String, status: PaymentVerificationStatus) {
        scope.launch { db.paymentProofDao().setStatus(id, status.name) }
    }

    // ---- Production ----
    lateinit var lots: StateFlow<List<RawMaterialLot>>
        private set

    fun movingAverageCost(material: String): Double {
        val matching = lots.value.filter { it.materialName == material }
        val totalQty = matching.sumOf { it.qtyKg }
        return if (totalQty == 0.0) 0.0 else matching.sumOf { it.qtyKg * it.costPerKg } / totalQty
    }

    lateinit var batches: StateFlow<List<ProductionBatch>>
        private set

    fun receiveGatepass(batchId: String) {
        scope.launch { db.productionBatchDao().receiveGatepass(batchId) }
    }

    // ================= Module 2: Manufacturing & Production extras =================

    lateinit var billOfMaterials: StateFlow<List<BillOfMaterials>>
        private set
    lateinit var productionOrders: StateFlow<List<ProductionOrder>>
        private set
    lateinit var qualityChecks: StateFlow<List<QualityCheck>>
        private set
    lateinit var productionLosses: StateFlow<List<ProductionLoss>>
        private set
    lateinit var machineLogs: StateFlow<List<MachineLog>>
        private set

    /** BOM — "to make 1 unit of X, you need these raw materials". Used by createProductionOrder to compute Production Costing (material + labor + overhead) up front, before a single unit is actually made. */
    fun createBom(finishedProductName: String, lines: List<BomLine>, laborCostPerUnit: Double, overheadCostPerUnit: Double): BillOfMaterials {
        val bom = BillOfMaterials(id = java.util.UUID.randomUUID().toString(), finishedProductName = finishedProductName, lines = lines, laborCostPerUnit = laborCostPerUnit, overheadCostPerUnit = overheadCostPerUnit)
        scope.launch {
            val entity = bom.toEntity()
            db.billOfMaterialsDao().upsert(entity)
            syncCollection("billOfMaterials").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push bom failed", it) }
            logAudit("BOM", bom.id, "CREATE", newValue = bom)
        }
        return bom
    }

    /** Estimated per-unit cost from a BOM: raw materials (using each material's moving-average cost where known, else 0) + labor + overhead. */
    fun estimatedUnitCost(bom: BillOfMaterials): Double {
        val materialCost = bom.lines.sumOf { line -> movingAverageCost(line.rawMaterialName) * line.qtyPerUnit }
        return materialCost + bom.laborCostPerUnit + bom.overheadCostPerUnit
    }

    fun createProductionOrder(bomId: String, finishedProductName: String, targetQty: Double, scheduledDate: LocalDateTime): ProductionOrder {
        val order = ProductionOrder(
            id = java.util.UUID.randomUUID().toString(), orderNo = "PRO-${(1000..9999).random()}",
            bomId = bomId, finishedProductName = finishedProductName, targetQty = targetQty,
            scheduledDate = scheduledDate, createdBy = currentUser.name,
        )
        scope.launch {
            val entity = order.toEntity()
            db.productionOrderDao().upsert(entity)
            syncCollection("productionOrders").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push productionOrder failed", it) }
            logAudit("ProductionOrder", order.orderNo, "CREATE", newValue = order)
            createNotification(NotificationCategory.PRODUCTION, "New Production Order", "${order.orderNo} — $finishedProductName × ${targetQty}")
        }
        return order
    }

    fun updateProductionOrderStatus(orderId: String, status: String) {
        scope.launch {
            db.productionOrderDao().setStatus(orderId, status)
            syncCollection("productionOrders").document(orderId).update("status", status)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push production-order-status failed", it) }
            logAudit("ProductionOrder", orderId, "UPDATE", newValue = status)
            if (status == "COMPLETED") {
                val order = productionOrders.value.firstOrNull { it.id == orderId }
                createNotification(NotificationCategory.PRODUCTION, "Production Completed", "${order?.orderNo ?: orderId} — ${order?.finishedProductName ?: ""}")
            }
        }
    }

    /** Quality Control — pass/fail check tied to a production batch. */
    fun recordQualityCheck(batchId: String, result: String, notes: String) {
        val check = QualityCheck(id = java.util.UUID.randomUUID().toString(), batchId = batchId, result = result, notes = notes, checkedBy = currentUser.name)
        scope.launch {
            val entity = check.toEntity()
            db.qualityCheckDao().upsert(entity)
            syncCollection("qualityChecks").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push qualityCheck failed", it) }
            logAudit("QualityCheck", batchId, "CREATE", newValue = "$result — $notes")
            if (result == "FAIL") {
                createNotification(NotificationCategory.QUALITY_CHECK, "Quality Check Failed", "Batch $batchId — $notes")
            }
        }
    }

    /** Production Loss Tracking — wastage recorded against a batch, separate from the batch's own output qty. */
    fun recordProductionLoss(batchId: String, qtyLost: Double, reason: String) {
        val loss = ProductionLoss(id = java.util.UUID.randomUUID().toString(), batchId = batchId, qtyLost = qtyLost, reason = reason)
        scope.launch {
            val entity = loss.toEntity()
            db.productionLossDao().upsert(entity)
            syncCollection("productionLosses").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push productionLoss failed", it) }
            logAudit("ProductionLoss", batchId, "CREATE", newValue = "$qtyLost — $reason")
        }
    }

    /** Machine Utilization — hours logged per machine, optionally tied to a batch. */
    fun recordMachineLog(machineName: String, batchId: String?, hoursUsed: Double, notes: String) {
        val log = MachineLog(id = java.util.UUID.randomUUID().toString(), machineName = machineName, batchId = batchId, hoursUsed = hoursUsed, notes = notes)
        scope.launch {
            val entity = log.toEntity()
            db.machineLogDao().upsert(entity)
            syncCollection("machineLogs").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push machineLog failed", it) }
            logAudit("MachineLog", machineName, "CREATE", newValue = "$hoursUsed hrs — $notes")
        }
    }

    /** Machine Utilization — hours-used log, optionally tied to a batch. */
    fun recordMachineUsage(machineName: String, batchId: String?, hoursUsed: Double, notes: String = "") {
        val log = MachineLog(id = java.util.UUID.randomUUID().toString(), machineName = machineName, batchId = batchId, hoursUsed = hoursUsed, notes = notes)
        scope.launch {
            val entity = log.toEntity()
            db.machineLogDao().upsert(entity)
            syncCollection("machineLogs").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push machineLog failed", it) }
        }
    }

    // ---- BI / advisory ----
    /** AI Boardroom — real, data-derived prescriptions instead of a static hardcoded list. Reuses computeRiskAlerts() (already live-computed from Dealer/Retailer/Approval/Stock data) and reshapes each RiskAlert into a PrescriptionCard, the shape BoardroomScreen already renders. If there's genuinely no risk signal right now, this returns an empty list rather than fabricating one — an honest "nothing flagged" instead of always showing 3 cards. */
    fun computePrescriptions(): List<PrescriptionCard> =
        computeRiskAlerts().map { alert -> PrescriptionCard(alert.id, alert.category, alert.message, alert.severity) }

    lateinit var boardroomHistory: StateFlow<List<BoardroomQuery>>
        private set

    // ---- Task Manager ----
    lateinit var tasks: StateFlow<List<TaskItem>>
        private set
    lateinit var deletedTasks: StateFlow<List<TaskItem>>
        private set

    fun addTask(title: String, assignee: String, parentTaskId: String? = null) {
        scope.launch {
            val entity = TaskItemEntity(id = java.util.UUID.randomUUID().toString(), title = title, assignee = assignee, done = false, createdAtEpochMillis = System.currentTimeMillis(), parentTaskId = parentTaskId)
            db.taskDao().upsert(entity)
            pushTask(entity)
            logAudit("Task", entity.id, "CREATE", newValue = entity.toDomain())
            createNotification(NotificationCategory.TASK, "Task Assigned", "$title — $assignee")
        }
    }

    /** Task & Activity Management — 4-state status; keeps `done` in sync (true only for COMPLETED) so existing checkbox UI keeps working unchanged. */
    fun setTaskStatus(id: String, status: TaskStatus) {
        scope.launch {
            db.taskDao().setStatus(id, status.name, status == TaskStatus.COMPLETED)
            syncCollection("tasks").document(id).update(mapOf("status" to status.name, "done" to (status == TaskStatus.COMPLETED)))
                .addOnFailureListener { android.util.Log.w("MockRepository", "push task-status failed", it) }
            logAudit("Task", id, "UPDATE", newValue = status)
        }
    }

    fun subTasksFor(parentTaskId: String): Flow<List<TaskItem>> =
        db.taskDao().getSubTasks(parentTaskId).map { list -> list.map { it.toDomain() } }

    fun setTaskDone(id: String, done: Boolean) {
        scope.launch {
            db.taskDao().setDone(id, done)
            syncCollection("tasks").document(id).update("done", done)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push task-done failed", it) }
        }
    }

    /** Soft delete — the record never actually leaves Room/Firestore, isDeleted just flips to true. */
    fun deleteTask(id: String) {
        scope.launch {
            val before = tasks.value.firstOrNull { it.id == id } ?: return@launch
            val now = System.currentTimeMillis()
            db.taskDao().softDelete(id, now, currentUser.name)
            syncCollection("tasks").document(id).update(mapOf("isDeleted" to true, "deletedAtEpochMillis" to now, "deletedBy" to currentUser.name))
                .addOnFailureListener { android.util.Log.w("MockRepository", "push task-delete failed", it) }
            logAudit("Task", id, "DELETE", oldValue = before)
        }
    }

    fun restoreTask(id: String) {
        scope.launch {
            db.taskDao().restore(id)
            syncCollection("tasks").document(id).update(mapOf("isDeleted" to false, "deletedAtEpochMillis" to null, "deletedBy" to null))
                .addOnFailureListener { android.util.Log.w("MockRepository", "push task-restore failed", it) }
            logAudit("Task", id, "RESTORE")
        }
    }

    // ---- Approvals ----
    lateinit var approvals: StateFlow<List<ApprovalRequest>>
        private set

    lateinit var roleDefinitions: StateFlow<List<RoleDefinition>>
        private set

    fun requestApproval(type: ApprovalType, fromEmployee: String, detail: String) {
        scope.launch {
            val entity = ApprovalRequestEntity(
                id = java.util.UUID.randomUUID().toString(), type = type.name, fromEmployee = fromEmployee,
                detail = detail, status = ApprovalStatus.PENDING.name, createdAtEpochMillis = System.currentTimeMillis(),
            )
            db.approvalDao().upsert(entity)
            pushApproval(entity)
        }
    }

    /** Returns false (and logs a DENY entry) if the current user's role isn't allowed to approve/reject — enforced here, not just hidden in the UI, so a bypassed/tampered client can't force it through. */
    fun setApprovalStatus(id: String, status: ApprovalStatus): Boolean {
        val needsApprovePermission = status == ApprovalStatus.APPROVED || status == ApprovalStatus.REJECTED
        if (needsApprovePermission && !PermissionManager.canCurrentUser("approval", PermissionAction.APPROVE)) {
            logAudit("ApprovalRequest", id, "DENY", oldValue = currentUser.role.name, newValue = status)
            return false
        }
        scope.launch {
            val before = approvals.value.firstOrNull { it.id == id }
            db.approvalDao().setStatus(id, status.name)
            syncCollection("approvals").document(id).update("status", status.name)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push approval-status failed", it) }
            val action = if (status == ApprovalStatus.APPROVED) "APPROVE" else if (status == ApprovalStatus.REJECTED) "REJECT" else "UPDATE"
            logAudit("ApprovalRequest", id, action, oldValue = before?.status, newValue = status)
        }
        return true
    }

    /**
     * Foundation Layer — Cascade Approval Engine. SO submits at level 1
     * (needs ASM); ASM approving advances it to level 2 (needs RSM); RSM
     * approving advances it to level 3 (needs GM, the final sign-off).
     * GM/MD/CHAIRMAN can short-circuit-approve at any level (matches their
     * full-access permission definition in PermissionManager). A REJECT at
     * any level is terminal — status becomes REJECTED with a reason
     * attached; the submitter sees why and can raise a fresh request to
     * try again (this build doesn't auto-resubmit a rejected request).
     */
    private val CASCADE_CHAIN = listOf(UserRole.ASM, UserRole.RSM, UserRole.GM)

    fun advanceApproval(id: String, decision: ApprovalStatus, rejectReason: String? = null): Boolean {
        if (decision != ApprovalStatus.APPROVED && decision != ApprovalStatus.REJECTED) return false
        if (!PermissionManager.canCurrentUser("approval", PermissionAction.APPROVE)) {
            logAudit("ApprovalRequest", id, "DENY", oldValue = currentUser.role.name, newValue = decision)
            return false
        }
        val request = approvals.value.firstOrNull { it.id == id } ?: return false
        val requiredTier = CASCADE_CHAIN.getOrNull(request.level - 1)
        val isOverrideRole = currentUser.role in setOf(UserRole.GM, UserRole.MD, UserRole.CHAIRMAN, UserRole.AGM)
        if (requiredTier != null && currentUser.role != requiredTier && !isOverrideRole) {
            logAudit("ApprovalRequest", id, "DENY", oldValue = "${currentUser.role} tried level ${request.level} (needs $requiredTier)", newValue = decision)
            return false
        }
        scope.launch {
            val now = System.currentTimeMillis()
            if (decision == ApprovalStatus.REJECTED) {
                db.approvalDao().setStatus(id, ApprovalStatus.REJECTED.name)
                syncCollection("approvals").document(id)
                    .update(mapOf("status" to ApprovalStatus.REJECTED.name, "approvedBy" to currentUser.name, "approvedAtEpochMillis" to now, "rejectReason" to rejectReason))
                    .addOnFailureListener { android.util.Log.w("MockRepository", "push approval-reject failed", it) }
                logAudit("ApprovalRequest", id, "REJECT", oldValue = "level ${request.level}", newValue = rejectReason ?: "no reason given")
                createNotification(NotificationCategory.APPROVAL, "Request Rejected", "${request.type} — ${request.fromEmployee}: ${rejectReason ?: "কারণ দেওয়া হয়নি"}", request.fromEmployee)
                return@launch
            }
            val isFinalLevel = isOverrideRole || request.level >= CASCADE_CHAIN.size
            if (isFinalLevel) {
                db.approvalDao().setStatus(id, ApprovalStatus.APPROVED.name)
                syncCollection("approvals").document(id)
                    .update(mapOf("status" to ApprovalStatus.APPROVED.name, "approvedBy" to currentUser.name, "approvedAtEpochMillis" to now))
                    .addOnFailureListener { android.util.Log.w("MockRepository", "push approval-final failed", it) }
                logAudit("ApprovalRequest", id, "APPROVE", oldValue = "level ${request.level} (final)", newValue = "APPROVED")
                createNotification(NotificationCategory.APPROVAL, "Request Approved", "${request.type} — ${request.fromEmployee}", request.fromEmployee)
            } else {
                val nextLevel = request.level + 1
                db.approvalDao().setLevel(id, nextLevel)
                syncCollection("approvals").document(id).update("level", nextLevel)
                    .addOnFailureListener { android.util.Log.w("MockRepository", "push approval-cascade failed", it) }
                logAudit("ApprovalRequest", id, "APPROVE", oldValue = "level ${request.level}", newValue = "advanced to level $nextLevel (${CASCADE_CHAIN.getOrNull(nextLevel - 1)})")
            }
        }
        return true
    }

    /** Escalate — jumps straight to the next tier up regardless of the normal per-level cascade (for when the assigned approver isn't responding in time). */
    fun escalateApproval(id: String): Boolean {
        if (!PermissionManager.canCurrentUser("approval", PermissionAction.APPROVE)) return false
        val request = approvals.value.firstOrNull { it.id == id } ?: return false
        val nextLevel = (request.level + 1).coerceAtMost(CASCADE_CHAIN.size)
        scope.launch {
            db.approvalDao().setLevel(id, nextLevel)
            db.approvalDao().setEscalated(id, true)
            syncCollection("approvals").document(id).update(mapOf("level" to nextLevel, "escalated" to true))
                .addOnFailureListener { android.util.Log.w("MockRepository", "push approval-escalate failed", it) }
            logAudit("ApprovalRequest", id, "UPDATE", oldValue = "level ${request.level}", newValue = "ESCALATED to level $nextLevel")
        }
        return true
    }

    /** Forward — hands this specific request to a named employee (outside the normal cascade), e.g. a specialist or a covering manager. */
    fun forwardApproval(id: String, toEmployeeId: String): Boolean {
        if (!PermissionManager.canCurrentUser("approval", PermissionAction.APPROVE)) return false
        scope.launch {
            db.approvalDao().setAssignedTo(id, toEmployeeId)
            syncCollection("approvals").document(id).update("assignedToEmployeeId", toEmployeeId)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push approval-forward failed", it) }
            logAudit("ApprovalRequest", id, "UPDATE", newValue = "FORWARDED to $toEmployeeId")
        }
        return true
    }

    /** Reassign — same mechanism as Forward, semantically "permanently hand off" rather than "temporarily loop in". */
    fun reassignApproval(id: String, toEmployeeId: String): Boolean = forwardApproval(id, toEmployeeId)

    // ---- Courier & Logistics ----
    lateinit var couriers: StateFlow<List<CourierPartner>>
        private set

    lateinit var shipments: StateFlow<List<Shipment>>
        private set

    fun bookShipment(courierId: String, dealerOrRetailer: String) {
        scope.launch {
            val hasApi = couriers.value.firstOrNull { it.id == courierId }?.hasApi ?: false
            val trackingId = if (hasApi) "${courierId.take(2).uppercase()}-${(10000..99999).random()}" else null
            val entity = ShipmentEntity(
                id = java.util.UUID.randomUUID().toString(), courierId = courierId, dealerOrRetailer = dealerOrRetailer,
                trackingId = trackingId, status = ShipmentStatus.PICKED_UP.name,
            )
            db.shipmentDao().upsert(entity)
            pushShipment(entity)
        }
    }

    private val autoAdvanceStages = listOf(ShipmentStatus.PICKED_UP, ShipmentStatus.IN_TRANSIT, ShipmentStatus.OUT_FOR_DELIVERY, ShipmentStatus.DELIVERED)

    private fun pushShipmentStatus(shipmentId: String, status: String) {
        syncCollection("shipments").document(shipmentId).update("status", status)
            .addOnFailureListener { android.util.Log.w("MockRepository", "push shipment-status failed", it) }
    }

    /** For API-connected couriers: simulate pulling the next tracking stage. Manual couriers use setShipmentStatus directly instead. */
    fun refreshShipmentStatus(shipmentId: String) {
        scope.launch {
            val current = shipments.value.firstOrNull { it.id == shipmentId } ?: return@launch
            val idx = autoAdvanceStages.indexOf(current.status)
            val next = autoAdvanceStages.getOrElse(idx + 1) { current.status }
            db.shipmentDao().setStatus(shipmentId, next.name)
            pushShipmentStatus(shipmentId, next.name)
        }
    }

    fun setShipmentStatus(shipmentId: String, status: ShipmentStatus) {
        scope.launch {
            db.shipmentDao().setStatus(shipmentId, status.name)
            pushShipmentStatus(shipmentId, status.name)
        }
    }

    // ---- Module 13: Logistics — Vehicle Tracking ----
    lateinit var vehicles: StateFlow<List<Vehicle>>
        private set
    lateinit var vehicleLocationPings: StateFlow<List<VehicleLocationPing>>
        private set

    fun createVehicle(registrationNo: String, vehicleType: String, driverName: String, driverPhone: String): Vehicle? {
        if (!PermissionManager.canCurrentUser("courier", PermissionAction.CREATE)) {
            logAudit("Vehicle", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return null
        }
        if (registrationNo.isBlank()) return null
        val vehicle = Vehicle(id = "VEH-${java.util.UUID.randomUUID().toString().take(8)}", registrationNo = registrationNo, vehicleType = vehicleType, driverName = driverName, driverPhone = driverPhone)
        scope.launch {
            val entity = vehicle.toEntity()
            db.vehicleDao().upsert(entity)
            syncCollection("vehicles").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push vehicle failed", it) }
            logAudit("Vehicle", vehicle.id, "CREATE", newValue = vehicle)
        }
        return vehicle
    }

    /** GPS ping for a vehicle in transit — same spoofing-aware shape as recordGpsPing/recordVisitCheckIn (Foundation Layer's Geo Validation), just tagged to a vehicle instead of an employee/party. */
    fun recordVehiclePing(vehicleId: String, lat: Double, lng: Double, speedKmh: Double) {
        val ping = VehicleLocationPing(id = java.util.UUID.randomUUID().toString(), vehicleId = vehicleId, lat = lat, lng = lng, speedKmh = speedKmh)
        scope.launch {
            val entity = ping.toEntity()
            db.vehicleLocationPingDao().upsert(entity)
            syncCollection("vehicleLocationPings").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("MockRepository", "push vehiclePing failed", it) }
        }
    }

    fun latestPingFor(vehicleId: String): Flow<VehicleLocationPing?> =
        db.vehicleLocationPingDao().getLatestForVehicle(vehicleId).map { it?.toDomain() }

    // ---- Accounts / Ledger (NSM+ only) ----
    lateinit var ledgerEntries: StateFlow<List<LedgerEntry>>
        private set

    fun addLedgerEntry(type: LedgerEntryType, category: String, description: String, amount: Double, recordedBy: String) {
        scope.launch {
            val division = EMPLOYEE_DIRECTORY.firstOrNull { it.id == currentUser.employeeId }?.geo?.division
            val entry = LedgerEntryEntity(
                id = java.util.UUID.randomUUID().toString(), type = type.name, category = category,
                description = description, amount = amount, recordedBy = recordedBy, division = division,
                recordedAtEpochMillis = System.currentTimeMillis(),
            )
            db.ledgerDao().upsert(entry)
            pushLedgerEntry(entry)
        }
    }

    /** "Analysis" slot — read-only insight, pattern-matched against LIVE data (real Gemini function-calling call plugs in here server-side once Blaze is on). */
    fun askAnalysis(question: String): String {
        val q = question.lowercase()
        val totalDealerSales = dealers.value.sumOf { it.salesLast90Days }
        val totalDealerDue = dealers.value.sumOf { it.dueBalance }
        val lowStock = InventoryRepository.stockLevels.value.filter { it.isLowStock }
        val ledgerIn = ledgerEntries.value.filter { it.type == LedgerEntryType.IN }.sumOf { it.amount }
        val ledgerOut = ledgerEntries.value.filter { it.type == LedgerEntryType.OUT }.sumOf { it.amount }
        val answer = when {
            "profit" in q || "margin" in q -> {
                val recentInvoices = salesInvoices.value.filter { !it.isDeleted }
                if (recentInvoices.isEmpty()) {
                    "এখনো কোনো invoice data নেই — margin বিশ্লেষণের জন্য যথেষ্ট তথ্য জমা হয়নি।"
                } else {
                    val avgDiscount = recentInvoices.map { it.dealerDiscountPct }.average()
                    val highDiscountCount = recentInvoices.count { it.dealerDiscountPct > avgDiscount + 2 }
                    "গড় dealer discount ${"%.1f".format(avgDiscount)}% (${recentInvoices.size}টা invoice জুড়ে)। ${highDiscountCount}টা invoice গড়ের চেয়ে বেশি discount দিয়েছে — এগুলোই margin-এর ওপর সবচেয়ে বেশি চাপ ফেলছে। (raw-material cost breakdown এই সিস্টেমে ট্র্যাক করা হয় না, তাই সেই অংশটা এখানে দেখানো সম্ভব না।)"
                }
            }
            "stock" in q || "shortage" in q ->
                if (lowStock.isEmpty()) "No products are currently at or below their reorder level."
                else "${lowStock.size} product(s) at or below reorder level — most urgent: ${lowStock.first().productName} at ${lowStock.first().warehouseName}."
            "due" in q || "payment" in q || "receivable" in q ->
                "Dealers owe ৳${"%,.0f".format(totalDealerDue)} against ৳${"%,.0f".format(totalDealerSales)} in 90-day sales (${"%.0f".format(if (totalDealerSales == 0.0) 0.0 else totalDealerDue / totalDealerSales * 100)}%)."
            "ledger" in q || "cash" in q || "balance" in q ->
                "Ledger balance is ৳${"%,.0f".format(ledgerIn - ledgerOut)} (in: ৳${"%,.0f".format(ledgerIn)}, out: ৳${"%,.0f".format(ledgerOut)})."
            "absence" in q || "attendance" in q ->
                "3 field officers have unapproved GPS gaps this week, concentrated in Barisal zone during afternoon shifts."
            "boost" in q || "best" in q || "zone" in q ->
                "ABM Masala Tea is growing fastest in Khulna zone (+18% vs forecast); recommend reallocating stock there and running a robocall promo."
            else ->
                "Based on current production, credit-risk, and attendance data, no critical anomalies outside the flagged prescription cards below."
        }
        recordBoardroomQuery(question, answer, "analysis")
        return answer
    }

    private data class ActionPattern(val regex: Regex, val action: String, val detail: String)
    private val ACTION_PATTERNS = listOf(
        ActionPattern(Regex("order|retailer|shop", RegexOption.IGNORE_CASE), "Log a retail order", "Would ask for retailer name, item, and amount, then submit it to Sales Chain."),
        ActionPattern(Regex("vacant|resign|leave", RegexOption.IGNORE_CASE), "Update an employee's vacancy status", "Would mark a specific employee vacant/active (Chairman-only)."),
        ActionPattern(Regex("notice|announcement", RegexOption.IGNORE_CASE), "Post a Chairman's Notice", "Would push an image/text to everyone's dashboard."),
    )

    /** "Assistant" slot — detects an action intent; real execution needs Firebase Blaze + Cloud Functions (this stays a preview until then). */
    fun askAssistant(question: String): String {
        val matched = ACTION_PATTERNS.firstOrNull { it.regex.containsMatchIn(question) }
        val answer = if (matched != null) {
            "🔧 Recognized: ${matched.action}. ${matched.detail}\n\n(Demo — real execution needs Firebase Blaze + Cloud Functions; once that's on, this same screen will complete the action directly.)"
        } else {
            "That sounds like an open-ended question rather than a specific action — real AI reasoning needs Firebase Blaze. Right now only pattern-recognized actions (order/vacancy/notice) can be demoed."
        }
        recordBoardroomQuery(question, answer, "assistant")
        return answer
    }

    private fun recordBoardroomQuery(question: String, answer: String, mode: String) {
        scope.launch {
            db.boardroomQueryDao().insert(
                BoardroomQueryEntity(question = question, answer = answer, mode = mode, askedAtEpochMillis = System.currentTimeMillis())
            )
        }
    }

    // ================= internal wiring =================

    private fun wireFlows() {
        orders = db.retailOrderDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        dealers = db.dealerDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        routes = db.fieldEmployeeRouteDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        campaigns = db.engagementCampaignDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        payroll = db.payrollDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        invoices = db.invoiceDao().getAllVoice().map { list -> list.map { it.toVoiceDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        payments = db.paymentProofDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        lots = db.rawMaterialLotDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        batches = db.productionBatchDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        boardroomHistory = db.boardroomQueryDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        tasks = db.taskDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        deletedTasks = db.taskDao().getDeleted().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        approvals = db.approvalDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        couriers = db.courierDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        shipments = db.shipmentDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        ledgerEntries = db.ledgerDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        salesInvoices = db.invoiceDao().getAllSales().map { list -> list.map { it.toSalesDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        roleDefinitions = db.roleDefinitionDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        scope.launch { roleDefinitions.collect { PermissionManager.updateFromSynced(it) } }

        retailers = db.retailerDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        quotations = db.quotationDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        deliveryChallans = db.deliveryChallanDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        salesReturns = db.salesReturnDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        partyCollections = db.partyCollectionDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        discountRules = db.discountRuleDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        salesRoutes = db.salesRouteDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        visitLogs = db.visitLogDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        billOfMaterials = db.billOfMaterialsDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        productionOrders = db.productionOrderDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        qualityChecks = db.qualityCheckDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        productionLosses = db.productionLossDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        machineLogs = db.machineLogDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        leaveRequests = db.leaveRequestDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        employeeLifecycleEvents = db.employeeLifecycleEventDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        vehicles = db.vehicleDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        vehicleLocationPings = db.vehicleLocationPingDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        notifications = db.notificationEntryDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
    }

    /** Inserts the same starter data the old in-memory version shipped with, but only once, on first run (empty DB). */
    private fun seedIfEmpty() = runBlocking(Dispatchers.IO) {
        if (db.retailOrderDao().count() == 0) {
            db.retailOrderDao().upsertAll(
                listOf(
                    RetailOrder(id = "seed-ord-101", orderNo = "ORD-101", retailerName = "Green Valley Store", loggedBySoId = "SO-1", zone = "Barishal", items = "ABM Masala Tea x40 ctn", amount = 48000.0).toEntity(),
                    RetailOrder(id = "seed-ord-102", orderNo = "ORD-102", retailerName = "City Corner Shop", loggedBySoId = "SO-2", zone = "Khulna", items = "ABM Tea Classic x25 ctn", amount = 31250.0, stage = OrderStage.ASM_VERIFIED).toEntity(),
                    RetailOrder(id = "seed-ord-103", orderNo = "ORD-103", retailerName = "New Bazar Traders", loggedBySoId = "SO-1", zone = "Barishal", items = "ABM Masala Tea x60 ctn", amount = 72000.0, stage = OrderStage.DEALER_ROUTED, routedDealerId = "D-1").toEntity(),
                )
            )
        }
        if (db.dealerDao().count() == 0) {
            db.dealerDao().upsertAll(
                listOf(
                    DealerEntity("D-1", "Barisal Central Dealer", "Barishal", 185000.0, 620000.0, "1111", 500),
                    DealerEntity("D-2", "Khulna Wholesale Hub", "Khulna", 42000.0, 410000.0, "2222", 300),
                    DealerEntity("D-3", "Rajshahi Distributors", "Rajshahi", 305000.0, 260000.0, "3333", 400),
                )
            )
        }
        if (db.fieldEmployeeRouteDao().count() == 0) {
            val breadcrumbs = listOf(
                GpsPing(22.701, 90.353, LocalDateTime.now().minusHours(4)),
                GpsPing(22.706, 90.360, LocalDateTime.now().minusHours(3)),
                GpsPing(22.712, 90.368, LocalDateTime.now().minusHours(1)),
            )
            db.fieldEmployeeRouteDao().upsertAll(
                listOf(
                    FieldEmployeeRouteEntity(
                        employeeId = "SO-1",
                        employeeName = "Sales Officer Rafiq",
                        dateEpochDay = LocalDate.now().toEpochDay(),
                        breadcrumbsRaw = Converters.packBreadcrumbs(breadcrumbs),
                    )
                )
            )
        }
        if (db.payrollDao().count() == 0) {
            db.payrollDao().upsertAll(
                listOf(
                    PayrollLineEntity("SO-1", "Sales Officer Rafiq", 22000.0, 500000.0, 460000.0, 0.015, 1, 733.0),
                    PayrollLineEntity("SO-2", "Sales Officer Nadia", 22000.0, 500000.0, 610000.0, 0.015, 0, 733.0),
                    PayrollLineEntity("ASM-1", "Area Manager Kabir", 38000.0, 1500000.0, 1290000.0, 0.01, 2, 1266.0),
                )
            )
        }
        if (db.invoiceDao().countByType("VOICE") == 0) {
            db.invoiceDao().upsertAll(
                listOf(
                    InvoiceEntity(
                        id = "INV-VB-01",
                        type = "VOICE",
                        dealerId = "D-1",
                        lineItemsRaw = Converters.packInvoiceItems(listOf(InvoiceLineItem("ABM Masala Tea 1kg", 50.0, "kg", 420.0, 5.0))),
                        previousDue = 185000.0,
                    )
                )
            )
        }
        if (db.paymentProofDao().count() == 0) {
            db.paymentProofDao().upsertAll(listOf(PaymentProofEntity("PMT-1", "D-2", 60000.0, "TXN-88213-BKASH", PaymentVerificationStatus.PENDING_VERIFICATION.name)))
        }
        if (db.rawMaterialLotDao().count() == 0) {
            db.rawMaterialLotDao().upsertAll(
                listOf(
                    RawMaterialLotEntity("RM-1", "Raw Leaves", 500.0, 210.0, LocalDate.now().minusDays(3).toEpochDay()),
                    RawMaterialLotEntity("RM-2", "Raw Leaves", 300.0, 225.0, LocalDate.now().minusDays(1).toEpochDay()),
                    RawMaterialLotEntity("RM-3", "CMC Thickener", 80.0, 340.0, LocalDate.now().minusDays(2).toEpochDay()),
                )
            )
        }
        if (db.productionBatchDao().count() == 0) {
            db.productionBatchDao().upsertAll(
                listOf(
                    ProductionBatchEntity("BATCH-77", "Spray Dryer 30kg", 30.0, 24.5, false),
                    ProductionBatchEntity("BATCH-78", "Drum Dryer 30kg", 30.0, 26.1, true),
                )
            )
        }
        if (db.courierDao().count() == 0) {
            db.courierDao().upsertAll(
                listOf(
                    CourierPartnerEntity("CR-1", "Pathao Courier", true),
                    CourierPartnerEntity("CR-2", "Sundarban Courier", true),
                    CourierPartnerEntity("CR-3", "Local Van Service", false),
                )
            )
        }
        if (db.approvalDao().count() == 0) {
            db.approvalDao().upsert(
                ApprovalRequestEntity(
                    id = "APR-1", type = ApprovalType.DISCOUNT.name, fromEmployee = "SR — Rafiq Hasan",
                    detail = "8% discount for New Bazar Traders (target: 6%)", status = ApprovalStatus.PENDING.name,
                    createdAtEpochMillis = System.currentTimeMillis(),
                )
            )
        }
        if (db.ledgerDao().count() == 0) {
            val now = System.currentTimeMillis()
            db.ledgerDao().upsert(LedgerEntryEntity("LEDGER-1", LedgerEntryType.IN.name, "Dealer Payment", "Barisal Central Dealer — invoice settlement", 480_000.0, "Accounts", null, now - 86_400_000L))
            db.ledgerDao().upsert(LedgerEntryEntity("LEDGER-2", LedgerEntryType.OUT.name, "Raw Material Purchase", "Tea leaf — 2 tonnes", 620_000.0, "Production", null, now - 3 * 86_400_000L))
            db.ledgerDao().upsert(LedgerEntryEntity("LEDGER-3", LedgerEntryType.OUT.name, "Payroll", "Monthly payroll — field staff", 1_450_000.0, "HR", null, now - 5 * 86_400_000L))
            db.ledgerDao().upsert(LedgerEntryEntity("LEDGER-4", LedgerEntryType.IN.name, "Dealer Payment", "Khulna Wholesale Hub — partial settlement", 310_000.0, "Accounts", null, now - 6 * 86_400_000L))
            db.ledgerDao().upsert(LedgerEntryEntity("LEDGER-5", LedgerEntryType.OUT.name, "Utility Bill", "Factory electricity — July", 95_000.0, "Production", null, now - 8 * 86_400_000L))
        }
        if (db.roleDefinitionDao().getAll().first().isEmpty()) {
            val defaults = PermissionManager.defaultDefinitionsForSeeding().map { it.toEntity() }
            db.roleDefinitionDao().upsertAll(defaults)
            PermissionManager.updateFromSynced(defaults.map { it.toDomain() })
        }
    }
}

// ================= Entity <-> domain mappers =================

private fun RetailOrder.toEntity() = RetailOrderEntity(
    id = id, orderNo = orderNo, retailerName = retailerName, loggedBySoId = loggedBySoId, zone = zone, items = items,
    amount = amount, stage = stage.name, routedDealerId = routedDealerId,
    loggedAtEpochMillis = loggedAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    retailerPhotoUri = retailerPhotoUri, retailerLat = retailerLat, retailerLng = retailerLng, retailerQrCode = retailerQrCode,
    channel = channel, anonymous = anonymous, photoPurpose = photoPurpose, retailerId = retailerId,
)

private fun RetailOrderEntity.toDomain() = RetailOrder(
    id = id, orderNo = orderNo, retailerName = retailerName, loggedBySoId = loggedBySoId, zone = zone, items = items,
    amount = amount, stage = OrderStage.valueOf(stage), routedDealerId = routedDealerId,
    loggedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(loggedAtEpochMillis), ZoneOffset.UTC),
    retailerPhotoUri = retailerPhotoUri, retailerLat = retailerLat, retailerLng = retailerLng, retailerQrCode = retailerQrCode,
    channel = channel, anonymous = anonymous, photoPurpose = photoPurpose, retailerId = retailerId,
)

private fun DealerEntity.toDomain() = Dealer(
    id = id, name = name, zone = zone, dueBalance = dueBalance, salesLast90Days = salesLast90Days, pin = pin, stockUnits = stockUnits,
    phone = phone, address = address, territoryId = territoryId, dedupKey = dedupKey, isActive = isActive, isDeleted = isDeleted,
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    deletedAt = deletedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) }, deletedBy = deletedBy,
    classification = classification, creditLimit = creditLimit,
)

private fun Dealer.toEntity() = DealerEntity(
    id = id, name = name, zone = zone, dueBalance = dueBalance, salesLast90Days = salesLast90Days, pin = pin, stockUnits = stockUnits,
    phone = phone, address = address, territoryId = territoryId, dedupKey = dedupKey, isActive = isActive, isDeleted = isDeleted,
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    deletedAtEpochMillis = deletedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(), deletedBy = deletedBy,
    classification = classification, creditLimit = creditLimit,
)

private fun Retailer.toEntity() = RetailerEntity(
    id = id, name = name, phone = phone, address = address, territoryId = territoryId, dealerId = dealerId,
    lat = lat, lng = lng, photoUri = photoUri, qrCode = qrCode, dedupKey = dedupKey, isActive = isActive, isDeleted = isDeleted,
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    deletedAtEpochMillis = deletedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(), deletedBy = deletedBy,
    dueBalance = dueBalance, creditLimit = creditLimit, outletCategory = outletCategory, outletType = outletType, routeId = routeId,
)

private fun RetailerEntity.toDomain() = Retailer(
    id = id, name = name, phone = phone, address = address, territoryId = territoryId, dealerId = dealerId,
    lat = lat, lng = lng, photoUri = photoUri, qrCode = qrCode, dedupKey = dedupKey, isActive = isActive, isDeleted = isDeleted,
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    deletedAt = deletedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) }, deletedBy = deletedBy,
    dueBalance = dueBalance, creditLimit = creditLimit, outletCategory = outletCategory, outletType = outletType, routeId = routeId,
)

private fun Territory.toEntity() = TerritoryEntity(
    id = id, division = division, district = district, market = market, parentTerritoryId = parentTerritoryId, zoneName = zoneName,
    country = country, upazila = upazila, area = area, beat = beat,
)

private fun TerritoryEntity.toDomain() = Territory(
    id = id, division = division, district = district, market = market, parentTerritoryId = parentTerritoryId, zoneName = zoneName,
    country = country, upazila = upazila, area = area, beat = beat,
)

private fun RoleDefinition.toEntity() = com.abm.erp.data.room.RoleDefinitionEntity(
    role = roleKey, label = label, modulePermissionsRaw = Converters.packModulePermissions(modulePermissions),
)

private fun com.abm.erp.data.room.RoleDefinitionEntity.toDomain() = RoleDefinition(
    roleKey = role, label = label, modulePermissions = Converters.unpackModulePermissions(modulePermissionsRaw),
)

private fun FieldEmployeeRouteEntity.toDomain() = FieldEmployeeRoute(
    employeeId = employeeId, employeeName = employeeName,
    date = LocalDate.ofEpochDay(dateEpochDay),
    breadcrumbs = Converters.unpackBreadcrumbs(breadcrumbsRaw),
)

private fun EngagementCampaignEntity.toDomain() = EngagementCampaign(
    id = id, channel = CampaignChannel.valueOf(channel), message = message, targetZone = targetZone, sentCount = sentCount,
)

private fun PayrollLineEntity.toDomain() = PayrollLine(
    employeeId = employeeId, employeeName = employeeName, basePay = basePay, targetAmount = targetAmount,
    achievedAmount = achievedAmount, commissionRate = commissionRate, unapprovedAbsenceDays = unapprovedAbsenceDays,
    dailyWage = dailyWage,
)

private fun InvoiceEntity.toVoiceDomain() = VoiceInvoice(
    id = id, dealerId = dealerId, items = Converters.unpackInvoiceItems(lineItemsRaw), previousDue = previousDue,
)

private fun PaymentProofEntity.toDomain() = PaymentProof(
    id = id, dealerId = dealerId, amount = amount, proofRef = proofRef,
    status = PaymentVerificationStatus.valueOf(status),
)

private fun RawMaterialLotEntity.toDomain() = RawMaterialLot(
    id = id, materialName = materialName, qtyKg = qtyKg, costPerKg = costPerKg,
    purchasedOn = LocalDate.ofEpochDay(purchasedOnEpochDay),
)

private fun ProductionBatchEntity.toDomain() = ProductionBatch(
    id = id, cycleType = cycleType, inputKg = inputKg, outputKg = outputKg, gatepassReceived = gatepassReceived,
)

private fun BoardroomQueryEntity.toDomain() = BoardroomQuery(
    question = question, answer = answer, mode = mode,
    askedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(askedAtEpochMillis), ZoneOffset.UTC),
)

private fun TaskItemEntity.toDomain() = TaskItem(
    id = id, title = title, assignee = assignee, done = done,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
    isDeleted = isDeleted,
    deletedAt = deletedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    deletedBy = deletedBy,
    status = runCatching { TaskStatus.valueOf(status) }.getOrDefault(TaskStatus.PENDING),
    parentTaskId = parentTaskId,
)

private fun ApprovalRequestEntity.toDomain() = ApprovalRequest(
    id = id, type = ApprovalType.valueOf(type), fromEmployee = fromEmployee, detail = detail,
    status = ApprovalStatus.valueOf(status),
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
    entityType = entityType, entityId = entityId, level = level, approvedBy = approvedBy,
    approvedAt = approvedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    rejectReason = rejectReason, assignedToEmployeeId = assignedToEmployeeId, escalated = escalated,
)

private fun CourierPartnerEntity.toDomain() = CourierPartner(id = id, name = name, hasApi = hasApi)

private fun ShipmentEntity.toDomain() = Shipment(
    id = id, courierId = courierId, dealerOrRetailer = dealerOrRetailer, trackingId = trackingId,
    status = ShipmentStatus.valueOf(status),
)

private fun LedgerEntryEntity.toDomain() = LedgerEntry(
    id = id, type = LedgerEntryType.valueOf(type), category = category, description = description,
    amount = amount, recordedBy = recordedBy, division = division,
    recordedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(recordedAtEpochMillis), ZoneOffset.UTC),
)

private fun InvoiceEntity.toSalesDomain() = SalesInvoice(
    id = id, invoiceNo = invoiceNo, dealerId = dealerId, dealerName = dealerName, dealerZone = dealerZone,
    lineItems = Converters.unpackSalesInvoiceItems(lineItemsRaw), dealerDiscountPct = dealerDiscountPct,
    commissionPct = commissionPct, courier = courier, signedByRole = signedByRole, createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
    status = status, isDeleted = isDeleted,
    deletedAt = deletedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) }, deletedBy = deletedBy,
)

/**
 * Rejects easily-guessable 5-digit PINs — repeated digits (11111, 00000) and
 * straight ascending/descending runs (12345, 54321). Used wherever a PIN gets
 * SET (Forgot-PIN's new-PIN step, Admin's Reset PIN) — not on ordinary login,
 * since that's just checking whatever PIN already exists.
 */
fun isWeakPin(pin: String): Boolean {
    if (!pin.matches(Regex("^\\d{5}$"))) return true
    if (pin.toSet().size == 1) return true // 11111, 00000, ইত্যাদি
    val ascending = "0123456789"
    val descending = "9876543210"
    if (ascending.contains(pin) || descending.contains(pin)) return true // 12345, 54321, ইত্যাদি
    return false
}

// ================= Module 4/7/8 mappers =================

private fun Quotation.toEntity() = QuotationEntity(
    id = id, quotationNo = quotationNo, partyType = partyType.name, partyId = partyId, partyName = partyName,
    lineItemsRaw = Converters.packSalesInvoiceItems(lineItems), validUntilEpochMillis = validUntil.toInstant(ZoneOffset.UTC).toEpochMilli(),
    status = status, convertedInvoiceId = convertedInvoiceId, createdBy = createdBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

private fun QuotationEntity.toDomain() = Quotation(
    id = id, quotationNo = quotationNo, partyType = PartyType.valueOf(partyType), partyId = partyId, partyName = partyName,
    lineItems = Converters.unpackSalesInvoiceItems(lineItemsRaw),
    validUntil = LocalDateTime.ofInstant(Instant.ofEpochMilli(validUntilEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    status = status, convertedInvoiceId = convertedInvoiceId, createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC), isDeleted = isDeleted,
)

private fun DeliveryChallan.toEntity() = DeliveryChallanEntity(
    id = id, challanNo = challanNo, invoiceId = invoiceId, partyType = partyType.name, partyId = partyId, partyName = partyName,
    lineItemsRaw = Converters.packSalesInvoiceItems(lineItems), vehicleNo = vehicleNo, driverName = driverName,
    deliveredBy = deliveredBy, status = status, createdBy = createdBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

private fun DeliveryChallanEntity.toDomain() = DeliveryChallan(
    id = id, challanNo = challanNo, invoiceId = invoiceId, partyType = PartyType.valueOf(partyType), partyId = partyId, partyName = partyName,
    lineItems = Converters.unpackSalesInvoiceItems(lineItemsRaw), vehicleNo = vehicleNo, driverName = driverName,
    deliveredBy = deliveredBy, status = status, createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC), isDeleted = isDeleted,
)

private fun SalesReturn.toEntity() = SalesReturnEntity(
    id = id, returnNo = returnNo, invoiceId = invoiceId, partyType = partyType.name, partyId = partyId, partyName = partyName,
    lineItemsRaw = Converters.packSalesInvoiceItems(lineItems), reason = reason, refundAmount = refundAmount,
    status = status, createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

private fun SalesReturnEntity.toDomain() = SalesReturn(
    id = id, returnNo = returnNo, invoiceId = invoiceId, partyType = PartyType.valueOf(partyType), partyId = partyId, partyName = partyName,
    lineItems = Converters.unpackSalesInvoiceItems(lineItemsRaw), reason = reason, refundAmount = refundAmount,
    status = status, createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC), isDeleted = isDeleted,
)

private fun PartyLedgerEntryEntity.toDomain() = PartyLedgerEntry(
    id = id, partyType = PartyType.valueOf(partyType), partyId = partyId, type = type, amount = amount,
    reason = reason, referenceId = referenceId, balanceAfter = balanceAfter,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
)

private fun PartyCollection.toEntity() = PartyCollectionEntity(
    id = id, partyType = partyType.name, partyId = partyId, partyName = partyName, amount = amount, method = method,
    proofUri = proofUri, status = status, collectedBy = collectedBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), verifiedBy = verifiedBy,
    verifiedAtEpochMillis = verifiedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
)

private fun PartyCollectionEntity.toDomain() = PartyCollection(
    id = id, partyType = PartyType.valueOf(partyType), partyId = partyId, partyName = partyName, amount = amount, method = method,
    proofUri = proofUri, status = status, collectedBy = collectedBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC), verifiedBy = verifiedBy,
    verifiedAt = verifiedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
)

private fun DiscountRule.toEntity() = DiscountRuleEntity(
    id = id, label = label, scope = scope, minQty = minQty, discountPct = discountPct, isActive = isActive,
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun DiscountRuleEntity.toDomain() = DiscountRule(
    id = id, label = label, scope = scope, minQty = minQty, discountPct = discountPct, isActive = isActive,
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
)

private fun SalesRoute.toEntity() = SalesRouteEntity(
    id = id, name = name, territoryId = territoryId, assignedToEmployeeId = assignedToEmployeeId,
    outletIdsRaw = outletIds.joinToString(","), isActive = isActive,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun SalesRouteEntity.toDomain() = SalesRoute(
    id = id, name = name, territoryId = territoryId, assignedToEmployeeId = assignedToEmployeeId,
    outletIds = outletIdsRaw.split(",").filter { it.isNotBlank() }, isActive = isActive,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

private fun VisitLog.toEntity() = VisitLogEntity(
    id = id, partyType = partyType.name, partyId = partyId, employeeId = employeeId, employeeName = employeeName,
    lat = lat, lng = lng, photoUri = photoUri, purpose = purpose,
    checkInAtEpochMillis = checkInAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    checkOutAtEpochMillis = checkOutAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
)

private fun VisitLogEntity.toDomain() = VisitLog(
    id = id, partyType = PartyType.valueOf(partyType), partyId = partyId, employeeId = employeeId, employeeName = employeeName,
    lat = lat, lng = lng, photoUri = photoUri, purpose = purpose,
    checkInAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(checkInAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    checkOutAt = checkOutAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
)

// ================= Module 2 Production mappers =================

private fun packBomLines(lines: List<BomLine>): String = lines.joinToString(";") { "${it.rawMaterialName},${it.qtyPerUnit},${it.unit}" }
private fun unpackBomLines(raw: String): List<BomLine> {
    if (raw.isBlank()) return emptyList()
    return raw.split(";").filter { it.isNotBlank() }.map { val p = it.split(","); BomLine(p[0], p[1].toDouble(), p[2]) }
}

private fun BillOfMaterials.toEntity() = com.abm.erp.data.room.BillOfMaterialsEntity(
    id = id, finishedProductName = finishedProductName, linesRaw = packBomLines(lines),
    laborCostPerUnit = laborCostPerUnit, overheadCostPerUnit = overheadCostPerUnit, isActive = isActive,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun com.abm.erp.data.room.BillOfMaterialsEntity.toDomain() = BillOfMaterials(
    id = id, finishedProductName = finishedProductName, lines = unpackBomLines(linesRaw),
    laborCostPerUnit = laborCostPerUnit, overheadCostPerUnit = overheadCostPerUnit, isActive = isActive,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

private fun ProductionOrder.toEntity() = com.abm.erp.data.room.ProductionOrderEntity(
    id = id, orderNo = orderNo, bomId = bomId, finishedProductName = finishedProductName, targetQty = targetQty,
    status = status, scheduledDateEpochMillis = scheduledDate.toInstant(ZoneOffset.UTC).toEpochMilli(),
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun com.abm.erp.data.room.ProductionOrderEntity.toDomain() = ProductionOrder(
    id = id, orderNo = orderNo, bomId = bomId, finishedProductName = finishedProductName, targetQty = targetQty,
    status = status, scheduledDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(scheduledDateEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
)

private fun QualityCheck.toEntity() = com.abm.erp.data.room.QualityCheckEntity(
    id = id, batchId = batchId, result = result, notes = notes, checkedBy = checkedBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun com.abm.erp.data.room.QualityCheckEntity.toDomain() = QualityCheck(
    id = id, batchId = batchId, result = result, notes = notes, checkedBy = checkedBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
)

private fun ProductionLoss.toEntity() = com.abm.erp.data.room.ProductionLossEntity(
    id = id, batchId = batchId, qtyLost = qtyLost, reason = reason,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun com.abm.erp.data.room.ProductionLossEntity.toDomain() = ProductionLoss(
    id = id, batchId = batchId, qtyLost = qtyLost, reason = reason,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
)

private fun MachineLog.toEntity() = com.abm.erp.data.room.MachineLogEntity(
    id = id, machineName = machineName, batchId = batchId, hoursUsed = hoursUsed, notes = notes,
    recordedAtEpochMillis = recordedAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun com.abm.erp.data.room.MachineLogEntity.toDomain() = MachineLog(
    id = id, machineName = machineName, batchId = batchId, hoursUsed = hoursUsed, notes = notes,
    recordedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(recordedAtEpochMillis), ZoneOffset.UTC),
)

// ================= Module 12 HR extras mappers =================

private fun LeaveRequest.toEntity() = com.abm.erp.data.room.LeaveRequestEntity(
    id = id, employeeId = employeeId, employeeName = employeeName, type = type.name,
    fromDateEpochDay = fromDate.toEpochDay(), toDateEpochDay = toDate.toEpochDay(), reason = reason,
    status = status.name, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun com.abm.erp.data.room.LeaveRequestEntity.toDomain() = LeaveRequest(
    id = id, employeeId = employeeId, employeeName = employeeName, type = LeaveType.valueOf(type),
    fromDate = LocalDate.ofEpochDay(fromDateEpochDay), toDate = LocalDate.ofEpochDay(toDateEpochDay), reason = reason,
    status = LeaveStatus.valueOf(status), createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

private fun EmployeeLifecycleEvent.toEntity() = com.abm.erp.data.room.EmployeeLifecycleEventEntity(
    id = id, employeeId = employeeId, employeeName = employeeName, type = type, oldValue = oldValue, newValue = newValue,
    effectiveDateEpochDay = effectiveDate.toEpochDay(), notes = notes, recordedBy = recordedBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun com.abm.erp.data.room.EmployeeLifecycleEventEntity.toDomain() = EmployeeLifecycleEvent(
    id = id, employeeId = employeeId, employeeName = employeeName, type = type, oldValue = oldValue, newValue = newValue,
    effectiveDate = LocalDate.ofEpochDay(effectiveDateEpochDay), notes = notes, recordedBy = recordedBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

// ================= Module 13 Vehicle Tracking mappers =================

private fun Vehicle.toEntity() = com.abm.erp.data.room.VehicleEntity(
    id = id, registrationNo = registrationNo, vehicleType = vehicleType, driverName = driverName, driverPhone = driverPhone,
    isActive = isActive, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun com.abm.erp.data.room.VehicleEntity.toDomain() = Vehicle(
    id = id, registrationNo = registrationNo, vehicleType = vehicleType, driverName = driverName, driverPhone = driverPhone,
    isActive = isActive, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

private fun VehicleLocationPing.toEntity() = com.abm.erp.data.room.VehicleLocationPingEntity(
    id = id, vehicleId = vehicleId, lat = lat, lng = lng, speedKmh = speedKmh,
    recordedAtEpochMillis = recordedAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun com.abm.erp.data.room.VehicleLocationPingEntity.toDomain() = VehicleLocationPing(
    id = id, vehicleId = vehicleId, lat = lat, lng = lng, speedKmh = speedKmh,
    recordedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(recordedAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

// ================= Universal Attachment mapper =================

private fun Attachment.toEntity() = com.abm.erp.data.room.AttachmentEntity(
    id = id, moduleReference = moduleReference, entityId = entityId, type = type.name, uri = uri,
    lat = lat, lng = lng, uploadedBy = uploadedBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun com.abm.erp.data.room.AttachmentEntity.toDomain() = Attachment(
    id = id, moduleReference = moduleReference, entityId = entityId, type = AttachmentType.valueOf(type), uri = uri,
    lat = lat, lng = lng, uploadedBy = uploadedBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

private fun com.abm.erp.data.room.AuditLogEntity.toDomain() = AuditLogEntry(
    id = id, entityType = entityType, entityId = entityId, action = action, performedBy = performedBy, performedByRole = performedByRole,
    oldValueJson = oldValueJson, newValueJson = newValueJson,
    timestamp = LocalDateTime.ofInstant(Instant.ofEpochMilli(timestampEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

private fun com.abm.erp.data.room.NotificationEntryEntity.toDomain() = NotificationEntry(
    id = id, category = runCatching { NotificationCategory.valueOf(category) }.getOrDefault(NotificationCategory.APPROVAL),
    title = title, body = body, targetEmployeeId = targetEmployeeId, isRead = isRead,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)
