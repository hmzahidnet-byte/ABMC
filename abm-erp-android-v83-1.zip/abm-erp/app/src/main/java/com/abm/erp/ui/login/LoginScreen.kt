package com.abm.erp.ui.login

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.abm.erp.data.EMPLOYEE_DIRECTORY
import com.abm.erp.data.Employee
import com.abm.erp.data.DIVISION_DISTRICTS
import com.abm.erp.data.ZONES
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.MockRepository
import com.abm.erp.data.getLastLoggedInEmployee
import com.abm.erp.data.getOrCreateDeviceId
import com.abm.erp.data.getSavedCompanyCode
import com.abm.erp.data.getSavedLanguage
import com.abm.erp.data.isWeakPin
import com.abm.erp.data.saveCompanyCode
import com.abm.erp.data.saveLanguage
import com.abm.erp.data.saveLastLoggedInEmployee
import com.abm.erp.theme.*
import com.abm.erp.util.LocationAnomalyChecker
import com.abm.erp.util.NetworkStatus
import com.abm.erp.util.tryGetLoginLocation
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
private enum class LoginStatus { Idle, Checking, Error, Success }

/** Best-effort single GPS fix for the login-time anomaly/geo-block check. Returns null on any failure — this must never block login. Now in NetworkStatus.kt (shared with DealerLoginScreen). */

// এই ডিভাইসে সর্বশেষ কে PIN দিয়ে লগইন করেছিল, সেটা স্থানীয়ভাবে (শুধু এই
// ফোনে) মনে রাখার জন্য — biometric/fingerprint unlock তখন শুধু সেই একই
// মানুষকেই ফিরিয়ে আনবে, অন্য কাউকে (যেমন Chairman) না। এটাই সঠিক এবং
// নিরাপদ পদ্ধতি, যেভাবে ব্যাংকিং অ্যাপগুলোও fingerprint ব্যবহার করে —
// fingerprint কখনো "কে" যাচাই করে না, শুধু "এই ফোনে আগে থেকে save করা
// পরিচয়টাই কি নিশ্চিত হলো" তা যাচাই করে। (helper ফাংশনগুলো এখন
// SessionPrefs.kt-এ — ABMApplication-ও company code পড়তে পারার জন্য।)

private val STRICT_ROLES = setOf("CHAIRMAN", "MD")

/**
 * Entry point before the main app. Two paths in, matching the design phase:
 * 1. 5-digit PIN checked against MockRepository.demoAccounts.
 * 2. Real device fingerprint/Face unlock via BiometricPrompt, which needs
 *    the FragmentActivity host passed in from MainActivity.
 *
 * Also matches the design phase's security additions: 3 wrong PIN attempts
 * locks this device (only the Chairman's PIN unlocks it), and a simulated
 * Forgot-PIN → OTP → new-PIN flow. No demo PINs are shown on screen anymore —
 * showing credentials on a real login screen is a security anti-pattern.
 *
 * On success, calls MockRepository.completeLogin(user) then onLoginSuccess(),
 * which flips MainActivity over to the real dashboard.
 */
@Composable
fun LoginScreen(activity: FragmentActivity, onLoginSuccess: () -> Unit, onDealerLoginRequested: () -> Unit = {}) {
    val deviceId = remember { getOrCreateDeviceId(activity) }

    // Multi-tenant: প্রথম ব্যবহারে Company Code চাইবে, তারপর মনে রাখবে —
    // "intro" (animated brand reveal, ~3.8s) then "pin" (the actual login UI).
    var phase by remember { mutableStateOf(if (getSavedCompanyCode(activity) == null) "companyCode" else "intro") }
    var lang by remember { mutableStateOf(getSavedLanguage(activity)) }
    fun t(bn: String, en: String) = if (lang == "bn") bn else en
    var companyCodeInput by remember { mutableStateOf("") }
    var companyCodeError by remember { mutableStateOf<String?>(null) }

    var pin by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(LoginStatus.Idle) }
    var biometricError by remember { mutableStateOf<String?>(null) }
    val shakeOffset = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    val demoAccounts by MockRepository.demoAccountsFlow.collectAsState()

    // ---- Designation + Area নির্বাচন (PIN দেওয়ার আগে) — blind PIN lookup-এর
    // বদলে, মানুষ নিজেই বলে দেয় "আমি কে, কোথায়" — PIN তখন শুধু সেটা
    // নিশ্চিত করে, খুঁজে বের করে না। JSX prototype-এর সাথে হুবহু মিলিয়ে। ----
    val DESIGNATIONS = listOf("SR", "TSM", "ASM", "RSM", "DSM", "NSM", "AGM", "GM", "MD", "Chairman")
    var selectedDesignation by remember { mutableStateOf<String?>(null) }
    var selectedDivision by remember { mutableStateOf<String?>(null) }
    var selectedDistrict by remember { mutableStateOf<String?>(null) }
    var resolvedEmployee by remember { mutableStateOf<Employee?>(null) }
    var noDemoPinError by remember { mutableStateOf(false) }
    var geoBlockError by remember { mutableStateOf(false) }

    fun areaStepsFor(d: String) = when (d) { "SR", "TSM", "ASM" -> 2; "RSM" -> 1; "DSM" -> 1; else -> 0 }

    fun resolveEmployeeId(designation: String, division: String?, district: String?, zone: String?): String? = when (designation) {
        "SR" -> "SR-$district"
        "TSM" -> "TSM-$district"
        "ASM" -> "ASM-$district"
        "RSM" -> "RSM-$division"
        "DSM" -> zone?.let { "DSM-${it.replace(" ", "")}" }
        "NSM" -> "NSM-1"; "AGM" -> "AGM-1"; "GM" -> "GM-1"; "MD" -> "MD-1"; "Chairman" -> "CHAIR-1"
        else -> null
    }

    fun tryResolveAndProceed(designation: String, division: String?, district: String?, zone: String?) {
        val empId = resolveEmployeeId(designation, division, district, zone)
        val emp = EMPLOYEE_DIRECTORY.firstOrNull { it.id == empId }
        val hasDemoPin = demoAccounts.values.any { it.employeeId == empId }
        if (emp != null && hasDemoPin) {
            resolvedEmployee = emp
            noDemoPinError = false
            phase = "pin"
        } else {
            resolvedEmployee = emp
            noDemoPinError = true
        }
    }

    val deviceLocked by MockRepository.deviceLocked.collectAsState()

    // ---- Admin-unlock sub-flow (only shown while deviceLocked) ----
    var unlockPin by remember { mutableStateOf("") }
    var unlockError by remember { mutableStateOf<String?>(null) }
    var showBreakGlass by remember { mutableStateOf(false) }
    var breakGlassCode by remember { mutableStateOf("") }
    var breakGlassError by remember { mutableStateOf<String?>(null) }

    // ---- Forgot-PIN sub-flow: 0 = off, 1 = phone, 2 = OTP, 3 = new PIN, 4 = done ----
    var forgotStep by remember { mutableStateOf(0) }
    var forgotPhone by remember { mutableStateOf("") }
    var forgotOtp by remember { mutableStateOf("") }
    var forgotNewPin by remember { mutableStateOf("") }
    var forgotError by remember { mutableStateOf<String?>(null) }

    // ---- role-based strictness: Chairman/MD need PIN + biometric, both ----
    var pendingStrictUser by remember { mutableStateOf<com.abm.erp.data.AppUser?>(null) }

    // ---- new-device Admin-approval ----
    var pendingDeviceApproval by remember { mutableStateOf<com.abm.erp.data.AppUser?>(null) }

    // ---- জরুরি SOS ----
    var showSOS by remember { mutableStateOf(false) }
    var sosSent by remember { mutableStateOf(false) }

    fun reset() {
        pin = ""
        status = LoginStatus.Idle
    }

    fun attemptLogin(code: String) {
        status = LoginStatus.Checking
        scope.launch {
            delay(400) // small pause so "Verifying..." is visible, matches the design prototype
            // আগে এখানে blind lookup ছিল (demoAccounts[code] থেকে সরাসরি কে
            // সেটা বের করা) — এখন PIN শুধু "designation+area থেকে resolve
            // করা মানুষটাই কিনা" তা নিশ্চিত করে, নিজে কাউকে খুঁজে বের করে না।
            val candidate = demoAccounts[code]
            val user = if (candidate != null && resolvedEmployee != null && candidate.employeeId == resolvedEmployee!!.id) candidate else null
            if (user != null) {
                // ---- অস্বাভাবিক লোকেশন চেক + hard geo-block (best-effort —
                // location না পেলে কোনোটাই প্রযোজ্য হয় না, লগইন আটকায় না) ----
                val loc = tryGetLoginLocation(activity)
                val employeeGeo = EMPLOYEE_DIRECTORY.firstOrNull { it.id == user.employeeId }?.geo
                val division = employeeGeo?.division
                val district = employeeGeo?.district
                val anomalous = loc != null && LocationAnomalyChecker.isAnomalous(division, loc.first, loc.second)
                val tooFar = loc != null && LocationAnomalyChecker.isTooFarToLogin(user.role.name, division, district, loc.first, loc.second)

                if (tooFar) {
                    // SR/TSM/ASM/RSM — নিজের এলাকা থেকে ৫০ কিমি-র বেশি দূরে
                    // হলে লগইনই সম্পূর্ণ হবে না (শুধু flag/log না, hard block) —
                    // তাই unlock/save/attendance-এর কোনো side-effect চলবে না।
                    geoBlockError = true
                    status = LoginStatus.Error
                    FirebaseSync.recordLoginAttempt(user.employeeId, user.name, deviceId, success = false, anomalous = true)
                    delay(700)
                    pin = ""
                    status = LoginStatus.Idle
                    return@launch
                }
                geoBlockError = false

                MockRepository.unlockDevice() // successful login clears any prior failed-attempt count
                saveLastLoggedInEmployee(activity, user.employeeId)
                FirebaseSync.recordLoginAttempt(user.employeeId, user.name, deviceId, success = true, anomalous = anomalous)

                // Login = Auto Attendance — এই একই location fix attendance-এও
                // ব্যবহার হয়, নতুন করে আলাদা GPS request লাগে না।
                if (loc != null) MockRepository.recordPresenceCheckIn(user.employeeId, user.name, loc.first, loc.second, false)

                // ---- Offline Login: অফলাইনে থাকলে Firestore-এর trustedDeviceIds
                // এখনো sync নাও হতে পারে (fresh cold-start) — তখন local-এ
                // "এই ডিভাইসে আগে এই মানুষই ছিল" প্রমাণ থাকলে সেটাই যথেষ্ট,
                // অকারণে নতুন Device Approval-এ পাঠানো হবে না। */
                val online = NetworkStatus.isOnline(activity)
                val isTrustedDevice = FirebaseSync.isTrustedDevice(user.employeeId, deviceId) ||
                    (!online && getLastLoggedInEmployee(activity) == user.employeeId)

                val isStrict = user.role.name in STRICT_ROLES
                when {
                    !isTrustedDevice -> {
                        // নতুন ডিভাইস — সরাসরি লগইন সম্পূর্ণ না করে Admin-approval-এর জন্য অপেক্ষা
                        pendingDeviceApproval = user
                        phase = "deviceApproval"
                        status = LoginStatus.Idle
                    }
                    isStrict -> {
                        // Chairman/MD — PIN ঠিক হলেও বাধ্যতামূলক biometric ছাড়া লগইন সম্পূর্ণ হবে না
                        pendingStrictUser = user
                        phase = "mandatoryBiometric"
                        status = LoginStatus.Idle
                    }
                    else -> {
                        status = LoginStatus.Success
                        MockRepository.completeLogin(user)
                        delay(650)
                        onLoginSuccess()
                    }
                }
            } else {
                status = LoginStatus.Error
                shakeOffset.animateTo(20f, tween(50))
                shakeOffset.animateTo(-20f, tween(80))
                shakeOffset.animateTo(12f, tween(80))
                shakeOffset.animateTo(0f, tween(80))
                delay(500)
                reset()
                // এই ডিভাইসে আগে যে লগইন করেছিল, তাকে "ভুল PIN চেষ্টা" নোটিফাই (log)
                val lastHere = getLastLoggedInEmployee(activity)
                val lastHereName = lastHere?.let { id -> demoAccounts.values.firstOrNull { it.employeeId == id }?.name } ?: "Unknown"
                FirebaseSync.recordLoginAttempt(lastHere, lastHereName, deviceId, success = false)
                // ৩ বার ভুল হলে ডিভাইস লক হয়ে যাবে — Chairman-এর PIN ছাড়া আনলক হবে না।
                MockRepository.recordFailedPinAttempt()
            }
        }
    }

    fun confirmMandatoryBiometric() {
        val user = pendingStrictUser ?: return
        status = LoginStatus.Checking
        scope.launch {
            delay(700)
            status = LoginStatus.Success
            MockRepository.completeLogin(user)
            delay(650)
            onLoginSuccess()
        }
    }

    // ডেমো-সিমুলেশন: বাস্তবে এটা Chairman-এর ডিভাইস থেকে দূর থেকে অনুমোদন
    // হতো (Trusted Devices স্ক্রিন থেকে); একই ডিভাইসে টেস্ট করার সুবিধার
    // জন্য এখানে একটা বোতাম দিয়ে সিমুলেট করা হচ্ছে।
    fun approveThisDeviceNow() {
        val user = pendingDeviceApproval ?: return
        FirebaseSync.addTrustedDevice(user.employeeId, deviceId)
        status = LoginStatus.Success
        MockRepository.completeLogin(user)
        pendingDeviceApproval = null
        scope.launch { delay(650); onLoginSuccess() }
    }

    fun submitBreakGlass() {
        // ডেমো recovery code — আসল অ্যাপে এটা secure ভাবে আলাদা রাখা কোনো কোড হবে, hash করে যাচাই হবে
        if (breakGlassCode.trim() == MockRepository.BREAK_GLASS_RECOVERY_CODE) {
            MockRepository.unlockDevice()
            showBreakGlass = false
            breakGlassError = null
            breakGlassCode = ""
        } else {
            breakGlassError = "Incorrect recovery code."
        }
    }

    fun pressUnlock(digit: String) {
        if (unlockPin.length >= 5) return
        val next = unlockPin + digit
        unlockPin = next
        if (next.length == 5) {
            if (MockRepository.isChairmanPin(next)) {
                MockRepository.unlockDevice()
                unlockPin = ""
                unlockError = null
            } else {
                unlockError = "Incorrect Admin PIN."
                scope.launch { delay(500); unlockPin = "" }
            }
        }
    }

    fun startBiometric() {
        // Android's biometric API only ever confirms "a fingerprint/face already
        // enrolled ON THIS DEVICE matched" — it can NEVER tell the app WHICH
        // person that was. So biometric login can only safely mean "quickly
        // re-enter the account that already logged in with a PIN on this
        // device" — never a way to pick/become an arbitrary account. If no
        // one has PIN-logged-in on this device yet, there's nothing to log
        // back into, so it's refused here rather than defaulting to anyone.
        val savedEmployeeId = getLastLoggedInEmployee(activity)
        if (savedEmployeeId == null) {
            biometricError = "Log in with your PIN at least once on this device first — fingerprint/face unlock then re-signs you in without needing the PIN again."
            return
        }
        val canAuth = BiometricManager.from(activity)
            .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.BIOMETRIC_STRONG)
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            biometricError = when (canAuth) {
                BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE ->
                    "This device has no fingerprint/face hardware — use your PIN instead."
                BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE ->
                    "Fingerprint/face hardware is busy or unavailable right now — use your PIN, or try again shortly."
                BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED ->
                    "No fingerprint/face enrolled on this device — set one up in phone Settings, or use your PIN."
                BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED ->
                    "This device needs a security update before fingerprint/face unlock will work — use your PIN for now."
                else -> "Fingerprint/face unlock isn't available right now — use your PIN."
            }
            return
        }
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    // logs back in as the SAME person who last PIN-logged-in on this
                    // device — resolved just now, not hardcoded to any one role.
                    val user = MockRepository.demoAccounts.values.firstOrNull { it.employeeId == savedEmployeeId }
                    if (user == null) {
                        biometricError = "Couldn't find that account anymore — please use your PIN."
                        return
                    }
                    MockRepository.completeLogin(user)
                    MockRepository.unlockDevice()
                    onLoginSuccess()
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    biometricError = errString.toString()
                }
            },
        )
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock ABM Corporation")
            .setSubtitle("Use your fingerprint or face to sign in")
            .setNegativeButtonText("Use PIN instead")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()
        prompt.authenticate(promptInfo)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(SkyTop, Sky, SkyHorizon, GoldBright)),
            ),
        contentAlignment = Alignment.Center,
    ) {
        val isOnline = remember { NetworkStatus.isOnline(activity) }
        // ভাষা টগল + অনলাইন/অফলাইন অবস্থা — সব phase-এ visible, top কোণে
        Row(
            modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(top = 14.dp, start = 14.dp, end = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                if (isOnline) t("📶 অনলাইন", "📶 Online") else t("📴 অফলাইন", "📴 Offline"),
                color = if (isOnline) Color.White else Color(0xFFF3D998),
                fontWeight = FontWeight.Bold, fontSize = 9.5.sp,
                modifier = Modifier
                    .background(Color(0x22FFFFFF), shape = androidx.compose.foundation.shape.RoundedCornerShape(999.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
            )
            TextButton(
                onClick = {
                    lang = if (lang == "bn") "en" else "bn"
                    saveLanguage(activity, lang)
                },
            ) {
                Text(
                    if (lang == "bn") "EN" else "বাং",
                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp,
                    modifier = Modifier
                        .background(Color(0x22FFFFFF), shape = androidx.compose.foundation.shape.RoundedCornerShape(999.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                )
            }
        }

        if (phase == "intro") {
            IntroSequence(onFinished = { phase = "designation" })
        } else if (phase == "companyCode") {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text("🏢", fontSize = 34.sp)
                Spacer(Modifier.height(10.dp))
                Text(t("আপনার কোম্পানির কোড দিন", "Enter your company code"), color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    t("প্রতিটা কোম্পানির নিজস্ব একটা কোড থাকে — একবার দিলে এই ডিভাইস মনে রাখবে।", "Each company has its own code — enter it once and this device will remember it."),
                    color = Color(0xFFE4EEF6), fontSize = 11.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = companyCodeInput, onValueChange = { companyCodeInput = it.uppercase() },
                    placeholder = { Text("ABM2026") }, modifier = Modifier.fillMaxWidth(),
                    textStyle = androidx.compose.ui.text.TextStyle(textAlign = androidx.compose.ui.text.style.TextAlign.Center),
                )
                companyCodeError?.let { Text(it, color = DangerRed, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)) }
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        val matched = FirebaseSync.validateCompanyCode(companyCodeInput)
                        if (matched == null) {
                            companyCodeError = t("কোড মেলেনি — আপনার Admin-এর কাছ থেকে সঠিক কোড নিন।", "Code didn't match — get the correct code from your Admin.")
                        } else {
                            companyCodeError = null
                            saveCompanyCode(activity, matched.code)
                            FirebaseSync.startCompanyScopedListeners(matched.id)
                            MockRepository.startCrossDeviceSync(matched.id)
                            InventoryRepository.startCrossDeviceSync(matched.id)
                            com.abm.erp.data.PurchaseRepository.startCrossDeviceSync(matched.id)
                            com.abm.erp.data.AccountsRepository.startCrossDeviceSync(matched.id)
                            com.abm.erp.data.CrmRepository.startCrossDeviceSync(matched.id)
                            com.abm.erp.data.CommsRepository.startCrossDeviceSync(matched.id)
                            phase = "intro"
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(t("চালিয়ে যান", "Continue")) }
                val knownCompanies by FirebaseSync.companies.collectAsState()
                Text(
                    if (knownCompanies.isEmpty()) t("Firebase সেটআপ না হলে কোড যাচাই হবে না — SETUP_FIREBASE.md দেখুন।", "Codes won't validate until Firebase is set up — see SETUP_FIREBASE.md.")
                    else "Demo codes: " + knownCompanies.joinToString(" · ") { it.code },
                    color = Color(0xFFE4EEF6), fontSize = 9.5.sp, modifier = Modifier.padding(top = 8.dp),
                )
            }
        } else if (phase == "designation") {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 48.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text(t("আপনার পদবী বেছে নিন", "Select your designation"), color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    t("এলাকা আর PIN-এর ধাপ এই অনুযায়ী সাজানো হবে।", "The area and PIN steps will adapt based on this."),
                    color = Color(0xFFE4EEF6), fontSize = 11.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
                Spacer(Modifier.height(16.dp))
                val rows = DESIGNATIONS.chunked(2)
                rows.forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                        row.forEach { d ->
                            OutlinedButton(
                                onClick = {
                                    selectedDesignation = d; selectedDivision = null; selectedDistrict = null; noDemoPinError = false
                                    if (areaStepsFor(d) == 0) tryResolveAndProceed(d, null, null, null) else phase = "area"
                                },
                                modifier = Modifier.weight(1f),
                            ) { Text(d, fontWeight = FontWeight.SemiBold) }
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        } else if (phase == "area" && selectedDesignation != null) {
            val designation = selectedDesignation!!
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 48.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text("$designation — " + t("এলাকা বেছে নিন", "select your area"), color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(14.dp))

                if (designation == "DSM") {
                    ZONES.keys.forEach { z ->
                        OutlinedButton(
                            onClick = { tryResolveAndProceed(designation, null, null, z) },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        ) { Text(z) }
                    }
                } else if (selectedDivision == null) {
                    val rows = DIVISION_DISTRICTS.keys.chunked(2)
                    rows.forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                            row.forEach { div ->
                                OutlinedButton(
                                    onClick = {
                                        selectedDivision = div
                                        if (designation == "RSM") tryResolveAndProceed(designation, div, null, null)
                                    },
                                    modifier = Modifier.weight(1f),
                                ) { Text(div, fontSize = 12.sp) }
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                } else {
                    Text(
                        "$selectedDivision " + t("বিভাগের জেলা", "division's districts"),
                        color = Color(0xFFE4EEF6), fontSize = 10.5.sp, modifier = Modifier.padding(bottom = 8.dp),
                    )
                    Column(modifier = Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                        DIVISION_DISTRICTS[selectedDivision]!!.forEach { dist ->
                            OutlinedButton(
                                onClick = { selectedDistrict = dist; tryResolveAndProceed(designation, selectedDivision, dist, null) },
                                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                            ) { Text(dist, fontSize = 12.sp) }
                        }
                    }
                }

                if (noDemoPinError) {
                    Spacer(Modifier.height(12.dp))
                    Surface(color = Color(0x26E24A3B), shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(
                                t("এই কম্বিনেশনের জন্য কোনো ডেমো PIN নেই", "No demo PIN for this combination"),
                                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.5.sp,
                            )
                            Text(
                                t("চেষ্টা করুন: Chairman, NSM, AGM, GM, MD (এলাকা লাগবে না), অথবা Barishal-এর SR, Khulna-এর RSM, Rangpur-এর ASM।", "Try: Chairman, NSM, AGM, GM, MD (no area needed), or Barishal's SR, Khulna's RSM, Rangpur's ASM."),
                                color = Color(0xFFE4EEF6), fontSize = 10.5.sp,
                            )
                        }
                    }
                }

                TextButton(onClick = {
                    selectedDesignation = null; selectedDivision = null; selectedDistrict = null; noDemoPinError = false
                    phase = "designation"
                }) {
                    Text(t("← পদবী আবার বেছে নিন", "← Choose designation again"), color = Color(0xFFE4EEF6), fontSize = 11.sp)
                }
            }
        } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 32.dp, vertical = 48.dp)
                .offset(x = shakeOffset.value.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            // ---- brand ----
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                AnimatedVisibility(visible = true, enter = scaleIn(tween(500)) + fadeIn(tween(500))) {
                    Box(
                        modifier = Modifier
                            .size(84.dp)
                            .background(
                                Brush.linearGradient(listOf(GoldBright, Gold, GoldDeep)),
                                shape = CircleShape,
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("ABM", color = Color(0xFF241A08), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    "ABM Corporation",
                    color = Color(0xFFFCFAF3),
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                )
                Spacer(Modifier.height(4.dp))
                Text("by Prime Distribution", color = Color.Black, fontSize = 11.sp)
            }

            when {
                deviceLocked -> {
                    // ================= Device locked out (3 wrong attempts) =================
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text("🔒", fontSize = 34.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Too many incorrect attempts", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "This device is locked. Only the Chairman's PIN can unlock it.",
                            color = Color(0xFFE4EEF6), fontSize = 11.5.sp,
                        )
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            repeat(5) { i ->
                                val filled = i < unlockPin.length
                                Box(
                                    modifier = Modifier.size(13.dp)
                                        .background(if (filled) GoldBright else Color.Transparent, CircleShape)
                                        .border(2.dp, if (filled) GoldBright else Color(0x55FFFFFF), CircleShape),
                                )
                            }
                        }
                        unlockError?.let { Text(it, color = DangerRed, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)) }
                        Spacer(Modifier.height(16.dp))
                        PinPadGrid(
                            buttonSize = 52.dp, keyFontSize = 19.sp, enabled = true,
                            onKeyPress = { key -> pressUnlock(key) },
                            onDelete = { unlockPin = unlockPin.dropLast(1) },
                        )
                        Text("Admin PIN unlock — Chairman only", color = Color(0xFFE4EEF6), fontSize = 10.sp)
                        TextButton(onClick = { showBreakGlass = true }) {
                            Text("Is the Chairman themselves locked out?", color = Color(0xFFE4EEF6), fontSize = 10.sp)
                        }
                        if (showBreakGlass) {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(top = 10.dp).background(Color(0x40000000), RoundedCornerShape(12.dp)).padding(14.dp),
                            ) {
                                Text("Break Glass Recovery", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(
                                    "Enter the pre-registered recovery code — this use is specially flagged in the audit log.",
                                    color = Color(0xFFE4EEF6), fontSize = 10.sp,
                                )
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = breakGlassCode, onValueChange = { breakGlassCode = it },
                                    placeholder = { Text("ABM-RECOVERY-2026") }, modifier = Modifier.fillMaxWidth(),
                                )
                                breakGlassError?.let { Text(it, color = DangerRed, fontSize = 10.5.sp) }
                                Spacer(Modifier.height(8.dp))
                                Button(onClick = { submitBreakGlass() }, modifier = Modifier.fillMaxWidth()) { Text("Verify") }
                            }
                        }
                    }
                }

                phase == "deviceApproval" && pendingDeviceApproval != null -> {
                    val pendingUser = pendingDeviceApproval!!
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text("🔐", fontSize = 34.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("New device — waiting for Admin approval", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 15.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Your PIN is correct, but this device is new for ${pendingUser.name} — for security, it needs Chairman/Admin approval first.",
                            color = Color(0xFFE4EEF6), fontSize = 11.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                        Spacer(Modifier.height(16.dp))
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = GoldBright)
                        Spacer(Modifier.height(16.dp))
                        OutlinedButton(onClick = { approveThisDeviceNow() }) {
                            Text("(Demo: simulate Admin approving now)", fontSize = 10.5.sp)
                        }
                        TextButton(onClick = { pendingDeviceApproval = null; phase = "pin"; pin = "" }) {
                            Text("← Back to login", color = Color(0xFFE4EEF6), fontSize = 11.sp)
                        }
                    }
                }
                phase == "mandatoryBiometric" && pendingStrictUser != null -> {
                    val strictUser = pendingStrictUser!!
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Text("👑", fontSize = 34.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Extra verification required", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "${strictUser.role} requires fingerprint/face in addition to your PIN — this much access needs more than a PIN alone.",
                            color = Color(0xFFE4EEF6), fontSize = 11.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                        Spacer(Modifier.height(16.dp))
                        if (status == LoginStatus.Checking) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = GoldBright)
                        } else {
                            Button(onClick = { confirmMandatoryBiometric() }, colors = ButtonDefaults.buttonColors(containerColor = GoldBright)) {
                                Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = Color(0xFF241A08))
                                Spacer(Modifier.width(6.dp))
                                Text("Confirm with Fingerprint/Face", color = Color(0xFF241A08), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                forgotStep > 0 -> {
                    // ================= Forgot PIN → OTP flow (simulated) =================
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        when (forgotStep) {
                            1 -> {
                                Text("Reset your PIN", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = forgotPhone, onValueChange = { forgotPhone = it },
                                    placeholder = { Text("Registered mobile number") }, modifier = Modifier.fillMaxWidth(),
                                )
                                forgotError?.let { Text(it, color = DangerRed, fontSize = 11.sp) }
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        if (forgotPhone.isBlank()) forgotError = "Enter your registered mobile number."
                                        else { forgotError = null; forgotStep = 2 }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                ) { Text("Send OTP") }
                            }
                            2 -> {
                                Text("Enter the OTP", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(Modifier.height(6.dp))
                                Text("Sent to $forgotPhone. (Demo OTP: 0000)", color = Color(0xFFE4EEF6), fontSize = 11.sp)
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = forgotOtp, onValueChange = { forgotOtp = it.filter(Char::isDigit).take(4) },
                                    placeholder = { Text("4-digit OTP") }, modifier = Modifier.fillMaxWidth(),
                                )
                                forgotError?.let { Text(it, color = DangerRed, fontSize = 11.sp) }
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        if (forgotOtp != "0000") forgotError = "Incorrect OTP."
                                        else { forgotError = null; forgotStep = 3 }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                ) { Text("Verify OTP") }
                            }
                            3 -> {
                                Text("Set a new 5-digit PIN", color = Color(0xFFFCFAF3), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = forgotNewPin, onValueChange = { forgotNewPin = it.filter(Char::isDigit).take(5) },
                                    placeholder = { Text("New PIN") }, modifier = Modifier.fillMaxWidth(),
                                )
                                forgotError?.let { Text(it, color = DangerRed, fontSize = 11.sp) }
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        if (forgotNewPin.length != 5) forgotError = "New PIN must be 5 digits."
                                        else if (isWeakPin(forgotNewPin)) forgotError = "That PIN is too weak/guessable — choose a different one."
                                        else {
                                            forgotError = null
                                            forgotStep = 4
                                            scope.launch { delay(2000); forgotStep = 0; forgotPhone = ""; forgotOtp = ""; forgotNewPin = "" }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                ) { Text("Save new PIN") }
                            }
                            4 -> Text("✓ PIN reset — please log in with it next time.", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        if (forgotStep < 4) {
                            TextButton(onClick = { forgotStep = 0; forgotError = null }) {
                                Text("← Back to login", color = Color(0xFFE4EEF6), fontSize = 11.sp)
                            }
                        }
                    }
                }

                else -> {
                    // ================= Normal PIN entry =================
                    // ---- PIN entry ----
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        resolvedEmployee?.let { emp ->
                            Text(
                                "${emp.name} — ${emp.role}", color = Color(0xFFFCFAF3),
                                fontWeight = FontWeight.Bold, fontSize = 13.sp,
                            )
                            Text(emp.geoLabel, color = Color(0xFFE4EEF6), fontSize = 10.5.sp)
                            Spacer(Modifier.height(6.dp))
                        }
                        if (geoBlockError) {
                            Surface(color = Color(0x2EE24A3B), shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                                Text(
                                    t("আপনার নির্ধারিত এলাকা থেকে অনেক দূরে — লগইন করা যাবে না।", "Too far from your assigned area — login blocked."),
                                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                )
                            }
                        }
                        Text(
                            text = when {
                                status == LoginStatus.Checking -> t("যাচাই হচ্ছে…", "Verifying…")
                                status == LoginStatus.Error && geoBlockError -> t("এলাকা মিলছে না", "Area mismatch")
                                status == LoginStatus.Error -> t("ভুল PIN — আবার চেষ্টা করুন", "Incorrect PIN — try again")
                                else -> t("আপনার ৫-সংখ্যার PIN দিন", "Enter your 5-digit PIN")
                            },
                            color = Color(0xFFE4EEF6),
                            fontSize = 13.sp,
                        )
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            repeat(5) { i ->
                                val filled = i < pin.length
                                val dotColor = if (status == LoginStatus.Error) DangerRed else GoldBright
                                Box(
                                    modifier = Modifier
                                        .size(14.dp)
                                        .background(color = if (filled) dotColor else Color.Transparent, shape = CircleShape)
                                        .border(width = 2.dp, color = if (filled) dotColor else Color(0x55FFFFFF), shape = CircleShape),
                                )
                            }
                        }
                        if (status == LoginStatus.Checking) {
                            Spacer(Modifier.height(10.dp))
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = GoldBright)
                        }
                    }

                    // ---- keypad ----
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        PinPadGrid(
                            buttonSize = 58.dp, keyFontSize = 20.sp, enabled = status == LoginStatus.Idle,
                            onKeyPress = { key -> if (pin.length < 5) { pin += key; if (pin.length == 5) attemptLogin(pin) } },
                            onDelete = { if (pin.isNotEmpty()) pin = pin.dropLast(1) },
                        )

                        TextButton(onClick = { startBiometric() }) {
                            Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = Color(0xFFFCFAF3))
                            Spacer(Modifier.width(6.dp))
                            Text("Fingerprint / Face unlock", color = Color(0xFFFCFAF3), fontSize = 12.sp)
                        }
                        biometricError?.let {
                            Text(it, color = Color(0xFF241A08), fontSize = 10.sp, modifier = Modifier.padding(horizontal = 24.dp))
                        }
                        // demo PIN hint সরিয়ে দেওয়া হলো — real app-এ login screen-এ
                        // password/PIN দেখানো একটা স্পষ্ট নিরাপত্তা ভুল।
                        TextButton(onClick = { forgotStep = 1 }) {
                            Text("Forgot PIN?", color = Color(0xFFE4EEF6), fontSize = 11.5.sp)
                        }
                        if (resolvedEmployee != null) {
                            TextButton(onClick = {
                                selectedDesignation = null; selectedDivision = null; selectedDistrict = null
                                resolvedEmployee = null; noDemoPinError = false; geoBlockError = false; pin = ""
                                phase = "designation"
                            }) {
                                Text(t("এই মানুষটা আমি না — আবার বেছে নিন", "Not you? Choose again"), color = Color(0xFFE4EEF6), fontSize = 11.sp)
                            }
                        }
                        TextButton(onClick = { showSOS = true }) {
                            Text("🆘 Emergency SOS", color = Color(0xFFFFCDD2), fontSize = 11.sp)
                        }
                        // ডিলার লগইন — স্টাফ PIN থেকে সম্পূর্ণ আলাদা পথ (ডিলার
                        // কোম্পানির staff hierarchy-র অংশ না, বহিরাগত পার্টনার)।
                        OutlinedButton(onClick = onDealerLoginRequested) {
                            Text("🏪 Continue as Dealer", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        } // closes the `else` branch for phase != "intro"

        if (status == LoginStatus.Success) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = SuccessGreen)
                    Spacer(Modifier.height(12.dp))
                    Text("Welcome, ${MockRepository.currentUser.name}", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        // জরুরি SOS — লগইন করার আগেও ব্যবহার করা যায়, দূরের/অনিরাপদ এলাকায়
        // কাজ করা field staff-দের জন্য।
        if (showSOS) {
            Box(
                modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)),
                contentAlignment = Alignment.Center,
            ) {
                Surface(shape = RoundedCornerShape(18.dp), color = Color.White, modifier = Modifier.padding(32.dp)) {
                    Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🆘", fontSize = 30.sp)
                        if (!sosSent) {
                            Text("Send an emergency alert?", color = Color(0xFF1B2430), fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
                            Text(
                                "Your live location will be sent immediately to your emergency contact and manager.",
                                color = Color(0xFF7C8698), fontSize = 11.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                modifier = Modifier.padding(top = 6.dp),
                            )
                            Button(
                                onClick = { sosSent = true },
                                colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                                modifier = Modifier.fillMaxWidth().padding(top = 14.dp),
                            ) { Text("Yes, send now") }
                            TextButton(onClick = { showSOS = false }) { Text("Cancel", color = Color(0xFF7C8698)) }
                        } else {
                            Text("✓ Sent", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
                            Text("Help is on the way.", color = Color(0xFF7C8698), fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                            TextButton(onClick = { showSOS = false; sosSent = false }) { Text("Close", color = Sky, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }
    }
}

/**
 * The ~3.8s animated brand reveal shown once per cold app-open, before the
 * PIN pad. Timings match the JSX design's CSS keyframes exactly:
 *   t=0ms     gold badge bounces in (0.7s, overshoot)
 *   t=500ms   "ABM Corporation" fades/slides in letter by letter (+45ms each)
 *   t=1350ms  thin gold line grows out (0.6s)
 *   t=1550ms  tagline fades in (0.5s)
 *   t=2200ms  tagline starts a soft continuous pulse
 *   t=3300ms  everything fades + lifts out (0.5s) -> onFinished() at t=3800ms
 */
/** The 3x4 PIN keypad — was duplicated (device-unlock flow + normal login flow); pulled out once here so both call it instead, shrinking LoginScreen's own bytecode size. */
@Composable
private fun PinPadGrid(buttonSize: androidx.compose.ui.unit.Dp, keyFontSize: androidx.compose.ui.unit.TextUnit, enabled: Boolean, onKeyPress: (String) -> Unit, onDelete: () -> Unit) {
    val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "del"))
    rows.forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(bottom = 12.dp)) {
            row.forEach { key ->
                when {
                    key.isEmpty() -> Spacer(Modifier.size(buttonSize))
                    key == "del" -> IconButton(onClick = { if (enabled) onDelete() }, modifier = Modifier.size(buttonSize)) {
                        Icon(Icons.Filled.Backspace, contentDescription = "Delete", tint = Color(0xFFE4EEF6))
                    }
                    else -> OutlinedButton(
                        onClick = { if (enabled) onKeyPress(key) },
                        modifier = Modifier.size(buttonSize), shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFCFAF3)),
                    ) { Text(key, fontSize = keyFontSize, fontWeight = FontWeight.SemiBold) }
                }
            }
        }
    }
}

@Composable
private fun IntroSequence(onFinished: () -> Unit) {
    val brand = "ABM Corporation"

    val badgeAlpha = remember { Animatable(0f) }
    val badgeScale = remember { Animatable(0.5f) }
    val badgeRotation = remember { Animatable(-25f) }
    val lineWidthFraction = remember { Animatable(0f) }
    val taglineAlpha = remember { Animatable(0f) }
    val taglinePulse = remember { Animatable(1f) }
    val overallAlpha = remember { Animatable(1f) }
    val overallOffsetY = remember { Animatable(0f) }
    val letterAlphas = remember { brand.indices.map { Animatable(0f) } }
    val letterOffsets = remember { brand.indices.map { Animatable(14f) } }

    LaunchedEffect(Unit) {
        // gold badge — quick bounce-in with a slight overshoot, like the JSX cubic-bezier
        launch { badgeAlpha.animateTo(1f, tween(220)) }
        launch { badgeScale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium)) }
        launch { badgeRotation.animateTo(0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium)) }

        // brand name, letter by letter
        brand.indices.forEach { i ->
            launch {
                delay(500L + i * 45L)
                launch { letterAlphas[i].animateTo(1f, tween(500)) }
                letterOffsets[i].animateTo(0f, tween(500))
            }
        }

        // gold divider line
        launch {
            delay(1350L)
            lineWidthFraction.animateTo(1f, tween(600))
        }

        // tagline: fade in, then a slow continuous pulse
        launch {
            delay(1550L)
            taglineAlpha.animateTo(1f, tween(500))
        }
        launch {
            delay(2200L)
            while (true) {
                taglinePulse.animateTo(0.55f, tween(1100, easing = FastOutSlowInEasing))
                taglinePulse.animateTo(1f, tween(1100, easing = FastOutSlowInEasing))
            }
        }

        // whole intro lifts and fades out, then hand off to the PIN phase
        delay(3300L)
        launch { overallOffsetY.animateTo(-14f, tween(500)) }
        overallAlpha.animateTo(0f, tween(500))
        onFinished()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                alpha = overallAlpha.value
                translationY = overallOffsetY.value.dp.toPx()
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier
                .size(88.dp)
                .graphicsLayer {
                    scaleX = badgeScale.value
                    scaleY = badgeScale.value
                    rotationZ = badgeRotation.value
                    alpha = badgeAlpha.value
                }
                .background(Brush.linearGradient(listOf(GoldBright, Gold, GoldDeep)), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Text("ABM", color = Color(0xFF241A08), fontWeight = FontWeight.Bold, fontSize = 26.sp)
        }
        Spacer(Modifier.height(22.dp))
        Row {
            brand.forEachIndexed { i, ch ->
                Text(
                    ch.toString(),
                    color = Color(0xFFFCFAF3),
                    fontWeight = FontWeight.Bold,
                    fontSize = 25.sp,
                    modifier = Modifier.graphicsLayer {
                        alpha = letterAlphas[i].value
                        translationY = letterOffsets[i].value.dp.toPx()
                    },
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .height(2.dp)
                .width(120.dp * lineWidthFraction.value)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, Gold, Color.Transparent))),
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "by Prime Distribution",
            color = Color.Black,
            fontSize = 11.sp,
            letterSpacing = 1.sp,
            modifier = Modifier.graphicsLayer { alpha = taglineAlpha.value * taglinePulse.value },
        )
    }
}
