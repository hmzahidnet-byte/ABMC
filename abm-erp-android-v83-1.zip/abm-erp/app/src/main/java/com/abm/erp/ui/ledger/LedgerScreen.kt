package com.abm.erp.ui.ledger

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.abm.erp.core.BackToSubMenuLink
import com.abm.erp.core.GlassCard
import com.abm.erp.core.ModuleGradientHeader
import com.abm.erp.core.SubModuleGrid
import com.abm.erp.core.SubModuleItem
import com.abm.erp.data.*
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import java.time.format.DateTimeFormatter
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

private val DATE_FMT = DateTimeFormatter.ofPattern("d MMM, h:mm a")

/**
 * Module 11 — Accounts & Finance. "Quick Ledger" (the original single-entry
 * IN/OUT recorder) stays exactly as it was; the new tabs are the formal
 * Chart of Accounts / double-entry Voucher layer backed by AccountsRepository.
 * NSM+ only (see ROLE_MODULES — "ledger" isn't in the SR/TSM/ASM/RSM/DSM sets).
 */
class LedgerViewModel : ViewModel() {
    val ledgerEntries = MockRepository.ledgerEntries
    val currentUser get() = MockRepository.currentUser
    fun addLedgerEntry(type: LedgerEntryType, category: String, description: String, amount: Double, recordedBy: String) =
        MockRepository.addLedgerEntry(type, category, description, amount, recordedBy)

    // ---- Module 11: Chart of Accounts / Vouchers / Reports ----
    val accounts = AccountsRepository.accounts
    val vouchers = AccountsRepository.vouchers
    fun createAccount(code: String, name: String, type: AccountType) = AccountsRepository.createAccount(code, name, type)
    fun createVoucher(type: VoucherType, narration: String, lines: List<VoucherLine>) = AccountsRepository.createVoucher(type, narration, lines)
    fun deleteVoucher(id: String) = AccountsRepository.deleteVoucher(id)
    fun trialBalance() = AccountsRepository.computeTrialBalance()
    fun profitAndLoss() = AccountsRepository.computeProfitAndLoss()
    fun balanceSheet() = AccountsRepository.computeBalanceSheet()
    fun cashBook() = AccountsRepository.cashBookEntries()
    fun bankBook() = AccountsRepository.bankBookEntries()
    fun canCreate() = PermissionManager.canCurrentUser("ledger", PermissionAction.CREATE)
    fun canDelete() = PermissionManager.canCurrentUser("ledger", PermissionAction.DELETE)
    fun canExport() = PermissionManager.canCurrentUser("ledger", PermissionAction.EXPORT)
}

@Composable
fun LedgerScreen(vm: LedgerViewModel = viewModel()) {
    var tab by remember { mutableStateOf<Int?>(null) }
    val subItems = listOf(
        SubModuleItem("quick", "Quick Ledger", "📒", 0xFF4E9CFF, 0xFF2E6FE0),
        SubModuleItem("coa", "Chart of Accounts", "🗂️", 0xFF8A6DFF, 0xFF5B3FE0),
        SubModuleItem("voucher", "Vouchers", "🧾", 0xFFFFB020, 0xFFE08A00),
        SubModuleItem("cashbank", "Cash & Bank Book", "🏦", 0xFF3DDC97, 0xFF1FA972),
        SubModuleItem("trial", "Trial Balance", "⚖️", 0xFFE85D4A, 0xFFC03A2B),
        SubModuleItem("pl", "Profit & Loss", "📈", 0xFF3FA9F5, 0xFF1D78C7),
        SubModuleItem("bs", "Balance Sheet", "📊", 0xFFB45CFF, 0xFF7A2EE0),
    )
    Column(Modifier.fillMaxSize()) {
        ModuleGradientHeader("Accounts & Finance", "💰", 0xFF12C2A9, 0xFF0E9F8B)
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            if (tab == null) {
                SubModuleGrid(subItems) { key -> tab = when (key) { "quick" -> 0; "coa" -> 1; "voucher" -> 2; "cashbank" -> 3; "trial" -> 4; "pl" -> 5; else -> 6 } }
            } else {
                BackToSubMenuLink(onClick = { tab = null })
                when (tab) {
                    0 -> QuickLedgerTab(vm)
                    1 -> ChartOfAccountsTab(vm)
                    2 -> VouchersTab(vm)
                    3 -> CashBankBookTab(vm)
                    4 -> TrialBalanceTab(vm)
                    5 -> ProfitLossTab(vm)
                    else -> BalanceSheetTab(vm)
                }
            }
        }
    }
}

@Composable
private fun QuickLedgerTab(vm: LedgerViewModel) {
    val allEntries by vm.ledgerEntries.collectAsState()
    val viewerRole = vm.currentUser.role
    val viewerDivision = EMPLOYEE_DIRECTORY.firstOrNull { it.id == vm.currentUser.employeeId }?.geo?.division
    val entries = if (viewerRole == UserRole.CHAIRMAN) allEntries
        else allEntries.filter { it.division == null || it.division == viewerDivision }
    val totalIn = entries.filter { it.type == LedgerEntryType.IN }.sumOf { it.amount }
    val totalOut = entries.filter { it.type == LedgerEntryType.OUT }.sumOf { it.amount }
    val balance = totalIn - totalOut

    var showAdd by remember { mutableStateOf(false) }
    var newType by remember { mutableStateOf(LedgerEntryType.IN) }
    var newCategory by remember { mutableStateOf("") }
    var newDescription by remember { mutableStateOf("") }
    var newAmount by remember { mutableStateOf("") }

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Running balance", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                Text(
                    "৳${"%,.0f".format(balance)}", style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold, color = if (balance >= 0) SuccessGreen else DangerRed,
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column {
                        Text("Total in", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("৳${"%,.0f".format(totalIn)}", color = SuccessGreen, fontWeight = FontWeight.SemiBold)
                    }
                    Column {
                        Text("Total out", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("৳${"%,.0f".format(totalOut)}", color = DangerRed, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        item {
            if (!showAdd) {
                Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Record entry") }
            } else {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LedgerEntryType.values().forEach { t ->
                            FilterChip(
                                selected = newType == t, onClick = { newType = t },
                                label = { Text(if (t == LedgerEntryType.IN) "Money in" else "Money out") },
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newCategory, onValueChange = { newCategory = it }, label = { Text("Category") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newDescription, onValueChange = { newDescription = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newAmount, onValueChange = { newAmount = it }, label = { Text("Amount (৳)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                val amt = newAmount.toDoubleOrNull() ?: return@Button
                                if (newCategory.isBlank() || amt <= 0) return@Button
                                vm.addLedgerEntry(newType, newCategory, newDescription, amt, vm.currentUser.name)
                                newCategory = ""; newDescription = ""; newAmount = ""; showAdd = false
                            },
                        ) { Text("Save") }
                        OutlinedButton(onClick = { showAdd = false }) { Text("Cancel") }
                    }
                }
            }
        }

        item { Text("Recent entries", style = MaterialTheme.typography.titleMedium) }
        items(entries, key = { it.id }) { entry ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(entry.category, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(entry.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Text("${entry.recordedBy} · ${entry.recordedAt.format(DATE_FMT)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Text(
                        (if (entry.type == LedgerEntryType.IN) "+৳" else "−৳") + "%,.0f".format(entry.amount),
                        color = if (entry.type == LedgerEntryType.IN) SuccessGreen else DangerRed, fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
        if (entries.isEmpty()) {
            item { Text("No ledger entries yet.", color = TextSecondary) }
        }
    }
}

@Composable
private fun ChartOfAccountsTab(vm: LedgerViewModel) {
    val accounts by vm.accounts.collectAsState()
    var showAdd by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        if (vm.canCreate()) {
            Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add Account") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            AccountType.values().forEach { type ->
                val group = accounts.filter { it.type == type }
                if (group.isNotEmpty()) {
                    item { Text(type.name, style = MaterialTheme.typography.titleSmall, color = TextSecondary, fontWeight = FontWeight.Bold) }
                    items(group, key = { it.id }) { a ->
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${a.code} — ${a.name}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                com.abm.erp.core.UniversalActionMenu(moduleReference = "ChartOfAccount", entityId = a.id, entityLabel = a.name, shareText = "${a.code} — ${a.name} (${a.type})", csvHeader = "Code,Name,Type", csvRow = com.abm.erp.core.toCsvRow(a.code, a.name, a.type))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        Dialog(onDismissRequest = { showAdd = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var code by remember { mutableStateOf("") }
                var name by remember { mutableStateOf("") }
                var type by remember { mutableStateOf(AccountType.EXPENSE) }
                var expanded by remember { mutableStateOf(false) }
                Column(Modifier.padding(16.dp)) {
                    Text("New Account", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Account code (e.g. 5400)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Account name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(type.name) }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            AccountType.values().forEach { t -> DropdownMenuItem(text = { Text(t.name) }, onClick = { type = t; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { if (vm.createAccount(code, name, type) != null) showAdd = false },
                        enabled = code.isNotBlank() && name.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Create Account") }
                }
            }
        }
    }
}

@Composable
private fun VouchersTab(vm: LedgerViewModel) {
    val vouchers by vm.vouchers.collectAsState()
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "VoucherNo,Type,Narration,TotalDebit,TotalCredit\n"
                    val rows = vouchers.joinToString("\n") { v -> com.abm.erp.core.toCsvRow(v.voucherNo, v.type, v.narration, v.totalDebit, v.totalCredit) }
                    val file = java.io.File(context.getExternalFilesDir(null), "vouchers_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Vouchers (${vouchers.size})\n" + vouchers.take(20).joinToString("\n") { "${it.voucherNo} (${it.type}) ৳${it.totalDebit}" }
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                    try { context.startActivity(android.content.Intent.createChooser(intent, "Vouchers")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                },
            )
        }
        if (vm.canCreate()) {
            Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Voucher") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(vouchers, key = { it.id }) { v ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${v.voucherNo} (${v.type})", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(v.narration.ifBlank { "—" }, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            v.lines.forEach { l ->
                                Text("  ${l.accountName}: Dr ৳${"%,.0f".format(l.debit)} / Cr ৳${"%,.0f".format(l.credit)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                        if (vm.canDelete()) {
                            TextButton(onClick = { vm.deleteVoucher(v.id) }) { Text("✕", color = DangerRed) }
                        }
                        val context = androidx.compose.ui.platform.LocalContext.current
                        TextButton(onClick = {
                            try {
                                val file = com.abm.erp.core.exportVoucherPdf(context, v)
                                com.abm.erp.core.shareStructuredPdf(context, file, "Voucher ${v.voucherNo}")
                            } catch (e: Exception) {
                                android.widget.Toast.makeText(context, "Voucher PDF তৈরি ব্যর্থ হয়েছে: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                            }
                        }) { Text("📄", style = MaterialTheme.typography.labelSmall) }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Voucher", entityId = v.id, entityLabel = v.voucherNo,
                            shareText = "${v.voucherNo} (${v.type})\n${v.narration}\nTotal: ৳${v.totalDebit}",
                            isDeleted = v.isDeleted,
                            recordStatus = "POSTED", // Task 4 — a Voucher is a posted ledger entry the moment it's created (no draft state exists), so it's always in the protected category; Archive shows disabled with an explanation instead of silently deleting ledger history.
                            onArchive = { vm.deleteVoucher(v.id) },
                            canArchive = vm.canDelete(),
                            csvHeader = "VoucherNo,Type,Narration,TotalDebit,TotalCredit",
                            csvRow = com.abm.erp.core.toCsvRow(v.voucherNo, v.type, v.narration, v.totalDebit, v.totalCredit),
                        )
                    }
                }
            }
            if (vouchers.isEmpty()) item { Text("এখনো কোনো Voucher পোস্ট করা হয়নি।", color = TextSecondary) }
        }
    }

    if (showNew) {
        Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                NewVoucherForm(vm) { showNew = false }
            }
        }
    }
}

@Composable
private fun NewVoucherForm(vm: LedgerViewModel, onDone: () -> Unit) {
    val accounts by vm.accounts.collectAsState()
    var type by remember { mutableStateOf(VoucherType.PAYMENT) }
    var narration by remember { mutableStateOf("") }
    val lines = remember { mutableStateListOf<VoucherLine>() }
    var drAccount by remember { mutableStateOf<ChartOfAccount?>(null) }
    var crAccount by remember { mutableStateOf<ChartOfAccount?>(null) }
    var amountText by remember { mutableStateOf("") }
    var drExpanded by remember { mutableStateOf(false) }
    var crExpanded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.padding(16.dp).heightIn(max = 600.dp)) {
        Text("New Voucher", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            VoucherType.values().forEach { t -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t.name) }) }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = narration, onValueChange = { narration = it }, label = { Text("Narration") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        Text("সহজ double-entry — একটা Debit account আর একটা Credit account বেছে নিন, সমপরিমাণ টাকা দুই দিকে পোস্ট হবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(8.dp))
        Box {
            OutlinedButton(onClick = { drExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Debit: " + (drAccount?.name ?: "Select account")) }
            DropdownMenu(expanded = drExpanded, onDismissRequest = { drExpanded = false }) {
                accounts.forEach { a -> DropdownMenuItem(text = { Text("${a.code} ${a.name}") }, onClick = { drAccount = a; drExpanded = false }) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Box {
            OutlinedButton(onClick = { crExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Credit: " + (crAccount?.name ?: "Select account")) }
            DropdownMenu(expanded = crExpanded, onDismissRequest = { crExpanded = false }) {
                accounts.forEach { a -> DropdownMenuItem(text = { Text("${a.code} ${a.name}") }, onClick = { crAccount = a; crExpanded = false }) }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("Amount (৳)") }, modifier = Modifier.fillMaxWidth())
        error?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 6.dp)) }
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = {
                val amt = amountText.toDoubleOrNull() ?: return@Button
                val dr = drAccount ?: return@Button
                val cr = crAccount ?: return@Button
                val voucherLines = listOf(
                    VoucherLine(accountId = dr.id, accountName = dr.name, debit = amt, credit = 0.0),
                    VoucherLine(accountId = cr.id, accountName = cr.name, debit = 0.0, credit = amt),
                )
                val created = vm.createVoucher(type, narration, voucherLines)
                if (created == null) error = "Voucher balance মেলেনি অথবা permission নেই।" else onDone()
            },
            enabled = drAccount != null && crAccount != null && amountText.toDoubleOrNull() != null,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Post Voucher") }
    }
}

@Composable
private fun CashBankBookTab(vm: LedgerViewModel) {
    var sub by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = sub) {
            Tab(selected = sub == 0, onClick = { sub = 0 }, text = { Text("Cash Book") })
            Tab(selected = sub == 1, onClick = { sub = 1 }, text = { Text("Bank Book") })
        }
        Spacer(Modifier.height(10.dp))
        val rows = if (sub == 0) vm.cashBook() else vm.bankBook()
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(rows) { (voucher, line) ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${voucher.voucherNo} — ${voucher.narration.ifBlank { voucher.type.name }}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(voucher.createdAt.format(DATE_FMT), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text(
                            if (line.debit > 0) "+৳${"%,.0f".format(line.debit)}" else "−৳${"%,.0f".format(line.credit)}",
                            color = if (line.debit > 0) SuccessGreen else DangerRed, fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
            if (rows.isEmpty()) item { Text("এখনো কোনো এন্ট্রি নেই।", color = TextSecondary) }
        }
    }
}

@Composable
private fun TrialBalanceTab(vm: LedgerViewModel) {
    val rows = vm.trialBalance()
    val totalDebit = rows.sumOf { it.totalDebit }
    val totalCredit = rows.sumOf { it.totalCredit }
    Column(Modifier.fillMaxSize()) {
        Text("Trial Balance", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
            items(rows) { r ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${r.account.code} ${r.account.name}", style = MaterialTheme.typography.bodySmall)
                    Text("Dr ৳${"%,.0f".format(r.netDebit)}  Cr ৳${"%,.0f".format(r.netCredit)}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Divider(modifier = Modifier.padding(vertical = 6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Total", fontWeight = FontWeight.Bold)
            Text("Dr ৳${"%,.0f".format(totalDebit)}  Cr ৳${"%,.0f".format(totalCredit)}", fontWeight = FontWeight.Bold, color = if (kotlin.math.abs(totalDebit - totalCredit) < 0.01) SuccessGreen else DangerRed)
        }
    }
}

@Composable
private fun ProfitLossTab(vm: LedgerViewModel) {
    val (income, expense, net) = vm.profitAndLoss()
    Column(Modifier.fillMaxSize()) {
        Text("Profit & Loss", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Total Income"); Text("৳${"%,.0f".format(income)}", color = SuccessGreen, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Total Expense"); Text("৳${"%,.0f".format(expense)}", color = DangerRed, fontWeight = FontWeight.Bold) }
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Net Profit / (Loss)", fontWeight = FontWeight.Bold)
                Text("৳${"%,.0f".format(net)}", color = if (net >= 0) SuccessGreen else DangerRed, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@Composable
private fun BalanceSheetTab(vm: LedgerViewModel) {
    val (assets, liabilities, equity) = vm.balanceSheet()
    val totalAssets = assets.sumOf { it.netDebit }
    val totalLiabEquity = liabilities.sumOf { it.netCredit } + equity.sumOf { it.netCredit }
    Column(Modifier.fillMaxSize()) {
        Text("Balance Sheet", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            item { Text("Assets", fontWeight = FontWeight.Bold, color = TextSecondary) }
            items(assets) { r -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(r.account.name); Text("৳${"%,.0f".format(r.netDebit)}") } }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Total Assets", fontWeight = FontWeight.Bold); Text("৳${"%,.0f".format(totalAssets)}", fontWeight = FontWeight.Bold) } }
            item { Spacer(Modifier.height(10.dp)); Text("Liabilities", fontWeight = FontWeight.Bold, color = TextSecondary) }
            items(liabilities) { r -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(r.account.name); Text("৳${"%,.0f".format(r.netCredit)}") } }
            item { Spacer(Modifier.height(10.dp)); Text("Equity", fontWeight = FontWeight.Bold, color = TextSecondary) }
            items(equity) { r -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(r.account.name); Text("৳${"%,.0f".format(r.netCredit)}") } }
            item {
                Divider(modifier = Modifier.padding(vertical = 8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Liabilities + Equity", fontWeight = FontWeight.Bold)
                    Text("৳${"%,.0f".format(totalLiabEquity)}", fontWeight = FontWeight.Bold, color = if (kotlin.math.abs(totalAssets - totalLiabEquity) < 0.01) SuccessGreen else WarningAmber)
                }
            }
        }
    }
}
