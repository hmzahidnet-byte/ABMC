package com.abm.erp.data

import android.content.Context
import com.abm.erp.data.room.AppDatabase
import com.abm.erp.data.room.ChartOfAccountEntity
import com.abm.erp.data.room.VoucherEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset

/**
 * Module 11 — Accounts & Finance. Same repository-object pattern as
 * PurchaseRepository/InventoryRepository. Chart of Accounts + double-entry
 * Vouchers (Payment/Receipt/Journal/Contra) are the authoritative source for
 * Trial Balance, Profit & Loss, and Balance Sheet — the existing single-entry
 * LedgerEntry (MockRepository.addLedgerEntry) is untouched and keeps serving
 * its own quick IN/OUT recording use elsewhere in the app; this is a
 * separate, more formal layer alongside it, not a replacement.
 */
object AccountsRepository {

    private lateinit var db: AppDatabase
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val firestoreDb by lazy { com.google.firebase.firestore.FirebaseFirestore.getInstance() }
    private var syncCompanyId: String? = null
    private var accountsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var vouchersListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

    private fun syncCollection(name: String) =
        firestoreDb.collection("companies").document(syncCompanyId ?: "_unset").collection(name)

    fun startCrossDeviceSync(companyId: String) {
        if (companyId == syncCompanyId) return
        syncCompanyId = companyId
        listenAccountsRemote()
        listenVouchersRemote()
    }

    private fun listenAccountsRemote() {
        accountsListenerReg?.remove()
        accountsListenerReg = syncCollection("chartOfAccounts").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("AccountsRepository", "chartOfAccounts sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(ChartOfAccountEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.chartOfAccountDao().upsertAll(list) }
        }
    }

    private fun listenVouchersRemote() {
        vouchersListenerReg?.remove()
        vouchersListenerReg = syncCollection("vouchers").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("AccountsRepository", "vouchers sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(VoucherEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.voucherDao().upsertAll(list) }
        }
    }

    private fun pushAccount(e: ChartOfAccountEntity) {
        syncCollection("chartOfAccounts").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("AccountsRepository", "pushAccount failed", it) }
    }

    private fun pushVoucher(e: VoucherEntity) {
        syncCollection("vouchers").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("AccountsRepository", "pushVoucher failed", it) }
    }

    fun init(context: Context) {
        db = AppDatabase.getInstance(context)
        seedChartOfAccountsIfEmpty()

        accounts = db.chartOfAccountDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        vouchers = db.voucherDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
    }

    /**
     * Standard starter Chart of Accounts — conventional numbering bands
     * (1000s Assets, 2000s Liabilities, 3000s Equity, 4000s Income, 5000s
     * Expense) so a Chairman/accountant sees a familiar structure on day
     * one, matching how Dealer/Retailer started empty but Chart of Accounts
     * genuinely needs a baseline to be usable at all (an empty account list
     * would make every other Accounts feature a dead end).
     */
    private fun seedChartOfAccountsIfEmpty() = runBlocking(Dispatchers.IO) {
        if (db.chartOfAccountDao().count() > 0) return@runBlocking
        val starter = listOf(
            ChartOfAccount(id = "ACC-1000", code = "1000", name = "Cash in Hand", type = AccountType.ASSET),
            ChartOfAccount(id = "ACC-1010", code = "1010", name = "Bank Account", type = AccountType.ASSET),
            ChartOfAccount(id = "ACC-1100", code = "1100", name = "Accounts Receivable — Dealers", type = AccountType.ASSET),
            ChartOfAccount(id = "ACC-1110", code = "1110", name = "Accounts Receivable — Retailers", type = AccountType.ASSET),
            ChartOfAccount(id = "ACC-1200", code = "1200", name = "Inventory", type = AccountType.ASSET),
            ChartOfAccount(id = "ACC-2000", code = "2000", name = "Accounts Payable — Suppliers", type = AccountType.LIABILITY),
            ChartOfAccount(id = "ACC-2100", code = "2100", name = "Salary Payable", type = AccountType.LIABILITY),
            ChartOfAccount(id = "ACC-3000", code = "3000", name = "Owner's Equity", type = AccountType.EQUITY),
            ChartOfAccount(id = "ACC-3100", code = "3100", name = "Retained Earnings", type = AccountType.EQUITY),
            ChartOfAccount(id = "ACC-4000", code = "4000", name = "Sales Revenue", type = AccountType.INCOME),
            ChartOfAccount(id = "ACC-4100", code = "4100", name = "Other Income", type = AccountType.INCOME),
            ChartOfAccount(id = "ACC-5000", code = "5000", name = "Purchase / Cost of Goods Sold", type = AccountType.EXPENSE),
            ChartOfAccount(id = "ACC-5100", code = "5100", name = "Salary Expense", type = AccountType.EXPENSE),
            ChartOfAccount(id = "ACC-5200", code = "5200", name = "Utility & Office Expense", type = AccountType.EXPENSE),
            ChartOfAccount(id = "ACC-5300", code = "5300", name = "Logistics & Courier Expense", type = AccountType.EXPENSE),
        )
        val entities = starter.map { it.toEntity() }
        db.chartOfAccountDao().upsertAll(entities)
        entities.forEach { pushAccount(it) }
    }

    lateinit var accounts: StateFlow<List<ChartOfAccount>>
        private set
    lateinit var vouchers: StateFlow<List<Voucher>>
        private set

    /** Chart of Accounts — Chairman/GM can extend the starter list with company-specific accounts. */
    fun createAccount(code: String, name: String, type: AccountType, parentId: String? = null): ChartOfAccount? {
        if (!PermissionManager.canCurrentUser("ledger", PermissionAction.CREATE)) {
            MockRepository.logAudit("ChartOfAccount", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            return null
        }
        if (code.isBlank() || name.isBlank()) return null
        val account = ChartOfAccount(id = "ACC-${java.util.UUID.randomUUID().toString().take(8)}", code = code, name = name, type = type, parentId = parentId)
        scope.launch {
            val entity = account.toEntity()
            db.chartOfAccountDao().upsert(entity)
            pushAccount(entity)
            MockRepository.logAudit("ChartOfAccount", account.id, "CREATE", newValue = account)
        }
        return account
    }

    /**
     * Creates a Voucher (Payment/Receipt/Journal/Contra) — the CORE
     * double-entry integrity rule is enforced here: total debits must equal
     * total credits, or the voucher is rejected outright before it ever
     * touches Room/Firestore. This is what makes Trial Balance/Balance
     * Sheet trustworthy — an unbalanced posting can never enter the system.
     */
    fun createVoucher(type: VoucherType, narration: String, lines: List<VoucherLine>): Voucher? {
        if (!PermissionManager.canCurrentUser("ledger", PermissionAction.CREATE)) {
            MockRepository.logAudit("Voucher", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            return null
        }
        if (lines.isEmpty()) return null
        val totalDebit = lines.sumOf { it.debit }
        val totalCredit = lines.sumOf { it.credit }
        if (kotlin.math.abs(totalDebit - totalCredit) > 0.01) {
            android.util.Log.w("AccountsRepository", "createVoucher rejected: unbalanced (debit=$totalDebit, credit=$totalCredit)")
            return null
        }
        val prefix = when (type) { VoucherType.PAYMENT -> "PV"; VoucherType.RECEIPT -> "RV"; VoucherType.JOURNAL -> "JV"; VoucherType.CONTRA -> "CV" }
        val voucher = Voucher(
            id = java.util.UUID.randomUUID().toString(), voucherNo = "$prefix-${(1000..9999).random()}",
            type = type, narration = narration, lines = lines, createdBy = MockRepository.currentUser.name,
        )
        scope.launch {
            val entity = voucher.toEntity()
            db.voucherDao().upsert(entity)
            pushVoucher(entity)
            MockRepository.logAudit("Voucher", voucher.voucherNo, "CREATE", newValue = voucher)
        }
        return voucher
    }

    fun deleteVoucher(voucherId: String): Boolean {
        if (!PermissionManager.canCurrentUser("ledger", PermissionAction.DELETE)) {
            MockRepository.logAudit("Voucher", voucherId, "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "DELETE")
            return false
        }
        scope.launch {
            db.voucherDao().softDelete(voucherId)
            syncCollection("vouchers").document(voucherId).update("isDeleted", true)
                .addOnFailureListener { android.util.Log.w("AccountsRepository", "push voucher-delete failed", it) }
            MockRepository.logAudit("Voucher", voucherId, "DELETE")
        }
        return true
    }

    // ---- Financial Reports (Module 11 & 17) — all computed live from posted Vouchers ----

    /** Trial Balance — every account's net debit/credit position across all posted vouchers. Must always balance (total net debit == total net credit) by construction, since every voucher itself is balanced. */
    fun computeTrialBalance(): List<TrialBalanceRow> {
        val allAccounts = accounts.value
        val allVouchers = vouchers.value
        return allAccounts.map { account ->
            var debit = 0.0
            var credit = 0.0
            allVouchers.forEach { v -> v.lines.filter { it.accountId == account.id }.forEach { debit += it.debit; credit += it.credit } }
            TrialBalanceRow(account, debit, credit)
        }.filter { it.totalDebit != 0.0 || it.totalCredit != 0.0 }
    }

    /** Profit & Loss — Income accounts' net credit balance minus Expense accounts' net debit balance, over all posted vouchers (no date filtering yet — a full fiscal-period P&L needs a date-range parameter, a natural next refinement). */
    fun computeProfitAndLoss(): Triple<Double, Double, Double> {
        val trial = computeTrialBalance()
        val income = trial.filter { it.account.type == AccountType.INCOME }.sumOf { it.netCredit }
        val expense = trial.filter { it.account.type == AccountType.EXPENSE }.sumOf { it.netDebit }
        return Triple(income, expense, income - expense)
    }

    /** Balance Sheet — Assets vs (Liabilities + Equity), the two sides must match once Retained Earnings absorbs the current period's net profit/loss. */
    fun computeBalanceSheet(): Triple<List<TrialBalanceRow>, List<TrialBalanceRow>, List<TrialBalanceRow>> {
        val trial = computeTrialBalance()
        val assets = trial.filter { it.account.type == AccountType.ASSET }
        val liabilities = trial.filter { it.account.type == AccountType.LIABILITY }
        val equity = trial.filter { it.account.type == AccountType.EQUITY }
        return Triple(assets, liabilities, equity)
    }

    /** Cash Book — every voucher line touching the Cash in Hand account. */
    fun cashBookEntries(): List<Pair<Voucher, VoucherLine>> =
        vouchers.value.flatMap { v -> v.lines.filter { it.accountId == "ACC-1000" }.map { v to it } }.sortedByDescending { it.first.createdAt }

    /** Bank Book — every voucher line touching the Bank Account. */
    fun bankBookEntries(): List<Pair<Voucher, VoucherLine>> =
        vouchers.value.flatMap { v -> v.lines.filter { it.accountId == "ACC-1010" }.map { v to it } }.sortedByDescending { it.first.createdAt }
}

private fun ChartOfAccount.toEntity() = ChartOfAccountEntity(
    id = id, code = code, name = name, type = type.name, parentId = parentId, isActive = isActive,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun ChartOfAccountEntity.toDomain() = ChartOfAccount(
    id = id, code = code, name = name, type = AccountType.valueOf(type), parentId = parentId, isActive = isActive,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

private fun Voucher.toEntity() = VoucherEntity(
    id = id, voucherNo = voucherNo, type = type.name, voucherDateEpochMillis = voucherDate.toInstant(ZoneOffset.UTC).toEpochMilli(),
    narration = narration, linesRaw = com.abm.erp.data.room.Converters.packVoucherLines(lines),
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

private fun VoucherEntity.toDomain() = Voucher(
    id = id, voucherNo = voucherNo, type = VoucherType.valueOf(type),
    voucherDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(voucherDateEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    narration = narration, lines = com.abm.erp.data.room.Converters.unpackVoucherLines(linesRaw),
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    isDeleted = isDeleted,
)
