package com.abm.erp

import android.app.Application
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.MockRepository
import com.abm.erp.data.SyncRetryWorker

/**
 * App-level entry point. MockRepository.init() and InventoryRepository.init()
 * open/create the on-device Room database (abm_erp.db) and seed it with
 * starter data on first run. FirebaseSync.init() signs in anonymously and
 * starts listening to Firestore for the data that needs to sync across
 * different people's phones (Complaint Box, Vacant Positions today; more
 * modules move here in later phases). It fails safely if google-services.json
 * hasn't been added yet — see SETUP_FIREBASE.md. SyncRetryWorker.schedule()
 * registers the WorkManager background job that re-heals sync if a listener
 * silently dies (see SyncRetryWorker's own doc comment).
 */
class ABMApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        MockRepository.init(this)
        InventoryRepository.init(this)
        com.abm.erp.data.PurchaseRepository.init(this)
        com.abm.erp.data.AccountsRepository.init(this)
        com.abm.erp.data.CrmRepository.init(this)
        com.abm.erp.data.CommsRepository.init(this)
        FirebaseSync.init(this)
        SyncRetryWorker.schedule(this)
    }
}
