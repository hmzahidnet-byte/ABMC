package com.abm.erp.data

import android.content.Context
import androidx.room.withTransaction
import com.abm.erp.data.room.AppDatabase
import com.abm.erp.data.room.ProductEntity
import com.abm.erp.data.room.StockLevelEntity
import com.abm.erp.data.room.StockMovementEntity
import com.abm.erp.data.room.WarehouseEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset

/**
 * Inventory / Stock Management module. Kept as its own repository object
 * (rather than folded into MockRepository) so modules stay decoupled as the
 * app grows — Sales/Dealer/Production screens will read stock levels from
 * here directly once they're wired up (Phase 3+).
 *
 * Call InventoryRepository.init(context) once, from ABMApplication.onCreate.
 */
object InventoryRepository {

    private lateinit var db: AppDatabase
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ---- Cross-device sync for Products (same pattern as MockRepository's Sales/Dealer/HR sync) ----
    private val firestoreDb by lazy { com.google.firebase.firestore.FirebaseFirestore.getInstance() }
    private var syncCompanyId: String? = null
    private var productsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var warehousesListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var stockMovementsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var stockLevelsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

    private fun syncCollection(name: String) =
        firestoreDb.collection("companies").document(syncCompanyId ?: "_unset").collection(name)

    /** Call once the company code is known — same call site as MockRepository.startCrossDeviceSync. */
    fun startCrossDeviceSync(companyId: String) {
        if (companyId == syncCompanyId) return
        syncCompanyId = companyId
        listenProductsRemote()
        listenWarehousesRemote()
        listenStockMovementsRemote()
        listenStockLevelsRemote()
        listenCategoriesRemote()
        listenBrandsRemote()
        listenDamageReportsRemote()
        listenStockTransfersRemote()
        listenInventoryLotsRemote()
    }

    private fun listenCategoriesRemote() {
        syncCollection("productCategories").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("InventoryRepository", "categories sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.ProductCategoryEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.productCategoryDao().upsertAll(list) }
        }
    }

    private fun listenBrandsRemote() {
        syncCollection("productBrands").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("InventoryRepository", "brands sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.ProductBrandEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.productBrandDao().upsertAll(list) }
        }
    }

    private fun listenDamageReportsRemote() {
        syncCollection("damageReports").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("InventoryRepository", "damageReports sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.DamageReportEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.damageReportDao().upsertAll(list) }
        }
    }

    private fun listenStockTransfersRemote() {
        syncCollection("stockTransfers").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("InventoryRepository", "stockTransfers sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.StockTransferEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.stockTransferDao().upsertAll(list) }
        }
    }

    private fun listenInventoryLotsRemote() {
        syncCollection("inventoryLots").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("InventoryRepository", "inventoryLots sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(com.abm.erp.data.room.InventoryLotEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.inventoryLotDao().upsertAll(list) }
        }
    }

    private fun listenProductsRemote() {
        productsListenerReg?.remove()
        productsListenerReg = syncCollection("products").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("InventoryRepository", "products sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(ProductEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.productDao().upsertAll(list) }
        }
    }

    private fun listenWarehousesRemote() {
        warehousesListenerReg?.remove()
        warehousesListenerReg = syncCollection("warehouses").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("InventoryRepository", "warehouses sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(WarehouseEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.warehouseDao().upsertAll(list) }
        }
    }

    private fun pushProduct(e: ProductEntity) {
        syncCollection("products").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("InventoryRepository", "pushProduct failed", it) }
    }

    private fun pushWarehouse(e: WarehouseEntity) {
        syncCollection("warehouses").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("InventoryRepository", "pushWarehouse failed", it) }
    }

    private fun listenStockMovementsRemote() {
        stockMovementsListenerReg?.remove()
        stockMovementsListenerReg = syncCollection("stockMovements").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("InventoryRepository", "stockMovements sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(StockMovementEntity::class.java) }.orEmpty()
            // পরিমাণ এখান থেকে recompute করা হয় না — সেটা listenStockLevelsRemote()-এর atomic
            // increment থেকেই আসে (Dealer stock/due-এর মতো একই প্রমাণিত পদ্ধতি), তাই একই
            // movement দুইবার (নিজের ডিভাইস + remote echo) গোনার ঝুঁকি নেই। এখানে শুধু
            // ইতিহাস/audit-trail হিসেবে Room-এ মিশিয়ে রাখা হয়।
            if (list.isNotEmpty()) scope.launch { db.stockDao().upsertMovements(list) }
        }
    }

    private fun pushStockMovement(e: StockMovementEntity) {
        syncCollection("stockMovements").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("InventoryRepository", "pushStockMovement failed", it) }
    }

    private fun pushStockLevelIncrement(productId: String, warehouseId: String, delta: Double) {
        val data: MutableMap<String, Any> = hashMapOf(
            "productId" to productId,
            "warehouseId" to warehouseId,
            "quantityOnHand" to com.google.firebase.firestore.FieldValue.increment(delta),
        )
        syncCollection("stockLevels").document("${productId}_$warehouseId")
            .set(data, com.google.firebase.firestore.SetOptions.merge())
            .addOnFailureListener { android.util.Log.w("InventoryRepository", "pushStockLevelIncrement failed", it) }
    }

    private fun listenStockLevelsRemote() {
        stockLevelsListenerReg?.remove()
        stockLevelsListenerReg = syncCollection("stockLevels").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("InventoryRepository", "stockLevels sync listener error", err); return@addSnapshotListener }
            snap?.documents?.forEach { doc ->
                val pid = doc.getString("productId") ?: return@forEach
                val wid = doc.getString("warehouseId") ?: return@forEach
                val qty = doc.getDouble("quantityOnHand") ?: return@forEach
                scope.launch { db.stockDao().upsertLevel(StockLevelEntity(pid, wid, qty)) }
            }
        }
    }

    fun init(context: Context) {
        if (::db.isInitialized) return
        db = AppDatabase.getInstance(context)
        seedIfEmpty()
        wireFlows()
    }

    lateinit var products: StateFlow<List<Product>>
        private set

    lateinit var warehouses: StateFlow<List<Warehouse>>
        private set

    lateinit var stockLevels: StateFlow<List<StockLevelView>>
        private set

    lateinit var movements: StateFlow<List<StockMovement>>
        private set

    val lowStockCount: Int get() = stockLevels.value.count { it.isLowStock }

    /**
     * Foundation Layer enforcement: action permission (canCreate on "inv"),
     * basic validation, and duplicate-prevention on sku+name — the same
     * pattern as MockRepository.createDealer/createRetailer.
     */
    fun addProduct(sku: String, name: String, unit: String, category: String, reorderThreshold: Double, defaultUnitPrice: Double, photoUri: String? = null, barcodeValue: String = "", categoryId: String? = null, brandId: String? = null) {
        if (!PermissionManager.canCurrentUser("inv", PermissionAction.CREATE)) {
            MockRepository.logAudit("Product", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            return
        }
        if (sku.isBlank() || name.isBlank()) {
            android.util.Log.w("InventoryRepository", "addProduct rejected: blank sku/name")
            return
        }
        if (reorderThreshold < 0 || defaultUnitPrice < 0) {
            android.util.Log.w("InventoryRepository", "addProduct rejected: negative threshold/price")
            return
        }
        val dedupKey = (sku.trim().lowercase() + "|" + name.trim().lowercase())
        scope.launch {
            if (db.productDao().countByDedupKey(dedupKey) > 0) {
                android.util.Log.w("InventoryRepository", "addProduct rejected: duplicate sku+name")
                return@launch
            }
            val entity = ProductEntity(
                id = java.util.UUID.randomUUID().toString(),
                sku = sku, name = name, unit = unit, category = category,
                reorderThreshold = reorderThreshold, defaultUnitPrice = defaultUnitPrice, photoUri = photoUri,
                dedupKey = dedupKey, createdBy = MockRepository.currentUser.name,
                barcodeValue = barcodeValue, categoryId = categoryId, brandId = brandId,
            )
            db.productDao().upsert(entity)
            pushProduct(entity)
            MockRepository.logAudit("Product", entity.id, "CREATE", newValue = entity)
        }
    }

    /** Universal Action Menu: Duplicate — new id + "-COPY" suffixed SKU so the dedup check doesn't collide with the original. */
    fun duplicateProduct(productId: String): DuplicateResult? {
        if (!PermissionManager.canCurrentUser("inv", PermissionAction.CREATE)) return null
        val p = products.value.firstOrNull { it.id == productId } ?: return null
        val newId = java.util.UUID.randomUUID().toString()
        val newSku = "${p.sku}-COPY${(100..999).random()}"
        val dedupKey = (newSku.trim().lowercase() + "|" + p.name.trim().lowercase())
        scope.launch {
            val entity = ProductEntity(
                id = newId, sku = newSku, name = p.name, unit = p.unit, category = p.category,
                reorderThreshold = p.reorderThreshold, defaultUnitPrice = p.defaultUnitPrice, photoUri = p.photoUri,
                dedupKey = dedupKey, createdBy = MockRepository.currentUser.name,
                barcodeValue = "", categoryId = p.categoryId, brandId = p.brandId,
            )
            db.productDao().upsert(entity)
            pushProduct(entity)
            MockRepository.logAudit("Product", newId, "CREATE", newValue = entity)
        }
        return DuplicateResult(newId, "${p.name} ($newSku)")
    }

    fun deleteProduct(productId: String) {
        if (!PermissionManager.canCurrentUser("inv", PermissionAction.DELETE)) {
            MockRepository.logAudit("Product", productId, "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "DELETE")
            return
        }
        scope.launch {
            val now = System.currentTimeMillis()
            db.productDao().softDelete(productId, now, MockRepository.currentUser.name)
            MockRepository.logAudit("Product", productId, "DELETE")
        }
    }

    fun restoreProduct(productId: String) {
        if (!PermissionManager.canCurrentUser("inv", PermissionAction.DELETE)) {
            MockRepository.logAudit("Product", productId, "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "RESTORE")
            return
        }
        scope.launch {
            db.productDao().restore(productId)
            MockRepository.logAudit("Product", productId, "RESTORE")
        }
    }

    fun addWarehouse(name: String, zone: String, stockCategory: StockCategory = StockCategory.STORE) {
        scope.launch {
            val entity = WarehouseEntity(id = java.util.UUID.randomUUID().toString(), name = name, zone = zone, stockCategory = stockCategory.name)
            db.warehouseDao().upsert(entity)
            pushWarehouse(entity)
        }
    }

    /** Adds stock (e.g. purchase, production output). Always succeeds. */
    fun stockIn(productId: String, warehouseId: String, quantity: Double, reason: String) {
        scope.launch { adjustStock(productId, warehouseId, quantity, MovementType.IN, reason) }
    }

    /**
     * Removes stock (e.g. dealer fulfillment, damage). Suspends the caller so the
     * UI can react to whether it actually happened — returns false instead of
     * going negative if there isn't enough on hand.
     */
    suspend fun stockOut(productId: String, warehouseId: String, quantity: Double, reason: String): Boolean {
        val current = db.stockDao().getLevel(productId, warehouseId)?.quantityOnHand ?: 0.0
        if (current < quantity) return false
        adjustStock(productId, warehouseId, quantity, MovementType.OUT, reason)
        return true
    }

    /**
     * Module 3 — Stock Adjustment: sets the shelf count to a physically
     * counted absolute quantity (not a delta like stockIn/stockOut), for
     * reconciling a stock-take against what Room/Firestore currently show.
     * Uses the same MovementType.ADJUST the private adjustStock() already
     * supported but nothing ever called.
     */
    fun adjustStockToCount(productId: String, warehouseId: String, actualCount: Double, reason: String) {
        if (!PermissionManager.canCurrentUser("inv", PermissionAction.EDIT)) {
            MockRepository.logAudit("StockAdjustment", productId, "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "EDIT")
            return
        }
        scope.launch {
            val before = db.stockDao().getLevel(productId, warehouseId)?.quantityOnHand ?: 0.0
            adjustStock(productId, warehouseId, actualCount, MovementType.ADJUST, reason.ifBlank { "Stock count adjustment" })
            MockRepository.logAudit("StockAdjustment", productId, "UPDATE", oldValue = before, newValue = actualCount)
        }
    }

    private suspend fun adjustStock(productId: String, warehouseId: String, quantity: Double, type: MovementType, reason: String) {
        var finalLevel = 0.0
        db.withTransaction {
            val current = db.stockDao().getLevel(productId, warehouseId)?.quantityOnHand ?: 0.0
            val delta = when (type) {
                MovementType.IN -> quantity
                MovementType.OUT -> -quantity
                MovementType.ADJUST -> quantity - current
            }
            val updated = current + delta
            finalLevel = updated
            db.stockDao().upsertLevel(StockLevelEntity(productId, warehouseId, updated))
            pushStockLevelIncrement(productId, warehouseId, delta)
            val movement = StockMovementEntity(
                id = java.util.UUID.randomUUID().toString(),
                productId = productId, warehouseId = warehouseId, type = type.name,
                quantity = quantity, reason = reason, timestampEpochMillis = System.currentTimeMillis(),
            )
            db.stockDao().insertMovement(movement)
            pushStockMovement(movement)
        }
        // Notification Framework — Low Stock: only fires on OUT/ADJUST (the movements that can actually cross the threshold downward), not every IN.
        if (type != MovementType.IN) {
            val product = products.value.firstOrNull { it.id == productId }
            if (product != null && finalLevel <= product.reorderThreshold) {
                MockRepository.createNotification(NotificationCategory.LOW_STOCK, "Low Stock: ${product.name}", "${product.name} — ${"%.1f".format(finalLevel)} ${product.unit} left (reorder at ${"%.1f".format(product.reorderThreshold)})")
            }
        }
    }

    // ================= Module 3 extras: Category, Brand, Expiry, Damage, Transfer =================

    lateinit var categories: StateFlow<List<ProductCategory>>
        private set
    lateinit var brands: StateFlow<List<ProductBrand>>
        private set
    lateinit var damageReports: StateFlow<List<DamageReport>>
        private set
    lateinit var stockTransfers: StateFlow<List<StockTransfer>>
        private set
    lateinit var inventoryLots: StateFlow<List<InventoryLot>>
        private set

    fun createCategory(name: String) {
        scope.launch {
            val entity = com.abm.erp.data.room.ProductCategoryEntity(id = java.util.UUID.randomUUID().toString(), name = name)
            db.productCategoryDao().upsert(entity)
            syncCollection("productCategories").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("InventoryRepository", "push category failed", it) }
        }
    }

    fun createBrand(name: String) {
        scope.launch {
            val entity = com.abm.erp.data.room.ProductBrandEntity(id = java.util.UUID.randomUUID().toString(), name = name)
            db.productBrandDao().upsert(entity)
            syncCollection("productBrands").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("InventoryRepository", "push brand failed", it) }
        }
    }

    /**
     * Stock-in WITH expiry tracking — creates a lot record (FEFO: first
     * expiry, first out) alongside the normal stock-level increment.
     * Regular stockIn() (no expiry) still works for non-perishable stock —
     * this is additive, not a replacement.
     */
    fun stockInWithExpiry(productId: String, warehouseId: String, quantity: Double, reason: String, expiryDate: java.time.LocalDateTime?, batchCode: String) {
        scope.launch {
            adjustStock(productId, warehouseId, quantity, MovementType.IN, reason)
            val lot = com.abm.erp.data.room.InventoryLotEntity(
                id = java.util.UUID.randomUUID().toString(), productId = productId, warehouseId = warehouseId,
                batchCode = batchCode.ifBlank { "LOT-${(1000..9999).random()}" }, qtyRemaining = quantity,
                expiryDateEpochMillis = expiryDate?.toInstant(java.time.ZoneOffset.UTC)?.toEpochMilli(),
                receivedAtEpochMillis = System.currentTimeMillis(),
            )
            db.inventoryLotDao().upsert(lot)
            syncCollection("inventoryLots").document(lot.id).set(lot)
                .addOnFailureListener { android.util.Log.w("InventoryRepository", "push lot failed", it) }
        }
    }

    /** Damage Tracking — explicitly tagged stock-out, distinct from a normal fulfillment stockOut, with its own DamageReport record for reporting. */
    fun reportDamage(productId: String, productName: String, warehouseId: String, qty: Double, reason: String): Boolean {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.DELETE)) {
            MockRepository.logAudit("DamageReport", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            return false
        }
        var succeeded = false
        scope.launch {
            val current = db.stockDao().getLevel(productId, warehouseId)?.quantityOnHand ?: 0.0
            if (current < qty) { android.util.Log.w("InventoryRepository", "reportDamage rejected: insufficient stock"); return@launch }
            adjustStock(productId, warehouseId, qty, MovementType.OUT, "Damage: $reason")
            val report = com.abm.erp.data.room.DamageReportEntity(
                id = java.util.UUID.randomUUID().toString(), productId = productId, productName = productName,
                warehouseId = warehouseId, qty = qty, reason = reason, reportedBy = MockRepository.currentUser.name,
                createdAtEpochMillis = System.currentTimeMillis(),
            )
            db.damageReportDao().upsert(report)
            syncCollection("damageReports").document(report.id).set(report)
                .addOnFailureListener { android.util.Log.w("InventoryRepository", "push damageReport failed", it) }
            MockRepository.logAudit("DamageReport", report.id, "CREATE", newValue = "$productName × $qty — $reason")
            succeeded = true
        }
        return succeeded
    }

    /** Stock Transfer — moves stock between two of our own warehouses atomically (stock-out at source + stock-in at destination), with one audit-friendly StockTransfer record instead of two disconnected movements. */
    suspend fun transferStock(productId: String, productName: String, fromWarehouseId: String, toWarehouseId: String, qty: Double): Boolean {
        val current = db.stockDao().getLevel(productId, fromWarehouseId)?.quantityOnHand ?: 0.0
        if (current < qty) return false
        db.withTransaction {
            adjustStock(productId, fromWarehouseId, qty, MovementType.OUT, "Transfer to $toWarehouseId")
            adjustStock(productId, toWarehouseId, qty, MovementType.IN, "Transfer from $fromWarehouseId")
        }
        val transfer = com.abm.erp.data.room.StockTransferEntity(
            id = java.util.UUID.randomUUID().toString(), productId = productId, productName = productName,
            fromWarehouseId = fromWarehouseId, toWarehouseId = toWarehouseId, qty = qty,
            createdBy = MockRepository.currentUser.name, createdAtEpochMillis = System.currentTimeMillis(),
        )
        db.stockTransferDao().upsert(transfer)
        syncCollection("stockTransfers").document(transfer.id).set(transfer)
            .addOnFailureListener { android.util.Log.w("InventoryRepository", "push stockTransfer failed", it) }
        MockRepository.logAudit("StockTransfer", transfer.id, "CREATE", newValue = "$productName × $qty: $fromWarehouseId -> $toWarehouseId")
        MockRepository.createNotification(NotificationCategory.STOCK_TRANSFER, "Stock Transfer", "$productName × ${"%.1f".format(qty)}: $fromWarehouseId → $toWarehouseId")
        return true
    }

    // ================= internal wiring =================

    private fun wireFlows() {
        products = db.productDao().getAll().map { it.toDomainProducts() }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        warehouses = db.warehouseDao().getAll().map { it.toDomainWarehouses() }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        stockLevels = combine(
            db.productDao().getAll(), db.warehouseDao().getAll(), db.stockDao().getAllLevels(),
        ) { productEntities, warehouseEntities, levelEntities ->
            val productsById = productEntities.associateBy { it.id }
            val warehousesById = warehouseEntities.associateBy { it.id }
            levelEntities.mapNotNull { level ->
                val product = productsById[level.productId] ?: return@mapNotNull null
                val warehouse = warehousesById[level.warehouseId] ?: return@mapNotNull null
                StockLevelView(
                    productId = product.id, productName = product.name, unit = product.unit,
                    warehouseId = warehouse.id, warehouseName = warehouse.name,
                    quantityOnHand = level.quantityOnHand, reorderThreshold = product.reorderThreshold,
                    stockCategory = StockCategory.valueOf(warehouse.stockCategory),
                )
            }.sortedBy { it.productName }
        }.stateIn(scope, SharingStarted.Eagerly, emptyList())

        movements = combine(
            db.productDao().getAll(), db.warehouseDao().getAll(), db.stockDao().getAllMovements(),
        ) { productEntities, warehouseEntities, movementEntities ->
            val productsById = productEntities.associateBy { it.id }
            val warehousesById = warehouseEntities.associateBy { it.id }
            movementEntities.mapNotNull { m ->
                val product = productsById[m.productId] ?: return@mapNotNull null
                val warehouse = warehousesById[m.warehouseId] ?: return@mapNotNull null
                StockMovement(
                    id = m.id, productId = product.id, productName = product.name,
                    warehouseId = warehouse.id, warehouseName = warehouse.name,
                    type = MovementType.valueOf(m.type), quantity = m.quantity, reason = m.reason,
                    timestamp = LocalDateTime.ofInstant(Instant.ofEpochMilli(m.timestampEpochMillis), ZoneOffset.UTC),
                )
            }
        }.stateIn(scope, SharingStarted.Eagerly, emptyList())

        categories = db.productCategoryDao().getAll().map { list -> list.map { ProductCategory(it.id, it.name, it.isActive) } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        brands = db.productBrandDao().getAll().map { list -> list.map { ProductBrand(it.id, it.name, it.isActive) } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        damageReports = db.damageReportDao().getAll().map { list -> list.map {
            DamageReport(it.id, it.productId, it.productName, it.warehouseId, it.qty, it.reason, it.reportedBy,
                LocalDateTime.ofInstant(Instant.ofEpochMilli(it.createdAtEpochMillis), ZoneOffset.UTC))
        } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        stockTransfers = db.stockTransferDao().getAll().map { list -> list.map {
            StockTransfer(it.id, it.productId, it.productName, it.fromWarehouseId, it.toWarehouseId, it.qty, it.status, it.createdBy,
                LocalDateTime.ofInstant(Instant.ofEpochMilli(it.createdAtEpochMillis), ZoneOffset.UTC))
        } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        inventoryLots = db.inventoryLotDao().getAll().map { list -> list.map {
            InventoryLot(it.id, it.productId, it.warehouseId, it.batchCode, it.qtyRemaining,
                it.expiryDateEpochMillis?.let { e -> LocalDateTime.ofInstant(Instant.ofEpochMilli(e), ZoneOffset.UTC) },
                LocalDateTime.ofInstant(Instant.ofEpochMilli(it.receivedAtEpochMillis), ZoneOffset.UTC))
        } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
    }

    /** Starter products/warehouses/stock so the screen isn't empty on first run. */
    private fun seedIfEmpty() = runBlocking(Dispatchers.IO) {
        if (db.warehouseDao().count() == 0) {
            db.warehouseDao().upsertAll(
                listOf(
                    WarehouseEntity("WH-1", "Barisal Main Warehouse", "Barisal", StockCategory.STORE.name),
                    WarehouseEntity("WH-2", "Khulna Depot", "Khulna", StockCategory.STORE.name),
                    WarehouseEntity("WH-3", "Rajshahi Depot", "Rajshahi", StockCategory.STORE.name),
                    WarehouseEntity("WH-4", "Factory Production Store", "Barisal", StockCategory.PRODUCTION.name),
                )
            )
        }
        if (db.productDao().count() == 0) {
            db.productDao().upsertAll(
                listOf(
                    ProductEntity("PRD-1", "MHN-MASALA-1KG", "ABM Masala Tea 1kg", "kg", "Tea", 50.0, 420.0),
                    ProductEntity("PRD-2", "MHN-CLASSIC-1KG", "ABM Tea Classic 1kg", "kg", "Tea", 40.0, 380.0),
                )
            )
        }
        // Seed opening stock only once, guarded by absence of a stock level row.
        if (db.stockDao().getLevel("PRD-1", "WH-1") == null) {
            adjustStock("PRD-1", "WH-1", 320.0, MovementType.IN, "Opening stock")
            adjustStock("PRD-2", "WH-1", 45.0, MovementType.IN, "Opening stock")
            adjustStock("PRD-1", "WH-2", 180.0, MovementType.IN, "Opening stock")
            adjustStock("PRD-1", "WH-4", 600.0, MovementType.IN, "Raw material received")
            adjustStock("PRD-2", "WH-4", 150.0, MovementType.IN, "Raw material received")
        }
    }
}

private fun ProductEntity.toDomainSingle() = Product(
    id, sku, name, unit, category, reorderThreshold, defaultUnitPrice, photoUri,
    isActive, isDeleted, createdBy,
    java.time.LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), java.time.ZoneOffset.UTC),
    dedupKey,
    deletedAtEpochMillis?.let { java.time.LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(it), java.time.ZoneOffset.UTC) },
    deletedBy, barcodeValue, categoryId, brandId,
)
private fun List<ProductEntity>.toDomainProducts() = map { it.toDomainSingle() }

private fun WarehouseEntity.toDomainSingle() = Warehouse(id, name, zone, StockCategory.valueOf(stockCategory))
private fun List<WarehouseEntity>.toDomainWarehouses() = map { it.toDomainSingle() }
