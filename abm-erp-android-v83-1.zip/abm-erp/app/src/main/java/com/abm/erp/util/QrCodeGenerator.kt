package com.abm.erp.util

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

/**
 * Generates a real, scannable QR code Bitmap (via ZXing) for a retailer shop
 * tag. SR prints this and sticks it at the shop; scanning it later (with any
 * QR reader, including a future in-app scanner) yields the retailerCode,
 * which the app can look up back to that shop's full record.
 */
object QrCodeGenerator {
    fun generate(content: String, sizePx: Int = 512): Bitmap {
        val hints = mapOf(EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M, EncodeHintType.MARGIN to 1)
        val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.RGB_565)
        for (x in 0 until sizePx) {
            for (y in 0 until sizePx) {
                bitmap.setPixel(x, y, if (matrix[x, y]) AndroidColor.BLACK else AndroidColor.WHITE)
            }
        }
        return bitmap
    }

    /** Unique, stable, scan-safe code for a retailer — e.g. "RT-BRSL-4F21A". */
    fun retailerCode(retailerName: String, zone: String): String {
        val slug = zone.take(4).uppercase().padEnd(4, 'X')
        val hash = (retailerName + System.nanoTime()).hashCode().toUInt().toString(16).takeLast(5).uppercase()
        return "RT-$slug-$hash"
    }
}
