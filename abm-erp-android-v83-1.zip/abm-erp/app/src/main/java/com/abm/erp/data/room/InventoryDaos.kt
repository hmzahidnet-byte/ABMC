package com.abm.erp.data.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name ASC")
    fun getAll(): Flow<List<ProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(product: ProductEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(products: List<ProductEntity>)

    @Query("SELECT COUNT(*) FROM products")
    suspend fun count(): Int

    @Query("SELECT COUNT(*) FROM products WHERE dedupKey = :dedupKey AND isDeleted = 0")
    suspend fun countByDedupKey(dedupKey: String): Int

    @Query("UPDATE products SET isDeleted = 1, deletedAtEpochMillis = :deletedAt, deletedBy = :deletedBy WHERE id = :id")
    suspend fun softDelete(id: String, deletedAt: Long, deletedBy: String)

    @Query("UPDATE products SET isDeleted = 0, deletedAtEpochMillis = NULL, deletedBy = NULL WHERE id = :id")
    suspend fun restore(id: String)
}

@Dao
interface WarehouseDao {
    @Query("SELECT * FROM warehouses ORDER BY name ASC")
    fun getAll(): Flow<List<WarehouseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(warehouse: WarehouseEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(warehouses: List<WarehouseEntity>)

    @Query("SELECT COUNT(*) FROM warehouses")
    suspend fun count(): Int
}

@Dao
interface StockDao {
    @Query("SELECT * FROM stock_levels")
    fun getAllLevels(): Flow<List<StockLevelEntity>>

    @Query("SELECT * FROM stock_levels WHERE productId = :productId AND warehouseId = :warehouseId LIMIT 1")
    suspend fun getLevel(productId: String, warehouseId: String): StockLevelEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertLevel(level: StockLevelEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMovement(movement: StockMovementEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMovements(movements: List<StockMovementEntity>)

    @Query("SELECT * FROM stock_movements ORDER BY timestampEpochMillis DESC")
    fun getAllMovements(): Flow<List<StockMovementEntity>>
}
