package com.abm.erp.ui.hrm

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.BackToSubMenuLink
import com.abm.erp.core.GlassCard
import com.abm.erp.core.SubModuleGrid
import com.abm.erp.core.SubModuleItem
import com.abm.erp.data.EMPLOYEE_DIRECTORY
import com.abm.erp.data.MockRepository
import com.abm.erp.data.PayrollLine
import com.abm.erp.data.findMyCascade
import com.abm.erp.theme.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

private val IndigoStart = Color(0xFF5B67F1)
private val IndigoEnd = Color(0xFF6C7CF5)

class PayrollViewModel : ViewModel() {
    val currentUser get() = MockRepository.currentUser
    val routes = MockRepository.routes
    val payroll = MockRepository.payroll
    fun refreshPayrollAbsences() = MockRepository.refreshPayrollAbsences()

    // ---- Module 12: HR extras ----
    val leaveRequests = MockRepository.leaveRequests
    val lifecycleEvents = MockRepository.employeeLifecycleEvents
    fun applyLeave(employeeId: String, employeeName: String, type: com.abm.erp.data.LeaveType, from: java.time.LocalDate, to: java.time.LocalDate, reason: String) =
        MockRepository.applyLeave(employeeId, employeeName, type, from, to, reason)
    fun setLeaveStatus(id: String, status: com.abm.erp.data.LeaveStatus) = MockRepository.setLeaveStatus(id, status)
    fun recordLifecycleEvent(employeeId: String, employeeName: String, type: String, oldValue: String, newValue: String, effectiveDate: java.time.LocalDate, notes: String) =
        MockRepository.recordLifecycleEvent(employeeId, employeeName, type, oldValue, newValue, effectiveDate, notes)
    fun canApproveHr() = com.abm.erp.data.PermissionManager.canCurrentUser("hr", com.abm.erp.data.PermissionAction.APPROVE)
}

@Composable
fun PayrollScreen(vm: PayrollViewModel = viewModel()) {
    var tab by remember { mutableStateOf<Int?>(null) }
    val subItems = listOf(
        SubModuleItem("attend", "Attendance", "🕒", 0xFF5B67F1, 0xFF6C7CF5),
        SubModuleItem("payroll", "Payroll", "💳", 0xFF3DDC97, 0xFF1FA972),
        SubModuleItem("leave", "Leave Management", "🏖️", 0xFF4E9CFF, 0xFF2E6FE0),
        SubModuleItem("lifecycle", "Increment/Promotion/Transfer/Exit", "📋", 0xFF8A6DFF, 0xFF5B3FE0),
    )

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("HR & Payroll", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        if (tab == null) {
            SubModuleGrid(subItems) { key -> tab = when (key) { "attend" -> 0; "payroll" -> 1; "leave" -> 2; else -> 3 } }
        } else {
            BackToSubMenuLink(onClick = { tab = null })
            when (tab) {
                0 -> AttendanceTab(vm)
                1 -> PayrollTab(vm)
                2 -> LeaveManagementTab(vm)
                else -> LifecycleEventsTab(vm)
            }
        }
    }
}

/**
 * FUNDAMENTAL RULE — every employee-level list uses the same area-matching
 * cascade (findMyCascade): a viewer only ever sees their own subordinate
 * chain, never sideways or upward. Chairman's unrestricted geo naturally
 * returns everyone; nobody else gets that by accident.
 */
@Composable
private fun AttendanceTab(vm: PayrollViewModel) {
    var selectedEmployeeId by remember { mutableStateOf<String?>(null) }
    val myCascade = remember {
        val me = EMPLOYEE_DIRECTORY.first { it.id == vm.currentUser.employeeId }
        findMyCascade(me).filter { it.role.name in setOf("SR", "TSM", "ASM") }
    }

    if (selectedEmployeeId == null) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(IndigoStart, IndigoEnd)), RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)).padding(18.dp)) {
                Column {
                    Text("Employee Attend List", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(6.dp))
                    val activeCount = myCascade.count { it.id.hashCode() % 3 != 2 } // demo proxy until live check-in feed is queried per-person
                    Text("এখন কর্মরত: $activeCount / ${myCascade.size} জন", color = Color(0xFFE4E9FF), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(4.dp))
            LazyColumn(Modifier.fillMaxSize().offset(y = (-16).dp), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(myCascade) { emp ->
                    val isPresent = emp.id.hashCode() % 3 != 2
                    GlassCard(modifier = Modifier.fillMaxWidth().clickable { selectedEmployeeId = emp.id }) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(36.dp).clip(CircleShape).background(Brush.linearGradient(listOf(IndigoStart, IndigoEnd))), contentAlignment = Alignment.Center) {
                                    Text(emp.name.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text(emp.name, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    Text(emp.role.name, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                }
                            }
                            Box(
                                Modifier.size(26.dp).clip(RoundedCornerShape(8.dp))
                                    .background(if (isPresent) SuccessGreen.copy(alpha = 0.12f) else DangerRed.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center,
                            ) { Text(if (isPresent) "P" else "A", color = if (isPresent) SuccessGreen else DangerRed, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column { Text("In Time", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("09:00 AM", style = MaterialTheme.typography.labelSmall) }
                            Column { Text("Out Time", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text(if (isPresent) "—" else "05:00 PM", style = MaterialTheme.typography.labelSmall) }
                        }
                    }
                }
                if (myCascade.isEmpty()) item { Text("আপনার অধীনে কেউ নেই।", color = TextSecondary) }
            }
        }
    } else {
        val emp = EMPLOYEE_DIRECTORY.first { it.id == selectedEmployeeId }
        AttendanceDetail(emp.id, emp.name, emp.role.name, vm) { selectedEmployeeId = null }
    }
}

@Composable
private fun AttendanceDetail(employeeId: String, name: String, role: String, vm: PayrollViewModel, onBack: () -> Unit) {
    val routes by vm.routes.collectAsState()
    val myRoute = routes.firstOrNull { it.employeeId == employeeId }
    val weekly = listOf(7f, 7.5f, 6.5f, 6f, 8f, 5.5f, 6.5f)
    val days = listOf("S", "M", "T", "W", "T", "F", "S")

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(IndigoStart, IndigoEnd)), RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)).padding(18.dp)) {
            Column {
                Text("←", color = Color.White, fontSize = 16.sp, modifier = Modifier.clickable(onClick = onBack))
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                        Text(name.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("$name Details", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(role, color = Color(0xFFE4E9FF), fontSize = 11.sp)
                    }
                }
            }
        }
        LazyColumn(Modifier.fillMaxSize().offset(y = (-16).dp), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Working Hours", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    Text("6h 30m", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = IndigoStart)
                    Text("Today", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth().height(70.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                        weekly.forEachIndexed { i, h ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.width(18.dp).height((h * 7).dp).background(if (i == 2) IndigoStart else Color(0xFFDCE6F5), RoundedCornerShape(4.dp)))
                                Spacer(Modifier.height(3.dp))
                                Text(days[i], style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                    }
                }
            }
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("📍 Location Trail — Live Presence Heartbeat", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(Modifier.height(6.dp))
                    val pings = myRoute?.breadcrumbs?.take(6) ?: emptyList()
                    if (pings.isEmpty()) {
                        Text("আজ এখনো কোনো checkpoint রেকর্ড হয়নি।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    } else {
                        pings.forEach { ping ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                                Text(ping.timestamp.toLocalTime().toString(), style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(70.dp))
                                Text("${"%.4f".format(ping.lat)}°N, ${"%.4f".format(ping.lng)}°E", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                    }
                }
            }
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Attendance", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(Modifier.height(8.dp))
                    val stats = listOf("Present" to (13 to SuccessGreen), "Absent" to (0 to DangerRed), "Holiday" to (4 to Sky), "Half Day" to (6 to WarningAmber), "Week Off" to (4 to Color(0xFFB45CFF)), "Leave" to (3 to Color(0xFF00B4B4)))
                    stats.chunked(3).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { (label, pair) ->
                                val (value, color) = pair
                                Column(
                                    modifier = Modifier.weight(1f).background(Color(0xFFF7F8FA), RoundedCornerShape(10.dp)).padding(8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                ) {
                                    Text("$value", fontWeight = FontWeight.Bold, color = color, fontSize = 15.sp)
                                    Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun PayrollTab(vm: PayrollViewModel) {
    val payroll by vm.payroll.collectAsState()
    var expandedId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { vm.refreshPayrollAbsences() }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Dynamic 3-layer payroll: base pay × achievement curve + commission − absence penalty", style = MaterialTheme.typography.bodyMedium) }
        items(payroll) { line ->
            PayrollCard(line, expanded = expandedId == line.employeeId, onToggle = {
                expandedId = if (expandedId == line.employeeId) null else line.employeeId
            })
        }
    }
}

@Composable
private fun PayrollCard(line: PayrollLine, expanded: Boolean, onToggle: () -> Unit) {
    val band = when {
        line.achievementPct >= 100 -> SuccessGreen
        line.achievementPct >= 80 -> WarningAmber
        else -> DangerRed
    }
    GlassCard(modifier = Modifier.fillMaxWidth().clickable(onClick = onToggle)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(line.employeeName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text("Achievement: ${"%.1f".format(line.achievementPct)}%", color = band, style = MaterialTheme.typography.labelSmall)
            }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text("৳${"%,.0f".format(line.netPayable)}", style = MaterialTheme.typography.titleMedium, color = ElectricCyan)
                val context = androidx.compose.ui.platform.LocalContext.current
                IconButton(onClick = {
                    try {
                        val file = com.abm.erp.core.exportPayslipPdf(context, line)
                        com.abm.erp.core.shareStructuredPdf(context, file, "Payslip — ${line.employeeName}")
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(context, "Payslip PDF তৈরি ব্যর্থ হয়েছে: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                    }
                }) { Text("📄") }
            }
        }
        if (expanded) {
            Spacer(Modifier.height(10.dp))
            Divider(color = GlassBorder)
            Spacer(Modifier.height(10.dp))
            StatRow("Base pay", line.basePay)
            StatRow("Scaling factor", null, "${"%.2f".format(line.scalingFactor)}×")
            StatRow("Base × scaling", line.basePay * line.scalingFactor)
            StatRow("Sales commission (${"%.1f".format(line.commissionRate * 100)}%)", line.commission)
            StatRow("Unapproved absences", null, "${line.unapprovedAbsenceDays} day(s) — GPS-verified")
            StatRow("Absence penalty", -line.absencePenalty)
            Spacer(Modifier.height(6.dp))
            Divider(color = GlassBorder)
            Spacer(Modifier.height(6.dp))
            StatRow("Net payable", line.netPayable, bold = true)
            Spacer(Modifier.height(8.dp))
            Text(
                "Dispute-proof statement generated · penalty derived from missing/spoofed GPS nodes during duty hours, not manual entry.",
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}

@Composable
private fun StatRow(label: String, amount: Double?, override: String? = null, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(
            override ?: "৳${"%,.0f".format(amount ?: 0.0)}",
            color = if (bold) ElectricCyan else TextPrimary,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

@Composable
private fun LeaveManagementTab(vm: PayrollViewModel) {
    val leaves by vm.leaveRequests.collectAsState()
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "Employee,Type,From,To,Status\n"
                    val rows = leaves.joinToString("\n") { l -> com.abm.erp.core.toCsvRow(l.employeeName, l.type, l.fromDate, l.toDate, l.status) }
                    val file = java.io.File(context.getExternalFilesDir(null), "leave_requests_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Leave Requests (${leaves.size})\n" + leaves.take(20).joinToString("\n") { "${it.employeeName} — ${it.type} (${it.status})" }
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                    try { context.startActivity(android.content.Intent.createChooser(intent, "Leave Requests")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                },
            )
        }
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Apply Leave") }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(leaves) { l ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(l.employeeName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${l.type} · ${l.fromDate} → ${l.toDate} (${l.days} days)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            if (l.reason.isNotBlank()) Text(l.reason, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text(l.status.name, color = when (l.status) { com.abm.erp.data.LeaveStatus.APPROVED -> SuccessGreen; com.abm.erp.data.LeaveStatus.REJECTED -> DangerRed; else -> WarningAmber }, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "LeaveRequest", entityId = l.id, entityLabel = l.employeeName,
                            shareText = "Leave: ${l.employeeName}\n${l.type}: ${l.fromDate} → ${l.toDate}\nStatus: ${l.status}",
                            csvHeader = "Employee,Type,From,To,Days,Status",
                            csvRow = com.abm.erp.core.toCsvRow(l.employeeName, l.type, l.fromDate, l.toDate, l.days, l.status),
                        )
                    }
                    if (l.status == com.abm.erp.data.LeaveStatus.PENDING && vm.canApproveHr()) {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.setLeaveStatus(l.id, com.abm.erp.data.LeaveStatus.APPROVED) }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) { Text("Approve") }
                            OutlinedButton(onClick = { vm.setLeaveStatus(l.id, com.abm.erp.data.LeaveStatus.REJECTED) }) { Text("Reject", color = DangerRed) }
                        }
                    }
                }
            }
            if (leaves.isEmpty()) item { Text("এখনো কোনো Leave application নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                var selectedEmployee by remember { mutableStateOf<com.abm.erp.data.Employee?>(null) }
                var expanded by remember { mutableStateOf(false) }
                var type by remember { mutableStateOf(com.abm.erp.data.LeaveType.CASUAL) }
                var fromDaysOffset by remember { mutableStateOf("0") }
                var toDaysOffset by remember { mutableStateOf("1") }
                var reason by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
                    Text("Apply Leave", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedEmployee?.name ?: "Select employee") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            EMPLOYEE_DIRECTORY.forEach { e -> DropdownMenuItem(text = { Text(e.name) }, onClick = { selectedEmployee = e; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        com.abm.erp.data.LeaveType.values().forEach { t -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t.name) }) }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = fromDaysOffset, onValueChange = { fromDaysOffset = it }, label = { Text("From (আজ থেকে দিন)") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = toDaysOffset, onValueChange = { toDaysOffset = it }, label = { Text("To (আজ থেকে দিন)") }, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val e = selectedEmployee ?: return@Button
                            val from = java.time.LocalDate.now().plusDays(fromDaysOffset.toLongOrNull() ?: 0)
                            val to = java.time.LocalDate.now().plusDays(toDaysOffset.toLongOrNull() ?: 1)
                            if (vm.applyLeave(e.id, e.name, type, from, to, reason) != null) showNew = false
                        },
                        enabled = selectedEmployee != null,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Submit") }
                }
            }
        }
    }
}

@Composable
private fun LifecycleEventsTab(vm: PayrollViewModel) {
    val events by vm.lifecycleEvents.collectAsState()
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        if (vm.canApproveHr()) {
            Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Record Event") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(events) { e ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(e.employeeName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${e.oldValue} → ${e.newValue} · effective ${e.effectiveDate}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            if (e.notes.isNotBlank()) Text(e.notes, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text(e.type, color = ElectricCyan, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "EmployeeLifecycleEvent", entityId = e.id, entityLabel = e.employeeName,
                            shareText = "${e.type}: ${e.employeeName}\n${e.oldValue} → ${e.newValue}\nEffective: ${e.effectiveDate}",
                            csvHeader = "Employee,Type,OldValue,NewValue,EffectiveDate",
                            csvRow = com.abm.erp.core.toCsvRow(e.employeeName, e.type, e.oldValue, e.newValue, e.effectiveDate),
                        )
                    }
                }
            }
            if (events.isEmpty()) item { Text("এখনো কোনো lifecycle event নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                var selectedEmployee by remember { mutableStateOf<com.abm.erp.data.Employee?>(null) }
                var expanded by remember { mutableStateOf(false) }
                var type by remember { mutableStateOf("INCREMENT") }
                var oldValue by remember { mutableStateOf("") }
                var newValue by remember { mutableStateOf("") }
                var notes by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
                    Text("Record Employee Event", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedEmployee?.name ?: "Select employee") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            EMPLOYEE_DIRECTORY.forEach { emp -> DropdownMenuItem(text = { Text(emp.name) }, onClick = { selectedEmployee = emp; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("INCREMENT", "PROMOTION", "TRANSFER", "EXIT").forEach { t -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t, style = MaterialTheme.typography.labelSmall) }) }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = oldValue, onValueChange = { oldValue = it }, label = { Text("আগে (e.g. পুরনো বেতন/পদবি/শাখা)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newValue, onValueChange = { newValue = it }, label = { Text("এখন") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("নোট") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val e = selectedEmployee ?: return@Button
                            if (vm.recordLifecycleEvent(e.id, e.name, type, oldValue, newValue, java.time.LocalDate.now(), notes)) showNew = false
                        },
                        enabled = selectedEmployee != null,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Save") }
                }
            }
        }
    }
}
