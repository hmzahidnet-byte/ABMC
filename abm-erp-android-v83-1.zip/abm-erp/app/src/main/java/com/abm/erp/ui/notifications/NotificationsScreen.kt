package com.abm.erp.ui.notifications

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.data.ApprovalStatus
import com.abm.erp.data.EMPLOYEE_DIRECTORY
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.LeaveStatus
import com.abm.erp.data.MockRepository
import com.abm.erp.data.UserRole
import com.abm.erp.data.findCoveringEmployee
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import java.time.LocalDateTime

class NotificationsViewModel : ViewModel() {
    val currentUserFlow = MockRepository.currentUserFlow
    val vacantEmployeeIds = MockRepository.vacantEmployeeIds
    val stockLevels = InventoryRepository.stockLevels
    val complaints = FirebaseSync.complaints
    val approvals = MockRepository.approvals
    val leaveRequests = MockRepository.leaveRequests
    val partyCollections = MockRepository.partyCollections
    val dealers = MockRepository.dealers
    val retailers = MockRepository.retailers
    val notifications = MockRepository.notifications
    fun markRead(id: String) = MockRepository.markNotificationRead(id)
}

/**
 * A single inbox pulling from every source that generates an alert, rather
 * than one screen per source — matches the JSX design's Notifications
 * concept. Low-stock reaches everyone (even SR, who doesn't manage dealers
 * directly, still benefits from knowing); vacancy-coverage duties and open
 * complaints are scoped to what's actually relevant to the viewer.
 */
@Composable
fun NotificationsScreen(vm: NotificationsViewModel = viewModel()) {
    val appUser by vm.currentUserFlow.collectAsState()
    val vacantIds by vm.vacantEmployeeIds.collectAsState()
    val stockLevels by vm.stockLevels.collectAsState()
    val complaints by vm.complaints.collectAsState()

    val employee = remember(appUser.employeeId) {
        EMPLOYEE_DIRECTORY.firstOrNull { it.id == appUser.employeeId } ?: EMPLOYEE_DIRECTORY.first { it.role == UserRole.CHAIRMAN }
    }
    val coveredEmployees = remember(employee.id, vacantIds) {
        EMPLOYEE_DIRECTORY.filter { vacantIds.contains(it.id) && findCoveringEmployee(it, vacantIds)?.id == employee.id }
    }
    val lowStock = stockLevels.filter { it.isLowStock }
    val openComplaints = if (appUser.role == UserRole.CHAIRMAN) complaints.filter { !it.resolved } else emptyList()
    val approvals by vm.approvals.collectAsState()
    val myPendingApprovals = approvals.filter { it.status == ApprovalStatus.PENDING }
    val leaveRequests by vm.leaveRequests.collectAsState()
    val pendingLeaves = leaveRequests.filter { it.status == LeaveStatus.PENDING }
    val partyCollections by vm.partyCollections.collectAsState()
    val dueCollections = partyCollections.filter { it.status == "PENDING" }
    val dealers by vm.dealers.collectAsState()
    val retailers by vm.retailers.collectAsState()
    val dayAgo = LocalDateTime.now().minusHours(24)
    val newDealers = dealers.filter { it.createdAt.isAfter(dayAgo) }
    val newRetailers = retailers.filter { it.createdAt.isAfter(dayAgo) }
    val persistedNotifications by vm.notifications.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text("Notifications", style = MaterialTheme.typography.headlineSmall)
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "Title,Body,Category,Read\n"
                    val rows = persistedNotifications.joinToString("\n") { n -> com.abm.erp.core.toCsvRow(n.title, n.body, n.category, n.isRead) }
                    val file = java.io.File(context.getExternalFilesDir(null), "notifications_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Notifications (${persistedNotifications.size})\n" + persistedNotifications.take(20).joinToString("\n") { "${it.title}: ${it.body}" }
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                    try { context.startActivity(android.content.Intent.createChooser(intent, "Notifications")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                },
            )
        }
        Spacer(Modifier.height(12.dp))

        if (persistedNotifications.isNotEmpty()) {
            Text("Recent Activity", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            persistedNotifications.take(10).forEach { n ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(n.title, fontWeight = FontWeight.SemiBold, color = if (n.isRead) TextSecondary else TextPrimary)
                            Text(n.body, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        if (!n.isRead) {
                            TextButton(onClick = { vm.markRead(n.id) }) { Text("Mark read") }
                        }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Notification", entityId = n.id, entityLabel = n.title,
                            shareText = "${n.title}\n${n.body}\n${n.category}",
                            csvHeader = "Title,Body,Category,Read", csvRow = com.abm.erp.core.toCsvRow(n.title, n.body, n.category, n.isRead),
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        if (coveredEmployees.isEmpty() && lowStock.isEmpty() && openComplaints.isEmpty() && myPendingApprovals.isEmpty() &&
            pendingLeaves.isEmpty() && dueCollections.isEmpty() && newDealers.isEmpty() && newRetailers.isEmpty()
        ) {
            Text("You're all caught up — nothing needs attention right now.", color = TextSecondary)
        }

        if (myPendingApprovals.isNotEmpty()) {
            Text("Approval alerts (${myPendingApprovals.size})", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            myPendingApprovals.forEach { a ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text("${a.type} — ${a.fromEmployee}", color = WarningAmber, fontWeight = FontWeight.SemiBold)
                    Text(a.detail, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }

        if (pendingLeaves.isNotEmpty()) {
            Text("Leave alerts (${pendingLeaves.size})", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            pendingLeaves.forEach { l ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text("${l.employeeName} — ${l.type}", color = WarningAmber, fontWeight = FontWeight.SemiBold)
                    Text("${l.fromDate} → ${l.toDate}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }

        if (dueCollections.isNotEmpty()) {
            Text("Collection due (${dueCollections.size})", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            dueCollections.forEach { c ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text("${c.partyName} — ৳${"%,.0f".format(c.amount)}", color = WarningAmber, fontWeight = FontWeight.SemiBold)
                    Text("Awaiting verification · ${c.method}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }

        if (newDealers.isNotEmpty() || newRetailers.isNotEmpty()) {
            Text("New registrations (24h)", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            newDealers.forEach { d ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text("New Dealer: ${d.name}", color = SuccessGreen, fontWeight = FontWeight.SemiBold)
                    Text(d.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
            newRetailers.forEach { r ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text("New Outlet: ${r.name}", color = SuccessGreen, fontWeight = FontWeight.SemiBold)
                    Text(r.outletCategory, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }

        coveredEmployees.forEach { vacant ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                Text("⚠ Covering: ${vacant.name} (${vacant.role}, ${vacant.geoLabel})", color = WarningAmber, fontWeight = FontWeight.SemiBold)
                Text("This position is currently vacant — their duties route to you.", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
        }

        if (lowStock.isNotEmpty()) {
            Text("Stock alerts", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            lowStock.forEach { level ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text("${level.productName} low at ${level.warehouseName}", color = DangerRed, fontWeight = FontWeight.SemiBold)
                    Text("${"%.1f".format(level.quantityOnHand)} ${level.unit} left (reorder level: ${"%.0f".format(level.reorderThreshold)})", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }

        if (openComplaints.isNotEmpty()) {
            Text("Open complaints", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            openComplaints.forEach { c ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text(c.subject, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                    Text(if (c.anonymous) "Anonymous · ${c.fromRole}" else "${c.fromName} · ${c.fromRole}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }
    }
}
