package com.abm.erp.ui.production

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.core.SubModuleGrid
import com.abm.erp.core.SubModuleItem
import com.abm.erp.core.BackToSubMenuLink
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

class ProductionViewModel : ViewModel() {
    val lots = MockRepository.lots
    val batches = MockRepository.batches
    fun movingAverageCost(material: String) = MockRepository.movingAverageCost(material)
    fun receiveGatepass(batchId: String) = MockRepository.receiveGatepass(batchId)

    // ---- Module 2: Manufacturing & Production ----
    val boms = MockRepository.billOfMaterials
    val productionOrders = MockRepository.productionOrders
    val qualityChecks = MockRepository.qualityChecks
    val productionLosses = MockRepository.productionLosses
    val machineLogs = MockRepository.machineLogs
    fun createBom(name: String, lines: List<com.abm.erp.data.BomLine>, laborCost: Double, overheadCost: Double) =
        MockRepository.createBom(name, lines, laborCost, overheadCost)
    fun estimatedUnitCost(bom: com.abm.erp.data.BillOfMaterials) = MockRepository.estimatedUnitCost(bom)
    fun createProductionOrder(bomId: String, productName: String, targetQty: Double, scheduledDate: java.time.LocalDateTime) =
        MockRepository.createProductionOrder(bomId, productName, targetQty, scheduledDate)
    fun updateProductionOrderStatus(id: String, status: String) = MockRepository.updateProductionOrderStatus(id, status)
    fun recordQualityCheck(batchId: String, result: String, notes: String) = MockRepository.recordQualityCheck(batchId, result, notes)
    fun recordProductionLoss(batchId: String, qtyLost: Double, reason: String) = MockRepository.recordProductionLoss(batchId, qtyLost, reason)
    fun recordMachineLog(machineName: String, batchId: String?, hours: Double, notes: String) = MockRepository.recordMachineLog(machineName, batchId, hours, notes)
}

@Composable
fun ProductionScreen(vm: ProductionViewModel = viewModel()) {
    var tab by remember { mutableStateOf<Int?>(null) }
    val subItems = listOf(
        SubModuleItem("materials", "Materials", "🧱", 0xFFFFB020, 0xFFE08A00),
        SubModuleItem("batches", "Batches", "⚙️", 0xFF4E9CFF, 0xFF2E6FE0),
        SubModuleItem("hrm", "Factory HRM", "👷", 0xFF3DDC97, 0xFF1FA972),
        SubModuleItem("bom", "Bill of Materials", "📐", 0xFF8A6DFF, 0xFF5B3FE0),
        SubModuleItem("porder", "Production Orders", "🏭", 0xFF3FA9F5, 0xFF1D78C7),
        SubModuleItem("qc", "Quality Control", "✅", 0xFF3DDC97, 0xFF1FA972),
        SubModuleItem("ploss", "Production Loss", "📉", 0xFFFF5252, 0xFFC62828),
        SubModuleItem("machine", "Machine Utilization", "🛠️", 0xFFFFB300, 0xFFE08600),
    )
    Column(Modifier.fillMaxSize()) {
        com.abm.erp.core.ModuleGradientHeader("Factory Production Wing", "⚙️", 0xFFE85D4A, 0xFFC03A2B)
        Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Isolated from marketing operations", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        if (tab == null) {
            SubModuleGrid(subItems) { key -> tab = when (key) { "materials" -> 0; "batches" -> 1; "hrm" -> 2; "bom" -> 3; "porder" -> 4; "qc" -> 5; "ploss" -> 6; else -> 7 } }
        } else {
            BackToSubMenuLink(onClick = { tab = null })
            when (tab) {
                0 -> MaterialsTab(vm)
                1 -> BatchesTab(vm)
                2 -> FactoryHrmTab()
                3 -> BomTab(vm)
                4 -> ProductionOrdersTab(vm)
                5 -> QualityControlTab(vm)
                6 -> ProductionLossTab(vm)
                else -> MachineUtilizationTab(vm)
            }
        }
        }
    }
}

@Composable
private fun MaterialsTab(vm: ProductionViewModel) {
    val lots by vm.lots.collectAsState()
    val materials = lots.map { it.materialName }.distinct()

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Moving average cost", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                materials.forEach { m ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(m, style = MaterialTheme.typography.bodyLarge)
                        Text("৳${"%.2f".format(vm.movingAverageCost(m))}/kg", color = ElectricCyan, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        item { Text("Purchase lots", style = MaterialTheme.typography.titleMedium) }
        items(lots) { lot ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("${lot.materialName} — ${lot.qtyKg}kg", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text("Cost ৳${lot.costPerKg}/kg · purchased ${lot.purchasedOn}", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun BatchesTab(vm: ProductionViewModel) {
    val batches by vm.batches.collectAsState()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(batches) { b ->
            val yieldPct = (b.outputKg / b.inputKg) * 100
            val yieldColor = if (yieldPct >= 85) SuccessGreen else if (yieldPct >= 70) WarningAmber else DangerRed
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${b.id} · ${b.cycleType}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${"%.0f".format(yieldPct)}%", fontWeight = FontWeight.Bold, color = yieldColor)
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "ProductionBatch", entityId = b.id, entityLabel = "${b.id} — ${b.cycleType}",
                            shareText = "Batch ${b.id} (${b.cycleType})\nInput: ${b.inputKg}kg → Output: ${b.outputKg}kg\nYield: ${"%.0f".format(yieldPct)}%",
                            csvHeader = "BatchId,CycleType,InputKg,OutputKg,YieldPct", csvRow = com.abm.erp.core.toCsvRow(b.id, b.cycleType, b.inputKg, b.outputKg, "%.0f".format(yieldPct)),
                        )
                    }
                }
                Text("Input ${b.inputKg}kg → Output ${b.outputKg}kg", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(6.dp))
                androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth().height(7.dp).background(androidx.compose.ui.graphics.Color(0xFFEEF1F5), androidx.compose.foundation.shape.RoundedCornerShape(999.dp))) {
                    androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth((yieldPct / 100).toFloat().coerceIn(0f, 1f)).fillMaxHeight().background(yieldColor, androidx.compose.foundation.shape.RoundedCornerShape(999.dp)))
                }
                Spacer(Modifier.height(8.dp))
                if (b.gatepassReceived) {
                    Text("✓ Gatepass received by Central Warehouse Incharge", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                } else {
                    Button(onClick = { vm.receiveGatepass(b.id) }, colors = ButtonDefaults.buttonColors(containerColor = DeepIndigo)) {
                        Text("Tap \"Receive\" — release from production")
                    }
                }
            }
        }
    }
}

@Composable
private fun FactoryHrmTab() {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Factory attendance lock", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "Laborer check-in is only accepted when both are true: device is on the factory WiFi IP allowlist, and GPS falls inside the factory geofence polygon. Either failing marks the day as unapproved for payroll purposes.",
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(12.dp))
        listOf(
            Triple("Laborer 12", true, true),
            Triple("Laborer 27", true, false),
            Triple("Laborer 33", false, true),
        ).forEach { (name, wifi, geo) ->
            val ok = wifi && geo
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(name, style = MaterialTheme.typography.bodyLarge)
                Text(
                    if (ok) "✓ Valid check-in" else "✗ Flagged (wifi=$wifi, geofence=$geo)",
                    color = if (ok) SuccessGreen else DangerRed,
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        }
    }
}

@Composable
private fun BomLineBuilder(lines: MutableList<com.abm.erp.data.BomLine>) {
    var material by remember { mutableStateOf("") }
    var qtyText by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("kg") }

    Column {
        lines.forEachIndexed { idx, l ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${l.rawMaterialName}: ${l.qtyPerUnit} ${l.unit}/unit", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { lines.removeAt(idx) }) { Text("✕", color = DangerRed) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(value = material, onValueChange = { material = it }, label = { Text("Raw material") }, modifier = Modifier.weight(2f))
            OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Qty/unit") }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Button(
            onClick = {
                val qty = qtyText.toDoubleOrNull() ?: return@Button
                if (material.isBlank()) return@Button
                lines.add(com.abm.erp.data.BomLine(material, qty, unit))
                material = ""; qtyText = ""
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("+ Add material line") }
    }
}

@Composable
private fun BomTab(vm: ProductionViewModel) {
    val boms by vm.boms.collectAsState()
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New BOM") }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(boms) { b ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(b.finishedProductName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    b.lines.forEach { l -> Text("  ${l.rawMaterialName}: ${l.qtyPerUnit} ${l.unit}/unit", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                    Spacer(Modifier.height(4.dp))
                    Text("Estimated unit cost: ৳${"%.2f".format(vm.estimatedUnitCost(b))}", color = ElectricCyan, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelSmall)
                }
            }
            if (boms.isEmpty()) item { Text("এখনো কোনো BOM নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var name by remember { mutableStateOf("") }
                var labor by remember { mutableStateOf("") }
                var overhead by remember { mutableStateOf("") }
                val lines = remember { mutableStateListOf<com.abm.erp.data.BomLine>() }
                Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
                    Text("New Bill of Materials", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Finished product name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    BomLineBuilder(lines)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = labor, onValueChange = { labor = it }, label = { Text("Labor cost/unit (৳)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = overhead, onValueChange = { overhead = it }, label = { Text("Overhead cost/unit (৳)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            vm.createBom(name, lines.toList(), labor.toDoubleOrNull() ?: 0.0, overhead.toDoubleOrNull() ?: 0.0)
                            showNew = false
                        },
                        enabled = name.isNotBlank() && lines.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Create BOM") }
                }
            }
        }
    }
}

@Composable
private fun ProductionOrdersTab(vm: ProductionViewModel) {
    val orders by vm.productionOrders.collectAsState()
    val boms by vm.boms.collectAsState()
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "OrderNo,Product,Target,Status\n"
                    val rows = orders.joinToString("\n") { o -> com.abm.erp.core.toCsvRow(o.orderNo, o.finishedProductName, o.targetQty, o.status) }
                    val file = java.io.File(context.getExternalFilesDir(null), "production_orders_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Production Orders (${orders.size})\n" + orders.take(20).joinToString("\n") { "${it.orderNo} — ${it.finishedProductName} (${it.status})" }
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                    try { context.startActivity(android.content.Intent.createChooser(intent, "Production Orders")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                },
            )
        }
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth(), enabled = boms.isNotEmpty()) { Text("+ New Production Order") }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(orders) { o ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${o.orderNo} — ${o.finishedProductName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("Target: ${o.targetQty} · scheduled ${o.scheduledDate.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(o.status, color = when (o.status) { "COMPLETED" -> SuccessGreen; "CANCELLED" -> DangerRed; else -> WarningAmber }, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            val context = androidx.compose.ui.platform.LocalContext.current
                            TextButton(onClick = {
                                try {
                                    val file = com.abm.erp.core.exportProductionOrderPdf(context, o)
                                    com.abm.erp.core.shareStructuredPdf(context, file, "Production ${o.orderNo}")
                                } catch (e: Exception) {
                                    android.widget.Toast.makeText(context, "Production Sheet PDF তৈরি ব্যর্থ হয়েছে: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                                }
                            }) { Text("📄", style = MaterialTheme.typography.labelSmall) }
                            com.abm.erp.core.UniversalActionMenu(
                                moduleReference = "ProductionOrder", entityId = o.id, entityLabel = o.orderNo,
                                shareText = "Production Order ${o.orderNo} — ${o.finishedProductName}\nTarget: ${o.targetQty}\nScheduled: ${o.scheduledDate.toLocalDate()}\nStatus: ${o.status}",
                                csvHeader = "OrderNo,Product,Target,Scheduled,Status", csvRow = com.abm.erp.core.toCsvRow(o.orderNo, o.finishedProductName, o.targetQty, o.scheduledDate.toLocalDate(), o.status),
                            )
                        }
                    }
                    if (o.status in setOf("PLANNED", "IN_PROGRESS")) {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (o.status == "PLANNED") Button(onClick = { vm.updateProductionOrderStatus(o.id, "IN_PROGRESS") }) { Text("Start") }
                            if (o.status == "IN_PROGRESS") Button(onClick = { vm.updateProductionOrderStatus(o.id, "COMPLETED") }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) { Text("Complete") }
                            OutlinedButton(onClick = { vm.updateProductionOrderStatus(o.id, "CANCELLED") }) { Text("Cancel", color = DangerRed) }
                        }
                    }
                }
            }
            if (orders.isEmpty()) item { Text("এখনো কোনো Production Order নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var selectedBom by remember { mutableStateOf<com.abm.erp.data.BillOfMaterials?>(null) }
                var expanded by remember { mutableStateOf(false) }
                var qtyText by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp)) {
                    Text("New Production Order", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedBom?.finishedProductName ?: "Select BOM") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            boms.forEach { b -> DropdownMenuItem(text = { Text(b.finishedProductName) }, onClick = { selectedBom = b; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Target quantity") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val b = selectedBom ?: return@Button
                            val qty = qtyText.toDoubleOrNull() ?: return@Button
                            vm.createProductionOrder(b.id, b.finishedProductName, qty, java.time.LocalDateTime.now())
                            showNew = false
                        },
                        enabled = selectedBom != null && qtyText.toDoubleOrNull() != null,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Create Order") }
                }
            }
        }
    }
}

@Composable
private fun QualityControlTab(vm: ProductionViewModel) {
    val checks by vm.qualityChecks.collectAsState()
    val batches by vm.batches.collectAsState()
    var selectedBatch by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("PASS") }
    var notes by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Record Quality Check", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(batches.firstOrNull { it.id == selectedBatch }?.cycleType ?: "Select batch")
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    batches.forEach { b -> DropdownMenuItem(text = { Text(b.cycleType) }, onClick = { selectedBatch = b.id; expanded = false }) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = result == "PASS", onClick = { result = "PASS" }, label = { Text("PASS") })
                FilterChip(selected = result == "FAIL", onClick = { result = "FAIL" }, label = { Text("FAIL") })
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = { val b = selectedBatch ?: return@Button; vm.recordQualityCheck(b, result, notes); notes = "" },
                enabled = selectedBatch != null,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Save Quality Check") }
        }
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(checks) { c ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(c.notes.ifBlank { "—" }, style = MaterialTheme.typography.bodySmall)
                        Text(c.result, color = if (c.result == "PASS") SuccessGreen else DangerRed, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProductionLossTab(vm: ProductionViewModel) {
    val losses by vm.productionLosses.collectAsState()
    val batches by vm.batches.collectAsState()
    var selectedBatch by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(false) }
    var qtyText by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Record Production Loss / Wastage", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(batches.firstOrNull { it.id == selectedBatch }?.cycleType ?: "Select batch")
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    batches.forEach { b -> DropdownMenuItem(text = { Text(b.cycleType) }, onClick = { selectedBatch = b.id; expanded = false }) }
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Qty lost (kg)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    val b = selectedBatch ?: return@Button
                    val qty = qtyText.toDoubleOrNull() ?: return@Button
                    vm.recordProductionLoss(b, qty, reason)
                    qtyText = ""; reason = ""
                },
                enabled = selectedBatch != null && qtyText.toDoubleOrNull() != null,
                colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Record Loss") }
        }
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(losses) { l ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${l.qtyLost} kg lost — ${l.reason}", style = MaterialTheme.typography.bodySmall)
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "ProductionLoss", entityId = l.id, entityLabel = "Loss — ${l.batchId}",
                            shareText = "Production Loss: ${l.qtyLost} kg\nBatch: ${l.batchId}\nReason: ${l.reason}",
                            csvHeader = "BatchId,QtyLost,Reason", csvRow = com.abm.erp.core.toCsvRow(l.batchId, l.qtyLost, l.reason),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MachineUtilizationTab(vm: ProductionViewModel) {
    val logs by vm.machineLogs.collectAsState()
    var machineName by remember { mutableStateOf("") }
    var hoursText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Log Machine Usage", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = machineName, onValueChange = { machineName = it }, label = { Text("Machine name") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = hoursText, onValueChange = { hoursText = it }, label = { Text("Hours used") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    val hours = hoursText.toDoubleOrNull() ?: return@Button
                    if (machineName.isBlank()) return@Button
                    vm.recordMachineLog(machineName, null, hours, notes)
                    machineName = ""; hoursText = ""; notes = ""
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Save Log") }
        }
        Spacer(Modifier.height(14.dp))
        val totalsByMachine = logs.groupBy { it.machineName }.mapValues { it.value.sumOf { l -> l.hoursUsed } }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(totalsByMachine.entries.toList()) { (name, hours) ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("${"%.1f".format(hours)} hrs total", color = ElectricCyan, fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (logs.isEmpty()) item { Text("এখনো কোনো machine log নেই।", color = TextSecondary) }
        }
    }
}
