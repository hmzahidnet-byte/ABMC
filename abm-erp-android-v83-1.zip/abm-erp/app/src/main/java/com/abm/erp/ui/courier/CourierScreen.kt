package com.abm.erp.ui.courier

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.core.SubModuleGrid
import com.abm.erp.core.SubModuleItem
import com.abm.erp.core.BackToSubMenuLink
import com.abm.erp.data.MockRepository
import com.abm.erp.data.ShipmentStatus
import com.abm.erp.theme.ElectricCyan
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

class CourierViewModel : ViewModel() {
    val couriers = MockRepository.couriers
    val shipments = MockRepository.shipments
    fun bookShipment(courierId: String, dealerOrRetailer: String) = MockRepository.bookShipment(courierId, dealerOrRetailer)
    fun refreshShipmentStatus(id: String) = MockRepository.refreshShipmentStatus(id)
    fun setShipmentStatus(id: String, status: ShipmentStatus) = MockRepository.setShipmentStatus(id, status)

    // ---- Module 13: Vehicle Tracking ----
    val vehicles = MockRepository.vehicles
    val vehicleLocationPings = MockRepository.vehicleLocationPings
    fun createVehicle(registrationNo: String, vehicleType: String, driverName: String, driverPhone: String) =
        MockRepository.createVehicle(registrationNo, vehicleType, driverName, driverPhone)
    fun recordVehiclePing(vehicleId: String, lat: Double, lng: Double, speedKmh: Double) =
        MockRepository.recordVehiclePing(vehicleId, lat, lng, speedKmh)
    fun latestPingFor(vehicleId: String) = MockRepository.latestPingFor(vehicleId)
    fun canCreateVehicle() = com.abm.erp.data.PermissionManager.canCurrentUser("courier", com.abm.erp.data.PermissionAction.CREATE)
}

@Composable
fun CourierScreen(vm: CourierViewModel = viewModel()) {
    val couriers by vm.couriers.collectAsState()
    val shipments by vm.shipments.collectAsState()
    var dealerText by remember { mutableStateOf("") }
    var selectedCourier by remember { mutableStateOf<String?>(null) }
    var statusMenuFor by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf<Int?>(null) }
    val subItems = listOf(
        SubModuleItem("book", "Book Shipment", "🚚", 0xFF4E9CFF, 0xFF2E6FE0),
        SubModuleItem("track", "Track Shipments", "📍", 0xFF3DDC97, 0xFF1FA972),
        SubModuleItem("vehicle", "Vehicle Tracking", "🚛", 0xFF8A6DFF, 0xFF5B3FE0),
    )

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Courier & Logistics", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        if (tab == null) {
            SubModuleGrid(subItems) { key -> tab = when (key) { "book" -> 0; "track" -> 1; else -> 2 } }
        } else if (tab == 2) {
            BackToSubMenuLink(onClick = { tab = null })
            VehicleTrackingTab(vm)
        } else {
            BackToSubMenuLink(onClick = { tab = null })
            LazyColumn(Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (tab == 0) {
        item {
            Text("Courier partners", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            couriers.forEach { c ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(c.name, color = TextPrimary)
                    Text(if (c.hasApi) "API connected" else "Manual (no API)", color = if (c.hasApi) SuccessGreen else TextSecondary, style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        item {
            Spacer(Modifier.height(6.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Book a new shipment", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = dealerText, onValueChange = { dealerText = it }, label = { Text("Dealer / retailer name") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Box {
                    OutlinedButton(onClick = { statusMenuFor = "courier-picker" }, modifier = Modifier.fillMaxWidth()) {
                        Text(couriers.firstOrNull { it.id == selectedCourier }?.name ?: "Choose courier…")
                    }
                    DropdownMenu(expanded = statusMenuFor == "courier-picker", onDismissRequest = { statusMenuFor = null }) {
                        couriers.forEach { c ->
                            DropdownMenuItem(text = { Text(c.name) }, onClick = { selectedCourier = c.id; statusMenuFor = null })
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val courierId = selectedCourier ?: couriers.firstOrNull()?.id ?: return@Button
                        if (dealerText.isBlank()) return@Button
                        vm.bookShipment(courierId, dealerText)
                        dealerText = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Book shipment") }
            }
        }
        } else {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text("Shipments", style = MaterialTheme.typography.titleMedium)
                val context = androidx.compose.ui.platform.LocalContext.current
                com.abm.erp.core.ModuleActionBar(
                    onExport = {
                        val header = "DealerOrRetailer,Status\n"
                        val rows = shipments.joinToString("\n") { s -> com.abm.erp.core.toCsvRow(s.dealerOrRetailer, s.status) }
                        val file = java.io.File(context.getExternalFilesDir(null), "shipments_${System.currentTimeMillis()}.csv")
                        file.writeText(header + rows)
                        android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                    },
                    onShare = {
                        val summary = "Shipments (${shipments.size})\n" + shipments.take(20).joinToString("\n") { "${it.dealerOrRetailer} — ${it.status}" }
                        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                        try { context.startActivity(android.content.Intent.createChooser(intent, "Shipments")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                    },
                )
            }
        }
        items(shipments, key = { it.id }) { s ->
            val courier = couriers.firstOrNull { it.id == s.courierId }
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(s.dealerOrRetailer, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Row {
                        Text(s.status.name.replace("_", " "), color = if (s.status == ShipmentStatus.DELIVERED) SuccessGreen else ElectricCyan, style = MaterialTheme.typography.labelSmall)
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Shipment", entityId = s.id, entityLabel = s.dealerOrRetailer,
                            shareText = "Shipment: ${s.dealerOrRetailer}\nCourier: ${courier?.name ?: s.courierId}\nStatus: ${s.status}${s.trackingId?.let { "\nTracking: $it" } ?: ""}",
                            csvHeader = "DealerOrRetailer,Courier,TrackingId,Status",
                            csvRow = com.abm.erp.core.toCsvRow(s.dealerOrRetailer, courier?.name ?: s.courierId, s.trackingId ?: "", s.status),
                        )
                    }
                }
                Text("${courier?.name ?: s.courierId}${s.trackingId?.let { " · Tracking: $it" } ?: ""}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                Spacer(Modifier.height(8.dp))
                if (courier?.hasApi == true) {
                    Button(onClick = { vm.refreshShipmentStatus(s.id) }) { Text("🔄 Refresh API status") }
                } else {
                    Box {
                        OutlinedButton(onClick = { statusMenuFor = s.id }) { Text("Update status") }
                        DropdownMenu(expanded = statusMenuFor == s.id, onDismissRequest = { statusMenuFor = null }) {
                            ShipmentStatus.values().forEach { st ->
                                DropdownMenuItem(text = { Text(st.name.replace("_", " ")) }, onClick = { vm.setShipmentStatus(s.id, st); statusMenuFor = null })
                            }
                        }
                    }
                }
            }
        }
        item {
            Text(
                "API couriers auto-refresh their stage; traditional couriers without an API are updated by hand by whoever hands off the package.",
                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
            )
        }
        }
    }
    }
}
}

@Composable
private fun VehicleTrackingTab(vm: CourierViewModel) {
    val vehicles by vm.vehicles.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var pingFor by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        if (vm.canCreateVehicle()) {
            Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add Vehicle") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(vehicles, key = { it.id }) { v ->
                val latestPing by vm.latestPingFor(v.id).collectAsState(initial = null)
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${v.registrationNo} (${v.vehicleType})", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("Driver: ${v.driverName.ifBlank { "—" }} · ${v.driverPhone}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            latestPing?.let { p ->
                                Text("সর্বশেষ অবস্থান: ${"%.4f".format(p.lat)}, ${"%.4f".format(p.lng)} · ${"%.0f".format(p.speedKmh)} km/h", style = MaterialTheme.typography.labelSmall, color = ElectricCyan)
                            } ?: Text("এখনো কোনো GPS ping পাওয়া যায়নি।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        TextButton(onClick = { pingFor = v.id }) { Text("📍 Log position") }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Vehicle", entityId = v.id, entityLabel = v.registrationNo,
                            shareText = "Vehicle: ${v.registrationNo} (${v.vehicleType})\nDriver: ${v.driverName} · ${v.driverPhone}",
                            csvHeader = "RegistrationNo,Type,Driver,Phone",
                            csvRow = com.abm.erp.core.toCsvRow(v.registrationNo, v.vehicleType, v.driverName, v.driverPhone),
                        )
                    }
                }
            }
            if (vehicles.isEmpty()) item { Text("এখনো কোনো vehicle registered নেই।", color = TextSecondary) }
        }
    }

    if (showAdd) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showAdd = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var reg by remember { mutableStateOf("") }
                var type by remember { mutableStateOf("Truck") }
                var driver by remember { mutableStateOf("") }
                var phone by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp)) {
                    Text("Add Vehicle", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = reg, onValueChange = { reg = it }, label = { Text("Registration No.") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Truck", "Van", "Motorcycle").forEach { t -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) }) }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = driver, onValueChange = { driver = it }, label = { Text("Driver name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Driver phone") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { if (vm.createVehicle(reg, type, driver, phone) != null) showAdd = false }, enabled = reg.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Register Vehicle") }
                }
            }
        }
    }

    pingFor?.let { vehicleId ->
        androidx.compose.ui.window.Dialog(onDismissRequest = { pingFor = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var latText by remember { mutableStateOf("") }
                var lngText by remember { mutableStateOf("") }
                var speedText by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp)) {
                    Text("Log Vehicle Position", style = MaterialTheme.typography.titleMedium)
                    Text("বর্তমান GPS lat/lng ম্যানুয়ালি দিন (পরবর্তীতে auto-GPS wiring যোগ করা যাবে)।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = latText, onValueChange = { latText = it }, label = { Text("Latitude") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = lngText, onValueChange = { lngText = it }, label = { Text("Longitude") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = speedText, onValueChange = { speedText = it }, label = { Text("Speed (km/h)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val lat = latText.toDoubleOrNull() ?: return@Button
                            val lng = lngText.toDoubleOrNull() ?: return@Button
                            vm.recordVehiclePing(vehicleId, lat, lng, speedText.toDoubleOrNull() ?: 0.0)
                            pingFor = null
                        },
                        enabled = latText.toDoubleOrNull() != null && lngText.toDoubleOrNull() != null,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Save Position") }
                }
            }
        }
    }
}
