package com.abm.erp.ui.reports

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.LedgerEntryType
import com.abm.erp.data.MockRepository
import com.abm.erp.data.OrderStage
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

class ReportsViewModel : ViewModel() {
    val orders = MockRepository.orders
    val dealers = MockRepository.dealers
    val stockLevels = InventoryRepository.stockLevels
    val ledgerEntries = MockRepository.ledgerEntries
    val payroll = MockRepository.payroll
    val batches = MockRepository.batches

    /**
     * Module 17 — Excel Export. Writes a real CSV (opens directly in Excel/
     * Sheets) to this device's app-external-files folder — same storage
     * location BackupManager already uses for its local backup copy, so no
     * new permissions or FileProvider setup are needed. Returns the saved
     * file's absolute path so the UI can show the person where it landed.
     */
    fun exportDealersCsv(context: android.content.Context): String {
        val header = "Name,Zone,Classification,Due Balance,Credit Limit,90-Day Sales\n"
        val rows = dealers.value.joinToString("\n") { d -> com.abm.erp.core.toCsvRow(d.name, d.zone, d.classification, d.dueBalance, d.creditLimit, d.salesLast90Days) }
        val file = java.io.File(context.getExternalFilesDir(null), "dealers_report_${System.currentTimeMillis()}.csv")
        file.writeText(header + rows)
        return file.absolutePath
    }

    fun exportStockCsv(context: android.content.Context): String {
        val header = "Product,Warehouse,Quantity On Hand,Reorder Threshold,Low Stock\n"
        val rows = stockLevels.value.joinToString("\n") { s -> com.abm.erp.core.toCsvRow(s.productName, s.warehouseName, s.quantityOnHand, s.reorderThreshold, s.isLowStock) }
        val file = java.io.File(context.getExternalFilesDir(null), "stock_report_${System.currentTimeMillis()}.csv")
        file.writeText(header + rows)
        return file.absolutePath
    }

    fun exportLedgerCsv(context: android.content.Context): String {
        val header = "Type,Category,Description,Amount,Recorded By,Date\n"
        val rows = ledgerEntries.value.joinToString("\n") { e -> com.abm.erp.core.toCsvRow(e.type, e.category, e.description, e.amount, e.recordedBy, e.recordedAt) }
        val file = java.io.File(context.getExternalFilesDir(null), "ledger_report_${System.currentTimeMillis()}.csv")
        file.writeText(header + rows)
        return file.absolutePath
    }

    /**
     * Module 17 — PDF Export. Uses Android's own built-in
     * android.graphics.pdf.PdfDocument (no external library needed) to draw
     * a simple one-page text report — a real, valid, openable PDF file,
     * not a placeholder. Saved next to the CSV exports in this device's
     * app-external-files folder.
     */
    fun exportSummaryPdf(context: android.content.Context): String {
        val pdfDocument = android.graphics.pdf.PdfDocument()
        val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 at 72dpi
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas
        val titlePaint = android.graphics.Paint().apply { textSize = 20f; isFakeBoldText = true }
        val bodyPaint = android.graphics.Paint().apply { textSize = 12f }
        var y = 50f
        canvas.drawText("ABM Corporation — Business Summary Report", 40f, y, titlePaint)
        y += 30f
        canvas.drawText(java.time.LocalDateTime.now().toString(), 40f, y, bodyPaint)
        y += 30f
        canvas.drawText("Total Dealers: ${dealers.value.size}", 40f, y, bodyPaint); y += 20f
        canvas.drawText("Total Due (Dealers): ৳${"%,.0f".format(dealers.value.sumOf { it.dueBalance })}", 40f, y, bodyPaint); y += 20f
        canvas.drawText("90-Day Sales: ৳${"%,.0f".format(dealers.value.sumOf { it.salesLast90Days })}", 40f, y, bodyPaint); y += 20f
        canvas.drawText("Low Stock Items: ${stockLevels.value.count { it.isLowStock }}", 40f, y, bodyPaint); y += 20f
        canvas.drawText("Pending Orders: ${orders.value.count { it.stage != com.abm.erp.data.OrderStage.FULFILLED && it.stage != com.abm.erp.data.OrderStage.REJECTED }}", 40f, y, bodyPaint); y += 30f
        canvas.drawText("— Top 10 Dealers by 90-Day Sales —", 40f, y, titlePaint); y += 24f
        dealers.value.sortedByDescending { it.salesLast90Days }.take(10).forEach { d ->
            canvas.drawText("${d.name} (${d.zone}): ৳${"%,.0f".format(d.salesLast90Days)}, due ৳${"%,.0f".format(d.dueBalance)}", 40f, y, bodyPaint)
            y += 18f
        }
        pdfDocument.finishPage(page)
        val file = java.io.File(context.getExternalFilesDir(null), "summary_report_${System.currentTimeMillis()}.pdf")
        pdfDocument.writeTo(java.io.FileOutputStream(file))
        pdfDocument.close()
        return file.absolutePath
    }
}

/**
 * RSM+ only (see ROLE_MODULES). Every section here reads from a repository
 * that already exists — Reports doesn't own any data of its own, it's a
 * summary lens over Sales, Inventory, Ledger, Dealers, Payroll, and
 * Production, which is why it made sense to build last, once those were done.
 */
@Composable
fun ReportsScreen(vm: ReportsViewModel = viewModel()) {
    val allOrders by vm.orders.collectAsState()
    val allDealers by vm.dealers.collectAsState()
    val allStockLevels by vm.stockLevels.collectAsState()
    val allLedgerEntries by vm.ledgerEntries.collectAsState()
    val payroll by vm.payroll.collectAsState()
    val batches by vm.batches.collectAsState()

    // ---- Module 17: Reporting Framework — Date/Dealer/Territory/Warehouse/Status filters ----
    // Every section below reads the FILTERED lists, not the raw StateFlows,
    // so one filter bar controls the whole Reports screen instead of each
    // section needing its own.
    var dateRangeDays by remember { mutableStateOf(0) } // 0 = all-time
    var territoryFilter by remember { mutableStateOf<String?>(null) }
    var dealerFilter by remember { mutableStateOf<String?>(null) }
    var warehouseFilter by remember { mutableStateOf<String?>(null) }
    var statusFilter by remember { mutableStateOf<String?>(null) } // "PENDING" | "FULFILLED" | null = all
    val zones = remember(allDealers) { allDealers.map { it.zone }.distinct().sorted() }
    val warehouseNames = remember(allStockLevels) { allStockLevels.map { it.warehouseName }.distinct().sorted() }
    val cutoff = if (dateRangeDays > 0) java.time.LocalDateTime.now().minusDays(dateRangeDays.toLong()) else null

    val dealers = allDealers.filter { d ->
        (territoryFilter == null || d.zone == territoryFilter) && (dealerFilter == null || d.id == dealerFilter)
    }
    val dealerIdsInScope = dealers.map { it.id }.toSet()
    val orders = allOrders.filter { o ->
        (cutoff == null || o.loggedAt.isAfter(cutoff)) &&
            (territoryFilter == null || o.zone == territoryFilter) &&
            (dealerFilter == null || o.routedDealerId == dealerFilter) &&
            (statusFilter == null || (if (statusFilter == "FULFILLED") o.stage == OrderStage.FULFILLED else o.stage != OrderStage.FULFILLED))
    }
    val ledgerEntries = allLedgerEntries.filter { e ->
        (cutoff == null || e.recordedAt.isAfter(cutoff)) && (territoryFilter == null || e.division == territoryFilter)
    }
    val stockLevels = allStockLevels.filter { s -> warehouseFilter == null || s.warehouseName == warehouseFilter }

    val totalSalesValue = orders.sumOf { it.amount }
    val fulfilledCount = orders.count { it.stage == OrderStage.FULFILLED }
    val pendingCount = orders.count { it.stage != OrderStage.FULFILLED && it.stage != OrderStage.REJECTED }

    val lowStockCount = stockLevels.count { it.isLowStock }
    val totalDealerSales = dealers.sumOf { it.salesLast90Days }
    val totalDealerDue = dealers.sumOf { it.dueBalance }

    val ledgerIn = ledgerEntries.filter { it.type == LedgerEntryType.IN }.sumOf { it.amount }
    val ledgerOut = ledgerEntries.filter { it.type == LedgerEntryType.OUT }.sumOf { it.amount }

    val totalPayroll = payroll.sumOf { it.netPayable }
    val pendingGatepass = batches.count { !it.gatepassReceived }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Reports", style = MaterialTheme.typography.headlineSmall)
        Text("Company-wide summary, pulled live from every module.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Spacer(Modifier.height(14.dp))

        ReportSection("🔎 Filters") {
            Text("Date range", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(0 to "All time", 7 to "7 days", 30 to "30 days", 90 to "90 days").forEach { (days, label) ->
                    FilterChip(selected = dateRangeDays == days, onClick = { dateRangeDays = days }, label = { Text(label) })
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Territory / Zone", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            var zoneExpanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { zoneExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text(territoryFilter ?: "All territories") }
                DropdownMenu(expanded = zoneExpanded, onDismissRequest = { zoneExpanded = false }) {
                    DropdownMenuItem(text = { Text("All territories") }, onClick = { territoryFilter = null; zoneExpanded = false })
                    zones.forEach { z -> DropdownMenuItem(text = { Text(z) }, onClick = { territoryFilter = z; zoneExpanded = false }) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Dealer", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            var dealerExpanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { dealerExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(allDealers.firstOrNull { it.id == dealerFilter }?.name ?: "All dealers")
                }
                DropdownMenu(expanded = dealerExpanded, onDismissRequest = { dealerExpanded = false }) {
                    DropdownMenuItem(text = { Text("All dealers") }, onClick = { dealerFilter = null; dealerExpanded = false })
                    allDealers.forEach { d -> DropdownMenuItem(text = { Text(d.name) }, onClick = { dealerFilter = d.id; dealerExpanded = false }) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Warehouse", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            var warehouseExpanded by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { warehouseExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text(warehouseFilter ?: "All warehouses") }
                DropdownMenu(expanded = warehouseExpanded, onDismissRequest = { warehouseExpanded = false }) {
                    DropdownMenuItem(text = { Text("All warehouses") }, onClick = { warehouseFilter = null; warehouseExpanded = false })
                    warehouseNames.forEach { w -> DropdownMenuItem(text = { Text(w) }, onClick = { warehouseFilter = w; warehouseExpanded = false }) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Order Status", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = statusFilter == null, onClick = { statusFilter = null }, label = { Text("All") })
                FilterChip(selected = statusFilter == "PENDING", onClick = { statusFilter = "PENDING" }, label = { Text("Pending") })
                FilterChip(selected = statusFilter == "FULFILLED", onClick = { statusFilter = "FULFILLED" }, label = { Text("Fulfilled") })
            }
        }
        Spacer(Modifier.height(14.dp))

        ReportSection("📤 Excel Export (CSV)") {
            val context = androidx.compose.ui.platform.LocalContext.current
            var lastExportMsg by remember { mutableStateOf<String?>(null) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { lastExportMsg = "Saved: " + vm.exportDealersCsv(context) }) { Text("Dealers") }
                OutlinedButton(onClick = { lastExportMsg = "Saved: " + vm.exportStockCsv(context) }) { Text("Stock") }
                OutlinedButton(onClick = { lastExportMsg = "Saved: " + vm.exportLedgerCsv(context) }) { Text("Ledger") }
            }
            Spacer(Modifier.height(6.dp))
            Button(onClick = { lastExportMsg = "Saved: " + vm.exportSummaryPdf(context) }, modifier = Modifier.fillMaxWidth()) { Text("📄 Export Summary PDF") }
            Spacer(Modifier.height(6.dp))
            OutlinedButton(
                onClick = {
                    val summaryText = "Reports Summary — ${java.time.LocalDate.now()}\nOrders: ${orders.size} (৳${"%,.0f".format(totalSalesValue)})\nLow Stock: $lowStockCount\nDealer Sales(90d): ৳${"%,.0f".format(totalDealerSales)} · Due: ৳${"%,.0f".format(totalDealerDue)}"
                    val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, summaryText) }
                    try { context.startActivity(Intent.createChooser(intent, "Reports Summary")) } catch (e: Exception) { lastExportMsg = "No app found to share this." }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("🔗 Share Summary") }
            lastExportMsg?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = SuccessGreen, modifier = Modifier.padding(top = 6.dp)) }
        }
        Spacer(Modifier.height(14.dp))

        ReportSection("🛒 Sales") {
            ReportRow("Total orders", "${orders.size}")
            ReportRow("Total value", "৳${"%,.0f".format(totalSalesValue)}")
            ReportRow("Fulfilled", "$fulfilledCount", SuccessGreen)
            ReportRow("In pipeline", "$pendingCount", WarningAmber)
        }

        ReportSection("📦 Inventory") {
            ReportRow("Products tracked", "${stockLevels.map { it.productId }.distinct().size}")
            ReportRow(
                "Low-stock alerts", "$lowStockCount",
                if (lowStockCount > 0) DangerRed else SuccessGreen,
            )
        }

        ReportSection("🏪 Dealers") {
            ReportRow("Active dealers", "${dealers.size}")
            ReportRow("90-day sales", "৳${"%,.0f".format(totalDealerSales)}")
            ReportRow("Total due", "৳${"%,.0f".format(totalDealerDue)}", if (totalDealerDue > totalDealerSales * 0.4) DangerRed else TextPrimary)
        }

        ReportSection("💰 Accounts / Ledger") {
            ReportRow("Money in", "৳${"%,.0f".format(ledgerIn)}", SuccessGreen)
            ReportRow("Money out", "৳${"%,.0f".format(ledgerOut)}", DangerRed)
            ReportRow("Balance", "৳${"%,.0f".format(ledgerIn - ledgerOut)}", fontWeight = FontWeight.Bold)
        }

        ReportSection("💳 HR / Payroll") {
            ReportRow("Employees on this run", "${payroll.size}")
            ReportRow("Total payable", "৳${"%,.0f".format(totalPayroll)}")
        }

        ReportSection("⚙️ Production") {
            ReportRow("Batches this cycle", "${batches.size}")
            ReportRow("Pending gatepass", "$pendingGatepass", if (pendingGatepass > 0) WarningAmber else SuccessGreen)
        }
    }
}

@Composable
private fun ReportSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(8.dp))
        content()
    }
    Spacer(Modifier.height(12.dp))
}

@Composable
private fun ReportRow(label: String, value: String, color: Color = TextPrimary, fontWeight: FontWeight = FontWeight.SemiBold) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = color, fontWeight = fontWeight)
    }
}
