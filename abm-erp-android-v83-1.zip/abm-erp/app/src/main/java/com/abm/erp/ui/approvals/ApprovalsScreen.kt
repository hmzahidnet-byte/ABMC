package com.abm.erp.ui.approvals

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.data.ApprovalStatus
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

class ApprovalsViewModel : ViewModel() {
    val approvals = MockRepository.approvals
    fun setApprovalStatus(id: String, status: ApprovalStatus) = MockRepository.setApprovalStatus(id, status)
    fun escalate(id: String) = MockRepository.escalateApproval(id)
    fun forward(id: String, toEmployeeId: String) = MockRepository.forwardApproval(id, toEmployeeId)
    fun reassign(id: String, toEmployeeId: String) = MockRepository.reassignApproval(id, toEmployeeId)
}

@Composable
fun ApprovalsScreen(vm: ApprovalsViewModel = viewModel()) {
    val approvals by vm.approvals.collectAsState()
    var forwardDialogFor by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Approvals", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(4.dp))
        Text("Leave, discount, and expense requests from designations below you.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "Type,From,Detail,Status\n"
                    val rows = approvals.joinToString("\n") { req -> com.abm.erp.core.toCsvRow(req.type, req.fromEmployee, req.detail, req.status) }
                    val file = java.io.File(context.getExternalFilesDir(null), "approvals_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Approvals (${approvals.size})\n" + approvals.take(20).joinToString("\n") { "${it.type} — ${it.fromEmployee} (${it.status})" }
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                    try { context.startActivity(android.content.Intent.createChooser(intent, "Approvals")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                },
            )
        }
        Spacer(Modifier.height(4.dp))

        if (approvals.isEmpty()) {
            Text("No approval requests right now.", color = TextSecondary)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(approvals, key = { it.id }) { req ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(req.type.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val (label, color) = when (req.status) {
                                ApprovalStatus.PENDING -> "Pending" to WarningAmber
                                ApprovalStatus.APPROVED -> "Approved" to SuccessGreen
                                ApprovalStatus.REJECTED -> "Rejected" to DangerRed
                            }
                            Text(label, color = color, style = MaterialTheme.typography.labelSmall)
                            com.abm.erp.core.UniversalActionMenu(
                                moduleReference = "ApprovalRequest", entityId = req.id, entityLabel = req.type.name,
                                shareText = "${req.type} — ${req.fromEmployee}\n${req.detail}\nStatus: ${req.status}",
                                csvHeader = "Type,From,Detail,Status", csvRow = com.abm.erp.core.toCsvRow(req.type, req.fromEmployee, req.detail, req.status),
                            )
                        }
                    }
                    Text(req.fromEmployee, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(req.detail, style = MaterialTheme.typography.bodyMedium)
                    if (req.escalated) Text("⚠ Escalated", color = WarningAmber, style = MaterialTheme.typography.labelSmall)
                    req.assignedToEmployeeId?.let { Text("→ Forwarded to $it", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                    if (req.status == ApprovalStatus.PENDING) {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.setApprovalStatus(req.id, ApprovalStatus.APPROVED) }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) {
                                Text("Approve")
                            }
                            OutlinedButton(onClick = { vm.setApprovalStatus(req.id, ApprovalStatus.REJECTED) }) {
                                Text("Reject", color = DangerRed)
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { vm.escalate(req.id) }) { Text("⬆ Escalate") }
                            TextButton(onClick = { forwardDialogFor = req.id }) { Text("↪ Forward/Reassign") }
                        }
                    }
                }
            }
        }
    }

    forwardDialogFor?.let { reqId ->
        androidx.compose.ui.window.Dialog(onDismissRequest = { forwardDialogFor = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var employeeId by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp)) {
                    Text("Forward / Reassign", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = employeeId, onValueChange = { employeeId = it }, label = { Text("Employee ID") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { vm.forward(reqId, employeeId); forwardDialogFor = null }, enabled = employeeId.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Confirm") }
                }
            }
        }
    }
}
