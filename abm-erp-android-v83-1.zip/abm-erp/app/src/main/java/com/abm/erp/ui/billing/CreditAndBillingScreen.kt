package com.abm.erp.ui.billing

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.*
import com.abm.erp.data.*
import com.abm.erp.theme.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

class CreditAndBillingViewModel : ViewModel() {
    val dealers = MockRepository.dealers
    val invoices = MockRepository.invoices
    val salesInvoices = MockRepository.salesInvoices
    val payments = MockRepository.payments
    val currentUser get() = MockRepository.currentUser
    fun riskBand(dealer: Dealer) = MockRepository.riskBand(dealer)
    fun updateInvoiceItem(invoiceId: String, index: Int, item: InvoiceLineItem) = MockRepository.updateInvoiceItem(invoiceId, index, item)
    fun setPaymentStatus(id: String, status: PaymentVerificationStatus) = MockRepository.setPaymentStatus(id, status)
    fun approveSalesInvoice(invoiceId: String) = MockRepository.approveSalesInvoice(invoiceId)
    fun deleteSalesInvoice(invoiceId: String) = MockRepository.deleteSalesInvoice(invoiceId)
    fun can(action: PermissionAction) = PermissionManager.can(currentUser.role, "bill", action)

    // ---- Module 4: Sales Management ----
    val quotations = MockRepository.quotations
    val deliveryChallans = MockRepository.deliveryChallans
    val salesReturns = MockRepository.salesReturns
    val discountRules = MockRepository.discountRules

    fun createQuotation(partyId: String, partyName: String, lineItems: List<SalesInvoiceLineItem>, validDays: Long) =
        MockRepository.createQuotation(PartyType.DEALER, partyId, partyName, lineItems, java.time.LocalDateTime.now().plusDays(validDays))
    fun convertQuotation(id: String, zone: String) = MockRepository.convertQuotationToInvoice(id, zone)
    fun cancelQuotation(id: String) = MockRepository.cancelQuotation(id)
    fun duplicateQuotationAction(id: String) = MockRepository.duplicateQuotation(id)

    fun createChallan(invoiceId: String?, partyId: String, partyName: String, lineItems: List<SalesInvoiceLineItem>, vehicleNo: String, driverName: String) =
        MockRepository.createDeliveryChallan(invoiceId, PartyType.DEALER, partyId, partyName, lineItems, vehicleNo, driverName)
    fun updateChallanStatus(id: String, status: String) = MockRepository.updateChallanStatus(id, status)

    fun createReturn(invoiceId: String?, partyId: String, partyName: String, lineItems: List<SalesInvoiceLineItem>, reason: String) =
        MockRepository.createSalesReturn(invoiceId, PartyType.DEALER, partyId, partyName, lineItems, reason)
    fun approveReturn(id: String) = MockRepository.approveSalesReturn(id)
    fun rejectReturn(id: String) = MockRepository.rejectSalesReturn(id)

    fun createPosSale(customerName: String, lineItems: List<SalesInvoiceLineItem>) = MockRepository.createPosSale(customerName, lineItems)

    fun createDiscountRule(label: String, scope: String, minQty: Double, discountPct: Double) =
        MockRepository.createDiscountRule(label, scope, minQty, discountPct)
}

@Composable
fun CreditAndBillingScreen(vm: CreditAndBillingViewModel = viewModel()) {
    var tab by remember { mutableStateOf<Int?>(null) }
    val subItems = listOf(
        SubModuleItem("risk", "Risk Matrix", "⚠️", 0xFFFF7A45, 0xFFE0521E),
        SubModuleItem("voice", "Voice Billing", "🎙️", 0xFFB45CFF, 0xFF7A2EE0),
        SubModuleItem("pay", "Payments", "💳", 0xFF3DDC97, 0xFF1FA972),
        SubModuleItem("quote", "Quotation", "📄", 0xFF4E9CFF, 0xFF2E6FE0),
        SubModuleItem("pos", "POS Billing", "🧮", 0xFFFFB020, 0xFFE08A00),
        SubModuleItem("challan", "Delivery Challan", "🚛", 0xFF3FA9F5, 0xFF1D78C7),
        SubModuleItem("return", "Sales Return", "↩️", 0xFFE85D4A, 0xFFC03A2B),
    )
    Column(Modifier.fillMaxSize()) {
        com.abm.erp.core.ModuleGradientHeader("Credit Risk & Billing", "🧾", 0xFFF5A623, 0xFFE08600)
        Column(Modifier.fillMaxSize().padding(16.dp)) {
        if (tab == null) {
            SubModuleGrid(subItems) { key -> tab = when (key) { "risk" -> 0; "voice" -> 1; "pay" -> 2; "quote" -> 3; "pos" -> 4; "challan" -> 5; else -> 6 } }
        } else {
            BackToSubMenuLink(onClick = { tab = null })
            when (tab) {
                0 -> RiskMatrixTab(vm)
                1 -> VoiceBillingTab(vm)
                2 -> PaymentsTab(vm)
                3 -> QuotationTab(vm)
                4 -> PosBillingTab(vm)
                5 -> DeliveryChallanTab(vm)
                else -> SalesReturnTab(vm)
            }
        }
        }
    }
}

@Composable
private fun RiskMatrixTab(vm: CreditAndBillingViewModel) {
    val dealers by vm.dealers.collectAsState()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(dealers) { d ->
            val band = vm.riskBand(d)
            val color = when (band) { RiskBand.GREEN -> RiskGreen; RiskBand.YELLOW -> RiskYellow; RiskBand.RED -> RiskRed }
            GlassCard(borderColor = color.copy(alpha = 0.6f), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(d.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(d.zone, style = MaterialTheme.typography.labelSmall)
                    }
                    Text(band.name, color = color, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Text("Due: ৳${"%,.0f".format(d.dueBalance)}  ·  Sales (90d): ৳${"%,.0f".format(d.salesLast90Days)}", style = MaterialTheme.typography.bodyMedium)
                val ratio = if (d.salesLast90Days == 0.0) 1f else (d.dueBalance / d.salesLast90Days).toFloat().coerceIn(0f, 1f)
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(progress = ratio, color = color, trackColor = color.copy(alpha = 0.15f), modifier = Modifier.fillMaxWidth())
                if (band == RiskBand.RED) {
                    Spacer(Modifier.height(6.dp))
                    Text("⚠ New order intake locked — due balance exceeds threshold", color = DangerRed, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun VoiceBillingTab(vm: CreditAndBillingViewModel) {
    val invoices by vm.invoices.collectAsState()
    val invoice = invoices.first()
    val dealers by vm.dealers.collectAsState()
    val dealer = dealers.first { it.id == invoice.dealerId }

    var voiceCommand by remember { mutableStateOf("") }
    var lastAgentAction by remember { mutableStateOf<String?>(null) }
    var listening by remember { mutableStateOf(false) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { AgentActivityBanner(lastAgentAction) { lastAgentAction = null } }
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Voice command", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = voiceCommand,
                        onValueChange = { voiceCommand = it },
                        placeholder = { Text("e.g. \"Change quantity to 60kg and bump discount to 7%\"") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyan, unfocusedBorderColor = GlassBorder),
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(onClick = { listening = !listening }) {
                        Icon(Icons.Filled.Mic, contentDescription = "Voice input", tint = if (listening) DangerRed else ElectricCyan)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val result = parseVoiceCommand(voiceCommand, invoice.items.first())
                        if (result != null) {
                            vm.updateInvoiceItem(invoice.id, 0, result)
                            lastAgentAction = "Applied: qty ${result.qty}${result.unit}, discount ${result.discountPct}% on \"${result.name}\""
                        } else {
                            lastAgentAction = "Could not parse that command — edit the fields below manually."
                        }
                        voiceCommand = ""
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = DeepIndigo)
                ) { Text("Apply voice command") }
            }
        }
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Invoice ${invoice.id} · ${dealer.name}", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                invoice.items.forEachIndexed { idx, item ->
                    InvoiceItemRow(item) { updated -> vm.updateInvoiceItem(invoice.id, idx, updated) }
                    Spacer(Modifier.height(8.dp))
                }
                Divider(color = GlassBorder)
                Spacer(Modifier.height(8.dp))
                StatLine("Subtotal", invoice.subtotal)
                StatLine("Previous due carried forward", invoice.previousDue)
                Spacer(Modifier.height(4.dp))
                StatLine("Net Outstanding Balance", invoice.netOutstanding, bold = true)
                Spacer(Modifier.height(12.dp))
                ManualSubmitBar("Confirm & issue invoice") {}
            }
        }
    }
}

/** Very small rule-based parser standing in for real Gemini function-calling; matches the demo command shapes from the brief. */
private fun parseVoiceCommand(command: String, current: InvoiceLineItem): InvoiceLineItem? {
    if (command.isBlank()) return null
    val qtyMatch = Regex("""(\d+(\.\d+)?)\s*kg""", RegexOption.IGNORE_CASE).find(command)
    val discountMatch = Regex("""(\d+(\.\d+)?)\s*%""").find(command)
    if (qtyMatch == null && discountMatch == null) return null
    return current.copy(
        qty = qtyMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: current.qty,
        discountPct = discountMatch?.groupValues?.get(1)?.toDoubleOrNull() ?: current.discountPct,
    )
}

@Composable
private fun InvoiceItemRow(item: InvoiceLineItem, onChange: (InvoiceLineItem) -> Unit) {
    Column {
        DualControlTextField("Item", DualControlValue(item.name, FieldSource.AI), { onChange(item.copy(name = it)) })
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DualControlTextField("Qty (${item.unit})", DualControlValue(item.qty.toString(), FieldSource.AI),
                { onChange(item.copy(qty = it.toDoubleOrNull() ?: item.qty)) }, modifier = Modifier.weight(1f))
            DualControlTextField("Discount %", DualControlValue(item.discountPct.toString(), FieldSource.AI),
                { onChange(item.copy(discountPct = it.toDoubleOrNull() ?: item.discountPct)) }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(4.dp))
        Text("Line total: ৳${"%,.0f".format(item.lineTotal)}", color = ElectricCyan, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun StatLine(label: String, amount: Double, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text("৳${"%,.0f".format(amount)}", fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, color = if (bold) ElectricCyan else TextPrimary)
    }
}

@Composable
private fun PaymentsTab(vm: CreditAndBillingViewModel) {
    val payments by vm.payments.collectAsState()
    val dealers by vm.dealers.collectAsState()
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(payments) { p ->
            val dealerName = dealers.firstOrNull { it.id == p.dealerId }?.name ?: p.dealerId
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(dealerName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text("৳${"%,.0f".format(p.amount)} · proof: ${p.proofRef}", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                when (p.status) {
                    PaymentVerificationStatus.PENDING_VERIFICATION -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.setPaymentStatus(p.id, PaymentVerificationStatus.VERIFIED) },
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) { Text("Verify & release") }
                        OutlinedButton(onClick = { vm.setPaymentStatus(p.id, PaymentVerificationStatus.REJECTED) }) {
                            Text("Reject", color = DangerRed)
                        }
                    }
                    PaymentVerificationStatus.VERIFIED -> Text("✓ Verified & released", color = SuccessGreen, fontWeight = FontWeight.SemiBold)
                    PaymentVerificationStatus.REJECTED -> Text("✕ Rejected", color = DangerRed, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/** Shared "build up a list of line items" widget reused by Quotation/POS/Challan/Return — name+qty+price, add to list, remove any row. */
@Composable
private fun LineItemBuilder(items: MutableList<SalesInvoiceLineItem>, onChanged: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var qtyText by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }

    Column {
        items.forEachIndexed { idx, item ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("${item.name} × ${item.qty} @ ৳${item.unitPrice}", style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { items.removeAt(idx); onChanged() }) { Text("✕", color = DangerRed) }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Item") }, modifier = Modifier.weight(2f))
            OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Qty") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = priceText, onValueChange = { priceText = it }, label = { Text("৳/unit") }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Button(
            onClick = {
                val qty = qtyText.toIntOrNull() ?: return@Button
                val price = priceText.toDoubleOrNull() ?: return@Button
                if (name.isBlank()) return@Button
                items.add(SalesInvoiceLineItem(productId = "", name = name, unit = "pcs", qty = qty, unitPrice = price))
                name = ""; qtyText = ""; priceText = ""
                onChanged()
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("+ Add item") }
    }
}

@Composable
private fun QuotationTab(vm: CreditAndBillingViewModel) {
    val quotations by vm.quotations.collectAsState()
    val dealers by vm.dealers.collectAsState()
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "QuotationNo,Party,SubTotal,Status\n"
                    val rows = quotations.joinToString("\n") { q -> com.abm.erp.core.toCsvRow(q.quotationNo, q.partyName, q.subTotal, q.status) }
                    val file = java.io.File(context.getExternalFilesDir(null), "quotations_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Quotations (${quotations.size})\n" + quotations.take(20).joinToString("\n") { "${it.quotationNo} — ${it.partyName} ৳${it.subTotal}" }
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                    try { context.startActivity(android.content.Intent.createChooser(intent, "Quotations")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                },
            )
        }
        if (vm.can(PermissionAction.CREATE)) {
            Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Quotation") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(quotations) { q ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${q.quotationNo} — ${q.partyName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("৳${"%,.0f".format(q.subTotal)} · valid till ${q.validUntil.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text(q.status, color = when (q.status) { "CONVERTED" -> SuccessGreen; "CANCELLED", "EXPIRED" -> DangerRed; else -> WarningAmber }, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Quotation", entityId = q.id, entityLabel = q.quotationNo,
                            shareText = "Quotation ${q.quotationNo} — ${q.partyName}\nTotal: ৳${q.subTotal}\nStatus: ${q.status}",
                            onDuplicate = { vm.duplicateQuotationAction(q.id) },
                            csvHeader = "QuotationNo,Party,SubTotal,Status",
                            csvRow = com.abm.erp.core.toCsvRow(q.quotationNo, q.partyName, q.subTotal, q.status),
                        )
                    }
                    if (q.status in setOf("DRAFT", "SENT")) {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.convertQuotation(q.id, dealers.firstOrNull { it.id == q.partyId }?.zone ?: "") }) { Text("Convert to Invoice") }
                            OutlinedButton(onClick = { vm.cancelQuotation(q.id) }) { Text("Cancel", color = DangerRed) }
                        }
                    }
                }
            }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var selectedDealer by remember { mutableStateOf<Dealer?>(null) }
                var expanded by remember { mutableStateOf(false) }
                val lineItems = remember { mutableStateListOf<SalesInvoiceLineItem>() }
                var refreshTick by remember { mutableStateOf(0) }
                Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
                    Text("New Quotation", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedDealer?.name ?: "Select dealer") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            dealers.forEach { d -> DropdownMenuItem(text = { Text(d.name) }, onClick = { selectedDealer = d; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    LineItemBuilder(lineItems) { refreshTick++ }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val d = selectedDealer ?: return@Button
                            if (lineItems.isEmpty()) return@Button
                            vm.createQuotation(d.id, d.name, lineItems.toList(), validDays = 7)
                            showNew = false
                        },
                        enabled = selectedDealer != null && lineItems.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Create Quotation (7-day validity)") }
                }
            }
        }
    }
}

@Composable
private fun PosBillingTab(vm: CreditAndBillingViewModel) {
    var customerName by remember { mutableStateOf("") }
    val lineItems = remember { mutableStateListOf<SalesInvoiceLineItem>() }
    var refreshTick by remember { mutableStateOf(0) }
    var lastResult by remember { mutableStateOf<String?>(null) }
    val total = lineItems.sumOf { it.lineTotal }

    Column(Modifier.fillMaxSize()) {
        Text("Walk-in / Point-of-Sale Billing", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = customerName, onValueChange = { customerName = it }, label = { Text("Customer name (optional)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        LineItemBuilder(lineItems) { refreshTick++ }
        Spacer(Modifier.height(10.dp))
        Text("Total: ৳${"%,.0f".format(total)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ElectricCyan)
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                vm.createPosSale(customerName, lineItems.toList())
                lastResult = "✓ POS sale recorded — ৳${"%,.0f".format(total)}"
                lineItems.clear(); customerName = ""
            },
            enabled = lineItems.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Complete Sale") }
        lastResult?.let { Text(it, color = SuccessGreen, modifier = Modifier.padding(top = 8.dp)) }
    }
}

@Composable
private fun DeliveryChallanTab(vm: CreditAndBillingViewModel) {
    val challans by vm.deliveryChallans.collectAsState()
    val dealers by vm.dealers.collectAsState()
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Delivery Challan") }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(challans) { c ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("${c.challanNo} — ${c.partyName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("Vehicle: ${c.vehicleNo.ifBlank { "—" }} · Driver: ${c.driverName.ifBlank { "—" }}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "DeliveryChallan", entityId = c.id, entityLabel = c.challanNo,
                            shareText = "Challan ${c.challanNo} — ${c.partyName}\nVehicle: ${c.vehicleNo}\nStatus: ${c.status}",
                            csvHeader = "ChallanNo,Party,Vehicle,Driver,Status",
                            csvRow = com.abm.erp.core.toCsvRow(c.challanNo, c.partyName, c.vehicleNo, c.driverName, c.status),
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("PENDING", "DISPATCHED", "DELIVERED").forEach { st ->
                            FilterChip(selected = c.status == st, onClick = { vm.updateChallanStatus(c.id, st) }, label = { Text(st) })
                        }
                    }
                }
            }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var selectedDealer by remember { mutableStateOf<Dealer?>(null) }
                var expanded by remember { mutableStateOf(false) }
                var vehicleNo by remember { mutableStateOf("") }
                var driverName by remember { mutableStateOf("") }
                val lineItems = remember { mutableStateListOf<SalesInvoiceLineItem>() }
                var refreshTick by remember { mutableStateOf(0) }
                Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
                    Text("New Delivery Challan", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedDealer?.name ?: "Select dealer") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            dealers.forEach { d -> DropdownMenuItem(text = { Text(d.name) }, onClick = { selectedDealer = d; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = vehicleNo, onValueChange = { vehicleNo = it }, label = { Text("Vehicle No.") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = driverName, onValueChange = { driverName = it }, label = { Text("Driver name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    LineItemBuilder(lineItems) { refreshTick++ }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val d = selectedDealer ?: return@Button
                            vm.createChallan(null, d.id, d.name, lineItems.toList(), vehicleNo, driverName)
                            showNew = false
                        },
                        enabled = selectedDealer != null && lineItems.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Create Challan") }
                }
            }
        }
    }
}

@Composable
private fun SalesReturnTab(vm: CreditAndBillingViewModel) {
    val returns by vm.salesReturns.collectAsState()
    val dealers by vm.dealers.collectAsState()
    var showNew by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Sales Return") }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(returns) { r ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${r.returnNo} — ${r.partyName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("৳${"%,.0f".format(r.refundAmount)} · ${r.reason}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text(r.status, color = when (r.status) { "APPROVED" -> SuccessGreen; "REJECTED" -> DangerRed; else -> WarningAmber }, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "SalesReturn", entityId = r.id, entityLabel = r.returnNo,
                            shareText = "Return ${r.returnNo} — ${r.partyName}\nAmount: ৳${r.refundAmount}\nReason: ${r.reason}\nStatus: ${r.status}",
                            csvHeader = "ReturnNo,Party,Amount,Reason,Status",
                            csvRow = com.abm.erp.core.toCsvRow(r.returnNo, r.partyName, r.refundAmount, r.reason, r.status),
                        )
                    }
                    if (r.status == "PENDING" && vm.can(PermissionAction.APPROVE)) {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.approveReturn(r.id) }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) { Text("Approve") }
                            OutlinedButton(onClick = { vm.rejectReturn(r.id) }) { Text("Reject", color = DangerRed) }
                        }
                    }
                }
            }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var selectedDealer by remember { mutableStateOf<Dealer?>(null) }
                var expanded by remember { mutableStateOf(false) }
                var reason by remember { mutableStateOf("") }
                val lineItems = remember { mutableStateListOf<SalesInvoiceLineItem>() }
                var refreshTick by remember { mutableStateOf(0) }
                Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
                    Text("New Sales Return", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selectedDealer?.name ?: "Select dealer") }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            dealers.forEach { d -> DropdownMenuItem(text = { Text(d.name) }, onClick = { selectedDealer = d; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    LineItemBuilder(lineItems) { refreshTick++ }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val d = selectedDealer ?: return@Button
                            vm.createReturn(null, d.id, d.name, lineItems.toList(), reason)
                            showNew = false
                        },
                        enabled = selectedDealer != null && lineItems.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Submit Return") }
                }
            }
        }
    }
}
