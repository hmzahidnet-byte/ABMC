package com.abm.erp.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

// পুরনো dark "Obsidian" থিম বাদ দিয়ে এখন ABM Corporation-এর আসল sky/gold
// থিম (light background, dark text, sky-blue/gold accents) — এটাই মূল কারণ
// ছিল dashboard-এ পুরো JSX ডিজাইনের সাথে না মেলার। TextPrimary/TextSecondary/
// GlassSurface/GlassBorder-এর মান Color.kt-তে বদলে দেওয়ায়, প্রতিটা আগে
// থেকে বানানো স্ক্রিন (Sales, Billing, HRM, ইত্যাদি) এখন থেকেই সঠিকভাবে
// light background-এ readable হয়ে যায় — প্রতিটা ফাইল আলাদা করে ধরতে হয়নি।
private val ABMLightColors = lightColorScheme(
    primary = Sky,
    secondary = Gold,
    background = DashBg,
    surface = CardWhite,
    onPrimary = Color.White,
    onSecondary = Color(0xFF241A08),
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = DangerRed,
)

@Composable
fun ABMErpTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ABMLightColors,
        typography = ABMTypography,
        content = {
            Box(Modifier.fillMaxSize().background(DashBg)) {
                content()
            }
        },
    )
}
