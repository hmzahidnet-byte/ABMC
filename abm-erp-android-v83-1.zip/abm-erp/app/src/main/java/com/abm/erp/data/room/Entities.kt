package com.abm.erp.data.room

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room table definitions. These are the on-disk, flat/serializable counterparts
 * of the rich domain models in data/Models.kt. AppRepository maps between the
 * two directions so every UI Composable keeps working against the same
 * domain types (RetailOrder, Dealer, etc.) it always did.
 *
 * Complex nested fields (lists of value objects) are stored as compact
 * delimited strings via the *Raw fields and packed/unpacked in Converters.kt,
 * to avoid pulling in a JSON library for this first persistence pass.
 */

@Entity(tableName = "companies")
data class CompanyEntity(
    @PrimaryKey val id: String,
    val name: String,
    val address: String = "",
    val logoUrl: String? = null,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "app_users")
data class AppUserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val role: String,
    val companyId: String,
    val zone: String,
    val territoryId: String? = null,
    val phone: String = "",
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "territories")
data class TerritoryEntity(
    @PrimaryKey val id: String = "",
    val division: String = "",
    val district: String? = null,
    val market: String? = null,
    val parentTerritoryId: String? = null,
    val zoneName: String? = null,
    val country: String = "Bangladesh",
    val upazila: String? = null,
    val area: String? = null,
    val beat: String? = null,
)

@Entity(tableName = "retailers")
data class RetailerEntity(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val phone: String = "",
    val address: String = "",
    val territoryId: String? = null,
    val dealerId: String? = null,
    val lat: Double? = null,
    val lng: Double? = null,
    val photoUri: String? = null,
    val qrCode: String? = null,
    val dedupKey: String = "",
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val deletedAtEpochMillis: Long? = null,
    val deletedBy: String? = null,
    val dueBalance: Double = 0.0,
    val creditLimit: Double = 0.0,
    val outletCategory: String = "General Store",
    val outletType: String = "Retail",
    val routeId: String? = null,
)

@Entity(tableName = "role_definitions")
data class RoleDefinitionEntity(
    @PrimaryKey val role: String = "",
    val label: String = "",
    val modulePermissionsRaw: String = "", // packed ModulePermission list, see Converters.packModulePermissions
)

@Entity(tableName = "retail_orders")
data class RetailOrderEntity(
    @PrimaryKey val id: String = "",
    val orderNo: String = "",
    val retailerName: String = "",
    val loggedBySoId: String = "",
    val zone: String = "",
    val items: String = "",
    val amount: Double = 0.0,
    val stage: String = "SO_LOGGED",
    val routedDealerId: String? = null,
    val loggedAtEpochMillis: Long = 0,
    val retailerPhotoUri: String? = null,
    val retailerLat: Double? = null,
    val retailerLng: Double? = null,
    val retailerQrCode: String? = null,
    val channel: String = "retail",
    val anonymous: Boolean = false,
    val photoPurpose: String? = null,
    val retailerId: String? = null,
)

@Entity(tableName = "dealers")
data class DealerEntity(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val zone: String = "",
    val dueBalance: Double = 0.0,
    val salesLast90Days: Double = 0.0,
    val pin: String = "0000",
    val stockUnits: Int = 0,
    val phone: String = "",
    val address: String = "",
    val territoryId: String? = null,
    val dedupKey: String = "",
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val deletedAtEpochMillis: Long? = null,
    val deletedBy: String? = null,
    val classification: String = "B",
    val creditLimit: Double = 0.0,
)

@Entity(tableName = "bulk_dealer_requests")
data class BulkDealerRequestEntity(
    @PrimaryKey val id: String,
    val dealerId: String,
    val requestedByAsmId: String,
    val items: String,
    val warehouseAvailable: Boolean,
)

@Entity(tableName = "field_employee_routes", primaryKeys = ["employeeId", "dateEpochDay"])
data class FieldEmployeeRouteEntity(
    val employeeId: String,
    val employeeName: String,
    val dateEpochDay: Long,
    val breadcrumbsRaw: String, // packed GpsPing list, see Converters.packBreadcrumbs
)

@Entity(tableName = "engagement_campaigns")
data class EngagementCampaignEntity(
    @PrimaryKey val id: String = "",
    val channel: String = "",
    val message: String = "",
    val targetZone: String = "",
    val sentCount: Int = 0,
)

@Entity(tableName = "attendance_records")
data class AttendanceRecordEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
    val employeeId: String = "",
    val dateEpochDay: Long = 0,
    val checkedIn: Boolean = false,
    val gpsValid: Boolean = false,
)

@Entity(tableName = "payroll_lines")
data class PayrollLineEntity(
    @PrimaryKey val employeeId: String = "",
    val employeeName: String = "",
    val basePay: Double = 0.0,
    val targetAmount: Double = 0.0,
    val achievedAmount: Double = 0.0,
    val commissionRate: Double = 0.0,
    val unapprovedAbsenceDays: Int = 0,
    val dailyWage: Double = 0.0,
)

// Unified table backing BOTH the Billing module's "Voice Billing" feature and
// the Sales Chain's dealer invoicing — one physical Invoice structure with a
// `type` discriminator, instead of two separate tables. Domain-facing shapes
// (VoiceInvoice / SalesInvoice in Models.kt) are unchanged so existing screens
// keep working exactly as before; only the persistence layer is unified.
@Entity(tableName = "invoices")
data class InvoiceEntity(
    @PrimaryKey val id: String = "",
    val invoiceNo: String = "",
    val type: String = "SALES", // "SALES" | "VOICE"
    val dealerId: String = "",
    val dealerName: String = "",
    val dealerZone: String = "",
    val lineItemsRaw: String = "", // packed line items — packInvoiceItems for VOICE, packSalesInvoiceItems for SALES
    val dealerDiscountPct: Double = 0.0,
    val commissionPct: Double = 0.0,
    val previousDue: Double = 0.0, // VOICE-type only
    val courier: String? = null,
    val signedByRole: String? = null,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val status: String = "PENDING",
    val isDeleted: Boolean = false,
    val deletedAtEpochMillis: Long? = null,
    val deletedBy: String? = null,
)

@Entity(tableName = "payment_proofs")
data class PaymentProofEntity(
    @PrimaryKey val id: String,
    val dealerId: String,
    val amount: Double,
    val proofRef: String,
    val status: String,
)

@Entity(tableName = "raw_material_lots")
data class RawMaterialLotEntity(
    @PrimaryKey val id: String,
    val materialName: String,
    val qtyKg: Double,
    val costPerKg: Double,
    val purchasedOnEpochDay: Long,
)

@Entity(tableName = "production_batches")
data class ProductionBatchEntity(
    @PrimaryKey val id: String,
    val cycleType: String,
    val inputKg: Double,
    val outputKg: Double,
    val gatepassReceived: Boolean,
)

@Entity(tableName = "factory_attendance")
data class FactoryAttendanceEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
    val laborerId: String,
    val dateEpochDay: Long,
    val withinFactoryGeofence: Boolean,
    val wifiIpLocked: Boolean,
)

@Entity(tableName = "prescription_cards")
data class PrescriptionCardEntity(
    @PrimaryKey val id: String,
    val title: String,
    val body: String,
    val severity: String,
)

@Entity(tableName = "boardroom_queries")
data class BoardroomQueryEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
    val question: String,
    val answer: String,
    val mode: String = "analysis",
    val askedAtEpochMillis: Long,
)

@Entity(tableName = "tasks")
data class TaskItemEntity(
    @PrimaryKey val id: String = "",
    val title: String = "",
    val assignee: String = "",
    val done: Boolean = false,
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
    val deletedAtEpochMillis: Long? = null,
    val deletedBy: String? = null,
    val status: String = "PENDING",
    val parentTaskId: String? = null,
)

@Entity(tableName = "approval_requests")
data class ApprovalRequestEntity(
    @PrimaryKey val id: String = "",
    val type: String = "",
    val fromEmployee: String = "",
    val detail: String = "",
    val status: String = "Pending",
    val createdAtEpochMillis: Long = 0,
    val entityType: String = "",
    val entityId: String = "",
    val level: Int = 1,
    val approvedBy: String? = null,
    val approvedAtEpochMillis: Long? = null,
    val rejectReason: String? = null,
    val assignedToEmployeeId: String? = null,
    val escalated: Boolean = false,
)

@Entity(tableName = "courier_partners")
data class CourierPartnerEntity(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val hasApi: Boolean = false,
)

@Entity(tableName = "shipments")
data class ShipmentEntity(
    @PrimaryKey val id: String = "",
    val courierId: String = "",
    val dealerOrRetailer: String = "",
    val trackingId: String? = null,
    val status: String = "",
)

@Entity(tableName = "ledger_entries")
data class LedgerEntryEntity(
    @PrimaryKey val id: String = "",
    val type: String = "IN", // "IN" | "OUT"
    val category: String = "",
    val description: String = "",
    val amount: Double = 0.0,
    val recordedBy: String = "",
    val division: String? = null,
    val recordedAtEpochMillis: Long = 0,
)

/**
 * One shared audit trail for the whole app — every module writes into this
 * SAME table instead of each module getting its own bespoke log. entityType
 * + entityId identify what was touched (e.g. "SalesInvoice" / "INV-1044");
 * oldValueJson/newValueJson are simple JSON snapshots (nullable — a CREATE
 * has no old value, a DELETE has no new value).
 */
@Entity(tableName = "audit_log")
data class AuditLogEntity(
    @PrimaryKey val id: String = "",
    val entityType: String = "",
    val entityId: String = "",
    val action: String = "CREATE", // CREATE / UPDATE / DELETE / APPROVE / REJECT / RESTORE
    val performedBy: String = "",
    val performedByRole: String = "",
    val oldValueJson: String? = null,
    val newValueJson: String? = null,
    val timestampEpochMillis: Long = 0,
)

/** Backup & Recovery — one row per export taken; fileUrl points at the Firebase Storage copy of the JSON bundle (see BackupManager). */
@Entity(tableName = "backup_metadata")
data class BackupMetadataEntity(
    @PrimaryKey val id: String = "",
    val companyId: String = "",
    val version: String = "v1",
    val collectionsIncluded: Int = 0,
    val fileUrl: String = "",
    val fileSizeBytes: Long = 0,
    val triggeredBy: String = "",
    val status: String = "COMPLETED",
    val createdAtEpochMillis: Long = 0,
    val restoredAtEpochMillis: Long? = null,
    val restoredBy: String? = null,
)

// ================= Module 4/7/8: Sales Management, DMS, Retailer/Outlet =================

@Entity(tableName = "quotations")
data class QuotationEntity(
    @PrimaryKey val id: String = "",
    val quotationNo: String = "",
    val partyType: String = "DEALER",
    val partyId: String = "",
    val partyName: String = "",
    val lineItemsRaw: String = "",
    val validUntilEpochMillis: Long = 0,
    val status: String = "DRAFT",
    val convertedInvoiceId: String? = null,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

@Entity(tableName = "delivery_challans")
data class DeliveryChallanEntity(
    @PrimaryKey val id: String = "",
    val challanNo: String = "",
    val invoiceId: String? = null,
    val partyType: String = "DEALER",
    val partyId: String = "",
    val partyName: String = "",
    val lineItemsRaw: String = "",
    val vehicleNo: String = "",
    val driverName: String = "",
    val deliveredBy: String = "",
    val status: String = "PENDING",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

@Entity(tableName = "sales_returns")
data class SalesReturnEntity(
    @PrimaryKey val id: String = "",
    val returnNo: String = "",
    val invoiceId: String? = null,
    val partyType: String = "DEALER",
    val partyId: String = "",
    val partyName: String = "",
    val lineItemsRaw: String = "",
    val reason: String = "",
    val refundAmount: Double = 0.0,
    val status: String = "PENDING",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

@Entity(tableName = "party_ledger")
data class PartyLedgerEntryEntity(
    @PrimaryKey val id: String = "",
    val partyType: String = "DEALER",
    val partyId: String = "",
    val type: String = "DEBIT",
    val amount: Double = 0.0,
    val reason: String = "",
    val referenceId: String = "",
    val balanceAfter: Double = 0.0,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "party_collections")
data class PartyCollectionEntity(
    @PrimaryKey val id: String = "",
    val partyType: String = "DEALER",
    val partyId: String = "",
    val partyName: String = "",
    val amount: Double = 0.0,
    val method: String = "CASH",
    val proofUri: String? = null,
    val status: String = "PENDING",
    val collectedBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val verifiedBy: String? = null,
    val verifiedAtEpochMillis: Long? = null,
)

@Entity(tableName = "discount_rules")
data class DiscountRuleEntity(
    @PrimaryKey val id: String = "",
    val label: String = "",
    val scope: String = "ALL",
    val minQty: Double = 0.0,
    val discountPct: Double = 0.0,
    val isActive: Boolean = true,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "sales_routes")
data class SalesRouteEntity(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val territoryId: String? = null,
    val assignedToEmployeeId: String = "",
    val outletIdsRaw: String = "", // comma-separated Retailer ids, visit order matters
    val isActive: Boolean = true,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "visit_logs")
data class VisitLogEntity(
    @PrimaryKey val id: String = "",
    val partyType: String = "DEALER",
    val partyId: String = "",
    val employeeId: String = "",
    val employeeName: String = "",
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val photoUri: String? = null,
    val purpose: String = "",
    val checkInAtEpochMillis: Long = 0,
    val checkOutAtEpochMillis: Long? = null,
)

// ================= Module 5: Purchase Management =================

@Entity(tableName = "suppliers")
data class SupplierEntity(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val phone: String = "",
    val address: String = "",
    val dueBalance: Double = 0.0,
    val creditLimit: Double = 0.0,
    val dedupKey: String = "",
    val isActive: Boolean = true,
    val isDeleted: Boolean = false,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val deletedAtEpochMillis: Long? = null,
    val deletedBy: String? = null,
)

@Entity(tableName = "purchase_orders")
data class PurchaseOrderEntity(
    @PrimaryKey val id: String = "",
    val poNo: String = "",
    val supplierId: String = "",
    val supplierName: String = "",
    val lineItemsRaw: String = "",
    val status: String = "DRAFT",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

@Entity(tableName = "goods_received_notes")
data class GoodsReceivedNoteEntity(
    @PrimaryKey val id: String = "",
    val grnNo: String = "",
    val purchaseOrderId: String = "",
    val supplierId: String = "",
    val supplierName: String = "",
    val receivedItemsRaw: String = "",
    val warehouseId: String = "",
    val receivedBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

@Entity(tableName = "purchase_returns")
data class PurchaseReturnEntity(
    @PrimaryKey val id: String = "",
    val returnNo: String = "",
    val purchaseOrderId: String? = null,
    val supplierId: String = "",
    val supplierName: String = "",
    val lineItemsRaw: String = "",
    val reason: String = "",
    val refundAmount: Double = 0.0,
    val status: String = "PENDING",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

// ================= Module 3: Inventory extras =================

@Entity(tableName = "product_categories")
data class ProductCategoryEntity(@PrimaryKey val id: String = "", val name: String = "", val isActive: Boolean = true)

@Entity(tableName = "product_brands")
data class ProductBrandEntity(@PrimaryKey val id: String = "", val name: String = "", val isActive: Boolean = true)

@Entity(tableName = "inventory_lots")
data class InventoryLotEntity(
    @PrimaryKey val id: String = "",
    val productId: String = "",
    val warehouseId: String = "",
    val batchCode: String = "",
    val qtyRemaining: Double = 0.0,
    val expiryDateEpochMillis: Long? = null,
    val receivedAtEpochMillis: Long = 0,
)

@Entity(tableName = "damage_reports")
data class DamageReportEntity(
    @PrimaryKey val id: String = "",
    val productId: String = "",
    val productName: String = "",
    val warehouseId: String = "",
    val qty: Double = 0.0,
    val reason: String = "",
    val reportedBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "stock_transfers")
data class StockTransferEntity(
    @PrimaryKey val id: String = "",
    val productId: String = "",
    val productName: String = "",
    val fromWarehouseId: String = "",
    val toWarehouseId: String = "",
    val qty: Double = 0.0,
    val status: String = "COMPLETED",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

// ================= Module 2: Manufacturing & Production extras =================

@Entity(tableName = "bill_of_materials")
data class BillOfMaterialsEntity(
    @PrimaryKey val id: String = "",
    val finishedProductName: String = "",
    val linesRaw: String = "", // packed: name,qtyPerUnit,unit;name,qtyPerUnit,unit...
    val laborCostPerUnit: Double = 0.0,
    val overheadCostPerUnit: Double = 0.0,
    val isActive: Boolean = true,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "production_orders")
data class ProductionOrderEntity(
    @PrimaryKey val id: String = "",
    val orderNo: String = "",
    val bomId: String = "",
    val finishedProductName: String = "",
    val targetQty: Double = 0.0,
    val status: String = "PLANNED",
    val scheduledDateEpochMillis: Long = 0,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "quality_checks")
data class QualityCheckEntity(
    @PrimaryKey val id: String = "",
    val batchId: String = "",
    val result: String = "PASS",
    val notes: String = "",
    val checkedBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "production_losses")
data class ProductionLossEntity(
    @PrimaryKey val id: String = "",
    val batchId: String = "",
    val qtyLost: Double = 0.0,
    val reason: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "machine_logs")
data class MachineLogEntity(
    @PrimaryKey val id: String = "",
    val machineName: String = "",
    val batchId: String? = null,
    val hoursUsed: Double = 0.0,
    val notes: String = "",
    val recordedAtEpochMillis: Long = 0,
)

// ================= Module 11: Accounts & Finance =================

@Entity(tableName = "chart_of_accounts")
data class ChartOfAccountEntity(
    @PrimaryKey val id: String = "",
    val code: String = "",
    val name: String = "",
    val type: String = "ASSET",
    val parentId: String? = null,
    val isActive: Boolean = true,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "vouchers")
data class VoucherEntity(
    @PrimaryKey val id: String = "",
    val voucherNo: String = "",
    val type: String = "PAYMENT",
    val voucherDateEpochMillis: Long = 0,
    val narration: String = "",
    val linesRaw: String = "", // packed: accountId,accountName,debit,credit ; per line
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

// ================= Module 6: CRM =================

@Entity(tableName = "leads")
data class LeadEntity(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val phone: String = "",
    val source: String = "",
    val status: String = "NEW",
    val assignedTo: String = "",
    val notes: String = "",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

@Entity(tableName = "opportunities")
data class OpportunityEntity(
    @PrimaryKey val id: String = "",
    val leadId: String? = null,
    val title: String = "",
    val estimatedValue: Double = 0.0,
    val stage: String = "PROSPECTING",
    val assignedTo: String = "",
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "customer_segments")
data class CustomerSegmentEntity(
    @PrimaryKey val id: String = "",
    val name: String = "",
    val criteria: String = "",
)

@Entity(tableName = "call_logs")
data class CallLogEntity(
    @PrimaryKey val id: String = "",
    val leadId: String? = null,
    val partyType: String? = null,
    val partyId: String? = null,
    val contactName: String = "",
    val phone: String = "",
    val durationMinutes: Int = 0,
    val notes: String = "",
    val loggedBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "meeting_logs")
data class MeetingLogEntity(
    @PrimaryKey val id: String = "",
    val title: String = "",
    val attendees: String = "",
    val notes: String = "",
    val meetingDateEpochMillis: Long = 0,
    val loggedBy: String = "",
)

@Entity(tableName = "follow_ups")
data class FollowUpEntity(
    @PrimaryKey val id: String = "",
    val leadId: String? = null,
    val note: String = "",
    val dueDateEpochMillis: Long = 0,
    val done: Boolean = false,
    val createdBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

// ================= Module 12: HR & Payroll extras =================

@Entity(tableName = "leave_requests")
data class LeaveRequestEntity(
    @PrimaryKey val id: String = "",
    val employeeId: String = "",
    val employeeName: String = "",
    val type: String = "CASUAL",
    val fromDateEpochDay: Long = 0,
    val toDateEpochDay: Long = 0,
    val reason: String = "",
    val status: String = "PENDING",
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "employee_lifecycle_events")
data class EmployeeLifecycleEventEntity(
    @PrimaryKey val id: String = "",
    val employeeId: String = "",
    val employeeName: String = "",
    val type: String = "INCREMENT",
    val oldValue: String = "",
    val newValue: String = "",
    val effectiveDateEpochDay: Long = 0,
    val notes: String = "",
    val recordedBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

// ================= Module 14: Communication Hub =================

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String = "",
    val channelId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val message: String = "",
    val attachmentUri: String? = null,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "announcements")
data class AnnouncementEntity(
    @PrimaryKey val id: String = "",
    val title: String = "",
    val body: String = "",
    val postedBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

@Entity(tableName = "circulars")
data class CircularEntity(
    @PrimaryKey val id: String = "",
    val title: String = "",
    val body: String = "",
    val department: String? = null,
    val postedBy: String = "",
    val createdAtEpochMillis: Long = 0,
    val isDeleted: Boolean = false,
)

// ================= Module 13: Logistics — Vehicle Tracking =================

@Entity(tableName = "vehicles")
data class VehicleEntity(
    @PrimaryKey val id: String = "",
    val registrationNo: String = "",
    val vehicleType: String = "Truck",
    val driverName: String = "",
    val driverPhone: String = "",
    val isActive: Boolean = true,
    val createdAtEpochMillis: Long = 0,
)

@Entity(tableName = "vehicle_location_pings")
data class VehicleLocationPingEntity(
    @PrimaryKey val id: String = "",
    val vehicleId: String = "",
    val lat: Double = 0.0,
    val lng: Double = 0.0,
    val speedKmh: Double = 0.0,
    val recordedAtEpochMillis: Long = 0,
)

// ================= Universal Attachment System =================

@Entity(tableName = "attachments")
data class AttachmentEntity(
    @PrimaryKey val id: String = "",
    val moduleReference: String = "",
    val entityId: String = "",
    val type: String = "PHOTO",
    val uri: String = "",
    val lat: Double? = null,
    val lng: Double? = null,
    val uploadedBy: String = "",
    val createdAtEpochMillis: Long = 0,
)

/** Notification Framework — persisted in-app notification record (see Models.kt's NotificationEntry doc comment). */
@Entity(tableName = "notification_entries")
data class NotificationEntryEntity(
    @PrimaryKey val id: String = "",
    val category: String = "APPROVAL",
    val title: String = "",
    val body: String = "",
    val targetEmployeeId: String? = null,
    val isRead: Boolean = false,
    val createdAtEpochMillis: Long = 0,
)
