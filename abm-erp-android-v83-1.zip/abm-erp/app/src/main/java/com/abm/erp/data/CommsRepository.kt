package com.abm.erp.data

import android.content.Context
import com.abm.erp.data.room.AnnouncementEntity
import com.abm.erp.data.room.AppDatabase
import com.abm.erp.data.room.ChatMessageEntity
import com.abm.erp.data.room.CircularEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset

/**
 * Module 14 — Communication Hub. Same repository-object pattern as
 * Purchase/Accounts/CrmRepository. Internal Chat is channel-based (a fixed
 * set of department channels plus "general") rather than full peer-to-peer
 * DMs with typing indicators/read receipts — that's a real-time-infra
 * project of its own; this is a genuine, working persisted message board
 * per channel, which covers "Internal Chat / Department Messaging" as
 * specified without overclaiming a full messaging-app rebuild.
 */
object CommsRepository {

    private lateinit var db: AppDatabase
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val firestoreDb by lazy { com.google.firebase.firestore.FirebaseFirestore.getInstance() }
    private var syncCompanyId: String? = null
    private var chatListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var announcementsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var circularsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

    /** Fixed channel set — "general" plus one per department; a Circular's `department` field uses the same names. */
    val CHANNELS = listOf("general", "sales", "production", "accounts", "hr", "logistics")

    private fun syncCollection(name: String) =
        firestoreDb.collection("companies").document(syncCompanyId ?: "_unset").collection(name)

    fun startCrossDeviceSync(companyId: String) {
        if (companyId == syncCompanyId) return
        syncCompanyId = companyId
        listenChatRemote()
        listenAnnouncementsRemote()
        listenCircularsRemote()
    }

    private fun listenChatRemote() {
        chatListenerReg?.remove()
        chatListenerReg = syncCollection("chatMessages").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("CommsRepository", "chatMessages sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(ChatMessageEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.chatMessageDao().upsertAll(list) }
        }
    }

    private fun listenAnnouncementsRemote() {
        announcementsListenerReg?.remove()
        announcementsListenerReg = syncCollection("announcements").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("CommsRepository", "announcements sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(AnnouncementEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.announcementDao().upsertAll(list) }
        }
    }

    private fun listenCircularsRemote() {
        circularsListenerReg?.remove()
        circularsListenerReg = syncCollection("circulars").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("CommsRepository", "circulars sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(CircularEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.circularDao().upsertAll(list) }
        }
    }

    fun init(context: Context) {
        db = AppDatabase.getInstance(context)
        announcements = db.announcementDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        circulars = db.circularDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
    }

    lateinit var announcements: StateFlow<List<Announcement>>
        private set
    lateinit var circulars: StateFlow<List<Circular>>
        private set

    /** Live per-channel message stream — a screen collects this for whichever channel is open, same as MockRepository.partyLedgerFor's per-party pattern. */
    fun messagesForChannel(channelId: String): Flow<List<ChatMessage>> =
        db.chatMessageDao().getForChannel(channelId).map { list -> list.map { it.toDomain() } }

    fun sendMessage(channelId: String, message: String, attachmentUri: String? = null): ChatMessage {
        val msg = ChatMessage(id = java.util.UUID.randomUUID().toString(), channelId = channelId, senderId = MockRepository.currentUser.employeeId, senderName = MockRepository.currentUser.name, message = message, attachmentUri = attachmentUri)
        scope.launch {
            val entity = msg.toEntity()
            db.chatMessageDao().upsert(entity)
            syncCollection("chatMessages").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("CommsRepository", "push chatMessage failed", it) }
        }
        return msg
    }

    /** Company-wide broadcast — Chairman/GM-tier action (same "announce" permission gate as the Chairman's Notice image upload). */
    fun postAnnouncement(title: String, body: String): Announcement? {
        if (!PermissionManager.canCurrentUser("notify", PermissionAction.CREATE)) {
            MockRepository.logAudit("Announcement", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            return null
        }
        val ann = Announcement(id = java.util.UUID.randomUUID().toString(), title = title, body = body, postedBy = MockRepository.currentUser.name)
        scope.launch {
            val entity = ann.toEntity()
            db.announcementDao().upsert(entity)
            syncCollection("announcements").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("CommsRepository", "push announcement failed", it) }
            MockRepository.logAudit("Announcement", ann.id, "CREATE", newValue = ann)
        }
        return ann
    }

    fun deleteAnnouncement(id: String) {
        scope.launch {
            db.announcementDao().softDelete(id)
            syncCollection("announcements").document(id).update("isDeleted", true)
                .addOnFailureListener { android.util.Log.w("CommsRepository", "push announcement-delete failed", it) }
            MockRepository.logAudit("Announcement", id, "DELETE")
        }
    }

    /** Circular — same broadcast concept as Announcement but department-scoped and typically longer-form (policy notices etc.). */
    fun postCircular(title: String, body: String, department: String?): Circular? {
        if (!PermissionManager.canCurrentUser("notify", PermissionAction.CREATE)) {
            MockRepository.logAudit("Circular", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            return null
        }
        val circular = Circular(id = java.util.UUID.randomUUID().toString(), title = title, body = body, department = department, postedBy = MockRepository.currentUser.name)
        scope.launch {
            val entity = circular.toEntity()
            db.circularDao().upsert(entity)
            syncCollection("circulars").document(entity.id).set(entity)
                .addOnFailureListener { android.util.Log.w("CommsRepository", "push circular failed", it) }
            MockRepository.logAudit("Circular", circular.id, "CREATE", newValue = circular)
        }
        return circular
    }

    fun deleteCircular(id: String) {
        scope.launch {
            db.circularDao().softDelete(id)
            syncCollection("circulars").document(id).update("isDeleted", true)
                .addOnFailureListener { android.util.Log.w("CommsRepository", "push circular-delete failed", it) }
            MockRepository.logAudit("Circular", id, "DELETE")
        }
    }
}

private fun ChatMessage.toEntity() = ChatMessageEntity(
    id = id, channelId = channelId, senderId = senderId, senderName = senderName, message = message,
    attachmentUri = attachmentUri, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

private fun ChatMessageEntity.toDomain() = ChatMessage(
    id = id, channelId = channelId, senderId = senderId, senderName = senderName, message = message, attachmentUri = attachmentUri,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

private fun Announcement.toEntity() = AnnouncementEntity(
    id = id, title = title, body = body, postedBy = postedBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

private fun AnnouncementEntity.toDomain() = Announcement(
    id = id, title = title, body = body, postedBy = postedBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC), isDeleted = isDeleted,
)

private fun Circular.toEntity() = CircularEntity(
    id = id, title = title, body = body, department = department, postedBy = postedBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

private fun CircularEntity.toDomain() = Circular(
    id = id, title = title, body = body, department = department, postedBy = postedBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC), isDeleted = isDeleted,
)
