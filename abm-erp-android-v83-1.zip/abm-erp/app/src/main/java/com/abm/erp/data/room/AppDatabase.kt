package com.abm.erp.data.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CompanyEntity::class,
        AppUserEntity::class,
        RetailOrderEntity::class,
        DealerEntity::class,
        BulkDealerRequestEntity::class,
        FieldEmployeeRouteEntity::class,
        EngagementCampaignEntity::class,
        AttendanceRecordEntity::class,
        PayrollLineEntity::class,
        InvoiceEntity::class,
        PaymentProofEntity::class,
        RawMaterialLotEntity::class,
        ProductionBatchEntity::class,
        FactoryAttendanceEntity::class,
        PrescriptionCardEntity::class,
        BoardroomQueryEntity::class,
        ProductEntity::class,
        WarehouseEntity::class,
        StockLevelEntity::class,
        StockMovementEntity::class,
        TaskItemEntity::class,
        ApprovalRequestEntity::class,
        CourierPartnerEntity::class,
        ShipmentEntity::class,
        LedgerEntryEntity::class,
        AuditLogEntity::class,
        TerritoryEntity::class,
        RetailerEntity::class,
        RoleDefinitionEntity::class,
        BackupMetadataEntity::class,
        QuotationEntity::class,
        DeliveryChallanEntity::class,
        SalesReturnEntity::class,
        PartyLedgerEntryEntity::class,
        PartyCollectionEntity::class,
        DiscountRuleEntity::class,
        SalesRouteEntity::class,
        VisitLogEntity::class,
        SupplierEntity::class,
        PurchaseOrderEntity::class,
        GoodsReceivedNoteEntity::class,
        PurchaseReturnEntity::class,
        ProductCategoryEntity::class,
        ProductBrandEntity::class,
        InventoryLotEntity::class,
        DamageReportEntity::class,
        StockTransferEntity::class,
        BillOfMaterialsEntity::class,
        ProductionOrderEntity::class,
        QualityCheckEntity::class,
        ProductionLossEntity::class,
        MachineLogEntity::class,
        ChartOfAccountEntity::class,
        VoucherEntity::class,
        LeadEntity::class,
        OpportunityEntity::class,
        CustomerSegmentEntity::class,
        CallLogEntity::class,
        MeetingLogEntity::class,
        FollowUpEntity::class,
        LeaveRequestEntity::class,
        EmployeeLifecycleEventEntity::class,
        ChatMessageEntity::class,
        AnnouncementEntity::class,
        CircularEntity::class,
        VehicleEntity::class,
        VehicleLocationPingEntity::class,
        AttachmentEntity::class,
        NotificationEntryEntity::class,
    ],
    version = 23,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun companyDao(): CompanyDao
    abstract fun appUserDao(): AppUserDao
    abstract fun retailOrderDao(): RetailOrderDao
    abstract fun dealerDao(): DealerDao
    abstract fun fieldEmployeeRouteDao(): FieldEmployeeRouteDao
    abstract fun engagementCampaignDao(): EngagementCampaignDao
    abstract fun payrollDao(): PayrollDao
    abstract fun invoiceDao(): InvoiceDao
    abstract fun paymentProofDao(): PaymentProofDao
    abstract fun rawMaterialLotDao(): RawMaterialLotDao
    abstract fun productionBatchDao(): ProductionBatchDao
    abstract fun prescriptionCardDao(): PrescriptionCardDao
    abstract fun boardroomQueryDao(): BoardroomQueryDao
    abstract fun productDao(): ProductDao
    abstract fun warehouseDao(): WarehouseDao
    abstract fun stockDao(): StockDao
    abstract fun taskDao(): TaskDao
    abstract fun approvalDao(): ApprovalDao
    abstract fun courierDao(): CourierDao
    abstract fun shipmentDao(): ShipmentDao
    abstract fun ledgerDao(): LedgerDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun territoryDao(): TerritoryDao
    abstract fun retailerDao(): RetailerDao
    abstract fun roleDefinitionDao(): RoleDefinitionDao
    abstract fun backupDao(): BackupDao
    abstract fun quotationDao(): QuotationDao
    abstract fun deliveryChallanDao(): DeliveryChallanDao
    abstract fun salesReturnDao(): SalesReturnDao
    abstract fun partyLedgerDao(): PartyLedgerDao
    abstract fun partyCollectionDao(): PartyCollectionDao
    abstract fun discountRuleDao(): DiscountRuleDao
    abstract fun salesRouteDao(): SalesRouteDao
    abstract fun visitLogDao(): VisitLogDao
    abstract fun supplierDao(): SupplierDao
    abstract fun purchaseOrderDao(): PurchaseOrderDao
    abstract fun goodsReceivedNoteDao(): GoodsReceivedNoteDao
    abstract fun purchaseReturnDao(): PurchaseReturnDao
    abstract fun productCategoryDao(): ProductCategoryDao
    abstract fun productBrandDao(): ProductBrandDao
    abstract fun inventoryLotDao(): InventoryLotDao
    abstract fun damageReportDao(): DamageReportDao
    abstract fun stockTransferDao(): StockTransferDao
    abstract fun billOfMaterialsDao(): BillOfMaterialsDao
    abstract fun productionOrderDao(): ProductionOrderDao
    abstract fun qualityCheckDao(): QualityCheckDao
    abstract fun productionLossDao(): ProductionLossDao
    abstract fun machineLogDao(): MachineLogDao
    abstract fun chartOfAccountDao(): ChartOfAccountDao
    abstract fun voucherDao(): VoucherDao
    abstract fun leadDao(): LeadDao
    abstract fun opportunityDao(): OpportunityDao
    abstract fun customerSegmentDao(): CustomerSegmentDao
    abstract fun callLogDao(): CallLogDao
    abstract fun meetingLogDao(): MeetingLogDao
    abstract fun followUpDao(): FollowUpDao
    abstract fun leaveRequestDao(): LeaveRequestDao
    abstract fun employeeLifecycleEventDao(): EmployeeLifecycleEventDao
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun announcementDao(): AnnouncementDao
    abstract fun circularDao(): CircularDao
    abstract fun vehicleDao(): VehicleDao
    abstract fun vehicleLocationPingDao(): VehicleLocationPingDao
    abstract fun attachmentDao(): AttachmentDao
    abstract fun notificationEntryDao(): NotificationEntryDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "abm_erp.db",
                )
                    // Prototype is still under active schema changes; destructive
                    // fallback is fine until the app has real installed users with
                    // data worth preserving across upgrades — switch to real
                    // Migration objects before a production release.
                    .fallbackToDestructiveMigration()
                    .build().also { instance = it }
            }
    }
}
