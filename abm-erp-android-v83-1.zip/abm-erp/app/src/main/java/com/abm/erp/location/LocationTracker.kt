package com.abm.erp.location

import android.annotation.SuppressLint
import android.content.Context
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Thin wrapper around FusedLocationProviderClient exposing live GPS fixes as
 * a cold Flow. Caller is responsible for checking/requesting the
 * ACCESS_FINE_LOCATION runtime permission before collecting — collecting
 * without permission throws SecurityException by design (Android's rule),
 * so callers should guard with a permission check first.
 *
 * "spoofed" is flagged using Android's built-in mock-location detector
 * (Location.isFromMockProvider), which is the OS-level signal used to catch
 * field staff faking GPS via a mock-location app.
 *
 * Defensive note: a few emulator images (and rare real devices) don't have
 * Google Play Services installed at all, which would otherwise crash this
 * with an opaque error the moment tracking starts. isGooglePlayServicesAvailable
 * lets the caller show a friendly message instead.
 */
class LocationTracker(private val context: Context) {

    fun isGooglePlayServicesAvailable(): Boolean =
        GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(context) == ConnectionResult.SUCCESS

    @SuppressLint("MissingPermission") // caller guards permission before collecting
    fun liveLocation(intervalMillis: Long = 15_000L): Flow<GpsFix> = callbackFlow {
        if (!isGooglePlayServicesAvailable()) {
            close(IllegalStateException("Google Play Services isn't available on this device/emulator — GPS tracking needs it. Try a different emulator image (one with Google APIs) or a real device."))
            return@callbackFlow
        }

        val client = LocationServices.getFusedLocationProviderClient(context)
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, intervalMillis).build()

        val callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { loc ->
                    trySend(GpsFix(lat = loc.latitude, lng = loc.longitude, spoofed = loc.isFromMockProvider))
                }
            }
        }

        try {
            client.requestLocationUpdates(request, callback, context.mainLooper)
        } catch (e: Exception) {
            close(e)
            return@callbackFlow
        }
        awaitClose { client.removeLocationUpdates(callback) }
    }
}

data class GpsFix(val lat: Double, val lng: Double, val spoofed: Boolean)
