package com.abm.erp.ui.dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.abm.erp.core.GlassCard
import com.abm.erp.data.*
import com.abm.erp.theme.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

class MainDashboardViewModel : ViewModel() {
    val currentUserFlow = MockRepository.currentUserFlow
    val vacantEmployeeIds = MockRepository.vacantEmployeeIds
    val demoAccountsFlow = MockRepository.demoAccountsFlow
    val syncStatus = MockRepository.syncStatus
    val chairmanNotice = FirebaseSync.chairmanNotice
    fun uploadChairmanNotice(uri: android.net.Uri, caption: String) = FirebaseSync.uploadChairmanNotice(uri, caption)

    // ---- Module 1: Executive Summary / Company Performance Scorecard ----
    val dealers = MockRepository.dealers
    val retailers = MockRepository.retailers
    val stockLevels = InventoryRepository.stockLevels
    val approvals = MockRepository.approvals
    val salesInvoices = MockRepository.salesInvoices
    val partyCollections = MockRepository.partyCollections
    val productionOrders = MockRepository.productionOrders
    val visitLogs = MockRepository.visitLogs
    val vehicleLocationPings = MockRepository.vehicleLocationPings
    val tasks = MockRepository.tasks
    val followUps = com.abm.erp.data.CrmRepository.followUps
    val payroll = MockRepository.payroll
    val products = com.abm.erp.data.InventoryRepository.products
}

@Composable
fun MainDashboardScreen(onNavigate: (String) -> Unit, vm: MainDashboardViewModel = viewModel()) {
    val appUser by vm.currentUserFlow.collectAsState()
    val vacantIds by vm.vacantEmployeeIds.collectAsState()

    // Local override so the role-switcher (a testing convenience, same as in
    // the JSX prototype) can preview other designations without logging out.
    var employeeId by remember { mutableStateOf(appUser.employeeId) }
    LaunchedEffect(appUser.employeeId) { employeeId = appUser.employeeId }

    val employee = remember(employeeId) {
        EMPLOYEE_DIRECTORY.firstOrNull { it.id == employeeId }
            ?: EMPLOYEE_DIRECTORY.first { it.role == UserRole.CHAIRMAN }
    }
    val visibleModules = remember(employee.role) { visibleModulesFor(employee.role) }
    val coveredEmployees = remember(employee.id, vacantIds) {
        EMPLOYEE_DIRECTORY.filter { vacantIds.contains(it.id) && findCoveringEmployee(it, vacantIds)?.id == employee.id }
    }

    // ---- Auto-lock: নিষ্ক্রিয়তায় ড্যাশবোর্ড লক হবে (পুরোপুরি logout না, শুধু
    // আবার PIN দিতে হবে)। Chairman/MD-এর জন্য সময় কম — বেশি অ্যাক্সেস মানে
    // বেশি কড়াকড়ি। এখানে টেস্ট করার সুবিধার জন্য সময়টা তুলনামূলক ছোট রাখা
    // হয়েছে — production-এ এই কনস্ট্যান্ট দুটো বাড়িয়ে দিলেই যথেষ্ট। ----
    var dashboardLocked by remember { mutableStateOf(false) }
    var lockPin by remember { mutableStateOf("") }
    var lockError by remember { mutableStateOf<String?>(null) }
    var lastInteractionAt by remember { mutableStateOf(System.currentTimeMillis()) }
    val idleTimeoutMs = if (employee.role == UserRole.CHAIRMAN || employee.role == UserRole.MD) 30_000L else 60_000L
    val demoAccountsForLock by vm.demoAccountsFlow.collectAsState()

    LaunchedEffect(lastInteractionAt, dashboardLocked) {
        if (!dashboardLocked) {
            kotlinx.coroutines.delay(idleTimeoutMs)
            dashboardLocked = true
        }
    }

    fun dashLockPress(k: String) {
        if (k == "del") { lockPin = lockPin.dropLast(1); return }
        if (lockPin.length >= 5) return
        val next = lockPin + k
        lockPin = next
        if (next.length == 5) {
            val matches = demoAccountsForLock.entries.any { (pin, user) -> pin == next && user.employeeId == employee.id }
            if (matches) { dashboardLocked = false; lockPin = ""; lockError = null; lastInteractionAt = System.currentTimeMillis() }
            else { lockError = "Incorrect PIN."; lockPin = "" }
        }
    }

    // ---- Post-login Briefing: প্রথমবার dashboard-এ এসেই দিনের সংক্ষিপ্ত সারাংশ ----
    var showBriefing by remember { mutableStateOf(true) }

    var showEmployeePicker by remember { mutableStateOf(false) }
    var showVacancyPanel by remember { mutableStateOf(false) }
    var showAccountsPanel by remember { mutableStateOf(false) }
    var showDevicesPanel by remember { mutableStateOf(false) }
    var showLoginLogPanel by remember { mutableStateOf(false) }
    var showBackupPanel by remember { mutableStateOf(false) }
    var toastMessage by remember { mutableStateOf<String?>(null) }
    val chairmanNotice by vm.chairmanNotice.collectAsState()
    val noticePickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent(),
    ) { uri -> if (uri != null) vm.uploadChairmanNotice(uri, "Company announcement") }

    LaunchedEffect(toastMessage) {
        if (toastMessage != null) {
            kotlinx.coroutines.delay(2200)
            toastMessage = null
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                while (true) {
                    awaitPointerEventScope { awaitPointerEvent() }
                    lastInteractionAt = System.currentTimeMillis()
                }
            },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // ---- header: sky-blue gradient banner with gold ABM badge (matches the JSX "Active Portal" header) ----
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(SkyTop, Sky)))
                    .padding(16.dp),
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(44.dp)
                                .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(GoldBright, Gold, GoldDeep)), androidx.compose.foundation.shape.CircleShape),
                            contentAlignment = Alignment.Center,
                        ) { Text("ABM", color = Color(0xFF241A08), fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(employee.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("${roleLabel(employee.role)} · ${employee.geoLabel}", style = MaterialTheme.typography.labelSmall, color = Color(0xFFE4EEF6))
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SyncStatusBadge(vm)
                        Spacer(Modifier.width(8.dp))
                        TextButton(onClick = { showEmployeePicker = true }) { Text("Switch (test)", color = Color.White) }
                    }
                }
            }

            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            // ---- vacancy-cascade banner: only visible if this person is genuinely covering someone ----
            AnimatedVisibility(visible = coveredEmployees.isNotEmpty()) {
                GlassCard(borderColor = WarningAmber.copy(alpha = 0.6f), modifier = Modifier.fillMaxWidth()) {
                    Text("⚠ Covering: " + coveredEmployees.joinToString("; ") { "${it.name} (${roleLabel(it.role)}, ${it.geoLabel})" },
                        style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = WarningAmber)
                    Spacer(Modifier.height(2.dp))
                    Text("These positions are currently unfilled — their duties temporarily route to you so operations don't stop.",
                        style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }

            // ---- personal target vs achievement ----
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("My target — ${employee.geoLabel}", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                Spacer(Modifier.height(4.dp))
                Text("৳${"%,d".format(employee.achieved)} / ${"%,d".format(employee.target)}",
                    style = MaterialTheme.typography.headlineSmall, color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                val pct = (employee.achieved.toFloat() / employee.target.toFloat()).coerceIn(0f, 1f)
                LinearProgressIndicator(progress = pct, modifier = Modifier.fillMaxWidth().height(6.dp), color = Gold, trackColor = Color(0xFFEEF1F5))
                Spacer(Modifier.height(6.dp))
                Text(employee.insight, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }

            // ---- Chairman's Notice: Chairman uploads, everyone else views read-only ----
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("📢 Chairman's Notice", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    if (employee.role == UserRole.CHAIRMAN) {
                        TextButton(onClick = { noticePickerLauncher.launch("image/*") }) {
                            Text(if (chairmanNotice != null) "Change" else "Upload")
                        }
                    } else if (chairmanNotice != null) {
                        Text("View only", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }
                if (chairmanNotice != null) {
                    Spacer(Modifier.height(8.dp))
                    coil.compose.AsyncImage(
                        model = chairmanNotice!!.imageUrl,
                        contentDescription = chairmanNotice!!.caption,
                        modifier = Modifier.fillMaxWidth().height(160.dp),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(chairmanNotice!!.caption, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                } else {
                    Text(
                        if (employee.role == UserRole.CHAIRMAN) "No announcement posted yet — tap Upload to add a PNG or GIF everyone will see."
                        else "No announcement from the Chairman right now.",
                        style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                    )
                }
            }

            // ---- Module 1: Executive Summary / Company Performance Scorecard ----
            // AGM+ tier only (executive-level aggregate view) — matches how
            // "market"/"report" tiles are already AGM+ scoped elsewhere.
            if (employee.role.ordinal >= UserRole.AGM.ordinal) {
                val dealersList by vm.dealers.collectAsState()
                val retailersList by vm.retailers.collectAsState()
                val stockLevelsList by vm.stockLevels.collectAsState()
                val approvalsList by vm.approvals.collectAsState()
                val invoicesList by vm.salesInvoices.collectAsState()
                val totalDue = dealersList.sumOf { it.dueBalance } + retailersList.sumOf { it.dueBalance }
                val totalSales90d = dealersList.sumOf { it.salesLast90Days }
                val lowStockCount = stockLevelsList.count { it.isLowStock }
                val pendingApprovals = approvalsList.count { it.status == ApprovalStatus.PENDING }
                val invoiceCount = invoicesList.count { !it.isDeleted }

                GlassCard(modifier = Modifier.fillMaxWidth().background(
                    brush = Brush.linearGradient(listOf(Color(0xFF1B2340), Color(0xFF141A30))),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                )) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Executive Summary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Dashboard", entityId = "executive-summary", entityLabel = "Executive Summary",
                            shareText = "Executive Summary — ${java.time.LocalDate.now()}\nTotal Due: ৳${"%,.0f".format(totalDue)}\nSales (90d): ৳${"%,.0f".format(totalSales90d)}\nLow Stock: $lowStockCount\nPending Approvals: $pendingApprovals\nInvoices: $invoiceCount",
                            csvHeader = "Metric,Value",
                            csvRow = "TotalDue,$totalDue\nSales90d,$totalSales90d\nLowStock,$lowStockCount\nPendingApprovals,$pendingApprovals\nInvoices,$invoiceCount",
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        KpiTile("Total Due", totalDue, { "৳${"%,.0f".format(it)}" }, if (totalDue > 0) WarningAmber else SuccessGreen)
                        KpiTile("Sales (90d)", totalSales90d, { "৳${"%,.0f".format(it)}" }, ElectricCyan)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        KpiTile("Low Stock", lowStockCount.toDouble(), { "${it.toInt()}" }, if (lowStockCount > 0) DangerRed else SuccessGreen)
                        KpiTile("Pending Approvals", pendingApprovals.toDouble(), { "${it.toInt()}" }, if (pendingApprovals > 0) WarningAmber else SuccessGreen)
                        KpiTile("Invoices", invoiceCount.toDouble(), { "${it.toInt()}" }, TextPrimary)
                    }
                }
                Spacer(Modifier.height(16.dp))

                // ---- Live Business Feed: Collection / Production / Top Dealers / GPS Team / Employee Activity ----
                val collectionsList by vm.partyCollections.collectAsState()
                val productionList by vm.productionOrders.collectAsState()
                val visitsList by vm.visitLogs.collectAsState()
                val vehiclePings by vm.vehicleLocationPings.collectAsState()
                var periodSelection by remember { mutableStateOf(0) } // 0=Today, 1=Week, 2=Month
                val periodStart = when (periodSelection) {
                    1 -> java.time.LocalDateTime.now().minusDays(7)
                    2 -> java.time.LocalDateTime.now().minusDays(30)
                    else -> java.time.LocalDateTime.now().toLocalDate().atStartOfDay()
                }
                val periodLabel = when (periodSelection) { 1 -> "This Week"; 2 -> "This Month"; else -> "Today" }
                val periodCollections = collectionsList.filter { it.createdAt.isAfter(periodStart) }
                // Production has no per-day timestamp on the domain model (ProductionOrder tracks scheduledDate, not a created-at we can safely filter by period without misrepresenting it) — so this KPI stays a live current-status count regardless of period, and is labelled honestly rather than pretending to be period-filtered.
                val currentProduction = productionList.filter { it.status == "IN_PROGRESS" || it.status == "COMPLETED" }
                val periodVisits = visitsList.filter { it.checkInAt.isAfter(periodStart) }
                val topDealers = dealersList.sortedByDescending { it.salesLast90Days }.take(5)

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = periodSelection == 0, onClick = { periodSelection = 0 }, label = { Text("Today") })
                    FilterChip(selected = periodSelection == 1, onClick = { periodSelection = 1 }, label = { Text("This Week") })
                    FilterChip(selected = periodSelection == 2, onClick = { periodSelection = 2 }, label = { Text("This Month") })
                }
                Spacer(Modifier.height(8.dp))
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("$periodLabel's Performance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Collection", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("৳${"%,.0f".format(periodCollections.sumOf { it.amount })}", fontWeight = FontWeight.Bold, color = SuccessGreen)
                        }
                        Column {
                            Text("Production (live status)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${currentProduction.size} orders", fontWeight = FontWeight.Bold, color = ElectricCyan)
                        }
                        Column {
                            Text("Field Visits", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${periodVisits.size}", fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))

                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Top Dealers (90-day sales)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    topDealers.forEach { d ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(d.name, style = MaterialTheme.typography.bodySmall)
                            Text("৳${"%,.0f".format(d.salesLast90Days)}", style = MaterialTheme.typography.bodySmall, color = ElectricCyan)
                        }
                    }
                    if (topDealers.isEmpty()) Text("এখনো কোনো dealer sales data নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(16.dp))

                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("GPS Team Summary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Outlet visits ($periodLabel)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${periodVisits.size}", fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                        Column {
                            Text("Active vehicles pinged", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${vehiclePings.map { it.vehicleId }.distinct().size}", fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                        Column {
                            Text("Employees active today", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${periodVisits.map { it.employeeId }.distinct().size}", fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))

                // ---- Today's Priority: real pending tasks, approvals, overdue follow-ups ----
                val tasksList by vm.tasks.collectAsState()
                val followUpsList by vm.followUps.collectAsState()
                val pendingTasks = tasksList.filter { !it.isDeleted && it.status != com.abm.erp.data.TaskStatus.COMPLETED && it.status != com.abm.erp.data.TaskStatus.CANCELLED }
                val overdueFollowUps = followUpsList.filter { !it.done && it.dueDate.isBefore(java.time.LocalDateTime.now()) }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Today's Priority", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Pending Tasks", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${pendingTasks.size}", fontWeight = FontWeight.Bold, color = if (pendingTasks.isNotEmpty()) WarningAmber else SuccessGreen)
                        }
                        Column {
                            Text("Pending Approvals", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("$pendingApprovals", fontWeight = FontWeight.Bold, color = if (pendingApprovals > 0) WarningAmber else SuccessGreen)
                        }
                        Column {
                            Text("Overdue Follow-ups", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${overdueFollowUps.size}", fontWeight = FontWeight.Bold, color = if (overdueFollowUps.isNotEmpty()) DangerRed else SuccessGreen)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))

                // ---- Low-performing dealer warning: active dealers with zero 90-day sales (genuinely different from "inactiveDealers" wording — this is a dashboard-level warning card, not the CRM module's own list) ----
                val lowPerformers = dealersList.filter { it.isActive && !it.isDeleted && it.salesLast90Days <= 0.0 }
                if (lowPerformers.isNotEmpty()) {
                    GlassCard(modifier = Modifier.fillMaxWidth(), borderColor = WarningAmber.copy(alpha = 0.6f)) {
                        Text("⚠ Low-Performing Dealers (${lowPerformers.size})", color = WarningAmber, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(6.dp))
                        lowPerformers.take(5).forEach { d -> Text("${d.name} — ${d.zone}: কোনো বিক্রি নেই গত ৯০ দিনে", style = MaterialTheme.typography.bodySmall, color = TextSecondary) }
                    }
                    Spacer(Modifier.height(16.dp))
                }

                // ---- Top Products: aggregated from real SalesInvoice line items ----
                val invoicesForProducts by vm.salesInvoices.collectAsState()
                val topProducts = remember(invoicesForProducts) {
                    invoicesForProducts.filter { !it.isDeleted }
                        .flatMap { it.lineItems }
                        .groupBy { it.name }
                        .mapValues { (_, items) -> items.sumOf { it.qty } }
                        .entries.sortedByDescending { it.value }.take(5)
                }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Top Products (by quantity sold)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    if (topProducts.isEmpty()) {
                        Text("এখনো কোনো invoice line-item data নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                    } else {
                        topProducts.forEach { (name, qty) ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(name, style = MaterialTheme.typography.bodySmall)
                                Text("$qty units", style = MaterialTheme.typography.bodySmall, color = ElectricCyan)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))

                // ---- Quick Actions: real navigation routes, no dead callbacks ----
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Quick Actions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        AssistChip(onClick = { onNavigate("sales") }, label = { Text("Sales / New Invoice") })
                        AssistChip(onClick = { onNavigate("dealers") }, label = { Text("Dealers") })
                        AssistChip(onClick = { onNavigate("approvals") }, label = { Text("Approvals") })
                        AssistChip(onClick = { onNavigate("tasks") }, label = { Text("Tasks") })
                        AssistChip(onClick = { onNavigate("reports") }, label = { Text("Reports") })
                    }
                }
                Spacer(Modifier.height(16.dp))
            }

            // ---- categorized module grid ----
            CATEGORY_ORDER.forEach { category ->
                val itemsInCategory = visibleModules.filter { it.category == category }
                if (itemsInCategory.isNotEmpty()) {
                    Text(category.uppercase(), style = MaterialTheme.typography.labelMedium, color = TextSecondary, fontWeight = FontWeight.Bold)
                    itemsInCategory.chunked(3).forEach { rowItems ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            rowItems.forEach { module ->
                                ModuleTile(
                                    module = module,
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        val route = IMPLEMENTED_MODULE_ROUTES[module.key]
                                        if (route != null) onNavigate(route)
                                        else toastMessage = "${module.label} — coming in the next update"
                                    },
                                )
                            }
                            // pad the last row so tiles stay a consistent width
                            repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }

            if (employee.role == UserRole.CHAIRMAN) {
                OutlinedButton(onClick = { showVacancyPanel = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("🪑 Vacant Positions")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { showAccountsPanel = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("🔑 Account & Access Control")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { showDevicesPanel = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("📱 Trusted Devices")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { showLoginLogPanel = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("🕒 Login Activity Log")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { showBackupPanel = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("💾 Backup & Recovery")
                }
            }

            Spacer(Modifier.height(24.dp))
            } // closes the horizontally-padded inner Column started right after the header banner
        }

        AnimatedVisibility(visible = toastMessage != null, modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp)) {
            Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFF1B2430)) {
                Text(toastMessage ?: "", color = Color.White, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    if (showEmployeePicker) {
        EmployeePickerDialog(
            currentId = employeeId,
            onPick = { employeeId = it; showEmployeePicker = false },
            onDismiss = { showEmployeePicker = false },
        )
    }
    if (showVacancyPanel) {
        Dialog(onDismissRequest = { showVacancyPanel = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                VacantPositionsScreen(onClose = { showVacancyPanel = false })
            }
        }
    }
    if (showAccountsPanel) {
        Dialog(onDismissRequest = { showAccountsPanel = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                AccountsScreen(onClose = { showAccountsPanel = false })
            }
        }
    }
    if (showDevicesPanel) {
        Dialog(onDismissRequest = { showDevicesPanel = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                TrustedDevicesScreen(onClose = { showDevicesPanel = false })
            }
        }
    }
    if (showLoginLogPanel) {
        Dialog(onDismissRequest = { showLoginLogPanel = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                LoginActivityLogScreen(onClose = { showLoginLogPanel = false })
            }
        }
    }
    if (showBackupPanel) {
        Dialog(onDismissRequest = { showBackupPanel = false }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                BackupRecoveryScreen(onClose = { showBackupPanel = false })
            }
        }
    }
}

@Composable
private fun ModuleTile(module: AppModule, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(54.dp)
                .background(
                    androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(module.colorStart), Color(module.colorEnd))),
                    RoundedCornerShape(17.dp),
                ),
            contentAlignment = Alignment.Center,
        ) {
            Text(module.icon, fontSize = 22.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            module.label,
            style = MaterialTheme.typography.labelSmall,
            color = TextPrimary,
            textAlign = TextAlign.Center,
            maxLines = 2,
        )
    }
}

@Composable
private fun EmployeePickerDialog(currentId: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query) {
        val q = query.lowercase()
        if (q.isBlank()) EMPLOYEE_DIRECTORY.take(60)
        else EMPLOYEE_DIRECTORY.filter {
            it.name.lowercase().contains(q) || it.role.name.lowercase().contains(q) || it.geoLabel.lowercase().contains(q)
        }.take(60)
    }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 480.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Switch employee (testing)", style = MaterialTheme.typography.titleMedium)
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = "Close") }
                }
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("Search name, role, or district…") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                )
                LazyColumn {
                    items(filtered, key = { it.id }) { emp ->
                        val selected = emp.id == currentId
                        Text(
                            "${emp.name}  ·  ${roleLabel(emp.role)}  ·  ${emp.geoLabel}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (selected) ElectricCyan else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(emp.id) }
                                .padding(vertical = 10.dp),
                        )
                    }
                }
            }
        }
    }
}

/** Human-friendly designation label (UserRole enum names are already short/clear, but centralizing here in case that changes). */
fun roleLabel(role: UserRole): String = role.name

/** Small "did my last action actually leave the phone" indicator — Pending/Synced/Failed, backed by MockRepository.syncStatus. */
@Composable
private fun SyncStatusBadge(vm: MainDashboardViewModel) {
    val status by vm.syncStatus.collectAsState()
    val (label, dotColor) = when (status) {
        com.abm.erp.data.SyncStatus.SYNCED -> "Synced" to Color(0xFF3DDC97)
        com.abm.erp.data.SyncStatus.PENDING -> "Syncing…" to Color(0xFFFFB020)
        com.abm.erp.data.SyncStatus.FAILED -> "Sync failed" to Color(0xFFE85D4A)
    }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(Color.White.copy(alpha = 0.18f), androidx.compose.foundation.shape.RoundedCornerShape(999.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp),
    ) {
        Box(Modifier.size(7.dp).background(dotColor, androidx.compose.foundation.shape.CircleShape))
        Spacer(Modifier.width(5.dp))
        Text(label, color = Color.White, fontSize = 10.sp)
    }
}

/** Module 1 — premium/animated KPI tile: counts up from 0 on first appear instead of a static number, matching the "Stripe/Linear-style" animated-counter dashboard requirement. */
@Composable
private fun KpiTile(label: String, targetValue: Double, format: (Double) -> String, color: Color) {
    val animated by androidx.compose.animation.core.animateFloatAsState(
        targetValue = targetValue.toFloat(),
        animationSpec = androidx.compose.animation.core.tween(durationMillis = 900, easing = androidx.compose.animation.core.FastOutSlowInEasing),
        label = "kpiCounter",
    )
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Text(format(animated.toDouble()), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color)
    }
}
