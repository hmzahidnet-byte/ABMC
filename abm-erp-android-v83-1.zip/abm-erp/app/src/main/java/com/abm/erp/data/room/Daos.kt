package com.abm.erp.data.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CompanyDao {
    @Query("SELECT * FROM companies")
    fun getAll(): Flow<List<CompanyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(companies: List<CompanyEntity>)
}

@Dao
interface AppUserDao {
    @Query("SELECT * FROM app_users LIMIT 1")
    fun getCurrent(): Flow<AppUserEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(user: AppUserEntity)
}

@Dao
interface RetailOrderDao {
    @Query("SELECT * FROM retail_orders ORDER BY loggedAtEpochMillis DESC")
    fun getAll(): Flow<List<RetailOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(order: RetailOrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(orders: List<RetailOrderEntity>)

    @Query("UPDATE retail_orders SET stage = :stage, routedDealerId = COALESCE(:dealerId, routedDealerId) WHERE id = :id")
    suspend fun advance(id: String, stage: String, dealerId: String?)

    @Query("SELECT COUNT(*) FROM retail_orders")
    suspend fun count(): Int
}

@Dao
interface DealerDao {
    @Query("SELECT * FROM dealers")
    fun getAll(): Flow<List<DealerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(dealers: List<DealerEntity>)

    @Query("SELECT COUNT(*) FROM dealers")
    suspend fun count(): Int

    @Query("UPDATE dealers SET stockUnits = stockUnits + :delta WHERE id = :dealerId")
    suspend fun adjustStock(dealerId: String, delta: Int)

    @Query("UPDATE dealers SET dueBalance = dueBalance + :delta WHERE id = :dealerId")
    suspend fun adjustDueBalance(dealerId: String, delta: Double)

    @Query("SELECT COUNT(*) FROM dealers WHERE dedupKey = :dedupKey AND isDeleted = 0")
    suspend fun countByDedupKey(dedupKey: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(dealer: DealerEntity)

    @Query("UPDATE dealers SET isDeleted = 1, deletedAtEpochMillis = :deletedAt, deletedBy = :deletedBy WHERE id = :id")
    suspend fun softDelete(id: String, deletedAt: Long, deletedBy: String)

    @Query("UPDATE dealers SET isDeleted = 0, deletedAtEpochMillis = NULL, deletedBy = NULL WHERE id = :id")
    suspend fun restore(id: String)
}

@Dao
interface TerritoryDao {
    @Query("SELECT * FROM territories")
    fun getAll(): Flow<List<TerritoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(territories: List<TerritoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(territory: TerritoryEntity)
}

@Dao
interface RetailerDao {
    @Query("SELECT * FROM retailers WHERE isDeleted = 0")
    fun getAll(): Flow<List<RetailerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(retailer: RetailerEntity)

    @Query("SELECT COUNT(*) FROM retailers WHERE dedupKey = :dedupKey AND isDeleted = 0")
    suspend fun countByDedupKey(dedupKey: String): Int

    @Query("UPDATE retailers SET dueBalance = dueBalance + :delta WHERE id = :id")
    suspend fun adjustDueBalance(id: String, delta: Double)

    @Query("UPDATE retailers SET isDeleted = 1, deletedAtEpochMillis = :deletedAt, deletedBy = :deletedBy WHERE id = :id")
    suspend fun softDelete(id: String, deletedAt: Long, deletedBy: String)

    @Query("UPDATE retailers SET isDeleted = 0, deletedAtEpochMillis = NULL, deletedBy = NULL WHERE id = :id")
    suspend fun restore(id: String)
}

@Dao
interface RoleDefinitionDao {
    @Query("SELECT * FROM role_definitions")
    fun getAll(): Flow<List<RoleDefinitionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(roles: List<RoleDefinitionEntity>)
}

@Dao
interface FieldEmployeeRouteDao {
    @Query("SELECT * FROM field_employee_routes")
    fun getAll(): Flow<List<FieldEmployeeRouteEntity>>

    @Query("SELECT * FROM field_employee_routes WHERE employeeId = :employeeId AND dateEpochDay = :dateEpochDay LIMIT 1")
    suspend fun getForEmployeeAndDate(employeeId: String, dateEpochDay: Long): FieldEmployeeRouteEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(routes: List<FieldEmployeeRouteEntity>)

    @Query("SELECT COUNT(*) FROM field_employee_routes")
    suspend fun count(): Int
}

@Dao
interface EngagementCampaignDao {
    @Query("SELECT * FROM engagement_campaigns")
    fun getAll(): Flow<List<EngagementCampaignEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(campaign: EngagementCampaignEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(campaigns: List<EngagementCampaignEntity>)
}

@Dao
interface PayrollDao {
    @Query("SELECT * FROM payroll_lines")
    fun getAll(): Flow<List<PayrollLineEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(lines: List<PayrollLineEntity>)

    @Query("SELECT COUNT(*) FROM payroll_lines")
    suspend fun count(): Int

    @Query("UPDATE payroll_lines SET unapprovedAbsenceDays = :days WHERE employeeId = :employeeId")
    suspend fun updateAbsenceDays(employeeId: String, days: Int)
}

@Dao
interface InvoiceDao {
    @Query("SELECT * FROM invoices WHERE type = 'VOICE' AND isDeleted = 0")
    fun getAllVoice(): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM invoices WHERE type = 'SALES' AND isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAllSales(): Flow<List<InvoiceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(invoice: InvoiceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(invoices: List<InvoiceEntity>)

    @Update
    suspend fun update(invoice: InvoiceEntity)

    @Query("SELECT COUNT(*) FROM invoices WHERE type = :type")
    suspend fun countByType(type: String): Int

    @Query("UPDATE invoices SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)

    @Query("UPDATE invoices SET isDeleted = 0, deletedAtEpochMillis = NULL, deletedBy = NULL WHERE id = :id")
    suspend fun restore(id: String)
}

@Dao
interface PaymentProofDao {
    @Query("SELECT * FROM payment_proofs")
    fun getAll(): Flow<List<PaymentProofEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(payments: List<PaymentProofEntity>)

    @Query("UPDATE payment_proofs SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("SELECT COUNT(*) FROM payment_proofs")
    suspend fun count(): Int
}

@Dao
interface RawMaterialLotDao {
    @Query("SELECT * FROM raw_material_lots")
    fun getAll(): Flow<List<RawMaterialLotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(lots: List<RawMaterialLotEntity>)

    @Query("SELECT COUNT(*) FROM raw_material_lots")
    suspend fun count(): Int
}

@Dao
interface ProductionBatchDao {
    @Query("SELECT * FROM production_batches")
    fun getAll(): Flow<List<ProductionBatchEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(batches: List<ProductionBatchEntity>)

    @Query("UPDATE production_batches SET gatepassReceived = 1 WHERE id = :id")
    suspend fun receiveGatepass(id: String)

    @Query("SELECT COUNT(*) FROM production_batches")
    suspend fun count(): Int
}

@Dao
interface PrescriptionCardDao {
    @Query("SELECT * FROM prescription_cards")
    fun getAll(): Flow<List<PrescriptionCardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(cards: List<PrescriptionCardEntity>)

    @Query("SELECT COUNT(*) FROM prescription_cards")
    suspend fun count(): Int
}

@Dao
interface BoardroomQueryDao {
    @Query("SELECT * FROM boardroom_queries ORDER BY askedAtEpochMillis ASC")
    fun getAll(): Flow<List<BoardroomQueryEntity>>

    @Insert
    suspend fun insert(query: BoardroomQueryEntity)
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<TaskItemEntity>>

    @Query("SELECT * FROM tasks WHERE isDeleted = 1 ORDER BY createdAtEpochMillis DESC")
    fun getDeleted(): Flow<List<TaskItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: TaskItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(tasks: List<TaskItemEntity>)

    @Query("UPDATE tasks SET done = :done WHERE id = :id")
    suspend fun setDone(id: String, done: Boolean)

    @Query("UPDATE tasks SET status = :status, done = :done WHERE id = :id")
    suspend fun setStatus(id: String, status: String, done: Boolean)

    @Query("SELECT * FROM tasks WHERE parentTaskId = :parentId AND isDeleted = 0")
    fun getSubTasks(parentId: String): Flow<List<TaskItemEntity>>

    @Query("UPDATE tasks SET isDeleted = 1, deletedAtEpochMillis = :deletedAt, deletedBy = :deletedBy WHERE id = :id")
    suspend fun softDelete(id: String, deletedAt: Long, deletedBy: String)

    @Query("UPDATE tasks SET isDeleted = 0, deletedAtEpochMillis = NULL, deletedBy = NULL WHERE id = :id")
    suspend fun restore(id: String)
}

@Dao
interface ApprovalDao {
    @Query("SELECT * FROM approval_requests ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<ApprovalRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(request: ApprovalRequestEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(requests: List<ApprovalRequestEntity>)

    @Query("UPDATE approval_requests SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("UPDATE approval_requests SET level = :level WHERE id = :id")
    suspend fun setLevel(id: String, level: Int)

    @Query("UPDATE approval_requests SET assignedToEmployeeId = :employeeId WHERE id = :id")
    suspend fun setAssignedTo(id: String, employeeId: String?)

    @Query("UPDATE approval_requests SET escalated = :escalated WHERE id = :id")
    suspend fun setEscalated(id: String, escalated: Boolean)

    @Query("SELECT COUNT(*) FROM approval_requests")
    suspend fun count(): Int
}

@Dao
interface CourierDao {
    @Query("SELECT * FROM courier_partners")
    fun getAll(): Flow<List<CourierPartnerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(couriers: List<CourierPartnerEntity>)

    @Query("SELECT COUNT(*) FROM courier_partners")
    suspend fun count(): Int
}

@Dao
interface ShipmentDao {
    @Query("SELECT * FROM shipments")
    fun getAll(): Flow<List<ShipmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(shipment: ShipmentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(shipments: List<ShipmentEntity>)

    @Query("UPDATE shipments SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)
}

@Dao
interface LedgerDao {
    @Query("SELECT * FROM ledger_entries ORDER BY recordedAtEpochMillis DESC")
    fun getAll(): Flow<List<LedgerEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: LedgerEntryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entries: List<LedgerEntryEntity>)

    @Query("SELECT COUNT(*) FROM ledger_entries")
    suspend fun count(): Int
}

@Dao
interface AttendanceDao {
    @Query("SELECT * FROM attendance_records WHERE employeeId = :employeeId AND dateEpochDay = :dateEpochDay LIMIT 1")
    suspend fun getForDay(employeeId: String, dateEpochDay: Long): AttendanceRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(record: AttendanceRecordEntity)

    @Query("SELECT * FROM attendance_records WHERE employeeId = :employeeId ORDER BY dateEpochDay DESC")
    fun getAllForEmployee(employeeId: String): Flow<List<AttendanceRecordEntity>>

    @Query("SELECT COUNT(*) FROM attendance_records WHERE employeeId = :employeeId AND checkedIn = 0")
    suspend fun countAbsences(employeeId: String): Int
}

@Dao
interface AuditLogDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: AuditLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entries: List<AuditLogEntity>)

    @Query("SELECT * FROM audit_log ORDER BY timestampEpochMillis DESC")
    fun getAll(): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM audit_log WHERE entityType = :entityType AND entityId = :entityId ORDER BY timestampEpochMillis DESC")
    fun getForEntity(entityType: String, entityId: String): Flow<List<AuditLogEntity>>
}

@Dao
interface BackupDao {
    @Query("SELECT * FROM backup_metadata ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<BackupMetadataEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: BackupMetadataEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<BackupMetadataEntity>)
}

@Dao
interface QuotationDao {
    @Query("SELECT * FROM quotations WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<QuotationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(quotation: QuotationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(quotations: List<QuotationEntity>)

    @Query("UPDATE quotations SET status = :status, convertedInvoiceId = :invoiceId WHERE id = :id")
    suspend fun setStatus(id: String, status: String, invoiceId: String? = null)

    @Query("UPDATE quotations SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)

    @Query("SELECT COUNT(*) FROM quotations")
    suspend fun count(): Int
}

@Dao
interface DeliveryChallanDao {
    @Query("SELECT * FROM delivery_challans WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<DeliveryChallanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(challan: DeliveryChallanEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(challans: List<DeliveryChallanEntity>)

    @Query("UPDATE delivery_challans SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("UPDATE delivery_challans SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)

    @Query("SELECT COUNT(*) FROM delivery_challans")
    suspend fun count(): Int
}

@Dao
interface SalesReturnDao {
    @Query("SELECT * FROM sales_returns WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<SalesReturnEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(salesReturn: SalesReturnEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(returns: List<SalesReturnEntity>)

    @Query("UPDATE sales_returns SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("UPDATE sales_returns SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)

    @Query("SELECT COUNT(*) FROM sales_returns")
    suspend fun count(): Int
}

@Dao
interface PartyLedgerDao {
    @Query("SELECT * FROM party_ledger WHERE partyType = :partyType AND partyId = :partyId ORDER BY createdAtEpochMillis DESC")
    fun getForParty(partyType: String, partyId: String): Flow<List<PartyLedgerEntryEntity>>

    @Query("SELECT * FROM party_ledger ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<PartyLedgerEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: PartyLedgerEntryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entries: List<PartyLedgerEntryEntity>)
}

@Dao
interface PartyCollectionDao {
    @Query("SELECT * FROM party_collections ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<PartyCollectionEntity>>

    @Query("SELECT * FROM party_collections WHERE partyType = :partyType AND partyId = :partyId ORDER BY createdAtEpochMillis DESC")
    fun getForParty(partyType: String, partyId: String): Flow<List<PartyCollectionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(collection: PartyCollectionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(collections: List<PartyCollectionEntity>)

    @Query("UPDATE party_collections SET status = :status, verifiedBy = :verifiedBy, verifiedAtEpochMillis = :verifiedAt WHERE id = :id")
    suspend fun setStatus(id: String, status: String, verifiedBy: String?, verifiedAt: Long?)
}

@Dao
interface DiscountRuleDao {
    @Query("SELECT * FROM discount_rules WHERE isActive = 1")
    fun getAll(): Flow<List<DiscountRuleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(rule: DiscountRuleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(rules: List<DiscountRuleEntity>)
}

@Dao
interface SalesRouteDao {
    @Query("SELECT * FROM sales_routes WHERE isActive = 1")
    fun getAll(): Flow<List<SalesRouteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(route: SalesRouteEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(routes: List<SalesRouteEntity>)
}

@Dao
interface VisitLogDao {
    @Query("SELECT * FROM visit_logs ORDER BY checkInAtEpochMillis DESC")
    fun getAll(): Flow<List<VisitLogEntity>>

    @Query("SELECT * FROM visit_logs WHERE partyType = :partyType AND partyId = :partyId ORDER BY checkInAtEpochMillis DESC")
    fun getForParty(partyType: String, partyId: String): Flow<List<VisitLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(visit: VisitLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(visits: List<VisitLogEntity>)

    @Query("UPDATE visit_logs SET checkOutAtEpochMillis = :checkOutAt WHERE id = :id")
    suspend fun setCheckOut(id: String, checkOutAt: Long)
}

// ================= Module 5: Purchase Management =================

@Dao
interface SupplierDao {
    @Query("SELECT * FROM suppliers WHERE isDeleted = 0")
    fun getAll(): Flow<List<SupplierEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(supplier: SupplierEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(suppliers: List<SupplierEntity>)

    @Query("SELECT COUNT(*) FROM suppliers WHERE dedupKey = :dedupKey AND isDeleted = 0")
    suspend fun countByDedupKey(dedupKey: String): Int

    @Query("UPDATE suppliers SET dueBalance = dueBalance + :delta WHERE id = :id")
    suspend fun adjustDueBalance(id: String, delta: Double)

    @Query("UPDATE suppliers SET isDeleted = 1, deletedAtEpochMillis = :deletedAt, deletedBy = :deletedBy WHERE id = :id")
    suspend fun softDelete(id: String, deletedAt: Long, deletedBy: String)

    @Query("UPDATE suppliers SET isDeleted = 0, deletedAtEpochMillis = NULL, deletedBy = NULL WHERE id = :id")
    suspend fun restore(id: String)
}

@Dao
interface PurchaseOrderDao {
    @Query("SELECT * FROM purchase_orders WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<PurchaseOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(po: PurchaseOrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(pos: List<PurchaseOrderEntity>)

    @Query("UPDATE purchase_orders SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("SELECT COUNT(*) FROM purchase_orders")
    suspend fun count(): Int
}

@Dao
interface GoodsReceivedNoteDao {
    @Query("SELECT * FROM goods_received_notes WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<GoodsReceivedNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(grn: GoodsReceivedNoteEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(grns: List<GoodsReceivedNoteEntity>)
}

@Dao
interface PurchaseReturnDao {
    @Query("SELECT * FROM purchase_returns WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<PurchaseReturnEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(pr: PurchaseReturnEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(prs: List<PurchaseReturnEntity>)

    @Query("UPDATE purchase_returns SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)
}

// ================= Module 3: Inventory extras =================

@Dao
interface ProductCategoryDao {
    @Query("SELECT * FROM product_categories WHERE isActive = 1")
    fun getAll(): Flow<List<ProductCategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(category: ProductCategoryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(categories: List<ProductCategoryEntity>)
}

@Dao
interface ProductBrandDao {
    @Query("SELECT * FROM product_brands WHERE isActive = 1")
    fun getAll(): Flow<List<ProductBrandEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(brand: ProductBrandEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(brands: List<ProductBrandEntity>)
}

@Dao
interface InventoryLotDao {
    @Query("SELECT * FROM inventory_lots WHERE productId = :productId AND warehouseId = :warehouseId AND qtyRemaining > 0 ORDER BY expiryDateEpochMillis ASC")
    suspend fun getLotsFefo(productId: String, warehouseId: String): List<InventoryLotEntity>

    @Query("SELECT * FROM inventory_lots WHERE qtyRemaining > 0")
    fun getAll(): Flow<List<InventoryLotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(lot: InventoryLotEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(lots: List<InventoryLotEntity>)

    @Query("UPDATE inventory_lots SET qtyRemaining = :qty WHERE id = :id")
    suspend fun setRemaining(id: String, qty: Double)
}

@Dao
interface DamageReportDao {
    @Query("SELECT * FROM damage_reports ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<DamageReportEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(report: DamageReportEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(reports: List<DamageReportEntity>)
}

@Dao
interface StockTransferDao {
    @Query("SELECT * FROM stock_transfers ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<StockTransferEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(transfer: StockTransferEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(transfers: List<StockTransferEntity>)
}

// ================= Module 2: Manufacturing & Production extras =================

@Dao
interface BillOfMaterialsDao {
    @Query("SELECT * FROM bill_of_materials WHERE isActive = 1")
    fun getAll(): Flow<List<BillOfMaterialsEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(bom: BillOfMaterialsEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(boms: List<BillOfMaterialsEntity>)
}

@Dao
interface ProductionOrderDao {
    @Query("SELECT * FROM production_orders ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<ProductionOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(order: ProductionOrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(orders: List<ProductionOrderEntity>)

    @Query("UPDATE production_orders SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)
}

@Dao
interface QualityCheckDao {
    @Query("SELECT * FROM quality_checks ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<QualityCheckEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(check: QualityCheckEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(checks: List<QualityCheckEntity>)
}

@Dao
interface ProductionLossDao {
    @Query("SELECT * FROM production_losses ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<ProductionLossEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(loss: ProductionLossEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(losses: List<ProductionLossEntity>)
}

@Dao
interface MachineLogDao {
    @Query("SELECT * FROM machine_logs ORDER BY recordedAtEpochMillis DESC")
    fun getAll(): Flow<List<MachineLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(log: MachineLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(logs: List<MachineLogEntity>)
}

@Dao
interface ChartOfAccountDao {
    @Query("SELECT * FROM chart_of_accounts WHERE isActive = 1 ORDER BY code ASC")
    fun getAll(): Flow<List<ChartOfAccountEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(account: ChartOfAccountEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(accounts: List<ChartOfAccountEntity>)

    @Query("SELECT COUNT(*) FROM chart_of_accounts")
    suspend fun count(): Int
}

@Dao
interface VoucherDao {
    @Query("SELECT * FROM vouchers WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<VoucherEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(voucher: VoucherEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(vouchers: List<VoucherEntity>)

    @Query("UPDATE vouchers SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)

    @Query("SELECT COUNT(*) FROM vouchers")
    suspend fun count(): Int
}

@Dao
interface LeadDao {
    @Query("SELECT * FROM leads WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<LeadEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(lead: LeadEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(leads: List<LeadEntity>)

    @Query("UPDATE leads SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("UPDATE leads SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)
}

@Dao
interface OpportunityDao {
    @Query("SELECT * FROM opportunities ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<OpportunityEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(opportunity: OpportunityEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(opportunities: List<OpportunityEntity>)

    @Query("UPDATE opportunities SET stage = :stage WHERE id = :id")
    suspend fun setStage(id: String, stage: String)
}

@Dao
interface CustomerSegmentDao {
    @Query("SELECT * FROM customer_segments")
    fun getAll(): Flow<List<CustomerSegmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(segment: CustomerSegmentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(segments: List<CustomerSegmentEntity>)
}

@Dao
interface CallLogDao {
    @Query("SELECT * FROM call_logs ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<CallLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(call: CallLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(calls: List<CallLogEntity>)
}

@Dao
interface MeetingLogDao {
    @Query("SELECT * FROM meeting_logs ORDER BY meetingDateEpochMillis DESC")
    fun getAll(): Flow<List<MeetingLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(meeting: MeetingLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(meetings: List<MeetingLogEntity>)
}

@Dao
interface FollowUpDao {
    @Query("SELECT * FROM follow_ups ORDER BY dueDateEpochMillis ASC")
    fun getAll(): Flow<List<FollowUpEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(followUp: FollowUpEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(followUps: List<FollowUpEntity>)

    @Query("UPDATE follow_ups SET done = :done WHERE id = :id")
    suspend fun setDone(id: String, done: Boolean)
}

@Dao
interface LeaveRequestDao {
    @Query("SELECT * FROM leave_requests ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<LeaveRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(leave: LeaveRequestEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(leaves: List<LeaveRequestEntity>)

    @Query("UPDATE leave_requests SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)
}

@Dao
interface EmployeeLifecycleEventDao {
    @Query("SELECT * FROM employee_lifecycle_events ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<EmployeeLifecycleEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(event: EmployeeLifecycleEventEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(events: List<EmployeeLifecycleEventEntity>)
}

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages WHERE channelId = :channelId ORDER BY createdAtEpochMillis ASC")
    fun getForChannel(channelId: String): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages ORDER BY createdAtEpochMillis ASC")
    fun getAll(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(message: ChatMessageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(messages: List<ChatMessageEntity>)
}

@Dao
interface AnnouncementDao {
    @Query("SELECT * FROM announcements WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<AnnouncementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(announcement: AnnouncementEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(announcements: List<AnnouncementEntity>)

    @Query("UPDATE announcements SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)
}

@Dao
interface CircularDao {
    @Query("SELECT * FROM circulars WHERE isDeleted = 0 ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<CircularEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(circular: CircularEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(circulars: List<CircularEntity>)

    @Query("UPDATE circulars SET isDeleted = 1 WHERE id = :id")
    suspend fun softDelete(id: String)
}

@Dao
interface VehicleDao {
    @Query("SELECT * FROM vehicles WHERE isActive = 1")
    fun getAll(): Flow<List<VehicleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(vehicle: VehicleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(vehicles: List<VehicleEntity>)
}

@Dao
interface VehicleLocationPingDao {
    @Query("SELECT * FROM vehicle_location_pings WHERE vehicleId = :vehicleId ORDER BY recordedAtEpochMillis DESC LIMIT 1")
    fun getLatestForVehicle(vehicleId: String): Flow<VehicleLocationPingEntity?>

    @Query("SELECT * FROM vehicle_location_pings ORDER BY recordedAtEpochMillis DESC")
    fun getAll(): Flow<List<VehicleLocationPingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(ping: VehicleLocationPingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(pings: List<VehicleLocationPingEntity>)
}

@Dao
interface AttachmentDao {
    @Query("SELECT * FROM attachments WHERE moduleReference = :moduleReference AND entityId = :entityId ORDER BY createdAtEpochMillis DESC")
    fun getForEntity(moduleReference: String, entityId: String): Flow<List<AttachmentEntity>>

    @Query("SELECT * FROM attachments ORDER BY createdAtEpochMillis DESC")
    fun getAll(): Flow<List<AttachmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(attachment: AttachmentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(attachments: List<AttachmentEntity>)
}

@Dao
interface NotificationEntryDao {
    @Query("SELECT * FROM notification_entries ORDER BY createdAtEpochMillis DESC LIMIT 100")
    fun getAll(): Flow<List<NotificationEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: NotificationEntryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entries: List<NotificationEntryEntity>)

    @Query("UPDATE notification_entries SET isRead = 1 WHERE id = :id")
    suspend fun markRead(id: String)
}
