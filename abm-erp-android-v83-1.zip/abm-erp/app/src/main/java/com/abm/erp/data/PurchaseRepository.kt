package com.abm.erp.data

import android.content.Context
import com.abm.erp.data.room.AppDatabase
import com.abm.erp.data.room.GoodsReceivedNoteEntity
import com.abm.erp.data.room.PurchaseOrderEntity
import com.abm.erp.data.room.PurchaseReturnEntity
import com.abm.erp.data.room.SupplierEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset

/**
 * Module 5 — Purchase Management. Its own repository object, same pattern as
 * InventoryRepository — a GRN posting is what actually moves stock in
 * (calls InventoryRepository.stockIn) and increases the Supplier's due
 * balance, matching how a Sales Invoice moves stock out and increases a
 * Dealer's due balance. Purchase Ledger reuses the same PartyLedgerEntry
 * table as Dealer/Retailer (MockRepository.postPartyLedgerEntry) with
 * PartyType.SUPPLIER, rather than inventing a third parallel ledger shape.
 */
object PurchaseRepository {

    private lateinit var db: AppDatabase
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val firestoreDb by lazy { com.google.firebase.firestore.FirebaseFirestore.getInstance() }
    private var syncCompanyId: String? = null
    private var suppliersListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var purchaseOrdersListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var grnListenerReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var purchaseReturnsListenerReg: com.google.firebase.firestore.ListenerRegistration? = null

    private fun syncCollection(name: String) =
        firestoreDb.collection("companies").document(syncCompanyId ?: "_unset").collection(name)

    fun startCrossDeviceSync(companyId: String) {
        if (companyId == syncCompanyId) return
        syncCompanyId = companyId
        listenSuppliersRemote()
        listenPurchaseOrdersRemote()
        listenGrnRemote()
        listenPurchaseReturnsRemote()
    }

    private fun listenSuppliersRemote() {
        suppliersListenerReg?.remove()
        suppliersListenerReg = syncCollection("suppliers").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("PurchaseRepository", "suppliers sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(SupplierEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.supplierDao().upsertAll(list) }
        }
    }

    private fun listenPurchaseOrdersRemote() {
        purchaseOrdersListenerReg?.remove()
        purchaseOrdersListenerReg = syncCollection("purchaseOrders").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("PurchaseRepository", "purchaseOrders sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(PurchaseOrderEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.purchaseOrderDao().upsertAll(list) }
        }
    }

    private fun listenGrnRemote() {
        grnListenerReg?.remove()
        grnListenerReg = syncCollection("goodsReceivedNotes").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("PurchaseRepository", "goodsReceivedNotes sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(GoodsReceivedNoteEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.goodsReceivedNoteDao().upsertAll(list) }
        }
    }

    private fun listenPurchaseReturnsRemote() {
        purchaseReturnsListenerReg?.remove()
        purchaseReturnsListenerReg = syncCollection("purchaseReturns").addSnapshotListener { snap, err ->
            if (err != null) { android.util.Log.w("PurchaseRepository", "purchaseReturns sync listener error", err); return@addSnapshotListener }
            val list = snap?.documents?.mapNotNull { it.toObject(PurchaseReturnEntity::class.java) }.orEmpty()
            if (list.isNotEmpty()) scope.launch { db.purchaseReturnDao().upsertAll(list) }
        }
    }

    private fun pushSupplier(e: SupplierEntity) {
        syncCollection("suppliers").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("PurchaseRepository", "pushSupplier failed", it) }
    }

    private fun pushPurchaseOrder(e: PurchaseOrderEntity) {
        syncCollection("purchaseOrders").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("PurchaseRepository", "pushPurchaseOrder failed", it) }
    }

    private fun pushGrn(e: GoodsReceivedNoteEntity) {
        syncCollection("goodsReceivedNotes").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("PurchaseRepository", "pushGrn failed", it) }
    }

    private fun pushPurchaseReturn(e: PurchaseReturnEntity) {
        syncCollection("purchaseReturns").document(e.id).set(e)
            .addOnFailureListener { android.util.Log.w("PurchaseRepository", "pushPurchaseReturn failed", it) }
    }

    fun init(context: Context) {
        db = AppDatabase.getInstance(context)
        seedIfEmpty()

        suppliers = db.supplierDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        purchaseOrders = db.purchaseOrderDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        goodsReceivedNotes = db.goodsReceivedNoteDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        purchaseReturns = db.purchaseReturnDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
    }

    private fun seedIfEmpty() = runBlocking(Dispatchers.IO) {
        if (db.supplierDao().getAll().let { true } && db.purchaseOrderDao().count() == 0) {
            // Nothing seeded by default — Purchase Management starts empty on
            // a fresh install, same as Retailer did before its first
            // registration; the Foundation Layer's dedup/validation guards
            // are exercised for real starting from the very first Supplier.
        }
    }

    lateinit var suppliers: StateFlow<List<Supplier>>
        private set
    lateinit var purchaseOrders: StateFlow<List<PurchaseOrder>>
        private set
    lateinit var goodsReceivedNotes: StateFlow<List<GoodsReceivedNote>>
        private set
    lateinit var purchaseReturns: StateFlow<List<PurchaseReturn>>
        private set

    private fun dedupKeyFor(name: String, phone: String): String = (name.trim().lowercase() + "|" + phone.trim().filter { it.isDigit() })

    /** Supplier Registration — same dedup+validation+permission pattern as MockRepository.createDealer. */
    fun createSupplier(name: String, phone: String = "", address: String = "", creditLimit: Double = 0.0): Supplier? {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.CREATE)) {
            MockRepository.logAudit("Supplier", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            return null
        }
        if (name.isBlank()) return null
        if (creditLimit < 0) {
            android.util.Log.w("PurchaseRepository", "createSupplier rejected: negative creditLimit")
            return null
        }
        val dedupKey = dedupKeyFor(name, phone)
        var created: Supplier? = null
        runBlocking(Dispatchers.IO) {
            if (db.supplierDao().countByDedupKey(dedupKey) > 0) {
                android.util.Log.w("PurchaseRepository", "createSupplier rejected: duplicate name+phone")
                return@runBlocking
            }
            val supplier = Supplier(
                id = "SUP-${java.util.UUID.randomUUID().toString().take(8)}", name = name, phone = phone, address = address,
                creditLimit = creditLimit, dedupKey = dedupKey, createdBy = MockRepository.currentUser.name,
            )
            val entity = supplier.toEntity()
            db.supplierDao().upsert(entity)
            pushSupplier(entity)
            MockRepository.logAudit("Supplier", supplier.id, "CREATE", newValue = supplier)
            created = supplier
        }
        return created
    }

    /** Universal Action Menu: Duplicate. */
    fun duplicateSupplier(supplierId: String): DuplicateResult? {
        val s = suppliers.value.firstOrNull { it.id == supplierId } ?: return null
        val created = createSupplier("${s.name} (copy)", s.phone, s.address, s.creditLimit) ?: return null
        return DuplicateResult(created.id, created.name)
    }

    fun deleteSupplier(supplierId: String): Boolean {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.DELETE)) return false
        scope.launch {
            val now = System.currentTimeMillis()
            db.supplierDao().softDelete(supplierId, now, MockRepository.currentUser.name)
            syncCollection("suppliers").document(supplierId)
                .update(mapOf("isDeleted" to true, "deletedAtEpochMillis" to now, "deletedBy" to MockRepository.currentUser.name))
                .addOnFailureListener { android.util.Log.w("PurchaseRepository", "push supplier-delete failed", it) }
            MockRepository.logAudit("Supplier", supplierId, "DELETE")
        }
        return true
    }

    fun restoreSupplier(supplierId: String): Boolean {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.DELETE)) return false
        scope.launch {
            db.supplierDao().restore(supplierId)
            syncCollection("suppliers").document(supplierId)
                .update(mapOf("isDeleted" to false, "deletedAtEpochMillis" to null, "deletedBy" to null))
                .addOnFailureListener { android.util.Log.w("PurchaseRepository", "push supplier-restore failed", it) }
            MockRepository.logAudit("Supplier", supplierId, "RESTORE")
        }
        return true
    }

    // ---- Purchase Requisition / Purchase Order ----
    fun createPurchaseOrder(supplierId: String, supplierName: String, lineItems: List<PurchaseLineItem>): PurchaseOrder? {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.CREATE)) {
            MockRepository.logAudit("PurchaseOrder", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            return null
        }
        val po = PurchaseOrder(
            id = java.util.UUID.randomUUID().toString(), poNo = "PO-${(1000..9999).random()}",
            supplierId = supplierId, supplierName = supplierName, lineItems = lineItems, createdBy = MockRepository.currentUser.name,
        )
        scope.launch {
            val entity = po.toEntity()
            db.purchaseOrderDao().upsert(entity)
            pushPurchaseOrder(entity)
            MockRepository.logAudit("PurchaseOrder", po.poNo, "CREATE", newValue = po)
            MockRepository.createNotification(NotificationCategory.PURCHASE_ORDER, "New Purchase Order", "${po.poNo} — $supplierName")
        }
        return po
    }

    /** Universal Action Menu: Duplicate — clones line items into a brand-new DRAFT PO. */
    fun duplicatePurchaseOrder(poId: String): DuplicateResult? {
        val po = purchaseOrders.value.firstOrNull { it.id == poId } ?: return null
        val created = createPurchaseOrder(po.supplierId, po.supplierName, po.lineItems) ?: return null
        return DuplicateResult(created.id, created.poNo)
    }

    fun updatePurchaseOrderStatus(poId: String, status: String) {
        scope.launch {
            db.purchaseOrderDao().setStatus(poId, status)
            syncCollection("purchaseOrders").document(poId).update("status", status)
                .addOnFailureListener { android.util.Log.w("PurchaseRepository", "push po-status failed", it) }
            MockRepository.logAudit("PurchaseOrder", poId, "UPDATE", newValue = status)
        }
    }

    /**
     * GRN — Goods Received Note. This is what actually moves stock and
     * money: stock-in for every received line (via InventoryRepository,
     * same as any other stock-in) and a supplier due increase + Purchase
     * Ledger DEBIT posting (money we now owe). The PO itself never touches
     * stock or ledger — only a confirmed GRN does, since what's ordered and
     * what actually arrives can differ.
     */
    fun receiveGoods(purchaseOrderId: String, supplierId: String, supplierName: String, receivedItems: List<PurchaseLineItem>, warehouseId: String): GoodsReceivedNote? {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.CREATE)) {
            MockRepository.logAudit("GRN", "(new)", "DENY", oldValue = MockRepository.currentUser.role.name, newValue = "CREATE")
            return null
        }
        val grn = GoodsReceivedNote(
            id = java.util.UUID.randomUUID().toString(), grnNo = "GRN-${(1000..9999).random()}",
            purchaseOrderId = purchaseOrderId, supplierId = supplierId, supplierName = supplierName,
            receivedItems = receivedItems, warehouseId = warehouseId, receivedBy = MockRepository.currentUser.name,
        )
        scope.launch {
            val entity = grn.toEntity()
            db.goodsReceivedNoteDao().upsert(entity)
            pushGrn(entity)
            receivedItems.forEach { line ->
                InventoryRepository.stockIn(line.productId.ifBlank { line.name }, warehouseId, line.qty, "GRN ${grn.grnNo}")
            }
            db.supplierDao().adjustDueBalance(supplierId, grn.totalValue)
            syncCollection("suppliers").document(supplierId)
                .update("dueBalance", com.google.firebase.firestore.FieldValue.increment(grn.totalValue))
                .addOnFailureListener { android.util.Log.w("PurchaseRepository", "push supplier-due-increment failed", it) }
            MockRepository.postPartyLedgerEntry(PartyType.SUPPLIER, supplierId, "DEBIT", grn.totalValue, "GRN ${grn.grnNo}", entity.id)
            db.purchaseOrderDao().setStatus(purchaseOrderId, "RECEIVED")
            MockRepository.logAudit("GRN", grn.grnNo, "CREATE", newValue = grn)
            MockRepository.createNotification(NotificationCategory.GOODS_RECEIPT, "Goods Received", "${grn.grnNo} — $supplierName (৳${"%,.0f".format(grn.totalValue)})")
        }
        return grn
    }

    // ---- Purchase Return ----
    fun createPurchaseReturn(purchaseOrderId: String?, supplierId: String, supplierName: String, lineItems: List<PurchaseLineItem>, reason: String): PurchaseReturn? {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.CREATE)) return null
        val refund = lineItems.sumOf { it.lineTotal }
        val purchaseReturn = PurchaseReturn(
            id = java.util.UUID.randomUUID().toString(), returnNo = "PR-${(1000..9999).random()}",
            purchaseOrderId = purchaseOrderId, supplierId = supplierId, supplierName = supplierName,
            lineItems = lineItems, reason = reason, refundAmount = refund, createdBy = MockRepository.currentUser.name,
        )
        scope.launch {
            val entity = purchaseReturn.toEntity()
            db.purchaseReturnDao().upsert(entity)
            pushPurchaseReturn(entity)
            MockRepository.logAudit("PurchaseReturn", purchaseReturn.returnNo, "CREATE", newValue = purchaseReturn)
        }
        return purchaseReturn
    }

    fun approvePurchaseReturn(returnId: String): Boolean {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.APPROVE)) return false
        val purchaseReturn = purchaseReturns.value.firstOrNull { it.id == returnId } ?: return false
        scope.launch {
            db.purchaseReturnDao().setStatus(returnId, "APPROVED")
            syncCollection("purchaseReturns").document(returnId).update("status", "APPROVED")
                .addOnFailureListener { android.util.Log.w("PurchaseRepository", "push purchase-return-approve failed", it) }
            db.supplierDao().adjustDueBalance(purchaseReturn.supplierId, -purchaseReturn.refundAmount)
            MockRepository.postPartyLedgerEntry(PartyType.SUPPLIER, purchaseReturn.supplierId, "CREDIT", purchaseReturn.refundAmount, "Purchase Return ${purchaseReturn.returnNo}", returnId)
            MockRepository.logAudit("PurchaseReturn", purchaseReturn.returnNo, "APPROVE")
        }
        return true
    }

    fun rejectPurchaseReturn(returnId: String) {
        scope.launch {
            db.purchaseReturnDao().setStatus(returnId, "REJECTED")
            syncCollection("purchaseReturns").document(returnId).update("status", "REJECTED")
                .addOnFailureListener { android.util.Log.w("PurchaseRepository", "push purchase-return-reject failed", it) }
            MockRepository.logAudit("PurchaseReturn", returnId, "REJECT")
        }
    }

    /** Supplier Payment — outgoing money, mirrors MockRepository.createCollection's shape but posts a CREDIT (we owe them less) instead. */
    fun createSupplierPayment(supplierId: String, amount: Double, method: String = "BANK") {
        if (amount <= 0) {
            android.util.Log.w("PurchaseRepository", "createSupplierPayment rejected: non-positive amount")
            return
        }
        scope.launch {
            db.supplierDao().adjustDueBalance(supplierId, -amount)
            syncCollection("suppliers").document(supplierId)
                .update("dueBalance", com.google.firebase.firestore.FieldValue.increment(-amount))
                .addOnFailureListener { android.util.Log.w("PurchaseRepository", "push supplier-payment failed", it) }
            MockRepository.postPartyLedgerEntry(PartyType.SUPPLIER, supplierId, "CREDIT", amount, "Supplier payment ($method)", "")
            MockRepository.logAudit("SupplierPayment", supplierId, "CREATE", newValue = "৳$amount via $method")
        }
    }
}

// ================= Purchase Repository mappers =================

private fun Supplier.toEntity() = SupplierEntity(
    id = id, name = name, phone = phone, address = address, dueBalance = dueBalance, creditLimit = creditLimit,
    dedupKey = dedupKey, isActive = isActive, isDeleted = isDeleted, createdBy = createdBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    deletedAtEpochMillis = deletedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(), deletedBy = deletedBy,
)

private fun SupplierEntity.toDomain() = Supplier(
    id = id, name = name, phone = phone, address = address, dueBalance = dueBalance, creditLimit = creditLimit,
    dedupKey = dedupKey, isActive = isActive, isDeleted = isDeleted, createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    deletedAt = deletedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) }, deletedBy = deletedBy,
)

private fun packPurchaseLineItems(items: List<PurchaseLineItem>): String =
    items.joinToString(";") { "${it.productId},${it.name},${it.unit},${it.qty},${it.unitCost}" }

private fun unpackPurchaseLineItems(raw: String): List<PurchaseLineItem> {
    if (raw.isBlank()) return emptyList()
    return raw.split(";").filter { it.isNotBlank() }.map { record ->
        val p = record.split(",")
        PurchaseLineItem(productId = p[0], name = p[1], unit = p[2], qty = p[3].toDouble(), unitCost = p[4].toDouble())
    }
}

private fun PurchaseOrder.toEntity() = PurchaseOrderEntity(
    id = id, poNo = poNo, supplierId = supplierId, supplierName = supplierName,
    lineItemsRaw = packPurchaseLineItems(lineItems), status = status, createdBy = createdBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

private fun PurchaseOrderEntity.toDomain() = PurchaseOrder(
    id = id, poNo = poNo, supplierId = supplierId, supplierName = supplierName,
    lineItems = unpackPurchaseLineItems(lineItemsRaw), status = status, createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC), isDeleted = isDeleted,
)

private fun GoodsReceivedNote.toEntity() = GoodsReceivedNoteEntity(
    id = id, grnNo = grnNo, purchaseOrderId = purchaseOrderId, supplierId = supplierId, supplierName = supplierName,
    receivedItemsRaw = packPurchaseLineItems(receivedItems), warehouseId = warehouseId, receivedBy = receivedBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

private fun GoodsReceivedNoteEntity.toDomain() = GoodsReceivedNote(
    id = id, grnNo = grnNo, purchaseOrderId = purchaseOrderId, supplierId = supplierId, supplierName = supplierName,
    receivedItems = unpackPurchaseLineItems(receivedItemsRaw), warehouseId = warehouseId, receivedBy = receivedBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC), isDeleted = isDeleted,
)

private fun PurchaseReturn.toEntity() = PurchaseReturnEntity(
    id = id, returnNo = returnNo, purchaseOrderId = purchaseOrderId, supplierId = supplierId, supplierName = supplierName,
    lineItemsRaw = packPurchaseLineItems(lineItems), reason = reason, refundAmount = refundAmount, status = status,
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

private fun PurchaseReturnEntity.toDomain() = PurchaseReturn(
    id = id, returnNo = returnNo, purchaseOrderId = purchaseOrderId, supplierId = supplierId, supplierName = supplierName,
    lineItems = unpackPurchaseLineItems(lineItemsRaw), reason = reason, refundAmount = refundAmount, status = status,
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC), isDeleted = isDeleted,
)
