package com.abm.erp.ui.inventory

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.GlassCard
import com.abm.erp.core.ModuleGradientHeader
import com.abm.erp.core.SubModuleGrid
import com.abm.erp.core.SubModuleItem
import com.abm.erp.core.BackToSubMenuLink
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.MovementType
import com.abm.erp.theme.*
import kotlinx.coroutines.launch
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

class InventoryViewModel : ViewModel() {
    val stockLevels = InventoryRepository.stockLevels
    val products = InventoryRepository.products
    val warehouses = InventoryRepository.warehouses
    val movements = InventoryRepository.movements
    val categories = InventoryRepository.categories
    val brands = InventoryRepository.brands
    fun stockIn(productId: String, warehouseId: String, qty: Double, reason: String) =
        InventoryRepository.stockIn(productId, warehouseId, qty, reason)
    suspend fun stockOut(productId: String, warehouseId: String, qty: Double, reason: String) =
        InventoryRepository.stockOut(productId, warehouseId, qty, reason)
    fun addProduct(sku: String, name: String, unit: String, category: String, reorderThreshold: Double, defaultUnitPrice: Double, photoUri: String?, barcodeValue: String, categoryId: String?, brandId: String?) =
        InventoryRepository.addProduct(sku, name, unit, category, reorderThreshold, defaultUnitPrice, photoUri, barcodeValue, categoryId, brandId)
    fun createCategory(name: String) = InventoryRepository.createCategory(name)
    fun createBrand(name: String) = InventoryRepository.createBrand(name)
    fun duplicateProduct(id: String) = InventoryRepository.duplicateProduct(id)
    fun deleteProduct(id: String) = InventoryRepository.deleteProduct(id)
    fun restoreProduct(id: String) = InventoryRepository.restoreProduct(id)
    fun adjustStockToCount(productId: String, warehouseId: String, actualCount: Double, reason: String) =
        InventoryRepository.adjustStockToCount(productId, warehouseId, actualCount, reason)

    // ---- Module 3 gap-fill: Stock Transfer / Damage Tracking / Expiry Tracking ----
    val inventoryLots = InventoryRepository.inventoryLots
    val damageReports = InventoryRepository.damageReports
    val stockTransfers = InventoryRepository.stockTransfers
    suspend fun transferStock(productId: String, productName: String, fromWarehouseId: String, toWarehouseId: String, qty: Double) =
        InventoryRepository.transferStock(productId, productName, fromWarehouseId, toWarehouseId, qty)
    fun reportDamage(productId: String, productName: String, warehouseId: String, qty: Double, reason: String) =
        InventoryRepository.reportDamage(productId, productName, warehouseId, qty, reason)
    fun stockInWithExpiry(productId: String, warehouseId: String, qty: Double, reason: String, expiryDate: java.time.LocalDateTime?, batchCode: String) =
        InventoryRepository.stockInWithExpiry(productId, warehouseId, qty, reason, expiryDate, batchCode)
}

@Composable
fun InventoryScreen(vm: InventoryViewModel = viewModel()) {
    var tab by remember { mutableStateOf<Int?>(null) }
    val subItems = listOf(
        SubModuleItem("levels", "Stock Levels", "📦", 0xFF3DDC97, 0xFF1FA972),
        SubModuleItem("move", "Stock In/Out", "🔄", 0xFF4E9CFF, 0xFF2E6FE0),
        SubModuleItem("add", "Add Product", "➕", 0xFFFFB020, 0xFFE08A00),
        SubModuleItem("catbrand", "Category & Brand", "🏷️", 0xFFB45CFF, 0xFF7A2EE0),
        SubModuleItem("adjust", "Stock Adjustment", "⚖️", 0xFFE85D4A, 0xFFC03A2B),
        SubModuleItem("transfer", "Stock Transfer", "🚚", 0xFF3FA9F5, 0xFF1D78C7),
        SubModuleItem("damage", "Damage Tracking", "💥", 0xFFFF5252, 0xFFC62828),
        SubModuleItem("expiry", "Expiry Tracking", "⏳", 0xFFFFB300, 0xFFE08600),
    )
    Column(Modifier.fillMaxSize()) {
        ModuleGradientHeader("Inventory & Stock Management", "📦", 0xFF12C2A9, 0xFF0E9F8B)
        Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Real-time stock across warehouses", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        if (tab == null) {
            SubModuleGrid(subItems) { key -> tab = when (key) { "levels" -> 0; "move" -> 1; "add" -> 2; "catbrand" -> 3; "adjust" -> 4; "transfer" -> 5; "damage" -> 6; else -> 7 } }
        } else {
            BackToSubMenuLink(onClick = { tab = null })
            when (tab) {
                0 -> StockLevelsTab(vm)
                1 -> StockMovementTab(vm)
                2 -> AddProductTab(vm)
                3 -> CategoryBrandTab(vm)
                4 -> StockAdjustmentTab(vm)
                5 -> StockTransferTab(vm)
                6 -> DamageTrackingTab(vm)
                else -> ExpiryTrackingTab(vm)
            }
        }
        }
    }
}

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun StockLevelsTab(vm: InventoryViewModel) {
    val levels by vm.stockLevels.collectAsState()
    var category by remember { mutableStateOf(com.abm.erp.data.StockCategory.STORE) }
    val filtered = levels.filter { it.stockCategory == category }
    val lowCount = filtered.count { it.isLowStock }

    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            com.abm.erp.data.StockCategory.values().forEach { c ->
                FilterChip(
                    selected = category == c,
                    onClick = { category = c },
                    label = { Text(if (c == com.abm.erp.data.StockCategory.STORE) "Store" else "Production") },
                    modifier = Modifier.weight(1f),
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (lowCount > 0) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text("⚠ $lowCount item(s) at or below reorder level", color = WarningAmber, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            items(filtered) { level ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(level.productName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(level.warehouseName, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${"%.1f".format(level.quantityOnHand)} ${level.unit}", color = if (level.isLowStock) DangerRed else SuccessGreen, fontWeight = FontWeight.Bold)
                            if (level.isLowStock) {
                                Text("below reorder (${"%.0f".format(level.reorderThreshold)})", style = MaterialTheme.typography.labelSmall, color = DangerRed)
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    val pct = if (level.reorderThreshold > 0) (level.quantityOnHand / (level.reorderThreshold * 2)).coerceIn(0.0, 1.0) else 0.5
                    val barColor = when { level.quantityOnHand <= level.reorderThreshold -> DangerRed; level.quantityOnHand <= level.reorderThreshold * 1.5 -> WarningAmber; else -> SuccessGreen }
                    Box(Modifier.fillMaxWidth().height(6.dp).background(Color(0xFFEEF1F5), androidx.compose.foundation.shape.RoundedCornerShape(999.dp))) {
                        Box(Modifier.fillMaxWidth(pct.toFloat()).fillMaxHeight().background(barColor, androidx.compose.foundation.shape.RoundedCornerShape(999.dp)))
                    }
                }
            }
            if (filtered.isEmpty()) {
                item { Text("No stock recorded yet in this category.", color = TextSecondary) }
            }
        }
    }
}

@Composable
private fun StockMovementTab(vm: InventoryViewModel) {
    val products by vm.products.collectAsState()
    val warehouses by vm.warehouses.collectAsState()
    val movements by vm.movements.collectAsState()
    val scope = rememberCoroutineScope()

    var selectedProduct by remember { mutableStateOf<String?>(null) }
    var selectedWarehouse by remember { mutableStateOf<String?>(null) }
    var qtyText by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Record stock movement", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))

                Text("Product", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                DropdownPicker(
                    options = products.map { it.id to it.name },
                    selectedId = selectedProduct,
                    onSelect = { selectedProduct = it },
                )
                Spacer(Modifier.height(8.dp))

                Text("Warehouse", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                DropdownPicker(
                    options = warehouses.map { it.id to it.name },
                    selectedId = selectedWarehouse,
                    onSelect = { selectedWarehouse = it },
                )
                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = qtyText, onValueChange = { qtyText = it },
                    label = { Text("Quantity") }, modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = reason, onValueChange = { reason = it },
                    label = { Text("Reason (e.g. Dealer fulfillment, Purchase)") }, modifier = Modifier.fillMaxWidth(),
                )
                errorMsg?.let {
                    Spacer(Modifier.height(4.dp))
                    Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall)
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val qty = qtyText.toDoubleOrNull()
                            if (selectedProduct == null || selectedWarehouse == null || qty == null || qty <= 0.0) {
                                errorMsg = "Select product, warehouse, and a valid quantity."
                                return@Button
                            }
                            errorMsg = null
                            vm.stockIn(selectedProduct!!, selectedWarehouse!!, qty, reason.ifBlank { "Stock in" })
                            qtyText = ""; reason = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                    ) { Text("Stock IN") }

                    Button(
                        onClick = {
                            val qty = qtyText.toDoubleOrNull()
                            if (selectedProduct == null || selectedWarehouse == null || qty == null || qty <= 0.0) {
                                errorMsg = "Select product, warehouse, and a valid quantity."
                                return@Button
                            }
                            scope.launch {
                                val ok = vm.stockOut(selectedProduct!!, selectedWarehouse!!, qty, reason.ifBlank { "Stock out" })
                                errorMsg = if (ok) null else "Not enough stock on hand for this warehouse."
                                if (ok) { qtyText = ""; reason = "" }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                    ) { Text("Stock OUT") }
                }
            }
        }
        item { Text("Movement history", style = MaterialTheme.typography.titleMedium) }
        items(movements) { m ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("${m.productName} · ${m.warehouseName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(m.reason, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    Text(
                        "${if (m.type == MovementType.IN) "+" else "−"}${"%.1f".format(m.quantity)}",
                        color = if (m.type == MovementType.IN) SuccessGreen else DangerRed,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}

@Composable
private fun AddProductTab(vm: InventoryViewModel) {
    var sku by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var reorder by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }
    var photoUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var barcodeValue by remember { mutableStateOf("") }
    var selectedCategoryId by remember { mutableStateOf<String?>(null) }
    var selectedBrandId by remember { mutableStateOf<String?>(null) }
    val categories by vm.categories.collectAsState()
    val brands by vm.brands.collectAsState()
    val photoLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent(),
    ) { uri -> photoUri = uri }
    val products by vm.products.collectAsState()
    val allMovements by vm.movements.collectAsState()

    Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState())) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Add a new product / SKU", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(56.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                    .background(Color(0xFFF0F2F6)).clickable { photoLauncher.launch("image/*") },
                contentAlignment = Alignment.Center,
            ) {
                if (photoUri != null) {
                    androidx.compose.foundation.Image(
                        painter = coil.compose.rememberAsyncImagePainter(photoUri), contentDescription = null,
                        modifier = Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    )
                } else {
                    Text("📷", fontSize = 20.sp)
                }
            }
            Spacer(Modifier.width(10.dp))
            Text(if (photoUri != null) "আসল product photo যোগ হয়েছে ✓" else "Company real product photo দিন (ঐচ্ছিক)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = sku, onValueChange = { sku = it }, label = { Text("SKU code") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Product name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = barcodeValue, onValueChange = { barcodeValue = it }, label = { Text("Barcode / QR value (স্ক্যান করুন বা লিখুন)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text("Unit (kg, ctn, pcs)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category (free text, e.g. \"Tea\")") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text("Category master (Module 3)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        DropdownPicker(options = categories.map { it.id to it.name }, selectedId = selectedCategoryId, onSelect = { selectedCategoryId = it })
        Spacer(Modifier.height(8.dp))
        Text("Brand", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        DropdownPicker(options = brands.map { it.id to it.name }, selectedId = selectedBrandId, onSelect = { selectedBrandId = it })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = reorder, onValueChange = { reorder = it }, label = { Text("Reorder threshold") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("Default unit price") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        if (saved) Text("✓ Product saved", color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                vm.addProduct(
                    sku = sku, name = name, unit = unit.ifBlank { "pcs" }, category = category.ifBlank { "General" },
                    reorderThreshold = reorder.toDoubleOrNull() ?: 0.0, defaultUnitPrice = price.toDoubleOrNull() ?: 0.0,
                    photoUri = photoUri?.toString(), barcodeValue = barcodeValue, categoryId = selectedCategoryId, brandId = selectedBrandId,
                )
                sku = ""; name = ""; unit = ""; category = ""; reorder = ""; price = ""; photoUri = null; barcodeValue = ""
                saved = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = DeepIndigo),
            enabled = name.isNotBlank(),
        ) { Text("Save product") }
    }

    Spacer(Modifier.height(16.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text("Product Directory (${products.size})", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 4.dp))
        val context = androidx.compose.ui.platform.LocalContext.current
        com.abm.erp.core.ModuleActionBar(
            onExport = {
                val header = "SKU,Name,Category,Unit,Price\n"
                val rows = products.joinToString("\n") { p -> com.abm.erp.core.toCsvRow(p.sku, p.name, p.category, p.unit, p.defaultUnitPrice) }
                val file = java.io.File(context.getExternalFilesDir(null), "product_directory_${System.currentTimeMillis()}.csv")
                file.writeText(header + rows)
                android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
            },
            onShare = {
                val summary = "Product Directory (${products.size} items)\n" + products.take(20).joinToString("\n") { "${it.name} (${it.sku}) — ৳${it.defaultUnitPrice}" }
                val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                try { context.startActivity(android.content.Intent.createChooser(intent, "Product Directory")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
            },
        )
    }
    Spacer(Modifier.height(8.dp))
    products.forEach { p ->
        GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(p.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Text("${p.sku} · ${p.category} · ৳${p.defaultUnitPrice}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                com.abm.erp.core.UniversalActionMenu(
                    moduleReference = "Product", entityId = p.id, entityLabel = p.name,
                    shareText = "${p.name} (${p.sku})\nCategory: ${p.category}\nPrice: ৳${p.defaultUnitPrice}",
                    isDeleted = p.isDeleted,
                    onDuplicate = { vm.duplicateProduct(p.id) },
                    onArchive = { vm.deleteProduct(p.id) },
                    onRestore = { vm.restoreProduct(p.id) },
                    csvHeader = "SKU,Name,Category,Unit,Price",
                    csvRow = com.abm.erp.core.toCsvRow(p.sku, p.name, p.category, p.unit, p.defaultUnitPrice),
                    historyLabel = "Stock History",
                    historyItems = allMovements.filter { it.productName == p.name }.map { "${it.type}: ${it.quantity} ${p.unit} — ${it.reason}" },
                )
            }
        }
    }
    }
}

@Composable
private fun CategoryBrandTab(vm: InventoryViewModel) {
    val categories by vm.categories.collectAsState()
    val brands by vm.brands.collectAsState()
    var newCategory by remember { mutableStateOf("") }
    var newBrand by remember { mutableStateOf("") }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Categories (${categories.size})", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                categories.forEach { c ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("• ${c.name}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 2.dp))
                        com.abm.erp.core.UniversalActionMenu(moduleReference = "Category", entityId = c.id, entityLabel = c.name, shareText = "Category: ${c.name}", csvHeader = "Name", csvRow = c.name)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = newCategory, onValueChange = { newCategory = it }, label = { Text("New category") }, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { if (newCategory.isNotBlank()) { vm.createCategory(newCategory); newCategory = "" } }) { Text("+ Add") }
                }
            }
        }
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Brands (${brands.size})", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                brands.forEach { b ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("• ${b.name}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 2.dp))
                        com.abm.erp.core.UniversalActionMenu(moduleReference = "Brand", entityId = b.id, entityLabel = b.name, shareText = "Brand: ${b.name}", csvHeader = "Name", csvRow = b.name)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = newBrand, onValueChange = { newBrand = it }, label = { Text("New brand") }, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { if (newBrand.isNotBlank()) { vm.createBrand(newBrand); newBrand = "" } }) { Text("+ Add") }
                }
            }
        }
    }
}

@Composable
private fun StockAdjustmentTab(vm: InventoryViewModel) {
    val products by vm.products.collectAsState()
    val warehouses by vm.warehouses.collectAsState()
    val stockLevels by vm.stockLevels.collectAsState()
    var selectedProduct by remember { mutableStateOf<String?>(null) }
    var selectedWarehouse by remember { mutableStateOf<String?>(null) }
    var actualCountText by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var confirmMsg by remember { mutableStateOf<String?>(null) }
    val currentOnHand = stockLevels.firstOrNull { it.productId == selectedProduct && it.warehouseId == selectedWarehouse }?.quantityOnHand

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Text("Stock count reconciliation", style = MaterialTheme.typography.titleMedium)
        Text("ফিজিক্যাল গণনার সংখ্যা দিন — সিস্টেম নিজে থেকে পার্থক্যটা হিসাব করে adjust করবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(10.dp))
        Text("Product", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
        DropdownPicker(options = products.map { it.id to it.name }, selectedId = selectedProduct, onSelect = { selectedProduct = it })
        Spacer(Modifier.height(8.dp))
        Text("Warehouse", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
        DropdownPicker(options = warehouses.map { it.id to it.name }, selectedId = selectedWarehouse, onSelect = { selectedWarehouse = it })
        Spacer(Modifier.height(8.dp))
        currentOnHand?.let { Text("System-এ এখন আছে: ${"%.1f".format(it)}", style = MaterialTheme.typography.bodySmall, color = TextSecondary) }
        OutlinedTextField(value = actualCountText, onValueChange = { actualCountText = it }, label = { Text("Actual counted quantity") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason (e.g. Monthly stock-take)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        confirmMsg?.let { Text(it, color = SuccessGreen, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(bottom = 8.dp)) }
        Button(
            onClick = {
                val actual = actualCountText.toDoubleOrNull() ?: return@Button
                val p = selectedProduct ?: return@Button
                val w = selectedWarehouse ?: return@Button
                vm.adjustStockToCount(p, w, actual, reason)
                confirmMsg = "✓ Adjustment recorded"
                actualCountText = ""; reason = ""
            },
            enabled = selectedProduct != null && selectedWarehouse != null && actualCountText.toDoubleOrNull() != null,
            colors = ButtonDefaults.buttonColors(containerColor = WarningAmber),
        ) { Text("Apply Adjustment") }
    }
}

@Composable
private fun DropdownPicker(options: List<Pair<String, String>>, selectedId: String?, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val label = options.firstOrNull { it.first == selectedId }?.second ?: "Select…"
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(label) }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { (id, name) ->
                DropdownMenuItem(text = { Text(name) }, onClick = { onSelect(id); expanded = false })
            }
        }
    }
}

@Composable
private fun StockTransferTab(vm: InventoryViewModel) {
    val products by vm.products.collectAsState()
    val warehouses by vm.warehouses.collectAsState()
    val transfers by vm.stockTransfers.collectAsState()
    val scope = rememberCoroutineScope()
    var selectedProduct by remember { mutableStateOf<String?>(null) }
    var fromWarehouse by remember { mutableStateOf<String?>(null) }
    var toWarehouse by remember { mutableStateOf<String?>(null) }
    var qtyText by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    Column {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Transfer stock between warehouses", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            Text("Product", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            DropdownPicker(options = products.map { it.id to it.name }, selectedId = selectedProduct, onSelect = { selectedProduct = it })
            Spacer(Modifier.height(8.dp))
            Text("From warehouse", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            DropdownPicker(options = warehouses.map { it.id to it.name }, selectedId = fromWarehouse, onSelect = { fromWarehouse = it })
            Spacer(Modifier.height(8.dp))
            Text("To warehouse", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            DropdownPicker(options = warehouses.map { it.id to it.name }, selectedId = toWarehouse, onSelect = { toWarehouse = it })
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Quantity") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            message?.let { Text(it, color = if (it.startsWith("✓")) SuccessGreen else DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(bottom = 8.dp)) }
            Button(
                onClick = {
                    val qty = qtyText.toDoubleOrNull() ?: return@Button
                    val p = products.firstOrNull { it.id == selectedProduct } ?: return@Button
                    val from = fromWarehouse ?: return@Button
                    val to = toWarehouse ?: return@Button
                    if (from == to) { message = "উৎস আর গন্তব্য warehouse একই হতে পারবে না।"; return@Button }
                    scope.launch {
                        val ok = vm.transferStock(p.id, p.name, from, to, qty)
                        message = if (ok) "✓ Transfer সম্পন্ন" else "যথেষ্ট স্টক নেই উৎস warehouse-এ।"
                        if (ok) { qtyText = "" }
                    }
                },
                enabled = selectedProduct != null && fromWarehouse != null && toWarehouse != null && qtyText.toDoubleOrNull() != null,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Transfer") }
        }
        Spacer(Modifier.height(14.dp))
        Text("Recent transfers", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(transfers) { t ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${t.productName} × ${"%.1f".format(t.qty)}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${t.fromWarehouseId} → ${t.toWarehouseId} · by ${t.createdBy}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        com.abm.erp.core.UniversalActionMenu(moduleReference = "StockTransfer", entityId = t.id, entityLabel = t.productName, shareText = "Transfer: ${t.productName} × ${t.qty}\n${t.fromWarehouseId} → ${t.toWarehouseId}", csvHeader = "Product,Qty,From,To", csvRow = com.abm.erp.core.toCsvRow(t.productName, t.qty, t.fromWarehouseId, t.toWarehouseId))
                    }
                }
            }
        }
    }
}

@Composable
private fun DamageTrackingTab(vm: InventoryViewModel) {
    val products by vm.products.collectAsState()
    val warehouses by vm.warehouses.collectAsState()
    val reports by vm.damageReports.collectAsState()
    var selectedProduct by remember { mutableStateOf<String?>(null) }
    var selectedWarehouse by remember { mutableStateOf<String?>(null) }
    var qtyText by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    Column {
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Report damaged stock", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            Text("Product", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            DropdownPicker(options = products.map { it.id to it.name }, selectedId = selectedProduct, onSelect = { selectedProduct = it })
            Spacer(Modifier.height(8.dp))
            Text("Warehouse", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            DropdownPicker(options = warehouses.map { it.id to it.name }, selectedId = selectedWarehouse, onSelect = { selectedWarehouse = it })
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Quantity damaged") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            message?.let { Text(it, color = if (it.startsWith("✓")) SuccessGreen else DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(bottom = 8.dp)) }
            Button(
                onClick = {
                    val qty = qtyText.toDoubleOrNull() ?: return@Button
                    val p = products.firstOrNull { it.id == selectedProduct } ?: return@Button
                    val w = selectedWarehouse ?: return@Button
                    val ok = vm.reportDamage(p.id, p.name, w, qty, reason)
                    message = if (ok) "✓ Damage report লেখা হয়েছে, স্টক থেকে বাদ" else "যথেষ্ট স্টক নেই।"
                    if (ok) { qtyText = ""; reason = "" }
                },
                enabled = selectedProduct != null && selectedWarehouse != null && qtyText.toDoubleOrNull() != null,
                colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Report Damage") }
        }
        Spacer(Modifier.height(14.dp))
        Text("Damage history", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(reports) { r ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${r.productName} × ${"%.1f".format(r.qty)}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${r.reason} · by ${r.reportedBy}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        com.abm.erp.core.UniversalActionMenu(moduleReference = "DamageReport", entityId = r.id, entityLabel = r.productName, shareText = "Damage: ${r.productName} × ${r.qty}\nReason: ${r.reason}", csvHeader = "Product,Qty,Reason", csvRow = com.abm.erp.core.toCsvRow(r.productName, r.qty, r.reason))
                    }
                }
            }
        }
    }
}

@Composable
private fun ExpiryTrackingTab(vm: InventoryViewModel) {
    val products by vm.products.collectAsState()
    val warehouses by vm.warehouses.collectAsState()
    val lots by vm.inventoryLots.collectAsState()
    var selectedProduct by remember { mutableStateOf<String?>(null) }
    var selectedWarehouse by remember { mutableStateOf<String?>(null) }
    var qtyText by remember { mutableStateOf("") }
    var batchCode by remember { mutableStateOf("") }
    var expiryDays by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    val now = java.time.LocalDateTime.now()
    val soonExpiring = lots.filter { it.expiryDate != null && it.expiryDate.isBefore(now.plusDays(30)) && it.qtyRemaining > 0 }

    Column {
        if (soonExpiring.isNotEmpty()) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("⚠ ৩০ দিনের মধ্যে মেয়াদ শেষ হবে (${soonExpiring.size})", color = WarningAmber, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                soonExpiring.forEach { lot ->
                    val pname = products.firstOrNull { it.id == lot.productId }?.name ?: lot.productId
                    Text("$pname — batch ${lot.batchCode} · ${"%.1f".format(lot.qtyRemaining)} left · expires ${lot.expiryDate?.toLocalDate()}", style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Stock-in with expiry (perishable goods)", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            Text("Product", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            DropdownPicker(options = products.map { it.id to it.name }, selectedId = selectedProduct, onSelect = { selectedProduct = it })
            Spacer(Modifier.height(8.dp))
            Text("Warehouse", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            DropdownPicker(options = warehouses.map { it.id to it.name }, selectedId = selectedWarehouse, onSelect = { selectedWarehouse = it })
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = qtyText, onValueChange = { qtyText = it }, label = { Text("Quantity") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = batchCode, onValueChange = { batchCode = it }, label = { Text("Batch code (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = expiryDays, onValueChange = { expiryDays = it }, label = { Text("মেয়াদ শেষ — কত দিন পরে (সংখ্যা)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            message?.let { Text(it, color = SuccessGreen, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(bottom = 8.dp)) }
            Button(
                onClick = {
                    val qty = qtyText.toDoubleOrNull() ?: return@Button
                    val p = selectedProduct ?: return@Button
                    val w = selectedWarehouse ?: return@Button
                    val days = expiryDays.toLongOrNull()
                    val expiry = days?.let { now.plusDays(it) }
                    vm.stockInWithExpiry(p, w, qty, "Perishable stock-in", expiry, batchCode)
                    message = "✓ Stock-in সম্পন্ন, expiry tracked"
                    qtyText = ""; batchCode = ""; expiryDays = ""
                },
                enabled = selectedProduct != null && selectedWarehouse != null && qtyText.toDoubleOrNull() != null,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Stock In") }
        }
    }
}
