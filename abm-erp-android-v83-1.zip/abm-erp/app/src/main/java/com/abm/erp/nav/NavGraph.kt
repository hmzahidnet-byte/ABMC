package com.abm.erp.nav

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.abm.erp.ui.advisory.BoardroomScreen
import com.abm.erp.ui.approvals.ApprovalsScreen
import com.abm.erp.ui.billing.CreditAndBillingScreen
import com.abm.erp.ui.complaint.ComplaintBoxScreen
import com.abm.erp.ui.courier.CourierScreen
import com.abm.erp.ui.crm.GeoCrmScreen
import com.abm.erp.ui.dashboard.MainDashboardScreen
import com.abm.erp.ui.dealer.DealersScreen
import com.abm.erp.ui.helpdesk.HelpdeskScreen
import com.abm.erp.ui.hrm.PayrollScreen
import com.abm.erp.ui.inventory.InventoryScreen
import com.abm.erp.ui.ledger.LedgerScreen
import com.abm.erp.ui.market.MarketAnalysisScreen
import com.abm.erp.ui.notifications.NotificationsScreen
import com.abm.erp.ui.production.ProductionScreen
import com.abm.erp.ui.purchase.PurchaseScreen
import com.abm.erp.ui.comms.CommunicationHubScreen
import com.abm.erp.ui.reports.ReportsScreen
import com.abm.erp.ui.sales.SalesChainScreen
import com.abm.erp.ui.tasks.TaskManagerScreen

sealed class Dest(val route: String, val label: String) {
    data object Dashboard : Dest("dashboard", "Dashboard")
    data object Sales : Dest("sales", "Sales Chain")
    data object Inventory : Dest("inventory", "Inventory")
    data object Crm : Dest("crm", "Geo CRM")
    data object Hrm : Dest("hrm", "HRM & Payroll")
    data object Billing : Dest("billing", "Credit & Billing")
    data object Production : Dest("production", "Production")
    data object Boardroom : Dest("boardroom", "Boardroom")
    data object Complaint : Dest("complaint", "Complaint Box")
    data object Dealers : Dest("dealers", "Dealers & Stock")
    data object Courier : Dest("courier", "Courier & Logistics")
    data object Tasks : Dest("tasks", "Task Manager")
    data object Approvals : Dest("approvals", "Approvals")
    data object Notifications : Dest("notifications", "Notifications")
    data object Market : Dest("market", "Market Analysis")
    data object Ledger : Dest("ledger", "Accounts / Ledger")
    data object Helpdesk : Dest("helpdesk", "Helpdesk")
    data object Reports : Dest("reports", "Reports")
    data object Purchase : Dest("purchase", "Purchase")
    data object Comms : Dest("comms", "Communication Hub")
}

val bottomNavItems = listOf(Dest.Dashboard, Dest.Sales, Dest.Inventory, Dest.Crm, Dest.Hrm, Dest.Billing, Dest.Production, Dest.Boardroom)

@Composable
fun ABMNavGraph(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Dest.Dashboard.route) {
        composable(Dest.Dashboard.route) { MainDashboardScreen(onNavigate = { navController.navigate(it) }) }
        composable(Dest.Sales.route) { SalesChainScreen() }
        composable(Dest.Inventory.route) { InventoryScreen() }
        composable(Dest.Crm.route) { GeoCrmScreen() }
        composable(Dest.Hrm.route) { PayrollScreen() }
        composable(Dest.Billing.route) { CreditAndBillingScreen() }
        composable(Dest.Production.route) { ProductionScreen() }
        composable(Dest.Boardroom.route) { BoardroomScreen() }
        composable(Dest.Complaint.route) { ComplaintBoxScreen() }
        composable(Dest.Dealers.route) { DealersScreen() }
        composable(Dest.Courier.route) { CourierScreen() }
        composable(Dest.Tasks.route) { TaskManagerScreen() }
        composable(Dest.Approvals.route) { ApprovalsScreen() }
        composable(Dest.Notifications.route) { NotificationsScreen() }
        composable(Dest.Market.route) { MarketAnalysisScreen() }
        composable(Dest.Ledger.route) { LedgerScreen() }
        composable(Dest.Helpdesk.route) { HelpdeskScreen() }
        composable(Dest.Reports.route) { ReportsScreen() }
        composable(Dest.Purchase.route) { PurchaseScreen() }
        composable(Dest.Comms.route) { CommunicationHubScreen() }
    }
}
