package com.abm.erp.ui.dealer

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.MockRepository
import com.abm.erp.data.PartyType
import com.abm.erp.data.PermissionAction
import com.abm.erp.data.PermissionManager
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * Module 7 — Dealer Management (DMS). ViewModel delegates every action to
 * MockRepository/FirebaseSync (repository pattern) and every write already
 * runs through PermissionManager + audit log at the repository layer — the
 * canX() checks here only control what the UI shows/hides.
 */
class DealersScreenViewModel : ViewModel() {
    val dealers = MockRepository.dealers
    val dealerOrders = FirebaseSync.dealerOrders
    val collections = MockRepository.partyCollections

    fun setDealerOrderStatus(id: String, status: String) = FirebaseSync.setDealerOrderStatus(id, status)
    fun createDealer(name: String, zone: String, phone: String, address: String) = MockRepository.createDealer(name, zone, phone, address)
    fun deleteDealer(id: String) = MockRepository.deleteDealer(id)
    fun restoreDealer(id: String) = MockRepository.restoreDealer(id)

    fun ledgerFor(dealerId: String) = MockRepository.partyLedgerFor(PartyType.DEALER, dealerId)
    fun visitsFor(dealerId: String) = MockRepository.visitLogsFor(PartyType.DEALER, dealerId)
    fun createCollection(dealerId: String, dealerName: String, amount: Double, method: String) =
        MockRepository.createCollection(PartyType.DEALER, dealerId, dealerName, amount, method)
    fun verifyCollection(id: String) = MockRepository.verifyCollection(id)
    fun rejectCollection(id: String) = MockRepository.rejectCollection(id)

    fun canCreateDealer() = PermissionManager.canCurrentUser("dealer", PermissionAction.CREATE)
    fun canDeleteDealer() = PermissionManager.canCurrentUser("dealer", PermissionAction.DELETE)
    fun canApproveCollection() = PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)
    fun duplicateDealerAction(id: String) = MockRepository.duplicateDealer(id)
    fun deleteDealerAction(id: String) = MockRepository.deleteDealer(id)
    fun restoreDealerAction(id: String) = MockRepository.restoreDealer(id)
    fun duplicateRetailerAction(id: String) = MockRepository.duplicateRetailer(id)
    fun archiveRetailerAction(id: String) = MockRepository.deleteRetailer(id)
    fun restoreRetailerAction(id: String) = MockRepository.restoreRetailer(id)
    fun creditUtilization(d: com.abm.erp.data.Dealer) = MockRepository.creditUtilization(d)
    fun creditUtilization(r: com.abm.erp.data.Retailer) = MockRepository.creditUtilization(r)
    fun inactiveDealers() = MockRepository.inactiveDealers()

    // ---- Module 8: Retailer / Outlet ----
    val retailers = MockRepository.retailers
    val salesRoutes = MockRepository.salesRoutes
    fun createRetailer(name: String, phone: String, address: String, dealerId: String?, outletCategory: String, outletType: String) =
        MockRepository.createRetailer(name = name, phone = phone, address = address, dealerId = dealerId, outletCategory = outletCategory, outletType = outletType)
    fun deleteRetailer(id: String) = MockRepository.deleteRetailer(id)
    fun retailerLedgerFor(retailerId: String) = MockRepository.partyLedgerFor(PartyType.RETAILER, retailerId)
    fun retailerVisitsFor(retailerId: String) = MockRepository.visitLogsFor(PartyType.RETAILER, retailerId)
    fun createRoute(name: String, employeeId: String) = MockRepository.createRoute(name, null, employeeId, emptyList())
    fun assignOutletToRoute(routeId: String, retailerId: String) = MockRepository.assignOutletToRoute(routeId, retailerId)
    fun createRetailerCollection(retailerId: String, retailerName: String, amount: Double, method: String) =
        MockRepository.createCollection(PartyType.RETAILER, retailerId, retailerName, amount, method)
}

@Composable
fun DealersScreen(vm: DealersScreenViewModel = viewModel()) {
    val dealers by vm.dealers.collectAsState()
    val allOrders by vm.dealerOrders.collectAsState()
    val pending = allOrders.filter { it.status == "Pending" }
    var tab by remember { mutableStateOf(0) }
    var selectedDealerId by remember { mutableStateOf<String?>(null) }
    var selectedRetailerId by remember { mutableStateOf<String?>(null) }
    var showAddDealer by remember { mutableStateOf(false) }
    var showAddRetailer by remember { mutableStateOf(false) }

    // Universal Search deep-link: if the person tapped a Dealer/Retailer search result, jump straight to its detail panel and the right tab.
    LaunchedEffect(Unit) {
        com.abm.erp.data.PendingSearchNavigation.consume("Dealer")?.let { id -> tab = 0; selectedDealerId = id }
        com.abm.erp.data.PendingSearchNavigation.consume("Retailer")?.let { id -> tab = 2; selectedRetailerId = id }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Dealers & Stock", style = MaterialTheme.typography.headlineSmall)
            if (vm.canCreateDealer() && tab == 0) {
                Button(onClick = { showAddDealer = true }) { Text("+ Add Dealer") }
            }
            if (vm.canCreateDealer() && tab == 2) {
                Button(onClick = { showAddRetailer = true }) { Text("+ Add Outlet") }
            }
        }
        Spacer(Modifier.height(8.dp))
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Directory") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Collections") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Outlets") })
        }
        Spacer(Modifier.height(12.dp))

        when (tab) {
            0 -> DirectoryTab(vm, dealers, pending) { selectedDealerId = it }
            1 -> CollectionsTab(vm, dealers)
            2 -> OutletsTab(vm) { selectedRetailerId = it }
        }
    }

    selectedDealerId?.let { id ->
        val dealer = dealers.firstOrNull { it.id == id }
        if (dealer != null) {
            Dialog(onDismissRequest = { selectedDealerId = null }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                    DealerDetailPanel(vm, dealer, onClose = { selectedDealerId = null })
                }
            }
        }
    }

    if (showAddDealer) {
        Dialog(onDismissRequest = { showAddDealer = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                AddDealerForm(vm, onDone = { showAddDealer = false })
            }
        }
    }

    selectedRetailerId?.let { id ->
        val retailer = vm.retailers.collectAsState().value.firstOrNull { it.id == id }
        if (retailer != null) {
            Dialog(onDismissRequest = { selectedRetailerId = null }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                    RetailerDetailPanel(vm, retailer, onClose = { selectedRetailerId = null })
                }
            }
        }
    }

    if (showAddRetailer) {
        Dialog(onDismissRequest = { showAddRetailer = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                AddRetailerForm(vm, dealers, onDone = { showAddRetailer = false })
            }
        }
    }
}

@Composable
private fun DirectoryTab(vm: DealersScreenViewModel, dealers: List<com.abm.erp.data.Dealer>, pending: List<com.abm.erp.data.DealerOrderRecord>, onOpenDealer: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "Name,Zone,Classification,Due,CreditLimit,Sales90d\n"
                    val rows = dealers.joinToString("\n") { d -> com.abm.erp.core.toCsvRow(d.name, d.zone, d.classification, d.dueBalance, d.creditLimit, d.salesLast90Days) }
                    val file = java.io.File(context.getExternalFilesDir(null), "dealer_directory_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Dealer Directory (${dealers.size})\n" + dealers.take(20).joinToString("\n") { "${it.name} — ${it.zone} · Due ৳${it.dueBalance}" }
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                    try { context.startActivity(android.content.Intent.createChooser(intent, "Dealer Directory")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                },
            )
        }
        var searchQuery by remember { mutableStateOf("") }
        var zoneFilter by remember { mutableStateOf<String?>(null) }
        var classFilter by remember { mutableStateOf<String?>(null) }
        var riskFilter by remember { mutableStateOf<com.abm.erp.data.RiskBand?>(null) }
        val zones = remember(dealers) { dealers.map { it.zone }.distinct().sorted() }
        OutlinedTextField(
            value = searchQuery, onValueChange = { searchQuery = it },
            placeholder = { Text("Search by name or phone…") },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            FilterChip(selected = zoneFilter == null, onClick = { zoneFilter = null }, label = { Text("All Areas") })
            zones.forEach { z -> FilterChip(selected = zoneFilter == z, onClick = { zoneFilter = z }, label = { Text(z) }) }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = classFilter == null, onClick = { classFilter = null }, label = { Text("All Tiers") })
            listOf("A", "B", "C").forEach { c -> FilterChip(selected = classFilter == c, onClick = { classFilter = c }, label = { Text("Tier $c") }) }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = riskFilter == null, onClick = { riskFilter = null }, label = { Text("All Risk") })
            FilterChip(selected = riskFilter == com.abm.erp.data.RiskBand.GREEN, onClick = { riskFilter = com.abm.erp.data.RiskBand.GREEN }, label = { Text("Healthy", color = SuccessGreen) })
            FilterChip(selected = riskFilter == com.abm.erp.data.RiskBand.YELLOW, onClick = { riskFilter = com.abm.erp.data.RiskBand.YELLOW }, label = { Text("Watch", color = WarningAmber) })
            FilterChip(selected = riskFilter == com.abm.erp.data.RiskBand.RED, onClick = { riskFilter = com.abm.erp.data.RiskBand.RED }, label = { Text("At Risk", color = DangerRed) })
        }
        val visitLogsForFilter by MockRepository.visitLogs.collectAsState()
        val routes = remember(dealers) { dealers.mapNotNull { it.territoryId }.distinct().sorted() }
        val officers = remember(visitLogsForFilter) { visitLogsForFilter.filter { it.partyType == PartyType.DEALER }.map { it.employeeName }.distinct().sorted() }
        var routeFilter by remember { mutableStateOf<String?>(null) }
        var officerFilter by remember { mutableStateOf<String?>(null) }
        if (routes.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                FilterChip(selected = routeFilter == null, onClick = { routeFilter = null }, label = { Text("All Routes") })
                routes.forEach { r -> FilterChip(selected = routeFilter == r, onClick = { routeFilter = r }, label = { Text(r) }) }
            }
        }
        if (officers.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text("Officer (যিনি visit করেছেন)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                FilterChip(selected = officerFilter == null, onClick = { officerFilter = null }, label = { Text("All Officers") })
                officers.forEach { o -> FilterChip(selected = officerFilter == o, onClick = { officerFilter = o }, label = { Text(o) }) }
            }
        }
        Spacer(Modifier.height(10.dp))
        val dealerIdsVisitedByOfficer = remember(visitLogsForFilter, officerFilter) {
            if (officerFilter == null) null else visitLogsForFilter.filter { it.partyType == PartyType.DEALER && it.employeeName == officerFilter }.map { it.partyId }.toSet()
        }
        val filteredDealers = remember(dealers, searchQuery, zoneFilter, classFilter, riskFilter, routeFilter, dealerIdsVisitedByOfficer) {
            dealers.filter { d ->
                (searchQuery.isBlank() || d.name.contains(searchQuery, ignoreCase = true) || d.phone.contains(searchQuery)) &&
                    (zoneFilter == null || d.zone == zoneFilter) &&
                    (classFilter == null || d.classification == classFilter) &&
                    (riskFilter == null || MockRepository.riskBand(d) == riskFilter) &&
                    (routeFilter == null || d.territoryId == routeFilter) &&
                    (dealerIdsVisitedByOfficer == null || d.id in dealerIdsVisitedByOfficer)
            }
        }
        val inactive = remember(dealers) { vm.inactiveDealers() }
        if (inactive.isNotEmpty()) {
            GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                Text("⚠ Inactive Dealers (${inactive.size}) — কোনো ৯০-দিনের sales নেই", color = WarningAmber, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelMedium)
                inactive.take(5).forEach { d -> Text("• ${d.name} (${d.zone})", style = MaterialTheme.typography.bodySmall, color = TextSecondary) }
            }
        }
        if (pending.isNotEmpty()) {
            Text("Pending dealer orders (${pending.size})", style = MaterialTheme.typography.titleMedium, color = WarningAmber)
            Spacer(Modifier.height(8.dp))
            pending.forEach { o ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text(o.dealerName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Text("${o.product} × ${o.qty}", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.setDealerOrderStatus(o.id, "Approved") }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) {
                            Text("Approve")
                        }
                        OutlinedButton(onClick = { vm.setDealerOrderStatus(o.id, "Rejected") }) {
                            Text("Reject", color = DangerRed)
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        Text("Dealers in your territory", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filteredDealers, key = { it.id }) { d ->
                val dealerLedger by vm.ledgerFor(d.id).collectAsState(initial = emptyList())
                GlassCard(modifier = Modifier.fillMaxWidth().clickable { onOpenDealer(d.id) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(d.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(d.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Spacer(Modifier.height(4.dp))
                            Text("Due: ৳${"%,.0f".format(d.dueBalance)} · 90-day sales: ৳${"%,.0f".format(d.salesLast90Days)}", style = MaterialTheme.typography.bodySmall)
                            if (d.creditLimit > 0) {
                                Text("Credit limit: ৳${"%,.0f".format(d.creditLimit)} · Utilization: ${(vm.creditUtilization(d) * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = if (d.dueBalance >= d.creditLimit) DangerRed else TextSecondary)
                            }
                        }
                        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(6.dp), color = classificationColor(d.classification).copy(alpha = 0.15f)) {
                            Text(" ${d.classification} ", modifier = Modifier.padding(4.dp), color = classificationColor(d.classification), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Dealer", entityId = d.id, entityLabel = d.name,
                            shareText = "${d.name} — ${d.zone}\nDue: ৳${d.dueBalance}\n90-day sales: ৳${d.salesLast90Days}",
                            isDeleted = d.isDeleted,
                            onDuplicate = { vm.duplicateDealerAction(d.id) },
                            onArchive = { vm.deleteDealerAction(d.id) },
                            canArchive = vm.canDeleteDealer(),
                            archiveBlockedReasonOverride = if (d.dueBalance > 0) "এই ডিলারের বকেয়া ৳${"%,.0f".format(d.dueBalance)} আছে — বকেয়া ক্লিয়ার না হওয়া পর্যন্ত archive করা যাবে না।" else null,
                            onRestore = { vm.restoreDealerAction(d.id) },
                            csvHeader = "Name,Zone,Classification,Due,CreditLimit,Sales90d",
                            csvRow = com.abm.erp.core.toCsvRow(d.name, d.zone, d.classification, d.dueBalance, d.creditLimit, d.salesLast90Days),
                            historyLabel = "Dealer History",
                            historyItems = dealerLedger.map { "${it.reason}: ${it.type} ৳${"%,.0f".format(it.amount)} — ${it.createdAt.toLocalDate()}" },
                        )
                    }
                }
            }
        }
    }
}

private fun classificationColor(tier: String) = when (tier) {
    "A" -> SuccessGreen
    "C" -> DangerRed
    else -> WarningAmber
}

@Composable
private fun CollectionsTab(vm: DealersScreenViewModel, dealers: List<com.abm.erp.data.Dealer>) {
    val collections by vm.collections.collectAsState()
    val dealerCollections = collections.filter { it.partyType == PartyType.DEALER }
    var showNewCollection by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { showNewCollection = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Record Collection") }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(dealerCollections, key = { it.id }) { c ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(c.partyName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("৳${"%,.0f".format(c.amount)} · ${c.method} · by ${c.collectedBy}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text(c.status, color = when (c.status) { "VERIFIED" -> SuccessGreen; "REJECTED" -> DangerRed; else -> WarningAmber }, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                        if (c.status == "PENDING" && vm.canApproveCollection()) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(onClick = { vm.verifyCollection(c.id) }) { Text("Verify") }
                                TextButton(onClick = { vm.rejectCollection(c.id) }) { Text("Reject", color = DangerRed) }
                            }
                        }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Collection", entityId = c.id, entityLabel = c.partyName,
                            shareText = "Collection: ${c.partyName}\nAmount: ৳${c.amount}\nMethod: ${c.method}\nStatus: ${c.status}",
                            csvHeader = "Party,Amount,Method,Status,CollectedBy",
                            csvRow = com.abm.erp.core.toCsvRow(c.partyName, c.amount, c.method, c.status, c.collectedBy),
                        )
                    }
                }
            }
        }
    }

    if (showNewCollection) {
        Dialog(onDismissRequest = { showNewCollection = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                NewCollectionForm(dealers, onSubmit = { dealerId, dealerName, amount, method ->
                    vm.createCollection(dealerId, dealerName, amount, method)
                    showNewCollection = false
                })
            }
        }
    }
}

@Composable
private fun NewCollectionForm(dealers: List<com.abm.erp.data.Dealer>, onSubmit: (String, String, Double, String) -> Unit) {
    var selectedDealer by remember { mutableStateOf<com.abm.erp.data.Dealer?>(null) }
    var amountText by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("CASH") }
    var expanded by remember { mutableStateOf(false) }

    Column(Modifier.padding(16.dp)) {
        Text("Record Dealer Collection", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selectedDealer?.name ?: "Select dealer")
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                dealers.forEach { d ->
                    DropdownMenuItem(text = { Text(d.name) }, onClick = { selectedDealer = d; expanded = false })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("Amount (৳)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("CASH", "BANK", "MOBILE_BANKING", "CHEQUE").forEach { m ->
                FilterChip(selected = method == m, onClick = { method = m }, label = { Text(m) })
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = {
                val amt = amountText.toDoubleOrNull() ?: return@Button
                val d = selectedDealer ?: return@Button
                onSubmit(d.id, d.name, amt, method)
            },
            enabled = selectedDealer != null && amountText.toDoubleOrNull() != null,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Submit for verification") }
    }
}

@Composable
private fun AddDealerForm(vm: DealersScreenViewModel, onDone: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var zone by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.padding(16.dp)) {
        Text("Dealer Registration", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Dealer name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = zone, onValueChange = { zone = it }, label = { Text("Zone / district") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth())
        error?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 6.dp)) }
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = {
                val created = vm.createDealer(name, zone, phone, address)
                if (created == null) error = "তৈরি করা যায়নি — একই নাম+ফোনে দোকান আগে থেকেই আছে, অথবা ইনপুট সঠিক না।" else onDone()
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Register Dealer") }
    }
}

@Composable
private fun DealerDetailPanel(vm: DealersScreenViewModel, dealer: com.abm.erp.data.Dealer, onClose: () -> Unit) {
    var subTab by remember { mutableStateOf(0) }
    val ledger by vm.ledgerFor(dealer.id).collectAsState(initial = emptyList())
    val visits by vm.visitsFor(dealer.id).collectAsState(initial = emptyList())

    Column(Modifier.padding(16.dp).heightIn(max = 560.dp).widthIn(max = 400.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(dealer.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${dealer.zone} · Tier ${dealer.classification}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            Row {
                val statementContext = androidx.compose.ui.platform.LocalContext.current
                IconButton(onClick = {
                    try {
                        val file = com.abm.erp.core.exportDealerStatementPdf(statementContext, dealer, ledger)
                        com.abm.erp.core.shareStructuredPdf(statementContext, file, "Statement — ${dealer.name}")
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(statementContext, "Statement PDF তৈরি ব্যর্থ হয়েছে: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                    }
                }) { Text("📄") }
                IconButton(onClick = onClose) { Icon(androidx.compose.material.icons.Icons.Filled.Close, contentDescription = "Close") }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text("Due: ৳${"%,.0f".format(dealer.dueBalance)}" + if (dealer.creditLimit > 0) " / limit ৳${"%,.0f".format(dealer.creditLimit)}" else "", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            val healthScore = remember(dealer.id) { MockRepository.dealerHealthScore(dealer) }
            Column {
                Text("Health Score", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text("$healthScore/100", fontWeight = FontWeight.Bold, color = when { healthScore >= 65 -> SuccessGreen; healthScore >= 40 -> WarningAmber; else -> DangerRed })
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text("Last Visit", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text(visits.maxByOrNull { it.checkInAt }?.checkInAt?.toLocalDate()?.toString() ?: "কখনো না", style = MaterialTheme.typography.bodySmall)
            }
            if (dealer.phone.isNotBlank()) {
                val callContext = androidx.compose.ui.platform.LocalContext.current
                IconButton(onClick = {
                    try {
                        callContext.startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:${dealer.phone}")))
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(callContext, "Call করা যায়নি।", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }) { Icon(androidx.compose.material.icons.Icons.Filled.Call, contentDescription = "Call ${dealer.name}") }
            }
        }
        Spacer(Modifier.height(10.dp))
        TabRow(selectedTabIndex = subTab) {
            Tab(selected = subTab == 0, onClick = { subTab = 0 }, text = { Text("Ledger") })
            Tab(selected = subTab == 1, onClick = { subTab = 1 }, text = { Text("Visits") })
            Tab(selected = subTab == 2, onClick = { subTab = 2 }, text = { Text("Notes") })
        }
        Spacer(Modifier.height(10.dp))
        when (subTab) {
            0 -> LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(ledger, key = { it.id }) { e ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(e.reason, style = MaterialTheme.typography.bodySmall)
                            Text("balance after: ৳${"%,.0f".format(e.balanceAfter)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text(
                            (if (e.type == "DEBIT") "+" else "−") + "৳${"%,.0f".format(e.amount)}",
                            color = if (e.type == "DEBIT") WarningAmber else SuccessGreen, fontWeight = FontWeight.Bold,
                        )
                    }
                }
                if (ledger.isEmpty()) item { Text("এখনো কোনো ledger entry নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
            }
            1 -> LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                val timeline = visits.sortedByDescending { it.checkInAt }
                items(timeline, key = { it.id }) { v ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${v.employeeName} — ${v.purpose}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            Text(
                                "In: ${v.checkInAt.toLocalDate()} ${v.checkInAt.toLocalTime()}" + (v.checkOutAt?.let { " · Out: ${it.toLocalTime()}" } ?: " · checkout নেই"),
                                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                            )
                        }
                        com.abm.erp.core.UniversalActionMenu(moduleReference = "Visit", entityId = v.id, entityLabel = v.employeeName, shareText = "Visit by ${v.employeeName} — ${v.purpose}\n${v.checkInAt}", csvHeader = "Employee,Purpose,CheckIn", csvRow = com.abm.erp.core.toCsvRow(v.employeeName, v.purpose, v.checkInAt))
                    }
                }
                if (visits.isEmpty()) item { Text("এখনো কোনো visit রেকর্ড নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
            }
            2 -> {
                var noteText by remember { mutableStateOf("") }
                val notesLog by MockRepository.activityLogFor("Dealer", dealer.id).collectAsState(initial = emptyList())
                val notes = remember(notesLog) { notesLog.filter { it.action == "NOTE" }.sortedByDescending { it.timestamp } }
                Column {
                    OutlinedTextField(
                        value = noteText, onValueChange = { noteText = it },
                        placeholder = { Text("একটা note লিখুন…") }, modifier = Modifier.fillMaxWidth(), minLines = 2,
                    )
                    Spacer(Modifier.height(6.dp))
                    Button(
                        onClick = {
                            if (noteText.isNotBlank()) {
                                MockRepository.logAudit("Dealer", dealer.id, "NOTE", newValue = noteText)
                                noteText = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Add Note") }
                    Spacer(Modifier.height(10.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(notes) { n ->
                            Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Text(n.newValueJson ?: "", style = MaterialTheme.typography.bodySmall)
                                Text("${n.performedBy} · ${n.timestamp}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                        if (notes.isEmpty()) item { Text("এখনো কোনো note নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
        }
        if (vm.canDeleteDealer()) {
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = { vm.deleteDealer(dealer.id); onClose() }, modifier = Modifier.fillMaxWidth()) {
                Text("Delete Dealer", color = DangerRed)
            }
        }
    }
}

@Composable
private fun OutletsTab(vm: DealersScreenViewModel, onOpenRetailer: (String) -> Unit) {
    val retailers by vm.retailers.collectAsState()
    Column(Modifier.fillMaxSize()) {
        Text("Retailers / Outlets (${retailers.size})", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        if (retailers.isEmpty()) {
            Text(
                "এখনো কোনো outlet registration নেই — Sales Chain-এ order দেওয়ার সময় শুধু নাম লেখা হয়, কিন্তু \"+ Add Outlet\" দিয়ে এখন সত্যিকারের Retailer রেকর্ড বানানো যাবে (dedup-check, ledger, visit history সহ)।",
                style = MaterialTheme.typography.bodySmall, color = TextSecondary,
            )
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(retailers, key = { it.id }) { r ->
                val retailerLedger by vm.retailerLedgerFor(r.id).collectAsState(initial = emptyList())
                GlassCard(modifier = Modifier.fillMaxWidth().clickable { onOpenRetailer(r.id) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(r.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${r.outletCategory} · ${r.outletType}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            if (r.dueBalance > 0) Text("Due: ৳${"%,.0f".format(r.dueBalance)}", style = MaterialTheme.typography.bodySmall, color = WarningAmber)
                        }
                        if (r.routeId != null) {
                            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(6.dp), color = SuccessGreen.copy(alpha = 0.15f)) {
                                Text(" Routed ", modifier = Modifier.padding(4.dp), color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Retailer", entityId = r.id, entityLabel = r.name,
                            shareText = "${r.name} — ${r.outletCategory}/${r.outletType}\nDue: ৳${r.dueBalance}",
                            isDeleted = r.isDeleted,
                            onDuplicate = { vm.duplicateRetailerAction(r.id) },
                            onArchive = { vm.archiveRetailerAction(r.id) },
                            canArchive = vm.canDeleteDealer(), // Retailer/Outlet master data shares the "dealer" module permission scope — no separate canDeleteRetailer() exists, and this app's permission model doesn't distinguish them
                            archiveBlockedReasonOverride = if (r.dueBalance > 0) "এই আউটলেটের বকেয়া ৳${"%,.0f".format(r.dueBalance)} আছে — বকেয়া ক্লিয়ার না হওয়া পর্যন্ত archive করা যাবে না।" else null,
                            onRestore = { vm.restoreRetailerAction(r.id) },
                            csvHeader = "Name,Category,Type,Due,CreditLimit",
                            csvRow = com.abm.erp.core.toCsvRow(r.name, r.outletCategory, r.outletType, r.dueBalance, r.creditLimit),
                            historyLabel = "Retailer History",
                            historyItems = retailerLedger.map { "${it.reason}: ${it.type} ৳${"%,.0f".format(it.amount)} — ${it.createdAt.toLocalDate()}" },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AddRetailerForm(vm: DealersScreenViewModel, dealers: List<com.abm.erp.data.Dealer>, onDone: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var selectedDealer by remember { mutableStateOf<com.abm.erp.data.Dealer?>(null) }
    var dealerMenuExpanded by remember { mutableStateOf(false) }
    var outletCategory by remember { mutableStateOf("General Store") }
    var outletType by remember { mutableStateOf("Retail") }
    var error by remember { mutableStateOf<String?>(null) }
    val categories = listOf("General Store", "Super Shop", "Pharmacy", "Tea Stall", "Grocery")
    val types = listOf("Retail", "Wholesale")

    Column(Modifier.padding(16.dp).heightIn(max = 560.dp)) {
        Text("Outlet / Retailer Registration", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Outlet name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text("Outlet category", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            categories.forEach { c -> FilterChip(selected = outletCategory == c, onClick = { outletCategory = c }, label = { Text(c) }) }
        }
        Spacer(Modifier.height(8.dp))
        Text("Outlet type", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            types.forEach { t -> FilterChip(selected = outletType == t, onClick = { outletType = t }, label = { Text(t) }) }
        }
        Spacer(Modifier.height(8.dp))
        Box {
            OutlinedButton(onClick = { dealerMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selectedDealer?.name ?: "Link to a dealer (optional)")
            }
            DropdownMenu(expanded = dealerMenuExpanded, onDismissRequest = { dealerMenuExpanded = false }) {
                dealers.forEach { d -> DropdownMenuItem(text = { Text(d.name) }, onClick = { selectedDealer = d; dealerMenuExpanded = false }) }
            }
        }
        error?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 6.dp)) }
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = {
                val created = vm.createRetailer(name, phone, address, selectedDealer?.id, outletCategory, outletType)
                if (created == null) error = "তৈরি করা যায়নি — একই নাম+ফোন/লোকেশনে outlet আগে থেকে আছে, অথবা ইনপুট সঠিক না।" else onDone()
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Register Outlet") }
    }
}

@Composable
private fun RetailerDetailPanel(vm: DealersScreenViewModel, retailer: com.abm.erp.data.Retailer, onClose: () -> Unit) {
    var subTab by remember { mutableStateOf(0) }
    val ledger by vm.retailerLedgerFor(retailer.id).collectAsState(initial = emptyList())
    val visits by vm.retailerVisitsFor(retailer.id).collectAsState(initial = emptyList())

    Column(Modifier.padding(16.dp).heightIn(max = 560.dp).widthIn(max = 400.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(retailer.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${retailer.outletCategory} · ${retailer.outletType}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            IconButton(onClick = onClose) { Icon(androidx.compose.material.icons.Icons.Filled.Close, contentDescription = "Close") }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Due: ৳${"%,.0f".format(retailer.dueBalance)}" + if (retailer.creditLimit > 0) " / limit ৳${"%,.0f".format(retailer.creditLimit)}" else "",
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            val healthScore = remember(retailer.id) { MockRepository.retailerHealthScore(retailer) }
            Column {
                Text("Health Score", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text("$healthScore/100", fontWeight = FontWeight.Bold, color = when { healthScore >= 65 -> SuccessGreen; healthScore >= 40 -> WarningAmber; else -> DangerRed })
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text("Last Visit", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text(visits.maxByOrNull { it.checkInAt }?.checkInAt?.toLocalDate()?.toString() ?: "কখনো না", style = MaterialTheme.typography.bodySmall)
            }
            if (retailer.phone.isNotBlank()) {
                val callContext = androidx.compose.ui.platform.LocalContext.current
                IconButton(onClick = {
                    try {
                        callContext.startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:${retailer.phone}")))
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(callContext, "Call করা যায়নি।", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }) { Icon(androidx.compose.material.icons.Icons.Filled.Call, contentDescription = "Call ${retailer.name}") }
            }
        }
        Spacer(Modifier.height(10.dp))
        TabRow(selectedTabIndex = subTab) {
            Tab(selected = subTab == 0, onClick = { subTab = 0 }, text = { Text("Ledger") })
            Tab(selected = subTab == 1, onClick = { subTab = 1 }, text = { Text("Visits") })
            Tab(selected = subTab == 2, onClick = { subTab = 2 }, text = { Text("Notes") })
        }
        Spacer(Modifier.height(10.dp))
        when (subTab) {
            0 -> LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(ledger, key = { it.id }) { e ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(e.reason, style = MaterialTheme.typography.bodySmall)
                        Text(
                            (if (e.type == "DEBIT") "+" else "−") + "৳${"%,.0f".format(e.amount)}",
                            color = if (e.type == "DEBIT") WarningAmber else SuccessGreen, fontWeight = FontWeight.Bold,
                        )
                    }
                }
                if (ledger.isEmpty()) item { Text("এখনো কোনো ledger entry নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
            }
            1 -> LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                val timeline = visits.sortedByDescending { it.checkInAt }
                items(timeline, key = { it.id }) { v ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${v.employeeName} — ${v.purpose}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            Text(
                                "In: ${v.checkInAt.toLocalDate()} ${v.checkInAt.toLocalTime()}" + (v.checkOutAt?.let { " · Out: ${it.toLocalTime()}" } ?: " · checkout নেই"),
                                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                            )
                        }
                        com.abm.erp.core.UniversalActionMenu(moduleReference = "Visit", entityId = v.id, entityLabel = v.employeeName, shareText = "Visit by ${v.employeeName} — ${v.purpose}\n${v.checkInAt}", csvHeader = "Employee,Purpose,CheckIn", csvRow = com.abm.erp.core.toCsvRow(v.employeeName, v.purpose, v.checkInAt))
                    }
                }
                if (visits.isEmpty()) item { Text("এখনো কোনো visit রেকর্ড নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
            }
            2 -> {
                var noteText by remember { mutableStateOf("") }
                val notesLog by MockRepository.activityLogFor("Retailer", retailer.id).collectAsState(initial = emptyList())
                val notes = remember(notesLog) { notesLog.filter { it.action == "NOTE" }.sortedByDescending { it.timestamp } }
                Column {
                    OutlinedTextField(
                        value = noteText, onValueChange = { noteText = it },
                        placeholder = { Text("একটা note লিখুন…") }, modifier = Modifier.fillMaxWidth(), minLines = 2,
                    )
                    Spacer(Modifier.height(6.dp))
                    Button(
                        onClick = {
                            if (noteText.isNotBlank()) {
                                MockRepository.logAudit("Retailer", retailer.id, "NOTE", newValue = noteText)
                                noteText = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Add Note") }
                    Spacer(Modifier.height(10.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(notes) { n ->
                            Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Text(n.newValueJson ?: "", style = MaterialTheme.typography.bodySmall)
                                Text("${n.performedBy} · ${n.timestamp}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                        if (notes.isEmpty()) item { Text("এখনো কোনো note নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { vm.deleteRetailer(retailer.id); onClose() }, modifier = Modifier.fillMaxWidth()) {
            Text("Delete Outlet", color = DangerRed)
        }
    }
}
