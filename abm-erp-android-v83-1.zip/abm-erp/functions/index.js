/**
 * ABM ERP — Cloud Functions
 *
 * setUserRoleClaim is the one function this project needs for real,
 * database-level role enforcement. It exists because Firestore security
 * rules can only trust request.auth.token — they can never trust anything
 * the client sends in the request body, since a client could always lie
 * about its own role. This function is the ONE place that's allowed to look
 * an employee's real role up (from Firestore, written only by the app's own
 * login flow) and then permanently stamp it onto that specific device's own
 * auth token, where the client can no longer change it.
 *
 * Flow, end to end:
 *   1. Employee enters their PIN in the Android app (unchanged, existing flow).
 *   2. App calls this function with { employeeId, companyId }.
 *   3. Function looks up companies/{companyId}/employeeRoles/{employeeId}
 *      in Firestore using the Admin SDK (which bypasses security rules —
 *      this is the ONE place in the whole system allowed to do that).
 *   4. Function sets custom claims (role, companyId, division, district)
 *      on the CALLER'S OWN uid — never on anyone else's.
 *   5. App refreshes its ID token so the new claims apply immediately.
 *   6. Firestore rules can now check request.auth.token.role for real.
 */

const functions = require("firebase-functions");
const admin = require("firebase-admin");
const { onDocumentWritten } = require("firebase-functions/v2/firestore");
const { onSchedule } = require("firebase-functions/v2/scheduler");

admin.initializeApp();

exports.setUserRoleClaim = functions.https.onCall(async (data, context) => {
  // Must be signed in (Anonymous Auth counts — this app doesn't use email/password).
  if (!context.auth) {
    throw new functions.https.HttpsError(
      "unauthenticated",
      "You must be signed in to claim a role.",
    );
  }

  const employeeId = data.employeeId;
  const companyId = data.companyId;

  if (!employeeId || !companyId) {
    throw new functions.https.HttpsError(
      "invalid-argument",
      "Both employeeId and companyId are required.",
    );
  }

  const snapshot = await admin
    .firestore()
    .collection("companies")
    .doc(companyId)
    .collection("employeeRoles")
    .doc(employeeId)
    .get();

  if (!snapshot.exists) {
    // Fails closed — no record means no claim, not "trust the client instead".
    throw new functions.https.HttpsError(
      "not-found",
      "No employee record found for that id in that company.",
    );
  }

  const record = snapshot.data() || {};

  await admin.auth().setCustomUserClaims(context.auth.uid, {
    role: record.role || null,
    companyId: companyId,
    division: record.division || null,
    district: record.district || null,
    employeeId: employeeId,
  });

  return { success: true, role: record.role || null };
});

/**
 * Chairman-এর Notice Board-এ কিছু পোস্ট/বদল হলেই সাথে সাথে চলে — company-র
 * সবার registered ফোনে push notification পাঠায়। App-এর নিজের কাজ শুধু
 * "receive" করা (AbmFirebaseMessagingService.kt); "পাঠানো"-টা এখানেই হয়,
 * কারণ এটা একটা server-side trigger — কেউ notice লিখলেই আপনাআপনি চলে,
 * app খোলা থাকুক বা না থাকুক।
 */
exports.onChairmanNoticePosted = onDocumentWritten(
  "companies/{companyId}/orgState/chairmanNotice",
  async (event) => {
    const companyId = event.params.companyId;
    const after = event.data?.after?.data();
    if (!after) return; // deleted, nothing to notify about

    const tokensSnap = await admin
      .firestore()
      .collection("companies").doc(companyId)
      .collection("fcmTokens")
      .get();

    const tokens = tokensSnap.docs
      .map((d) => d.data().token)
      .filter((t) => typeof t === "string" && t.length > 0);

    if (tokens.length === 0) return;

    const message = {
      notification: {
        title: "Chairman-এর নতুন নোটিশ",
        body: after.caption || "একটা নতুন নোটিশ পোস্ট হয়েছে।",
      },
      tokens: tokens,
    };

    const response = await admin.messaging().sendEachForMulticast(message);
    functions.logger.info(
      `Chairman notice push: ${response.successCount} success, ${response.failureCount} failed`,
    );
  },
);

/**
 * প্রতিদিন রাতে একবার নিজে থেকে চলে (Payroll screen খোলার অপেক্ষা করে না)
 * — প্রতিটা কোম্পানির প্রতিটা employee-র জন্য আজকের attendance record
 * আছে কিনা চেক করে, না থাকলে "অনুপস্থিত" হিসেবে লিখে রাখে। এর ফলে
 * Payroll-এর absence-count সবসময় real-time-এর কাছাকাছি থাকে, কেউ app
 * না খুললেও।
 */
exports.dailyAbsenceSweep = onSchedule(
  { schedule: "0 20 * * *", timeZone: "Asia/Dhaka" }, // প্রতিদিন রাত ৮টা, বাংলাদেশ সময়
  async () => {
    const db = admin.firestore();
    const companiesSnap = await db.collection("companies").get();
    const todayEpochDay = Math.floor(Date.now() / 86400000);

    for (const companyDoc of companiesSnap.docs) {
      const companyId = companyDoc.id;
      const payrollSnap = await db
        .collection("companies").doc(companyId)
        .collection("payroll")
        .get();

      for (const payrollDoc of payrollSnap.docs) {
        const employeeId = payrollDoc.id;
        const attendanceDocId = `${employeeId}_${todayEpochDay}`;
        const attendanceRef = db
          .collection("companies").doc(companyId)
          .collection("attendance").doc(attendanceDocId);
        const existing = await attendanceRef.get();
        if (existing.exists) continue; // already checked in today, nothing to do

        await attendanceRef.set({
          employeeId,
          dateEpochDay: todayEpochDay,
          checkedIn: false,
          gpsValid: false,
        });
      }
    }
    functions.logger.info(`dailyAbsenceSweep: processed ${companiesSnap.size} companies`);
  },
);

/**
 * Market Analysis-এর ভারী হিসাব (সব dealer-এর zone-wise sales/due যোগফল)
 * প্রতি ঘণ্টায় একবার আগে থেকেই বানিয়ে রাখে, যাতে Chairman/MD-এর ফোন
 * প্রতিবার screen খোলার সময় শত শত dealer-এর ডেটা টেনে নিজে যোগফল না করে
 * — শুধু এই ছোট্ট, আগে-থেকে-বানানো summary document-টা পড়লেই হয়।
 */
exports.hourlyMarketSummary = onSchedule(
  { schedule: "0 * * * *", timeZone: "Asia/Dhaka" }, // প্রতি ঘণ্টায় একবার
  async () => {
    const db = admin.firestore();
    const companiesSnap = await db.collection("companies").get();

    for (const companyDoc of companiesSnap.docs) {
      const companyId = companyDoc.id;
      const dealersSnap = await db
        .collection("companies").doc(companyId)
        .collection("dealers")
        .get();

      const byZone = {};
      dealersSnap.docs.forEach((d) => {
        const data = d.data();
        const zone = data.zone || "Unknown";
        if (!byZone[zone]) byZone[zone] = { salesLast90Days: 0, dueBalance: 0 };
        byZone[zone].salesLast90Days += data.salesLast90Days || 0;
        byZone[zone].dueBalance += data.dueBalance || 0;
      });

      await db
        .collection("companies").doc(companyId)
        .collection("orgState").doc("marketSummary")
        .set({ byZone, computedAtMillis: Date.now() });
    }
    functions.logger.info(`hourlyMarketSummary: processed ${companiesSnap.size} companies`);
  },
);
