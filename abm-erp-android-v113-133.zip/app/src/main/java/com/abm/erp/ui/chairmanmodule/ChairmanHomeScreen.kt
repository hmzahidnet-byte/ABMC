package com.abm.erp.ui.chairmanmodule

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.core.ModuleDrawerItem
import com.abm.erp.core.ModuleDrawerScaffold
import com.abm.erp.data.MockRepository
import com.abm.erp.data.chairmanApproveCorrection
import com.abm.erp.data.chairmanRejectCorrection
import com.abm.erp.data.managerReviewCorrection
import com.abm.erp.data.UserRole
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * CHAIRMAN — Full Control Center. Mother module #5 (of five: the person moved AI
 * inside Chairman, so the Home Dashboard shows DMS · RMS · HR · FMS · CHAIRMAN).
 *
 * Two decisions the person made explicitly for this module, recorded here because
 * both are exceptions or refinements of earlier rules:
 *
 * 1. **Approval Center is the ONE sanctioned exception to Decision 2.** Every other
 *    role approves inside the owning module (leave in HR, expense in FMS, invoice in
 *    DMS — unchanged). The Chairman alone gets a cross-module approval inbox,
 *    because observing and deciding across everything IS the Chairman's job. It is
 *    role-gated at render time AND every action still goes through the same
 *    permission-checked repository functions, so a non-chairman reaching this screen
 *    can see nothing and force nothing.
 *
 * 2. **Master Controller has NO hard delete.** The person confirmed: view
 *    soft-deleted records and restore them, nothing more. The app's everything-is-
 *    soft-delete policy stays intact; no data-destruction path exists here.
 */
private val CH_COLOR_START = 0xFF0F1E3D
private val CH_COLOR_END = 0xFF0A1428

private val CH_ITEMS = listOf(
    ModuleDrawerItem("dashboard", "Dashboard", Icons.Filled.Home, "Business Overview in Real Time"),
    ModuleDrawerItem("approvals", "Approve Center", Icons.Filled.FactCheck, "All Approval & Request Management"),
    ModuleDrawerItem("ai", "AI", Icons.Filled.Insights, "AI Boardroom & Intelligence"),
    ModuleDrawerItem("master", "Master Controller", Icons.Filled.Settings, "Soft-Deleted Records & Restore"),
    ModuleDrawerItem("employees", "Employee Control", Icons.Filled.ManageAccounts, "Hiring, Setup & Access"),
    // v113-86 — poster feature 3 (Dealer + Retailer List) had no drawer home until now.
    // Chairman sees the same approved browse pattern the modules use; cascade scoping
    // still applies (Chairman's scope is everything, so the lists are complete).
    ModuleDrawerItem("parties", "Dealer & Retailer List", Icons.Filled.Groups, "All Dealer & Retailer Management"),
    ModuleDrawerItem("ledger", "Main Ledger Book", Icons.Filled.MenuBook, "Whole Business Financial Overview"),
    ModuleDrawerItem("reports", "Reports & Analytics", Icons.Filled.InsertChart, "Advanced Reports"),
    ModuleDrawerItem("company", "Company Setup", Icons.Filled.Business, "Company & Setup Management"),
    ModuleDrawerItem("rules", "Business Rules", Icons.Filled.Rule, "Rule Engine"),
    ModuleDrawerItem("permissions", "Permission Control", Icons.Filled.AdminPanelSettings, "Role & Access"),
    ModuleDrawerItem("audit", "System Logs", Icons.Filled.Assignment, "Every Data Action"),
    ModuleDrawerItem("backup", "Backup Center", Icons.Filled.CloudUpload, "Online & Offline Backup"),
    ModuleDrawerItem("notice", "Notice Board", Icons.Filled.Campaign, "Direct Notice to Employees"),
)

@Composable
fun ChairmanHomeScreen(
    startKey: String? = null,
    onBackToHome: () -> Unit = {},
    onNavigate: (String) -> Unit = {},
) {
    // Role gate at the door. The drawer items host real admin screens; those screens
    // and every repository write re-check permissions themselves (defense in depth),
    // but a non-chairman shouldn't even see this module's option list.
    if (MockRepository.currentUser.role != UserRole.CHAIRMAN) {
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            Text("এই মডিউল শুধু Chairman-এর জন্য।", fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(Modifier.height(6.dp))
            TextButton(onClick = onBackToHome) { Text("← Home") }
        }
        return
    }

    var selected by remember { mutableStateOf(startKey ?: "dashboard") }

    ModuleDrawerScaffold(
        moduleName = "CHAIRMAN",
        moduleSubtitle = "Full Control Center",
        colorStart = CH_COLOR_START,
        colorEnd = CH_COLOR_END,
        moduleIcon = Icons.Filled.WorkspacePremium,
        items = CH_ITEMS,
        selectedKey = selected,
        onSelect = { selected = it },
        onBackToHome = onBackToHome,
    ) { key ->
        when (key) {
            "dashboard" -> com.abm.erp.ui.chairman.ChairmanHubScreen(onNavigate = onNavigate)
            "approvals" -> ChairmanApprovalCenter()
            "ai" -> com.abm.erp.ui.advisory.BoardroomScreen(onNavigate = onNavigate)
            "master" -> ChairmanMasterController()
            "employees" -> com.abm.erp.ui.admin.EmployeeSetupScreen(onNavigate = onNavigate)
            "parties" -> {
                var partyTab by remember { mutableStateOf(0) }
                val dealers = com.abm.erp.core.rememberVisibleDealers()
                val retailers = com.abm.erp.core.rememberVisibleRetailers()
                Column(Modifier.fillMaxSize()) {
                    TabRow(selectedTabIndex = partyTab) {
                        Tab(selected = partyTab == 0, onClick = { partyTab = 0 }, text = { Text("Dealers (${dealers.size})") })
                        Tab(selected = partyTab == 1, onClick = { partyTab = 1 }, text = { Text("Retailers (${retailers.size})") })
                    }
                    Box(Modifier.weight(1f)) {
                        if (partyTab == 0) com.abm.erp.core.ModuleBrowseList(
                            config = com.abm.erp.core.rememberDealerBrowseConfig(
                                zones = remember(dealers) { dealers.map { it.zone }.filter { it.isNotBlank() }.distinct().sorted() },
                            ),
                            records = dealers,
                            onBack = { selected = "dashboard" },
                            onNavigate = onNavigate,
                        ) else com.abm.erp.core.ModuleBrowseList(
                            config = com.abm.erp.core.rememberRetailerBrowseConfig(
                                markets = remember(retailers) { retailers.map { it.market }.filter { it.isNotBlank() }.distinct().sorted() },
                            ),
                            records = retailers,
                            onBack = { selected = "dashboard" },
                            onNavigate = onNavigate,
                        )
                    }
                }
            }
            "ledger" -> com.abm.erp.ui.ledger.LedgerScreen(startTab = 0, onBack = { selected = "dashboard" }, onNavigate = onNavigate)
            "reports" -> com.abm.erp.ui.reports.ReportsScreen()
            "company" -> com.abm.erp.ui.admin.CompanySettingsCenterScreen()
            "rules" -> com.abm.erp.ui.admin.BusinessRuleEngineScreen()
            "permissions" -> com.abm.erp.ui.admin.PermissionControlCenterScreen()
            "audit" -> com.abm.erp.ui.admin.EnterpriseAuditCenterScreen()
            "backup" -> com.abm.erp.ui.dashboard.BackupRecoveryScreen(onClose = { selected = "dashboard" })
            "notice" -> ChairmanNoticeBoard()
            else -> com.abm.erp.ui.chairman.ChairmanHubScreen(onNavigate = onNavigate)
        }
    }
}

/**
 * The sanctioned Decision-2 exception: the Chairman's cross-module approval inbox.
 *
 * Section 1 — every pending generic `ApprovalRequest` in the system, whichever module
 * raised it. The entityTypes set below is every value `raiseApprovalRequest` is ever
 * called with in this codebase (verified in v113-72's call-site trace: SalesInvoice,
 * Expense, Voucher, Payroll, AttendanceRecord) plus "" for requests raised through
 * the older `requestApproval` path which sets no entityType. Approve/Reject/Escalate/
 * Forward go through the exact same `setApprovalStatus` etc. as the in-module
 * sections — no new write path, so the audit trail is identical.
 *
 * Section 2 — pending Leave requests, which are their own record type (`LeaveRequest`,
 * not `ApprovalRequest`), actioned through the same `setLeaveStatus` HRM uses.
 *
 * What this deliberately does NOT do: pull in pending invoices/collections/stock
 * counts as actionable rows. Approving an invoice has stock/due/ledger side effects
 * that its own screen surfaces (totals, dealer due, timeline) — approving it blind
 * from a list would hide exactly the context the approval exists to check. Those
 * appear as counts with a pointer to the owning module instead.
 */
@Composable
private fun ChairmanApprovalCenter() {
    val leaves by MockRepository.leaveRequests.collectAsState()
    val invoices by MockRepository.salesInvoices.collectAsState()
    val pendingLeaves = remember(leaves) { leaves.filter { it.status == com.abm.erp.data.LeaveStatus.PENDING } }
    val pendingInvoices = remember(invoices) { invoices.count { it.status == "PENDING" && !it.isDeleted } }

    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Text("Approval Center", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
        Text(
            "Chairman-এর জন্য ব্যতিক্রম — অন্য সবাই নিজ নিজ মডিউলে approve করে।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(12.dp))

        com.abm.erp.core.ModuleApprovalSection(
            title = "সব pending request",
            entityTypes = setOf("SalesInvoice", "Expense", "Voucher", "Payroll", "AttendanceRecord", ""),
        )

        // ---- Leave requests (separate record type) ----
        if (pendingLeaves.isNotEmpty()) {
            Text("Leave Request (${pendingLeaves.size})", fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Spacer(Modifier.height(8.dp))
            pendingLeaves.forEach { l ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(l.employeeName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${l.type} · ${l.fromDate} → ${l.toDate}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        com.abm.erp.core.WaitingAge(l.createdAt)
                    }
                    Spacer(Modifier.height(8.dp))
                    var leaveError by remember(l.id) { mutableStateOf<String?>(null) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { MockRepository.setLeaveStatus(l.id, com.abm.erp.data.LeaveStatus.APPROVED, onRejected = { r -> leaveError = r }) },
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        ) { Text("Approve") }
                        OutlinedButton(onClick = { MockRepository.setLeaveStatus(l.id, com.abm.erp.data.LeaveStatus.REJECTED, onRejected = { r -> leaveError = r }) }) {
                            Text("Reject", color = DangerRed)
                        }
                    }
                    leaveError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        // ---- Correction Requests (v113-77) — the backend has existed for a long time
        // (submitCorrectionRequest / chairmanApproveCorrection / chairmanRejectCorrection,
        // full reversal-and-repost logic) with NO UI anywhere; this is the first surface.
        // It belongs here because the flow is literally chairman-approval-shaped: the
        // CorrectionRequest model's own states are MANAGER_REVIEW → CHAIRMAN_APPROVED. ----
        ChairmanCorrectionSection()

        // ---- Counts that point at their owning module rather than acting blind ----
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("অন্যান্য অপেক্ষমাণ", fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Pending Invoice (DMS-এ approve হয়)", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                Text("$pendingInvoices", fontWeight = FontWeight.Bold, color = if (pendingInvoices > 0) WarningAmber else SuccessGreen)
            }
            Text(
                "Invoice-এর approve বোতাম DMS → Invoice-এই থাকে, কারণ approve করার আগে total/due/timeline " +
                    "দেখা দরকার — তালিকা থেকে অন্ধভাবে approve করা ঠিক সেই context লুকিয়ে ফেলত।",
                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

/**
 * Master Controller — the person's confirmed scope: **view soft-deleted records and
 * restore them. No hard delete exists and none is added.**
 *
 * Each section below is a record type that (a) actually carries `isDeleted` and
 * (b) actually has a repository restore function — both verified against the source,
 * not assumed. Types with soft delete but no restore function (e.g. leads) are not
 * listed: showing a Restore button that silently can't work would be a fake screen.
 * Every restore call is the existing permission-checked repository function; DELETE-
 * tier permission is re-checked inside each one.
 */
@Composable
private fun ChairmanMasterController() {
    val invoices by MockRepository.salesInvoices.collectAsState()
    val dealers by MockRepository.dealers.collectAsState()
    val retailers by MockRepository.retailers.collectAsState()
    val tasks by MockRepository.tasks.collectAsState()
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val suppliers by com.abm.erp.data.PurchaseRepository.suppliers.collectAsState()

    val delInvoices = remember(invoices) { invoices.filter { it.isDeleted } }
    val delDealers = remember(dealers) { dealers.filter { it.isDeleted } }
    val delRetailers = remember(retailers) { retailers.filter { it.isDeleted } }
    val delTasks = remember(tasks) { tasks.filter { it.isDeleted } }
    val delProducts = remember(products) { products.filter { it.isDeleted } }
    val delSuppliers = remember(suppliers) { suppliers.filter { it.isDeleted } }
    val totalDeleted = delInvoices.size + delDealers.size + delRetailers.size + delTasks.size + delProducts.size + delSuppliers.size

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Master Controller", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(
                "Soft-deleted রেকর্ড দেখা ও restore — hard delete এই অ্যাপে নেই, এখানেও নেই।",
                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
            )
            Spacer(Modifier.height(4.dp))
            if (totalDeleted == 0) {
                Text("কোনো soft-deleted রেকর্ড নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
            }
        }
        if (delInvoices.isNotEmpty()) item { McSectionHeader("Invoice", delInvoices.size) }
        items(delInvoices, key = { "inv-${it.id}" }) { r ->
            McRestoreRow(r.invoiceNo, r.dealerName) { MockRepository.restoreSalesInvoice(r.id) }
        }
        if (delDealers.isNotEmpty()) item { McSectionHeader("Dealer", delDealers.size) }
        items(delDealers, key = { "dlr-${it.id}" }) { r ->
            McRestoreRow(r.name, r.zone) { MockRepository.restoreDealer(r.id) }
        }
        if (delRetailers.isNotEmpty()) item { McSectionHeader("Retailer", delRetailers.size) }
        items(delRetailers, key = { "rtl-${it.id}" }) { r ->
            McRestoreRow(r.name, r.market.orEmpty()) { MockRepository.restoreRetailer(r.id) }
        }
        if (delProducts.isNotEmpty()) item { McSectionHeader("Product", delProducts.size) }
        items(delProducts, key = { "prd-${it.id}" }) { r ->
            McRestoreRow(r.name, r.sku) { com.abm.erp.data.InventoryRepository.restoreProduct(r.id); true }
        }
        if (delSuppliers.isNotEmpty()) item { McSectionHeader("Supplier", delSuppliers.size) }
        items(delSuppliers, key = { "sup-${it.id}" }) { r ->
            McRestoreRow(r.name, r.phone) { com.abm.erp.data.PurchaseRepository.restoreSupplier(r.id) }
        }
        if (delTasks.isNotEmpty()) item { McSectionHeader("Task", delTasks.size) }
        items(delTasks, key = { "tsk-${it.id}" }) { r ->
            McRestoreRow(r.title, r.assignee) { MockRepository.restoreTask(r.id); true }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun McSectionHeader(label: String, count: Int) {
    Text("$label ($count)", fontWeight = FontWeight.SemiBold, color = TextPrimary, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun McRestoreRow(title: String, subtitle: String, onRestore: () -> Boolean) {
    var denied by remember(title) { mutableStateOf(false) }
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                if (subtitle.isNotBlank()) Text(subtitle, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            OutlinedButton(onClick = { denied = !onRestore() }) { Text("↩ Restore") }
        }
        if (denied) {
            Text(
                "⚠ Restore ব্যর্থ — আপনার role-এ এই কাজের অনুমতি নেই।",
                style = MaterialTheme.typography.labelSmall, color = DangerRed,
            )
        }
    }
}

/**
 * v113-77 — Chairman → employees direct notice. Uses the existing
 * `createNotification` (targetEmployeeId = null broadcasts to everyone's Notification
 * screen; a specific employeeId targets one person) — the same pipeline every system
 * alert already rides, so no new delivery mechanism and no new schema.
 */
@Composable
private fun ChairmanNoticeBoard() {
    // v113-128 — defense-in-depth, matching every sibling Chairman-only screen
    // in this file (Master Controller, and the standalone PermissionControl/
    // BusinessRuleEngine/EnterpriseAudit/CompanySettings screens). The outer
    // ChairmanHomeScreen already gates entry to the whole module, but this
    // codebase's own stated principle is that no Chairman-only mutation relies
    // on a single line of defense — this screen was the one exception.
    if (MockRepository.currentUser.role != UserRole.CHAIRMAN) {
        Text("এই স্ক্রিন শুধু Chairman-এর জন্য।", color = TextSecondary)
        return
    }
    val profiles by MockRepository.employeeProfiles.collectAsState()
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var targetId by remember { mutableStateOf<String?>(null) } // null = সবাই
    var sentMsg by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Text("Notice Board", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
        Text("সরাসরি employee-দের কাছে notice — Notification-এ পৌঁছাবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("শিরোনাম") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Notice") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        Spacer(Modifier.height(8.dp))
        Text("প্রাপক", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = targetId == null, onClick = { targetId = null }, label = { Text("সবাই") })
        }
        Column(Modifier.heightIn(max = 160.dp).verticalScroll(rememberScrollState())) {
            profiles.forEach { p ->
                Text(
                    p.fullName,
                    fontWeight = if (targetId == p.id) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        .clickable { targetId = p.id },
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                MockRepository.createNotification(
                    com.abm.erp.data.NotificationCategory.ALERT,
                    "📢 ${title.trim()}",
                    body.trim(),
                    targetEmployeeId = targetId,
                )
                sentMsg = if (targetId == null) "সবাইকে পাঠানো হয়েছে।" else "পাঠানো হয়েছে।"
                title = ""; body = ""
            },
            enabled = title.isNotBlank() && body.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Notice পাঠান") }
        sentMsg?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
        }
        Spacer(Modifier.height(24.dp))
    }
}


/**
 * v113-77 — first UI for the long-existing CorrectionRequest backend. Two action
 * tiers, exactly matching the repository's own state machine (verified, not guessed):
 * SUBMITTED → managerReviewCorrection → MANAGER_REVIEW → chairmanApproveCorrection
 * (applies real reversal + corrected repost) or chairmanRejectCorrection. All three
 * functions permission-check internally; denial shows the standard blocked-at-
 * repository line.
 */
@Composable
private fun ChairmanCorrectionSection() {
    val corrections by MockRepository.correctionRequests.collectAsState()
    val open = remember(corrections) {
        corrections.filter {
            it.status == com.abm.erp.data.CorrectionRequestStatus.SUBMITTED ||
                it.status == com.abm.erp.data.CorrectionRequestStatus.MANAGER_REVIEW
        }
    }
    var rejectFor by remember { mutableStateOf<String?>(null) }
    var denyReason by remember { mutableStateOf<String?>(null) }
    if (open.isEmpty()) return

    Text("Correction Request (${open.size})", fontWeight = FontWeight.SemiBold, color = TextPrimary)
    Spacer(Modifier.height(8.dp))
    open.forEach { c ->
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${c.module} · ${c.correctionType}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text(c.status.name, style = MaterialTheme.typography.labelSmall, color = WarningAmber)
            }
            Text("${c.requestedByName} — ${c.reason}", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (c.status == com.abm.erp.data.CorrectionRequestStatus.SUBMITTED) {
                    Button(onClick = { MockRepository.managerReviewCorrection(c.id, null, onRejected = { reason -> denyReason = reason }) }) { Text("Review ✓") }
                } else {
                    Button(
                        onClick = { MockRepository.chairmanApproveCorrection(c.id, onRejected = { reason -> denyReason = reason }) },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                    ) { Text("Approve & Apply") }
                }
                OutlinedButton(onClick = { rejectFor = c.id }) { Text("Reject", color = DangerRed) }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
    denyReason?.let {
        Text("⚠ $it", color = DangerRed, style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(6.dp))
    }

    rejectFor?.let { id ->
        androidx.compose.ui.window.Dialog(onDismissRequest = { rejectFor = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var reason by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp)) {
                    Text("Reject Correction", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { MockRepository.chairmanRejectCorrection(id, reason, onRejected = { r -> denyReason = r }); rejectFor = null },
                        enabled = reason.isNotBlank(), modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm Reject") }
                }
            }
        }
    }
}
