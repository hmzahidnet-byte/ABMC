package com.abm.erp.ui.search

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.abm.erp.core.GlassCard
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

/**
 * Global Rule — Universal Search. One search box across Dealers, Retailers,
 * Sales Invoices, Tasks, Leads, Approvals, and Territories/areas
 * (MockRepository.universalSearch does the actual matching, purely in-memory
 * over what's already loaded — works offline like everything else in this
 * app). Tapping a result navigates to that module's existing screen.
 *
 * v113-158 — two changes, both from the person's direct feedback:
 * 1. Converted from a small centered popup Dialog to a genuine full-screen
 *    workspace (same `Dialog(usePlatformDefaultWidth = false)` + full-size
 *    Surface pattern this session already established for Collection/Expense
 *    — "no tiny embedded forms for major operations"), since search results
 *    — especially a Territory result, which opens a full area-intelligence
 *    page — deserve more room than a small popup gave them.
 * 2. A "Territory" result (searching a place name — "Cox's Bazar" is the
 *    person's own example) is now visually distinct — a highlighted card
 *    with a location pin icon and an "এলাকা" badge — rather than blending
 *    into the same plain row every other result type used. Tapping it opens
 *    `TerritoryOverviewScreen` (already real: KPIs, 7-day sales/collection
 *    trend, product-wise sales with photos and company-wide %, and full
 *    clickable Dealers/Retailers/Employees lists for that area) — that
 *    screen already existed and already did most of what the person asked
 *    for; the gap was that its entry point was easy to miss inside a small
 *    popup, not that the destination itself was thin.
 */
@Composable
fun UniversalSearchDialog(onDismiss: () -> Unit, onNavigate: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var debouncedQuery by remember { mutableStateOf("") }
    LaunchedEffect(query) {
        kotlinx.coroutines.delay(250) // debounce — avoid re-searching on every single keystroke
        debouncedQuery = query
    }
    val results = remember(debouncedQuery) { MockRepository.universalSearch(debouncedQuery) }
    var typeFilter by remember { mutableStateOf<String?>(null) }
    val availableTypes = remember(results) { results.map { it.moduleReference }.distinct() }
    val filteredResults = remember(results, typeFilter) { if (typeFilter == null) results else results.filter { it.moduleReference == typeFilter } }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {

                // ── top bar: back + inline search field ──
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                    Spacer(Modifier.width(4.dp))
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        placeholder = { Text("Dealer, retailer, এলাকা, invoice, task, lead…") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        modifier = Modifier.weight(1f), singleLine = true,
                    )
                }

                Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
                    if (query.isBlank()) {
                        Spacer(Modifier.height(24.dp))
                        Text(
                            "টাইপ করা শুরু করুন — Dealer/Retailer/এলাকা/Invoice/Task/Lead/Approval সব জায়গায় একসাথে খুঁজবে।\n\nএকটা এলাকার নাম লিখলে (যেমন \"Cox's Bazar\") — সেই এলাকার সব Dealer/Retailer/Employee, KPI, sales/collection trend আর product-wise বিক্রি একসাথে দেখতে পাবেন।",
                            style = MaterialTheme.typography.bodySmall, color = TextSecondary,
                        )
                    } else if (results.isEmpty()) {
                        Spacer(Modifier.height(24.dp))
                        Text("কোনো ফলাফল পাওয়া যায়নি।", color = TextSecondary)
                    } else {
                        if (availableTypes.size > 1) {
                            Spacer(Modifier.height(4.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(bottom = 8.dp),
                            ) {
                                FilterChip(selected = typeFilter == null, onClick = { typeFilter = null }, label = { Text("All (${results.size})") })
                                availableTypes.forEach { t ->
                                    FilterChip(selected = typeFilter == t, onClick = { typeFilter = t }, label = { Text(t) })
                                }
                            }
                        }
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(bottom = 24.dp),
                        ) {
                            items(filteredResults, key = { it.moduleReference + it.entityId }) { r ->
                                if (r.moduleReference == "Territory") {
                                    // ── distinct card for a location result — this is the
                                    // entry point into the full area-intelligence page ──
                                    Row(
                                        Modifier.fillMaxWidth()
                                            .background(DarazOrange.copy(alpha = 0.08f), androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                                            .then(
                                                if (r.navRoute != null) Modifier.clickable {
                                                    com.abm.erp.data.PendingSearchNavigation.request(r.moduleReference, r.entityId)
                                                    onNavigate(r.navRoute)
                                                } else Modifier,
                                            )
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Box(
                                            Modifier.size(38.dp).background(DarazOrange.copy(alpha = 0.18f), androidx.compose.foundation.shape.CircleShape),
                                            contentAlignment = Alignment.Center,
                                        ) { Icon(Icons.Filled.LocationOn, contentDescription = null, tint = DarazOrange) }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(r.title, fontWeight = FontWeight.Bold, color = TextPrimary)
                                                Spacer(Modifier.width(6.dp))
                                                Box(
                                                    Modifier.background(DarazOrange, androidx.compose.foundation.shape.RoundedCornerShape(4.dp))
                                                        .padding(horizontal = 5.dp, vertical = 1.dp),
                                                ) { Text("এলাকা", color = Color.White, style = MaterialTheme.typography.labelSmall) }
                                            }
                                            Text(r.subtitle, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                        }
                                    }
                                } else {
                                    GlassCard(
                                        modifier = Modifier.fillMaxWidth().then(
                                            if (r.navRoute != null) Modifier.clickable {
                                                com.abm.erp.data.PendingSearchNavigation.request(r.moduleReference, r.entityId)
                                                onNavigate(r.navRoute)
                                            } else Modifier,
                                        ),
                                    ) {
                                        Text("${r.moduleReference} · ${r.title}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                        Text(r.subtitle, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
