package com.abm.erp.ui.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.abm.erp.data.*
import com.abm.erp.theme.*
import kotlinx.coroutines.launch

/**
 * Any authorized HR/Manager can submit here — but the Submit form
 * deliberately only has name/proposed-mobile/notes fields (no
 * designation/department/role/territory/PIN), matching the requirement
 * that submitters cannot approve, activate, or set anything official.
 * The Chairman-only approval section below only renders for the
 * Chairman; a non-Chairman never even sees those controls, and every
 * action they'd try also re-checks server/repo-side in MockRepository —
 * this UI gate is not the only line of defense (Firestore rules also
 * enforce it).
 */
@Composable
fun HiringApprovalCenterScreen() {
    val scope = rememberCoroutineScope()
    val currentUser = MockRepository.currentUser
    val isChairman = currentUser.role == UserRole.CHAIRMAN
    val employees by MockRepository.employeeProfiles.collectAsState()
    val pending = employees.filter { it.onboardingStatus == EmployeeOnboardingStatus.PENDING_CHAIRMAN_APPROVAL || it.onboardingStatus == EmployeeOnboardingStatus.RETURNED_FOR_CORRECTION }

    var showSubmit by remember { mutableStateOf(false) }
    var selectedForApproval by remember { mutableStateOf<String?>(null) }
    var showRejectDialog by remember { mutableStateOf<String?>(null) }
    var showReturnDialog by remember { mutableStateOf<String?>(null) }
    var approvalError by remember { mutableStateOf<String?>(null) }
    var generatedPin by remember { mutableStateOf<Pair<String, String>?>(null) } // employeeId to tempPin, shown ONCE

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Chairman Hiring & Activation Center", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(6.dp))
        Button(onClick = { showSubmit = true }) { Text("+ Submit New Hiring Request") }
        Spacer(Modifier.height(10.dp))
        Text("Pending Requests (${pending.size})", style = MaterialTheme.typography.titleMedium)

        LazyColumn(Modifier.weight(1f)) {
            items(pending) { e ->
                Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), tonalElevation = 2.dp) {
                    Column(Modifier.padding(10.dp)) {
                        Text(e.fullName, style = MaterialTheme.typography.titleSmall)
                        Text("Status: ${e.onboardingStatus}", style = MaterialTheme.typography.labelSmall, color = if (e.onboardingStatus == EmployeeOnboardingStatus.RETURNED_FOR_CORRECTION) WarningAmber else TextSecondary)
                        e.statusReason?.let { Text("Note: $it", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                        if (isChairman) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                                Button(onClick = { selectedForApproval = e.id }) { Text("Approve") }
                                OutlinedButton(onClick = { showReturnDialog = e.id }) { Text("Return") }
                                OutlinedButton(onClick = { showRejectDialog = e.id }) { Text("Reject", color = DangerRed) }
                            }
                        } else {
                            Text("শুধু Chairman-ই approve/reject/return করতে পারবেন।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                }
            }
        }
    }

    if (showSubmit) {
        var name by remember { mutableStateOf("") }
        var mobile by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var notes by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        Dialog(onDismissRequest = { showSubmit = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("New Hiring Request", style = MaterialTheme.typography.titleMedium)
                    Text("এখানে শুধু নাম, প্রস্তাবিত মোবাইল ও নোট — designation/PIN/activation Chairman নিজে সেট করবেন।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Full name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = mobile, onValueChange = { mobile = it }, label = { Text("Proposed mobile") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email (optional)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
                    err?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            scope.launch {
                                val r = MockRepository.submitHiringRequest(name, mobile, email.ifBlank { null }, notes.ifBlank { null }, onRejected = { reason -> err = reason })
                                if (r != null) showSubmit = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Submit for Chairman Approval") }
                }
            }
        }
    }

    selectedForApproval?.let { empId ->
        val emp = employees.firstOrNull { it.id == empId }
        if (emp != null) {
            var officialMobile by remember { mutableStateOf("") }
            var department by remember { mutableStateOf("") }
            var designation by remember { mutableStateOf("") }
            var role by remember { mutableStateOf(UserRole.SR) }
            var territoryId by remember { mutableStateOf<String?>(null) }
            var managerId by remember { mutableStateOf<String?>(null) }
            var templateKey by remember { mutableStateOf<String?>(null) }
            val managers = employees.filter { it.hasActiveAccess && it.role != UserRole.SR }
            Dialog(onDismissRequest = { selectedForApproval = null }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp).heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                        Text("Chairman Approval — ${emp.fullName}", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = officialMobile, onValueChange = { officialMobile = it }, label = { Text("Official mobile number") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(value = department, onValueChange = { department = it }, label = { Text("Department") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(value = designation, onValueChange = { designation = it }, label = { Text("Designation") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        Text("Role", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState())) {
                            UserRole.values().forEach { r -> FilterChip(selected = role == r, onClick = { role = r }, label = { Text(r.name, style = MaterialTheme.typography.labelSmall) }) }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Reporting manager", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState())) {
                            managers.take(20).forEach { m -> FilterChip(selected = managerId == m.id, onClick = { managerId = m.id }, label = { Text(m.fullName, style = MaterialTheme.typography.labelSmall) }) }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Permission template", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState())) {
                            PermissionManager.allTemplates().forEach { t -> FilterChip(selected = templateKey == t.roleKey, onClick = { templateKey = t.roleKey }, label = { Text(t.roleKey, style = MaterialTheme.typography.labelSmall) }) }
                        }
                        approvalError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = {
                                val pin = MockRepository.chairmanApproveHiring(empId, officialMobile, department, designation, role, territoryId, managerId, templateKey, onRejected = { r -> approvalError = r })
                                if (pin != null) { generatedPin = empId to pin; selectedForApproval = null; approvalError = null }
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Approve & Activate") }
                    }
                }
            }
        }
    }

    showRejectDialog?.let { empId ->
        var reason by remember { mutableStateOf("") }
        Dialog(onDismissRequest = { showRejectDialog = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Reject Hiring Request", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason (required)") }, modifier = Modifier.fillMaxWidth())
                    var rejectHiringError by remember { mutableStateOf<String?>(null) }
                    rejectHiringError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { scope.launch { if (MockRepository.chairmanRejectHiring(empId, reason, onRejected = { r -> rejectHiringError = r })) showRejectDialog = null } }, enabled = reason.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Confirm Reject") }
                }
            }
        }
    }

    showReturnDialog?.let { empId ->
        var comment by remember { mutableStateOf("") }
        Dialog(onDismissRequest = { showReturnDialog = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Return for Correction", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(value = comment, onValueChange = { comment = it }, label = { Text("Comment (required)") }, modifier = Modifier.fillMaxWidth())
                    var returnError by remember { mutableStateOf<String?>(null) }
                    returnError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { scope.launch { if (MockRepository.chairmanReturnForCorrection(empId, comment, onRejected = { r -> returnError = r })) showReturnDialog = null } }, enabled = comment.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Confirm Return") }
                }
            }
        }
    }

    generatedPin?.let { (empId, pin) ->
        Dialog(onDismissRequest = { generatedPin = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("✓ Activated", style = MaterialTheme.typography.titleMedium, color = SuccessGreen)
                    Text("Temporary PIN (share securely, shown only once): $pin", style = MaterialTheme.typography.bodyMedium)
                    Text("Employee must change this PIN on first login.", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { generatedPin = null }, modifier = Modifier.fillMaxWidth()) { Text("Done") }
                }
            }
        }
    }
}
