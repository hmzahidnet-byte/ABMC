package com.abm.erp.nav

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.abm.erp.ui.advisory.BoardroomScreen
import com.abm.erp.ui.billing.CreditAndBillingScreen
import com.abm.erp.ui.complaint.ComplaintBoxScreen
import com.abm.erp.ui.courier.CourierScreen
import com.abm.erp.ui.crm.GeoCrmScreen
import com.abm.erp.ui.dashboard.MainDashboardScreen
import com.abm.erp.ui.dealer.DealersScreen
import com.abm.erp.ui.helpdesk.HelpdeskScreen
import com.abm.erp.ui.hrm.PayrollScreen
import com.abm.erp.ui.inventory.InventoryScreen
import com.abm.erp.ui.ledger.LedgerScreen
import com.abm.erp.ui.market.MarketAnalysisScreen
import com.abm.erp.ui.notifications.NotificationsScreen
import com.abm.erp.ui.production.ProductionScreen
import com.abm.erp.ui.purchase.PurchaseScreen
import com.abm.erp.ui.comms.CommunicationHubScreen
import com.abm.erp.ui.reports.ReportsScreen
import com.abm.erp.ui.sales.SalesChainScreen
import com.abm.erp.ui.tasks.TaskManagerScreen

sealed class Dest(val route: String, val label: String) {
    data object Dashboard : Dest("dashboard", "Dashboard")
    data object Sales : Dest("sales", "Sales Chain")
    data object Inventory : Dest("inventory", "Inventory")
    data object Crm : Dest("crm", "Geo CRM")
    data object Hrm : Dest("hrm", "HRM & Payroll")
    data object Billing : Dest("billing", "Credit & Billing")
    data object Production : Dest("production", "Production")
    data object Boardroom : Dest("boardroom", "Boardroom")
    data object PermissionCenter : Dest("permission_center", "Permission Control Center")
    data object HiringCenter : Dest("hiring_center", "Chairman Hiring & Activation Center")
    data object VacancyTargetCenter : Dest("vacancy_target_center", "Vacancy & Target Control Center")
    data object ProductionWarehouse : Dest("production_warehouse", "Production & Warehouse")
    data object PeriodLockCenter : Dest("period_lock_center", "Accounting Period Lock")
    data object CompanySettingsCenter : Dest("company_settings_center", "Company Settings Center")
    data object SystemHealthDashboard : Dest("system_health_dashboard", "System Health Dashboard")
    data object BusinessRuleEngine : Dest("business_rule_engine", "Business Rule Engine")
    data object EnterpriseAuditCenter : Dest("enterprise_audit_center", "Enterprise Audit Center")
    data object UniversalScanner : Dest("universal_scanner", "Universal QR Scanner")
    data object Expenses : Dest("expenses", "Expenses")
    data object SyncStatusCenter : Dest("sync_status_center", "Sync Status Center")
    data object Complaint : Dest("complaint", "Complaint Box")
    data object Dealers : Dest("dealers", "Dealers & Stock")
    data object Courier : Dest("courier", "Courier & Logistics")
    data object Tasks : Dest("tasks", "Task Manager")
    data object Notifications : Dest("notifications", "Notifications")
    data object Market : Dest("market", "Market Analysis")
    data object ChairmanHub : Dest("chairman_hub", "Chairman Intelligence Hub")
    data object Suite : Dest("suite/{key}", "Module")
    data object InvoiceDoc : Dest("invoice_doc/{id}", "Invoice")
    data object MemoDoc : Dest("memo_doc/{id}", "Memo")
    data object RetailOrder : Dest("retail_order", "Retailer Order")
    data object EmployeeSetup : Dest("employee_setup", "Employee Setup")
    data object PartyStatement : Dest("statement/{type}/{id}", "Party Statement")
    data object Territory : Dest("territory/{zone}", "Territory")
    data object DealerStock : Dest("dealer_stock/{id}", "Dealer Stock")
    data object DealerInvoiceNew : Dest("dealer_invoice_new", "New Dealer Invoice")
    data object ConfigCenter : Dest("configuration_center", "Configuration Center")
    data object Ledger : Dest("ledger", "Accounts / Ledger")
    // v113-74 — the six mother modules. DMS and RMS are built; the other four follow.
    data object Dms : Dest("dms", "DMS")
    data object Rms : Dest("rms", "RMS")
    data object Hr : Dest("hr_module", "HR")
    data object Fms : Dest("fms", "FMS")
    data object ChairmanModule : Dest("chairman_module", "Chairman")
    data object Helpdesk : Dest("helpdesk", "Helpdesk")
    data object Reports : Dest("reports", "Reports")
    data object Purchase : Dest("purchase", "Purchase")
    data object Comms : Dest("comms", "Communication Hub")
}

val bottomNavItems = listOf(Dest.Dashboard, Dest.Sales, Dest.Inventory, Dest.Crm, Dest.Hrm, Dest.Billing, Dest.Production, Dest.Boardroom)

@Composable
fun ABMNavGraph(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Dest.Dashboard.route) {
        // v113-77 — the Dashboard route now lands on the clean five-module Home. The old
        // MainDashboardScreen file stays in the codebase un-routed (see HomeScreen's doc).
        composable(Dest.Dashboard.route) { com.abm.erp.ui.home.HomeScreen(onNavigate = { navController.navigate(it) }) }
        composable("${Dest.Sales.route}?tab={tab}", arguments = listOf(navArgument("tab") { type = NavType.StringType; nullable = true; defaultValue = null }),) { e -> SalesChainScreen(startTab = e.arguments?.getString("tab")?.toIntOrNull(), onBack = { navController.popBackStack() }, onNavigate = { navController.navigate(it) { launchSingleTop = true } }) }
        composable("${Dest.Inventory.route}?tab={tab}", arguments = listOf(navArgument("tab") { type = NavType.StringType; nullable = true; defaultValue = null }),) { e -> InventoryScreen(startTab = e.arguments?.getString("tab")?.toIntOrNull(), onBack = { navController.popBackStack() }) }
        composable("${Dest.Crm.route}?tab={tab}", arguments = listOf(navArgument("tab") { type = NavType.StringType; nullable = true; defaultValue = null }),) { e -> GeoCrmScreen(startTab = e.arguments?.getString("tab")?.toIntOrNull(), onBack = { navController.popBackStack() }) }
        composable("${Dest.Hrm.route}?tab={tab}", arguments = listOf(navArgument("tab") { type = NavType.StringType; nullable = true; defaultValue = null }),) { e -> PayrollScreen(startTab = e.arguments?.getString("tab")?.toIntOrNull(), onBack = { navController.popBackStack() }) }
        composable("${Dest.Billing.route}?tab={tab}", arguments = listOf(navArgument("tab") { type = NavType.StringType; nullable = true; defaultValue = null }),) { e -> CreditAndBillingScreen(startTab = e.arguments?.getString("tab")?.toIntOrNull(), onBack = { navController.popBackStack() }) }
        composable("${Dest.Production.route}?tab={tab}", arguments = listOf(navArgument("tab") { type = NavType.StringType; nullable = true; defaultValue = null }),) { e -> ProductionScreen(startTab = e.arguments?.getString("tab")?.toIntOrNull(), onBack = { navController.popBackStack() }, onNavigate = { navController.navigate(it) { launchSingleTop = true } }) }
        composable(Dest.Boardroom.route) { BoardroomScreen(onNavigate = { navController.navigate(it) }) }
        composable(Dest.PermissionCenter.route) { com.abm.erp.ui.admin.PermissionControlCenterScreen() }
        composable(Dest.HiringCenter.route) { com.abm.erp.ui.admin.HiringApprovalCenterScreen() }
        composable(Dest.VacancyTargetCenter.route) { com.abm.erp.ui.admin.VacancyTargetCenterScreen() }
        composable("${Dest.ProductionWarehouse.route}?tab={tab}", arguments = listOf(navArgument("tab") { type = NavType.StringType; nullable = true; defaultValue = null }),) { e -> com.abm.erp.ui.production.ProductionWarehouseScreen(startTab = e.arguments?.getString("tab")?.toIntOrNull(), onBack = { navController.popBackStack() }, onNavigate = { navController.navigate(it) { launchSingleTop = true } }) }
        composable(Dest.PeriodLockCenter.route) { com.abm.erp.ui.admin.PeriodLockCenterScreen() }
        composable(Dest.CompanySettingsCenter.route) { com.abm.erp.ui.admin.CompanySettingsCenterScreen() }
        composable(Dest.SystemHealthDashboard.route) { com.abm.erp.ui.admin.SystemHealthDashboardScreen() }
        composable(Dest.BusinessRuleEngine.route) { com.abm.erp.ui.admin.BusinessRuleEngineScreen() }
        composable(Dest.EnterpriseAuditCenter.route) { com.abm.erp.ui.admin.EnterpriseAuditCenterScreen() }
        composable(Dest.UniversalScanner.route) { com.abm.erp.ui.scanner.UniversalScannerScreen(onNavigate = { navController.navigate(it) { launchSingleTop = true } }) }
        composable(Dest.Expenses.route) { com.abm.erp.ui.expense.ExpenseScreen() }
        composable(Dest.SyncStatusCenter.route) { com.abm.erp.ui.admin.SyncStatusCenterScreen() }
        composable(Dest.Complaint.route) { ComplaintBoxScreen() }
        composable("${Dest.Dealers.route}?tab={tab}", arguments = listOf(navArgument("tab") { type = NavType.StringType; nullable = true; defaultValue = null }),) { e -> DealersScreen(startTab = e.arguments?.getString("tab")?.toIntOrNull(), onBack = { navController.popBackStack() }, onNavigate = { navController.navigate(it) { launchSingleTop = true } }) }
        composable(Dest.Courier.route) { CourierScreen() }
        composable(Dest.Tasks.route) { TaskManagerScreen() }
        composable("${Dest.Dms.route}?key={key}", arguments = listOf(navArgument("key") { type = NavType.StringType; nullable = true; defaultValue = null }),) { e ->
            com.abm.erp.ui.dms.DmsHomeScreen(startKey = e.arguments?.getString("key"), onBackToHome = { navController.popBackStack() }, onNavigate = { navController.navigate(it) { launchSingleTop = true } })
        }
        composable("${Dest.Rms.route}?key={key}", arguments = listOf(navArgument("key") { type = NavType.StringType; nullable = true; defaultValue = null }),) { e ->
            com.abm.erp.ui.rms.RmsHomeScreen(startKey = e.arguments?.getString("key"), onBackToHome = { navController.popBackStack() }, onNavigate = { navController.navigate(it) { launchSingleTop = true } })
        }
        composable("${Dest.Hr.route}?key={key}", arguments = listOf(navArgument("key") { type = NavType.StringType; nullable = true; defaultValue = null }),) { e ->
            com.abm.erp.ui.hr.HrHomeScreen(startKey = e.arguments?.getString("key"), onBackToHome = { navController.popBackStack() }, onNavigate = { navController.navigate(it) { launchSingleTop = true } })
        }
        composable("${Dest.Fms.route}?key={key}", arguments = listOf(navArgument("key") { type = NavType.StringType; nullable = true; defaultValue = null }),) { e ->
            com.abm.erp.ui.fms.FmsHomeScreen(startKey = e.arguments?.getString("key"), onBackToHome = { navController.popBackStack() }, onNavigate = { navController.navigate(it) { launchSingleTop = true } })
        }
        composable("${Dest.ChairmanModule.route}?key={key}", arguments = listOf(navArgument("key") { type = NavType.StringType; nullable = true; defaultValue = null }),) { e ->
            com.abm.erp.ui.chairmanmodule.ChairmanHomeScreen(startKey = e.arguments?.getString("key"), onBackToHome = { navController.popBackStack() }, onNavigate = { navController.navigate(it) { launchSingleTop = true } })
        }
        composable(Dest.Notifications.route) { NotificationsScreen(onNavigate = { navController.navigate(it) }) }
        composable(Dest.Market.route) { MarketAnalysisScreen() }
        composable(Dest.ChairmanHub.route) { com.abm.erp.ui.chairman.ChairmanHubScreen(onNavigate = { navController.navigate(it) { launchSingleTop = true } }) }
        composable(Dest.ConfigCenter.route) {
            com.abm.erp.ui.admin.ConfigurationCenterScreen(onNavigate = { navController.navigate(it) { launchSingleTop = true } })
        }
        composable(Dest.DealerInvoiceNew.route) {
            com.abm.erp.ui.sales.DealerInvoiceScreen(
                onBack = { navController.popBackStack() },
                onNavigate = { navController.navigate(it) { launchSingleTop = true } },
            )
        }
        composable(Dest.DealerStock.route) { entry ->
            com.abm.erp.ui.dealer.DealerStockScreen(
                dealerId = entry.arguments?.getString("id").orEmpty(),
                onBack = { navController.popBackStack() },
            )
        }
        composable("retailer_stock/{id}") { entry ->
            com.abm.erp.ui.dealer.RetailerStockScreen(
                retailerId = entry.arguments?.getString("id").orEmpty(),
                onBack = { navController.popBackStack() },
            )
        }
        composable(Dest.Territory.route) { entry ->
            com.abm.erp.ui.territory.TerritoryOverviewScreen(
                zoneRaw = entry.arguments?.getString("zone").orEmpty(),
                onNavigate = { navController.navigate(it) { launchSingleTop = true } },
                onBack = { navController.popBackStack() },
            )
        }
        composable(Dest.PartyStatement.route) { entry ->
            com.abm.erp.ui.ledger.PartyStatementScreen(
                partyType = entry.arguments?.getString("type").orEmpty(),
                partyId = entry.arguments?.getString("id").orEmpty(),
                onBack = { navController.popBackStack() },
            )
        }
        composable(Dest.EmployeeSetup.route) {
            com.abm.erp.ui.admin.EmployeeSetupScreen(onNavigate = { navController.navigate(it) { launchSingleTop = true } })
        }
        composable(Dest.RetailOrder.route) {
            com.abm.erp.ui.sales.RetailOrderScreen(onBack = { navController.popBackStack() })
        }
        composable(Dest.InvoiceDoc.route) { entry ->
            com.abm.erp.ui.invoice.InvoiceDocumentScreen(
                invoiceId = entry.arguments?.getString("id").orEmpty(),
                onBack = { navController.popBackStack() },
            )
        }
        composable(Dest.MemoDoc.route) { entry ->
            com.abm.erp.ui.memo.MemoDocumentScreen(
                orderId = entry.arguments?.getString("id").orEmpty(),
                onBack = { navController.popBackStack() },
            )
        }
        composable(Dest.Suite.route) { entry ->
            com.abm.erp.ui.suite.SuiteHomeScreen(
                suiteKey = entry.arguments?.getString("key").orEmpty(),
                onNavigate = { navController.navigate(it) { launchSingleTop = true } },
            )
        }
        composable("${Dest.Ledger.route}?tab={tab}", arguments = listOf(navArgument("tab") { type = NavType.StringType; nullable = true; defaultValue = null }),) { e -> LedgerScreen(startTab = e.arguments?.getString("tab")?.toIntOrNull(), onBack = { navController.popBackStack() }, onNavigate = { navController.navigate(it) { launchSingleTop = true } }) }
        composable(Dest.Helpdesk.route) { HelpdeskScreen() }
        composable(Dest.Reports.route) { ReportsScreen() }
        composable("${Dest.Purchase.route}?tab={tab}", arguments = listOf(navArgument("tab") { type = NavType.StringType; nullable = true; defaultValue = null }),) { e -> PurchaseScreen(startTab = e.arguments?.getString("tab")?.toIntOrNull(), onBack = { navController.popBackStack() }) }
        composable(Dest.Comms.route) { CommunicationHubScreen() }
    }
}
