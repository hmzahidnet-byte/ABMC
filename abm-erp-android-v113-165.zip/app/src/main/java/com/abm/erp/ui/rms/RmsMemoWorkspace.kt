package com.abm.erp.ui.rms

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.GlassCard
import com.abm.erp.core.Space
import com.abm.erp.core.rememberVisibleRetailers
import com.abm.erp.data.CodeRegistry
import com.abm.erp.data.MockRepository
import com.abm.erp.data.SalesInvoiceLineItem
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.DarazOrange
import com.abm.erp.theme.DarazOrangeDark
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import kotlinx.coroutines.launch

/**
 * v113-80 — RMS ORDER (MEMO) WORKSPACE. Second application of the workspace contract,
 * built from the DMS Invoice Workspace reference: retailer identify (search OR QR/code
 * autofill, cascade re-checked), retailer financial context (due / credit limit /
 * memo history), product add with live stock, memo summary, create, and the
 * retailer's memo history inline. Helper actions stay dialogs; nothing navigates away.
 *
 * Engines reused untouched: `logNewOrder` (now carrying the real retailerId — see
 * MockRepository v113-80 note), `CodeRegistry.resolve`, `rememberVisibleRetailers`.
 * The old free-text RetailerTab keeps serving the legacy Sales suite; this workspace
 * is the RMS-native path where the memo is linked to a real Retailer record, which is
 * also what makes the v113-75 retailer-stock pipeline actually run.
 */
@Composable
fun RmsMemoWorkspace(onNavigate: (String) -> Unit = {}) {
    val retailers = rememberVisibleRetailers()
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val stockLevels by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
    val orders by MockRepository.orders.collectAsState()

    var codeInput by remember { mutableStateOf("") }
    var codeError by remember { mutableStateOf<String?>(null) }
    var retailerQuery by remember { mutableStateOf("") }
    var selectedRetailerId by remember { mutableStateOf<String?>(null) }
    var showAddProduct by remember { mutableStateOf(false) }
    var productQuery by remember { mutableStateOf("") }
    var cart by remember { mutableStateOf(listOf<SalesInvoiceLineItem>()) }
    var lastResult by remember { mutableStateOf<String?>(null) }
    // v113-162 — same "one workspace" fix as the Invoice side: Print/Share now
    // shows the same branded MemoDocumentBody inline instead of navigating away.
    var viewingOrderId by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var docBusy by remember { mutableStateOf(false) }
    var qrPayloadForPdf by remember(viewingOrderId) { mutableStateOf<String?>(null) }

    val retailer = retailers.firstOrNull { it.id == selectedRetailerId }
    val retailerOrders = remember(orders, selectedRetailerId, retailer) {
        if (retailer == null) emptyList()
        // Matches by linked id where present, by name for pre-v113-80 memos that have no link.
        else orders.filter { it.retailerId == retailer.id || (it.retailerId == null && it.retailerName == retailer.name) }
            .sortedByDescending { it.loggedAt }
    }
    val total = remember(cart) { cart.sumOf { it.lineTotal } }
    val overCredit = retailer != null && retailer.creditLimit > 0 && (retailer.dueBalance + total) > retailer.creditLimit

    fun applyCode() {
        codeError = null
        when (val r = CodeRegistry.resolve(codeInput)) {
            is CodeRegistry.ResolveResult.Found -> when (r.type) {
                CodeRegistry.CodeType.RETAILER -> {
                    if (retailers.any { it.id == r.id }) { selectedRetailerId = r.id; codeInput = "" }
                    else codeError = "এই retailer আপনার এলাকার বাইরে — নির্বাচন করা যাবে না।"
                }
                CodeRegistry.CodeType.PRODUCT -> {
                    val p = products.firstOrNull { it.id == r.id && !it.isDeleted }
                    if (p != null) { cart = cart + SalesInvoiceLineItem(p.id, p.name, p.unit, 1, p.defaultUnitPrice); codeInput = "" }
                    else codeError = "Product পাওয়া গেল কিন্তু লোড হয়নি।"
                }
                else -> codeError = "এই কোডটি ${r.type} — এখানে retailer/product কোড লাগবে।"
            }
            is CodeRegistry.ResolveResult.Ambiguous -> codeError = "একই কোড একাধিক রেকর্ডে — data integrity সমস্যা, admin-কে জানান।"
            CodeRegistry.ResolveResult.NotFound -> codeError = "কোডটি মেলেনি।"
            CodeRegistry.ResolveResult.Invalid -> codeError = "কোড খালি/অবৈধ।"
        }
    }

    // v113-162 — branded header, always visible in both modes, matching the
    // Invoice workspace's same treatment.
    val memoWsCompany = remember { MockRepository.companySettings() }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(DarazOrange, DarazOrangeDark)))
                .padding(horizontal = Space.lg, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    memoWsCompany.companyName.ifBlank { "ABM CORPORATION" }.uppercase(),
                    color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                )
                Text(
                    if (viewingOrderId == null) "New Memo" else "Memo",
                    color = Color.White.copy(alpha = 0.85f), fontSize = 10.sp,
                )
            }
            Text("MEMO", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }

        if (viewingOrderId == null) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Spacer(Modifier.height(4.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = codeInput, onValueChange = { codeInput = it },
                        placeholder = { Text("Retailer/Product QR বা কোড…") },
                        singleLine = true, modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { applyCode() }, enabled = codeInput.isNotBlank()) { Text("Fill") }
                    IconButton(onClick = { onNavigate("universal_scanner") }) {
                        Icon(Icons.Filled.QrCodeScanner, contentDescription = "Scan", tint = TextPrimary)
                    }
                }
                codeError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
            }
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Retailer", fontWeight = FontWeight.Bold, color = TextPrimary)
                if (retailer == null) {
                    OutlinedTextField(
                        value = retailerQuery, onValueChange = { retailerQuery = it },
                        placeholder = { Text("নাম/market দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                    val matches = remember(retailers, retailerQuery) {
                        if (retailerQuery.isBlank()) emptyList()
                        else retailers.filter { it.name.contains(retailerQuery, true) || it.market.orEmpty().contains(retailerQuery, true) }.take(5)
                    }
                    matches.forEach { rt ->
                        Text(
                            "${rt.name} — ${rt.market.orEmpty()}",
                            modifier = Modifier.fillMaxWidth().clickable { selectedRetailerId = rt.id; retailerQuery = "" }.padding(vertical = 8.dp),
                            color = TextPrimary,
                        )
                    }
                    if (retailerQuery.isNotBlank() && matches.isEmpty()) {
                        Text("আপনার এলাকায় মেলেনি।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(retailer.name, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(retailer.market.orEmpty(), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        TextButton(onClick = { selectedRetailerId = null }) { Text("বদলান") }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Outstanding Due", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("৳${"%,.0f".format(retailer.dueBalance)}", fontWeight = FontWeight.Bold, color = if (retailer.dueBalance > 0) WarningAmber else SuccessGreen)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Credit Limit", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("৳${"%,.0f".format(retailer.creditLimit)}", color = TextPrimary)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Memo history", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("${retailerOrders.size} টি · ৳${"%,.0f".format(retailerOrders.sumOf { it.amount })}", color = TextPrimary)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { onNavigate("statement/RETAILER/${retailer.id}") }) { Text("Full Ledger →") }
                        TextButton(onClick = { onNavigate("retailer_stock/${retailer.id}") }) { Text("Stock →") }
                    }
                    // v113-142 — retailer location inside the memo workspace. Unlike
                    // Dealer, Retailer genuinely HAS lat/lng, so this gives real
                    // turn-by-turn navigation when a GPS fix was captured, and falls
                    // back to an address search when it wasn't. Same proven intent
                    // chain as DealersScreen (Maps → geo: → honest Toast).
                    val memoNavContext = androidx.compose.ui.platform.LocalContext.current
                    val hasGps = retailer.lat != null && retailer.lng != null
                    if (hasGps || retailer.address.isNotBlank()) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text(
                                "📍 " + if (hasGps) "GPS tagged · ${retailer.address.ifBlank { retailer.market.orEmpty() }}" else retailer.address,
                                style = MaterialTheme.typography.labelSmall, color = TextSecondary, modifier = Modifier.weight(1f),
                            )
                            TextButton(onClick = {
                                try {
                                    val uri = if (hasGps) android.net.Uri.parse("google.navigation:q=${retailer.lat},${retailer.lng}")
                                    else android.net.Uri.parse("geo:0,0?q=${android.net.Uri.encode(retailer.address)}")
                                    memoNavContext.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, uri).apply { setPackage("com.google.android.apps.maps") })
                                } catch (e: Exception) {
                                    try {
                                        val fb = if (hasGps) "geo:${retailer.lat},${retailer.lng}" else "geo:0,0?q=${android.net.Uri.encode(retailer.address)}"
                                        memoNavContext.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(fb)))
                                    } catch (e2: Exception) {
                                        android.widget.Toast.makeText(memoNavContext, "Maps app পাওয়া যায়নি।", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }) { Text(if (hasGps) "Navigate" else "Map") }
                        }
                    }
                }
            }
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("Product", fontWeight = FontWeight.Bold, color = TextPrimary)
                    // v113-143 — same in-place product add as the invoice workspace, so a
                    // missing product doesn't force the SR out of a half-written memo in
                    // the field. Permission-gated on inv-CREATE: a button that could only
                    // ever reject the person is worse than no button. Workspace only — the
                    // printed memo is drawn separately and carries no controls.
                    if (com.abm.erp.data.PermissionManager.canCurrentUser("inv", com.abm.erp.data.PermissionAction.CREATE)) {
                        TextButton(onClick = { showAddProduct = true }) { Text("+ New Product") }
                    }
                }
                OutlinedTextField(
                    value = productQuery, onValueChange = { productQuery = it },
                    placeholder = { Text("Product নাম/SKU…") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                val productMatches = remember(products, productQuery) {
                    products.filter {
                        !it.isDeleted && it.isActive &&
                            (productQuery.isBlank() || it.name.contains(productQuery, true) || it.sku.contains(productQuery, true))
                    }.take(6)
                }
                productMatches.forEach { p ->
                    val onHand = stockLevels.filter { it.productId == p.id }.sumOf { it.quantityOnHand }
                    Row(
                        Modifier.fillMaxWidth().clickable { cart = cart + SalesInvoiceLineItem(p.id, p.name, p.unit, 1, p.defaultUnitPrice) }.padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column {
                            Text(p.name, color = TextPrimary)
                            Text("৳${"%,.0f".format(p.defaultUnitPrice)}/${p.unit} · stock ${"%,.0f".format(onHand)}", style = MaterialTheme.typography.labelSmall, color = if (onHand <= 0) DangerRed else TextSecondary)
                        }
                        Icon(Icons.Filled.AddCircleOutline, contentDescription = "Add", tint = TextSecondary)
                    }
                }
            }
        }

        if (cart.isNotEmpty()) {
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Memo Items (${cart.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
                    cart.forEachIndexed { idx, line ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(line.name, color = TextPrimary)
                                Text("৳${"%,.0f".format(line.unitPrice)}/${line.unit}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                            IconButton(onClick = { if (line.qty > 1) cart = cart.toMutableList().also { it[idx] = line.copy(qty = line.qty - 1) } }) { Icon(Icons.Filled.RemoveCircleOutline, null, tint = TextSecondary) }
                            Text("${line.qty}", fontWeight = FontWeight.Bold, color = TextPrimary)
                            IconButton(onClick = { cart = cart.toMutableList().also { it[idx] = line.copy(qty = line.qty + 1) } }) { Icon(Icons.Filled.AddCircleOutline, null, tint = TextSecondary) }
                            IconButton(onClick = { cart = cart.filterIndexed { i, _ -> i != idx } }) { Icon(Icons.Filled.Delete, null, tint = DangerRed) }
                        }
                    }
                }
            }
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Memo Summary", fontWeight = FontWeight.Bold, color = TextPrimary)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("৳${"%,.0f".format(total)}", fontWeight = FontWeight.Bold, color = TextPrimary)
                }
                if (overCredit) {
                    Text(
                        "⚠ Credit limit ছাড়িয়ে যাবে — TSM verify ধাপে এটি দেখা যাবে।",
                        color = WarningAmber, style = MaterialTheme.typography.labelSmall,
                    )
                }
                Button(
                    onClick = {
                        val rt = retailer ?: return@Button
                        lastResult = null
                        val ok = MockRepository.logNewOrder(
                            retailerName = rt.name, items = cart.joinToString(", ") { "${it.name} x${it.qty}" },
                            amount = total, zone = rt.market.orEmpty().ifBlank { "N/A" },
                            lineItems = cart, retailerId = rt.id,
                            onRejected = { reason -> lastResult = "✖ $reason" },
                        )
                        if (ok) {
                            lastResult = "✔ Memo তৈরি হয়েছে — TSM verify করলে dealer-এ route হবে।"
                            cart = emptyList()
                        } else if (lastResult == null) {
                            lastResult = "✖ Memo তৈরি হয়নি — আবার চেষ্টা করুন।"
                        }
                    },
                    enabled = retailer != null && cart.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Memo তৈরি করুন") }
                lastResult?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = if (it.startsWith("✔")) SuccessGreen else DangerRed) }
            }
        }

        if (retailerOrders.isNotEmpty()) {
            item { Text("এই retailer-এর Memo (${retailerOrders.size})", fontWeight = FontWeight.SemiBold, color = TextPrimary) }
            items(retailerOrders.take(10), key = { it.id }) { o ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(o.orderNo, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        com.abm.erp.core.StatusPill(o.stage.name)
                    }
                    Text("৳${"%,.0f".format(o.amount)} · ${o.loggedAt.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(o.items, style = MaterialTheme.typography.labelSmall, color = TextSecondary, maxLines = 2)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { viewingOrderId = o.id }) { Text("Print/Share") }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
        } else {
            // ── view mode: same branded document MemoDocumentScreen uses,
            // rendered inline — no navigation, no separate screen. ──
            val viewedOrder = orders.firstOrNull { it.id == viewingOrderId }
            if (viewedOrder == null) {
                Column(Modifier.weight(1f).fillMaxWidth().padding(Space.lg)) {
                    Text("এই মেমোটি পাওয়া যায়নি।", color = TextSecondary)
                    TextButton(onClick = { viewingOrderId = null }) { Text("← ফিরে যান") }
                }
            } else {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(Space.md)) {
                    com.abm.erp.ui.memo.MemoDocumentBody(order = viewedOrder, onQrPayloadReady = { qrPayloadForPdf = it })
                    Spacer(Modifier.height(Space.lg))
                }
                Row(
                    Modifier.fillMaxWidth().padding(Space.md),
                    horizontalArrangement = Arrangement.spacedBy(Space.sm),
                ) {
                    Box(Modifier.weight(1f)) {
                        com.abm.erp.core.SecondaryButton("← New Memo", onClick = { viewingOrderId = null })
                    }
                    Box(Modifier.weight(1f)) {
                        com.abm.erp.core.SecondaryButton("Share", onClick = {
                            runCatching {
                                val summary = "Memo ${viewedOrder.orderNo}\n${viewedOrder.retailerName}\nTotal: ৳${"%,.0f".format(viewedOrder.amount)}\nStage: ${viewedOrder.stage.name}"
                                val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                    type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary)
                                }
                                context.startActivity(android.content.Intent.createChooser(i, "Share memo"))
                            }.onFailure {
                                android.widget.Toast.makeText(context, "Share করার মতো app পাওয়া যায়নি।", android.widget.Toast.LENGTH_LONG).show()
                            }
                        }, icon = Icons.Filled.Share)
                    }
                    Box(Modifier.weight(1.2f)) {
                        com.abm.erp.core.PrimaryButton(
                            text = if (docBusy) "…" else "Print / PDF",
                            icon = Icons.Filled.Print,
                            loading = docBusy,
                            onClick = {
                                docBusy = true
                                scope.launch {
                                    runCatching {
                                        // Same reuse-or-warn QR logic as MemoDocumentScreen — see v113-161.
                                        val payload = qrPayloadForPdf ?: run {
                                            val alreadyExists = com.abm.erp.data.QrRegistry.activeFor("RetailOrder", viewedOrder.id) != null
                                            if (alreadyExists) null
                                            else com.abm.erp.data.QrRegistry.issue("RetailOrder", viewedOrder.id)?.also { qrPayloadForPdf = it }
                                        }
                                        if (payload == null) {
                                            android.widget.Toast.makeText(
                                                context,
                                                "এই মেমোর QR আগেই issue করা আছে — উপরে \"Reissue QR\"-এ ট্যাপ করে নতুন QR নিন, তারপর Print করুন।",
                                                android.widget.Toast.LENGTH_LONG,
                                            ).show()
                                        } else {
                                            val file = com.abm.erp.core.exportRetailOrderPdf(context, viewedOrder, payload)
                                            val uri = androidx.core.content.FileProvider.getUriForFile(
                                                context, "${context.packageName}.fileprovider", file,
                                            )
                                            val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                                type = "application/pdf"
                                                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(android.content.Intent.createChooser(i, "Memo PDF"))
                                        }
                                    }.onFailure {
                                        android.widget.Toast.makeText(context, "PDF তৈরি করা যায়নি।", android.widget.Toast.LENGTH_LONG).show()
                                    }
                                    docBusy = false
                                }
                            },
                        )
                    }
                }
            }
        }
    }

    // v113-143 — real add-product dialog, same engine and same real rejection
    // surfacing as the invoice workspace's version. Placed after the LazyColumn
    // (a dialog, never a navigation step — workspace contract).
    if (showAddProduct) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showAddProduct = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var pName by remember { mutableStateOf("") }
                var pSku by remember { mutableStateOf("") }
                var pUnit by remember { mutableStateOf("pcs") }
                var pCategory by remember { mutableStateOf("") }
                var pPrice by remember { mutableStateOf("") }
                var pError by remember { mutableStateOf<String?>(null) }
                Column(Modifier.padding(16.dp)) {
                    Text("নতুন Product", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("যোগ করার সাথে সাথেই এই memo-তে ব্যবহার করা যাবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    pError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = pName, onValueChange = { pName = it }, label = { Text("নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = pSku, onValueChange = { pSku = it }, label = { Text("SKU") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = pUnit, onValueChange = { pUnit = it }, label = { Text("Unit") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = pPrice, onValueChange = { pPrice = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("দাম") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = pCategory, onValueChange = { pCategory = it }, label = { Text("Category") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            pError = null
                            com.abm.erp.data.InventoryRepository.addProduct(
                                sku = pSku.trim(), name = pName.trim(), unit = pUnit.trim().ifBlank { "pcs" },
                                category = pCategory.trim(), reorderThreshold = 0.0,
                                defaultUnitPrice = pPrice.toDoubleOrNull() ?: 0.0,
                                onRejected = { r -> pError = r },
                                onCreated = { showAddProduct = false },
                            )
                        },
                        enabled = pName.isNotBlank() && pSku.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("যোগ করুন") }
                }
            }
        }
    }
}
