package com.abm.erp.ui.territory

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.core.Space
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.*
import java.time.LocalDate

/**
 * Territory Overview — everything about one area, on one page.
 *
 * Reached by tapping a place name in search. Previously that dropped the user on the Dealers
 * module hub, which threw away the thing they had just found; a zone is a real subject with
 * its own dealers, retailers, sales and due, so it gets its own destination.
 *
 * **Cascade visibility is applied to the underlying lists, not just the header.** Dealers and
 * retailers are filtered through the same `visibleDealerIds` / `visibleRetailerIds` the rest
 * of the app uses, so an SR opening a zone sees that zone *as far as their own scope reaches*,
 * never the whole company's data for it. Every figure below is derived from those scoped
 * lists, so the KPIs, graphs and product breakdown inherit the same limit automatically.
 *
 * All figures come from existing repository data. Nothing is generated or sampled.
 */
@Composable
fun TerritoryOverviewScreen(zoneRaw: String, onNavigate: (String) -> Unit, onBack: () -> Unit) {
    val zone = remember(zoneRaw) { runCatching { java.net.URLDecoder.decode(zoneRaw, "UTF-8") }.getOrDefault(zoneRaw) }

    val allDealers by MockRepository.dealers.collectAsState()
    val allRetailers by MockRepository.retailers.collectAsState()
    val invoices by MockRepository.salesInvoices.collectAsState()
    val collections by MockRepository.partyCollections.collectAsState()
    val orders by MockRepository.orders.collectAsState()
    val profiles by MockRepository.employeeProfiles.collectAsState()

    val myProfileId = remember(profiles) {
        profiles.firstOrNull { it.userAccountId == MockRepository.currentUser.id }?.id
    }
    // Cascade scope. When the viewer has no profile mapping (e.g. the Chairman demo account)
    // the module permission that let them reach this screen is the governing check.
    val visibleDealerIds = remember(myProfileId) {
        myProfileId?.let { MockRepository.visibleDealerIds(it) }
    }
    val visibleRetailerIds = remember(myProfileId) {
        myProfileId?.let { MockRepository.visibleRetailerIds(it) }
    }

    val dealers = remember(allDealers, zone, visibleDealerIds) {
        allDealers.filter { !it.isDeleted && it.zone == zone && (visibleDealerIds == null || it.id in visibleDealerIds) }
    }
    val retailers = remember(allRetailers, zone, visibleRetailerIds) {
        allRetailers.filter { !it.isDeleted && it.market == zone && (visibleRetailerIds == null || it.id in visibleRetailerIds) }
    }
    val dealerIds = remember(dealers) { dealers.map { it.id }.toSet() }

    val zoneInvoices = remember(invoices, dealerIds) {
        invoices.filter { !it.isDeleted && it.dealerId in dealerIds }
    }
    val zoneCollections = remember(collections, dealerIds) {
        collections.filter { it.partyId in dealerIds }
    }

    val totalDue = dealers.sumOf { it.dueBalance } + retailers.sumOf { it.dueBalance }
    val overLimit = dealers.count { it.creditLimit > 0 && it.dueBalance > it.creditLimit }
    val today = LocalDate.now()

    // ---- 7-day series, built from real invoice/collection dates ----
    val days = remember { (6 downTo 0).map { today.minusDays(it.toLong()) } }
    val salesSeries = remember(zoneInvoices, days) {
        days.map { d -> zoneInvoices.filter { it.createdAt.toLocalDate() == d }.sumOf { it.total } }
    }
    val collectionSeries = remember(zoneCollections, days) {
        days.map { d -> zoneCollections.filter { it.createdAt.toLocalDate() == d }.sumOf { it.amount } }
    }
    val dayLabels = remember(days) { days.map { it.dayOfMonth.toString() } }

    // ---- product-wise sales, aggregated from real invoice line items ----
    // v113-158 — person asked for "koto percent product gese" (what % of a
    // product's sales this area represents) and product photos, alongside
    // what already existed here. Grouped by productId now (not name) so it
    // joins accurately against the real Product record for both the photo
    // and the company-wide total the percentage is computed against.
    val allProducts by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val companyWideProductValue = remember(invoices) {
        invoices.filter { !it.isDeleted }.flatMap { it.lineItems }
            .groupBy { it.productId }.mapValues { (_, lines) -> lines.sumOf { it.lineTotal } }
    }
    data class ZoneProductRow(val productId: String, val name: String, val photoUri: String?, val qty: Int, val value: Double, val companyPct: Double?)
    val productSales = remember(zoneInvoices, allProducts, companyWideProductValue) {
        zoneInvoices.flatMap { it.lineItems }
            .groupBy { it.productId }
            .map { (pid, lines) ->
                val value = lines.sumOf { it.lineTotal }
                val companyTotal = companyWideProductValue[pid] ?: 0.0
                ZoneProductRow(
                    productId = pid,
                    name = lines.first().name,
                    photoUri = allProducts.firstOrNull { it.id == pid }?.photoUri,
                    qty = lines.sumOf { it.qty },
                    value = value,
                    companyPct = if (companyTotal > 0) (value / companyTotal * 100) else null,
                )
            }
            .sortedByDescending { it.value }
            .take(8)
    }
    val productMax = productSales.maxOfOrNull { it.value } ?: 0.0

    Column(Modifier.fillMaxSize().background(DashBg)) {

        // ── header ──
        Column(
            Modifier.fillMaxWidth()
                .background(Brush.linearGradient(listOf(Color(0xFF2563EB), Color(0xFF1E3A8A))))
                .padding(horizontal = Space.md, vertical = 12.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text(zone, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Territory Overview", color = Color.White.copy(alpha = 0.82f), fontSize = 10.sp)
                }
                Icon(Icons.Filled.Map, null, tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(22.dp))
            }
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(Space.md)) {

            // ── KPIs ──
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Space.md)) {
                Box(Modifier.width(128.dp)) { com.abm.erp.core.MetricCard("Dealers", "${dealers.size}", valueColor = TextPrimary) }
                Box(Modifier.width(128.dp)) { com.abm.erp.core.MetricCard("Retailers", "${retailers.size}", valueColor = TextPrimary) }
                Box(Modifier.width(150.dp)) {
                    com.abm.erp.core.MetricCard(
                        "Total Due", "৳${"%,.0f".format(totalDue)}",
                        valueColor = if (totalDue > 0) StatusAmber else StatusGreen,
                    )
                }
                Box(Modifier.width(128.dp)) {
                    com.abm.erp.core.MetricCard(
                        "Over Limit", "$overLimit",
                        valueColor = if (overLimit > 0) StatusRed else StatusGreen,
                    )
                }
                Box(Modifier.width(150.dp)) {
                    com.abm.erp.core.MetricCard(
                        "Sales (7d)", "৳${"%,.0f".format(salesSeries.sum())}",
                        valueColor = DarazOrange,
                    )
                }
            }

            // ── sales graph ──
            com.abm.erp.core.SectionTitle("Sales Trend (7 days)")
            com.abm.erp.core.PremiumCard(padding = Space.md) {
                if (salesSeries.all { it == 0.0 }) {
                    Text("এই সময়ে কোনো বিক্রি নেই।", fontSize = 11.sp, color = TextSecondary)
                } else {
                    com.abm.erp.core.TrendLineChart(
                        labels = dayLabels,
                        values = salesSeries,
                        lineColor = StatusBlue,
                        modifier = Modifier.fillMaxWidth().height(120.dp),
                    )
                }
            }

            // ── collection graph ──
            com.abm.erp.core.SectionTitle("Collection Trend (7 days)")
            com.abm.erp.core.PremiumCard(padding = Space.md) {
                if (collectionSeries.all { it == 0.0 }) {
                    Text("এই সময়ে কোনো কালেকশন নেই।", fontSize = 11.sp, color = TextSecondary)
                } else {
                    com.abm.erp.core.TrendLineChart(
                        labels = dayLabels,
                        values = collectionSeries,
                        lineColor = StatusGreen,
                        modifier = Modifier.fillMaxWidth().height(120.dp),
                    )
                }
            }

            // ── product-wise sales ──
            com.abm.erp.core.SectionTitle("Product-wise Sales")
            if (productSales.isEmpty()) {
                com.abm.erp.core.PremiumCard(padding = Space.md) {
                    Text(
                        "এই এলাকার ইনভয়েসে কোনো পণ্যের লাইন পাওয়া যায়নি।",
                        fontSize = 11.sp, color = TextSecondary,
                    )
                }
            } else {
                com.abm.erp.core.PremiumCard(padding = Space.md) {
                    productSales.forEach { p ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            // Real company-uploaded photo when one exists; a neutral
                            // placeholder icon otherwise — never a fabricated image.
                            if (p.photoUri != null) {
                                coil.compose.AsyncImage(
                                    model = p.photoUri,
                                    contentDescription = p.name,
                                    modifier = Modifier.size(40.dp).background(Color(0xFFF0F1F4), RoundedCornerShape(8.dp)),
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                )
                            } else {
                                Box(
                                    Modifier.size(40.dp).background(Color(0xFFF0F1F4), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center,
                                ) { Icon(Icons.Filled.Inventory2, null, tint = TextSecondary, modifier = Modifier.size(18.dp)) }
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(p.name, fontSize = 11.sp, color = TextPrimary, maxLines = 1, modifier = Modifier.weight(1f))
                                    Text(
                                        "${p.qty} · ৳${"%,.0f".format(p.value)}",
                                        fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold,
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                // Bar length is share-of-top-seller within this zone, so the
                                // local ranking is readable at a glance.
                                Box(
                                    Modifier.fillMaxWidth().height(5.dp)
                                        .background(HairlineBorder, RoundedCornerShape(999.dp)),
                                ) {
                                    Box(
                                        Modifier
                                            .fillMaxWidth(if (productMax > 0) (p.value / productMax).toFloat().coerceIn(0f, 1f) else 0f)
                                            .fillMaxHeight()
                                            .background(DarazOrange, RoundedCornerShape(999.dp)),
                                    )
                                }
                                if (p.companyPct != null) {
                                    Spacer(Modifier.height(3.dp))
                                    Text(
                                        "কোম্পানির মোট ${p.name}-বিক্রির ${"%.1f".format(p.companyPct)}% এই এলাকায়",
                                        fontSize = 9.sp, color = TextSecondary,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ── dealers ──
            com.abm.erp.core.SectionTitle("Dealers (${dealers.size})")
            if (dealers.isEmpty()) {
                com.abm.erp.core.WorkspaceEmptyState("এই এলাকায় আপনার আওতায় কোনো ডিলার নেই।", iconVector = Icons.Filled.Business)
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(Space.sm)) {
                    dealers.forEach { d ->
                        com.abm.erp.core.EnterpriseListRow(
                            title = d.name,
                            subtitle = "Due ৳${"%,.0f".format(d.dueBalance)}",
                            meta = if (d.creditLimit > 0) "Limit ৳${"%,.0f".format(d.creditLimit)}" else null,
                            icon = Icons.Filled.Business,
                            accent = if (d.creditLimit > 0 && d.dueBalance > d.creditLimit) StatusRed else Color(0xFF2563EB),
                            onClick = { onNavigate("statement/DEALER/${d.id}") },
                        )
                    }
                }
            }

            // ── retailers ──
            com.abm.erp.core.SectionTitle("Retailers (${retailers.size})")
            if (retailers.isEmpty()) {
                com.abm.erp.core.WorkspaceEmptyState("এই এলাকায় আপনার আওতায় কোনো রিটেইলার নেই।", iconVector = Icons.Filled.Store)
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(Space.sm)) {
                    retailers.forEach { r ->
                        com.abm.erp.core.EnterpriseListRow(
                            title = r.name,
                            subtitle = "${r.retailerCode} · ${r.outletCategory}",
                            meta = "Due ৳${"%,.0f".format(r.dueBalance)}",
                            icon = Icons.Filled.Store,
                            accent = Color(0xFF12C2A9),
                            onClick = { onNavigate("statement/RETAILER/${r.id}") },
                        )
                    }
                }
            }

            // v113-143 — person asked the location result to show employees for that
            // area too, alongside the KPIs/sales/dealers/retailers already here.
            // Matched against the SAME place fields the rest of this screen filters on
            // (region/area/branch), since EmployeeProfile has no single "zone" field.
            val areaEmployees = remember(zone) {
                MockRepository.employeeProfiles.value.filter { e ->
                    !e.isDeleted && listOf(e.region, e.area, e.branch).any { it.isNotBlank() && it.equals(zone, ignoreCase = true) }
                }
            }
            com.abm.erp.core.SectionTitle("Employees (${areaEmployees.size})")
            if (areaEmployees.isEmpty()) {
                com.abm.erp.core.WorkspaceEmptyState("এই এলাকায় assign করা কোনো কর্মী পাওয়া যায়নি।", iconVector = Icons.Filled.Person)
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(Space.sm)) {
                    areaEmployees.forEach { e ->
                        com.abm.erp.core.EnterpriseListRow(
                            title = e.fullName,
                            subtitle = "${e.designation.ifBlank { e.role.name }} · ${e.department.ifBlank { "—" }}",
                            meta = if (e.hasActiveAccess) "Active" else "Inactive",
                            icon = Icons.Filled.Person,
                            accent = Color(0xFFDB2777),
                            onClick = { onNavigate("hr_module?key=employees") },
                        )
                    }
                }
            }

            Spacer(Modifier.height(Space.xxl))
        }
    }
}
