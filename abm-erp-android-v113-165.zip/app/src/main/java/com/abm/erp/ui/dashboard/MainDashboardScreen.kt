package com.abm.erp.ui.dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.abm.erp.core.GlassCard
import com.abm.erp.data.*
import com.abm.erp.theme.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

class MainDashboardViewModel : ViewModel() {
    val currentUserFlow = MockRepository.currentUserFlow
    val vacantEmployeeIds = MockRepository.vacantEmployeeIds
    val demoAccountsFlow = MockRepository.demoAccountsFlow
    val syncStatus = MockRepository.syncStatus
    val chairmanNotices = FirebaseSync.chairmanNotices
    fun uploadChairmanNotice(slot: Int, uri: android.net.Uri, caption: String) = FirebaseSync.uploadChairmanNotice(slot, uri, caption)

    // ---- Module 1: Executive Summary / Company Performance Scorecard ----
    val dealers = MockRepository.dealers
    val retailers = MockRepository.retailers
    val stockLevels = InventoryRepository.stockLevels
    val approvals = MockRepository.approvals
    val salesInvoices = MockRepository.salesInvoices
    val partyCollections = MockRepository.partyCollections
    val productionOrders = MockRepository.productionOrders
    val visitLogs = MockRepository.visitLogs
    val vehicleLocationPings = MockRepository.vehicleLocationPings
    val tasks = MockRepository.tasks
    val followUps = com.abm.erp.data.CrmRepository.followUps
    val payroll = MockRepository.payroll
    val products = com.abm.erp.data.InventoryRepository.products
    val notifications = MockRepository.notifications
}

@Composable
fun MainDashboardScreen(onNavigate: (String) -> Unit, vm: MainDashboardViewModel = viewModel()) {
    val appUser by vm.currentUserFlow.collectAsState()
    val vacantIds by vm.vacantEmployeeIds.collectAsState()
    val widgetContext = androidx.compose.ui.platform.LocalContext.current
    var hiddenWidgets by remember { mutableStateOf(com.abm.erp.data.getHiddenDashboardWidgets(widgetContext)) }
    var showCustomize by remember { mutableStateOf(false) }
    val allWidgetNames = listOf("Sales Trend", "Collection Trend", "Outstanding Trend", "Inventory Value", "Purchase Trend", "Production Trend", "Cash Flow & Efficiency", "Smart Alerts", "Recent Activities", "Top Products", "Quick Actions")
    fun isWidgetVisible(name: String) = name !in hiddenWidgets
    fun toggleWidget(name: String) {
        hiddenWidgets = if (name in hiddenWidgets) hiddenWidgets - name else hiddenWidgets + name
        com.abm.erp.data.saveHiddenDashboardWidgets(widgetContext, hiddenWidgets)
    }

    // Local override so the role-switcher (a testing convenience, same as in
    // the JSX prototype) can preview other designations without logging out.
    var employeeId by remember { mutableStateOf(appUser.employeeId) }
    LaunchedEffect(appUser.employeeId) { employeeId = appUser.employeeId }

    val employee = remember(employeeId) {
        EMPLOYEE_DIRECTORY.firstOrNull { it.id == employeeId }
            ?: EMPLOYEE_DIRECTORY.first { it.role == UserRole.CHAIRMAN }
    }
    val visibleModules = remember(employee.role) { visibleModulesFor(employee.role) }
    val coveredEmployees = remember(employee.id, vacantIds) {
        EMPLOYEE_DIRECTORY.filter { vacantIds.contains(it.id) && findCoveringEmployee(it, vacantIds)?.id == employee.id }
    }

    // ---- Auto-lock: নিষ্ক্রিয়তায় ড্যাশবোর্ড লক হবে (পুরোপুরি logout না, শুধু
    // আবার PIN দিতে হবে)। Chairman/MD-এর জন্য সময় কম — বেশি অ্যাক্সেস মানে
    // বেশি কড়াকড়ি। এখানে টেস্ট করার সুবিধার জন্য সময়টা তুলনামূলক ছোট রাখা
    // হয়েছে — production-এ এই কনস্ট্যান্ট দুটো বাড়িয়ে দিলেই যথেষ্ট। ----
    var dashboardLocked by remember { mutableStateOf(false) }
    var lockPin by remember { mutableStateOf("") }
    var lockError by remember { mutableStateOf<String?>(null) }
    var lastInteractionAt by remember { mutableStateOf(System.currentTimeMillis()) }
    val idleTimeoutMs = if (employee.role == UserRole.CHAIRMAN || employee.role == UserRole.MD) 30_000L else 60_000L
    val demoAccountsForLock by vm.demoAccountsFlow.collectAsState()

    LaunchedEffect(lastInteractionAt, dashboardLocked) {
        if (!dashboardLocked) {
            kotlinx.coroutines.delay(idleTimeoutMs)
            dashboardLocked = true
        }
    }

    fun dashLockPress(k: String) {
        if (k == "del") { lockPin = lockPin.dropLast(1); return }
        if (lockPin.length >= 5) return
        val next = lockPin + k
        lockPin = next
        if (next.length == 5) {
            val matches = demoAccountsForLock.entries.any { (pin, user) -> pin == next && user.employeeId == employee.id }
            if (matches) { dashboardLocked = false; lockPin = ""; lockError = null; lastInteractionAt = System.currentTimeMillis() }
            else { lockError = "Incorrect PIN."; lockPin = "" }
        }
    }

    // ---- Post-login Briefing: প্রথমবার dashboard-এ এসেই দিনের সংক্ষিপ্ত সারাংশ ----
    var showBriefing by remember { mutableStateOf(true) }

    var showEmployeePicker by remember { mutableStateOf(false) }
    var toastMessage by remember { mutableStateOf<String?>(null) }
    val chairmanNotices by vm.chairmanNotices.collectAsState()
    var uploadingSlot by remember { mutableStateOf<Int?>(null) }
    val noticePickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent(),
    ) { uri -> val slot = uploadingSlot; if (uri != null && slot != null) vm.uploadChairmanNotice(slot, uri, "Company announcement") }

    LaunchedEffect(toastMessage) {
        if (toastMessage != null) {
            kotlinx.coroutines.delay(2200)
            toastMessage = null
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                while (true) {
                    awaitPointerEventScope { awaitPointerEvent() }
                    lastInteractionAt = System.currentTimeMillis()
                }
            },
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // ---- header: sky-blue gradient banner with gold ABM badge (matches the JSX "Active Portal" header) ----
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(SkyTop, Sky)))
                    .padding(16.dp),
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(44.dp)
                                .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(GoldBright, Gold, GoldDeep)), androidx.compose.foundation.shape.CircleShape),
                            contentAlignment = Alignment.Center,
                        ) { Text("ABM", color = Color(0xFF241A08), fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(employee.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("${roleLabel(employee.role)} · ${employee.geoLabel}", style = MaterialTheme.typography.labelSmall, color = Color(0xFFE4EEF6))
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SyncStatusBadge(vm)
                        Spacer(Modifier.width(8.dp))
                        TextButton(onClick = { showEmployeePicker = true }) { Text("Switch (test)", color = Color.White) }
                    }
                }
            }

            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            // ---- Enterprise Workspace: at-a-glance status strip (GPS, Notifications, Approvals) ----
            val notificationsList by vm.notifications.collectAsState()
            val unreadNotifCount = notificationsList.count { !it.isRead }
            val approvalsForStrip by vm.approvals.collectAsState()
            val pendingApprovalsForStrip = approvalsForStrip.count { it.status == ApprovalStatus.PENDING }
            DashboardStatusStrip(employee.geoLabel, unreadNotifCount, pendingApprovalsForStrip, onNavigate)

            DashboardSectionLabel("Overview")

            // ---- vacancy-cascade banner: only visible if this person is genuinely covering someone ----
            AnimatedVisibility(visible = coveredEmployees.isNotEmpty()) {
                GlassCard(borderColor = WarningAmber.copy(alpha = 0.6f), modifier = Modifier.fillMaxWidth()) {
                    Text("⚠ Covering: " + coveredEmployees.joinToString("; ") { "${it.name} (${roleLabel(it.role)}, ${it.geoLabel})" },
                        style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = WarningAmber)
                    Spacer(Modifier.height(2.dp))
                    Text("These positions are currently unfilled — their duties temporarily route to you so operations don't stop.",
                        style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }

            // ---- personal target vs achievement — the screen's single hero number ----
            val heroAchieved = remember(employee.name) { MockRepository.realAchievedSalesThisMonth(employee.name) }
            val heroTarget = remember(employee.name) { MockRepository.realTargetFor(employee.name) }
            com.abm.erp.core.HeroCard(
                label = "My Target — ${employee.geoLabel}",
                value = if (heroTarget != null) "৳${"%,.0f".format(heroAchieved)} / ${"%,.0f".format(heroTarget)}"
                        else "৳${"%,.0f".format(heroAchieved)}",
                caption = if (heroTarget != null) {
                    "${"%.0f".format((heroAchieved / heroTarget * 100).coerceIn(0.0, 999.0))}% achieved this month"
                } else "This month · target not set for this employee",
                icon = Icons.Filled.TrackChanges,
            )
            Spacer(Modifier.height(com.abm.erp.core.Space.lg))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Target detail", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                Spacer(Modifier.height(4.dp))
                // v86 fix: employee.achieved/target were hardcoded demo
                // numbers (identical for every SR/TSM/ASM regardless of
                // district). Achieved is now real month-to-date sales by
                // this employee; target comes from a real PayrollLine when
                // one exists, otherwise shown as unavailable rather than
                // fabricated.
                val realAchieved = remember(employee.name) { MockRepository.realAchievedSalesThisMonth(employee.name) }
                val realTarget = remember(employee.name) { MockRepository.realTargetFor(employee.name) }
                if (realTarget != null) {
                    Text("৳${"%,.0f".format(realAchieved)} / ${"%,.0f".format(realTarget)}",
                        style = MaterialTheme.typography.headlineSmall, color = Gold, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    val pct = (realAchieved / realTarget).toFloat().coerceIn(0f, 1f)
                    LinearProgressIndicator(progress = pct, modifier = Modifier.fillMaxWidth().height(6.dp), color = Gold, trackColor = Color(0xFFEEF1F5))
                } else {
                    Text("৳${"%,.0f".format(realAchieved)} (this month)", style = MaterialTheme.typography.headlineSmall, color = Gold, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("Target not set for this employee.", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                Spacer(Modifier.height(6.dp))
                val lastMonthStart = java.time.LocalDateTime.now().minusMonths(1).withDayOfMonth(1).toLocalDate().atStartOfDay()
                val thisMonthStart = java.time.LocalDateTime.now().withDayOfMonth(1).toLocalDate().atStartOfDay()
                val lastMonthSales = remember(employee.name) {
                    MockRepository.salesInvoices.value.filter { !it.isDeleted && it.createdBy == employee.name && it.createdAt.isAfter(lastMonthStart) && it.createdAt.isBefore(thisMonthStart) }.sumOf { it.total }
                }
                val insightText = if (lastMonthSales > 0) {
                    val changePct = ((realAchieved - lastMonthSales) / lastMonthSales * 100)
                    "vs last month: ${if (changePct >= 0) "+" else ""}${"%.0f".format(changePct)}%"
                } else "Last month: no recorded sales for comparison."
                Text(insightText, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }

            // ---- Chairman's Notice: 3 independent slots, Chairman uploads each, everyone else views read-only ----
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("📢 Chairman's Notice", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    for (slot in 0..2) {
                        val notice = chairmanNotices.getOrNull(slot)
                        Column(
                            Modifier.width(220.dp)
                                .background(Color(0xFFF7F8FA), androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                                .padding(10.dp),
                        ) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("স্লট ${slot + 1}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = TextSecondary)
                                if (employee.role == UserRole.CHAIRMAN) {
                                    TextButton(onClick = { uploadingSlot = slot; noticePickerLauncher.launch("image/*") }) {
                                        Text(if (notice != null) "Change" else "Upload", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                            if (notice != null) {
                                Spacer(Modifier.height(4.dp))
                                coil.compose.AsyncImage(
                                    model = notice.imageUrl,
                                    contentDescription = notice.caption,
                                    modifier = Modifier.fillMaxWidth().height(130.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(6.dp)),
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(notice.caption, style = MaterialTheme.typography.labelSmall, color = TextSecondary, maxLines = 2)
                            } else {
                                Spacer(Modifier.height(4.dp))
                                Box(Modifier.fillMaxWidth().height(130.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        if (employee.role == UserRole.CHAIRMAN) "খালি — Upload করুন" else "কোনো নোটিশ নেই",
                                        style = MaterialTheme.typography.labelSmall, color = TextSecondary, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ---- Module 1: Executive Summary / Company Performance Scorecard ----
            // AGM+ tier only (executive-level aggregate view) — matches how
            // "market"/"report" tiles are already AGM+ scoped elsewhere.
            if (employee.role.ordinal >= UserRole.AGM.ordinal) {
                DashboardSectionLabel("Executive Summary")
                val dealersList by vm.dealers.collectAsState()
                val retailersList by vm.retailers.collectAsState()
                val stockLevelsList by vm.stockLevels.collectAsState()
                val approvalsList by vm.approvals.collectAsState()
                val invoicesList by vm.salesInvoices.collectAsState()
                val totalDue = dealersList.sumOf { it.dueBalance } + retailersList.sumOf { it.dueBalance }
                val totalSales90d = dealersList.sumOf { it.salesLast90Days }
                val lowStockCount = stockLevelsList.count { it.isLowStock }
                val pendingApprovals = approvalsList.count { it.status == ApprovalStatus.PENDING }
                val invoiceCount = invoicesList.count { !it.isDeleted }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Executive Summary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    com.abm.erp.core.UniversalActionMenu(
                        moduleReference = "Dashboard", entityId = "executive-summary", entityLabel = "Executive Summary",
                        shareText = "Executive Summary — ${java.time.LocalDate.now()}\nTotal Due: ৳${"%,.0f".format(totalDue)}\nSales (90d): ৳${"%,.0f".format(totalSales90d)}\nLow Stock: $lowStockCount\nPending Approvals: $pendingApprovals\nInvoices: $invoiceCount",
                        csvHeader = "Metric,Value",
                        csvRow = "TotalDue,$totalDue\nSales90d,$totalSales90d\nLowStock,$lowStockCount\nPendingApprovals,$pendingApprovals\nInvoices,$invoiceCount",
                    )
                }
                Spacer(Modifier.height(8.dp))
                // Blueprint §22 — 2-column KPI grid on white cards. Replaces the previous
                // dark-gradient panel, which was a leftover from the old dark theme and
                // fought the bright-white direction the rest of the app now uses.
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    DashboardKpiCard("Sales (90d)", totalSales90d, { "৳${"%,.0f".format(it)}" }, com.abm.erp.theme.DarazOrange, Modifier.weight(1f))
                    DashboardKpiCard("Total Due", totalDue, { "৳${"%,.0f".format(it)}" }, if (totalDue > 0) WarningAmber else SuccessGreen, Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    DashboardKpiCard("Low Stock", lowStockCount.toDouble(), { "${it.toInt()}" }, com.abm.erp.core.problemColor(lowStockCount), Modifier.weight(1f))
                    DashboardKpiCard("Pending Approvals", pendingApprovals.toDouble(), { "${it.toInt()}" }, com.abm.erp.core.attentionColor(pendingApprovals), Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    DashboardKpiCard("Invoices", invoiceCount.toDouble(), { "${it.toInt()}" }, TextPrimary, Modifier.weight(1f))
                    Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(16.dp))

                // ---- Live Business Feed: Collection / Production / Top Dealers / GPS Team / Employee Activity ----
                DashboardSectionLabel("Performance & Trends")
                val collectionsList by vm.partyCollections.collectAsState()
                val productionList by vm.productionOrders.collectAsState()
                val visitsList by vm.visitLogs.collectAsState()
                val vehiclePings by vm.vehicleLocationPings.collectAsState()
                var periodSelection by remember { mutableStateOf(0) } // 0=Today, 1=Week, 2=Month, 3=Custom
                var customStart by remember { mutableStateOf<java.time.LocalDate?>(null) }
                var customEnd by remember { mutableStateOf<java.time.LocalDate?>(null) }
                val periodStart = when (periodSelection) {
                    1 -> java.time.LocalDateTime.now().minusDays(7)
                    2 -> java.time.LocalDateTime.now().minusDays(30)
                    3 -> (customStart ?: java.time.LocalDate.now()).atStartOfDay()
                    else -> java.time.LocalDateTime.now().toLocalDate().atStartOfDay()
                }
                val periodEndExclusive = if (periodSelection == 3 && customEnd != null) customEnd!!.plusDays(1).atStartOfDay() else null
                val periodLabel = when (periodSelection) { 1 -> "This Week"; 2 -> "This Month"; 3 -> "Custom (${customStart ?: "…"} – ${customEnd ?: "…"})"; else -> "Today" }
                val periodCollections = collectionsList.filter { it.createdAt.isAfter(periodStart) && (periodEndExclusive == null || it.createdAt.isBefore(periodEndExclusive)) }
                // Production has no per-day timestamp on the domain model (ProductionOrder tracks scheduledDate, not a created-at we can safely filter by period without misrepresenting it) — so this KPI stays a live current-status count regardless of period, and is labelled honestly rather than pretending to be period-filtered.
                val currentProduction = productionList.filter { it.status == "IN_PROGRESS" || it.status == "COMPLETED" }
                val periodVisits = visitsList.filter { it.checkInAt.isAfter(periodStart) && (periodEndExclusive == null || it.checkInAt.isBefore(periodEndExclusive)) }
                val topDealers = dealersList.sortedByDescending { it.salesLast90Days }.take(5)

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = periodSelection == 0, onClick = { periodSelection = 0 }, label = { Text("Today") })
                    FilterChip(selected = periodSelection == 1, onClick = { periodSelection = 1 }, label = { Text("This Week") })
                    FilterChip(selected = periodSelection == 2, onClick = { periodSelection = 2 }, label = { Text("This Month") })
                    val dateRangeContext = androidx.compose.ui.platform.LocalContext.current
                    FilterChip(
                        selected = periodSelection == 3,
                        onClick = {
                            val today = java.time.LocalDate.now()
                            android.app.DatePickerDialog(dateRangeContext, { _, y1, m1, d1 ->
                                val start = java.time.LocalDate.of(y1, m1 + 1, d1)
                                android.app.DatePickerDialog(dateRangeContext, { _, y2, m2, d2 ->
                                    customStart = start
                                    customEnd = java.time.LocalDate.of(y2, m2 + 1, d2)
                                    periodSelection = 3
                                }, today.year, today.monthValue - 1, today.dayOfMonth).show()
                            }, today.year, today.monthValue - 1, today.dayOfMonth).show()
                        },
                        label = { Text("Custom") },
                    )
                }
                Spacer(Modifier.height(8.dp))
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("$periodLabel's Performance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Collection", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("৳${"%,.0f".format(periodCollections.sumOf { it.amount })}", fontWeight = FontWeight.Bold, color = SuccessGreen)
                        }
                        Column {
                            Text("Production (live status)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${currentProduction.size} orders", fontWeight = FontWeight.Bold, color = ElectricCyan)
                        }
                        Column {
                            Text("Field Visits", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${periodVisits.size}", fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))

                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Top Dealers (90-day sales)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    topDealers.forEach { d ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(d.name, style = MaterialTheme.typography.bodySmall)
                            Text("৳${"%,.0f".format(d.salesLast90Days)}", style = MaterialTheme.typography.bodySmall, color = ElectricCyan)
                        }
                    }
                    if (topDealers.isEmpty()) Text("এখনো কোনো dealer sales data নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(16.dp))

                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("GPS Team Summary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Outlet visits ($periodLabel)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${periodVisits.size}", fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                        Column {
                            Text("Active vehicles pinged", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${vehiclePings.map { it.vehicleId }.distinct().size}", fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                        Column {
                            Text("Employees active today", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${periodVisits.map { it.employeeId }.distinct().size}", fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))

                // ---- Sales & Collection Trend (real, last 7 days) ----
                val allInvoicesForTrend by vm.salesInvoices.collectAsState()
                val allCollectionsForTrend by vm.partyCollections.collectAsState()
                val trendDays = (6 downTo 0).map { java.time.LocalDate.now().minusDays(it.toLong()) }
                val salesTrendValues = trendDays.map { day -> allInvoicesForTrend.filter { !it.isDeleted && it.createdAt.toLocalDate() == day }.sumOf { it.total } }
                val collectionTrendValues = trendDays.map { day -> allCollectionsForTrend.filter { it.createdAt.toLocalDate() == day }.sumOf { it.amount } }
                val trendLabels = trendDays.map { it.dayOfMonth.toString() }
                val prevDays = (13 downTo 7).map { java.time.LocalDate.now().minusDays(it.toLong()) }
                val prevSalesTotal = prevDays.sumOf { day -> allInvoicesForTrend.filter { !it.isDeleted && it.createdAt.toLocalDate() == day }.sumOf { it.total } }
                val prevCollectionTotal = prevDays.sumOf { day -> allCollectionsForTrend.filter { it.createdAt.toLocalDate() == day }.sumOf { it.amount } }
                val currentSalesTotal = salesTrendValues.sum()
                val currentCollectionTotal = collectionTrendValues.sum()
                val salesChangePct = if (prevSalesTotal > 0) ((currentSalesTotal - prevSalesTotal) / prevSalesTotal * 100) else null
                val collectionChangePct = if (prevCollectionTotal > 0) ((currentCollectionTotal - prevCollectionTotal) / prevCollectionTotal * 100) else null
                if (isWidgetVisible("Sales Trend")) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Sales Trend (7 days)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    com.abm.erp.core.TrendLineChart(labels = trendLabels, values = salesTrendValues, lineColor = ElectricCyan)
                    if (salesChangePct != null) {
                        Spacer(Modifier.height(4.dp))
                        Text("vs previous 7 days: ${if (salesChangePct >= 0) "+" else ""}${"%.0f".format(salesChangePct)}%", style = MaterialTheme.typography.labelSmall, color = if (salesChangePct >= 0) SuccessGreen else DangerRed)
                    }
                }
                Spacer(Modifier.height(16.dp))
                }
                if (isWidgetVisible("Collection Trend")) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Collection Trend (7 days)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    com.abm.erp.core.TrendLineChart(labels = trendLabels, values = collectionTrendValues, lineColor = SuccessGreen)
                    if (collectionChangePct != null) {
                        Spacer(Modifier.height(4.dp))
                        Text("vs previous 7 days: ${if (collectionChangePct >= 0) "+" else ""}${"%.0f".format(collectionChangePct)}%", style = MaterialTheme.typography.labelSmall, color = if (collectionChangePct >= 0) SuccessGreen else DangerRed)
                    }
                }
                }
                Spacer(Modifier.height(16.dp))

                // ---- Outstanding Trend (real dealer due, sampled over last 7 days from ledger postings where available; falls back to current total if no dated history) ----
                val outstandingTrendValues = trendDays.map { day -> allInvoicesForTrend.filter { !it.isDeleted && it.createdAt.toLocalDate() <= day }.sumOf { it.total } - allCollectionsForTrend.filter { it.createdAt.toLocalDate() <= day }.sumOf { it.amount } }
                if (isWidgetVisible("Outstanding Trend")) {
                GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("reports") }) {
                    Text("Outstanding Trend (7 days)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    com.abm.erp.core.TrendLineChart(labels = trendLabels, values = outstandingTrendValues.map { it.coerceAtLeast(0.0) }, lineColor = WarningAmber)
                }
                Spacer(Modifier.height(16.dp))
                }

                // ---- Inventory Trend (real stock-value per day, from movement history) ----
                val productsForValue by vm.products.collectAsState()
                val stockLevelsForValue by vm.stockLevels.collectAsState()
                val currentStockValue = stockLevelsForValue.sumOf { level -> (productsForValue.firstOrNull { it.id == level.productId }?.defaultUnitPrice ?: 0.0) * level.quantityOnHand }
                if (isWidgetVisible("Inventory Value")) {
                GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("inventory") }) {
                    Text("Inventory Value", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("৳${"%,.0f".format(currentStockValue)}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = ElectricCyan)
                    Text("বর্তমান মজুদ মূল্য (live) — দিনভিত্তিক ইতিহাস ট্র্যাক করা হয় না বলে trend chart না দেখিয়ে honestly শুধু current value দেখানো হলো।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                Spacer(Modifier.height(16.dp))
                }

                // ---- Purchase Trend (real PO value per day) ----
                val purchaseOrdersForTrend by com.abm.erp.data.PurchaseRepository.purchaseOrders.collectAsState()
                val purchaseTrendValues = trendDays.map { day -> purchaseOrdersForTrend.filter { it.createdAt.toLocalDate() == day }.sumOf { it.subTotal } }
                if (isWidgetVisible("Purchase Trend")) {
                GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("purchase") }) {
                    Text("Purchase Trend (7 days)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    com.abm.erp.core.TrendLineChart(labels = trendLabels, values = purchaseTrendValues, lineColor = Sky)
                }
                Spacer(Modifier.height(16.dp))
                }

                // ---- Production Trend (real completed-order count per day) ----
                val productionOrdersForTrend by vm.productionOrders.collectAsState()
                val productionTrendValues = trendDays.map { day -> productionOrdersForTrend.count { it.scheduledDate.toLocalDate() == day }.toDouble() }
                val delayedProdOrders = productionOrdersForTrend.filter { it.scheduledDate.toLocalDate().isBefore(java.time.LocalDate.now()) && it.status != "COMPLETED" && it.status != "CANCELLED" }
                if (isWidgetVisible("Production Trend")) {
                GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("production") }) {
                    Text("Production Trend (7 days)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    com.abm.erp.core.TrendLineChart(labels = trendLabels, values = productionTrendValues, lineColor = SuccessGreen)
                    if (delayedProdOrders.isNotEmpty()) {
                        Spacer(Modifier.height(4.dp))
                        Text("⚠ ${delayedProdOrders.size} order(s) delayed", color = DangerRed, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(16.dp))
                }

                // ---- Cash Flow Summary + Collection Efficiency + Target vs Achievement (all real data) ----
                val vouchersForCashFlow by com.abm.erp.data.AccountsRepository.vouchers.collectAsState()
                val cashIn = vouchersForCashFlow.flatMap { it.lines }.filter { it.debit > 0 && (it.accountName.contains("cash", true) || it.accountName.contains("bank", true)) }.sumOf { it.debit }
                val cashOut = vouchersForCashFlow.flatMap { it.lines }.filter { it.credit > 0 && (it.accountName.contains("cash", true) || it.accountName.contains("bank", true)) }.sumOf { it.credit }
                val totalInvoicedForEff = allInvoicesForTrend.filter { !it.isDeleted }.sumOf { it.total }
                val totalCollectedForEff = allCollectionsForTrend.sumOf { it.amount }
                val collectionEfficiencyPct = if (totalInvoicedForEff > 0) (totalCollectedForEff / totalInvoicedForEff * 100) else null
                val payrollForDashTarget by vm.payroll.collectAsState()
                val dashTarget = payrollForDashTarget.sumOf { it.targetAmount }
                val dashAchieved = payrollForDashTarget.sumOf { it.achievedAmount }
                if (isWidgetVisible("Cash Flow & Efficiency")) {
                GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("ledger") }) {
                    Text("Cash Flow & Efficiency", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Column { Text("Cash In", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(cashIn)}", fontWeight = FontWeight.Bold, color = SuccessGreen) }
                        Column { Text("Cash Out", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(cashOut)}", fontWeight = FontWeight.Bold, color = DangerRed) }
                        Column {
                            Text("Collection Efficiency", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text(collectionEfficiencyPct?.let { "${"%.0f".format(it)}%" } ?: "N/A", fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Target vs Achievement", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text(if (dashTarget > 0) "${"%.0f".format(dashAchieved / dashTarget * 100)}%" else "N/A", fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                }

                // ---- Recent Activities + Smart Alerts (real data) ----
                DashboardSectionLabel("Alerts & Activity")
                val recentInvoicesList = allInvoicesForTrend.filter { !it.isDeleted }.sortedByDescending { it.createdAt }.take(5)
                var smartBusinessAlerts by remember { mutableStateOf<List<MockRepository.SmartBusinessAlert>>(emptyList()) }
                LaunchedEffect(dealersList, stockLevelsList) { smartBusinessAlerts = MockRepository.computeSmartBusinessAlerts() }
                if (isWidgetVisible("Smart Alerts")) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Smart Alerts", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    if (smartBusinessAlerts.isEmpty()) {
                        Text("এই মুহূর্তে কোনো সতর্কতা নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                    } else {
                        smartBusinessAlerts.forEach { a ->
                            Text(
                                "${if (a.severity == MockRepository.SmartAlertSeverity.CRITICAL) "🔴" else "⚠"} ${a.message}",
                                color = if (a.severity == MockRepository.SmartAlertSeverity.CRITICAL) DangerRed else WarningAmber,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                }

                Spacer(Modifier.height(16.dp))
                if (isWidgetVisible("Recent Activities")) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Recent Activities", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    if (recentInvoicesList.isEmpty()) {
                        Text("এখনো কোনো কার্যক্রম নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                    } else {
                        recentInvoicesList.forEach { inv -> Text("Invoice ${inv.invoiceNo} — ${inv.dealerName} (৳${"%,.0f".format(inv.total)})", style = MaterialTheme.typography.bodySmall) }
                    }
                }
                Spacer(Modifier.height(16.dp))
                }

                // ---- Today's Priority: real pending tasks, approvals, overdue follow-ups ----
                val tasksList by vm.tasks.collectAsState()
                val followUpsList by vm.followUps.collectAsState()
                val pendingTasks = tasksList.filter { !it.isDeleted && it.status != com.abm.erp.data.TaskStatus.COMPLETED && it.status != com.abm.erp.data.TaskStatus.CANCELLED }
                val overdueFollowUps = followUpsList.filter { !it.done && it.dueDate.isBefore(java.time.LocalDateTime.now()) }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Today's Priority", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Pending Tasks", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${pendingTasks.size}", fontWeight = FontWeight.Bold, color = if (pendingTasks.isNotEmpty()) WarningAmber else SuccessGreen)
                        }
                        Column {
                            Text("Pending Approvals", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("$pendingApprovals", fontWeight = FontWeight.Bold, color = if (pendingApprovals > 0) WarningAmber else SuccessGreen)
                        }
                        Column {
                            Text("Overdue Follow-ups", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text("${overdueFollowUps.size}", fontWeight = FontWeight.Bold, color = if (overdueFollowUps.isNotEmpty()) DangerRed else SuccessGreen)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))

                // ---- Low-performing dealer warning: active dealers with zero 90-day sales (genuinely different from "inactiveDealers" wording — this is a dashboard-level warning card, not the CRM module's own list) ----
                val lowPerformers = dealersList.filter { it.isActive && !it.isDeleted && it.salesLast90Days <= 0.0 }
                if (lowPerformers.isNotEmpty()) {
                    GlassCard(modifier = Modifier.fillMaxWidth(), borderColor = WarningAmber.copy(alpha = 0.6f)) {
                        Text("⚠ Low-Performing Dealers (${lowPerformers.size})", color = WarningAmber, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(6.dp))
                        lowPerformers.take(5).forEach { d -> Text("${d.name} — ${d.zone}: কোনো বিক্রি নেই গত ৯০ দিনে", style = MaterialTheme.typography.bodySmall, color = TextSecondary) }
                    }
                    Spacer(Modifier.height(16.dp))
                }

                // ---- Top Products: aggregated from real SalesInvoice line items ----
                DashboardSectionLabel("Insights")
                val invoicesForProducts by vm.salesInvoices.collectAsState()
                val topProducts = remember(invoicesForProducts) {
                    invoicesForProducts.filter { !it.isDeleted }
                        .flatMap { it.lineItems }
                        .groupBy { it.name }
                        .mapValues { (_, items) -> items.sumOf { it.qty } }
                        .entries.sortedByDescending { it.value }.take(5)
                }
                if (isWidgetVisible("Top Products")) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Top Products (by quantity sold)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    if (topProducts.isEmpty()) {
                        Text("এখনো কোনো invoice line-item data নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                    } else {
                        topProducts.forEach { (name, qty) ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(name, style = MaterialTheme.typography.bodySmall)
                                Text("$qty units", style = MaterialTheme.typography.bodySmall, color = ElectricCyan)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                }

                // ---- v113-74 — the six mother modules. Eventually the Home Dashboard
                // shows ONLY these six and nothing else. DMS and RMS are built; the other
                // four are not, so the old dashboard content below is left in place for
                // now rather than stranding every other screen. Removing it is the last
                // step, once HR/FMS/Chairman/AI exist. ----
                MotherModuleGrid(onNavigate)
                Spacer(Modifier.height(16.dp))

                // ---- Quick Actions: real navigation routes, no dead callbacks ----
                DashboardSectionLabel("Quick Actions")
                if (isWidgetVisible("Quick Actions")) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Quick Actions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        AssistChip(onClick = { onNavigate("universal_scanner") }, label = { Text("📷 Scan QR") })
                        AssistChip(onClick = { onNavigate("expenses") }, label = { Text("💰 Expenses") })
                        AssistChip(onClick = { onNavigate("sales") }, label = { Text("Sales / New Invoice") })
                        AssistChip(onClick = { onNavigate("dealers") }, label = { Text("Dealers") })
                        // Decision 2 (v113-72) — the "Approvals" shortcut is gone on purpose.
                        // Approvals are now actioned inside the module that owns them, so a
                        // cross-cutting shortcut here would rebuild the inbox that was removed.
                        AssistChip(onClick = { onNavigate("tasks") }, label = { Text("Tasks") })
                        AssistChip(onClick = { onNavigate("reports") }, label = { Text("Reports") })
                        if (employee.role == UserRole.CHAIRMAN) {
                            AssistChip(onClick = { onNavigate("chairman_hub") }, label = { Text("👑 Chairman Hub") })
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                }
                TextButton(onClick = { showCustomize = true }, modifier = Modifier.fillMaxWidth()) { Text("⚙ Customize Dashboard") }
            }
            if (showCustomize) {
                androidx.compose.ui.window.Dialog(onDismissRequest = { showCustomize = false }) {
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(16.dp).heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
                            Text("Customize Dashboard", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(10.dp))
                            allWidgetNames.forEach { name ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text(name)
                                    androidx.compose.material3.Switch(checked = isWidgetVisible(name), onCheckedChange = { toggleWidget(name) })
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            TextButton(onClick = { showCustomize = false }) { Text("Close") }
                        }
                    }
                }
            }

            // ---- MODULE SUITES ----
            // Replaces the flat 21-tile grid. Each suite is the complete toolset for one
            // business segment; tapping one opens its own home, and every function inside
            // opens the existing screen at the right tab. Filtered by visibleSuitesFor(),
            // which derives from the same visibleModulesFor() rules as before — so this
            // changes where you tap, never what you are allowed to reach.
            com.abm.erp.core.SectionTitle("Modules")
            val suites = remember(employee.role) { com.abm.erp.data.visibleSuitesFor(employee.role) }
            Column(verticalArrangement = Arrangement.spacedBy(com.abm.erp.core.Space.md)) {
                suites.forEach { suite ->
                    com.abm.erp.core.PremiumCard(
                        modifier = Modifier.fillMaxWidth(),
                        padding = 14.dp,
                        onClick = { onNavigate("suite/${suite.key}") },
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            com.abm.erp.core.IconChip(
                                icon = suite.icon,
                                accent = Color(suite.colorStart),
                                size = 46,
                            )
                            Spacer(Modifier.width(com.abm.erp.core.Space.md))
                            Column(Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(suite.name, fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 14.sp)
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        "${suite.functionCount} functions",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(suite.colorStart),
                                        modifier = Modifier
                                            .background(Color(suite.colorStart).copy(alpha = 0.12f), RoundedCornerShape(999.dp))
                                            .padding(horizontal = 7.dp, vertical = 2.dp),
                                    )
                                }
                                Text(suite.fullName, fontSize = 11.sp, color = TextSecondary)
                                Text(suite.tagline, fontSize = 10.sp, color = TextSecondary)
                            }
                            Icon(Icons.Filled.ChevronRight, null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            } // closes the horizontally-padded inner Column started right after the header banner
        }

        AnimatedVisibility(visible = toastMessage != null, modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp)) {
            Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFF1B2430)) {
                Text(toastMessage ?: "", color = Color.White, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    if (showEmployeePicker) {
        EmployeePickerDialog(
            currentId = employeeId,
            onPick = { employeeId = it; showEmployeePicker = false },
            onDismiss = { showEmployeePicker = false },
        )
    }
}

@Composable
private fun ModuleTile(module: AppModule, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(54.dp)
                .background(
                    androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(module.colorStart), Color(module.colorEnd))),
                    RoundedCornerShape(17.dp),
                ),
            contentAlignment = Alignment.Center,
        ) {
            Text(module.icon, fontSize = 22.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            module.label,
            style = MaterialTheme.typography.labelSmall,
            color = TextPrimary,
            textAlign = TextAlign.Center,
            maxLines = 2,
        )
    }
}

@Composable
private fun EmployeePickerDialog(currentId: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query) {
        val q = query.lowercase()
        if (q.isBlank()) EMPLOYEE_DIRECTORY.take(60)
        else EMPLOYEE_DIRECTORY.filter {
            it.name.lowercase().contains(q) || it.role.name.lowercase().contains(q) || it.geoLabel.lowercase().contains(q)
        }.take(60)
    }
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 480.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Switch employee (testing)", style = MaterialTheme.typography.titleMedium)
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, contentDescription = "Close") }
                }
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("Search name, role, or district…") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                )
                LazyColumn {
                    items(filtered, key = { it.id }) { emp ->
                        val selected = emp.id == currentId
                        Text(
                            "${emp.name}  ·  ${roleLabel(emp.role)}  ·  ${emp.geoLabel}",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (selected) ElectricCyan else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(emp.id) }
                                .padding(vertical = 10.dp),
                        )
                    }
                }
            }
        }
    }
}

/** Human-friendly designation label (UserRole enum names are already short/clear, but centralizing here in case that changes). */
fun roleLabel(role: UserRole): String = role.name

/** Small "did my last action actually leave the phone" indicator — Pending/Synced/Failed, backed by MockRepository.syncStatus. */
@Composable
private fun SyncStatusBadge(vm: MainDashboardViewModel) {
    val status by vm.syncStatus.collectAsState()
    val (label, dotColor) = when (status) {
        com.abm.erp.data.SyncStatus.SYNCED -> "Synced" to Color(0xFF3DDC97)
        com.abm.erp.data.SyncStatus.PENDING -> "Syncing…" to Color(0xFFFFB020)
        com.abm.erp.data.SyncStatus.FAILED -> "Sync failed" to Color(0xFFE85D4A)
    }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(Color.White.copy(alpha = 0.18f), androidx.compose.foundation.shape.RoundedCornerShape(999.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp),
    ) {
        Box(Modifier.size(7.dp).background(dotColor, androidx.compose.foundation.shape.CircleShape))
        Spacer(Modifier.width(5.dp))
        Text(label, color = Color.White, fontSize = 10.sp)
    }
}

/** Blueprint §19 — one KPI: small label above, bold value below, and the value's
 *  colour IS its status. Used by the Dashboard's 2-column Executive Summary grid. */
@Composable
private fun DashboardKpiCard(label: String, targetValue: Double, format: (Double) -> String, color: Color, modifier: Modifier = Modifier) {
    // Blueprint §10 — KPI figures count up on first appear. Preserved from the previous
    // KpiTile so the grid conversion doesn't quietly drop the animation.
    val animated by androidx.compose.animation.core.animateFloatAsState(
        targetValue = targetValue.toFloat(),
        animationSpec = androidx.compose.animation.core.tween(durationMillis = 900, easing = androidx.compose.animation.core.FastOutSlowInEasing),
        label = "kpiCounter",
    )
    // Renders through the shared MetricCard so the Dashboard inherits the design
    // system rather than maintaining its own card. The count-up animation stays here
    // because it is specific to dashboard figures, not to every metric in the app.
    com.abm.erp.core.MetricCard(
        label = label,
        value = format(animated.toDouble()),
        valueColor = color,
        modifier = modifier,
    )
}

/** Enterprise Workspace redesign — small-caps section header with a hairline rule, the standard
 * enterprise-dashboard grouping convention. Purely visual: groups the existing cards into clear
 * zones (Overview / Performance / Activity / Actions) instead of one undifferentiated vertical
 * stack. No card's own content, data, or navigation changes — this only labels the group above it. */
@Composable
private fun DashboardSectionLabel(text: String) {
    Column(Modifier.fillMaxWidth().padding(top = 4.dp)) {
        Text(
            text.uppercase(), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold,
            color = TextSecondary, letterSpacing = 1.2.sp,
        )
        Spacer(Modifier.height(6.dp))
        Divider(color = TextSecondary.copy(alpha = 0.15f), thickness = 1.dp)
        Spacer(Modifier.height(4.dp))
    }
}

/** Enterprise Workspace redesign — compact glanceable status strip placed right under the header:
 * GPS/location (employee.geoLabel, already shown in the header subtitle — repeated here as a quick
 * chip since it's one of the required at-a-glance signals), unread Notifications count, and Pending
 * Approvals count. All three read data already loaded elsewhere on this screen (notifications,
 * approvals) — nothing new is fetched. Each chip navigates to its existing screen/route; no new
 * routes, no business logic. */
@Composable
private fun DashboardStatusStrip(geoLabel: String, unreadNotifications: Int, pendingApprovalsCount: Int, onNavigate: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        AssistChip(
            onClick = {}, enabled = false,
            leadingIcon = { Text("📍") },
            label = { Text(geoLabel, style = MaterialTheme.typography.labelSmall) },
        )
        AssistChip(
            onClick = { onNavigate("notifications") },
            leadingIcon = { Text(if (unreadNotifications > 0) "🔔" else "🔕") },
            label = { Text(if (unreadNotifications > 0) "Notifications ($unreadNotifications)" else "Notifications", style = MaterialTheme.typography.labelSmall) },
            colors = AssistChipDefaults.assistChipColors(
                labelColor = if (unreadNotifications > 0) WarningAmber else TextSecondary,
            ),
        )
        // Decision 2 (v113-72) — this stays as a *count*, but is no longer tappable:
        // there is no central inbox to open. Acting on an approval happens inside the
        // module that raised it (HRM / Expenses / Ledger / DMS).
        AssistChip(
            onClick = {}, enabled = false,
            leadingIcon = { Text("✅") },
            label = { Text(if (pendingApprovalsCount > 0) "Approvals ($pendingApprovalsCount)" else "Approvals", style = MaterialTheme.typography.labelSmall) },
            colors = AssistChipDefaults.assistChipColors(
                labelColor = if (pendingApprovalsCount > 0) WarningAmber else TextSecondary,
            ),
        )
    }
}

/**
 * v113-74 — Home Dashboard's six mother modules.
 *
 * Each opens a module that owns its own left drawer of options. No mother module is
 * reachable from inside another one: switching modules means coming back here. That
 * is the person's explicit rule and the reason this grid exists at all.
 */
@Composable
private fun MotherModuleGrid(onNavigate: (String) -> Unit) {
    data class Mother(val label: String, val sub: String, val emoji: String, val route: String?)
    // v113-76 — five, not six: the person moved AI inside the Chairman module, so it
    // is no longer a top-level entry. The Chairman tile only renders for the Chairman.
    val isChairman = com.abm.erp.data.MockRepository.currentUser.role == com.abm.erp.data.UserRole.CHAIRMAN
    val mothers = buildList {
        add(Mother("DMS", "Dealer Management", "\uD83C\uDFEC", "dms"))
        add(Mother("RMS", "Retailer Management", "\uD83C\uDFEA", "rms"))
        add(Mother("HR", "Employee Management", "\uD83D\uDC65", "hr_module"))
        add(Mother("FMS", "Factory Management", "\uD83C\uDFED", "fms"))
        if (isChairman) add(Mother("CHAIRMAN", "Full Control + AI", "\uD83D\uDC51", "chairman_module"))
    }
    DashboardSectionLabel("Modules")
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        mothers.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { m ->
                    val enabled = m.route != null
                    Column(
                        Modifier.weight(1f)
                            .padding(vertical = 4.dp)
                            .then(if (enabled) Modifier.clickable { onNavigate(m.route!!) } else Modifier)
                            .padding(12.dp),
                    ) {
                        Text(m.emoji, style = MaterialTheme.typography.titleLarge)
                        Text(m.label, fontWeight = FontWeight.Bold, color = if (enabled) TextPrimary else TextSecondary)
                        Text(
                            if (enabled) m.sub else "${m.sub} — শীঘ্রই",
                            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                        )
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}
