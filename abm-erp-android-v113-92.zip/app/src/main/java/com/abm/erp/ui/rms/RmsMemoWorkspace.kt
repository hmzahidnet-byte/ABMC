package com.abm.erp.ui.rms

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.core.rememberVisibleRetailers
import com.abm.erp.data.CodeRegistry
import com.abm.erp.data.MockRepository
import com.abm.erp.data.SalesInvoiceLineItem
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * v113-80 — RMS ORDER (MEMO) WORKSPACE. Second application of the workspace contract,
 * built from the DMS Invoice Workspace reference: retailer identify (search OR QR/code
 * autofill, cascade re-checked), retailer financial context (due / credit limit /
 * memo history), product add with live stock, memo summary, create, and the
 * retailer's memo history inline. Helper actions stay dialogs; nothing navigates away.
 *
 * Engines reused untouched: `logNewOrder` (now carrying the real retailerId — see
 * MockRepository v113-80 note), `CodeRegistry.resolve`, `rememberVisibleRetailers`.
 * The old free-text RetailerTab keeps serving the legacy Sales suite; this workspace
 * is the RMS-native path where the memo is linked to a real Retailer record, which is
 * also what makes the v113-75 retailer-stock pipeline actually run.
 */
@Composable
fun RmsMemoWorkspace(onNavigate: (String) -> Unit = {}) {
    val retailers = rememberVisibleRetailers()
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val stockLevels by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
    val orders by MockRepository.orders.collectAsState()

    var codeInput by remember { mutableStateOf("") }
    var codeError by remember { mutableStateOf<String?>(null) }
    var retailerQuery by remember { mutableStateOf("") }
    var selectedRetailerId by remember { mutableStateOf<String?>(null) }
    var productQuery by remember { mutableStateOf("") }
    var cart by remember { mutableStateOf(listOf<SalesInvoiceLineItem>()) }
    var lastResult by remember { mutableStateOf<String?>(null) }

    val retailer = retailers.firstOrNull { it.id == selectedRetailerId }
    val retailerOrders = remember(orders, selectedRetailerId, retailer) {
        if (retailer == null) emptyList()
        // Matches by linked id where present, by name for pre-v113-80 memos that have no link.
        else orders.filter { it.retailerId == retailer.id || (it.retailerId == null && it.retailerName == retailer.name) }
            .sortedByDescending { it.loggedAt }
    }
    val total = remember(cart) { cart.sumOf { it.lineTotal } }
    val overCredit = retailer != null && retailer.creditLimit > 0 && (retailer.dueBalance + total) > retailer.creditLimit

    fun applyCode() {
        codeError = null
        when (val r = CodeRegistry.resolve(codeInput)) {
            is CodeRegistry.ResolveResult.Found -> when (r.type) {
                CodeRegistry.CodeType.RETAILER -> {
                    if (retailers.any { it.id == r.id }) { selectedRetailerId = r.id; codeInput = "" }
                    else codeError = "এই retailer আপনার এলাকার বাইরে — নির্বাচন করা যাবে না।"
                }
                CodeRegistry.CodeType.PRODUCT -> {
                    val p = products.firstOrNull { it.id == r.id && !it.isDeleted }
                    if (p != null) { cart = cart + SalesInvoiceLineItem(p.id, p.name, p.unit, 1, p.defaultUnitPrice); codeInput = "" }
                    else codeError = "Product পাওয়া গেল কিন্তু লোড হয়নি।"
                }
                else -> codeError = "এই কোডটি ${r.type} — এখানে retailer/product কোড লাগবে।"
            }
            is CodeRegistry.ResolveResult.Ambiguous -> codeError = "একই কোড একাধিক রেকর্ডে — data integrity সমস্যা, admin-কে জানান।"
            CodeRegistry.ResolveResult.NotFound -> codeError = "কোডটি মেলেনি।"
            CodeRegistry.ResolveResult.Invalid -> codeError = "কোড খালি/অবৈধ।"
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Spacer(Modifier.height(4.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = codeInput, onValueChange = { codeInput = it },
                        placeholder = { Text("Retailer/Product QR বা কোড…") },
                        singleLine = true, modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { applyCode() }, enabled = codeInput.isNotBlank()) { Text("Fill") }
                    IconButton(onClick = { onNavigate("universal_scanner") }) {
                        Icon(Icons.Filled.QrCodeScanner, contentDescription = "Scan", tint = TextPrimary)
                    }
                }
                codeError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
            }
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Retailer", fontWeight = FontWeight.Bold, color = TextPrimary)
                if (retailer == null) {
                    OutlinedTextField(
                        value = retailerQuery, onValueChange = { retailerQuery = it },
                        placeholder = { Text("নাম/market দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                    val matches = remember(retailers, retailerQuery) {
                        if (retailerQuery.isBlank()) emptyList()
                        else retailers.filter { it.name.contains(retailerQuery, true) || it.market.orEmpty().contains(retailerQuery, true) }.take(5)
                    }
                    matches.forEach { rt ->
                        Text(
                            "${rt.name} — ${rt.market.orEmpty()}",
                            modifier = Modifier.fillMaxWidth().clickable { selectedRetailerId = rt.id; retailerQuery = "" }.padding(vertical = 8.dp),
                            color = TextPrimary,
                        )
                    }
                    if (retailerQuery.isNotBlank() && matches.isEmpty()) {
                        Text("আপনার এলাকায় মেলেনি।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(retailer.name, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(retailer.market.orEmpty(), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        TextButton(onClick = { selectedRetailerId = null }) { Text("বদলান") }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Outstanding Due", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("৳${"%,.0f".format(retailer.dueBalance)}", fontWeight = FontWeight.Bold, color = if (retailer.dueBalance > 0) WarningAmber else SuccessGreen)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Credit Limit", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("৳${"%,.0f".format(retailer.creditLimit)}", color = TextPrimary)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Memo history", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("${retailerOrders.size} টি · ৳${"%,.0f".format(retailerOrders.sumOf { it.amount })}", color = TextPrimary)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { onNavigate("statement/RETAILER/${retailer.id}") }) { Text("Full Ledger →") }
                        TextButton(onClick = { onNavigate("retailer_stock/${retailer.id}") }) { Text("Stock →") }
                    }
                }
            }
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Product", fontWeight = FontWeight.Bold, color = TextPrimary)
                OutlinedTextField(
                    value = productQuery, onValueChange = { productQuery = it },
                    placeholder = { Text("Product নাম/SKU…") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                val productMatches = remember(products, productQuery) {
                    products.filter {
                        !it.isDeleted && it.isActive &&
                            (productQuery.isBlank() || it.name.contains(productQuery, true) || it.sku.contains(productQuery, true))
                    }.take(6)
                }
                productMatches.forEach { p ->
                    val onHand = stockLevels.filter { it.productId == p.id }.sumOf { it.quantityOnHand }
                    Row(
                        Modifier.fillMaxWidth().clickable { cart = cart + SalesInvoiceLineItem(p.id, p.name, p.unit, 1, p.defaultUnitPrice) }.padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column {
                            Text(p.name, color = TextPrimary)
                            Text("৳${"%,.0f".format(p.defaultUnitPrice)}/${p.unit} · stock ${"%,.0f".format(onHand)}", style = MaterialTheme.typography.labelSmall, color = if (onHand <= 0) DangerRed else TextSecondary)
                        }
                        Icon(Icons.Filled.AddCircleOutline, contentDescription = "Add", tint = TextSecondary)
                    }
                }
            }
        }

        if (cart.isNotEmpty()) {
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Memo Items (${cart.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
                    cart.forEachIndexed { idx, line ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(line.name, color = TextPrimary)
                                Text("৳${"%,.0f".format(line.unitPrice)}/${line.unit}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                            IconButton(onClick = { if (line.qty > 1) cart = cart.toMutableList().also { it[idx] = line.copy(qty = line.qty - 1) } }) { Icon(Icons.Filled.RemoveCircleOutline, null, tint = TextSecondary) }
                            Text("${line.qty}", fontWeight = FontWeight.Bold, color = TextPrimary)
                            IconButton(onClick = { cart = cart.toMutableList().also { it[idx] = line.copy(qty = line.qty + 1) } }) { Icon(Icons.Filled.AddCircleOutline, null, tint = TextSecondary) }
                            IconButton(onClick = { cart = cart.filterIndexed { i, _ -> i != idx } }) { Icon(Icons.Filled.Delete, null, tint = DangerRed) }
                        }
                    }
                }
            }
        }

        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Memo Summary", fontWeight = FontWeight.Bold, color = TextPrimary)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total", fontWeight = FontWeight.Bold, color = TextPrimary)
                    Text("৳${"%,.0f".format(total)}", fontWeight = FontWeight.Bold, color = TextPrimary)
                }
                if (overCredit) {
                    Text(
                        "⚠ Credit limit ছাড়িয়ে যাবে — TSM verify ধাপে এটি দেখা যাবে।",
                        color = WarningAmber, style = MaterialTheme.typography.labelSmall,
                    )
                }
                Button(
                    onClick = {
                        val rt = retailer ?: return@Button
                        MockRepository.logNewOrder(
                            retailerName = rt.name, items = cart.joinToString(", ") { "${it.name} x${it.qty}" },
                            amount = total, zone = rt.market.orEmpty().ifBlank { "N/A" },
                            lineItems = cart, retailerId = rt.id,
                        )
                        lastResult = "✔ Memo তৈরি হয়েছে — TSM verify করলে dealer-এ route হবে।"
                        cart = emptyList()
                    },
                    enabled = retailer != null && cart.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Memo তৈরি করুন") }
                lastResult?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = SuccessGreen) }
            }
        }

        if (retailerOrders.isNotEmpty()) {
            item { Text("এই retailer-এর Memo (${retailerOrders.size})", fontWeight = FontWeight.SemiBold, color = TextPrimary) }
            items(retailerOrders.take(10), key = { it.id }) { o ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(o.orderNo, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        com.abm.erp.core.StatusPill(o.stage.name)
                    }
                    Text("৳${"%,.0f".format(o.amount)} · ${o.loggedAt.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Text(o.items, style = MaterialTheme.typography.labelSmall, color = TextSecondary, maxLines = 2)
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
