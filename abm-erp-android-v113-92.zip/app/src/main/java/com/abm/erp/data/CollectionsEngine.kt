package com.abm.erp.data

import androidx.room.withTransaction
import com.abm.erp.data.room.PartyCollectionEntity
import kotlinx.coroutines.flow.first
import java.time.LocalDateTime
import java.time.YearMonth

// ============================================================================
// v113-81 Phase 2 — the Collections group, moved out of MockRepository.kt.
//
// Mechanics: these are now extension functions on the MockRepository object, so
// every call site (`MockRepository.createCollection(...)`) is textually
// IDENTICAL to before — nothing outside this file changed. Private-member access
// was replaced with the object's existing internal bridges, the same ones the
// QR registry split already uses: `db` → `database`, `scope.launch` →
// `launchInRepoScope`, `syncCollection` → `qrSyncCollection`. The function
// bodies themselves are otherwise untouched — dual-control, period-close guard,
// online-only verify, allocation math: all exactly as they were.
// ============================================================================

fun MockRepository.createCollectionWithMultipleAllocations(
    partyType: PartyType, partyId: String, partyName: String, totalAmount: Double, method: String,
    allocations: List<Pair<String, Double>>, proofUri: String? = null,
): List<PartyCollection>? {
    val allocatedSum = allocations.sumOf { it.second }
    if (allocatedSum > totalAmount + 0.01) {
        com.abm.erp.config.AppLog.w("MockRepository", "createCollectionWithMultipleAllocations rejected: allocations (৳$allocatedSum) exceed collected amount (৳$totalAmount)")
        return null
    }
    val unallocated = totalAmount - allocatedSum
    val toCreate = allocations.filter { it.second > 0 }.map { (invoiceId, amount) ->
        PartyCollection(id = java.util.UUID.randomUUID().toString(), partyType = partyType, partyId = partyId, partyName = partyName, amount = amount, method = method, proofUri = proofUri, collectedBy = currentUser.name, allocatedInvoiceId = invoiceId)
    } + if (unallocated > 0.01) listOf(PartyCollection(id = java.util.UUID.randomUUID().toString(), partyType = partyType, partyId = partyId, partyName = partyName, amount = unallocated, method = method, proofUri = proofUri, collectedBy = currentUser.name, allocatedInvoiceId = null)) else emptyList()
    launchInRepoScope {
        // Part M — was N independent launchInRepoScope calls (one per
        // allocation), each its own coroutine; a process death mid-
        // batch could leave some allocations persisted and others not.
        // Now one real Room transaction — all rows land together or
        // none do, matching transferStock's already-correct pattern.
        database.withTransaction {
            toCreate.forEach { database.partyCollectionDao().upsert(it.toEntity()) }
        }
        toCreate.forEach { c ->
            qrSyncCollection("partyCollections").document(c.id).set(c.toEntity())
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push collection failed", it) }
            logAudit("Collection", c.id, "CREATE", newValue = c)
        }
    }
    return toCreate
}

fun MockRepository.createCollection(partyType: PartyType, partyId: String, partyName: String, amount: Double, method: String, proofUri: String? = null, allocatedInvoiceId: String? = null): PartyCollection {
    // Offline-safe temporary number, replaced with the real central-series number below once this write actually runs.
    val tempNo = generateTemporaryNumber("COLLECTION")
    val collection = PartyCollection(
        id = java.util.UUID.randomUUID().toString(), collectionNo = tempNo, partyType = partyType, partyId = partyId, partyName = partyName,
        amount = amount, method = method, proofUri = proofUri, collectedBy = currentUser.name, allocatedInvoiceId = allocatedInvoiceId,
    )
    launchInRepoScope {
        if (amount <= 0) {
            com.abm.erp.config.AppLog.w("MockRepository", "createCollection skipped: non-positive amount")
            return@launchInRepoScope
        }
        // Central Number Series Engine — replaces the temporary offline number with the real, mutex-guarded series number.
        val realNo = replaceTemporaryNumber("COLLECTION")
        val entity = collection.copy(collectionNo = realNo).toEntity()
        database.partyCollectionDao().upsert(entity)
        qrSyncCollection("partyCollections").document(entity.id).set(entity)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push collection failed", it) }
        logAudit("Collection", collection.id, "CREATE", newValue = collection)
    }
    return collection
}

/** Verifying a collection is what actually reduces the due balance — an unverified collection is just a claim, not yet trusted money. Requires APPROVE permission (same tier as approving an invoice). */
fun MockRepository.verifyCollection(collectionId: String): Boolean {
    if (!PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)) {
        logAudit("Collection", collectionId, "DENY", oldValue = currentUser.role.name, newValue = "VERIFY")
        return false
    }
    if (!com.abm.erp.ABMApplication.isOnlineNow()) {
        logAudit("Collection", collectionId, "DENY_OFFLINE", newValue = "Final Collection requires an online connection")
        return false
    }
    val collection = partyCollections.value.firstOrNull { it.id == collectionId } ?: return false
    // v86 fix — real "no double-counting" bug: this had no check that
    // the collection was still PENDING before applying due-balance
    // decrement + invoice allocation. A collection could be verified
    // twice (double-counting the due reduction), or verified after
    // being rejected. Explicit edge case this session's audit called
    // out: "No double-counting after editing, cancelling or reversing."
    if (collection.status != "PENDING") {
        logAudit("Collection", collectionId, "DENY", oldValue = collection.status, newValue = "VERIFY — already ${collection.status}, cannot verify again")
        return false
    }
    run {
        val currentYearMonth = LocalDateTime.now().let { "%04d-%02d".format(it.year, it.monthValue) }
        if (AccountsRepository.closedPeriods.value.contains(currentYearMonth)) {
            logAudit("Collection", collectionId, "DENY", oldValue = "period $currentYearMonth", newValue = "VERIFY — period is closed")
            return false
        }
    }
    launchInRepoScope {
        // Real atomic check-and-flip — closes the same retry/race window fixed for invoices: two near-simultaneous verify calls could otherwise both read the cached "PENDING" status before either commits, and both proceed to double-decrement due balance.
        val freshCollection = database.withTransaction {
            val current = database.partyCollectionDao().getAll().first().firstOrNull { it.id == collectionId }?.toDomain() ?: return@withTransaction null
            if (current.status != "PENDING") {
                logAudit("Collection", collectionId, "DENY", oldValue = current.status, newValue = "VERIFY — already ${current.status}, cannot verify again")
                return@withTransaction null
            }
            val now = System.currentTimeMillis()
            database.partyCollectionDao().setStatus(collectionId, "VERIFIED", currentUser.name, now)
            current
        } ?: return@launchInRepoScope
        val now = System.currentTimeMillis()
        qrSyncCollection("partyCollections").document(collectionId)
            .update(mapOf("status" to "VERIFIED", "verifiedBy" to currentUser.name, "verifiedAtEpochMillis" to now))
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push collection-verify failed", it) }
        if (freshCollection.partyType == PartyType.DEALER) {
            database.dealerDao().adjustDueBalance(freshCollection.partyId, -freshCollection.amount)
            pushDealerIncrement(freshCollection.partyId, stockDelta = 0, dueDelta = -freshCollection.amount)
            updateWeeklyPaidAmount(freshCollection.partyId, freshCollection.amount)
            freshCollection.allocatedInvoiceId?.let { invId ->
                val invoice = salesInvoices.value.firstOrNull { it.id == invId }
                if (invoice != null) {
                    val newPaid = (invoice.paidAmount + freshCollection.amount).coerceAtMost(invoice.netAfterDiscount)
                    val newStatus = if (newPaid >= invoice.netAfterDiscount) "PAID" else "PARTIALLY_PAID"
                    database.invoiceDao().updatePaidAmountAndStatus(invId, newPaid, newStatus)
                    qrSyncCollection("salesInvoices").document(invId)
                        .update(mapOf("paidAmount" to newPaid, "status" to newStatus))
                        .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push invoice-allocation failed", it) }
                    logAudit("SalesInvoice", invId, "COLLECTION_ALLOCATED", newValue = "৳${freshCollection.amount} — now $newStatus")
                }
            }
        } else {
            database.retailerDao().adjustDueBalance(freshCollection.partyId, -freshCollection.amount)
            qrSyncCollection("retailers").document(freshCollection.partyId)
                .update("dueBalance", com.google.firebase.firestore.FieldValue.increment(-freshCollection.amount))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-due-decrement failed", it) }
        }
        postPartyLedgerEntry(freshCollection.partyType, freshCollection.partyId, "CREDIT", freshCollection.amount, "Collection verified", collectionId)
        // Real cash/bank posting — the company's OWN cash-in-hand/bank-balance ledger, distinct from the party-due ledger above. Was completely missing before: money coming in was never actually recorded on the company's own books.
        addLedgerEntry(
            LedgerEntryType.IN, if (freshCollection.method == "BANK") "Bank Collection" else "Cash Collection",
            "${freshCollection.partyName} — ${freshCollection.collectionNo}", freshCollection.amount, currentUser.name,
        )
        logAudit("Collection", collectionId, "APPROVE", newValue = "due -৳${freshCollection.amount}")
        createNotification(NotificationCategory.COLLECTION, "Collection Verified", "${freshCollection.partyName}: ৳${"%,.0f".format(freshCollection.amount)} ${freshCollection.method}")
        activateQrFor("Collection", collectionId)  // verified receipt becomes scannable
    }
    return true
}

fun MockRepository.rejectCollection(collectionId: String) {
    launchInRepoScope {
        val existing = database.withTransaction {
            val current = database.partyCollectionDao().getAll().first().firstOrNull { it.id == collectionId }?.toDomain()
            if (current == null || current.status != "PENDING") {
                logAudit("Collection", collectionId, "DENY", oldValue = current?.status ?: "not found", newValue = "REJECT — only a PENDING collection can be rejected")
                return@withTransaction null
            }
            if (isDateLocked(current.createdAt.toLocalDate())) {
                logAudit("Collection", collectionId, "DENY_LOCKED_PERIOD", oldValue = current.createdAt.toLocalDate().toString(), newValue = "REJECT_ATTEMPT")
                return@withTransaction null
            }
            database.partyCollectionDao().setStatus(collectionId, "REJECTED", currentUser.name, System.currentTimeMillis())
            current
        } ?: return@launchInRepoScope
        qrSyncCollection("partyCollections").document(collectionId).update("status", "REJECTED")
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push collection-reject failed", it) }
        logAudit("Collection", collectionId, "REJECT")
        revokeQrFor("Collection", collectionId, "Collection rejected")
    }
}
