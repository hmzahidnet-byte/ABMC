package com.abm.erp.ui.advisory

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.InventoryRepository
import com.abm.erp.data.MockRepository
import com.abm.erp.data.pendingApprovalSlaItems
import com.abm.erp.data.RiskBand
import com.abm.erp.theme.*
import java.util.Locale

private enum class AiMode { ASSISTANT, ANALYSIS, DECISION_QUERY }

/** Thin MVVM wrapper — delegates straight to the MockRepository/FirebaseSync singletons (repository pattern already owns the real logic); this just gives the screen a lifecycle-scoped access point instead of calling the singletons directly. */
class BoardroomViewModel : ViewModel() {
    val history = MockRepository.boardroomHistory
    val usageCount = FirebaseSync.aiUsageThisMonth
    fun prescriptions() = MockRepository.computePrescriptions()
    val aiMonthlyCap = FirebaseSync.AI_MONTHLY_CAP
    fun tryConsumeAiUsage() = FirebaseSync.tryConsumeAiUsage()
    fun askAssistant(q: String) = MockRepository.askAssistant(q)
    fun askAnalysis(q: String) = MockRepository.askAnalysis(q)

    // ---- Module 16: AI & Automation — Sales Forecast ----
    val dealers = MockRepository.dealers
    fun forecastForDealer(dealer: com.abm.erp.data.Dealer) = MockRepository.computeSalesForecast(dealer)
    fun forecastForZone(zone: String) = MockRepository.computeZoneForecast(zone)

    // ---- Module 16: Business Health Score / Risk Detection / Demand-Collection-Production Forecast ----
    fun businessHealthScore() = MockRepository.computeBusinessHealthScore()
    fun riskAlerts() = MockRepository.computeRiskAlerts()
    fun demandForecast() = MockRepository.computeDemandForecast()
    fun collectionForecast30d() = MockRepository.computeCollectionForecast()
    fun productionForecast30d() = MockRepository.computeProductionForecast()
    fun inventoryForecast() = MockRepository.computeInventoryForecast()
    fun smartRecommendations() = MockRepository.smartBusinessRecommendations()
}

@Composable
fun BoardroomScreen(onNavigate: (String) -> Unit = {}, vm: BoardroomViewModel = viewModel()) {
    val scanScope = rememberCoroutineScope()
    val history by vm.history.collectAsState()
    val usageCount by vm.usageCount.collectAsState()
    val dealers by vm.dealers.collectAsState()
    var question by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(AiMode.ASSISTANT) }
    var decisionAnswer by remember { mutableStateOf<MockRepository.DecisionAnswer?>(null) }
    var micError by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (text != null) question = text
        }
    }
    val micPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            micError = null
            launchSpeechRecognizer(context, speechLauncher) { micError = it }
        } else {
            micError = "Microphone permission was denied — type your question instead."
        }
    }

    fun submit() {
        if (question.isBlank()) return
        if (mode == AiMode.DECISION_QUERY) {
            // Section 19 — deterministic, doesn't consume the AI usage cap since no external LLM is involved.
            decisionAnswer = MockRepository.askDecisionQuery(question)
            question = ""
            return
        }
        if (!vm.tryConsumeAiUsage()) {
            question = ""
            return // cap hit — the banner below already explains this
        }
        if (mode == AiMode.ASSISTANT) vm.askAssistant(question) else vm.askAnalysis(question)
        question = ""
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("AI Assistant", style = MaterialTheme.typography.headlineSmall)
            Text("Two ways to use it — get things done, or just understand what's happening.", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        }

        item {
            var showExec by remember { mutableStateOf(false) }
            TextButton(onClick = { showExec = !showExec }) { Text(if (showExec) "Hide Executive Command Center" else "📈 Executive Command Center") }
            if (showExec) {
                val salesKpi = remember { MockRepository.computeSalesKpi() }
                val collectionKpi = remember { MockRepository.computeCollectionKpi() }
                val retailerKpi = remember { MockRepository.computeRetailerKpi() }
                val employeeKpi by produceState(initialValue = MockRepository.EmployeeKpi(0, 0, 0, 0)) { value = MockRepository.computeEmployeeKpi() }
                val approvalKpi = remember { MockRepository.computeApprovalKpi() }
                val risks = remember { MockRepository.topRisks() }
                val opportunities by produceState<List<com.abm.erp.executive.ExecutiveIntelligence.OpportunityItem>>(initialValue = emptyList()) { value = MockRepository.topOpportunities() }
                val exceptions by MockRepository.executiveExceptions.collectAsState()

                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Sales — Today ৳${"%,.0f".format(salesKpi.today)} · This Month ৳${"%,.0f".format(salesKpi.thisMonth)}", style = MaterialTheme.typography.bodySmall)
                    Text("vs Last Month: ${if (salesKpi.trend.direction == "UP") "▲" else if (salesKpi.trend.direction == "DOWN") "▼" else "—"} ${salesKpi.trend.pctChange?.let { "%.0f".format(it) + "%" } ?: "no baseline"}", style = MaterialTheme.typography.labelSmall, color = if (salesKpi.trend.direction == "UP") SuccessGreen else DangerRed)
                    Text("Collection efficiency: ${"%.0f".format(collectionKpi.efficiencyPct)}% · Outstanding due: ৳${"%,.0f".format(collectionKpi.outstandingDue)}", style = MaterialTheme.typography.bodySmall)
                    Text("Retailers: ${retailerKpi.totalActive} active, ${retailerKpi.inactive} inactive, ${retailerKpi.newThisMonth} new", style = MaterialTheme.typography.bodySmall)
                    Text("Employees: ${employeeKpi.presentToday} present, ${employeeKpi.onLeave} on leave, ${employeeKpi.geoViolationsToday} geo-violations today", style = MaterialTheme.typography.bodySmall)
                    Text("Approvals: ${approvalKpi.pending} pending, ${approvalKpi.overdue} overdue", style = MaterialTheme.typography.bodySmall, color = if (approvalKpi.overdue > 0) WarningAmber else TextSecondary)
                }
                Spacer(Modifier.height(8.dp))
                Text("Top Risks", fontWeight = FontWeight.Bold, color = DangerRed)
                if (risks.isEmpty()) {
                    Text("এই মুহূর্তে কোনো critical risk পাওয়া যায়নি — ভালো লক্ষণ।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                risks.forEach { r ->
                    Text(
                        "• ${r.type}: ${r.evidence} → ${r.recommendedAction} (${r.responsibleOwner})",
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.fillMaxWidth().clickable {
                            when (r.type) { "STOCK_OUT" -> onNavigate("inventory"); "CREDIT_BREACH" -> onNavigate("dealers"); "SECURITY" -> onNavigate("dealers") }
                        },
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text("Top Opportunities", fontWeight = FontWeight.Bold, color = SuccessGreen)
                if (opportunities.isEmpty()) {
                    Text("এই মুহূর্তে কোনো নতুন opportunity চিহ্নিত হয়নি।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                opportunities.forEach { o -> Text("• ${o.type}: ${o.evidence} → ${o.recommendedAction} (${o.responsibleOwner})", style = MaterialTheme.typography.labelSmall) }
                Spacer(Modifier.height(8.dp))
                var showExecSettings by remember { mutableStateOf(false) }
                TextButton(onClick = { showExecSettings = true }) { Text("⚙ Executive Settings") }
                if (showExecSettings) {
                    val current = MockRepository.executiveSettings
                    var refreshMin by remember { mutableStateOf(current.alertRefreshMinutes.toString()) }
                    var overdueHrs by remember { mutableStateOf(current.approvalOverdueHours.toString()) }
                    Dialog(onDismissRequest = { showExecSettings = false }) {
                        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Executive Settings", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = refreshMin, onValueChange = { refreshMin = it }, label = { Text("Alert refresh (minutes)") }, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(6.dp))
                                OutlinedTextField(value = overdueHrs, onValueChange = { overdueHrs = it }, label = { Text("Approval overdue threshold (hours)") }, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        val updated = current.copy(alertRefreshMinutes = refreshMin.toIntOrNull() ?: current.alertRefreshMinutes, approvalOverdueHours = overdueHrs.toLongOrNull() ?: current.approvalOverdueHours)
                                        if (MockRepository.updateExecutiveSettings(updated)) showExecSettings = false
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                ) { Text("Save") }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Open Exceptions (${exceptions.count { it.status == "NEW" }})", fontWeight = FontWeight.Bold, color = WarningAmber)
                    TextButton(onClick = { scanScope.launch { MockRepository.generateExecutiveExceptions() }; MockRepository.escalateOverdueManagementActions() }) { Text("↻ Scan Now") }
                }
                exceptions.filter { it.status == "NEW" }.take(10).forEach { e ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${e.type}: ${e.message}", style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
                        Row {
                            TextButton(onClick = { MockRepository.updateExceptionStatus(e.id, "ACKNOWLEDGED") }) { Text("Ack") }
                            TextButton(onClick = { MockRepository.createManagementAction("Resolve: ${e.type}", e.id, MockRepository.currentUser.name, "HIGH", java.time.LocalDate.now().plusDays(3)) }) { Text("Assign") }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                var showBrief by remember { mutableStateOf<MockRepository.DailyBrief?>(null) }
                TextButton(onClick = { scanScope.launch { showBrief = MockRepository.generateDailyBrief() } }) { Text("📋 Generate Daily Brief") }
                showBrief?.let { brief ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text("Daily Brief — ${brief.generatedAt.toLocalDate()}", fontWeight = FontWeight.Bold)
                        Text("Yesterday sales: ৳${"%,.0f".format(brief.yesterdaySales)} · Today so far: ৳${"%,.0f".format(brief.todayProgress)}", style = MaterialTheme.typography.labelSmall)
                        Text("Collection: ${brief.collectionStatus} · Pending approvals: ${brief.pendingApprovals}", style = MaterialTheme.typography.labelSmall)
                        Text("Top Actions:", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelSmall)
                        brief.topActions.forEach { a -> Text("• $a", style = MaterialTheme.typography.labelSmall) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                val actions by MockRepository.managementActions.collectAsState()
                val openActions = actions.filter { it.status !in setOf("COMPLETED", "CANCELLED") }
                Text("Management Actions (${openActions.size})", fontWeight = FontWeight.Bold)
                if (openActions.isEmpty()) {
                    Text("কোনো open action নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                openActions.take(10).forEach { a ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${a.title} → ${a.assignedTo} (${a.status})", style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
                        TextButton(onClick = { MockRepository.updateManagementActionStatus(a.id, "COMPLETED") }) { Text("Done") }
                    }
                }
                Spacer(Modifier.height(8.dp))
                val syncStatusLive by MockRepository.syncStatus.collectAsState()
                val isLive = syncStatusLive == com.abm.erp.data.SyncStatus.SYNCED
                Text(
                    "Data status: ${syncStatusLive}" + if (!isLive) " — showing cached data, not live" else "",
                    style = MaterialTheme.typography.labelSmall, color = if (isLive) SuccessGreen else WarningAmber,
                )
                Spacer(Modifier.height(8.dp))
                Text("Field Force Status", fontWeight = FontWeight.Bold)
                val fieldForce by produceState<List<MockRepository.FieldForceStatus>>(initialValue = emptyList(), MockRepository.currentUser.employeeId) {
                    value = MockRepository.fieldForceStatus(MockRepository.currentUser.employeeId)
                }
                fieldForce.take(10).forEach { f ->
                    Text("${f.employeeName}: ${if (f.locationAgeMinutes != null) "${f.locationAgeMinutes}min ago" else "no location"}${if (f.currentVisitId != null) " · on visit" else ""}${if (f.geoViolationsToday > 0) " ⚠${f.geoViolationsToday}" else ""}", style = MaterialTheme.typography.labelSmall, color = if (f.geoViolationsToday > 0) DangerRed else TextSecondary)
                }
                Spacer(Modifier.height(8.dp))
                Text("Retailer Intelligence", fontWeight = FontWeight.Bold)
                val retailerIntel by produceState<MockRepository.RetailerIntelSummary?>(initialValue = null) { value = MockRepository.retailerIntelligence() }
                Text(
                    if (retailerIntel != null) "Credit-risk retailers: ${retailerIntel!!.creditRisk.size} · Fast-growing: ${retailerIntel!!.fastGrowing.size} · Declining: ${retailerIntel!!.declining.size}" else "Loading...",
                    style = MaterialTheme.typography.labelSmall,
                )
                Spacer(Modifier.height(8.dp))
                Text("Dealer/Distributor Performance", fontWeight = FontWeight.Bold)
                val dealerHealth by produceState<List<InventoryRepository.DealerStockHealthInsight>>(initialValue = emptyList()) {
                    value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { InventoryRepository.dealerStockHealthInsights() }
                }
                Text(
                    "Healthy: ${dealerHealth.count { it.health == com.abm.erp.inventory.StockIntelligence.StockHealth.HEALTHY }} · Warning: ${dealerHealth.count { it.health == com.abm.erp.inventory.StockIntelligence.StockHealth.WARNING }} · Critical: ${dealerHealth.count { it.health == com.abm.erp.inventory.StockIntelligence.StockHealth.CRITICAL }}",
                    style = MaterialTheme.typography.labelSmall,
                )
                Spacer(Modifier.height(8.dp))
                Text("Financial Command View", fontWeight = FontWeight.Bold)
                val finView by produceState<MockRepository.FinancialCommandView?>(initialValue = null) { value = MockRepository.financialCommandView() }
                val currentFinView = finView
                if (currentFinView != null) {
                    Text("Receivable (cached): ৳${"%,.0f".format(currentFinView.receivable)} · Pending high-value vouchers: ${currentFinView.pendingVouchers}", style = MaterialTheme.typography.labelSmall)
                    currentFinView.dataQualityWarning?.let { Text("⚠ $it", style = MaterialTheme.typography.labelSmall, color = WarningAmber) }
                } else {
                    Text("Financial data not authorized for your role.", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
                Spacer(Modifier.height(8.dp))
                Text("Approval Cockpit", fontWeight = FontWeight.Bold)
                val cockpit = remember { MockRepository.approvalCockpit() }
                cockpit.take(8).forEach { c ->
                    Text("${c.detail} — ${c.requester}, ${c.ageHours}h old${if (c.isEscalated) " ⚠ESCALATED" else ""}", style = MaterialTheme.typography.labelSmall, color = if (c.isEscalated) DangerRed else TextSecondary)
                }
                Spacer(Modifier.height(8.dp))
                Text("Approval SLA Breaches (all 6 types)", fontWeight = FontWeight.Bold)
                val slaItems = remember { MockRepository.pendingApprovalSlaItems() }
                if (slaItems.isEmpty()) {
                    Text("সময়সীমা লঙ্ঘিত কোনো approval নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                } else {
                    slaItems.take(10).forEach { item ->
                        val tierLabel = when (item.tier) {
                            com.abm.erp.data.SlaTier.CHAIRMAN_ALERT_72H -> "⚠️ Chairman Alert (72h+)"
                            com.abm.erp.data.SlaTier.ESCALATION_48H -> "🔺 Escalated (48h+)"
                            com.abm.erp.data.SlaTier.REMINDER_24H -> "🔔 Reminder (24h+)"
                            com.abm.erp.data.SlaTier.ON_TIME -> ""
                        }
                        Text(
                            "${item.approvalKind}: ${item.label} — ${item.ageHours}h — $tierLabel",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (item.tier == com.abm.erp.data.SlaTier.CHAIRMAN_ALERT_72H) DangerRed else if (item.tier == com.abm.erp.data.SlaTier.ESCALATION_48H) WarningAmber else TextSecondary,
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Product Performance (Top 5)", fontWeight = FontWeight.Bold)
                val products = remember { MockRepository.productPerformance() }
                products.take(5).forEach { p ->
                    Text("${p.productName}: ৳${"%,.0f".format(p.sales30d)}/30d, ${p.stockHealth}" + (p.marginPct?.let { " · margin ${"%.0f".format(it)}%" } ?: ""), style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { mode = AiMode.ASSISTANT },
                    colors = ButtonDefaults.buttonColors(containerColor = if (mode == AiMode.ASSISTANT) Sky else Color(0xFFF0F2F6), contentColor = if (mode == AiMode.ASSISTANT) Color.White else TextSecondary),
                    modifier = Modifier.weight(1f),
                ) { Text("🎙️ Assistant") }
                Button(
                    onClick = { mode = AiMode.ANALYSIS },
                    colors = ButtonDefaults.buttonColors(containerColor = if (mode == AiMode.ANALYSIS) Sky else Color(0xFFF0F2F6), contentColor = if (mode == AiMode.ANALYSIS) Color.White else TextSecondary),
                    modifier = Modifier.weight(1f),
                ) { Text("📊 Analysis") }
                Button(
                    onClick = { mode = AiMode.DECISION_QUERY },
                    colors = ButtonDefaults.buttonColors(containerColor = if (mode == AiMode.DECISION_QUERY) Sky else Color(0xFFF0F2F6), contentColor = if (mode == AiMode.DECISION_QUERY) Color.White else TextSecondary),
                    modifier = Modifier.weight(1f),
                ) { Text("🧭 Decisions") }
            }
        }
        if (mode == AiMode.DECISION_QUERY) {
            item {
                Text("Deterministic — no AI cap consumed. Example: \"which 5 retailers have highest overdue?\"", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                decisionAnswer?.let { ans ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(ans.question, fontWeight = FontWeight.SemiBold)
                        Text(ans.answer, style = MaterialTheme.typography.bodyMedium)
                        Text("Source: ${ans.dataSource} · ${ans.timestamp}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }
            }
        }

        item {
            Text(
                "This month's usage: $usageCount/${vm.aiMonthlyCap}",
                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                modifier = Modifier.fillMaxWidth(),
            )
            if (usageCount >= vm.aiMonthlyCap) {
                Text("⚠ Monthly AI limit reached for this company — resets next month.", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
            }
        }

        item {
            GlassCard(
                borderColor = if (mode == AiMode.ASSISTANT) Color(0xFFB45CFF).copy(alpha = 0.4f) else ElectricCyan.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    if (mode == AiMode.ASSISTANT)
                        "🎙️ Speak or type an instruction (log an order, update vacancy, post a notice) — recognized actions show here; completing them needs Firebase Blaze."
                    else
                        "📊 Ask about margin, stock, dues, or the ledger — read-only, nothing changes.",
                    style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                )
            }
        }

        items(history.filter { it.mode == mode.name.lowercase() }.reversed()) { qa ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(qa.question, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(6.dp))
                Text(qa.answer, style = MaterialTheme.typography.bodyMedium)
            }
        }

        item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = {
                        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                        if (granted) launchSpeechRecognizer(context, speechLauncher) { micError = it }
                        else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }) {
                        Icon(Icons.Filled.Mic, contentDescription = "Voice input", tint = if (mode == AiMode.ASSISTANT) Color(0xFFB45CFF) else ElectricCyan)
                    }
                    OutlinedTextField(
                        value = question,
                        onValueChange = { question = it },
                        placeholder = { Text(if (mode == AiMode.ASSISTANT) "যা করাতে চান বলুন বা লিখুন…" else "Ask about margin, stock, dues…") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyan, unfocusedBorderColor = GlassBorder),
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(onClick = { submit() }) {
                        Icon(Icons.Filled.Send, contentDescription = "Ask", tint = ElectricCyan)
                    }
                }
                micError?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = DangerRed, modifier = Modifier.padding(start = 48.dp)) }
            }
        }

        if (mode == AiMode.ANALYSIS) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Daily prescription feed", style = MaterialTheme.typography.titleMedium)
                    val context = androidx.compose.ui.platform.LocalContext.current
                    val prescriptionsForExport = vm.prescriptions()
                    com.abm.erp.core.ModuleActionBar(
                        onExport = {
                            val header = "Title,Body,Severity\n"
                            val rows = prescriptionsForExport.joinToString("\n") { p -> com.abm.erp.core.toCsvRow(p.title, p.body, p.severity) }
                            val file = java.io.File(context.getExternalFilesDir(null), "prescriptions_${System.currentTimeMillis()}.csv")
                            file.writeText(header + rows)
                            android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                        },
                        onShare = {
                            val summary = "Boardroom Prescriptions\n" + prescriptionsForExport.take(20).joinToString("\n") { "${it.title}: ${it.body}" }
                            val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, summary) }
                            try { context.startActivity(Intent.createChooser(intent, "Prescriptions")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                        },
                    )
                }
            }
            val prescriptionList = vm.prescriptions()
            if (prescriptionList.isEmpty()) {
                item { Text("এই মুহূর্তে কোনো risk signal নেই — সব ঠিক আছে।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
            }
            items(prescriptionList) { p ->
                val color = when (p.severity) { RiskBand.RED -> DangerRed; RiskBand.YELLOW -> WarningAmber; RiskBand.GREEN -> SuccessGreen }
                GlassCard(borderColor = color.copy(alpha = 0.6f), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(p.title, fontWeight = FontWeight.Bold, color = color, modifier = Modifier.weight(1f))
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Prescription", entityId = p.id, entityLabel = p.title,
                            shareText = "${p.title}\n${p.body}\nSeverity: ${p.severity}",
                            csvHeader = "Title,Body,Severity", csvRow = com.abm.erp.core.toCsvRow(p.title, p.body, p.severity),
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(p.body, style = MaterialTheme.typography.bodyMedium)
                }
            }
            item {
                val health = vm.businessHealthScore()
                Text("Business Health Score", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("${health.score}/100", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = when { health.score >= 65 -> SuccessGreen; health.score >= 45 -> WarningAmber; else -> DangerRed })
                        Text(health.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Sales ${health.salesTrendComponent}/25 · Collection ${health.collectionComponent}/25 · Stock ${health.stockHealthComponent}/25 · Risk ${health.riskComponent}/25", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
            item {
                Spacer(Modifier.height(10.dp))
                Text("Smart Recommendations", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                vm.smartRecommendations().forEach { rec ->
                    GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
                        Text(rec, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                Spacer(Modifier.height(6.dp))
                val invForecast = vm.inventoryForecast()
                if (invForecast.isNotEmpty()) {
                    Text("Inventory Forecast — days until stockout", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    invForecast.take(5).forEach { (name, days) ->
                        GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                Text(if (days >= 999) "N/A" else "$days days left", color = if (days < 7) DangerRed else WarningAmber, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            item {
                Spacer(Modifier.height(10.dp))
                Text("Risk Alerts", style = MaterialTheme.typography.titleMedium)
            }
            items(vm.riskAlerts()) { r ->
                GlassCard(borderColor = (if (r.severity == RiskBand.RED) DangerRed else WarningAmber).copy(alpha = 0.6f), modifier = Modifier.fillMaxWidth()) {
                    Text(r.category, fontWeight = FontWeight.Bold, color = if (r.severity == RiskBand.RED) DangerRed else WarningAmber, style = MaterialTheme.typography.labelMedium)
                    Text(r.message, style = MaterialTheme.typography.bodySmall)
                }
            }
            item {
                Spacer(Modifier.height(10.dp))
                val collectionF = vm.collectionForecast30d()
                val productionF = vm.productionForecast30d()
                Text("Collection & Production Forecast (30d)", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Projected Collection", style = MaterialTheme.typography.bodySmall)
                        Text("৳${"%,.0f".format(collectionF)}", color = SuccessGreen, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(4.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Projected Production Output", style = MaterialTheme.typography.bodySmall)
                        Text("${"%,.0f".format(productionF)} units", color = ElectricCyan, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Spacer(Modifier.height(10.dp))
                Text("Demand Forecast — top 5 products", style = MaterialTheme.typography.titleMedium)
            }
            items(vm.demandForecast().take(5)) { row ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(row.productName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("${"%,.1f".format(row.projectedNext30Days)} units/30d", color = ElectricCyan, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Spacer(Modifier.height(10.dp))
                Text("Advanced Trend Analysis", style = MaterialTheme.typography.titleMedium)
                Text("Custom date-range, real linear-regression trend (একে অন্য জায়গার fixed ৩০/৯০-দিন projection-এর চেয়ে বাস্তব statistical fit)।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Spacer(Modifier.height(6.dp))
                var fromDate by remember { mutableStateOf(java.time.LocalDate.now().minusDays(30)) }
                var toDate by remember { mutableStateOf(java.time.LocalDate.now()) }
                var trendResult by remember { mutableStateOf<MockRepository.TrendAnalysisResult?>(null) }
                val trendScope = rememberCoroutineScope()
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { fromDate = fromDate.minusDays(7) }) { Text("From: $fromDate ◀") }
                    OutlinedButton(onClick = { toDate = toDate.plusDays(1).coerceAtMost(java.time.LocalDate.now()) }) { Text("To: $toDate ▶") }
                }
                Spacer(Modifier.height(6.dp))
                Button(onClick = { trendScope.launch { trendResult = MockRepository.computeSalesTrendAnalysis(null, fromDate, toDate) } }) { Text("বিশ্লেষণ করুন") }
                trendResult?.let { result ->
                    Spacer(Modifier.height(10.dp))
                    com.abm.erp.ui.components.TrendLineChart(
                        values = result.dataPoints.map { it.value },
                        lineColor = if (result.slopePerDay >= 0) SuccessGreen else DangerRed,
                        valueFormatter = { "৳${"%,.0f".format(it)}" },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(6.dp))
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text("Trend: ${if (result.slopePerDay > 0) "📈 বাড়ছে" else if (result.slopePerDay < 0) "📉 কমছে" else "➖ স্থির"} (৳${"%,.1f".format(result.slopePerDay)}/দিন)", fontWeight = FontWeight.Bold)
                        Text("পরবর্তী একই-দৈর্ঘ্যের period-এর projection: ৳${"%,.0f".format(result.projectedNextPeriodTotal)}", style = MaterialTheme.typography.bodySmall)
                        Text("Fit reliability (R²): ${"%.0f".format(result.rSquared * 100)}% — যত বেশি, trend তত নির্ভরযোগ্য", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                }
            }
            item {
                Spacer(Modifier.height(6.dp))
                Text("Sales Forecast — top 5 dealers by 90-day sales", style = MaterialTheme.typography.titleMedium)
                Text("দৈনিক গড় বিক্রয় থেকে সরল projection — বাস্তব দৈনিক time-series নেই বলে এটা full ML forecast না, কিন্তু আসল ডেটা থেকে হিসাব করা।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            items(dealers.sortedByDescending { it.salesLast90Days }.take(5)) { d ->
                val forecast = vm.forecastForDealer(d)
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(forecast.scopeName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("Daily avg: ৳${"%,.0f".format(forecast.dailyAverage)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("৳${"%,.0f".format(forecast.projectedNext30Days)} / 30d", color = ElectricCyan, fontWeight = FontWeight.Bold)
                            Text(forecast.trend, style = MaterialTheme.typography.labelSmall, color = when (forecast.trend) { "GROWING" -> SuccessGreen; "DECLINING" -> DangerRed; else -> WarningAmber })
                        }
                    }
                }
            }
        }
    }
}

/** Launches Android's own on-device speech recognizer UI — no server round-trip, works fully offline-capable on most devices, free. */
private fun launchSpeechRecognizer(
    context: android.content.Context,
    launcher: androidx.activity.result.ActivityResultLauncher<Intent>,
    onError: (String) -> Unit,
) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale("bn", "BD").toString())
        putExtra(RecognizerIntent.EXTRA_PROMPT, "বলুন…")
    }
    try {
        launcher.launch(intent)
    } catch (e: android.content.ActivityNotFoundException) {
        onError("এই ডিভাইসে speech recognition সমর্থিত না — টাইপ করুন।")
    }
}
