package com.abm.erp.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.first

// ============================================================================
// v113-87 Phase 5 — the Expense group, moved out of MockRepository.kt:
// submitExpense, approveExpense (the ONLY point that posts to the ledger),
// rejectExpense. Same extension-function mechanics as Phases 2-4; bodies
// untouched; call sites (ExpenseWorkspace, ApprovalRouting-driven flows)
// textually identical.
// ============================================================================

fun MockRepository.submitExpense(category: String, amount: Double, description: String, paymentMethod: ExpensePaymentMethod, attachmentUri: String? = null): Expense? {
    if (!PermissionManager.canCurrentUser("bill", PermissionAction.CREATE)) {
        logAudit("Expense", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "SUBMIT")
        return null
    }
    if (amount <= 0.0 || category.isBlank()) return null
    val expense = Expense(
        id = "EXP-${java.util.UUID.randomUUID().toString().take(8)}", expenseNo = "", companyId = currentUser.companyId,
        category = category, amount = amount, description = description, paymentMethod = paymentMethod,
        submittedBy = currentUser.name, submittedByEmployeeId = currentUser.employeeId, attachmentUri = attachmentUri,
    )
    launchInRepoScope {
        val expenseNo = generateNumber("EXPENSE")
        val withNo = expense.copy(expenseNo = expenseNo)
        database.expenseDao().upsert(withNo.toEntity())
        qrSyncCollection("expenses").document(withNo.id).set(withNo.toEntity())
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push expense failed", it) }
        logAudit("Expense", withNo.id, "SUBMIT", newValue = withNo)
        raiseApprovalRequest(ApprovalType.EXPENSE, "$expenseNo — $category: ৳${"%,.0f".format(amount)}", "Expense", withNo.id)
    }
    return expense
}

fun MockRepository.approveExpense(expenseId: String): Boolean {
    if (!PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)) {
        logAudit("Expense", expenseId, "DENY", oldValue = currentUser.role.name, newValue = "APPROVE")
        return false
    }
    launchInRepoScope {
        val existing = database.withTransaction {
            val current = database.expenseDao().getAll().first().firstOrNull { it.id == expenseId } ?: return@withTransaction null
            if (current.status != "PENDING") {
                logAudit("Expense", expenseId, "DENY", oldValue = current.status, newValue = "APPROVE — already ${current.status}")
                return@withTransaction null
            }
            database.expenseDao().setStatus(expenseId, "APPROVED", currentUser.name, null, System.currentTimeMillis())
            current
        } ?: return@launchInRepoScope
        qrSyncCollection("expenses").document(expenseId).update(mapOf("status" to "APPROVED", "approvedBy" to currentUser.name, "approvedAtEpochMillis" to System.currentTimeMillis()))
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push expense-approve failed", it) }
        // Real account/ledger posting — only now, on approval, never at submission.
        addLedgerEntry(LedgerEntryType.OUT, existing.category, existing.description.ifBlank { "Expense ${existing.expenseNo}" }, existing.amount, currentUser.name)
        logAudit("Expense", expenseId, "APPROVE_AND_POST", oldValue = "PENDING", newValue = "APPROVED — ledger posted")
        createNotification(NotificationCategory.APPROVAL, "Expense Approved", "${existing.expenseNo} — ৳${"%,.0f".format(existing.amount)}")
    }
    return true
}

fun MockRepository.rejectExpense(expenseId: String, reason: String): Boolean {
    if (!PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)) {
        logAudit("Expense", expenseId, "DENY", oldValue = currentUser.role.name, newValue = "REJECT")
        return false
    }
    if (reason.isBlank()) return false
    launchInRepoScope {
        val existing = database.withTransaction {
            val current = database.expenseDao().getAll().first().firstOrNull { it.id == expenseId } ?: return@withTransaction null
            if (current.status != "PENDING") {
                logAudit("Expense", expenseId, "DENY", oldValue = current.status, newValue = "REJECT — already ${current.status}")
                return@withTransaction null
            }
            database.expenseDao().setStatus(expenseId, "REJECTED", null, reason, null)
            current
        } ?: return@launchInRepoScope
        qrSyncCollection("expenses").document(expenseId).update(mapOf("status" to "REJECTED", "rejectReason" to reason))
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push expense-reject failed", it) }
        logAudit("Expense", expenseId, "REJECT", oldValue = "PENDING", newValue = "REJECTED", reason = reason)
        createNotification(NotificationCategory.APPROVAL, "Expense Rejected", "${existing.expenseNo}: $reason")
    }
    return true
}
