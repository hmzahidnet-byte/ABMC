package com.abm.erp.core

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.data.CampaignChannel
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

/**
 * v113-77 — the person's own CRM definition, finally in the right place: "HQ/Chairman
 * reaching dealers and retailers directly — promotional notices, special discounts,
 * extras." One shared composer, hosted by DMS as "Message / CRM" (dealer zones) and by
 * RMS as "Relation" (retailer markets). Shared component, not shared screen — the same
 * relationship every other core/ piece has to the modules.
 *
 * Backed entirely by the real, existing campaign system (`broadcastCampaign` /
 * `campaigns`), which already computes an honest sentCount from actual active parties
 * in the target zone (Part S fix) — no new send infrastructure invented here.
 */
@Composable
fun PartyCampaignSection(
    /** e.g. "Dealer" / "Retailer" — display only. */
    audienceLabel: String,
    /** The zones/markets the composer can target, from the caller's cascade-scoped list. */
    zones: List<String>,
) {
    val campaigns by MockRepository.campaigns.collectAsState()
    var message by remember { mutableStateOf("") }
    var zone by remember { mutableStateOf<String?>(null) }
    var channel by remember { mutableStateOf(CampaignChannel.SMS) }

    Column(Modifier.fillMaxSize()) {
        Text("$audienceLabel-দের কাছে সরাসরি বার্তা", fontWeight = FontWeight.SemiBold, color = TextPrimary)
        Text(
            "Offer, due reminder, বিশেষ ছাড় — যেকোনো ঘোষণা এক জায়গা থেকে।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = message, onValueChange = { message = it },
            label = { Text("বার্তা") }, minLines = 2, modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CampaignChannel.values().forEach { c ->
                FilterChip(selected = channel == c, onClick = { channel = c }, label = { Text(c.name) })
            }
        }
        Spacer(Modifier.height(6.dp))
        if (zones.isEmpty()) {
            Text("আপনার এলাকায় কোনো zone/market পাওয়া যায়নি।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        } else {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                zones.forEach { z ->
                    FilterChip(selected = zone == z, onClick = { zone = z }, label = { Text(z) })
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                zone?.let { MockRepository.broadcastCampaign(channel, message, it) }
                message = ""
            },
            enabled = message.isNotBlank() && zone != null,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("পাঠান") }

        Spacer(Modifier.height(14.dp))
        Text("পাঠানো Campaign (${campaigns.size})", fontWeight = FontWeight.SemiBold, color = TextPrimary)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(campaigns, key = { it.id }) { c ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(c.channel.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("→ ${c.targetZone}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Text(c.message, style = MaterialTheme.typography.bodySmall)
                    Text("পৌঁছেছে: ${c.sentCount}", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                }
            }
            if (campaigns.isEmpty()) item { Text("এখনো কোনো campaign পাঠানো হয়নি।", color = TextSecondary) }
        }
    }
}
