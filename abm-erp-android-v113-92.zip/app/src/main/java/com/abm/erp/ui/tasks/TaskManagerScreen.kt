package com.abm.erp.ui.tasks

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

class TaskManagerViewModel : ViewModel() {
    val tasks = MockRepository.tasks
    val deletedTasks = MockRepository.deletedTasks
    fun addTask(title: String, assignee: String) = MockRepository.addTask(title, assignee)
    fun setTaskDone(id: String, done: Boolean) = MockRepository.setTaskDone(id, done)
    fun deleteTask(id: String) = MockRepository.deleteTask(id)
    fun restoreTask(id: String) = MockRepository.restoreTask(id)
    fun duplicateTask(id: String) = MockRepository.duplicateTask(id)
}

@Composable
fun TaskManagerScreen(vm: TaskManagerViewModel = viewModel()) {
    val tasks by vm.tasks.collectAsState()
    val deletedTasks by vm.deletedTasks.collectAsState()
    var title by remember { mutableStateOf("") }
    var assignee by remember { mutableStateOf("") }
    var showTrash by remember { mutableStateOf(false) }

    val pendingTasks = tasks.count { it.status == com.abm.erp.data.TaskStatus.PENDING }
    val inProgressTasks = tasks.count { it.status == com.abm.erp.data.TaskStatus.IN_PROGRESS }
    val completedTasks = tasks.count { it.status == com.abm.erp.data.TaskStatus.COMPLETED }

    Column(Modifier.fillMaxSize()) {
        com.abm.erp.core.ModuleWorkspaceHeader("Task Manager", "✅", 0xFF3DDC97, 0xFF1FA972, iconVector = Icons.Filled.TaskAlt, miniDashboard = {
            com.abm.erp.core.ModuleStat("Pending", "$pendingTasks", if (pendingTasks > 0) WarningAmber else SuccessGreen)
            com.abm.erp.core.ModuleStat("In Progress", "$inProgressTasks", TextPrimary)
            com.abm.erp.core.ModuleStat("Completed", "$completedTasks", SuccessGreen)
            com.abm.erp.core.ModuleStat("Total", "${tasks.size}", TextPrimary)
        }, quickActions = {
            AssistChip(onClick = { showTrash = !showTrash }, label = { Text(if (showTrash) "← Back to tasks" else "🗑 Trash (${deletedTasks.size})") })
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("TaskItem", "Task"))
        })
        Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                val context = androidx.compose.ui.platform.LocalContext.current
                com.abm.erp.core.ModuleActionBar(
                    onExport = {
                        val header = "Title,Assignee,Status\n"
                        val rows = tasks.joinToString("\n") { t -> com.abm.erp.core.toCsvRow(t.title, t.assignee, t.status) }
                        val file = java.io.File(context.getExternalFilesDir(null), "tasks_${System.currentTimeMillis()}.csv")
                        file.writeText(header + rows)
                        android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                    },
                    onShare = {
                        val summary = "Tasks (${tasks.size})\n" + tasks.take(20).joinToString("\n") { "${it.title} — ${it.assignee} (${it.status})" }
                        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                        try { context.startActivity(android.content.Intent.createChooser(intent, "Tasks")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                    },
                )
                TextButton(onClick = { showTrash = !showTrash }) {
                    Text(if (showTrash) "← Back to tasks" else "🗑 Trash (${deletedTasks.size})")
                }
            }
        Spacer(Modifier.height(12.dp))
        if (showTrash) {
            if (deletedTasks.isEmpty()) Text("Trash খালি।", color = TextSecondary)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(deletedTasks, key = { it.id }) { task ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Column {
                                Text(task.title, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                                Text(task.assignee, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                            TextButton(onClick = { vm.restoreTask(task.id) }) { Text("Restore") }
                        }
                    }
                }
            }
            return@Column
        }
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task title") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = assignee, onValueChange = { assignee = it }, label = { Text("Assign to (e.g. SR — Rafiq)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    if (title.isBlank()) return@Button
                    vm.addTask(title, assignee.ifBlank { "Unassigned" })
                    title = ""; assignee = ""
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Add task") }
        }
        Spacer(Modifier.height(16.dp))
        if (tasks.isEmpty()) {
            Text("No tasks yet.", color = TextSecondary)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(tasks, key = { it.id }) { task ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Checkbox(checked = task.done, onCheckedChange = { vm.setTaskDone(task.id, it) })
                            Column {
                                Text(
                                    task.title,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                    textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None,
                                )
                                Text(task.assignee, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                        TextButton(onClick = { vm.deleteTask(task.id) }) { Text("🗑") }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Task", entityId = task.id, entityLabel = task.title,
                            shareText = "Task: ${task.title}\nAssigned to: ${task.assignee}\nDone: ${task.done}",
                            isDeleted = task.isDeleted,
                            recordStatus = task.status.name,
                            onDuplicate = { vm.duplicateTask(task.id) },
                            onArchive = { vm.deleteTask(task.id) },
                            onRestore = { vm.restoreTask(task.id) },
                            csvHeader = "Title,Assignee,Done",
                            csvRow = com.abm.erp.core.toCsvRow(task.title, task.assignee, task.done),
                        )
                    }
                }
            }
        }
    }
    }
}
