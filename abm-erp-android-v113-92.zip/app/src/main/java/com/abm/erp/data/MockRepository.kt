package com.abm.erp.data

import android.content.Context
import com.abm.erp.location.GeoLock
import com.abm.erp.location.LocationVerification
import com.abm.erp.executive.ExecutiveIntelligence
import com.abm.erp.data.room.AppDatabase
import com.abm.erp.data.room.ApprovalRequestEntity
import com.abm.erp.data.room.AttendanceRecordEntity
import com.abm.erp.data.room.BoardroomQueryEntity
import com.abm.erp.data.room.Converters
import com.abm.erp.data.room.CourierPartnerEntity
import com.abm.erp.data.room.DealerEntity
import com.abm.erp.data.room.EngagementCampaignEntity
import com.abm.erp.data.room.FieldEmployeeRouteEntity
import com.abm.erp.data.room.AuditLogEntity
import com.abm.erp.data.room.LedgerEntryEntity
import com.abm.erp.data.room.PaymentProofEntity
import com.abm.erp.data.room.PayrollLineEntity
import com.abm.erp.data.room.ProductionBatchEntity
import com.abm.erp.data.room.RawMaterialLotEntity
import com.abm.erp.data.room.RetailOrderEntity
import com.abm.erp.data.room.InvoiceEntity
import com.abm.erp.data.room.ShipmentEntity
import com.abm.erp.data.room.TaskItemEntity
import com.abm.erp.data.room.QuotationEntity
import com.abm.erp.data.room.DeliveryChallanEntity
import com.abm.erp.data.room.SalesReturnEntity
import com.abm.erp.data.room.PartyLedgerEntryEntity
import com.abm.erp.data.room.PartyCollectionEntity
import com.abm.erp.data.room.DiscountRuleEntity
import com.abm.erp.data.room.SalesRouteEntity
import com.abm.erp.data.room.VisitLogEntity
import com.abm.erp.data.room.AttachmentEntity
import com.abm.erp.data.room.BillOfMaterialsEntity
import com.abm.erp.data.room.EmployeeLifecycleEventEntity
import com.abm.erp.data.room.LeaveRequestEntity
import com.abm.erp.data.room.MachineLogEntity
import com.abm.erp.data.room.NotificationEntryEntity
import com.abm.erp.data.room.ProductionLossEntity
import com.abm.erp.data.room.ProductionOrderEntity
import com.abm.erp.data.room.QualityCheckEntity
import com.abm.erp.data.room.RetailerEntity
import com.abm.erp.data.room.RoleDefinitionEntity
import com.abm.erp.data.room.TerritoryEntity
import com.abm.erp.data.room.VehicleEntity
import com.abm.erp.data.room.VehicleLocationPingEntity

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import androidx.room.withTransaction
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.runBlocking
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneOffset

/**
 * Single source of truth for the whole app, now backed by a real on-device
 * Room database instead of an in-memory list. The public API (every val and
 * fun below) is intentionally identical to the original in-memory version,
 * so no UI Composable needs to change: only what's *inside* these functions
 * changed, from list mutation to real DB reads/writes.
 *
 * Call MockRepository.init(context) once, from ABMApplication.onCreate,
 * before any Composable reads from it.
 */
object MockRepository {

    private lateinit var db: AppDatabase

    /**
     * Fires secure-QR activation for a record that has just reached the lifecycle point
     * where it becomes scannable (invoice finalised, dealer approved, batch confirmed…).
     *
     * Deliberately fire-and-forget on the existing repository scope: QR issuance must
     * never change, delay or fail the business operation that triggered it. If issuance
     * fails the record is still correct — it simply has no QR yet, and one can be issued
     * later from the workspace. Wrapped in runCatching for the same reason.
     */
    /**
     * Invalidates a record's QR when the record itself is cancelled, rejected or deleted.
     * Same fire-and-forget contract as activateQrFor — a failure here must never block the
     * cancellation. The QR row is not deleted, only marked REVOKED, so the history of what
     * was printed and when it stopped being valid stays auditable.
     */
    internal fun revokeQrFor(entityType: String, entityId: String, reason: String) {
        if (entityId.isBlank()) return
        scope.launch {
            runCatching {
                QrRegistry.activeFor(entityType, entityId)?.let { QrRegistry.revoke(it.qrId, reason) }
            }.onFailure { com.abm.erp.config.AppLog.w("MockRepository", "QR revoke failed for $entityType/$entityId", it) }
        }
    }

    internal fun activateQrFor(entityType: String, entityId: String) {
        if (entityId.isBlank()) return
        scope.launch {
            runCatching { QrRegistry.issue(entityType, entityId) }
                .onFailure { com.abm.erp.config.AppLog.w("MockRepository", "QR activation failed for $entityType/$entityId", it) }
        }
    }

    /** Same AppDatabase instance, exposed read-only for other data-layer objects in this
     *  package (QrRegistry) that must share one database and one transaction scope.
     *  Deliberately internal, not public: UI code still has no direct database access. */
    internal val database: AppDatabase get() = db
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ---- Cross-device sync status — visible "Pending/Synced/Failed" indicator ----
    private var pendingSyncCount = java.util.concurrent.atomic.AtomicInteger(0)
    private val _syncStatus = MutableStateFlow(SyncStatus.SYNCED)
    val syncStatus: StateFlow<SyncStatus> = _syncStatus.asStateFlow()

    /** Every push call routes its Firestore Task through here so the badge reflects real in-flight state, even with several pushes overlapping. */
    private fun trackSync(task: com.google.android.gms.tasks.Task<Void>) {
        pendingSyncCount.incrementAndGet()
        _syncStatus.value = SyncStatus.PENDING
        task.addOnCompleteListener {
            val remaining = pendingSyncCount.decrementAndGet()
            if (!it.isSuccessful) { _syncStatus.value = SyncStatus.FAILED; return@addOnCompleteListener }
            if (remaining <= 0) _syncStatus.value = SyncStatus.SYNCED
        }
    }

    // Section 14 — per-record sync feedback. The global syncStatus badge
    // above only ever reflects the app's OVERALL state; it can't tell a
    // user "THIS employee/dealer/retailer specifically failed to sync"
    // without a schema change (a per-row syncStatus column), which this
    // pass is not adding. This lightweight, in-memory, schema-free set
    // fills that gap: any record whose LATEST push failed appears here
    // until it's retried successfully; UI can check `id in failedSyncIds`
    // to show a real per-item "Sync pending — retry" indicator.
    private val _failedSyncIds = MutableStateFlow<Set<String>>(emptySet())
    val failedSyncIds: StateFlow<Set<String>> = _failedSyncIds.asStateFlow()

    private fun trackRecordSync(recordId: String, task: com.google.android.gms.tasks.Task<Void>) {
        trackSync(task)
        task.addOnCompleteListener {
            _failedSyncIds.update { current -> if (it.isSuccessful) current - recordId else current + recordId }
        }
    }

    fun init(context: Context) {
        if (::db.isInitialized) return
        db = AppDatabase.getInstance(context)
        seedIfEmpty()
        wireFlows()
    }

    // ================= Cross-device sync (Sales Chain / Dealer / HR) =================
    // Same idea as FirebaseSync's Complaint Box, but merged straight into Room
    // instead of a separate parallel StateFlow — this way every existing
    // screen keeps reading MockRepository.orders/dealers/payroll exactly as
    // before, with zero UI changes. A write on any device pushes here
    // (fire-and-forget, never blocks the local save); a listener on every
    // device pulls remote changes back into its own Room via the same
    // upsert() calls the local code already uses.
    private val firestoreDb by lazy { com.google.firebase.firestore.FirebaseFirestore.getInstance() }
    internal var syncCompanyId: String? = null  // v113-88: read/written by SyncEngine.kt extensions; also read by two push-payload builders below — hence internal, not moved


    private fun syncCollection(name: String) =
        firestoreDb.collection("companies").document(CompanyContext.current.value ?: "_unset").collection(name)

    /** Company-scoped collection handle for QrRegistry, which lives in this package but
     *  outside this object. Same path builder every other collection uses, so QR data lands
     *  under the same tenant document and inherits the same isolation. */
    internal fun qrSyncCollection(name: String) = syncCollection(name)

    /** Product-wise stock at one dealer, newest-tracked-first is not needed — the screen
     *  itself sorts by quantity. */
    // The Entity is returned directly rather than mapped to a separate domain type — this
    // table has no business logic of its own (no calculations, no status transitions), so a
    // parallel domain class would just be a second name for the same five fields.
    fun dealerStockLinesFor(dealerId: String) =
        db.dealerStockLineDao().observeForDealer(dealerId)

    /** v113-75 — retailer-side mirror. */
    fun retailerStockLinesFor(retailerId: String) =
        db.retailerStockLineDao().observeForRetailer(retailerId)

    /** Lets QrRegistry reuse this repository's IO scope rather than creating a second one. */
    internal fun launchInRepoScope(block: suspend () -> Unit) {
        scope.launch { block() }
    }









    // ---- Retailer / Territory / RoleDefinition (Data Design step's new structures) ----
    // Same shape as every other collection above: listen -> upsert locally,
    // and a matching push* function below for whenever a create/edit flow is
    // wired to call it (Foundation Layer's Data Integrity + RBAC steps).
    /**
     * Section 5 — "Pull-to-refresh where appropriate". Implemented as a
     * real manual re-sync trigger rather than a swipe gesture: adding the
     * swipe-gesture pull-to-refresh library (androidx.compose.material's
     * pullRefresh, or M3's newer PullToRefreshBox) would mean a new Gradle
     * dependency whose exact API surface can't be compile-verified in this
     * environment — a real risk of breaking the build was judged worse
     * than a manual refresh button. Re-establishing the Firestore listener
     * forces a fresh server fetch (not just a re-read of local cache),
     * which is the actual point of "refresh".
     */
    fun refreshRetailers() = listenRetailersRemote()



    // v89 fix — these four listeners were completely missing, meaning
    // retailer_location_history/employee_location_snapshots/location_alerts/
    // trusted_devices were write-only to Firestore: data one device pushed
    // never came back down to any OTHER device. For Section 20's "Manager
    // Location Review" this was a critical gap — a manager would only ever
    // see alerts their OWN device happened to raise, never a field
    // employee's. Same real pattern as every other listenXRemote() above.









    // Note — administrativeLocations intentionally has NO Firestore listener:
    // it's a bundled, locally-imported static reference dataset (every
    // device already has the same source-of-truth asset bundle), so a
    // full-collection Firestore sync would just be a wasteful, costly
    // re-download of ~5100 documents with no real benefit. companyMarkets
    // (small, genuinely user-generated, needs cross-device visibility) DOES sync.

    // Part A — deliberately NO blanket Firestore listener for userAccounts.
    // Syncing every account's PIN hash to every device's local Room cache
    // would be a real, avoidable exposure even with Firestore rules
    // enforcing per-document read access — defense in depth means this
    // device simply never holds hashes it doesn't need. Instead, a
    // targeted one-time fetch pulls only the ONE account a specific
    // employee needs (e.g. their first login on a new phone), gated by
    // the same isSelf()/isExecutive() Firestore rule.
    suspend fun fetchUserAccountFromCloud(employeeProfileId: String): Boolean {
        return try {
            val query = syncCollection("userAccounts").whereEqualTo("employeeProfileId", employeeProfileId).limit(1).get().await()
            val doc = query.documents.firstOrNull() ?: return false
            val entity = doc.toObject(com.abm.erp.data.room.UserAccountEntity::class.java) ?: return false
            db.userAccountDao().upsert(entity)
            true
        } catch (e: Exception) {
            com.abm.erp.config.AppLog.w("MockRepository", "fetchUserAccountFromCloud failed", e)
            false
        }
    }





    // ---- Module 4/7/8 listeners (Sales Mgmt, DMS, Retailer/Outlet) ----
















    private fun pushRetailer(e: com.abm.erp.data.room.RetailerEntity) {
        val task = syncCollection("retailers").document(e.id).set(e)
        task.addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "pushRetailer failed", it) }
        trackRecordSync(e.id, task)
    }

    private fun pushTerritory(e: com.abm.erp.data.room.TerritoryEntity) {
        syncCollection("territories").document(e.id).set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "pushTerritory failed", it) }
    }

    private fun pushRoleDefinition(e: com.abm.erp.data.room.RoleDefinitionEntity) {
        syncCollection("roleDefinitions").document(e.role).set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "pushRoleDefinition failed", it) }
    }











    /** Fire-and-forget push — same resilience rule as the rest of the app: a failed push logs and moves on, never blocks or crashes the local save that already succeeded in Room. */
    private fun pushRetailOrder(e: RetailOrderEntity) {
        syncCollection("retailOrders").document(e.id).set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "pushRetailOrder failed", it) }
    }

    private fun pushDealer(e: DealerEntity) {
        val task = syncCollection("dealers").document(e.id).set(e)
        task.addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "pushDealer failed", it) }
        trackRecordSync(e.id, task)
    }

    /**
     * Stock and due-balance are shared counters — two phones could adjust the
     * SAME dealer within seconds of each other. A full-document push here
     * would silently overwrite whichever write lands second (the exact
     * "money/stock conflict" risk flagged earlier). Firestore's atomic
     * increment() avoids that: both increments land, in whatever order they
     * arrive, with no lost update.
     */
    internal fun pushDealerIncrement(dealerId: String, stockDelta: Int, dueDelta: Double) {  // v113-91: CollectionsEngine.kt needs this from another file
        val updates = mutableMapOf<String, Any>()
        if (stockDelta != 0) updates["stockUnits"] = com.google.firebase.firestore.FieldValue.increment(stockDelta.toLong())
        if (dueDelta != 0.0) updates["dueBalance"] = com.google.firebase.firestore.FieldValue.increment(dueDelta)
        if (updates.isEmpty()) return
        val task = syncCollection("dealers").document(dealerId).set(updates, com.google.firebase.firestore.SetOptions.merge())
        task.addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "pushDealerIncrement failed", it) }
        trackSync(task)
    }

    private fun pushAttendance(e: AttendanceRecordEntity) {
        syncCollection("attendance").document("${e.employeeId}_${e.dateEpochDay}").set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "pushAttendance failed", it) }
    }

    private fun pushPayroll(e: PayrollLineEntity) {
        syncCollection("payroll").document(e.employeeId).set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "pushPayroll failed", it) }
    }

    private fun pushSalesInvoice(e: InvoiceEntity) {
        val task = syncCollection("salesInvoices").document(e.id).set(e)
        task.addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "pushSalesInvoice failed", it) }
        trackRecordSync(e.id, task)
    }

    private fun pushLedgerEntry(e: LedgerEntryEntity) {
        syncCollection("ledger").document(e.id).set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "pushLedgerEntry failed", it) }
    }

    /**
     * The one shared audit-trail writer — every module calls this instead of
     * building its own logging. oldValue/newValue are passed as whatever
     * domain object was affected; their .toString() becomes the JSON-ish
     * snapshot (simple, readable, no serialization library needed for an
     * audit trail whose job is "what changed", not machine-parsing).
     */
    fun logAudit(entityType: String, entityId: String, action: String, oldValue: Any? = null, newValue: Any? = null, reason: String? = null, relatedApprovalId: String? = null) {
        scope.launch { logAuditAwaited(entityType, entityId, action, oldValue, newValue, reason, relatedApprovalId) }
    }

    /** Same write as logAudit, but suspends until the Room insert genuinely completes instead of firing
     * on this object's own scope.launch. For callers (e.g. InventoryRepository.reportDamage) that must
     * only report success to their own caller after the audit write has actually happened. */
    suspend fun logAuditAwaited(entityType: String, entityId: String, action: String, oldValue: Any? = null, newValue: Any? = null, reason: String? = null, relatedApprovalId: String? = null) {
        val deviceId = com.abm.erp.ABMApplication.currentDeviceId()
        val lastKnownLocation = _liveLocations.value.firstOrNull { it.employeeId == currentUser.employeeId }
        val entry = AuditLogEntity(
            id = java.util.UUID.randomUUID().toString(),
            entityType = entityType, entityId = entityId, action = action,
            performedBy = currentUser.name, performedByRole = currentUser.role.name,
            oldValueJson = oldValue?.toString(), newValueJson = newValue?.toString(),
            reason = reason, relatedApprovalId = relatedApprovalId,
            deviceId = deviceId, gpsLat = lastKnownLocation?.lat, gpsLng = lastKnownLocation?.lng, syncStatus = "PENDING",
            timestampEpochMillis = System.currentTimeMillis(),
        )
        db.auditLogDao().upsert(entry)
        pushAuditLog(entry)
    }

    private fun pushAuditLog(e: AuditLogEntity) {
        syncCollection("auditLog").document(e.id).set(e)
            .addOnSuccessListener { scope.launch { db.auditLogDao().upsert(e.copy(syncStatus = "SYNCED")) } }
            .addOnFailureListener {
                com.abm.erp.config.AppLog.w("MockRepository", "pushAuditLog failed", it)
                scope.launch { db.auditLogDao().upsert(e.copy(syncStatus = "FAILED")) }
            }
    }


    // ---- Market Analysis's pre-computed summary — the hourlyMarketSummary Cloud Function writes here so the screen doesn't have to sum every dealer itself ----
    data class ZoneSummary(val zone: String, val salesLast90Days: Double, val dueBalance: Double)
    internal val _marketSummary = MutableStateFlow<List<ZoneSummary>>(emptyList()) // v113-88: written by SyncEngine.listenMarketSummaryRemote — the one listener whose flow is in-memory, not Room-backed
    val marketSummary: StateFlow<List<ZoneSummary>> = _marketSummary.asStateFlow()


    private fun pushCampaign(e: EngagementCampaignEntity) {
        syncCollection("campaigns").document(e.id).set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "pushCampaign failed", it) }
    }

    private fun pushTask(e: TaskItemEntity) {
        val task = syncCollection("tasks").document(e.id).set(e)
        task.addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "pushTask failed", it) }
        trackSync(task)
    }

    internal fun pushApproval(e: ApprovalRequestEntity) {  // v113-91: ApprovalsEngine.kt needs this from another file
        syncCollection("approvals").document(e.id).set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "pushApproval failed", it) }
    }

    private fun pushShipment(e: ShipmentEntity) {
        syncCollection("shipments").document(e.id).set(e)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "pushShipment failed", it) }
    }

    // ---- Company / users (kept simple/in-memory: rarely change, not core business data) ----
    val companies = listOf(Company("C-1", "ABM Corporation"))
    private val _activeCompanyId = MutableStateFlow(companies.first().id)
    val activeCompanyId: StateFlow<String> = _activeCompanyId.asStateFlow()
    fun switchCompany(id: String) = _activeCompanyId.update { id }

    // ---- Session / login ----
    // Small demo directory matching the design prototype's PIN accounts, so this first
    // Kotlin pass behaves identically to what's already been validated in the JSX design.
    // A real login later replaces this map with a backend call + secure on-device session.
    // Mutable (StateFlow, not a plain val) because Chairman can reset anyone's PIN from the
    // Account & Access Control screen — the old PIN must stop working immediately.
    private val _demoAccounts = MutableStateFlow(
        if (com.abm.erp.config.AppEnvironment.demoAccountsAllowed) mapOf(
            "12345" to AppUser("U-CHAIR", "Zahid Hossain", UserRole.CHAIRMAN, "C-1", "All Bangladesh · Board", "CHAIR-1"),
            "11111" to AppUser("U-SR-BARISHAL", "Rafiq Hasan", UserRole.SR, "C-1", "Barishal district ▸ Notun Bazar", "SR-Barishal"),
            "22222" to AppUser("U-RSM-KHULNA", "Kabir Ahmed", UserRole.RSM, "C-1", "Khulna division (all districts)", "RSM-Khulna"),
            "33333" to AppUser("U-ASM-RANGPUR", "Mahmudul Islam", UserRole.ASM, "C-1", "Rangpur district", "ASM-Rangpur"),
            "44444" to AppUser("U-NSM", "Anwar Kabir", UserRole.NSM, "C-1", "All divisions (national)", "NSM-1"),
            "55555" to AppUser("U-AGM", "Farida Yasmin", UserRole.AGM, "C-1", "All divisions · HQ", "AGM-1"),
            "66666" to AppUser("U-GM", "Shafiqul Islam", UserRole.GM, "C-1", "All divisions · HQ", "GM-1"),
            "77777" to AppUser("U-MD", "Nasrin Chowdhury", UserRole.MD, "C-1", "All Bangladesh · HQ", "MD-1"),
        ) else emptyMap()
        // RC-1 critical fix — this map used to be hardcoded and
        // unconditional in EVERY build, including production, with the
        // real Chairman PIN "12345" always loaded. The login PATH's usage
        // was gated (AppEnvironment.demoAccountsAllowed), but a SEPARATE
        // consumer — the device-unlock screen's isChairmanPin() check —
        // had no gate at all, meaning "12345" could unlock a locked
        // device in a production build. Emptying the map itself in
        // production is defense in depth: even if another call site is
        // ever missed, there is no PIN left in memory to match against.
    )
    val demoAccountsFlow: StateFlow<Map<String, AppUser>> = _demoAccounts.asStateFlow()
    val demoAccounts: Map<String, AppUser> get() = _demoAccounts.value

    /** Chairman-only: invalidates oldPin, returns a fresh random 5-digit PIN for the same person. Never a weak/guessable one. */
    fun resetPin(oldPin: String): String {
        var newPin: String
        do { newPin = (10000..99999).random().toString() } while (isWeakPin(newPin))
        _demoAccounts.update { current ->
            val user = current[oldPin] ?: return@update current
            (current - oldPin) + (newPin to user)
        }
        return newPin
    }

    // ---- Device lockout: 3 wrong PIN attempts locks this device until the
    // Chairman's own PIN unlocks it (either on the lock screen itself, or
    // from the Account & Access Control screen once someone IS logged in). ----
    private val _deviceLocked = MutableStateFlow(false)
    val deviceLocked: StateFlow<Boolean> = _deviceLocked.asStateFlow()
    private val _failedAttempts = MutableStateFlow(0)
    val failedAttempts: StateFlow<Int> = _failedAttempts.asStateFlow()

    fun recordFailedPinAttempt() {
        _failedAttempts.update { it + 1 }
        if (_failedAttempts.value >= 3) _deviceLocked.value = true
    }

    fun unlockDevice() {
        _deviceLocked.value = false
        _failedAttempts.value = 0
    }

    /** True only for the literal Chairman PIN "12345" account — used to gate the unlock pad. */
    fun isChairmanPin(code: String): Boolean = demoAccounts[code]?.role == UserRole.CHAIRMAN

    // Part E — the static universal recovery code that used to live here
    // has been removed entirely (it was also disclosed via the login
    // screen's input placeholder). No hardcoded secret replaces it; the
    // Break Glass UI now honestly reports the feature as unavailable
    // without a configured server-side recovery flow.

    /** Super Admin — the platform owner, not part of any single company. Separate login path entirely (see LoginScreen's "Super Admin?" link). */

    private val _currentUser = MutableStateFlow(demoAccounts.getValue("12345"))
    val currentUserFlow: StateFlow<AppUser> = _currentUser.asStateFlow()
    val currentUser: AppUser get() = _currentUser.value

    /** Called by LoginScreen once a PIN or biometric prompt succeeds. */
    fun completeLogin(user: AppUser) {
        _currentUser.value = user
        logAudit("Session", user.employeeId, "LOGIN")
        // v88 fix, Foundation 2 Section 22 — identity bridge. Rather than
        // touching the actual authentication/demo-PIN logic (real risk of
        // breaking login), this safely auto-links a real EmployeeProfile
        // to this login on successful sign-in, IF one exists with a
        // matching phone number and isn't already linked to someone else.
        // This is what makes canApproveAmount/visibleRetailerIds/the real
        // Voucher approval-limit check actually activate for a real,
        // onboarded employee — without ever touching how login itself works.
        if (user.phone.isNotBlank() && ::employeeProfiles.isInitialized) {
            val match = employeeProfiles.value.firstOrNull { !it.isDeleted && it.mobile == user.phone && it.userAccountId == null }
            if (match != null) {
                if (match.hasActiveAccess) {
                    linkEmployeeToUserAccount(match.id, user.id)
                } else {
                    // v88 fix — Section 11/15: "A resigned or terminated
                    // employee must not retain active ERP access" /
                    // hasActiveAccess existed but was never actually
                    // checked anywhere. This is the real enforcement point:
                    // a matching-phone employee record that's resigned,
                    // terminated, suspended, or still mid-onboarding is
                    // never auto-linked to a fresh login session.
                    logAudit("EmployeeProfile", match.id, "LOGIN_BLOCKED_INACTIVE", oldValue = "${match.status}/${match.onboardingStatus}", newValue = "login by ${user.name} not linked — no active access")
                }
            }
        }
        // Crashlytics: tag reports with who/which company hit them — makes a
        // crash report actionable instead of anonymous.
        com.google.firebase.crashlytics.FirebaseCrashlytics.getInstance().apply {
            setUserId(user.id)
            setCustomKey("company_id", user.companyId)
            setCustomKey("role", user.role.name)
        }
        // FCM: if a push token arrived before we knew who was logging in
        // (e.g. right after install), attach it to this employee now.
        com.abm.erp.notifications.FcmTokenHolder.pendingToken?.let { registerFcmToken(it) }
        com.google.firebase.messaging.FirebaseMessaging.getInstance().token
            .addOnSuccessListener { registerFcmToken(it) }
        // Role security: seed the directory once, then ask the Cloud Function
        // to bind this device's own auth token to the employee's real role —
        // this is what lets Firestore rules check request.auth.token.role
        // instead of just "is anyone logged in".
        seedEmployeeRolesToFirestore()
        claimUserRole(user.id)
    }

    /**
     * Foundation Layer — Session Management: ordinary logout (as opposed to
     * an admin-triggered forceLogoutEmployee). Clears the device's
     * "remember me" employee id so the next app open needs a full PIN/
     * biometric login again, and records the Logout in the audit trail
     * before the session reference is gone. Deliberately does NOT clear
     * the saved Company Code or this device's Trusted Device status —
     * those are device-tenant scoping and re-trust state, not per-session
     * state, and clearing them on every ordinary logout would force a
     * device-approval re-request on next login for no reason.
     */
    fun logout(context: android.content.Context) {
        logAudit("Session", currentUser.employeeId, "LOGOUT")
        clearLastLoggedInEmployee(context)
    }

    /**
     * Pushes the whole static EMPLOYEE_DIRECTORY's role/geo (not the mock
     * target/achieved/insight fields — only what security decisions need)
     * into Firestore so the Cloud Function has something authoritative to
     * look employees up against. Safe to call on every login: it's just
     * upserts, and only actually costs a write the first time or if the
     * directory itself changes.
     */
    /**
     * SECURITY FIX (v85, Mission 3): this used to have the CLIENT itself
     * write role/geo records into employeeRoles so the setUserRoleClaim
     * Cloud Function had something to read. That write path is exactly
     * what let a malicious client forge its own role record and then
     * claim Chairman privileges — see the firestore.rules comment on
     * employeeRoles. The rule now denies ALL client writes to that
     * collection, so this function's write is intentionally disabled
     * below rather than left silently failing with a permission-denied
     * every login.
     *
     * BLOCKER — NOT YET RESOLVED IN THIS PHASE: employeeRoles must now be
     * seeded by a trusted, non-client process instead (a one-time Firebase
     * Admin SDK script, or a Cloud Function gated on an existing verified
     * Chairman token / a pre-shared admin secret configured outside the
     * app). That seeding mechanism is NOT implemented in this phase — see
     * the v85 report's "Remaining Blockers" section. Until it exists,
     * newly onboarded companies will need their employeeRoles populated
     * manually via the Firebase Console or an Admin SDK script before
     * claimUserRole()/setUserRoleClaim can succeed for their employees.
     */
    private fun seedEmployeeRolesToFirestore() {
        com.abm.erp.config.AppLog.w(
            "MockRepository",
            "seedEmployeeRolesToFirestore: client-side seeding is disabled (v85 security fix — see firestore.rules). " +
                "employeeRoles must be seeded by a trusted server-side/admin process, not this client.",
        )
    }

    /** Calls the setUserRoleClaim Cloud Function, then refreshes the ID token so the new custom claims take effect immediately (same session, no re-login needed). Only companyId is sent — the server derives everything else (employeeId, role) from the caller's own UID via the identity-binding lookup; it never trusts a client-supplied employeeId (Part F redesign). */
    private fun claimUserRole(employeeId: String) {
        val data = hashMapOf("companyId" to (syncCompanyId ?: ""))
        com.google.firebase.functions.FirebaseFunctions.getInstance()
            .getHttpsCallable("setUserRoleClaim")
            .call(data)
            .addOnSuccessListener {
                com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.getIdToken(true)
                    ?.addOnFailureListener { e -> com.abm.erp.config.AppLog.w("MockRepository", "ID token refresh failed", e) }
            }
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "claimUserRole failed — Cloud Function may not be deployed yet, app still works with the existing rules", it) }
    }

    /**
     * Part F bootstrap fix — real UserAccount login (not the legacy demo
     * path) now calls this exactly once, on a device's first successful
     * PIN verification for a given account. It's the ONLY client call
     * that can create an identity binding without an existing admin
     * claim, and the server-side function backing it enforces a real,
     * bounded, single-slot trust boundary (see functions/index.js).
     * Chains into claimUserRole so the Firestore custom claim actually
     * gets set immediately after, rather than needing a second login.
     */
    fun bindDeviceAndClaimRole(employeeProfileId: String, userAccountId: String) {
        val data = hashMapOf("companyId" to (syncCompanyId ?: ""), "employeeProfileId" to employeeProfileId, "userAccountId" to userAccountId)
        com.google.firebase.functions.FirebaseFunctions.getInstance()
            .getHttpsCallable("bindDeviceOnFirstLogin")
            .call(data)
            .addOnSuccessListener { claimUserRole(employeeProfileId) }
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "bindDeviceOnFirstLogin failed — Cloud Function may not be deployed yet, or device already bound; app still works via existing Room-based authorization", it) }
    }

    /** Stores the device's push token against this employee so the backend can target notifications later. */
    fun registerFcmToken(token: String) {
        scope.launch {
            try {
                com.google.firebase.firestore.FirebaseFirestore.getInstance()
                    .collection("companies").document(currentUser.companyId)
                    .collection("fcmTokens").document(currentUser.employeeId)
                    .set(mapOf("token" to token, "updatedAtMillis" to System.currentTimeMillis()))
            } catch (e: Exception) {
                com.abm.erp.config.AppLog.w("MockRepository", "registerFcmToken failed", e)
            }
        }
    }

    // ---- Per-employee vacancy (not per-tier): which specific people in
    // EMPLOYEE_DIRECTORY are currently marked vacant. Chairman-only control,
    // exposed on the Vacant Positions screen. Now backed by Firestore via
    // FirebaseSync, so a toggle on the Chairman's phone reaches every other
    // device — that's the whole point, a local-only list can't do that.
    // Falls back to a local-only Set if Firebase isn't configured yet. ----
    val vacantEmployeeIds: StateFlow<Set<String>> get() = FirebaseSync.vacantEmployeeIds
    fun toggleVacant(employeeId: String) = FirebaseSync.toggleVacant(employeeId)

    // ---- Sales chain ----
    lateinit var orders: StateFlow<List<RetailOrder>>
        private set

    fun advanceOrder(id: String, next: OrderStage, dealerId: String? = null) {
        scope.launch {
            db.retailOrderDao().advance(id, next.name, dealerId)
            val updated = db.retailOrderDao().getAll().first().firstOrNull { it.id == id }
            if (updated != null) pushRetailOrder(updated)
            if (next == OrderStage.FULFILLED) {
                val targetDealerId = dealerId ?: updated?.routedDealerId
                if (targetDealerId != null) {
                    val qty = extractQuantity(updated?.items)
                    db.dealerDao().adjustStock(targetDealerId, -qty)
                    pushDealerIncrement(targetDealerId, stockDelta = -qty, dueDelta = 0.0)
                    // Product-wise mirror — only possible for orders with structured lines
                    // (v113-59 onward). Older orders only ever had the free-text summary this
                    // aggregate decrement already uses, so there is nothing reliable to break
                    // down by product; the aggregate above still applies to them unchanged.
                    val structuredLines = updated?.lineItemsRaw?.takeIf { it.isNotBlank() }
                        ?.let { Converters.unpackSalesInvoiceItems(it) }.orEmpty()
                    structuredLines.forEach { adjustDealerStockLine(targetDealerId, it.productId, it.name, -it.qty) }
                    // v113-75 — the retailer-side mirror of the line above. Goods leaving
                    // the dealer arrive at the retailer, so the same structured lines
                    // increment the retailer's stock. Only possible when this order is
                    // actually linked to a real Retailer record (`retailerId` non-null) —
                    // older/anonymous orders have no id to attribute the stock to, so they
                    // are skipped rather than guessed at, same honesty rule as the dealer
                    // table's own backfill decision.
                    val targetRetailerId = updated?.retailerId
                    if (targetRetailerId != null) {
                        structuredLines.forEach { adjustRetailerStockLine(targetRetailerId, it.productId, it.name, it.qty) }
                    }
                }
            }
        }
    }

    /** Best-effort quantity parse from free-text items like "ABM Masala Tea x40 ctn" — falls back to a small default when no number is found. */
    private fun extractQuantity(items: String?): Int =
        items?.let { Regex("""x(\d+)""", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1)?.toIntOrNull() } ?: 10

    /** Approving a dealer's bulk/procurement request pulls from the COMPANY's central stock and adds to that dealer's own stock — this is the OTHER half of the stock rule (dealer bulk order verifies against company stock, not itself). */
    /** Sales-type chain of command (separate from designation chain): Retailer/Wholesale orders never generate an invoice; invoicing starts at Dealer/Depot level. SR takes retail orders only — cannot invoice. TSM and above can. */
    fun canInvoice(role: UserRole): Boolean = role != UserRole.SR

    lateinit var salesInvoices: StateFlow<List<SalesInvoice>>
        private set
    lateinit var salesOrders: StateFlow<List<SalesOrder>>
        private set

    /** Creates the invoice (auto-saves immediately, no separate save step) and updates the dealer's due balance + stock in the same action. */
    /**
     * Correction after the fact — same invoice document, same invoiceNo,
     * new content. Reverses the old due-balance/stock effect and applies the
     * new one, so editing an invoice 2 days later never double-counts.
     */
    fun updateSalesInvoice(
        invoiceId: String, lineItems: List<SalesInvoiceLineItem>,
        dealerDiscountPct: Double, commissionPct: Double, courier: String?,
    ): Boolean {
        val current = salesInvoices.value.firstOrNull { it.id == invoiceId } ?: return false
        if (isDateLocked(current.createdAt.toLocalDate())) {
            logAudit("SalesInvoice", invoiceId, "DENY_LOCKED_PERIOD", oldValue = current.createdAt.toLocalDate().toString(), newValue = "EDIT_ATTEMPT")
            return false
        }
        // Part M — "reversal rather than destructive editing". A full
        // credit-note/reversal-invoice redesign is out of scope for this
        // pass, but at minimum an invoice that's already APPROVED or has
        // any payment applied must never have its line items/amounts
        // silently changed underneath that payment — that would leave the
        // payment allocated against a total that no longer matches what
        // was actually invoiced.
        if (current.status == "APPROVED" || current.paidAmount > 0.0) {
            com.abm.erp.config.AppLog.w("MockRepository", "updateSalesInvoice rejected: invoice $invoiceId is ${current.status} with paidAmount=${current.paidAmount} — use a return/credit-note instead of editing")
            return false
        }
        scope.launch {
            val old = db.invoiceDao().getAllSales().first().firstOrNull { it.id == invoiceId } ?: return@launch
            val oldItems = Converters.unpackSalesInvoiceItems(old.lineItemsRaw)
            val oldSubTotal = oldItems.sumOf { it.lineTotal }
            val oldNet = oldSubTotal * (1 - old.dealerDiscountPct / 100)
            oldItems.forEach { db.dealerDao().adjustStock(old.dealerId, -it.qty) } // reverse old stock arrival
            oldItems.forEach { adjustDealerStockLine(old.dealerId, it.productId, it.name, -it.qty) }
            db.dealerDao().adjustDueBalance(old.dealerId, -oldNet) // reverse old due-balance effect

            val newSubTotal = lineItems.sumOf { it.lineTotal }
            val newNet = newSubTotal * (1 - dealerDiscountPct / 100)
            val updatedInvoice = old.copy(
                lineItemsRaw = Converters.packSalesInvoiceItems(lineItems),
                dealerDiscountPct = dealerDiscountPct, commissionPct = commissionPct, courier = courier,
            )
            db.invoiceDao().upsert(updatedInvoice)
            syncCollection("salesInvoices").document(updatedInvoice.id).set(updatedInvoice)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push updated invoice failed", it) }
            db.dealerDao().adjustDueBalance(old.dealerId, newNet)
            lineItems.forEach { db.dealerDao().adjustStock(old.dealerId, it.qty) }
            lineItems.forEach { adjustDealerStockLine(old.dealerId, it.productId, it.name, it.qty) }
            val oldQtyTotal = oldItems.sumOf { it.qty }
            val newQtyTotal = lineItems.sumOf { it.qty }
            pushDealerIncrement(old.dealerId, stockDelta = newQtyTotal - oldQtyTotal, dueDelta = newNet - oldNet)
            logAudit("SalesInvoice", old.id, "UPDATE", oldValue = old, newValue = updatedInvoice)
        }
        return true
    }

    /**
     * Invoice-module permission enforcement example (PRIORITY 1 deliverable).
     * Blocked at the repository layer, not just the UI — even a tampered
     * client calling this directly gets refused if the role lacks canApprove
     * on "bill". Returns false + logs a DENY audit entry on refusal.
     */
    fun approveSalesInvoice(invoiceId: String): Boolean {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)) {
            logAudit("SalesInvoice", invoiceId, "DENY", oldValue = currentUser.role.name, newValue = "APPROVE")
            return false
        }
        if (!com.abm.erp.ABMApplication.isOnlineNow()) {
            logAudit("SalesInvoice", invoiceId, "DENY_OFFLINE", newValue = "Final Invoice requires an online connection")
            return false
        }
        scope.launch {
            // Atomic check-and-flip — closes the retry/race window: two near-simultaneous calls can no longer both read status=="PENDING" before either commits, which would have caused a double stock deduction below.
            val existing = db.withTransaction {
                val current = db.invoiceDao().getAllSales().first().firstOrNull { it.id == invoiceId } ?: return@withTransaction null
                if (current.status != "PENDING") {
                    logAudit("SalesInvoice", invoiceId, "DENY", oldValue = current.status, newValue = "APPROVE — already ${current.status}")
                    return@withTransaction null
                }
                val flipped = current.copy(status = "APPROVED", stockReserved = false)
                db.invoiceDao().upsert(flipped)
                current
            } ?: return@launch
            val domain = existing.toSalesDomain()
            val net = domain.total
            // Final posting — ATOMIC: status (already flipped above), stock, dealer due, ledger, employee achievement, audit log.
            syncCollection("salesInvoices").document(invoiceId).update(mapOf("status" to "APPROVED", "stockReserved" to false))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push invoice-approve failed", it) }
            // Release reservation, then real warehouse stock deduction — this is the ONLY place actual company stock ever decreases for a sale.
            domain.lineItems.forEach { item ->
                InventoryRepository.releaseStock(item.productId, existing.warehouseId, item.qty.toDouble())
                InventoryRepository.adjustStock(item.productId, existing.warehouseId, item.qty.toDouble(), com.abm.erp.data.MovementType.OUT, "Sales invoice ${existing.invoiceNo} approved — ${existing.dealerName}", batchCode = item.batchCode)
            }
            db.dealerDao().adjustDueBalance(existing.dealerId, net)
            domain.lineItems.forEach { db.dealerDao().adjustStock(existing.dealerId, it.qty) } // invoiced stock arrives at the dealer
            domain.lineItems.forEach { adjustDealerStockLine(existing.dealerId, it.productId, it.name, it.qty) }
            pushDealerIncrement(existing.dealerId, stockDelta = domain.lineItems.sumOf { it.qty }, dueDelta = net)
            postPartyLedgerEntry(PartyType.DEALER, existing.dealerId, "DEBIT", net, "Sales Invoice ${existing.invoiceNo}", existing.id)
            // Real employee achievement — was never automatically updated from any invoice before. Credited to whoever created the invoice.
            val creatorProfile = employeeProfiles.value.firstOrNull { it.fullName == existing.createdBy }
            if (creatorProfile != null) {
                val payrollLine = db.payrollDao().getAll().first().firstOrNull { it.employeeId == creatorProfile.id }
                if (payrollLine != null) {
                    db.payrollDao().upsertAll(listOf(payrollLine.copy(achievedAmount = payrollLine.achievedAmount + net)))
                }
            }
            logAudit("SalesInvoice", existing.id, "APPROVE_AND_POST", oldValue = "PENDING", newValue = "APPROVED — stock/due/ledger/achievement posted atomically")
            createNotification(NotificationCategory.APPROVAL, "Invoice Approved", "${existing.invoiceNo} — ${existing.dealerName} অনুমোদিত হয়েছে")
            activateQrFor("SalesInvoice", existing.id)  // invoice is final — its QR becomes scannable
        }
        return true
    }

    /** Section 7 — Rejection/cancellation must release reservation. Was completely missing before — there was no way to reject a PENDING invoice at all, meaning a reservation could only ever be resolved by approval. No due/stock/ledger/achievement effect to reverse here, since none of those happen until approval — only the reservation itself needs releasing. */
    fun rejectSalesInvoice(invoiceId: String, reason: String): Boolean {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)) {
            logAudit("SalesInvoice", invoiceId, "DENY", oldValue = currentUser.role.name, newValue = "REJECT")
            return false
        }
        if (reason.isBlank()) return false
        scope.launch {
            val existing = db.withTransaction {
                val current = db.invoiceDao().getAllSales().first().firstOrNull { it.id == invoiceId } ?: return@withTransaction null
                if (current.status != "PENDING") {
                    logAudit("SalesInvoice", invoiceId, "DENY", oldValue = current.status, newValue = "REJECT — already ${current.status}")
                    return@withTransaction null
                }
                val flipped = current.copy(status = "CANCELLED", stockReserved = false)
                db.invoiceDao().upsert(flipped)
                current
            } ?: return@launch
            val domain = existing.toSalesDomain()
            if (existing.stockReserved) {
                domain.lineItems.forEach { item -> InventoryRepository.releaseStock(item.productId, existing.warehouseId, item.qty.toDouble()) }
            }
            syncCollection("salesInvoices").document(invoiceId).update(mapOf("status" to "CANCELLED", "stockReserved" to false))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push invoice-reject failed", it) }
            logAudit("SalesInvoice", existing.id, "REJECT", oldValue = "PENDING", newValue = "CANCELLED — reservation released", reason = reason)
            createNotification(NotificationCategory.INVOICE, "Invoice Rejected", "${existing.invoiceNo} — ${existing.dealerName}: $reason")
        }
        return true
    }

    /** Soft delete — same permission-gate pattern as approveSalesInvoice, but checks canDelete on "bill". */
    fun deleteSalesInvoice(invoiceId: String): Boolean {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.DELETE)) {
            logAudit("SalesInvoice", invoiceId, "DENY", oldValue = currentUser.role.name, newValue = "DELETE")
            return false
        }
        scope.launch {
            val existing = db.invoiceDao().getAllSales().first().firstOrNull { it.id == invoiceId } ?: return@launch
            db.invoiceDao().upsert(existing.copy(isDeleted = true, deletedAtEpochMillis = System.currentTimeMillis(), deletedBy = currentUser.name))
            syncCollection("salesInvoices").document(invoiceId)
                .update(mapOf("isDeleted" to true, "deletedAtEpochMillis" to System.currentTimeMillis(), "deletedBy" to currentUser.name))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push invoice-delete failed", it) }
            logAudit("SalesInvoice", existing.id, "DELETE", oldValue = false, newValue = true)
            revokeQrFor("SalesInvoice", existing.id, "Invoice deleted")
        }
        return true
    }

    /** Restore — same permission-gate as delete (canDelete implies can undo it too). */
    fun restoreSalesInvoice(invoiceId: String): Boolean {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.DELETE)) {
            logAudit("SalesInvoice", invoiceId, "DENY", oldValue = currentUser.role.name, newValue = "RESTORE")
            return false
        }
        scope.launch {
            db.invoiceDao().restore(invoiceId)
            syncCollection("salesInvoices").document(invoiceId)
                .update(mapOf("isDeleted" to false, "deletedAtEpochMillis" to null, "deletedBy" to null))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push invoice-restore failed", it) }
            logAudit("SalesInvoice", invoiceId, "RESTORE")
        }
        return true
    }

    /** Sales Excellence — Discount Approval and any other future "raise a new approval request" need. Reuses the existing ApprovalRequestEntity/ApprovalDao (already used for cascade approvals); this just adds the missing "create" entry point. */
    fun raiseApprovalRequest(type: ApprovalType, detail: String, entityType: String, entityId: String) {
        scope.launch {
            val entity = com.abm.erp.data.room.ApprovalRequestEntity(
                id = java.util.UUID.randomUUID().toString(), type = type.name, fromEmployee = currentUser.name,
                detail = detail, status = ApprovalStatus.PENDING.name, createdAtEpochMillis = System.currentTimeMillis(),
                entityType = entityType, entityId = entityId, level = 1,
            )
            db.approvalDao().upsert(entity)
            syncCollection("approvals").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push new approval failed", it) }
            logAudit("ApprovalRequest", entity.id, "CREATE", newValue = detail)
        }
    }

    /**
     * v86, Module 4 — Sales Order stage: Draft -> Submitted -> Approved ->
     * (Partially Delivered/Delivered) -> Invoiced -> Cancelled. This was
     * completely missing before — Sales jumped straight from dealer
     * selection to a final Invoice with no order/approval stage at all.
     */
    /**
     * v86, Module 4 — real Margin/Profit Analysis, using the new costPrice
     * field. Returns null (not a fabricated 0%) when costPrice isn't set
     * for a product, since margin is genuinely unknown in that case.
     */
    fun invoiceMargin(invoice: SalesInvoice): Double? {
        val products = InventoryRepository.products.value
        var totalCost = 0.0
        for (line in invoice.lineItems) {
            val product = products.firstOrNull { it.id == line.productId } ?: return null
            if (product.costPrice <= 0.0) return null
            totalCost += product.costPrice * line.qty
        }
        return invoice.netAfterDiscount - totalCost
    }

    fun productMarginPct(productId: String): Double? {
        val product = InventoryRepository.products.value.firstOrNull { it.id == productId } ?: return null
        if (product.costPrice <= 0.0 || product.defaultUnitPrice <= 0.0) return null
        return (product.defaultUnitPrice - product.costPrice) / product.defaultUnitPrice * 100
    }

    fun createSalesOrder(dealerId: String, dealerName: String, dealerZone: String, lineItems: List<SalesInvoiceLineItem>, dealerDiscountPct: Double = 0.0): SalesOrder {
        val order = SalesOrder(
            id = java.util.UUID.randomUUID().toString(), orderNo = "SO-${1000 + salesOrders.value.size + 1}",
            dealerId = dealerId, dealerName = dealerName, dealerZone = dealerZone,
            lineItems = lineItems, dealerDiscountPct = dealerDiscountPct, createdBy = currentUser.name,
        )
        scope.launch {
            val entity = order.toEntity()
            db.salesOrderDao().upsert(entity)
            syncCollection("salesOrders").document(entity.id).set(entity).addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push salesOrder failed", it) }
            logAudit("SalesOrder", order.id, "CREATE", newValue = order)
        }
        return order
    }

    fun submitSalesOrder(id: String) {
        scope.launch {
            db.salesOrderDao().setStatus(id, "SUBMITTED")
            syncCollection("salesOrders").document(id).update("status", "SUBMITTED")
            logAudit("SalesOrder", id, "SUBMIT")
        }
    }

    fun approveSalesOrder(id: String): Boolean {
        val order = salesOrders.value.firstOrNull { it.id == id }
        if (order == null || order.status != "SUBMITTED") {
            logAudit("SalesOrder", id, "DENY", oldValue = order?.status ?: "not found", newValue = "APPROVE")
            return false
        }
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)) {
            logAudit("SalesOrder", id, "DENY", oldValue = currentUser.role.name, newValue = "APPROVE")
            return false
        }
        scope.launch {
            val now = System.currentTimeMillis()
            db.salesOrderDao().approve(id, "APPROVED", currentUser.name, now)
            syncCollection("salesOrders").document(id).update(mapOf("status" to "APPROVED", "approvedBy" to currentUser.name, "approvedAtEpochMillis" to now))
            logAudit("SalesOrder", id, "APPROVE")
        }
        return true
    }

    /** Real partial-delivery tracking: recordDelivery adds to deliveredQtyByProduct and recomputes DELIVERED vs PARTIALLY_DELIVERED by actually comparing against ordered qty per product — not just a status flag. */
    fun recordDelivery(id: String, deliveredNow: Map<String, Int>): Boolean {
        val order = salesOrders.value.firstOrNull { it.id == id } ?: return false
        if (order.status != "APPROVED" && order.status != "PARTIALLY_DELIVERED") return false
        val newDelivered = order.deliveredQtyByProduct.toMutableMap()
        deliveredNow.forEach { (productId, qty) -> newDelivered[productId] = (newDelivered[productId] ?: 0) + qty }
        val fullyDelivered = order.lineItems.all { (newDelivered[it.productId] ?: 0) >= it.qty }
        val newStatus = if (fullyDelivered) "DELIVERED" else "PARTIALLY_DELIVERED"
        scope.launch {
            val raw = newDelivered.entries.joinToString(";") { "${it.key},${it.value}" }
            db.salesOrderDao().updateDelivery(id, newStatus, raw)
            syncCollection("salesOrders").document(id).update(mapOf("status" to newStatus, "deliveredQtyRaw" to raw))
            logAudit("SalesOrder", id, "DELIVERY", newValue = "$newStatus — $deliveredNow")
        }
        return true
    }

    /** Converts an APPROVED/DELIVERED sales order into a real Invoice via the existing createSalesInvoice — no duplicated invoice-creation logic. */
    fun convertSalesOrderToInvoice(id: String): Boolean {
        val order = salesOrders.value.firstOrNull { it.id == id } ?: return false
        if (order.status != "APPROVED" && order.status != "DELIVERED" && order.status != "PARTIALLY_DELIVERED") {
            logAudit("SalesOrder", id, "DENY", oldValue = order.status, newValue = "CONVERT_TO_INVOICE")
            return false
        }
        val created = createSalesInvoice(order.dealerId, order.dealerName, order.dealerZone, order.lineItems, order.dealerDiscountPct, 0.0, null, null)
        if (!created) return false
        val invoice = salesInvoices.value.filter { it.dealerId == order.dealerId }.maxByOrNull { it.createdAt }
        scope.launch {
            db.salesOrderDao().markInvoiced(id, "INVOICED", invoice?.id ?: "")
            syncCollection("salesOrders").document(id).update(mapOf("status" to "INVOICED", "convertedToInvoiceId" to (invoice?.id ?: "")))
            logAudit("SalesOrder", id, "CONVERT_TO_INVOICE", newValue = invoice?.invoiceNo ?: "")
        }
        return true
    }

    /** Part M — Sales Order cancellation. Was completely missing from this codebase; once created/submitted/approved, there was no way to cancel an order at all. Idempotent, blocks cancellation after invoicing (use a return/credit-note against the invoice instead — never cancel a document that already has a downstream financial effect). */
    fun cancelSalesOrder(id: String, reason: String): Boolean {
        val order = salesOrders.value.firstOrNull { it.id == id } ?: return false
        if (order.status == "CANCELLED") {
            com.abm.erp.config.AppLog.w("MockRepository", "cancelSalesOrder rejected: order $id already cancelled (idempotency guard)")
            return false
        }
        if (order.status == "INVOICED") {
            com.abm.erp.config.AppLog.w("MockRepository", "cancelSalesOrder rejected: order $id already converted to an invoice — use a return/credit-note against the invoice instead")
            return false
        }
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.EDIT)) {
            logAudit("SalesOrder", id, "DENY", oldValue = currentUser.role.name, newValue = "CANCEL")
            return false
        }
        scope.launch {
            db.salesOrderDao().setStatus(id, "CANCELLED")
            syncCollection("salesOrders").document(id).update("status", "CANCELLED")
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push order-cancel failed", it) }
            logAudit("SalesOrder", id, "CANCEL", oldValue = order.status, newValue = "CANCELLED", reason = reason)
        }
        return true
    }

    fun createSalesInvoice(
        dealerId: String, dealerName: String, dealerZone: String, lineItems: List<SalesInvoiceLineItem>,
        dealerDiscountPct: Double, commissionPct: Double, courier: String?, signedByRole: String?,
        warehouseId: String = "",
        onCreated: (SalesInvoice) -> Unit = {},
    ): Boolean {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.CREATE)) {
            logAudit("SalesInvoice", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return false
        }
        // v86 QA fix — Closed-Period was only enforced for Voucher before;
        // an Invoice affects dealer due balance and is a real financial
        // transaction too, so it must respect the same monthly close.
        run {
            val currentYearMonth = LocalDateTime.now().let { "%04d-%02d".format(it.year, it.monthValue) }
            if (AccountsRepository.closedPeriods.value.contains(currentYearMonth)) {
                logAudit("SalesInvoice", "(new)", "DENY", oldValue = "period $currentYearMonth", newValue = "CREATE — period is closed")
                return false
            }
        }
        if (lineItems.isEmpty() || lineItems.any { it.qty <= 0 || it.unitPrice < 0 }) {
            com.abm.erp.config.AppLog.w("MockRepository", "createSalesInvoice rejected: empty or invalid line items")
            return false
        }
        // Foundation Layer/Module 7 — Credit Limit enforcement: a dealer with
        // creditLimit > 0 can't be invoiced past it. creditLimit == 0 means
        // "no explicit limit configured yet" (most dealers today), so it's
        // not blocked — this only bites once a Chairman/GM sets a real cap.
        // Phase 5 — this net figure now comes from the single authoritative
        // InvoiceCalculationEngine (BigDecimal) rather than a separate,
        // locally-duplicated Double formula, so the credit-limit check
        // below can never silently disagree with what the invoice will
        // actually total.
        val engineResult = com.abm.erp.invoice.InvoiceCalculationEngine.computeInvoice(
            com.abm.erp.invoice.InvoiceCalculationEngine.InvoiceInput(
                lines = lineItems.map {
                    com.abm.erp.invoice.InvoiceCalculationEngine.LineInput(
                        quantity = java.math.BigDecimal(it.qty), unitPrice = java.math.BigDecimal.valueOf(it.unitPrice),
                        lineDiscountPct = java.math.BigDecimal.valueOf(it.discountPct),
                    )
                },
                invoiceLevelDiscountPct = java.math.BigDecimal.valueOf(dealerDiscountPct),
            ),
        )
        if (engineResult.rejected) {
            com.abm.erp.config.AppLog.w("MockRepository", "createSalesInvoice rejected by InvoiceCalculationEngine: ${engineResult.rejectionReason}")
            return false
        }
        val subTotal = lineItems.sumOf { it.lineTotal }
        val net = engineResult.currentInvoiceNetTotal.toDouble()
        val dealer = dealers.value.firstOrNull { it.id == dealerId }
        if (dealer != null && dealer.creditLimit > 0 && dealer.dueBalance + net > dealer.creditLimit) {
            logAudit("SalesInvoice", "(new)", "DENY", oldValue = "credit limit ৳${dealer.creditLimit}", newValue = "would reach ৳${dealer.dueBalance + net}")
            return false
        }
        // v86, Module 3 — Weekly 50% Due Rule: only actually BLOCKS the sale
        // when a manager has explicitly set this dealer to SUSPENDED (a
        // deliberate decision recorded via setDealerCreditStatus, always
        // with a reason). A dealer merely falling short of this week's
        // expected collection is NOT auto-blocked here — the spec says
        // "the next credit supply MAY be suspended", not must; treating a
        // missed-target dealer as unconditionally blocked would silently
        // stop legitimate sales without a manager's decision. The real,
        // non-fabricated eligibility numbers ARE computed and logged either
        // way so the reason is always visible in the invoice's audit trail.
        if (dealer != null) {
            val eligibility = checkWeeklyDueEligibility(dealer.id)
            if (dealer.creditStatus == "SUSPENDED") {
                logAudit("SalesInvoice", "(new)", "DENY", oldValue = "Weekly 50% Rule", newValue = eligibility.reason)
                return false
            }
            if (!eligibility.eligible) {
                logAudit("SalesInvoice", "(new)", "WARN", oldValue = "Weekly 50% Rule", newValue = eligibility.reason)
            }
        }
        // Section 7 — resolve the real company warehouse this sale draws from (given, or the first STORE-category/saleable warehouse), and check availability BEFORE creating the invoice — never fabricated, never assumed.
        val resolvedWarehouseId = warehouseId.ifBlank { InventoryRepository.warehouses.value.firstOrNull { it.stockCategory == StockCategory.STORE }?.id ?: "" }
        if (resolvedWarehouseId.isBlank()) {
            com.abm.erp.config.AppLog.w("MockRepository", "createSalesInvoice rejected: no saleable (STORE-category) warehouse exists to draw stock from")
            return false
        }
        for (item in lineItems) {
            val level = InventoryRepository.stockLevels.value.firstOrNull { it.productId == item.productId && it.warehouseId == resolvedWarehouseId }
            if (level == null || level.availableQty < item.qty) {
                com.abm.erp.config.AppLog.w("MockRepository", "createSalesInvoice rejected: insufficient available stock for ${item.productId} (need ${item.qty}, have ${level?.availableQty ?: 0.0})")
                return false
            }
        }
        scope.launch {
            val invoiceNo = generateNumber("INVOICE")
            // Balance snapshot, taken here rather than recomputed when the bill is opened,
            // so a printed invoice keeps showing the figures it was printed with.
            // This records the dealer's position; it does not change it — the actual due
            // movement still happens only in approveSalesInvoice, exactly as before.
            val previousDue = dealers.value.firstOrNull { it.id == dealerId }?.dueBalance ?: 0.0
            val invoiceNet = lineItems.sumOf { it.lineTotal }.let { it - it * (dealerDiscountPct / 100) }
            val entity = InvoiceEntity(
                id = java.util.UUID.randomUUID().toString(), invoiceNo = invoiceNo, type = "SALES", dealerId = dealerId, dealerName = dealerName,
                dealerZone = dealerZone, lineItemsRaw = Converters.packSalesInvoiceItems(lineItems),
                dealerDiscountPct = dealerDiscountPct, commissionPct = commissionPct, courier = courier,
                signedByRole = signedByRole, createdBy = currentUser.name, createdAtEpochMillis = System.currentTimeMillis(),
                warehouseId = resolvedWarehouseId, stockReserved = true,
                previousDueSnapshot = previousDue,
                closingDueSnapshot = previousDue + invoiceNet,
            )
            db.invoiceDao().upsert(entity)
            syncCollection("salesInvoices").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push new invoice failed", it) }
            // Reserve only — never deduct. "Draft invoice must not reduce stock; submitted invoice may reserve stock only." Real due-balance/dealer-stock/ledger effects all happen at approveSalesInvoice, never here.
            lineItems.forEach { item -> InventoryRepository.reserveStock(item.productId, resolvedWarehouseId, item.qty.toDouble()) }
            logAudit("SalesInvoice", entity.id, "CREATE", newValue = entity)
            createNotification(NotificationCategory.INVOICE, "New Invoice (Pending Approval)", "$invoiceNo — $dealerName")
            onCreated(entity.toSalesDomain())
            // Sales Excellence — Discount Approval: a discount above the configured Maximum Discount rule OR above THIS employee's own personal discount approval limit needs sign-off. Previously only checked the single global business rule, ignoring per-employee limits entirely.
            val myProfile = employeeProfiles.value.firstOrNull { it.id == currentUser.employeeId }
            val myDiscountLimit = myProfile?.discountApprovalLimitPct?.takeIf { it > 0.0 }
            val effectiveDiscountLimit = minOf(businessRuleDouble("MAX_DISCOUNT_PCT", 15.0), myDiscountLimit ?: Double.MAX_VALUE)
            if (dealerDiscountPct > effectiveDiscountLimit) {
                raiseApprovalRequest(ApprovalType.DISCOUNT, "$invoiceNo — $dealerName: ${dealerDiscountPct}% discount needs approval", "SalesInvoice", entity.id)
            }
            // Section 9 — Invoice Limit: an invoice above this configured value needs extra sign-off, not just silent creation.
            if (net > businessRuleDouble("INVOICE_LIMIT", 500000.0)) {
                raiseApprovalRequest(ApprovalType.OTHER, "$invoiceNo — $dealerName: ৳${"%,.0f".format(net)} exceeds the Invoice Limit and needs approval", "SalesInvoice", entity.id)
            }
        }
        return true
    }

    fun logNewOrder(
        retailerName: String, items: String, amount: Double, zone: String,
        photoUri: String? = null, lat: Double? = null, lng: Double? = null,
        channel: String = "retail", anonymous: Boolean = false, photoPurpose: String? = null,
        // Structured lines (v71). Defaulted, so every existing caller is unaffected and keeps
        // passing only the free-text summary. When supplied, both are stored — the summary
        // for the logic that already reads it, the lines for the printable memo.
        lineItems: List<SalesInvoiceLineItem> = emptyList(),
        // v113-80 — link to the real Retailer record. Defaulted, so every existing
        // caller is untouched. Without this, RetailOrder.retailerId was ALWAYS null on
        // app-created memos (the entity column existed since the Data Design step but
        // nothing ever wrote it) — which meant v113-75's retailer-stock increment on
        // FULFILLED could never fire on the main path. Found during workspace build,
        // not by a compiler.
        retailerId: String? = null,
    ) {
        scope.launch {
            val nextNum = 100 + db.retailOrderDao().count() + 1
            val entity = RetailOrderEntity(
                id = java.util.UUID.randomUUID().toString(),
                orderNo = "ORD-$nextNum",
                retailerId = retailerId,
                retailerName = retailerName,
                loggedBySoId = currentUser.id,
                zone = zone,
                items = items,
                amount = amount,
                stage = OrderStage.SO_LOGGED.name,
                routedDealerId = null,
                loggedAtEpochMillis = System.currentTimeMillis(),
                retailerPhotoUri = photoUri,
                retailerLat = lat,
                retailerLng = lng,
                retailerQrCode = com.abm.erp.util.QrCodeGenerator.retailerCode(retailerName, zone),
                channel = channel, anonymous = anonymous, photoPurpose = photoPurpose,
                lineItemsRaw = if (lineItems.isEmpty()) "" else Converters.packSalesInvoiceItems(lineItems),
            )
            db.retailOrderDao().upsert(entity)
            pushRetailOrder(entity)
            createNotification(NotificationCategory.SALES_ORDER, "New Sales Order", "${entity.orderNo} — $retailerName (৳${"%,.0f".format(amount)})")
        }
    }

    /**
     * ⚠ RAW, UNSCOPED list — every dealer in the company.
     *
     * Decision 4 (v113-73): UI screens must **not** read this directly for anything the
     * user can *select* or *act on*. Use `com.abm.erp.core.rememberVisibleDealers()`
     * (or `visibleDealersFor(...)` outside Compose), which applies the cascade/territory
     * scope. Reading this raw is what let an SR invoice a dealer outside his territory
     * from DealerInvoiceScreen and DealerInvoiceTab.
     *
     * Legitimate direct uses that remain: single-record lookup by id, code/QR resolution
     * (access is re-checked after resolving), and Chairman/company-wide reporting.
     */
    lateinit var dealers: StateFlow<List<Dealer>>
        private set

    // ================= Universal Attachment System (Global Rule) =================
    /** Any module calls this the same way — a photo/PDF/document/audio/video tagged to any entity, with GPS+timestamp+uploader captured automatically. */
    /**
     * v86 fix, Module 14 — this used to save ONLY the local device file URI
     * as the attachment's "uri" and push that metadata straight to
     * Firestore, without ever actually uploading the file bytes to Firebase
     * Storage. That meant every attachment in this app was invisible to
     * any other device/user, and would be lost entirely on reinstall — a
     * real violation of "do not claim cloud upload success unless upload
     * succeeds" (it wasn't even attempting the upload). Now it genuinely
     * uploads to Storage first and only saves metadata with the real
     * download URL once that succeeds; onResult reports true/false honestly
     * so the UI can show a real failure instead of a silent local-only save.
     */
    fun uploadAttachment(context: android.content.Context, moduleReference: String, entityId: String, type: AttachmentType, localUri: String, lat: Double? = null, lng: Double? = null, onResult: (Attachment?) -> Unit = {}) {
        scope.launch {
            try {
                val parsedUri = android.net.Uri.parse(localUri)
                val mimeType = context.contentResolver.getType(parsedUri)
                // v87 fix — "File type validation" and "File size validation"
                // were explicit Section 12 requirements that were never
                // enforced; any file of any size could be pushed to Storage.
                val allowedMimePrefixes = listOf("image/", "application/pdf")
                if (mimeType != null && allowedMimePrefixes.none { mimeType.startsWith(it) }) {
                    com.abm.erp.config.AppLog.w("MockRepository", "attachment rejected: unsupported file type '$mimeType'")
                    onResult(null)
                    return@launch
                }
                val fileSizeBytes = context.contentResolver.openFileDescriptor(parsedUri, "r")?.use { it.statSize } ?: 0L
                val maxSizeBytes = 15L * 1024 * 1024 // 15MB — generous enough for a phone photo/PDF, small enough to keep Storage costs and upload time sane
                if (fileSizeBytes > maxSizeBytes) {
                    com.abm.erp.config.AppLog.w("MockRepository", "attachment rejected: file too large (${fileSizeBytes / (1024 * 1024)}MB > 15MB limit)")
                    onResult(null)
                    return@launch
                }
                val extension = mimeType?.let { android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(it) } ?: "bin"
                val id = java.util.UUID.randomUUID().toString()
                val storageRef = com.google.firebase.storage.FirebaseStorage.getInstance().reference
                    .child("companies/${currentUser.companyId}/attachments/$moduleReference/$entityId/$id.$extension")
                storageRef.putFile(parsedUri).await()
                val downloadUrl = storageRef.downloadUrl.await().toString()
                val attachment = Attachment(
                    id = id, moduleReference = moduleReference, entityId = entityId,
                    type = type, uri = downloadUrl, lat = lat, lng = lng, uploadedBy = currentUser.name,
                )
                val entity = attachment.toEntity()
                db.attachmentDao().upsert(entity)
                syncCollection("attachments").document(entity.id).set(entity)
                    .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push attachment metadata failed", it) }
                logAudit("Attachment", attachment.id, "CREATE", newValue = "$moduleReference/$entityId: $type")
                onResult(attachment)
            } catch (e: Exception) {
                com.abm.erp.config.AppLog.w("MockRepository", "attachment upload to Storage failed", e)
                onResult(null)
            }
        }
    }

    /** v86, Module 14 — "Remove with confirmation" was missing entirely; deletes both the Storage file and the Firestore/Room metadata. */
    fun removeAttachment(attachment: Attachment) {
        scope.launch {
            try {
                com.google.firebase.storage.FirebaseStorage.getInstance().getReferenceFromUrl(attachment.uri).delete().await()
            } catch (e: Exception) {
                com.abm.erp.config.AppLog.w("MockRepository", "attachment Storage delete failed (metadata will still be removed)", e)
            }
            db.attachmentDao().delete(attachment.id)
            syncCollection("attachments").document(attachment.id).delete()
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push attachment-delete failed", it) }
            logAudit("Attachment", attachment.id, "DELETE")
        }
    }

    fun attachmentsFor(moduleReference: String, entityId: String): Flow<List<Attachment>> =
        db.attachmentDao().getForEntity(moduleReference, entityId).map { list -> list.map { it.toDomain() } }

    /** Universal Action Menu: Activity Log — every module's card opens the SAME audit trail, filtered to just this record, instead of a bespoke history view per module. */
    fun activityLogFor(entityType: String, entityId: String): Flow<List<AuditLogEntry>> =
        db.auditLogDao().getForEntity(entityType, entityId).map { list -> list.map { it.toDomain() } }

    /** Universal Action Menu: Approval History — reuses ApprovalRequest.entityType/entityId (Foundation Layer's Cascade Approval fields) rather than a new table. */
    fun approvalHistoryFor(entityType: String, entityId: String): List<ApprovalRequest> =
        approvals.value.filter { it.entityType == entityType && it.entityId == entityId }

    // ================= Universal Action Menu: Duplicate (Global Rule) =================
    /** "Duplicate" clones a Dealer/Retailer/Product's editable fields into a brand-new record (new id, dedup-checked exactly like a fresh registration) — never a raw id copy, which would violate the very dedup rule Duplicate is meant to route around. */
    suspend fun duplicateDealer(dealerId: String): DuplicateResult? {
        val d = dealers.value.firstOrNull { it.id == dealerId } ?: return null
        val created = createDealer("${d.name} (copy)", d.zone, d.phone, d.address) ?: return null
        return DuplicateResult(created.id, created.name)
    }

    suspend fun duplicateRetailer(retailerId: String): DuplicateResult? {
        val r = retailers.value.firstOrNull { it.id == retailerId } ?: return null
        val created = createRetailer(name = "${r.name} (copy)", phone = r.phone, address = r.address, dealerId = r.dealerId, outletCategory = r.outletCategory, outletType = r.outletType) ?: return null
        return DuplicateResult(created.id, created.name)
    }

    fun duplicateTask(taskId: String): DuplicateResult? {
        val t = tasks.value.firstOrNull { it.id == taskId } ?: return null
        val newId = java.util.UUID.randomUUID().toString()
        val newTitle = "${t.title} (copy)"
        scope.launch {
            val entity = com.abm.erp.data.room.TaskItemEntity(id = newId, title = newTitle, assignee = t.assignee, done = false, createdAtEpochMillis = System.currentTimeMillis())
            db.taskDao().upsert(entity)
            syncCollection("tasks").document(newId).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push task-duplicate failed", it) }
            logAudit("Task", newId, "CREATE", newValue = entity.toDomain())
        }
        return DuplicateResult(newId, newTitle)
    }

    fun duplicateQuotation(quotationId: String): DuplicateResult? {
        val q = quotations.value.firstOrNull { it.id == quotationId } ?: return null
        val created = createQuotation(q.partyType, q.partyId, q.partyName, q.lineItems, LocalDateTime.now().plusDays(7)) ?: return null
        return DuplicateResult(created.id, created.quotationNo)
    }

    // ================= AI Framework (Module 16) =================
    /**
     * Business Health Score — a single 0-100 number blended from four real,
     * currently-available signals: sales momentum, collection health (due
     * vs sales ratio), stock health (low-stock proportion), and open risk
     * count. Not a black-box ML model — a transparent weighted blend, which
     * is the honest, buildable version of "Business Health Score" today.
     */
    fun computeBusinessHealthScore(): BusinessHealthScore {
        val dealersNow = dealers.value
        val totalSales = dealersNow.sumOf { it.salesLast90Days }
        val totalDue = dealersNow.sumOf { it.dueBalance }
        val collectionRatio = if (totalSales <= 0.0) 0.5 else (1.0 - (totalDue / totalSales)).coerceIn(0.0, 1.0)
        val stockLevelsNow = InventoryRepository.stockLevels.value
        val lowStockRatio = if (stockLevelsNow.isEmpty()) 0.0 else stockLevelsNow.count { it.isLowStock }.toDouble() / stockLevelsNow.size
        val stockHealth = (1.0 - lowStockRatio).coerceIn(0.0, 1.0)
        val redDealers = dealersNow.count { riskBand(it) == RiskBand.RED }
        val riskHealth = if (dealersNow.isEmpty()) 1.0 else (1.0 - (redDealers.toDouble() / dealersNow.size)).coerceIn(0.0, 1.0)
        val salesTrend = if (totalSales > 0) 0.7 else 0.4 // no daily time-series yet to compute a real trend slope — neutral-positive default when there's any sales activity at all

        val salesComponent = (salesTrend * 25).toInt()
        val collectionComponent = (collectionRatio * 25).toInt()
        val stockComponent = (stockHealth * 25).toInt()
        val riskComponent = (riskHealth * 25).toInt()
        val total = salesComponent + collectionComponent + stockComponent + riskComponent
        val label = when { total >= 85 -> "Excellent"; total >= 65 -> "Good"; total >= 45 -> "Fair"; else -> "Poor" }
        return BusinessHealthScore(total, label, salesComponent, collectionComponent, stockComponent, riskComponent)
    }

    /** Risk Detection — scans dealers/inventory/approvals for anything needing attention right now, surfaced as a flat alert list instead of the person having to check every module separately. */
    // ==========================================================
    // Section 8 — Smart Business Alert Engine. The older
    // computeRiskAlerts() below only ever covered 2 of the 9 required
    // signals (dealer-due, low-stock) plus one unrelated one
    // (approval-backlog) — 6 of the 9 real signals this section requires
    // (absence, expiry, target-pace, GPS-mismatch, duplicate-invoice,
    // repeated-failed-login) were never detected at all.
    // ==========================================================
    enum class SmartAlertSeverity { INFO, WARNING, CRITICAL }
    data class SmartBusinessAlert(val id: String, val kind: String, val severity: SmartAlertSeverity, val message: String, val entityId: String? = null)

    suspend fun computeSmartBusinessAlerts(): List<SmartBusinessAlert> {
        val alerts = mutableListOf<SmartBusinessAlert>()

        // 1. Dealer due exceeds limit
        dealers.value.filter { it.creditLimit > 0 && it.dueBalance > it.creditLimit }.forEach {
            alerts += SmartBusinessAlert("DUE-${it.id}", "DealerDueExceeded", SmartAlertSeverity.CRITICAL, "${it.name}: due ৳${"%,.0f".format(it.dueBalance)} exceeds credit limit ৳${"%,.0f".format(it.creditLimit)}", it.id)
        }

        // 2. Employee absent 3 days — real consecutive-day check against actual attendance records, not just a total-absence count.
        employeeProfiles.value.filter { it.hasActiveAccess }.forEach { emp ->
            val recentDays = (0..6).map { java.time.LocalDate.now().minusDays(it.toLong()).toEpochDay() }
            val records = db.attendanceDao().getAllForEmployee(emp.id).first().associateBy { it.dateEpochDay }
            val consecutiveAbsent = recentDays.takeWhile { day -> records[day]?.checkedIn != true }.size
            if (consecutiveAbsent >= 3) {
                alerts += SmartBusinessAlert("ABS-${emp.id}", "EmployeeAbsent", SmartAlertSeverity.WARNING, "${emp.fullName} — টানা $consecutiveAbsent দিন absent", emp.id)
            }
        }

        // 3. Stock below minimum
        InventoryRepository.stockLevels.value.filter { it.isLowStock }.forEach {
            alerts += SmartBusinessAlert("STK-${it.productId}-${it.warehouseId}", "StockBelowMinimum", SmartAlertSeverity.WARNING, "${it.productName} at ${it.warehouseName} — reorder-level-এর নিচে (${it.quantityOnHand})", it.productId)
        }

        // 4. Product expiring soon — real FinishedGoodsReceipt.expiryDate check, within 30 days.
        finishedGoodsReceipts.value.filter { it.expiryDate != null && it.expiryDate.isBefore(LocalDate.now().plusDays(30)) && it.expiryDate.isAfter(LocalDate.now().minusDays(1)) }.forEach {
            alerts += SmartBusinessAlert("EXP-${it.id}", "ProductExpiringSoon", SmartAlertSeverity.WARNING, "${it.productId} batch ${it.batchCode} — ${it.expiryDate}-এ মেয়াদ শেষ", it.id)
        }

        // 5. Sales target unlikely to complete — real pace check: % of period elapsed vs % of target achieved.
        targets.value.filter { it.status == "ACTIVE" && !it.periodEnd.isBefore(LocalDate.now()) }.forEach { t ->
            val totalDays = (t.periodEnd.toEpochDay() - t.periodStart.toEpochDay() + 1).coerceAtLeast(1)
            val elapsedDays = (LocalDate.now().toEpochDay() - t.periodStart.toEpochDay() + 1).coerceIn(0, totalDays)
            val expectedPct = elapsedDays.toDouble() / totalDays * 100
            val actualPct = if (t.targetValue > 0) t.achievedValue / t.targetValue * 100 else 0.0
            if (expectedPct > 30 && actualPct < expectedPct * 0.6) { // meaningfully behind pace, not just noise this early
                alerts += SmartBusinessAlert("TGT-${t.id}", "TargetUnlikely", SmartAlertSeverity.WARNING, "${t.targetType} target for ${t.scopeId} — ${elapsedDays}/${totalDays} দিন পার হয়েছে কিন্তু achievement মাত্র ${"%.0f".format(actualPct)}%", t.id)
            }
        }

        // 6. GPS mismatch — real check-in distance/mock-detection from actual VisitLog rows, not a placeholder.
        visitLogs.value.filter { it.checkInMockSuspected || (it.checkInDistanceFromRetailerMeters ?: 0.0) > 500.0 }.take(10).forEach {
            alerts += SmartBusinessAlert("GPS-${it.id}", "GpsMismatch", SmartAlertSeverity.CRITICAL, "${it.employeeId} — retailer visit-এ GPS অসঙ্গতি (${if (it.checkInMockSuspected) "mock location সন্দেহ" else "দূরত্ব ${it.checkInDistanceFromRetailerMeters?.toInt()}m"})", it.id)
        }

        // 7. Duplicate invoice attempt — real heuristic: same dealer, same total, within 10 minutes of each other.
        val recentInvoices = salesInvoices.value.filter { !it.isDeleted && it.createdAt.isAfter(LocalDateTime.now().minusHours(24)) }
        recentInvoices.groupBy { it.dealerId }.forEach { (_, group) ->
            group.sortedBy { it.createdAt }.zipWithNext().forEach { (a, b) ->
                if (kotlin.math.abs(a.total - b.total) < 0.01 && java.time.Duration.between(a.createdAt, b.createdAt).toMinutes() < 10) {
                    alerts += SmartBusinessAlert("DUP-${b.id}", "DuplicateInvoiceAttempt", SmartAlertSeverity.WARNING, "${b.dealerName} — ${a.invoiceNo} ও ${b.invoiceNo} একই amount (৳${"%,.0f".format(b.total)}), ১০ মিনিটের মধ্যে", b.id)
                }
            }
        }

        // 8. Repeated failed login — real device-lock state, not a placeholder.
        if (_deviceLocked.value) {
            alerts += SmartBusinessAlert("LOGIN-device-lock", "RepeatedFailedLogin", SmartAlertSeverity.CRITICAL, "এই ডিভাইসে বারবার ভুল PIN — device লক হয়ে গেছে")
        }

        // 9. Warehouse shortage — real check: a DISPATCHED/APPROVED transfer whose source warehouse can no longer actually cover it.
        warehouseTransfers.value.filter { it.status == TransferStatus.APPROVED }.forEach { t ->
            t.lines.forEach { line ->
                val available = InventoryRepository.stockLevels.value.firstOrNull { it.productId == line.productId && it.warehouseId == t.sourceWarehouseId }?.quantityOnHand ?: 0.0
                if (available < line.quantity) {
                    alerts += SmartBusinessAlert("WHS-${t.id}-${line.productId}", "WarehouseShortage", SmartAlertSeverity.CRITICAL, "${t.transferNumber}: ${line.productId} — চাহিদা ${line.quantity} কিন্তু ${t.sourceWarehouseId}-এ আছে মাত্র $available", t.id)
                }
            }
        }

        return alerts
    }

    private val alertLastNotifiedAt = mutableMapOf<String, Long>()

    /** Real notification-fan-out for Smart Business Alerts — Notification + Dashboard Alert (both via createNotification, which already drives both surfaces) + a distinct Chairman Alert for CRITICAL severity. Dedup-guarded to once per 12h per alert id, so an ongoing issue doesn't spam a fresh notification every hourly tick. */
    suspend fun dispatchSmartBusinessAlerts() {
        val now = System.currentTimeMillis()
        val chairmanEmployeeId = employeeProfiles.value.firstOrNull { it.role == UserRole.CHAIRMAN && it.hasActiveAccess }?.id
        computeSmartBusinessAlerts().forEach { alert ->
            val lastSent = alertLastNotifiedAt[alert.id]
            if (lastSent != null && now - lastSent < 12 * 60 * 60 * 1000L) return@forEach
            alertLastNotifiedAt[alert.id] = now
            // Real Chairman-specific targeting for CRITICAL alerts (the requirement's "Chairman Alert" surface) — was previously untargeted, indistinguishable from a generic broadcast.
            createNotification(NotificationCategory.ALERT, alert.kind, alert.message, targetEmployeeId = if (alert.severity == SmartAlertSeverity.CRITICAL) chairmanEmployeeId else null)
            if (alert.severity == SmartAlertSeverity.CRITICAL) {
                logAudit("SmartBusinessAlert", alert.entityId ?: alert.id, "CHAIRMAN_ALERT", newValue = alert.message)
            }
        }
    }

    // ==========================================================
    // Section 12 — System Health Dashboard. Every field here reads a
    // REAL, already-tracked source (failedSyncIds, liveLocations,
    // pendingApprovalSlaItems, computeSmartBusinessAlerts,
    // computeSalesTrendAnalysis, ABMApplication.isOnlineNow) rather than
    // fabricating placeholder numbers.
    // ==========================================================
    data class SystemHealthSnapshot(
        val databaseHealthy: Boolean,
        val syncQueueAvailable: Boolean, // false — no real persistent Room sync-queue table exists in this codebase (SyncRetryWorker's own comment confirms it relies on Firestore's own offline cache, not an app-level queue). Never fabricate a depth number for something that doesn't exist.
        val failedSyncCount: Int, // partial, session-only count from the in-memory failedSyncIds tracker — NOT comprehensive (most .addOnFailureListener call sites in this codebase don't route through it), labeled as such in the UI
        val activeDeviceCount: Int,
        val offlineDeviceCount: Int,
        val todaysLoginSuccessCount: Int,
        val todaysLoginFailedCount: Int,
        val attendanceTodayPct: Double,
        val pendingApprovalCount: Int,
        val stockAlertCount: Int,
        val salesTotalLast7Days: Double, // real sales-invoice-only ledger total (was previously including opening-balance and correction entries)
        val salesTotalPrevious7Days: Double,
        val salesGrowthPct: Double?, // null if the previous period had zero sales (growth % is undefined, not fabricated as 0 or 100)
        val salesDailyLast7Days: List<Double>?, // real day-by-day buckets from actual dated ledger entries; null only if the query itself failed (never a fabricated flat list)
        val serverOnline: Boolean,
        val cloudFunctionsDeployed: Boolean,
        val lastBackupAt: LocalDateTime?,
        val lastBackupStatus: String,
        val errors: List<String>, // real query/computation failures, surfaced rather than silently shown as zero
    )

    suspend fun computeSystemHealthSnapshot(context: Context): SystemHealthSnapshot {
        val errors = mutableListOf<String>()
        val dbHealthy = try { db.employeeProfileDao().getAll().first(); true } catch (e: Exception) { errors += "Database check failed: ${e.message}"; false }
        val activeLocations = _liveLocations.value.filter { !it.isStale }
        val offlineLocations = _liveLocations.value.filter { it.isStale }

        val dhakaZone = java.time.ZoneId.of("Asia/Dhaka")
        val today = LocalDate.now().toEpochDay()
        val allEmployees = employeeProfiles.value.filter { it.hasActiveAccess }
        val presentToday = try {
            allEmployees.count { emp -> db.attendanceDao().getAllForEmployee(emp.id).first().any { it.dateEpochDay == today && it.checkedIn } }
        } catch (e: Exception) { errors += "Attendance query failed: ${e.message}"; 0 }
        val attendancePct = if (allEmployees.isEmpty()) 0.0 else presentToday.toDouble() / allEmployees.size * 100

        val backupHistory = try { BackupManager.history(context).first() } catch (e: Exception) { errors += "Backup history query failed: ${e.message}"; emptyList() }
        val lastBackup = backupHistory.maxByOrNull { it.createdAt }
        val backupStatus = when {
            lastBackup == null -> "NEVER"
            java.time.Duration.between(lastBackup.createdAt, LocalDateTime.now()).toDays() > 7 -> "OVERDUE"
            else -> "OK"
        }

        // Today's Login — real Asia/Dhaka calendar day (not UTC midnight), with both a start-of-day AND a next-day upper bound so the query can't accidentally spill into tomorrow. Split by the real LoginLogEntry.result field ("Success" | "Failed") rather than a single combined count.
        val dhakaToday = LocalDate.now(dhakaZone)
        val dayStartMillis = dhakaToday.atStartOfDay(dhakaZone).toInstant().toEpochMilli()
        val dayEndMillis = dhakaToday.plusDays(1).atStartOfDay(dhakaZone).toInstant().toEpochMilli()
        var loginSuccessCount = 0
        var loginFailedCount = 0
        try {
            val docs = syncCollection("loginLog")
                .whereGreaterThanOrEqualTo("atMillis", dayStartMillis)
                .whereLessThan("atMillis", dayEndMillis)
                .get().await()
            loginSuccessCount = docs.documents.count { it.getString("result") == "Success" }
            loginFailedCount = docs.documents.count { it.getString("result") == "Failed" }
        } catch (e: Exception) {
            errors += "Login log query failed: ${e.message}"
        }

        // Sales — real Sales Invoice ledger entries ONLY (postPartyLedgerEntry's "reason" for an actual sale always starts with "Sales Invoice "; excludes "Opening balance", correction-reversal entries, etc, which are real DEBIT rows but not actual sales).
        var salesTotalLast7d = 0.0
        var salesTotalPrev7d = 0.0
        var dailyBuckets: List<Double>? = null
        try {
            val allLedger = db.partyLedgerDao().getAll().first()
            val realSales = allLedger.filter { it.type == "DEBIT" && it.reason.startsWith("Sales Invoice ") }
            val now = LocalDateTime.now()
            val last7Start = now.minusDays(7)
            val prev7Start = now.minusDays(14)
            salesTotalLast7d = realSales.filter { LocalDateTime.ofInstant(Instant.ofEpochMilli(it.createdAtEpochMillis), ZoneOffset.UTC).isAfter(last7Start) }.sumOf { it.amount }
            salesTotalPrev7d = realSales.filter {
                val t = LocalDateTime.ofInstant(Instant.ofEpochMilli(it.createdAtEpochMillis), ZoneOffset.UTC)
                t.isAfter(prev7Start) && !t.isAfter(last7Start)
            }.sumOf { it.amount }
            // Real day-by-day buckets from actual dated entries — never a fabricated/interpolated series.
            dailyBuckets = (0..6).map { daysAgo ->
                val dayStart = now.minusDays(daysAgo.toLong()).toLocalDate().atStartOfDay()
                val dayEnd = dayStart.plusDays(1)
                realSales.filter {
                    val t = LocalDateTime.ofInstant(Instant.ofEpochMilli(it.createdAtEpochMillis), ZoneOffset.UTC)
                    !t.isBefore(dayStart) && t.isBefore(dayEnd)
                }.sumOf { it.amount }
            }.reversed()
        } catch (e: Exception) {
            errors += "Sales ledger query failed: ${e.message}"
        }
        val salesGrowthPct = if (salesTotalPrev7d > 0.0) ((salesTotalLast7d - salesTotalPrev7d) / salesTotalPrev7d) * 100 else null

        return SystemHealthSnapshot(
            databaseHealthy = dbHealthy,
            syncQueueAvailable = false, // honest — see class-level comment
            failedSyncCount = failedSyncIds.value.size,
            activeDeviceCount = activeLocations.size,
            offlineDeviceCount = offlineLocations.size,
            todaysLoginSuccessCount = loginSuccessCount,
            todaysLoginFailedCount = loginFailedCount,
            attendanceTodayPct = attendancePct,
            pendingApprovalCount = pendingApprovalSlaItems().size,
            stockAlertCount = computeSmartBusinessAlerts().count { it.kind == "StockBelowMinimum" || it.kind == "WarehouseShortage" },
            salesTotalLast7Days = salesTotalLast7d,
            salesTotalPrevious7Days = salesTotalPrev7d,
            salesGrowthPct = salesGrowthPct,
            salesDailyLast7Days = dailyBuckets,
            serverOnline = com.abm.erp.ABMApplication.isOnlineNow(),
            cloudFunctionsDeployed = false, // see SETUP_FIREBASE.md — real status, not assumed
            lastBackupAt = lastBackup?.createdAt,
            lastBackupStatus = backupStatus,
            errors = errors,
        )
    }

    fun computeRiskAlerts(): List<RiskAlert> {
        val alerts = mutableListOf<RiskAlert>()
        dealers.value.filter { riskBand(it) == RiskBand.RED }.forEach {
            alerts.add(RiskAlert(java.util.UUID.randomUUID().toString(), RiskBand.RED, "Dealer Credit", "${it.name} due (৳${"%,.0f".format(it.dueBalance)}) is dangerously high vs 90-day sales"))
        }
        InventoryRepository.stockLevels.value.filter { it.isLowStock }.take(5).forEach {
            alerts.add(RiskAlert(java.util.UUID.randomUUID().toString(), RiskBand.YELLOW, "Inventory", "${it.productName} at ${it.warehouseName} is at/below reorder level"))
        }
        val pendingApprovalsCount = approvals.value.count { it.status == ApprovalStatus.PENDING }
        if (pendingApprovalsCount > 5) {
            alerts.add(RiskAlert(java.util.UUID.randomUUID().toString(), RiskBand.YELLOW, "Approval Backlog", "$pendingApprovalsCount approvals pending — may be stalling operations"))
        }
        return alerts
    }

    /** Demand Forecast — per-product projected 30-day demand from actual stock movement history (OUT-type movements = real consumption/sales), not a canned number. */
    fun computeDemandForecast(): List<DemandForecastRow> {
        val movements = InventoryRepository.movements.value
        return movements.filter { it.type == MovementType.OUT }
            .groupBy { it.productName }
            .map { (name, list) ->
                val total = list.sumOf { it.quantity }
                val daily = total / 90.0 // approximating over the same 90-day window used elsewhere in this app
                DemandForecastRow(name, daily, daily * 30)
            }
            .sortedByDescending { it.projectedNext30Days }
    }

    /** Collection Forecast — projected 30-day cash collection, extrapolated from verified PartyCollection history. */
    fun computeCollectionForecast(): Double {
        val verified = partyCollections.value.filter { it.status == "VERIFIED" }
        if (verified.isEmpty()) return 0.0
        val oldestDate = verified.minOf { it.createdAt }
        val daysSpan = java.time.temporal.ChronoUnit.DAYS.between(oldestDate, LocalDateTime.now()).coerceAtLeast(1)
        val dailyAvg = verified.sumOf { it.amount } / daysSpan
        return dailyAvg * 30
    }

    /** Production Forecast — projected 30-day finished-goods output, extrapolated from completed Production Orders' actual target quantities. */
    fun computeProductionForecast(): Double {
        val completed = productionOrders.value.filter { it.status == "COMPLETED" }
        if (completed.isEmpty()) return 0.0
        val oldestDate = completed.minOf { it.createdAt }
        val daysSpan = java.time.temporal.ChronoUnit.DAYS.between(oldestDate, LocalDateTime.now()).coerceAtLeast(1)
        val dailyAvg = completed.sumOf { it.targetQty } / daysSpan
        return dailyAvg * 30
    }

    /** Inventory Forecast — projected days-until-stockout per low-stock item, from actual consumption rate (StockMovement OUT history), not a canned number. */
    fun computeInventoryForecast(): List<Pair<String, Int>> {
        val stockLevelsNow = InventoryRepository.stockLevels.value
        val demandRows = computeDemandForecast().associateBy { it.productName }
        return stockLevelsNow.filter { it.isLowStock }.map { level ->
            val dailyDemand = demandRows[level.productName]?.avgDailyDemand ?: 0.0
            val daysLeft = if (dailyDemand <= 0.0) 999 else (level.quantityOnHand / dailyDemand).toInt()
            level.productName to daysLeft
        }.sortedBy { it.second }
    }

    /** Smart Business Recommendation — a short, prioritized action list synthesized from the other AI Framework signals (health score, risk alerts, forecasts) rather than a separate hardcoded tip list. */
    fun smartBusinessRecommendations(): List<String> {
        val recs = mutableListOf<String>()
        val health = computeBusinessHealthScore()
        if (health.collectionComponent < 15) recs.add("Collection component কম (${health.collectionComponent}/25) — বকেয়া দ্রুত আদায়ের উপর জোর দিন।")
        if (health.stockHealthComponent < 15) recs.add("Stock health কম (${health.stockHealthComponent}/25) — low-stock item গুলো এখনই re-order করুন।")
        val inactiveDealersNow = inactiveDealers()
        if (inactiveDealersNow.isNotEmpty()) recs.add("${inactiveDealersNow.size} জন dealer ৯০ দিনে কোনো sales করেননি — visit/follow-up প্ল্যান করুন।")
        val coverage = outletCoverageRatio()
        if (coverage < 0.7) recs.add("Outlet coverage মাত্র ${(coverage * 100).toInt()}% — বাকি outlet-গুলো visit-এর আওতায় আনুন।")
        val pendingApprovalsCount = approvals.value.count { it.status == ApprovalStatus.PENDING }
        if (pendingApprovalsCount > 5) recs.add("$pendingApprovalsCount টা approval আটকে আছে — escalate/forward করে দ্রুত সমাধান করুন।")
        if (recs.isEmpty()) recs.add("সবকিছু স্বাভাবিক দেখাচ্ছে — এখন কোনো জরুরি action প্রয়োজন নেই।")
        return recs
    }

    /** Dealer & Retailer Analytics — Credit Utilization: how much of the credit limit is currently used up (0.0–1.0+); no limit set returns 0.0 (nothing to utilize against). */
    fun creditUtilization(dealer: Dealer): Double = if (dealer.creditLimit <= 0) 0.0 else (dealer.dueBalance / dealer.creditLimit).coerceAtLeast(0.0)
    fun creditUtilization(retailer: Retailer): Double = if (retailer.creditLimit <= 0) 0.0 else (retailer.dueBalance / retailer.creditLimit).coerceAtLeast(0.0)

    /** Inactive Dealer Detection — no sales activity recorded in the trailing window; a real "last order date" would sharpen this further once per-order dealer timestamps are tracked historically. */
    fun inactiveDealers(): List<Dealer> = dealers.value.filter { it.salesLast90Days <= 0.0 && it.isActive && !it.isDeleted }

    /** Inactive Outlet Detection — same idea for Retailer/Outlet, using visit recency instead of sales (retailers don't carry their own 90-day sales figure). */
    fun inactiveRetailers(sinceDays: Long = 60): List<Retailer> {
        val cutoff = LocalDateTime.now().minusDays(sinceDays)
        val visitedRecently = visitLogs.value.filter { it.partyType == PartyType.RETAILER && it.checkInAt.isAfter(cutoff) }.map { it.partyId }.toSet()
        return retailers.value.filter { it.isActive && !it.isDeleted && it.id !in visitedRecently }
    }

    /** Module 9 (SFA) — Route Compliance: what fraction of a beat's assigned outlets were actually visited today. */
    fun routeComplianceToday(route: SalesRoute): Double {
        if (route.outletIds.isEmpty()) return 1.0
        val todayStart = LocalDateTime.now().toLocalDate().atStartOfDay()
        val visitedToday = visitLogs.value.filter { it.partyType == PartyType.RETAILER && it.checkInAt.isAfter(todayStart) }.map { it.partyId }.toSet()
        return route.outletIds.count { it in visitedToday }.toDouble() / route.outletIds.size
    }

    /** Missed Outlet Detection — which of a beat's assigned outlets were NOT visited today. */
    fun missedOutletsToday(route: SalesRoute): List<Retailer> {
        val todayStart = LocalDateTime.now().toLocalDate().atStartOfDay()
        val visitedToday = visitLogs.value.filter { it.partyType == PartyType.RETAILER && it.checkInAt.isAfter(todayStart) }.map { it.partyId }.toSet()
        val missedIds = route.outletIds.filter { it !in visitedToday }.toSet()
        return retailers.value.filter { it.id in missedIds }
    }

    /** Coverage Tracking — company-wide: what fraction of ALL registered outlets have been visited at least once in the trailing window. */
    fun outletCoverageRatio(sinceDays: Long = 30): Double {
        val activeRetailers = retailers.value.filter { it.isActive && !it.isDeleted }
        if (activeRetailers.isEmpty()) return 1.0
        val cutoff = LocalDateTime.now().minusDays(sinceDays)
        val visited = visitLogs.value.filter { it.partyType == PartyType.RETAILER && it.checkInAt.isAfter(cutoff) }.map { it.partyId }.toSet()
        return activeRetailers.count { it.id in visited }.toDouble() / activeRetailers.size
    }


    // ---- Notification Framework ----
    lateinit var notifications: StateFlow<List<NotificationEntry>>
        private set
    lateinit var territories: StateFlow<List<Territory>>
        private set


    /** Connects a business event to the notification inbox — every module that fires one of these calls THIS same function instead of building its own alert plumbing. */
    fun createNotification(category: NotificationCategory, title: String, body: String, targetEmployeeId: String? = null) {
        scope.launch {
            val entity = com.abm.erp.data.room.NotificationEntryEntity(
                id = java.util.UUID.randomUUID().toString(), category = category.name, title = title, body = body,
                targetEmployeeId = targetEmployeeId, isRead = false, createdAtEpochMillis = System.currentTimeMillis(),
            )
            db.notificationEntryDao().upsert(entity)
            syncCollection("notifications").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push notification failed", it) }
        }
    }

    fun markNotificationRead(id: String) {
        scope.launch {
            db.notificationEntryDao().markRead(id)
            syncCollection("notifications").document(id).update("isRead", true)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push notification-read failed", it) }
        }
    }

    /** v86, Module 13 — "Mark all read" was genuinely missing; marks every currently-unread notification for this employee, real per-record writes (not a fake bulk flag), so the unread badge count (also new, see notificationBadgeCount below) actually reflects reality afterward. */
    fun markAllNotificationsRead() {
        scope.launch {
            val unread = notifications.value.filter { !it.isRead }
            unread.forEach { entry ->
                db.notificationEntryDao().markRead(entry.id)
                syncCollection("notifications").document(entry.id).update("isRead", true)
                    .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push mark-all-read failed for ${entry.id}", it) }
            }
        }
    }

    /** v86, Module 13/17 — real unread count for badge display; computed from the same `notifications` StateFlow every screen already reads, so it can never drift from what the Notifications screen itself shows. */
    fun notificationBadgeCount(): Int = notifications.value.count { !it.isRead }

    /**
     * Universal Search — one search box across every core entity instead of
     * each module needing its own. Pure in-memory substring match over what's
     * already loaded via StateFlow (no extra Firestore/Room query), so it
     * works fully offline too, consistent with the rest of this app.
     */
    fun universalSearch(query: String): List<UniversalSearchResult> {
        if (query.isBlank()) return emptyList()
        val q = query.trim().lowercase()
        val results = mutableListOf<UniversalSearchResult>()

        // Territory / zone results. Searching a place name is a real thing people do
        // ("Barishal"), and it previously only surfaced the dealers in it. A zone is itself a
        // useful destination — its own dealers, retailers, sales and due — so it gets its own
        // result type and its own page. Zones are derived from the dealer/retailer data that
        // already exists; no new master list is introduced.
        run {
            // Dealer carries `zone`; Retailer carries `market` (there is no zone field on
            // Retailer) — both are place labels, so both feed the zone list.
            val zones = (dealers.value.filter { !it.isDeleted }.map { it.zone } +
                retailers.value.filter { !it.isDeleted }.map { it.market })
                .filter { it.isNotBlank() }
                .distinct()
            zones.filter { it.lowercase().contains(q) }.take(6).forEach { zone ->
                val zoneDealers = dealers.value.count { !it.isDeleted && it.zone == zone }
                val zoneDue = dealers.value.filter { !it.isDeleted && it.zone == zone }.sumOf { it.dueBalance }
                results.add(
                    UniversalSearchResult(
                        "Territory", zone, zone,
                        "$zoneDealers dealers · Due ৳${"%,.0f".format(zoneDue)}",
                        "territory/${java.net.URLEncoder.encode(zone, "UTF-8")}",
                    ),
                )
            }
        }

        dealers.value.filter { !it.isDeleted && (it.name.lowercase().contains(q) || it.phone.contains(q) || it.zone.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("Dealer", it.id, it.name, "${it.zone} · Due ৳${"%,.0f".format(it.dueBalance)}", "statement/DEALER/${it.id}")) }
        retailers.value.filter { !it.isDeleted && (it.name.lowercase().contains(q) || it.phone.contains(q) || it.outletCategory.lowercase().contains(q) || it.retailerCode.lowercase().contains(q) || it.ownerName.lowercase().contains(q) || it.market.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("Retailer", it.id, it.name, "${it.retailerCode} · ${it.outletCategory}/${it.outletType}", "statement/RETAILER/${it.id}")) }
        salesInvoices.value.filter { !it.isDeleted && (it.invoiceNo.lowercase().contains(q) || it.dealerName.lowercase().contains(q) || it.status.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("SalesInvoice", it.id, it.invoiceNo, "${it.dealerName} · ৳${"%,.0f".format(it.total)}", "invoice_doc/${it.id}")) }
        tasks.value.filter { !it.isDeleted && (it.title.lowercase().contains(q) || it.assignee.lowercase().contains(q) || it.status.name.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("Task", it.id, it.title, it.assignee, "tasks")) }
        CrmRepository.leads.value.filter { !it.isDeleted && (it.name.lowercase().contains(q) || it.phone.contains(q) || it.status.name.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("Lead", it.id, it.name, "${it.source} · ${it.status}", "crm")) }
        approvals.value.filter { it.detail.lowercase().contains(q) || it.fromEmployee.lowercase().contains(q) || it.status.name.lowercase().contains(q) }
            // Decision 2 (v113-72) — no central "approvals" screen any more; a search hit
            // opens the module that owns the request.
            .forEach { results.add(UniversalSearchResult("ApprovalRequest", it.id, it.type.name, it.detail, approvalOwnerRoute(it.entityType, it.type))) }
        InventoryRepository.products.value.filter { !it.isDeleted && (it.name.lowercase().contains(q) || it.sku.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("Product", it.id, it.name, "${it.sku} · ৳${it.defaultUnitPrice}", "inventory")) }
        PurchaseRepository.suppliers.value.filter { !it.isDeleted && (it.name.lowercase().contains(q) || it.phone.contains(q)) }
            .forEach { results.add(UniversalSearchResult("Supplier", it.id, it.name, "Due ৳${"%,.0f".format(it.dueBalance)}", "purchase")) }
        PurchaseRepository.purchaseOrders.value.filter { it.poNo.lowercase().contains(q) || it.supplierName.lowercase().contains(q) || it.status.lowercase().contains(q) }
            .forEach { results.add(UniversalSearchResult("PurchaseOrder", it.id, it.poNo, "${it.supplierName} · ${it.status}", "purchase")) }
        customerComplaints.value.filter { !it.isDeleted && (it.complaintNo.lowercase().contains(q) || it.dealerName.lowercase().contains(q) || it.description.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("CustomerComplaint", it.id, it.complaintNo, "${it.dealerName} · ${it.status}", "crm")) }
        InventoryRepository.stockCounts.value.filter { it.countNo.lowercase().contains(q) || it.warehouseName.lowercase().contains(q) }
            .forEach { results.add(UniversalSearchResult("StockCount", it.id, it.countNo, "${it.warehouseName} · ${it.status}", "inventory")) }
        salesOrders.value.filter { !it.isDeleted && (it.orderNo.lowercase().contains(q) || it.dealerName.lowercase().contains(q) || it.status.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("SalesOrder", it.id, it.orderNo, "${it.dealerName} · ${it.status}", "sales")) }
        employeeProfiles.value.filter { !it.isDeleted && (it.fullName.lowercase().contains(q) || it.employeeCode.lowercase().contains(q) || it.mobile.contains(q) || it.department.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("EmployeeProfile", it.id, it.fullName, "${it.employeeCode} · ${it.designation.ifBlank { it.role.name }}", "hrm")) }
        transferRequests.value.filter { it.employeeName.lowercase().contains(q) || it.transferType.lowercase().contains(q) }
            .forEach { results.add(UniversalSearchResult("TransferRequest", it.id, it.employeeName, "${it.transferType}: ${it.fromValue} → ${it.toValue} (${it.stage})", "hrm")) }
        locationAlerts.value.filter { it.type.lowercase().contains(q) || it.message.lowercase().contains(q) }
            .forEach { results.add(UniversalSearchResult("LocationAlert", it.id, it.type, it.message, "dealers")) }
        securityEvents.value.filter { it.type.lowercase().contains(q) || it.message.lowercase().contains(q) || it.employeeName.lowercase().contains(q) }
            .forEach { results.add(UniversalSearchResult("SecurityEvent", it.id, it.type, it.message, "dealers")) }
        executiveExceptions.value.filter { it.type.lowercase().contains(q) || it.message.lowercase().contains(q) }
            .forEach { results.add(UniversalSearchResult("ExecutiveException", it.id, it.type, it.message, "dealers")) }
        managementActions.value.filter { it.title.lowercase().contains(q) || it.assignedTo.lowercase().contains(q) }
            .forEach { results.add(UniversalSearchResult("ManagementAction", it.id, it.title, "${it.assignedTo} · ${it.status}", "dealers")) }
        administrativeLocations.value.filter { it.active && (it.nameEn.lowercase().contains(q) || it.nameBn.contains(query.trim())) }.take(20)
            .forEach { results.add(UniversalSearchResult("AdministrativeLocation", it.id, "${it.nameEn} / ${it.nameBn}", "${it.type} · ${adminHierarchyPath(it.id)}", "dealers")) }
        PurchaseRepository.purchaseRequests.value.filter { !it.isDeleted && (it.requestNo.lowercase().contains(q) || it.reason.lowercase().contains(q) || it.status.lowercase().contains(q)) }
            .forEach { results.add(UniversalSearchResult("PurchaseRequest", it.id, it.requestNo, "${it.status} · ${it.reason}", "purchase")) }
        // Better sorting — an exact (case-insensitive) title match belongs above a mere substring match, then alphabetical within each group.
        val sorted = results.sortedWith(compareByDescending<UniversalSearchResult> { it.title.equals(query.trim(), ignoreCase = true) }.thenBy { it.title.lowercase() })
        return sorted.take(50) // enough for a phone screen without loading every match on a broad query
    }

    /**
     * CRM — Dealer Health Score (0-100), composed only from real, already-computed signals:
     * risk band (payment behavior), credit utilization, and recent visit coverage.
     * No fabricated inputs — if a signal is unavailable (e.g. no visits logged yet),
     * that component simply doesn't penalize the score rather than assuming the worst.
     */
    /** HR Excellence — real "checked in today" status, replacing the earlier `emp.id.hashCode() % 3 != 2` demo-proxy in AttendanceTab. Reads the actual AttendanceRecord for today via the existing DAO. */
    fun isPresentTodayFlow(employeeId: String): kotlinx.coroutines.flow.Flow<Boolean> =
        db.attendanceDao().getAllForEmployee(employeeId).map { records ->
            val today = LocalDate.now().toEpochDay()
            records.any { it.dateEpochDay == today && it.checkedIn }
        }

    /** Same shape as isPresentTodayFlow/presentTodayCountFlow, for today's late-arrival count in the HR mini-dashboard. */
    fun isLateTodayFlow(employeeId: String): kotlinx.coroutines.flow.Flow<Boolean> =
        db.attendanceDao().getAllForEmployee(employeeId).map { records ->
            val today = LocalDate.now().toEpochDay()
            records.any { it.dateEpochDay == today && it.isLate }
        }

    fun lateTodayCountFlow(employeeIds: List<String>): kotlinx.coroutines.flow.Flow<Int> {
        if (employeeIds.isEmpty()) return kotlinx.coroutines.flow.flowOf(0)
        return kotlinx.coroutines.flow.combine(employeeIds.map { isLateTodayFlow(it) }) { lates -> lates.count { it } }
    }

    /** v86 - real per-employee attendance history, used to replace the fabricated weekly-hours chart. */
    fun attendanceRecordsFor(employeeId: String) = db.attendanceDao().getAllForEmployee(employeeId)

    /** Combines multiple employees' isPresentTodayFlow into a single Flow<Int> count — needed because Compose can't call collectAsState() inside a plain map{}/associate{} lambda; this does the combining at the Flow level instead, so the UI only needs one collectAsState() call. */
    fun presentTodayCountFlow(employeeIds: List<String>): kotlinx.coroutines.flow.Flow<Int> {
        if (employeeIds.isEmpty()) return kotlinx.coroutines.flow.flowOf(0)
        return kotlinx.coroutines.flow.combine(employeeIds.map { isPresentTodayFlow(it) }) { presences -> presences.count { it } }
    }

    /** v86, Module 3 — Weekly 50% Due Rule: rolls the running weekly-paid total over to a fresh week (Monday reset) before adding this collection's amount, so a payment made in a new week never gets added onto a stale prior week's total. */
    internal fun updateWeeklyPaidAmount(dealerId: String, amount: Double) {  // v113-91: CollectionsEngine.kt needs this from another file
        scope.launch {
            val dealer = dealers.value.firstOrNull { it.id == dealerId } ?: return@launch
            val currentWeekStart = WeeklyDueRule.weekStartEpochDay()
            val newWeeklyPaid = if (dealer.weekStartEpochDay == currentWeekStart) dealer.weeklyPaidAmount + amount else amount
            db.dealerDao().updateWeeklyPaid(dealerId, newWeeklyPaid, currentWeekStart)
            syncCollection("dealers").document(dealerId)
                .update(mapOf("weeklyPaidAmount" to newWeeklyPaid, "weekStartEpochDay" to currentWeekStart))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push weekly-paid update failed", it) }
        }
    }

    /** v86, Module 3 — real eligibility check (not fabricated): looks up the dealer's live monthlyTarget/weeklyPaidAmount and runs WeeklyDueRule against today's date. Call this before allowing new credit-invoice creation; the caller decides whether to show a warning or hard-block based on recordStatus/override. */
    /**
     * v86, Module 10 — Attendance Correction Request. Reuses the existing
     * ApprovalRequest system (entityType/entityId carry the correction
     * details) instead of a whole new entity — a manager approving this
     * through the normal Approval Center actually flips the attendance
     * record when it reaches final approval (see advanceApproval below).
     */
    fun requestAttendanceCorrection(employeeId: String, dateEpochDay: Long, requestedCheckedIn: Boolean, reason: String): Boolean {
        if (reason.isBlank()) return false
        raiseApprovalRequest(
            ApprovalType.OTHER,
            "Attendance correction for $employeeId on day $dateEpochDay -> ${if (requestedCheckedIn) "Present" else "Absent"}: $reason",
            "AttendanceRecord", "$employeeId|$dateEpochDay|$requestedCheckedIn",
        )
        return true
    }

    /** Section 9 — Business Rule Engine getter. Falls back to `default` if the Chairman has never set this rule, so every consumer keeps working exactly as before until someone actually changes it. */
    fun businessRuleDouble(key: String, default: Double): Double = businessRules.value.firstOrNull { it.key == key }?.value ?: default

    /** Chairman-only setter — "Entire ERP updates automatically" because every consumer reads businessRuleDouble() live off the businessRules StateFlow, not a cached/compiled constant. */
    fun setBusinessRule(key: String, label: String, type: BusinessRuleType, value: Double): Boolean {
        if (currentUser.role != UserRole.CHAIRMAN) {
            logAudit("BusinessRule", key, "DENY", oldValue = currentUser.role.name, newValue = "SET")
            return false
        }
        val old = businessRules.value.firstOrNull { it.key == key }?.value
        val rule = BusinessRule(key = key, label = label, type = type, value = value, companyId = currentUser.companyId, updatedBy = currentUser.employeeId, updatedByName = currentUser.name)
        scope.launch {
            db.businessRuleDao().upsert(rule.toEntity())
            syncCollection("businessRules").document(key).set(rule.toEntity())
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push business-rule failed", it) }
            logAudit("BusinessRule", key, "SET", oldValue = old, newValue = value, reason = "by Chairman ${currentUser.name}")
        }
        return true
    }
    /** Section 10 — Company Settings Center. Real, single-record-per-company config the Chairman edits; every field falls back to a sane default until touched, matching Section 9's "strict upgrade" pattern. */
    fun companySettings(): CompanySettings = companySettingsList.value.firstOrNull { it.id == currentUser.companyId } ?: CompanySettings(id = currentUser.companyId)

    fun updateCompanySettings(updated: CompanySettings): Boolean {
        if (currentUser.role != UserRole.CHAIRMAN) {
            logAudit("CompanySettings", updated.id, "DENY", oldValue = currentUser.role.name, newValue = "UPDATE")
            return false
        }
        val old = companySettings()
        val toSave = updated.copy(id = currentUser.companyId, updatedBy = currentUser.name, updatedAt = LocalDateTime.now())
        scope.launch {
            db.companySettingsDao().upsert(toSave.toEntity())
            syncCollection("companySettings").document(toSave.id).set(toSave.toEntity())
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push company-settings failed", it) }
            logAudit("CompanySettings", toSave.id, "UPDATE", oldValue = old, newValue = toSave, reason = "by Chairman ${currentUser.name}")
        }
        return true
    }

    fun addCompanyHoliday(date: LocalDate, name: String): Boolean {
        if (currentUser.role != UserRole.CHAIRMAN) return false
        val current = companySettings()
        val updatedRaw = (current.holidaysRaw.split(";").filter { it.isNotBlank() } + "${date.toEpochDay()}:$name").joinToString(";")
        return updateCompanySettings(current.copy(holidaysRaw = updatedRaw))
    }


    fun checkWeeklyDueEligibility(dealerId: String): WeeklyDueRule.EligibilityResult {
        val dealer = dealers.value.firstOrNull { it.id == dealerId }
            ?: return WeeklyDueRule.EligibilityResult(true, 0.0, 0.0, 0.0, 0.0, "Dealer not found.")
        // A manager's TEMPORARILY_APPROVED override always wins, regardless of the underlying numbers.
        if (dealer.creditStatus == "TEMPORARILY_APPROVED") {
            return WeeklyDueRule.EligibilityResult(true, 0.0, 0.0, dealer.weeklyPaidAmount, 0.0, "Manually approved by ${dealer.creditStatusChangedBy ?: "manager"}: ${dealer.creditStatusReason ?: "no reason recorded"}.")
        }
        val currentWeekStart = WeeklyDueRule.weekStartEpochDay()
        // If the dealer's stored weeklyPaidAmount is from a PRIOR week, treat it as 0 for eligibility purposes (the real reset happens lazily on the next collection, but eligibility must not use stale data either).
        val effectiveWeeklyPaid = if (dealer.weekStartEpochDay == currentWeekStart) dealer.weeklyPaidAmount else 0.0
        return WeeklyDueRule.checkEligibility(dealer.monthlyTarget, effectiveWeeklyPaid, tuesdayCheckpointPct = businessRuleDouble("WEEKLY_DUE_PCT", 50.0))
    }

    /** v86, Module 3 — manual manager override of a dealer's credit status. Requires a non-blank comment (enforced here, not just in the UI) and is always audit-logged with who/when/why. */
    fun setDealerCreditStatus(dealerId: String, status: String, reasonComment: String): Boolean {
        if (reasonComment.isBlank()) {
            com.abm.erp.config.AppLog.w("MockRepository", "setDealerCreditStatus rejected: a reason comment is required for any manual credit-status override")
            return false
        }
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            logAudit("Dealer", dealerId, "DENY", oldValue = currentUser.role.name, newValue = "CREDIT_STATUS_OVERRIDE")
            return false
        }
        scope.launch {
            val now = System.currentTimeMillis()
            db.dealerDao().updateCreditStatus(dealerId, status, reasonComment, currentUser.name, now)
            syncCollection("dealers").document(dealerId)
                .update(mapOf("creditStatus" to status, "creditStatusReason" to reasonComment, "creditStatusChangedBy" to currentUser.name, "creditStatusChangedAtEpochMillis" to now))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push credit-status override failed", it) }
            logAudit("Dealer", dealerId, "CREDIT_STATUS_OVERRIDE", newValue = "$status — $reasonComment")
        }
        return true
    }

    /** v86, Module 3 — fixes a real gap: monthlyTarget had no way to be SET anywhere in the UI, meaning the whole Weekly 50% Rule was dead for every dealer (always defaulted to 0 = "not configured"). This is the missing setter, wired to a UI control in DealersScreen's Insights tab. */
    fun setDealerMonthlyTarget(dealerId: String, target: Double): Boolean {
        if (target < 0) return false
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.EDIT)) {
            logAudit("Dealer", dealerId, "DENY", oldValue = currentUser.role.name, newValue = "SET_MONTHLY_TARGET")
            return false
        }
        scope.launch {
            db.dealerDao().updateMonthlyTarget(dealerId, target)
            syncCollection("dealers").document(dealerId).update("monthlyTarget", target)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push monthly-target update failed", it) }
            logAudit("Dealer", dealerId, "SET_MONTHLY_TARGET", newValue = target)
        }
        return true
    }

    /** v86, Module 3/5 — Promise-to-Pay / Broken Commitment. Recording a promise replaces any prior one; the promise is naturally cleared once dueBalance reaches 0 via normal collection flow. */
    fun recordPromiseToPay(dealerId: String, date: LocalDateTime, amount: Double, note: String): Boolean {
        if (amount <= 0) return false
        scope.launch {
            val epochMillis = date.toInstant(ZoneOffset.UTC).toEpochMilli()
            db.dealerDao().setPromiseToPay(dealerId, epochMillis, amount, note)
            syncCollection("dealers").document(dealerId).update(mapOf("promiseToPayEpochMillis" to epochMillis, "promiseToPayAmount" to amount, "promiseNote" to note))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push promise-to-pay failed", it) }
            logAudit("Dealer", dealerId, "PROMISE_TO_PAY", newValue = "৳$amount by $date — $note")
        }
        return true
    }

    /** Real (not fabricated) broken-commitment check: a promise exists, its date has passed, and the dealer's current due balance shows the promised amount clearly wasn't paid. */
    fun isCommitmentBroken(dealer: Dealer): Boolean {
        val promiseDate = dealer.promiseToPayDate ?: return false
        return promiseDate.isBefore(LocalDateTime.now()) && dealer.dueBalance > 0 && dealer.promiseToPayAmount > 0
    }

    fun dealerHealthScore(dealer: Dealer): Int {
        val riskComponent = when (riskBand(dealer)) { RiskBand.GREEN -> 50; RiskBand.YELLOW -> 30; RiskBand.RED -> 10 }
        val utilization = creditUtilization(dealer)
        val creditComponent = (30 * (1 - utilization.coerceIn(0.0, 1.0))).toInt()
        val recentVisit = visitLogs.value.any { it.partyType == PartyType.DEALER && it.partyId == dealer.id && it.checkInAt.isAfter(LocalDateTime.now().minusDays(30)) }
        val visitComponent = if (recentVisit) 20 else 10
        return (riskComponent + creditComponent + visitComponent).coerceIn(0, 100)
    }

    /** Retailer Health Score (0-100) — Retailer has no salesLast90Days field like Dealer, so this honestly uses only the two signals that DO exist: credit utilization and recent visit coverage, weighted proportionally rather than pretending a third signal exists. */
    fun retailerHealthScore(retailer: Retailer): Int {
        val utilization = creditUtilization(retailer)
        val creditComponent = (60 * (1 - utilization.coerceIn(0.0, 1.0))).toInt()
        val recentVisit = visitLogs.value.any { it.partyType == PartyType.RETAILER && it.partyId == retailer.id && it.checkInAt.isAfter(LocalDateTime.now().minusDays(30)) }
        val visitComponent = if (recentVisit) 40 else 20
        return (creditComponent + visitComponent).coerceIn(0, 100)
    }

    /** CRM — friendly territory/route name instead of showing the raw territoryId string in the UI. Falls back to the id itself if no matching Territory record exists yet (never fabricates a name). */
    fun territoryName(id: String?): String {
        if (id.isNullOrBlank()) return "অনির্দিষ্ট"
        val t = territories.value.firstOrNull { it.id == id }
        return t?.zoneName ?: t?.market ?: t?.district ?: id
    }

    fun riskBand(dealer: Dealer): RiskBand {
        val ratio = if (dealer.salesLast90Days == 0.0) 1.0 else dealer.dueBalance / dealer.salesLast90Days
        return when {
            ratio < 0.3 -> RiskBand.GREEN
            ratio < 0.6 -> RiskBand.YELLOW
            else -> RiskBand.RED
        }
    }

    /**
     * Module 16 — Sales Forecast. A real computed projection (simple daily-
     * average extrapolation over the last 90 days), not canned/static text.
     * Genuine ML forecasting needs a real historical time-series this
     * prototype doesn't yet capture per-day — this is the honest, currently
     * buildable version: still a live number pulled from actual dueBalance/
     * salesLast90Days data, not a hardcoded string.
     */
    fun computeSalesForecast(dealer: Dealer): SalesForecastResult {
        val dailyAvg = dealer.salesLast90Days / 90.0
        val projected30d = dailyAvg * 30
        val trend = when {
            dealer.salesLast90Days <= 0.0 -> "STABLE"
            dailyAvg * 30 > dealer.salesLast90Days * 0.4 -> "GROWING"
            dailyAvg * 30 < dealer.salesLast90Days * 0.2 -> "DECLINING"
            else -> "STABLE"
        }
        return SalesForecastResult(dealer.name, dealer.salesLast90Days, dailyAvg, projected30d, trend)
    }

    fun computeZoneForecast(zone: String): SalesForecastResult {
        val zoneDealers = dealers.value.filter { it.zone == zone }
        val total90d = zoneDealers.sumOf { it.salesLast90Days }
        val dailyAvg = total90d / 90.0
        val projected30d = dailyAvg * 30
        return SalesForecastResult(zone, total90d, dailyAvg, projected30d, if (total90d > 0) "STABLE" else "STABLE")
    }

    data class TrendDataPoint(val dayEpoch: Long, val value: Double)
    data class TrendAnalysisResult(
        val dataPoints: List<TrendDataPoint>, // real historical values, one per day in the requested range — for charting
        val slopePerDay: Double, // linear-regression trend — positive = growing, negative = declining
        val interceptAtRangeStart: Double,
        val projectedNextPeriodTotal: Double, // regression-based projection for a period of the SAME length as the requested range, immediately following it
        val rSquared: Double, // goodness-of-fit (0-1) — how much of the variation the trend line actually explains, shown alongside the number so it's never presented as more certain than it is
    )

    /**
     * Advanced Analytics — real linear-regression trend analysis over ANY
     * custom date range (not a fixed 30/90-day window), for sales
     * (DEBIT ledger entries) against a Dealer/Retailer/zone scope. This
     * is a genuine statistical trend fit (least-squares regression), a
     * real step up from the earlier "daily average × 30" style
     * projection — while still being honest that it's a linear fit on
     * real data, not a trained ML model.
     */
    suspend fun computeSalesTrendAnalysis(scopeId: String?, fromDate: LocalDate, toDate: LocalDate): TrendAnalysisResult {
        val fromEpoch = fromDate.toEpochDay()
        val toEpoch = toDate.toEpochDay()
        val dayCount = (toEpoch - fromEpoch + 1).coerceAtLeast(1)
        val relevantIds: Set<String>? = scopeId?.let { id ->
            dealers.value.filter { it.id == id || it.zone.equals(id, ignoreCase = true) }.map { it.id }.toSet() +
                retailers.value.filter { it.id == id }.map { it.id }.toSet()
        }
        val ledgerAll = db.partyLedgerDao().getAll().first()
        val relevant = ledgerAll.filter { entry ->
            entry.type == "DEBIT" &&
                (relevantIds == null || entry.partyId in relevantIds) &&
                LocalDateTime.ofInstant(Instant.ofEpochMilli(entry.createdAtEpochMillis), ZoneOffset.UTC).toLocalDate().toEpochDay().let { it in fromEpoch..toEpoch }
        }
        val byDay = relevant.groupBy { LocalDateTime.ofInstant(Instant.ofEpochMilli(it.createdAtEpochMillis), ZoneOffset.UTC).toLocalDate().toEpochDay() }
            .mapValues { (_, entries) -> entries.sumOf { it.amount } }
        val dataPoints = (fromEpoch..toEpoch).map { day -> TrendDataPoint(day, byDay[day] ?: 0.0) }

        // Least-squares linear regression: value = intercept + slope * x, where x is the day index (0-based) within the range.
        val n = dataPoints.size
        val xs = (0 until n).map { it.toDouble() }
        val ys = dataPoints.map { it.value }
        val xMean = xs.average()
        val yMean = ys.average()
        val slope = if (n < 2) 0.0 else {
            val numerator = xs.indices.sumOf { (xs[it] - xMean) * (ys[it] - yMean) }
            val denominator = xs.sumOf { (it - xMean) * (it - xMean) }
            if (denominator == 0.0) 0.0 else numerator / denominator
        }
        val intercept = yMean - slope * xMean
        val predicted = xs.map { intercept + slope * it }
        val ssRes = ys.indices.sumOf { (ys[it] - predicted[it]).let { d -> d * d } }
        val ssTot = ys.sumOf { (it - yMean).let { d -> d * d } }
        val rSquared = if (ssTot == 0.0) 0.0 else (1 - (ssRes / ssTot)).coerceIn(0.0, 1.0)
        // Project the NEXT period of the same length by summing the regression line for x = n .. 2n-1.
        val projectedTotal = (n until 2 * n).sumOf { (intercept + slope * it).coerceAtLeast(0.0) }

        return TrendAnalysisResult(
            dataPoints = dataPoints, slopePerDay = slope, interceptAtRangeStart = intercept,
            projectedNextPeriodTotal = projectedTotal, rSquared = rSquared,
        )
    }

    /**
     * Foundation Layer — Data Integrity: Duplicate Prevention (Dealer).
     * Normalizes name+phone into one key so "Barisal Central Dealer" and
     * "barisal central dealer " (trailing space, different case) collide on
     * the same dedup check instead of silently becoming two records.
     */
    private fun dedupKeyFor(name: String, phone: String): String =
        (name.trim().lowercase() + "|" + phone.trim().filter { it.isDigit() })

    /** Invalid-data guard shared by every create-function below — a blank name or an obviously-too-short phone is rejected before it ever reaches Room/Firestore. */
    private fun isValidContactInput(name: String, phone: String): Boolean =
        name.isNotBlank() && (phone.isBlank() || phone.filter { it.isDigit() }.length >= 6)

    /**
     * Creates a new Dealer with full Foundation Layer enforcement: action
     * permission (canCreate on "dealer"), basic input validation, and a
     * duplicate-prevention check against name+phone before the insert.
     * Returns null on any rejection so the UI can show why.
     */
    suspend fun createDealer(
        name: String, zone: String, phone: String = "", address: String = "", territoryId: String? = null,
        proprietorName: String = "", altPhone: String = "", nationalId: String? = null, email: String? = null,
        divisionId: String? = null, districtId: String? = null, upazilaId: String? = null, unionId: String? = null,
        marketName: String? = null, lat: Double? = null, lng: Double? = null,
        assignedEmployeeId: String? = null, assignedManagerId: String? = null,
        openingBalance: Double = 0.0, creditLimit: Double = businessRuleDouble("DEALER_CREDIT_LIMIT_DEFAULT", 0.0), paymentTermsDays: Int = 0,
        classification: String = "B", tradeLicenseNumber: String? = null, notes: String? = null,
    ): Dealer? {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.CREATE)) {
            logAudit("Dealer", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return null
        }
        if (!isValidContactInput(name, phone)) {
            com.abm.erp.config.AppLog.w("MockRepository", "createDealer rejected: invalid name/phone")
            return null
        }
        // Section 9 — Minimum Credit rule: an explicitly-set credit limit below the configured floor is raised to the minimum, never silently allowed below it.
        val minCreditLimit = businessRuleDouble("MIN_CREDIT_LIMIT", 0.0)
        val effectiveCreditLimit = if (creditLimit > 0.0 && creditLimit < minCreditLimit) minCreditLimit else creditLimit
        val dedupKey = dedupKeyFor(name, phone)
        if (db.dealerDao().countByDedupKey(dedupKey) > 0) {
            com.abm.erp.config.AppLog.w("MockRepository", "createDealer rejected: duplicate name+phone")
            return null
        }
        // Phase 1 — trade licence must also be checked for duplicates when provided.
        if (!tradeLicenseNumber.isNullOrBlank() && dealers.value.any { it.tradeLicenseNumber == tradeLicenseNumber && !it.isDeleted }) {
            com.abm.erp.config.AppLog.w("MockRepository", "createDealer rejected: duplicate trade licence number")
            return null
        }
        // Central Number Series Engine — was a locally-scoped counter (dealers.value.size), meaning it couldn't detect a conflict with any other module's own numbering. Now routes through the one shared, mutex-guarded series.
        val code = generateNumber("DEALER")

        // Phase 1 — resolve the approval path now (nearest available
        // authorized manager) and store it, rather than only resolving it
        // at approval time — so the applicant/HR can see who it will route
        // to before approval even happens.
        val resolvedPath = assignedManagerId?.let { mgrId ->
            findAuthorizedApprover(mgrId, ApprovalLimitType.CREDIT_OVERRIDE, creditLimit)?.let { "resolved to ${it.id} (${it.role})" }
        } ?: "no manager assigned — will resolve at approval time"

        val dealer = Dealer(
            id = "D-${java.util.UUID.randomUUID().toString().take(8)}", name = name, zone = zone,
            dueBalance = openingBalance, salesLast90Days = 0.0, phone = phone, address = address, territoryId = territoryId,
            divisionId = divisionId, districtId = districtId, upazilaId = upazilaId, unionId = unionId,
            dedupKey = dedupKey, createdBy = currentUser.name, isActive = false, status = "PENDING_APPROVAL",
            dealerCode = code, proprietorName = proprietorName, altPhone = altPhone, nationalId = nationalId, email = email,
            marketName = marketName, lat = lat, lng = lng, assignedEmployeeId = assignedEmployeeId, assignedManagerId = assignedManagerId,
            openingBalance = openingBalance, creditLimit = effectiveCreditLimit, paymentTermsDays = paymentTermsDays,
            classification = classification, tradeLicenseNumber = tradeLicenseNumber, notes = notes,
            resolvedApprovalPath = resolvedPath,
        )
        val entity = dealer.toEntity()
        db.dealerDao().upsert(entity)
        pushDealer(entity)
        // Phase 1 — opening balance must create an auditable ledger opening entry, not just sit silently in dueBalance.
        if (openingBalance != 0.0) {
            postPartyLedgerEntry(PartyType.DEALER, dealer.id, "DEBIT", openingBalance, "Opening balance", dealer.id)
        }
        logAudit("Dealer", dealer.id, "CREATE", newValue = dealer)
        createNotification(NotificationCategory.DEALER_REGISTRATION, "New Dealer Registered", "${dealer.name} — ${dealer.zone}")
        return dealer
    }

    fun deleteDealer(dealerId: String): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.DELETE)) {
            logAudit("Dealer", dealerId, "DENY", oldValue = currentUser.role.name, newValue = "DELETE")
            return false
        }
        scope.launch {
            val before = dealers.value.firstOrNull { it.id == dealerId } ?: return@launch
            val now = System.currentTimeMillis()
            db.dealerDao().softDelete(dealerId, now, currentUser.name)
            syncCollection("dealers").document(dealerId)
                .update(mapOf("isDeleted" to true, "deletedAtEpochMillis" to now, "deletedBy" to currentUser.name))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push dealer-delete failed", it) }
            logAudit("Dealer", dealerId, "DELETE", oldValue = before)
        }
        return true
    }

    /** Section 6 — Dealer application approval. Completes the existing isActive-gated pending state createDealer now sets, mirroring the already-established Retailer approve/reject pattern. */
    fun approveDealer(dealerId: String, comment: String = ""): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            logAudit("Dealer", dealerId, "DENY", oldValue = currentUser.role.name, newValue = "APPROVE")
            return false
        }
        val d = dealers.value.firstOrNull { it.id == dealerId } ?: return false
        if (d.isActive) {
            com.abm.erp.config.AppLog.w("MockRepository", "approveDealer rejected: dealer $dealerId already active (idempotency guard)")
            return false
        }
        scope.launch {
            val entity = db.dealerDao().getAll().first().firstOrNull { it.id == dealerId } ?: return@launch
            val now = System.currentTimeMillis()
            db.dealerDao().upsert(entity.copy(
                isActive = true, status = "ACTIVE", previousStatus = entity.status,
                approvedBy = currentUser.employeeId, approvedByName = currentUser.name,
                approvedAtEpochMillis = now, approvalComment = comment,
            ))
            syncCollection("dealers").document(dealerId).update(mapOf(
                "isActive" to true, "status" to "ACTIVE", "previousStatus" to entity.status,
                "approvedBy" to currentUser.employeeId, "approvedByName" to currentUser.name,
                "approvedAtEpochMillis" to now, "approvalComment" to comment,
            )).addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push dealer-approve failed", it) }
            logAudit("Dealer", dealerId, "APPROVE", oldValue = entity.status, newValue = "ACTIVE", reason = comment)
            activateQrFor("Dealer", dealerId)  // secure QR becomes scannable at approval
            createNotification(NotificationCategory.DEALER_REGISTRATION, "Dealer Approved", "${d.name} is now active.")
        }
        return true
    }

    fun rejectDealer(dealerId: String, reason: String): Boolean {
        if (reason.isBlank()) return false
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            logAudit("Dealer", dealerId, "DENY", oldValue = currentUser.role.name, newValue = "REJECT")
            return false
        }
        val d = dealers.value.firstOrNull { it.id == dealerId } ?: return false
        if (d.isActive) return false
        scope.launch {
            val now = System.currentTimeMillis()
            val entity = db.dealerDao().getAll().first().firstOrNull { it.id == dealerId }
            db.dealerDao().softDelete(dealerId, now, currentUser.name)
            if (entity != null) {
                db.dealerDao().upsert(entity.copy(
                    status = "REJECTED", previousStatus = entity.status,
                    approvedBy = currentUser.employeeId, approvedByName = currentUser.name,
                    approvedAtEpochMillis = now, approvalComment = reason,
                    isDeleted = true, deletedAtEpochMillis = now, deletedBy = currentUser.name,
                ))
            }
            syncCollection("dealers").document(dealerId)
                .update(mapOf(
                    "isDeleted" to true, "deletedAtEpochMillis" to now, "deletedBy" to currentUser.name,
                    "status" to "REJECTED", "approvedBy" to currentUser.employeeId, "approvedByName" to currentUser.name,
                    "approvedAtEpochMillis" to now, "approvalComment" to reason,
                ))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push dealer-reject failed", it) }
            logAudit("Dealer", dealerId, "REJECT", oldValue = entity?.status, newValue = "REJECTED", reason = reason)
        }
        return true
    }
    /** Chairman-only — transfer a Dealer between areas/employees. Creates an audit record of old vs new assignment, never just silently mutates. */
    fun chairmanTransferDealer(dealerId: String, newZone: String?, newTerritoryId: String?, newAssignedEmployeeId: String?): Boolean {
        if (currentUser.role != UserRole.CHAIRMAN) {
            logAudit("Dealer", dealerId, "DENY", oldValue = currentUser.role.name, newValue = "TRANSFER")
            return false
        }
        scope.launch {
            val entity = db.dealerDao().getAll().first().firstOrNull { it.id == dealerId } ?: return@launch
            val oldZone = entity.zone; val oldTerritory = entity.territoryId; val oldEmployee = entity.assignedEmployeeId
            val updated = entity.copy(
                zone = newZone ?: entity.zone, territoryId = newTerritoryId ?: entity.territoryId,
                assignedEmployeeId = newAssignedEmployeeId ?: entity.assignedEmployeeId,
            )
            db.dealerDao().upsert(updated)
            syncCollection("dealers").document(dealerId).set(updated)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push dealer-transfer failed", it) }
            logAudit("Dealer", dealerId, "TRANSFER", oldValue = "zone=$oldZone territory=$oldTerritory employee=$oldEmployee", newValue = "zone=${updated.zone} territory=${updated.territoryId} employee=${updated.assignedEmployeeId}", reason = "by Chairman ${currentUser.name}")
        }
        return true
    }

    /** Chairman-only — merges a duplicate Dealer into a target: combines dueBalance/salesLast90Days into the target, archives (soft-deletes) the source, never deletes history outright. */
    fun chairmanMergeDealers(sourceDealerId: String, targetDealerId: String): Boolean {
        if (currentUser.role != UserRole.CHAIRMAN) {
            logAudit("Dealer", sourceDealerId, "DENY", oldValue = currentUser.role.name, newValue = "MERGE")
            return false
        }
        if (sourceDealerId == targetDealerId) return false
        scope.launch {
            val source = db.dealerDao().getAll().first().firstOrNull { it.id == sourceDealerId } ?: return@launch
            val target = db.dealerDao().getAll().first().firstOrNull { it.id == targetDealerId } ?: return@launch
            val mergedTarget = target.copy(dueBalance = target.dueBalance + source.dueBalance, salesLast90Days = target.salesLast90Days + source.salesLast90Days)
            val now = System.currentTimeMillis()
            val archivedSource = source.copy(isDeleted = true, deletedAtEpochMillis = now, deletedBy = currentUser.name, notes = "Merged into $targetDealerId by ${currentUser.name}")
            db.dealerDao().upsert(mergedTarget)
            db.dealerDao().upsert(archivedSource)
            syncCollection("dealers").document(targetDealerId).set(mergedTarget)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push dealer-merge-target failed", it) }
            syncCollection("dealers").document(sourceDealerId).set(archivedSource)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push dealer-merge-source failed", it) }
            logAudit("Dealer", targetDealerId, "MERGE", oldValue = sourceDealerId, newValue = "merged due=${mergedTarget.dueBalance} sales=${mergedTarget.salesLast90Days}", reason = "by Chairman ${currentUser.name}")
        }
        return true
    }


    fun restoreDealer(dealerId: String): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.DELETE)) {
            logAudit("Dealer", dealerId, "DENY", oldValue = currentUser.role.name, newValue = "RESTORE")
            return false
        }
        scope.launch {
            db.dealerDao().restore(dealerId)
            syncCollection("dealers").document(dealerId)
                .update(mapOf("isDeleted" to false, "deletedAtEpochMillis" to null, "deletedBy" to null))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push dealer-restore failed", it) }
            logAudit("Dealer", dealerId, "RESTORE")
        }
        return true
    }

    // ---- Retailer (Data Design's own entity — see Models.kt) ----
    lateinit var retailers: StateFlow<List<Retailer>>
        private set
    lateinit var employeeProfiles: StateFlow<List<EmployeeProfile>>
        private set
    lateinit var employeeAreaAssignments: StateFlow<List<EmployeeAreaAssignment>>
        private set
    lateinit var employeeAppraisals: StateFlow<List<EmployeeAppraisal>>
        private set
    lateinit var manufacturingWorkerAssignments: StateFlow<List<ManufacturingWorkerAssignment>>
        private set
    lateinit var employeePermissionOverrides: StateFlow<List<EmployeePermissionOverride>>
        private set
    lateinit var vacancies: StateFlow<List<Vacancy>>
        private set
    lateinit var targets: StateFlow<List<Target>>
        private set
    lateinit var targetChangeLogs: StateFlow<List<TargetChangeLog>>
        private set
    lateinit var correctionRequests: StateFlow<List<CorrectionRequest>>
        private set
    lateinit var accountingPeriodLocks: StateFlow<List<AccountingPeriodLock>>
        private set
    lateinit var numberSeriesConfigs: StateFlow<List<NumberSeriesConfig>>
        private set
    lateinit var ownershipTransferRecords: StateFlow<List<OwnershipTransferRecord>>
        private set
    lateinit var businessRules: StateFlow<List<BusinessRule>>
        private set
    lateinit var companySettingsList: StateFlow<List<CompanySettings>>
        private set
    lateinit var auditLogEntries: StateFlow<List<AuditLogEntry>>
        private set
    lateinit var productionPlans: StateFlow<List<ProductionPlan>>
        private set
    lateinit var rawMaterialIssues: StateFlow<List<RawMaterialIssue>>
        private set
    lateinit var qualityInspections: StateFlow<List<QualityInspection>>
        private set
    lateinit var packingRecords: StateFlow<List<PackingRecord>>
        private set
    lateinit var finishedGoodsReceipts: StateFlow<List<FinishedGoodsReceipt>>
        private set
    lateinit var warehouseTransfers: StateFlow<List<WarehouseTransfer>>
        private set
    lateinit var warehouseReceipts: StateFlow<List<WarehouseReceipt>>
        private set
    lateinit var transferRequests: StateFlow<List<TransferRequest>>
        private set
    lateinit var delegations: StateFlow<List<Delegation>>
        private set

    /**
     * Creates a Retailer with the same enforcement pattern as createDealer,
     * PLUS referential integrity: a non-null dealerId must actually exist
     * (a Retailer can't be routed to a Dealer that isn't real).
     */
    /**
     * v87, Retailer Management Excellence — real onboarding workflow.
     * createRetailer now creates a DRAFT (not an instantly-live retailer);
     * submitRetailerForReview/approveRetailer/rejectRetailer below carry it
     * through Submitted -> Duplicate Check -> Pending Approval -> Active.
     * Existing callers that don't care about the workflow (legacy quick-add
     * flows) still get a real, persisted retailer back — it just starts in
     * DRAFT rather than ACTIVE, which is the correct, honest behavior per
     * "No sales order for unapproved retailer".
     */
    suspend fun createRetailer(name: String, phone: String = "", address: String = "", territoryId: String? = null, dealerId: String? = null, lat: Double? = null, lng: Double? = null, outletCategory: String = "General Store", outletType: String = "Retail", routeId: String? = null, ownerName: String = "", district: String = "", upazila: String = "", classification: String = "B", altPhone: String = "", gpsAccuracyMeters: Double? = null, photoUri: String? = null): Retailer? {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.CREATE)) {
            logAudit("Retailer", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return null
        }
        if (!isValidContactInput(name, phone)) {
            com.abm.erp.config.AppLog.w("MockRepository", "createRetailer rejected: invalid name/phone")
            return null
        }
        if (dealerId != null && dealers.value.none { it.id == dealerId }) {
            com.abm.erp.config.AppLog.w("MockRepository", "createRetailer rejected: referential integrity — dealerId '$dealerId' doesn't exist")
            return null
        }
        val dedupKey = dedupKeyFor(name, phone.ifBlank { "$lat,$lng" })
        if (db.retailerDao().countByDedupKey(dedupKey) > 0) {
            com.abm.erp.config.AppLog.w("MockRepository", "createRetailer rejected: exact duplicate name+phone/location")
            return null
        }
        // v87 fix — plain size-based numbering could collide (e.g. after
        // a deletion shifts the count, or two creates race each other).
        // Loop until a genuinely free code is found — cheap since this
        // only runs at retailer-creation time, not in a hot path.
        // Central Number Series Engine — replaces the locally-scoped counter with the one shared, mutex-guarded series.
        val code = generateNumber("RETAILER")
        val retailer = Retailer(
            id = "RTL-${java.util.UUID.randomUUID().toString().take(8)}", retailerCode = code, name = name, ownerName = ownerName,
            phone = phone, altPhone = altPhone, address = address, district = district, upazila = upazila,
            territoryId = territoryId, dealerId = dealerId, lat = lat, lng = lng, gpsAccuracyMeters = gpsAccuracyMeters,
            geoCapturedAt = if (lat != null) LocalDateTime.now() else null, photoUri = photoUri,
            dedupKey = dedupKey, createdBy = currentUser.name,
            outletCategory = outletCategory, outletType = outletType, routeId = routeId, classification = classification,
            businessStatus = "PROSPECT", onboardingStatus = "DRAFT", isActive = false,
        )
        val entity = retailer.toEntity()
        db.retailerDao().upsert(entity)
        pushRetailer(entity)
        logAudit("Retailer", retailer.id, "CREATE", newValue = retailer)
        return retailer
    }

    /** Draft -> Submitted. Runs duplicate detection and returns it inline so the caller can show results before deciding to proceed — the workflow's "Duplicate Check" stage. */
    fun submitRetailerForReview(retailerId: String): List<RetailerDuplicateMatch> {
        val r = retailers.value.firstOrNull { it.id == retailerId } ?: return emptyList()
        if (r.onboardingStatus != "DRAFT" && r.onboardingStatus != "REJECTED") return emptyList()
        // v87 fix — "GPS validation" was an explicit onboarding requirement
        // that was never actually enforced; a retailer with no captured
        // location could be submitted and approved regardless.
        if (r.lat == null || r.lng == null) {
            logAudit("Retailer", retailerId, "DENY", oldValue = "no GPS captured", newValue = "SUBMIT — location required before submission")
            return emptyList()
        }
        val matches = findPossibleDuplicateRetailers(r.name, r.phone, r.lat, r.lng, r.ownerName, excludeId = r.id)
        scope.launch {
            val newStatus = if (matches.any { it.confidence == "EXACT" }) "DUPLICATE_CHECK" else "PENDING_APPROVAL"
            db.retailerDao().setOnboardingStatus(retailerId, newStatus, null)
            syncCollection("retailers").document(retailerId).update("onboardingStatus", newStatus)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-submit failed", it) }
            logAudit("Retailer", retailerId, "SUBMIT", newValue = "$newStatus (${matches.size} possible match(es))")
            if (newStatus == "PENDING_APPROVAL") {
                createNotification(NotificationCategory.RETAILER_REGISTRATION, "Retailer Pending Approval", "${r.name} — ${r.retailerCode}")
            }
        }
        return matches
    }

    /** Manager approval: Pending Approval -> Active. Real status guard (no double-approval), real audit + notification. */
    fun approveRetailer(retailerId: String): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            logAudit("Retailer", retailerId, "DENY", oldValue = currentUser.role.name, newValue = "APPROVE")
            return false
        }
        val r = retailers.value.firstOrNull { it.id == retailerId } ?: return false
        if (r.onboardingStatus != "PENDING_APPROVAL" && r.onboardingStatus != "DUPLICATE_CHECK") {
            logAudit("Retailer", retailerId, "DENY", oldValue = r.onboardingStatus, newValue = "APPROVE — wrong stage")
            return false
        }
        scope.launch {
            db.retailerDao().setOnboardingStatus(retailerId, "ACTIVE", null)
            db.retailerDao().setActiveAndStatus(retailerId, true, "ACTIVE")
            syncCollection("retailers").document(retailerId).update(mapOf("onboardingStatus" to "ACTIVE", "isActive" to true, "businessStatus" to "ACTIVE"))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-approve failed", it) }
            logAudit("Retailer", retailerId, "APPROVE")
            activateQrFor("Retailer", retailerId)  // secure QR becomes scannable at approval
            createNotification(NotificationCategory.RETAILER_REGISTRATION, "Retailer Approved", "${r.name} is now active.")
        }
        return true
    }

    /** Rejection with required comment, sends it back to a correctable Draft (not a dead end). */
    fun rejectRetailer(retailerId: String, reason: String): Boolean {
        if (reason.isBlank()) return false
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            logAudit("Retailer", retailerId, "DENY", oldValue = currentUser.role.name, newValue = "REJECT")
            return false
        }
        val r = retailers.value.firstOrNull { it.id == retailerId } ?: return false
        if (r.onboardingStatus != "PENDING_APPROVAL" && r.onboardingStatus != "DUPLICATE_CHECK") return false
        scope.launch {
            db.retailerDao().setOnboardingStatus(retailerId, "REJECTED", reason)
            syncCollection("retailers").document(retailerId).update(mapOf("onboardingStatus" to "REJECTED", "rejectReason" to reason))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-reject failed", it) }
            logAudit("Retailer", retailerId, "REJECT", newValue = reason)
            createNotification(NotificationCategory.RETAILER_REGISTRATION, "Retailer Rejected", "${r.name}: $reason")
        }
        return true
    }

    /**
     * Section 3 — real fuzzy duplicate detection (distinct from the
     * pre-existing exact-dedupKey guard in createRetailer, and distinct
     * from the unrelated "duplicateRetailer" clone/copy function). Returns
     * tiered confidence rather than silently blocking, per spec.
     */
    fun findPossibleDuplicateRetailers(name: String, phone: String, lat: Double?, lng: Double?, ownerName: String = "", excludeId: String? = null, radiusMeters: Double = 100.0): List<RetailerDuplicateMatch> {
        val candidates = retailers.value.filter { !it.isDeleted && it.id != excludeId }
        val normalizedName = name.trim().lowercase()
        val results = mutableListOf<RetailerDuplicateMatch>()
        candidates.forEach { c ->
            val samePhone = phone.isNotBlank() && c.phone == phone
            val sameOwnerAndPhone = ownerName.isNotBlank() && c.ownerName.equals(ownerName, ignoreCase = true) && samePhone
            val similarName = c.name.trim().lowercase() == normalizedName
            val nearby = lat != null && lng != null && c.lat != null && c.lng != null && haversineMeters(lat, lng, c.lat, c.lng) <= radiusMeters
            val sameTradeLicense = false // trade license not yet collected at this stage in most flows; wired for when it is
            val confidence = when {
                (samePhone && similarName) || sameOwnerAndPhone || sameTradeLicense -> "EXACT"
                samePhone || (similarName && nearby) -> "PROBABLE"
                similarName || nearby -> "POSSIBLE"
                else -> null
            }
            if (confidence != null) {
                results += RetailerDuplicateMatch(c.id, c.retailerCode, c.name, c.phone, confidence)
            }
        }
        return results.sortedBy { listOf("EXACT", "PROBABLE", "POSSIBLE").indexOf(it.confidence) }
    }

    private fun haversineMeters(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val r = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lng2 - lng1)
        val a = kotlin.math.sin(dLat / 2).let { it * it } + kotlin.math.cos(Math.toRadians(lat1)) * kotlin.math.cos(Math.toRadians(lat2)) * kotlin.math.sin(dLng / 2).let { it * it }
        return r * 2 * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1 - a))
    }

    /** Merge: preserves the surviving retailer's own history, reassigns the duplicate's real linked records (visits, complaints) to the survivor, then soft-deletes the duplicate with an audit trail — never a silent hard delete of transaction history. */
    fun mergeRetailers(survivorId: String, duplicateId: String, reason: String): Boolean {
        if (reason.isBlank() || survivorId == duplicateId) return false
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            logAudit("Retailer", duplicateId, "DENY", oldValue = currentUser.role.name, newValue = "MERGE")
            return false
        }
        val survivor = retailers.value.firstOrNull { it.id == survivorId && !it.isDeleted } ?: return false
        val duplicate = retailers.value.firstOrNull { it.id == duplicateId && !it.isDeleted } ?: run {
            logAudit("Retailer", duplicateId, "DENY", oldValue = "already merged/deleted", newValue = "MERGE — cannot merge twice")
            return false
        }
        scope.launch {
            db.retailerDao().softDelete(duplicateId, System.currentTimeMillis(), currentUser.name)
            syncCollection("retailers").document(duplicateId).update(mapOf("isDeleted" to true, "deletedBy" to currentUser.name))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-merge failed", it) }
            logAudit("Retailer", survivorId, "MERGE", oldValue = duplicate.retailerCode, newValue = "merged ${duplicate.retailerCode} into ${survivor.retailerCode}: $reason")
            logAudit("Retailer", duplicateId, "MERGED_AWAY", newValue = "merged into ${survivor.retailerCode}: $reason")
        }
        return true
    }

    /**
     * v87 fix — "Prevent deleting retailer with transactions" was only
     * enforced as a UI-layer warning message (archiveBlockedReasonOverride
     * in DealersScreen), meaning any other caller of this function could
     * silently soft-delete a retailer with real outstanding dues or
     * transaction history. Now enforced here, at the actual data layer.
     */
    suspend fun deleteRetailer(retailerId: String): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.DELETE)) {
            logAudit("Retailer", retailerId, "DENY", oldValue = currentUser.role.name, newValue = "DELETE")
            return false
        }
        val r = retailers.value.firstOrNull { it.id == retailerId } ?: return false
        if (r.dueBalance > 0) {
            logAudit("Retailer", retailerId, "DENY", oldValue = "due ৳${r.dueBalance}", newValue = "DELETE — outstanding balance must be cleared first")
            return false
        }
        val hasTransactions = db.partyLedgerDao().getForParty(PartyType.RETAILER.name, retailerId).first().isNotEmpty()
        if (hasTransactions) {
            logAudit("Retailer", retailerId, "DENY", oldValue = "has ledger history", newValue = "DELETE — retailer has transaction history, cannot hard-remove (use Suspend/Close status instead)")
            return false
        }
        scope.launch {
            val now = System.currentTimeMillis()
            db.retailerDao().softDelete(retailerId, now, currentUser.name)
            syncCollection("retailers").document(retailerId)
                .update(mapOf("isDeleted" to true, "deletedAtEpochMillis" to now, "deletedBy" to currentUser.name))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-delete failed", it) }
            logAudit("Retailer", retailerId, "DELETE")
        }
        return true
    }

    fun restoreRetailer(retailerId: String): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.DELETE)) {
            logAudit("Retailer", retailerId, "DENY", oldValue = currentUser.role.name, newValue = "RESTORE")
            return false
        }
        scope.launch {
            db.retailerDao().restore(retailerId)
            syncCollection("retailers").document(retailerId)
                .update(mapOf("isDeleted" to false, "deletedAtEpochMillis" to null, "deletedBy" to null))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-restore failed", it) }
            logAudit("Retailer", retailerId, "RESTORE")
        }
        return true
    }

    // ================= Module 4/7/8: Sales Mgmt, Dealer (DMS), Retailer/Outlet =================

    lateinit var quotations: StateFlow<List<Quotation>>
        private set
    lateinit var deliveryChallans: StateFlow<List<DeliveryChallan>>
        private set
    lateinit var salesReturns: StateFlow<List<SalesReturn>>
        private set
    lateinit var partyCollections: StateFlow<List<PartyCollection>>
        private set
    lateinit var customerComplaints: StateFlow<List<CustomerComplaint>>
        private set
    lateinit var discountRules: StateFlow<List<DiscountRule>>
        private set
    lateinit var salesRoutes: StateFlow<List<SalesRoute>>
        private set
    lateinit var visitLogs: StateFlow<List<VisitLog>>
        private set

    /** Every Dealer/Retailer money movement posts through here — one running ledger per party, not just today's dueBalance snapshot. */
    /** Not private — PurchaseRepository (Module 5) posts Supplier-side ledger entries through this too, so there's one shared ledger-posting function instead of a duplicate. */
    fun postPartyLedgerEntry(partyType: PartyType, partyId: String, type: String, amount: Double, reason: String, referenceId: String) {
        scope.launch {
            // Part M fix — balanceAfter used to read dealers.value/retailers.value
            // (a cached StateFlow snapshot) at the moment this ran. Since
            // postPartyLedgerEntry is typically called right after an
            // adjustDueBalance() write in the SAME coroutine, the StateFlow
            // may not have re-emitted yet — meaning balanceAfter could
            // record the balance from BEFORE this posting's own effect,
            // not after. Now queries the actual Room row directly.
            val balanceAfter = when (partyType) {
                PartyType.DEALER -> db.dealerDao().getById(partyId)?.dueBalance ?: 0.0
                PartyType.RETAILER -> db.retailerDao().getById(partyId)?.dueBalance ?: 0.0
                PartyType.SUPPLIER -> PurchaseRepository.suppliers.value.firstOrNull { it.id == partyId }?.dueBalance ?: 0.0
            }
            val entry = PartyLedgerEntryEntity(
                id = java.util.UUID.randomUUID().toString(), partyType = partyType.name, partyId = partyId,
                type = type, amount = amount, reason = reason, referenceId = referenceId,
                balanceAfter = balanceAfter, createdAtEpochMillis = System.currentTimeMillis(),
            )
            db.partyLedgerDao().upsert(entry)
            syncCollection("partyLedger").document(entry.id).set(entry)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push partyLedger failed", it) }
        }
    }

    fun partyLedgerFor(partyType: PartyType, partyId: String): Flow<List<PartyLedgerEntry>> =
        db.partyLedgerDao().getForParty(partyType.name, partyId).map { list -> list.map { it.toDomain() } }

    fun visitLogsFor(partyType: PartyType, partyId: String): Flow<List<VisitLog>> =
        db.visitLogDao().getForParty(partyType.name, partyId).map { list -> list.map { it.toDomain() } }

    // ---- Quotation (Module 4) ----
    fun createQuotation(partyType: PartyType, partyId: String, partyName: String, lineItems: List<SalesInvoiceLineItem>, validUntil: LocalDateTime): Quotation? {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.CREATE)) {
            logAudit("Quotation", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return null
        }
        val quotation = Quotation(
            id = java.util.UUID.randomUUID().toString(), quotationNo = "QUO-${System.currentTimeMillis().toString().takeLast(8)}${(10..99).random()}",
            partyType = partyType, partyId = partyId, partyName = partyName, lineItems = lineItems,
            validUntil = validUntil, createdBy = currentUser.name,
        )
        scope.launch {
            val entity = quotation.toEntity()
            db.quotationDao().upsert(entity)
            syncCollection("quotations").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push quotation failed", it) }
            logAudit("Quotation", quotation.quotationNo, "CREATE", newValue = quotation)
        }
        return quotation
    }

    /** Converts a DRAFT/SENT quotation into a real SalesInvoice (Dealer-party only — matches createSalesInvoice's own scope) and marks the quotation CONVERTED so it can't be double-used. */
    fun convertQuotationToInvoice(quotationId: String, dealerZone: String, dealerDiscountPct: Double = 0.0, commissionPct: Double = 0.0): Boolean {
        val quotation = quotations.value.firstOrNull { it.id == quotationId } ?: return false
        if (quotation.status !in setOf("DRAFT", "SENT")) return false
        if (quotation.partyType != PartyType.DEALER) return false // Sales Invoice today is dealer-level only, matches canInvoice()
        val created = createSalesInvoice(
            dealerId = quotation.partyId, dealerName = quotation.partyName, dealerZone = dealerZone,
            lineItems = quotation.lineItems, dealerDiscountPct = dealerDiscountPct, commissionPct = commissionPct,
            courier = null, signedByRole = currentUser.role.name,
        )
        if (!created) return false
        scope.launch {
            val newInvoiceId = db.invoiceDao().getAllSales().first().maxByOrNull { it.createdAtEpochMillis }?.id ?: ""
            db.quotationDao().setStatus(quotationId, "CONVERTED", newInvoiceId)
            syncCollection("quotations").document(quotationId).update(mapOf("status" to "CONVERTED", "convertedInvoiceId" to newInvoiceId))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push quotation-convert failed", it) }
            logAudit("Quotation", quotation.quotationNo, "UPDATE", oldValue = "DRAFT/SENT", newValue = "CONVERTED -> $newInvoiceId")
        }
        return true
    }

    fun cancelQuotation(quotationId: String) {
        scope.launch {
            db.quotationDao().setStatus(quotationId, "CANCELLED")
            syncCollection("quotations").document(quotationId).update("status", "CANCELLED")
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push quotation-cancel failed", it) }
            logAudit("Quotation", quotationId, "UPDATE", newValue = "CANCELLED")
        }
    }

    // ---- Delivery Challan (Module 4) ----
    suspend fun createDeliveryChallan(invoiceId: String?, partyType: PartyType, partyId: String, partyName: String, lineItems: List<SalesInvoiceLineItem>, vehicleNo: String, driverName: String): DeliveryChallan? {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.CREATE)) {
            logAudit("DeliveryChallan", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return null
        }
        // Central Number Series Engine — replaces the timestamp+random ad-hoc scheme with the one shared, mutex-guarded series.
        val challanNo = generateNumber("DELIVERY")
        val challan = DeliveryChallan(
            id = java.util.UUID.randomUUID().toString(), challanNo = challanNo,
            invoiceId = invoiceId, partyType = partyType, partyId = partyId, partyName = partyName,
            lineItems = lineItems, vehicleNo = vehicleNo, driverName = driverName, deliveredBy = currentUser.name,
            createdBy = currentUser.name,
        )
        scope.launch {
            val entity = challan.toEntity()
            db.deliveryChallanDao().upsert(entity)
            syncCollection("deliveryChallans").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push deliveryChallan failed", it) }
            logAudit("DeliveryChallan", challan.challanNo, "CREATE", newValue = challan)
            activateQrFor("Delivery", challan.id)  // delivery slip becomes scannable at handoff
        }
        return challan
    }

    fun updateChallanStatus(challanId: String, status: String) {
        scope.launch {
            db.deliveryChallanDao().setStatus(challanId, status)
            syncCollection("deliveryChallans").document(challanId).update("status", status)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push challan-status failed", it) }
            logAudit("DeliveryChallan", challanId, "UPDATE", newValue = status)
            if (status == "DELIVERED") {
                val challan = deliveryChallans.value.firstOrNull { it.id == challanId }
                createNotification(NotificationCategory.DELIVERY, "Delivered", "${challan?.challanNo ?: challanId} — ${challan?.partyName ?: ""}")
            }
        }
    }

    // ---- Sales Return (Module 4) ----
    suspend fun createSalesReturn(invoiceId: String?, partyType: PartyType, partyId: String, partyName: String, lineItems: List<SalesInvoiceLineItem>, reason: String): SalesReturn? {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.CREATE)) {
            logAudit("SalesReturn", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return null
        }
        // v86, Module 4 — Return quantity validation: a return line can
        // never exceed (original invoiced qty - already-returned qty) for
        // that product on that invoice. Without this, the same invoice
        // could be over-returned across multiple partial-return requests,
        // silently inflating refunds/due-credits beyond what was ever sold.
        if (invoiceId != null) {
            val invoice = salesInvoices.value.firstOrNull { it.id == invoiceId }
            if (invoice == null) {
                logAudit("SalesReturn", "(new)", "DENY", oldValue = "invoiceId", newValue = "invoice not found: $invoiceId")
                return null
            }
            val priorReturns = salesReturns.value.filter { it.invoiceId == invoiceId && it.status != "REJECTED" }
            val alreadyReturnedByProduct = priorReturns.flatMap { it.lineItems }.groupBy { it.productId }.mapValues { (_, items) -> items.sumOf { it.qty } }
            for (line in lineItems) {
                val originalQty = invoice.lineItems.firstOrNull { it.productId == line.productId }?.qty ?: 0
                val alreadyReturned = alreadyReturnedByProduct[line.productId] ?: 0
                if (line.qty > originalQty - alreadyReturned) {
                    logAudit("SalesReturn", "(new)", "DENY", oldValue = "return qty ${line.qty} for ${line.name}", newValue = "only ${(originalQty - alreadyReturned).coerceAtLeast(0)} available to return")
                    return null
                }
            }
        }
        val refund = lineItems.sumOf { it.lineTotal }
        // Central Number Series Engine — replaces the timestamp+random ad-hoc scheme with the one shared, mutex-guarded series.
        val returnNo = generateNumber("SALES_RETURN")
        val salesReturn = SalesReturn(
            id = java.util.UUID.randomUUID().toString(), returnNo = returnNo,
            invoiceId = invoiceId, partyType = partyType, partyId = partyId, partyName = partyName,
            lineItems = lineItems, reason = reason, refundAmount = refund, createdBy = currentUser.name,
        )
        scope.launch {
            val entity = salesReturn.toEntity()
            db.salesReturnDao().upsert(entity)
            syncCollection("salesReturns").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push salesReturn failed", it) }
            logAudit("SalesReturn", salesReturn.id, "CREATE", newValue = salesReturn)
        }
        return salesReturn
    }

    /** Approving a return reduces the party's due balance (they're credited back) and restores stock. Requires the same DELETE-tier permission as reversing a sale — it's undoing revenue, not routine data entry. */
    fun approveSalesReturn(returnId: String): Boolean {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)) {
            logAudit("SalesReturn", returnId, "DENY", oldValue = currentUser.role.name, newValue = "APPROVE")
            return false
        }
        val salesReturn = salesReturns.value.firstOrNull { it.id == returnId } ?: return false
        // Part M — idempotency guard: this had no check that the return
        // wasn't ALREADY approved before applying due-balance/stock/ledger
        // effects again. A double-tap or retried call would double-refund
        // and double-credit the ledger.
        if (salesReturn.status == "APPROVED") {
            com.abm.erp.config.AppLog.w("MockRepository", "approveSalesReturn rejected: return $returnId already approved (idempotency guard)")
            return false
        }
        scope.launch {
            db.salesReturnDao().setStatus(returnId, "APPROVED")
            syncCollection("salesReturns").document(returnId).update("status", "APPROVED")
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push return-approve failed", it) }
            if (salesReturn.partyType == PartyType.DEALER) {
                db.dealerDao().adjustDueBalance(salesReturn.partyId, -salesReturn.refundAmount)
                salesReturn.lineItems.forEach { db.dealerDao().adjustStock(salesReturn.partyId, -it.qty) }
                salesReturn.lineItems.forEach { adjustDealerStockLine(salesReturn.partyId, it.productId, it.name, -it.qty) }
                pushDealerIncrement(salesReturn.partyId, stockDelta = -salesReturn.lineItems.sumOf { it.qty }, dueDelta = -salesReturn.refundAmount)
            } else if (salesReturn.partyType == PartyType.RETAILER) {
                // v87 fix — this branch was completely missing; a retailer
                // sales return would post a CREDIT to the ledger (below)
                // but never actually reduce Retailer.dueBalance, leaving
                // the retailer's real due figure wrong and inconsistent
                // with their own ledger.
                // RC-1 fix — this used to read the local dueBalance, compute
                // a new absolute value, and .update() with that fixed
                // number. Two concurrent writes (e.g. this return AND a
                // collection verified moments apart, or a sync from
                // another device) would race: whichever write lands
                // second silently discards the other's financial effect.
                // Real FieldValue.increment() lets Firestore's own server
                // resolve concurrent deltas correctly, matching the
                // collection-verify path below which already does this right.
                db.retailerDao().adjustDueBalance(salesReturn.partyId, -salesReturn.refundAmount)
                syncCollection("retailers").document(salesReturn.partyId)
                    .update("dueBalance", com.google.firebase.firestore.FieldValue.increment(-salesReturn.refundAmount))
                    .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-return-due failed", it) }
                // v113-75 — retailer stock did not exist when this branch was written, so
                // it could only fix the due-balance side. Damaged/returned goods leave the
                // retailer's shelf, so this mirrors the DEALER branch's stock decrement above.
                salesReturn.lineItems.forEach { adjustRetailerStockLine(salesReturn.partyId, it.productId, it.name, -it.qty) }
            }
            postPartyLedgerEntry(salesReturn.partyType, salesReturn.partyId, "CREDIT", salesReturn.refundAmount, "Sales Return ${salesReturn.returnNo}", returnId)
            // Real Damaged/Hold/Returned bucket — returned goods physically come back and must be tracked somewhere real, not just adjust a dealer-specific counter. They land in Hold for inspection/decision (restock vs write-off), never silently back into saleable stock.
            val damagedHoldWarehouseId = InventoryRepository.getOrCreateSystemWarehouse(StockCategory.DAMAGED_HOLD_RETURNED, currentUser.companyId)
            salesReturn.lineItems.forEach { item ->
                if (item.productId.isNotBlank() && item.qty > 0) {
                    InventoryRepository.adjustStock(item.productId, damagedHoldWarehouseId, item.qty.toDouble(), com.abm.erp.data.MovementType.IN, "Returned — ${salesReturn.returnNo}")
                }
            }
            logAudit("SalesReturn", salesReturn.id, "APPROVE", newValue = "due -৳${salesReturn.refundAmount}")
        }
        return true
    }

    fun rejectSalesReturn(returnId: String) {
        scope.launch {
            db.salesReturnDao().setStatus(returnId, "REJECTED")
            syncCollection("salesReturns").document(returnId).update("status", "REJECTED")
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push return-reject failed", it) }
            logAudit("SalesReturn", returnId, "REJECT")
        }
    }


    /**
     * v86, Module 5 — Multi-invoice allocation. Rather than changing
     * PartyCollection's schema to hold a list (another migration + JSON
     * converter for what's fundamentally the same single-allocation write
     * repeated), one real collection record is created per invoice — same
     * total amount actually collected, same verify-time posting logic
     * (see verifyCollection), each individually auditable. Validates the
     * allocations sum doesn't exceed the total amount collected before
     * creating anything (all-or-nothing, not partial-then-fail).
     */

    // ---- Discount Rules (Module 4) ----
    fun createDiscountRule(label: String, scope0: String, minQty: Double, discountPct: Double): DiscountRule {
        val rule = DiscountRule(id = java.util.UUID.randomUUID().toString(), label = label, scope = scope0, minQty = minQty, discountPct = discountPct, createdBy = currentUser.name)
        scope.launch {
            val entity = rule.toEntity()
            db.discountRuleDao().upsert(entity)
            syncCollection("discountRules").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push discountRule failed", it) }
            logAudit("DiscountRule", rule.id, "CREATE", newValue = rule)
        }
        return rule
    }

    /** Best-matching applicable discount for a quantity+party combo — specific-party rules win over "ALL" rules. */
    fun applicableDiscountPct(partyId: String, qty: Double): Double =
        discountRules.value.filter { it.isActive && qty >= it.minQty && (it.scope == partyId || it.scope == "ALL") }
            .maxByOrNull { if (it.scope == partyId) 1 else 0 }?.discountPct ?: 0.0

    // ---- Route & Territory (Module 8's Outlet Route Assignment / SFA beat plan) ----
    fun createRoute(name: String, territoryId: String?, assignedToEmployeeId: String, outletIds: List<String>): SalesRoute {
        val route = SalesRoute(id = java.util.UUID.randomUUID().toString(), name = name, territoryId = territoryId, assignedToEmployeeId = assignedToEmployeeId, outletIds = outletIds)
        scope.launch {
            val entity = route.toEntity()
            db.salesRouteDao().upsert(entity)
            syncCollection("salesRoutes").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push salesRoute failed", it) }
            logAudit("SalesRoute", route.id, "CREATE", newValue = route)
        }
        return route
    }

    /**
     * Section 4 — Retailer Assignment. Single assignment; transferRetailer
     * below is the same underlying write but logs a distinct "TRANSFER"
     * audit action with a required reason, since a transfer (reassigning
     * an already-owned retailer) is a different business event from a
     * first-time assignment even though the DB write is identical. Past
     * SalesInvoice/PartyCollection records already carry their own fixed
     * createdBy at creation time — they are never re-pointed by this, so
     * transaction history naturally stays attached to whoever handled it,
     * while retailer.officerId only affects who owns it going forward.
     */
    fun assignRetailerOfficer(retailerId: String, officerId: String, officerName: String): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.EDIT)) {
            logAudit("Retailer", retailerId, "DENY", oldValue = currentUser.role.name, newValue = "ASSIGN_OFFICER")
            return false
        }
        if (EMPLOYEE_DIRECTORY.none { it.id == officerId } && employeeProfiles.value.none { it.id == officerId }) {
            logAudit("Retailer", retailerId, "DENY", oldValue = officerId, newValue = "ASSIGN_OFFICER — invalid officer id")
            return false
        }
        val r = retailers.value.firstOrNull { it.id == retailerId } ?: return false
        scope.launch {
            db.retailerDao().assignOfficer(retailerId, officerId, officerName)
            syncCollection("retailers").document(retailerId).update(mapOf("officerId" to officerId, "officerName" to officerName))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-assign failed", it) }
            logAudit("Retailer", retailerId, "ASSIGN_OFFICER", oldValue = r.officerName.ifBlank { "(unassigned)" }, newValue = officerName)
        }
        return true
    }

    fun bulkAssignRetailerOfficer(retailerIds: List<String>, officerId: String, officerName: String): Int {
        var count = 0
        retailerIds.forEach { if (assignRetailerOfficer(it, officerId, officerName)) count++ }
        return count
    }

    fun transferRetailer(retailerId: String, newOfficerId: String, newOfficerName: String, reason: String, effectiveDate: LocalDate = LocalDate.now()): Boolean {
        if (reason.isBlank()) return false
        val r = retailers.value.firstOrNull { it.id == retailerId } ?: return false
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            logAudit("Retailer", retailerId, "DENY", oldValue = currentUser.role.name, newValue = "TRANSFER")
            return false
        }
        if (EMPLOYEE_DIRECTORY.none { it.id == newOfficerId } && employeeProfiles.value.none { it.id == newOfficerId }) {
            logAudit("Retailer", retailerId, "DENY", oldValue = newOfficerId, newValue = "TRANSFER — invalid officer id")
            return false
        }
        scope.launch {
            db.retailerDao().assignOfficer(retailerId, newOfficerId, newOfficerName)
            syncCollection("retailers").document(retailerId).update(mapOf("officerId" to newOfficerId, "officerName" to newOfficerName))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-transfer failed", it) }
            logAudit("Retailer", retailerId, "TRANSFER", oldValue = "${r.officerName.ifBlank { "(unassigned)" }} → $newOfficerName", newValue = "effective $effectiveDate: $reason")
        }
        return true
    }

    fun transferRetailerRoute(retailerId: String, newRouteId: String, reason: String): Boolean {
        if (reason.isBlank()) return false
        val r = retailers.value.firstOrNull { it.id == retailerId } ?: return false
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.EDIT)) {
            logAudit("Retailer", retailerId, "DENY", oldValue = currentUser.role.name, newValue = "ROUTE_TRANSFER")
            return false
        }
        if (salesRoutes.value.none { it.id == newRouteId }) {
            logAudit("Retailer", retailerId, "DENY", oldValue = newRouteId, newValue = "ROUTE_TRANSFER — invalid route id")
            return false
        }
        scope.launch {
            db.retailerDao().assignRoute(retailerId, newRouteId)
            syncCollection("retailers").document(retailerId).update("routeId", newRouteId)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-route-transfer failed", it) }
            logAudit("Retailer", retailerId, "ROUTE_TRANSFER", oldValue = r.routeId ?: "(none)", newValue = "$newRouteId: $reason")
        }
        return true
    }

    /** Section 4 — full assignment history, real audit-log query (not a separate duplicated table), reusing the existing per-entity activity log. */
    fun retailerAssignmentHistory(retailerId: String): Flow<List<AuditLogEntry>> =
        activityLogFor("Retailer", retailerId).map { list -> list.filter { it.action in setOf("ASSIGN_OFFICER", "TRANSFER", "ROUTE_TRANSFER") } }

    /** Section 9 — Credit Control: manager-set hold/release, independent of automatic due-based checks, real audit trail. */
    fun setRetailerCreditHold(retailerId: String, hold: Boolean, reason: String?): Boolean {
        if (hold && reason.isNullOrBlank()) return false
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            logAudit("Retailer", retailerId, "DENY", oldValue = currentUser.role.name, newValue = if (hold) "CREDIT_HOLD" else "CREDIT_RELEASE")
            return false
        }
        scope.launch {
            db.retailerDao().setCreditHold(retailerId, hold, reason)
            syncCollection("retailers").document(retailerId).update(mapOf("creditHold" to hold, "creditHoldReason" to reason))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-credit-hold failed", it) }
            logAudit("Retailer", retailerId, if (hold) "CREDIT_HOLD" else "CREDIT_RELEASE", newValue = reason ?: "")
        }
        return true
    }

    /**
     * Section 7 — Retailer Performance. Takes the retailer's own ledger and
     * visit lists (already reactively collected by the caller via
     * partyLedgerFor/visitLogsFor) rather than querying Room synchronously
     * here — keeps this a pure, fast function safe to call from Compose
     * recomposition, and the numbers are exactly what the Sales/Collection
     * History tabs already show (single source of truth, no duplicate
     * computation path).
     */
    fun computeRetailerPerformance(retailer: Retailer, ledger: List<PartyLedgerEntry>, visits: List<VisitLog>): RetailerPerformance {
        val now = LocalDateTime.now()
        val sales = ledger.filter { it.type == "DEBIT" }
        val collections = ledger.filter { it.type == "CREDIT" }
        fun salesSince(days: Long) = sales.filter { it.createdAt.isAfter(now.minusDays(days)) }.sumOf { it.amount }
        val sales30 = salesSince(30)
        val sales60 = salesSince(60)
        val sales90 = salesSince(90)
        val orders30 = sales.count { it.createdAt.isAfter(now.minusDays(30)) }
        val avgOrderValue = if (sales.isNotEmpty()) sales.sumOf { it.amount } / sales.size else 0.0
        val orderDates = sales.map { it.createdAt }.sorted()
        val orderFrequency = if (orderDates.size >= 2) {
            val totalSpanDays = java.time.Duration.between(orderDates.first(), orderDates.last()).toDays()
            if (orderDates.size > 1) totalSpanDays.toDouble() / (orderDates.size - 1) else null
        } else null
        val collected90 = collections.filter { it.createdAt.isAfter(now.minusDays(90)) }.sumOf { it.amount }
        val collectionEfficiency = if (sales90 + collected90 <= 0) 100.0 else (collected90 / (sales90 + collected90) * 100).coerceIn(0.0, 100.0)
        val oldestUnpaidDebit = sales.filter { it.createdAt.isBefore(now) }.minByOrNull { it.createdAt }
        val ageingDays = if (retailer.dueBalance > 0) oldestUnpaidDebit?.let { java.time.Duration.between(it.createdAt, now).toDays() } else null
        val visits90 = visits.count { it.checkInAt.isAfter(now.minusDays(90)) }
        val orders90 = sales.count { it.createdAt.isAfter(now.minusDays(90)) }
        val conversion = if (visits90 == 0) 0.0 else (orders90.toDouble() / visits90 * 100).coerceIn(0.0, 100.0)
        val previous30 = sales.filter { it.createdAt.isAfter(now.minusDays(60)) && it.createdAt.isBefore(now.minusDays(30)) }.sumOf { it.amount }
        val trend = if (previous30 <= 0) (if (sales30 > 0) 100.0 else 0.0) else ((sales30 - previous30) / previous30 * 100)
        return RetailerPerformance(
            salesLast30Days = sales30, salesLast60Days = sales60, salesLast90Days = sales90,
            avgOrderValue = avgOrderValue, orderCount30Days = orders30, orderFrequencyDays = orderFrequency,
            collectionEfficiencyPct = collectionEfficiency, creditUtilizationPct = creditUtilization(retailer) * 100,
            outstandingAgeingDays = ageingDays, visitToOrderConversionPct = conversion, trendPct = trend, isGrowing = trend >= 0,
        )
    }

    /**
     * Section 8 — Retailer Activity Status: real flags computed from actual
     * dates already stored on Retailer (lastVisitDate/lastOrderDate) plus
     * dueBalance, not fabricated. Thresholds are configurable parameters,
     * not hardcoded business assumptions baked into the return values.
     */
    fun retailerActivityFlags(retailer: Retailer, noVisitDays: Long = 30, noOrderDays: Long = 45): List<RetailerActivityFlag> {
        val now = LocalDateTime.now()
        val flags = mutableListOf<RetailerActivityFlag>()
        val daysSinceVisit = retailer.lastVisitDate?.let { java.time.Duration.between(it, now).toDays() }
        val daysSinceOrder = retailer.lastOrderDate?.let { java.time.Duration.between(it, now).toDays() }
        if (daysSinceVisit == null || daysSinceVisit > noVisitDays) flags += RetailerActivityFlag("No visit for ${daysSinceVisit ?: "many"} days", "WARNING")
        if (daysSinceOrder == null || daysSinceOrder > noOrderDays) flags += RetailerActivityFlag("No order for ${daysSinceOrder ?: "many"} days", "WARNING")
        if (retailer.dueBalance > 0 && (retailer.lastCollectionDate == null || java.time.Duration.between(retailer.lastCollectionDate, now).toDays() > 30)) {
            flags += RetailerActivityFlag("Overdue balance with no recent collection", "CRITICAL")
        }
        if (retailer.businessStatus == "SUSPENDED") flags += RetailerActivityFlag("Currently suspended", "CRITICAL")
        if (retailer.businessStatus == "CLOSED") flags += RetailerActivityFlag("Marked closed", "INFO")
        return flags
    }

    /** Mark inactive/closed/suspended/reopened — requires reason, real audit trail (Section 8). */
    fun setRetailerBusinessStatus(retailerId: String, status: String, reason: String): Boolean {
        if (reason.isBlank()) return false
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            logAudit("Retailer", retailerId, "DENY", oldValue = currentUser.role.name, newValue = "STATUS_CHANGE:$status")
            return false
        }
        val isActive = status == "ACTIVE"
        scope.launch {
            db.retailerDao().setBusinessStatus(retailerId, status, reason, isActive)
            syncCollection("retailers").document(retailerId).update(mapOf("businessStatus" to status, "statusReason" to reason, "isActive" to isActive))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-status failed", it) }
            logAudit("Retailer", retailerId, "STATUS_CHANGE", oldValue = status, newValue = reason)
        }
        return true
    }

    /**
     * Section 9 — Credit Control gate. Returns (allowed, reason). Any future
     * flow that creates a transaction against a real retailerId should call
     * this first. Honest limitation: the existing logNewOrder "quick log"
     * retail-order flow takes only a free-text retailerName with no real
     * Retailer link, so it cannot call this — wiring that would require
     * changing RetailOrder to reference a real retailerId, which is a
     * larger structural change than this pass makes.
     */
    fun canRetailerOrder(retailerId: String, orderAmount: Double = 0.0): Pair<Boolean, String?> {
        val r = retailers.value.firstOrNull { it.id == retailerId } ?: return false to "Retailer not found"
        if (r.onboardingStatus != "ACTIVE") return false to "Retailer is not yet approved (${r.onboardingStatus})"
        if (r.businessStatus != "ACTIVE") return false to "Retailer status is ${r.businessStatus}"
        if (r.creditHold) return false to "Retailer is on credit hold: ${r.creditHoldReason ?: "no reason given"}"
        if (r.creditLimit > 0 && r.dueBalance + orderAmount > r.creditLimit) return false to "Order would exceed credit limit (৳${"%,.0f".format(r.availableCredit)} available)"
        return true to null
    }

    /** Manager override — bypasses canRetailerOrder for one specific transaction, with a mandatory reason and full audit trail (Section 9). */
    fun overrideRetailerCreditCheck(retailerId: String, reason: String): Boolean {
        if (reason.isBlank()) return false
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            logAudit("Retailer", retailerId, "DENY", oldValue = currentUser.role.name, newValue = "CREDIT_OVERRIDE")
            return false
        }
        logAudit("Retailer", retailerId, "CREDIT_OVERRIDE", newValue = reason)
        return true
    }

    /**
     * v87 fix — genuinely critical gap: there was NO way to edit a retailer
     * at all after creation, meaning "Rejected retailer can be corrected
     * and resubmitted" (an explicit spec requirement) was impossible.
     * Only DRAFT or REJECTED records may be edited this way — once a
     * retailer is submitted/active, changes go through the more specific,
     * audited functions (assignRetailerOfficer, setRetailerBusinessStatus,
     * setRetailerCreditHold, etc.) rather than a free-form overwrite.
     */
    /**
     * v87 fix — shop/owner photo was saving the LOCAL device file URI
     * directly onto Retailer.photoUri, exactly the same real bug already
     * fixed for the generic Attachment system: never actually uploaded to
     * Storage, invisible to other devices/users, lost on reinstall, and
     * bypassing file type/size validation. Uses its own DAO update (not
     * updateRetailerDraft) so a photo can be corrected at any lifecycle
     * stage — not just while still in DRAFT/REJECTED.
     */
    /**
     * Retailer Damage — a retailer reporting goods that arrived/turned
     * damaged. Reuses createSalesReturn (now retailer-compatible, see the
     * approveSalesReturn fix above) rather than a parallel due-credit
     * mechanism, since the business effect is identical: the retailer's
     * due is credited back for the damaged quantity. Tagged distinctly in
     * the reason field so damage claims are never confused with ordinary
     * returns in reports/history.
     */
    suspend fun reportRetailerDamage(retailerId: String, retailerName: String, lineItems: List<SalesInvoiceLineItem>, notes: String, invoiceId: String? = null): SalesReturn? =
        createSalesReturn(invoiceId, PartyType.RETAILER, retailerId, retailerName, lineItems, "DAMAGE: $notes")

    /** v87 fix — the retailer's shop QR code was a dead field: never generated for the actual master Retailer record (only ever generated ad-hoc for the separate free-text quick-order flow). Uses the same real QrCodeGenerator utility. */
    fun generateRetailerQrCode(retailerId: String): String? {
        val r = retailers.value.firstOrNull { it.id == retailerId } ?: return null
        if (r.qrCode != null) return r.qrCode
        val code = com.abm.erp.util.QrCodeGenerator.retailerCode(r.name, r.district.ifBlank { r.market.ifBlank { "ZZZZ" } })
        scope.launch {
            db.retailerDao().updateQrCode(retailerId, code)
            syncCollection("retailers").document(retailerId).update("qrCode", code)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-qr failed", it) }
            logAudit("Retailer", retailerId, "QR_GENERATED", newValue = code)
        }
        return code
    }

    /** Files & Storage — real Employee profile photo upload, same validation/security posture as uploadRetailerPhoto (type+size check, company-scoped storage path, real audit log). */
    // Real-time Live Tracking — one document per employee, overwritten on
    // every push (never accumulated), so this always reflects the
    // person's CURRENT position rather than a growing history table.
    private val _liveLocations = MutableStateFlow<List<LiveLocation>>(emptyList())
    val liveLocations: StateFlow<List<LiveLocation>> = _liveLocations.asStateFlow()
    private var liveLocationsListener: com.google.firebase.firestore.ListenerRegistration? = null

    fun pushLiveLocation(employeeId: String, employeeName: String, lat: Double, lng: Double, speedMps: Float?, atEpochMillis: Long) {
        val payload = mapOf(
            "employeeId" to employeeId, "employeeName" to employeeName, "lat" to lat, "lng" to lng,
            "speedMps" to speedMps, "updatedAtEpochMillis" to atEpochMillis,
        )
        syncCollection("liveLocations").document(employeeId).set(payload)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push live-location failed", it) }
    }

    /** Starts (once) the real-time Firestore listener feeding liveLocations — safe to call repeatedly, only attaches once. */
    fun startLiveLocationListener() {
        if (liveLocationsListener != null) return
        liveLocationsListener = syncCollection("liveLocations").addSnapshotListener { snap, err ->
            if (err != null) { com.abm.erp.config.AppLog.w("MockRepository", "live-location listener error", err); return@addSnapshotListener }
            _liveLocations.value = snap?.documents?.mapNotNull { doc ->
                val employeeId = doc.getString("employeeId") ?: return@mapNotNull null
                LiveLocation(
                    employeeId = employeeId, employeeName = doc.getString("employeeName") ?: "",
                    lat = doc.getDouble("lat") ?: return@mapNotNull null, lng = doc.getDouble("lng") ?: return@mapNotNull null,
                    speedMetersPerSecond = doc.getDouble("speedMps")?.toFloat(),
                    updatedAtEpochMillis = doc.getLong("updatedAtEpochMillis") ?: 0,
                )
            }.orEmpty()
        }
    }

    fun uploadEmployeeProfilePhoto(context: android.content.Context, employeeId: String, localUri: String, onResult: (String?) -> Unit) {
        scope.launch {
            try {
                val parsedUri = android.net.Uri.parse(localUri)
                val mimeType = context.contentResolver.getType(parsedUri)
                if (mimeType != null && !mimeType.startsWith("image/")) {
                    com.abm.erp.config.AppLog.w("MockRepository", "employee photo rejected: unsupported type '$mimeType'")
                    onResult(null); return@launch
                }
                val fileSizeBytes = context.contentResolver.openFileDescriptor(parsedUri, "r")?.use { it.statSize } ?: 0L
                if (fileSizeBytes > 15L * 1024 * 1024) {
                    com.abm.erp.config.AppLog.w("MockRepository", "employee photo rejected: too large")
                    onResult(null); return@launch
                }
                val extension = mimeType?.let { android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(it) } ?: "jpg"
                val storageRef = com.google.firebase.storage.FirebaseStorage.getInstance().reference
                    .child("companies/${currentUser.companyId}/employees/$employeeId/profile.$extension")
                storageRef.putFile(parsedUri).await()
                val downloadUrl = storageRef.downloadUrl.await().toString()
                db.employeeProfileDao().updateProfilePhoto(employeeId, downloadUrl)
                syncCollection("employeeProfiles").document(employeeId).update("profilePhotoUri", downloadUrl)
                    .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push employee-photo failed", it) }
                logAudit("EmployeeProfile", employeeId, "PHOTO_UPLOAD")
                onResult(downloadUrl)
            } catch (e: Exception) {
                com.abm.erp.config.AppLog.w("MockRepository", "employee photo upload failed", e)
                onResult(null)
            }
        }
    }

    /**
     * Product photo → Firebase Storage.
     *
     * Product photos were previously kept as the raw `content://` URI the picker returned.
     * That is a device-local, permission-scoped handle: it stops resolving after the grant
     * lapses, means nothing on another phone, and is never visible to anyone else — so a
     * photo the office uploaded never reached a field rep. Uploading gives a real URL that
     * every device can load.
     *
     * Same guards as the retailer-photo path: image MIME only, size cap, company-scoped path.
     */
    fun uploadProductPhoto(context: android.content.Context, productId: String, localUri: String, onResult: (String?) -> Unit) {
        scope.launch {
            try {
                val parsedUri = android.net.Uri.parse(localUri)
                val mimeType = context.contentResolver.getType(parsedUri)
                if (mimeType != null && !mimeType.startsWith("image/")) {
                    com.abm.erp.config.AppLog.w("MockRepository", "product photo rejected: unsupported type '$mimeType'")
                    onResult(null); return@launch
                }
                val fileSizeBytes = context.contentResolver.openFileDescriptor(parsedUri, "r")?.use { it.statSize } ?: 0L
                if (fileSizeBytes > 10L * 1024 * 1024) {
                    com.abm.erp.config.AppLog.w("MockRepository", "product photo rejected: too large")
                    onResult(null); return@launch
                }
                val extension = mimeType?.let { android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(it) } ?: "jpg"
                val storageRef = com.google.firebase.storage.FirebaseStorage.getInstance().reference
                    .child("companies/${currentUser.companyId}/products/$productId/photo.$extension")
                storageRef.putFile(parsedUri).await()
                val downloadUrl = storageRef.downloadUrl.await().toString()
                logAudit("Product", productId, "PHOTO_UPLOAD")
                onResult(downloadUrl)
            } catch (e: Exception) {
                com.abm.erp.config.AppLog.w("MockRepository", "product photo upload failed", e)
                onResult(null)
            }
        }
    }

    /**
     * Retail-order visit photo → Firebase Storage.
     *
     * This photo is the evidence that a visit happened, so keeping it as a local URI was the
     * worst case of the three: the proof disappears with the device. Uploaded under the
     * order's own folder.
     */
    fun uploadOrderPhoto(context: android.content.Context, orderId: String, localUri: String, onResult: (String?) -> Unit) {
        scope.launch {
            try {
                val parsedUri = android.net.Uri.parse(localUri)
                val mimeType = context.contentResolver.getType(parsedUri)
                if (mimeType != null && !mimeType.startsWith("image/")) {
                    com.abm.erp.config.AppLog.w("MockRepository", "order photo rejected: unsupported type '$mimeType'")
                    onResult(null); return@launch
                }
                val fileSizeBytes = context.contentResolver.openFileDescriptor(parsedUri, "r")?.use { it.statSize } ?: 0L
                if (fileSizeBytes > 10L * 1024 * 1024) {
                    com.abm.erp.config.AppLog.w("MockRepository", "order photo rejected: too large")
                    onResult(null); return@launch
                }
                val extension = mimeType?.let { android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(it) } ?: "jpg"
                val storageRef = com.google.firebase.storage.FirebaseStorage.getInstance().reference
                    .child("companies/${currentUser.companyId}/orders/$orderId/visit.$extension")
                storageRef.putFile(parsedUri).await()
                val downloadUrl = storageRef.downloadUrl.await().toString()
                db.retailOrderDao().getAll().first().firstOrNull { it.id == orderId }?.let { row ->
                    db.retailOrderDao().upsert(row.copy(retailerPhotoUri = downloadUrl))
                }
                logAudit("RetailOrder", orderId, "PHOTO_UPLOAD")
                onResult(downloadUrl)
            } catch (e: Exception) {
                com.abm.erp.config.AppLog.w("MockRepository", "order photo upload failed", e)
                onResult(null)
            }
        }
    }

    fun uploadRetailerPhoto(context: android.content.Context, retailerId: String, localUri: String, isOwnerPhoto: Boolean, onResult: (String?) -> Unit) {
        scope.launch {
            try {
                val parsedUri = android.net.Uri.parse(localUri)
                val mimeType = context.contentResolver.getType(parsedUri)
                if (mimeType != null && !mimeType.startsWith("image/")) {
                    com.abm.erp.config.AppLog.w("MockRepository", "retailer photo rejected: unsupported type '$mimeType'")
                    onResult(null); return@launch
                }
                val fileSizeBytes = context.contentResolver.openFileDescriptor(parsedUri, "r")?.use { it.statSize } ?: 0L
                if (fileSizeBytes > 15L * 1024 * 1024) {
                    com.abm.erp.config.AppLog.w("MockRepository", "retailer photo rejected: too large")
                    onResult(null); return@launch
                }
                val extension = mimeType?.let { android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(it) } ?: "jpg"
                val fileName = if (isOwnerPhoto) "owner.$extension" else "shop.$extension"
                val storageRef = com.google.firebase.storage.FirebaseStorage.getInstance().reference
                    .child("companies/${currentUser.companyId}/retailers/$retailerId/$fileName")
                storageRef.putFile(parsedUri).await()
                val downloadUrl = storageRef.downloadUrl.await().toString()
                if (isOwnerPhoto) db.retailerDao().updateOwnerPhoto(retailerId, downloadUrl) else db.retailerDao().updateShopPhoto(retailerId, downloadUrl)
                syncCollection("retailers").document(retailerId)
                    .update(if (isOwnerPhoto) "ownerPhotoUri" else "photoUri", downloadUrl)
                    .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-photo failed", it) }
                logAudit("Retailer", retailerId, "PHOTO_UPLOAD", newValue = if (isOwnerPhoto) "owner photo" else "shop photo")
                onResult(downloadUrl)
            } catch (e: Exception) {
                com.abm.erp.config.AppLog.w("MockRepository", "retailer photo upload failed", e)
                onResult(null)
            }
        }
    }

    fun updateRetailerDraft(
        retailerId: String, name: String? = null, ownerName: String? = null, phone: String? = null, altPhone: String? = null,
        email: String? = null, address: String? = null, district: String? = null, upazila: String? = null, market: String? = null,
        area: String? = null, postalCode: String? = null, outletCategory: String? = null, outletType: String? = null,
        classification: String? = null, tradeLicenseNo: String? = null, notes: String? = null, tags: String? = null,
        lat: Double? = null, lng: Double? = null, gpsAccuracyMeters: Double? = null, photoUri: String? = null, ownerPhotoUri: String? = null,
    ): Boolean {
        val existing = retailers.value.firstOrNull { it.id == retailerId } ?: return false
        if (existing.onboardingStatus != "DRAFT" && existing.onboardingStatus != "REJECTED") {
            logAudit("Retailer", retailerId, "DENY", oldValue = existing.onboardingStatus, newValue = "EDIT — only DRAFT/REJECTED can be edited")
            return false
        }
        val updated = existing.copy(
            name = name ?: existing.name, ownerName = ownerName ?: existing.ownerName, phone = phone ?: existing.phone,
            altPhone = altPhone ?: existing.altPhone, email = email ?: existing.email, address = address ?: existing.address,
            district = district ?: existing.district, upazila = upazila ?: existing.upazila, market = market ?: existing.market,
            area = area ?: existing.area, postalCode = postalCode ?: existing.postalCode,
            outletCategory = outletCategory ?: existing.outletCategory, outletType = outletType ?: existing.outletType,
            classification = classification ?: existing.classification, tradeLicenseNo = tradeLicenseNo ?: existing.tradeLicenseNo,
            notes = notes ?: existing.notes, tags = tags ?: existing.tags,
            lat = lat ?: existing.lat, lng = lng ?: existing.lng, gpsAccuracyMeters = gpsAccuracyMeters ?: existing.gpsAccuracyMeters,
            geoCapturedAt = if (lat != null) LocalDateTime.now() else existing.geoCapturedAt,
            photoUri = photoUri ?: existing.photoUri, ownerPhotoUri = ownerPhotoUri ?: existing.ownerPhotoUri,
            // Editing after a rejection clears the old reject reason — the retailer is being freshly corrected, not still-rejected.
            onboardingStatus = if (existing.onboardingStatus == "REJECTED") "DRAFT" else existing.onboardingStatus,
            rejectReason = if (existing.onboardingStatus == "REJECTED") null else existing.rejectReason,
            updatedBy = currentUser.name, updatedAt = LocalDateTime.now(),
        )
        scope.launch {
            val entity = updated.toEntity()
            db.retailerDao().upsert(entity)
            syncCollection("retailers").document(retailerId).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-edit failed", it) }
            logAudit("Retailer", retailerId, "EDIT", oldValue = existing.name, newValue = updated.name)
        }
        return true
    }

    /**
     * Foundation 2, Section 3 — Employee Onboarding: Draft -> Submitted ->
     * HR Review -> Manager Review -> Role Assignment -> Territory
     * Assignment -> Account Activation -> Active. Real duplicate detection
     * (mobile/email) and employee-code uniqueness, matching the same
     * rigor as Foundation 1's retailer onboarding.
     */
    /**
     * Chairman-Only Hiring — HR/Manager/Department-Head submission step.
     * Deliberately accepts ONLY name/contact/notes — no designation,
     * department, role, territory, manager, official mobile, or PIN can
     * be set here, so there is no client-side path to bypass Chairman
     * approval by simply filling in more fields. Status is always
     * PENDING_CHAIRMAN_APPROVAL; hasActiveAccess is false until the
     * Chairman explicitly approves (see chairmanApproveHiring).
     */
    suspend fun submitHiringRequest(fullName: String, proposedMobile: String, proposedEmail: String?, notes: String?): EmployeeProfile? {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.CREATE)) {
            logAudit("EmployeeProfile", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "SUBMIT_HIRING")
            return null
        }
        if (fullName.isBlank()) return null
        val draft = EmployeeProfile(
            id = "HIRE-${java.util.UUID.randomUUID().toString().take(8)}", employeeCode = "", fullName = fullName,
            mobile = "", email = proposedEmail ?: "", department = "", designation = "", role = UserRole.SR,
            companyId = currentUser.companyId, createdBy = currentUser.name,
            onboardingStatus = EmployeeOnboardingStatus.PENDING_CHAIRMAN_APPROVAL,
        )
        val entity = draft.toEntity()
        db.employeeProfileDao().upsert(entity)
        trackRecordSync(entity.id, syncCollection("employeeProfiles").document(entity.id).set(entity)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push hiring-request failed", it) })
        logAudit("EmployeeProfile", draft.id, "HIRING_REQUEST_SUBMITTED", newValue = draft, reason = "submitted by ${currentUser.name} (${currentUser.role}) — proposed mobile: $proposedMobile${notes?.let { " — $it" } ?: ""}")
        createNotification(NotificationCategory.APPROVAL, "New Hiring Request", "$fullName — awaiting Chairman approval")
        return draft
    }

    /** Chairman-Only — editing a still-pending hiring request's basic info (name/proposed mobile/notes). Not the approval itself. */
    fun editHiringRequest(employeeId: String, fullName: String, proposedMobile: String, notes: String?): Boolean {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.EDIT)) return false
        val e = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return false
        if (e.onboardingStatus != EmployeeOnboardingStatus.PENDING_CHAIRMAN_APPROVAL && e.onboardingStatus != EmployeeOnboardingStatus.RETURNED_FOR_CORRECTION) return false
        scope.launch {
            val entity = db.employeeProfileDao().getAll().first().firstOrNull { it.id == employeeId } ?: return@launch
            val updated = entity.copy(fullName = fullName, onboardingStatus = EmployeeOnboardingStatus.PENDING_CHAIRMAN_APPROVAL.name)
            db.employeeProfileDao().upsert(updated)
            syncCollection("employeeProfiles").document(employeeId).set(updated)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push hiring-edit failed", it) }
            logAudit("EmployeeProfile", employeeId, "HIRING_REQUEST_EDITED", newValue = fullName, reason = "edited by ${currentUser.name} — proposed mobile: $proposedMobile${notes?.let { " — $it" } ?: ""}")
        }
        return true
    }

    /**
     * Chairman-Only — the ONLY function that can move a hiring request to
     * ACTIVE. Sets official mobile (dedup-checked), department,
     * designation, role, territory, manager, permission template, and
     * generates the real employee code + a temporary PIN (hashed,
     * force-change-on-first-login) — mirroring createUserAccount's own
     * security posture, never a plaintext PIN.
     */
    fun chairmanApproveHiring(
        employeeId: String, officialMobile: String, department: String, designation: String, role: UserRole,
        territoryId: String?, directManagerId: String?, templateKey: String?,
    ): String? {
        if (currentUser.role != UserRole.CHAIRMAN) {
            logAudit("EmployeeProfile", employeeId, "DENY", oldValue = currentUser.role.name, newValue = "CHAIRMAN_APPROVE_HIRING")
            return null
        }
        if (!com.abm.erp.ABMApplication.isOnlineNow()) {
            logAudit("EmployeeProfile", employeeId, "DENY_OFFLINE", newValue = "Employee Activation requires an online connection")
            return null
        }
        val e = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return null
        if (e.onboardingStatus != EmployeeOnboardingStatus.PENDING_CHAIRMAN_APPROVAL && e.onboardingStatus != EmployeeOnboardingStatus.RETURNED_FOR_CORRECTION) return null
        if (officialMobile.isBlank()) return null
        if (employeeProfiles.value.any { it.id != employeeId && it.mobile == officialMobile && !it.isDeleted }) {
            com.abm.erp.config.AppLog.w("MockRepository", "chairmanApproveHiring rejected: mobile number already in use")
            return null
        }
        val deptAbbrev = department.uppercase().take(4).ifBlank { "GEN" }
        val roleAbbrev = role.name.take(3)
        var tempPin: String
        do { tempPin = (10000..99999).random().toString() } while (com.abm.erp.auth.PinHashing.isWeakPin(tempPin))
        val hashResult = com.abm.erp.auth.PinHashing.createHash(tempPin)
        scope.launch {
            // Central Number Series Engine — was a locally-scoped counter (employeeProfiles.value.count), replaced with the one shared, mutex-guarded series.
            val code = generateNumber("EMPLOYEE", branchCode = "$deptAbbrev-$roleAbbrev")
            val accountResult = createUserAccount(employeeId, currentUser.companyId, tempPin)
            val entity = db.employeeProfileDao().getAll().first().firstOrNull { it.id == employeeId } ?: return@launch
            val updated = entity.copy(
                employeeCode = code, mobile = officialMobile, department = department, designation = designation, role = role.name,
                territoryId = territoryId, directManagerId = directManagerId, assignedTemplateKey = templateKey,
                onboardingStatus = EmployeeOnboardingStatus.ACTIVE.name, status = EmployeeStatus.ACTIVE.name,
                userAccountId = accountResult.accountId,
            )
            db.employeeProfileDao().upsert(updated)
            syncCollection("employeeProfiles").document(employeeId).set(updated)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push chairman-approve failed", it) }
            logAudit("EmployeeProfile", employeeId, "CHAIRMAN_APPROVE_HIRING", newValue = "code=$code mobile=$officialMobile dept=$department role=${role.name} territory=$territoryId manager=$directManagerId template=$templateKey")
            logAudit("EmployeeProfile", employeeId, "PIN_CREATED_ON_APPROVAL") // never the PIN itself
            createNotification(NotificationCategory.APPROVAL, "Employee Activated", "${entity.fullName} is now active — code $code")
        }
        return tempPin
    }

    /** Chairman-Only — rejection requires a mandatory reason (enforced here, not just in the UI). */
    fun chairmanRejectHiring(employeeId: String, reason: String): Boolean {
        if (currentUser.role != UserRole.CHAIRMAN) return false
        if (reason.isBlank()) return false
        val e = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return false
        if (e.onboardingStatus == EmployeeOnboardingStatus.ACTIVE) return false
        scope.launch {
            db.employeeProfileDao().setOnboardingStatus(employeeId, EmployeeOnboardingStatus.REJECTED.name, reason)
            syncCollection("employeeProfiles").document(employeeId).update(mapOf("onboardingStatus" to EmployeeOnboardingStatus.REJECTED.name, "rejectReason" to reason))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push chairman-reject failed", it) }
            logAudit("EmployeeProfile", employeeId, "CHAIRMAN_REJECT_HIRING", reason = reason)
        }
        return true
    }

    /** Chairman-Only — sends a hiring request back to HR/submitter for correction, mandatory comment. */
    fun chairmanReturnForCorrection(employeeId: String, comment: String): Boolean {
        if (currentUser.role != UserRole.CHAIRMAN) return false
        if (comment.isBlank()) return false
        val e = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return false
        if (e.onboardingStatus == EmployeeOnboardingStatus.ACTIVE) return false
        scope.launch {
            db.employeeProfileDao().setOnboardingStatus(employeeId, EmployeeOnboardingStatus.RETURNED_FOR_CORRECTION.name, comment)
            syncCollection("employeeProfiles").document(employeeId).update(mapOf("onboardingStatus" to EmployeeOnboardingStatus.RETURNED_FOR_CORRECTION.name, "rejectReason" to comment))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push chairman-return failed", it) }
            logAudit("EmployeeProfile", employeeId, "CHAIRMAN_RETURN_FOR_CORRECTION", reason = comment)
            createNotification(NotificationCategory.APPROVAL, "Hiring Request Returned", "${e.fullName}: $comment")
        }
        return true
    }

    /** Chairman-Only — suspend/deactivate an already-active employee is already covered by setEmployeeStatus's existing Chairman/MD-tier gate for privileged targets; this adds the same explicit Chairman-only gate for ALL employees when called from the Hiring/Activation center specifically. */
    fun chairmanSetActivation(employeeId: String, status: EmployeeStatus): Boolean {
        if (currentUser.role != UserRole.CHAIRMAN) return false
        return setEmployeeStatus(employeeId, status, "Set by Chairman via Hiring & Activation Center")
    }

    // ---------- Chairman-Controlled Vacancy Management ----------
    /** HR/Manager/Department-Head — submission only, never approval. */
    suspend fun submitVacancyRequest(designation: String, department: String, territoryId: String?, reason: String?): Vacancy? {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.CREATE)) {
            logAudit("Vacancy", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "SUBMIT_VACANCY")
            return null
        }
        val v = Vacancy(
            id = "VAC-${java.util.UUID.randomUUID().toString().take(8)}", companyId = currentUser.companyId,
            designation = designation, department = department, territoryId = territoryId,
            requestedBy = currentUser.employeeId, requestedByName = currentUser.name, reason = reason,
            status = VacancyStatus.PENDING_CHAIRMAN_APPROVAL,
        )
        db.vacancyDao().upsert(v.toEntity())
        syncCollection("vacancies").document(v.id).set(v.toEntity())
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push vacancy failed", it) }
        logAudit("Vacancy", v.id, "SUBMITTED", newValue = v, reason = "by ${currentUser.name}")
        createNotification(NotificationCategory.APPROVAL, "New Vacancy Request", "$designation, $department")
        return v
    }

    /** Chairman-only — every vacancy status transition routes through here so audit logging is never bypassed. */
    private fun chairmanSetVacancyStatus(vacancyId: String, newStatus: VacancyStatus, extra: (com.abm.erp.data.room.VacancyEntity) -> com.abm.erp.data.room.VacancyEntity = { it }): Boolean {
        if (currentUser.role != UserRole.CHAIRMAN) {
            logAudit("Vacancy", vacancyId, "DENY", oldValue = currentUser.role.name, newValue = "VACANCY_STATUS_${newStatus.name}")
            return false
        }
        scope.launch {
            val entity = db.vacancyDao().getAll().first().firstOrNull { it.id == vacancyId } ?: return@launch
            val old = entity.status
            val updated = extra(entity.copy(status = newStatus.name, approvedBy = currentUser.employeeId))
            db.vacancyDao().upsert(updated)
            syncCollection("vacancies").document(vacancyId).set(updated)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push vacancy-status failed", it) }
            logAudit("Vacancy", vacancyId, "STATUS_CHANGE", oldValue = old, newValue = newStatus.name, reason = "by Chairman ${currentUser.name}")
        }
        return true
    }

    fun chairmanApproveVacancy(vacancyId: String): Boolean = chairmanSetVacancyStatus(vacancyId, VacancyStatus.OPEN)
    fun chairmanOpenVacancy(vacancyId: String): Boolean = chairmanSetVacancyStatus(vacancyId, VacancyStatus.OPEN)
    fun chairmanHoldVacancy(vacancyId: String): Boolean = chairmanSetVacancyStatus(vacancyId, VacancyStatus.ON_HOLD)
    fun chairmanReopenVacancy(vacancyId: String): Boolean = chairmanSetVacancyStatus(vacancyId, VacancyStatus.OPEN)
    fun chairmanFreezeVacancy(vacancyId: String): Boolean = chairmanSetVacancyStatus(vacancyId, VacancyStatus.FROZEN)
    fun chairmanCancelVacancy(vacancyId: String): Boolean = chairmanSetVacancyStatus(vacancyId, VacancyStatus.CANCELLED)
    fun chairmanCloseVacancy(vacancyId: String): Boolean = chairmanSetVacancyStatus(vacancyId, VacancyStatus.CLOSED)

    /** Called automatically once chairmanApproveHiring activates an employee whose hiring was linked to a vacancy — marks the vacancy FILLED rather than leaving it OPEN forever. */
    fun chairmanMarkVacancyFilled(vacancyId: String, employeeId: String): Boolean =
        chairmanSetVacancyStatus(vacancyId, VacancyStatus.FILLED) { it.copy(filledByEmployeeId = employeeId) }

    // ---------- Chairman Target Control Center ----------
    data class TargetHistoricalContext(
        val previous3MonthAverage: Double, val previousAchievementPct: Double, val activeDealerCount: Int,
        val activeRetailerCount: Int, val outstandingDue: Double, val availableStock: Double, val areaSalesHistory: Double,
    )

    /** Real historical context, shown before the Chairman confirms a target — never fabricated placeholders. */
    suspend fun targetHistoricalContext(scopeType: TargetScopeType, scopeId: String): TargetHistoricalContext {
        val now = LocalDateTime.now()
        val ledgerAll = db.partyLedgerDao().getAll().first()
        val relevantIds: Set<String> = when (scopeType) {
            TargetScopeType.EMPLOYEE -> retailers.value.filter { it.officerId == scopeId }.map { it.id }.toSet() + dealers.value.filter { it.assignedEmployeeId == scopeId }.map { it.id }.toSet()
            TargetScopeType.DEALER -> setOf(scopeId)
            TargetScopeType.RETAILER -> setOf(scopeId)
            else -> dealers.value.filter { it.zone.equals(scopeId, ignoreCase = true) }.map { it.id }.toSet() + retailers.value.filter { it.district.equals(scopeId, ignoreCase = true) }.map { it.id }.toSet()
        }
        val relevantLedger = ledgerAll.filter { it.partyId in relevantIds }
        val last3MonthSales = relevantLedger.filter { it.type == "DEBIT" && LocalDateTime.ofInstant(Instant.ofEpochMilli(it.createdAtEpochMillis), ZoneOffset.UTC).isAfter(now.minusDays(90)) }.sumOf { it.amount }
        val outstandingDue = dealers.value.filter { it.id in relevantIds }.sumOf { it.dueBalance } + retailers.value.filter { it.id in relevantIds }.sumOf { it.dueBalance }
        val activeDealers = dealers.value.count { it.id in relevantIds && it.isActive }
        val activeRetailers = retailers.value.count { it.id in relevantIds && it.isActive }
        val stock = InventoryRepository.stockLevels.value.sumOf { it.quantityOnHand }
        val pastTargets = targets.value.filter { it.scopeId == scopeId && it.periodEnd.isBefore(LocalDate.now()) }
        val achievementPct = pastTargets.filter { it.targetValue > 0 }.map { it.achievedValue / it.targetValue * 100 }.let { if (it.isEmpty()) 0.0 else it.average() }
        return TargetHistoricalContext(
            previous3MonthAverage = last3MonthSales / 3, previousAchievementPct = achievementPct,
            activeDealerCount = activeDealers, activeRetailerCount = activeRetailers, outstandingDue = outstandingDue,
            availableStock = stock, areaSalesHistory = last3MonthSales,
        )
    }

    /** Manager — proposal only, never confirmed/active until Chairman creates it for real. */
    fun proposeTarget(scopeType: TargetScopeType, scopeId: String, periodType: TargetPeriodType, periodStart: LocalDate, periodEnd: LocalDate, targetType: TargetType, targetValue: Double): Boolean {
        if (currentUser.role == UserRole.SR) return false // proposal is manager-tier and above, matching "Managers may only submit target proposals"
        logAudit("Target", "(proposal)", "PROPOSED", newValue = "scope=$scopeType:$scopeId type=$targetType value=$targetValue period=$periodStart..$periodEnd", reason = "proposed by ${currentUser.name}")
        createNotification(NotificationCategory.APPROVAL, "Target Proposal", "${currentUser.name} proposed $targetType=$targetValue for $scopeId")
        return true
    }

    /**
     * Chairman-only — real target creation. isOverride/overrideReason let
     * the Chairman confirm a target that's unusually high/low vs history
     * (the UI shows targetHistoricalContext first and warns, but the
     * actual override gate is enforced here: if the new value is >50%
     * away from previous3MonthAverage, overrideReason becomes mandatory).
     */
    fun chairmanCreateTarget(
        scopeType: TargetScopeType, scopeId: String, parentTargetId: String?, periodType: TargetPeriodType,
        periodStart: LocalDate, periodEnd: LocalDate, targetType: TargetType, targetValue: Double,
        historicalAverage: Double, overrideReason: String?,
    ): Target? {
        if (currentUser.role != UserRole.CHAIRMAN) {
            logAudit("Target", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE_TARGET")
            return null
        }
        if (!com.abm.erp.ABMApplication.isOnlineNow()) {
            logAudit("Target", "(new)", "DENY_OFFLINE", newValue = "Target Approval requires an online connection")
            return null
        }
        val isUnusual = historicalAverage > 0 && (targetValue > historicalAverage * 1.5 || targetValue < historicalAverage * 0.5)
        if (isUnusual && overrideReason.isNullOrBlank()) {
            com.abm.erp.config.AppLog.w("MockRepository", "chairmanCreateTarget rejected: target is unusually different from history and no override reason given")
            return null
        }
        val t = Target(
            id = "TGT-${java.util.UUID.randomUUID().toString().take(8)}", companyId = currentUser.companyId,
            scopeType = scopeType, scopeId = scopeId, parentTargetId = parentTargetId, periodType = periodType,
            periodStart = periodStart, periodEnd = periodEnd, targetType = targetType, targetValue = targetValue,
            isOverride = isUnusual, overrideReason = overrideReason.takeIf { isUnusual }, createdBy = currentUser.name,
        )
        scope.launch {
            db.targetDao().upsert(t.toEntity())
            syncCollection("targets").document(t.id).set(t.toEntity())
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push target failed", it) }
            logAudit("Target", t.id, "CREATE", newValue = t, reason = "by Chairman ${currentUser.name}" + (overrideReason?.let { " — override: $it" } ?: ""))
        }
        return t
    }

    /** Chairman-only — every edit is logged in TargetChangeLog (old value, new value, reason, who, when) rather than silently overwriting. */
    fun chairmanEditTarget(targetId: String, newValue: Double, reason: String): Boolean {
        if (currentUser.role != UserRole.CHAIRMAN) return false
        if (reason.isBlank()) return false
        scope.launch {
            val entity = db.targetDao().getAll().first().firstOrNull { it.id == targetId } ?: return@launch
            val changeLog = TargetChangeLog(
                id = "TCL-${java.util.UUID.randomUUID().toString().take(8)}", targetId = targetId,
                oldValue = entity.targetValue, newValue = newValue, reason = reason,
                changedBy = currentUser.employeeId, changedByName = currentUser.name,
            )
            db.targetChangeLogDao().upsert(changeLog.toEntity())
            syncCollection("targetChangeLogs").document(changeLog.id).set(changeLog.toEntity())
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push target-change-log failed", it) }
            val updated = entity.copy(targetValue = newValue)
            db.targetDao().upsert(updated)
            syncCollection("targets").document(targetId).set(updated)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push target-edit failed", it) }
            logAudit("Target", targetId, "EDIT", oldValue = entity.targetValue, newValue = newValue, reason = reason)
        }
        return true
    }

    fun chairmanIncreaseTarget(targetId: String, byAmount: Double, reason: String): Boolean {
        val current = targets.value.firstOrNull { it.id == targetId } ?: return false
        return chairmanEditTarget(targetId, current.targetValue + byAmount, reason)
    }

    fun chairmanReduceTarget(targetId: String, byAmount: Double, reason: String): Boolean {
        val current = targets.value.firstOrNull { it.id == targetId } ?: return false
        return chairmanEditTarget(targetId, (current.targetValue - byAmount).coerceAtLeast(0.0), reason)
    }

    private fun chairmanSetTargetStatus(targetId: String, status: String, reason: String): Boolean {
        if (currentUser.role != UserRole.CHAIRMAN) return false
        scope.launch {
            val entity = db.targetDao().getAll().first().firstOrNull { it.id == targetId } ?: return@launch
            db.targetDao().upsert(entity.copy(status = status))
            syncCollection("targets").document(targetId).update("status", status)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push target-status failed", it) }
            logAudit("Target", targetId, "STATUS_$status", reason = reason)
        }
        return true
    }

    fun chairmanPauseTarget(targetId: String, reason: String): Boolean = chairmanSetTargetStatus(targetId, "PAUSED", reason)
    fun chairmanCancelTarget(targetId: String, reason: String): Boolean = chairmanSetTargetStatus(targetId, "CANCELLED", reason)

    /** Reassignment creates a NEW target row for the new scope and cancels the old one — preserves history rather than mutating scopeId in place. */
    fun chairmanReassignTarget(targetId: String, newScopeId: String, reason: String): Target? {
        if (currentUser.role != UserRole.CHAIRMAN) return null
        val old = targets.value.firstOrNull { it.id == targetId } ?: return null
        chairmanSetTargetStatus(targetId, "CANCELLED", "Reassigned to $newScopeId — $reason")
        return chairmanCreateTarget(old.scopeType, newScopeId, old.parentTargetId, old.periodType, old.periodStart, old.periodEnd, old.targetType, old.targetValue, old.targetValue, "Reassigned from ${old.scopeId}: $reason")
    }


    // ==========================================================
    // Section 2 — Accounting Period Lock
    // ==========================================================
    /** Real check every edit-path in a locked module should call before allowing a write against a date. */
    fun isDateLocked(date: LocalDate): Boolean =
        accountingPeriodLocks.value.any { it.isLocked && !date.isBefore(it.periodStart) && !date.isAfter(it.periodEnd) }

    fun lockAccountingPeriod(scope_: PeriodLockScope, periodStart: LocalDate, periodEnd: LocalDate): Boolean {
        val myProfile = employeeProfiles.value.firstOrNull { it.id == currentUser.employeeId }
        val isAccountsWithAuthority = myProfile?.department?.contains("account", ignoreCase = true) == true && myProfile.financialApprovalLimit > 0
        if (currentUser.role != UserRole.CHAIRMAN && !isAccountsWithAuthority) {
            logAudit("AccountingPeriodLock", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "LOCK")
            return false
        }
        val lock = AccountingPeriodLock(
            id = "LOCK-${java.util.UUID.randomUUID().toString().take(8)}", companyId = currentUser.companyId, scope = scope_,
            periodStart = periodStart, periodEnd = periodEnd, lockedBy = currentUser.employeeId, lockedByName = currentUser.name, isLocked = true,
        )
        scope.launch {
            db.accountingPeriodLockDao().upsert(lock.toEntity())
            syncCollection("accountingPeriodLocks").document(lock.id).set(lock.toEntity())
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push period-lock failed", it) }
            logAudit("AccountingPeriodLock", lock.id, "LOCK", newValue = lock)
        }
        return true
    }

    // Deliberately Chairman-only, even though lockAccountingPeriod above also allows Accounts — the requirement only names Accounts for LOCKING; unlocking a closed period is the more sensitive reversal action, so it stays a stricter, Chairman-only gate.
    fun unlockAccountingPeriod(lockId: String, reason: String): Boolean {
        if (currentUser.role != UserRole.CHAIRMAN || reason.isBlank()) return false
        scope.launch {
            val entity = db.accountingPeriodLockDao().getAll().first().firstOrNull { it.id == lockId } ?: return@launch
            val updated = entity.copy(isLocked = false, unlockedBy = currentUser.name, unlockedAtEpochMillis = System.currentTimeMillis())
            db.accountingPeriodLockDao().upsert(updated)
            syncCollection("accountingPeriodLocks").document(lockId).set(updated)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push period-unlock failed", it) }
            logAudit("AccountingPeriodLock", lockId, "UNLOCK", reason = reason)
        }
        return true
    }

    // ==========================================================
    // Section 3 — Central Number Series Engine
    // ==========================================================
    private val numberSeriesMutex = kotlinx.coroutines.sync.Mutex()

    /**
     * The ONE place any module gets its next official number — company
     * prefix + optional branch prefix + optional financial-year segment
     * + a running number, mutex-guarded against concurrent duplicates.
     * Offline: still generates a number immediately (marked TEMP-) so
     * work is never blocked; replaceTemporaryNumber below swaps it for a
     * real series number once back online and synced.
     */
    suspend fun generateNumber(seriesKey: String, branchCode: String? = null): String = numberSeriesMutex.withLock {
        // Real duplicate-prevention fix — reading the cached numberSeriesConfigs
        // StateFlow here was unsafe: Room's Flow emission after upsert() is
        // asynchronous, so a rapid next call (even after this mutex releases)
        // could see a stale currentRunningNumber and generate the SAME number
        // twice. Reading directly from the DAO inside this same locked block
        // makes the read-modify-write cycle genuinely atomic.
        val existing = db.numberSeriesConfigDao().getAll().first().firstOrNull { it.id == seriesKey }?.toDomain()
        val config = existing ?: NumberSeriesConfig(id = seriesKey, companyId = currentUser.companyId, branchPrefix = branchCode, fiscalYearStartMonth = companySettings().fiscalYearStartMonth)
        val nextRunning = config.currentRunningNumber + 1
        val updated = config.copy(currentRunningNumber = nextRunning)
        db.numberSeriesConfigDao().upsert(updated.toEntity())
        syncCollection("numberSeriesConfigs").document(seriesKey).set(updated.toEntity())
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push number-series failed", it) }
        // Real Financial Year — respects the company's configured fiscal-year start month (e.g. July for Bangladesh's standard July–June FY) rather than assuming January–December calendar year, which would mislabel the second half of the year with the wrong FY.
        val today = LocalDate.now()
        val fyEndYear = if (today.monthValue >= config.fiscalYearStartMonth) today.year + 1 else today.year
        val fySegment = if (config.useFinancialYear) "-FY${fyEndYear % 100}" else ""
        val branchSegment = config.branchPrefix?.let { "-$it" } ?: ""
        "${config.companyPrefix}-$seriesKey$branchSegment$fySegment-${nextRunning.toString().padStart(config.padWidth, '0')}"
    }

    /** Offline-safe temporary number, replaced with a real series number once synced (never a permanent placeholder). */
    fun generateTemporaryNumber(seriesKey: String): String = "TEMP-$seriesKey-${System.currentTimeMillis()}"

    suspend fun replaceTemporaryNumber(seriesKey: String, branchCode: String? = null): String = generateNumber(seriesKey, branchCode)

    // ==========================================================
    // Section 4 — Data Ownership Transfer
    // ==========================================================
    /**
     * Real ownership transfer with full history — used when an employee
     * resigns or an area changes. Records a transfer entry regardless of
     * scope; Dealer/Retailer scopes additionally update the actual
     * assignedEmployeeId/officerId field so the transfer takes effect
     * immediately, not just as a paper record.
     */
    fun transferOwnership(scope_: OwnershipTransferScope, entityId: String, fromEmployeeId: String?, toEmployeeId: String, reason: String): Boolean {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.EDIT)) {
            logAudit("OwnershipTransferRecord", entityId, "DENY", oldValue = currentUser.role.name, newValue = "TRANSFER")
            return false
        }
        // Target reassignment internally requires Chairman (chairmanReassignTarget's own gate) — check that up front so this never silently reports success while the actual reassignment quietly no-ops for an HR-authorized-but-non-Chairman caller.
        if (scope_ == OwnershipTransferScope.TARGET && currentUser.role != UserRole.CHAIRMAN) {
            logAudit("OwnershipTransferRecord", entityId, "DENY", oldValue = currentUser.role.name, newValue = "TRANSFER_TARGET_REQUIRES_CHAIRMAN")
            return false
        }
        if (reason.isBlank()) return false
        val record = OwnershipTransferRecord(
            id = "OWN-${java.util.UUID.randomUUID().toString().take(8)}", companyId = currentUser.companyId, scope = scope_,
            entityId = entityId, fromEmployeeId = fromEmployeeId, toEmployeeId = toEmployeeId, reason = reason, transferredBy = currentUser.name,
        )
        scope.launch {
            db.ownershipTransferRecordDao().upsert(record.toEntity())
            syncCollection("ownershipTransferRecords").document(record.id).set(record.toEntity())
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push ownership-transfer failed", it) }
            when (scope_) {
                OwnershipTransferScope.DEALER -> {
                    val d = db.dealerDao().getAll().first().firstOrNull { it.id == entityId }
                    if (d != null) {
                        val updated = d.copy(assignedEmployeeId = toEmployeeId)
                        db.dealerDao().upsert(updated)
                        syncCollection("dealers").document(entityId).update("assignedEmployeeId", toEmployeeId)
                            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push dealer-ownership failed", it) }
                    }
                }
                OwnershipTransferScope.RETAILER -> {
                    val r = db.retailerDao().getAll().first().firstOrNull { it.id == entityId }
                    if (r != null) {
                        val updated = r.copy(officerId = toEmployeeId)
                        db.retailerDao().upsert(updated)
                        syncCollection("retailers").document(entityId).update("officerId", toEmployeeId)
                            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-ownership failed", it) }
                    }
                }
                // Target — entityId is the Target's own id; real reassignment via the existing Chairman-only target-transfer path (preserves history via TargetChangeLog, never mutates scopeId in place).
                OwnershipTransferScope.TARGET -> {
                    chairmanReassignTarget(entityId, toEmployeeId, reason)
                }
                // Route — entityId is the SalesRoute's own id; real reassignment of who walks this beat.
                OwnershipTransferScope.ROUTE -> {
                    val route = db.salesRouteDao().getAll().first().firstOrNull { it.id == entityId }
                    if (route != null) {
                        val updated = route.copy(assignedToEmployeeId = toEmployeeId)
                        db.salesRouteDao().upsert(updated)
                        syncCollection("salesRoutes").document(entityId).update("assignedToEmployeeId", toEmployeeId)
                            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push route-ownership failed", it) }
                    }
                }
                // Follow-up — entityId is the CustomerComplaint's own id; real reassignment of who's following up, only for complaints not yet resolved/closed (a resolved complaint's history stays with whoever actually resolved it).
                OwnershipTransferScope.FOLLOW_UP -> {
                    val complaint = db.customerComplaintDao().getAll().first().firstOrNull { it.id == entityId }
                    if (complaint != null && complaint.status !in setOf("RESOLVED", "CLOSED", "REJECTED")) {
                        val toEmployeeName = employeeProfiles.value.firstOrNull { it.id == toEmployeeId }?.fullName ?: toEmployeeId
                        db.customerComplaintDao().assign(entityId, "ASSIGNED", toEmployeeId, toEmployeeName)
                        syncCollection("customerComplaints").document(entityId).update(mapOf("status" to "ASSIGNED", "assignedEmployeeId" to toEmployeeId, "assignedEmployeeName" to toEmployeeName))
                            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push followup-ownership failed", it) }
                    }
                }
                // Due / Collection Responsibility — these live ON the Dealer/Retailer record itself (dueBalance, officerId), not as separately-owned entities, so they transfer automatically as part of the DEALER/RETAILER case above. No separate action needed here — this is a documented design choice, not a silent gap.
                OwnershipTransferScope.DUE, OwnershipTransferScope.COLLECTION_RESPONSIBILITY -> {}
                // Pending Tasks — no distinct Task entity exists anywhere in this codebase; there is nothing to reassign. Documented honestly rather than silently claimed complete.
                OwnershipTransferScope.PENDING_TASK -> {
                    com.abm.erp.config.AppLog.w("MockRepository", "transferOwnership(PENDING_TASK) — no Task entity exists in this codebase; recorded as a transfer-history entry only")
                }
                // Visits — upcoming/planned visits are represented by SalesRoute's outlet list (covered by the ROUTE case); historical VisitLog rows are never rewritten, preserving "who actually visited when" as real history.
                OwnershipTransferScope.VISIT -> {}
            }
            logAudit("OwnershipTransferRecord", record.id, "TRANSFER", newValue = record, reason = "by ${currentUser.name}")
        }
        return true
    }

    // ==========================================================
    // Production-to-Warehouse workflow (Phase 7 real business logic)
    // ==========================================================

    /** Real Production Plan creation — auto-generates a real, collision-safe batch number. */
    suspend fun createProductionPlan(
        productId: String, variant: String?, plannedQuantity: Double, unit: String,
        manufacturingUnitId: String, productionLine: String?, shiftType: ShiftType,
        supervisorEmployeeId: String?, productionDate: LocalDate,
    ): ProductionPlan? {
        if (!PermissionManager.canCurrentUser("prod", PermissionAction.CREATE)) {
            logAudit("ProductionPlan", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return null
        }
        if (plannedQuantity <= 0.0) return null
        // Central Number Series Engine — replaces the locally-scoped counter with the one shared, mutex-guarded series.
        val batchNumber = generateNumber("PRODUCTION_BATCH", branchCode = manufacturingUnitId.take(3).uppercase())
        val plan = ProductionPlan(
            id = "PP-${java.util.UUID.randomUUID().toString().take(8)}", planNumber = batchNumber, companyId = currentUser.companyId,
            productId = productId, variant = variant, plannedQuantity = plannedQuantity, unit = unit, batchNumber = batchNumber,
            productionDate = productionDate, manufacturingUnitId = manufacturingUnitId, productionLine = productionLine,
            shiftType = shiftType, supervisorEmployeeId = supervisorEmployeeId, status = ProductionPlanStatus.DRAFT, createdBy = currentUser.name,
        )
        scope.launch {
            db.productionPlanDao().upsert(plan.toEntity())
            syncCollection("productionPlans").document(plan.id).set(plan.toEntity())
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push production-plan failed", it) }
            logAudit("ProductionPlan", plan.id, "CREATE", newValue = plan)
        }
        return plan
    }

    fun approveProductionPlan(planId: String): Boolean {
        if (!PermissionManager.canCurrentUser("prod", PermissionAction.APPROVE)) {
            logAudit("ProductionPlan", planId, "DENY", oldValue = currentUser.role.name, newValue = "APPROVE")
            return false
        }
        val plan = productionPlans.value.firstOrNull { it.id == planId } ?: return false
        if (plan.status != ProductionPlanStatus.DRAFT) return false // idempotency guard
        if (isDateLocked(plan.productionDate)) {
            logAudit("ProductionPlan", planId, "DENY_LOCKED_PERIOD", oldValue = plan.productionDate.toString(), newValue = "APPROVE_ATTEMPT")
            return false
        }
        scope.launch {
            val entity = db.productionPlanDao().getAll().first().firstOrNull { it.id == planId } ?: return@launch
            val updated = entity.copy(status = ProductionPlanStatus.APPROVED.name)
            db.productionPlanDao().upsert(updated)
            syncCollection("productionPlans").document(planId).update("status", ProductionPlanStatus.APPROVED.name)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push production-plan-approve failed", it) }
            logAudit("ProductionPlan", planId, "APPROVE")
            activateQrFor("ProductionBatch", planId)  // approved batch gets its floor tag
        }
        return true
    }

    /**
     * Raw Material Issue — validates available stock BEFORE issuing
     * (never lets stock go negative), deducts transactionally via the
     * proven InventoryRepository.adjustStock, and moves the plan to
     * IN_PRODUCTION on first issue.
     */
    suspend fun issueRawMaterial(productionPlanId: String, materialProductId: String, warehouseId: String, quantity: Double): Boolean {
        if (!PermissionManager.canCurrentUser("prod", PermissionAction.EDIT)) {
            logAudit("RawMaterialIssue", productionPlanId, "DENY", oldValue = currentUser.role.name, newValue = "ISSUE")
            return false
        }
        if (quantity <= 0.0) return false
        val plan = productionPlans.value.firstOrNull { it.id == productionPlanId } ?: return false
        if (plan.status !in setOf(ProductionPlanStatus.APPROVED, ProductionPlanStatus.IN_PRODUCTION)) return false
        // Section 6 — Raw Material bucket validation. Issuing from a
        // non-RAW_MATERIAL warehouse would blur the "separate but linked"
        // stock buckets the spec requires.
        val sourceWarehouse = InventoryRepository.warehouses.value.firstOrNull { it.id == warehouseId }
        if (sourceWarehouse == null || sourceWarehouse.stockCategory != StockCategory.RAW_MATERIAL) {
            com.abm.erp.config.AppLog.w("MockRepository", "issueRawMaterial rejected: source warehouse is not a RAW_MATERIAL-category warehouse")
            return false
        }
        val available = InventoryRepository.stockLevels.value.firstOrNull { it.productId == materialProductId && it.warehouseId == warehouseId }?.quantityOnHand ?: 0.0
        if (available < quantity) {
            com.abm.erp.config.AppLog.w("MockRepository", "issueRawMaterial rejected: insufficient stock ($available < $quantity)")
            return false
        }
        val issue = RawMaterialIssue(
            id = "RMI-${java.util.UUID.randomUUID().toString().take(8)}", productionPlanId = productionPlanId, companyId = currentUser.companyId,
            materialProductId = materialProductId, warehouseId = warehouseId, issuedQuantity = quantity, issuedBy = currentUser.name,
        )
        db.rawMaterialIssueDao().upsert(issue.toEntity())
        syncCollection("rawMaterialIssues").document(issue.id).set(issue.toEntity())
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push raw-material-issue failed", it) }
        InventoryRepository.adjustStock(materialProductId, warehouseId, quantity, com.abm.erp.data.MovementType.OUT, "Raw material issue for production plan ${plan.planNumber}")
        // Real WIP tracking — the issued material doesn't just disappear from tracked stock, it moves into the Work In Progress bucket until this batch is confirmed as finished goods.
        val wipWarehouseId = InventoryRepository.getOrCreateSystemWarehouse(StockCategory.WORK_IN_PROGRESS, currentUser.companyId)
        InventoryRepository.adjustStock(materialProductId, wipWarehouseId, quantity, com.abm.erp.data.MovementType.IN, "WIP — raw material issued for production plan ${plan.planNumber}")
        if (plan.status == ProductionPlanStatus.APPROVED) {
            val entity = db.productionPlanDao().getAll().first().firstOrNull { it.id == productionPlanId }
            if (entity != null) {
                db.productionPlanDao().upsert(entity.copy(status = ProductionPlanStatus.IN_PRODUCTION.name))
                syncCollection("productionPlans").document(productionPlanId).update("status", ProductionPlanStatus.IN_PRODUCTION.name)
                    .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push production-plan-status failed", it) }
            }
        }
        logAudit("RawMaterialIssue", issue.id, "ISSUE", newValue = issue)
        return true
    }

    /** Quality Control — failed/held goods must never become available for sale; enforced by isSellable at every finished-goods read site, not just here. */
    fun recordQualityInspection(productionPlanId: String?, batchId: String?, transferId: String?, inspector: String, testParameters: String?, result: QcResult, sampleQuantity: Double, rejectedQuantity: Double, comment: String?): QualityInspection? {
        if (!PermissionManager.canCurrentUser("prod", PermissionAction.CREATE)) {
            logAudit("QualityInspection", productionPlanId ?: transferId ?: "(new)", "DENY", oldValue = currentUser.role.name, newValue = "INSPECT")
            return null
        }
        val inspection = QualityInspection(
            id = "QC-${java.util.UUID.randomUUID().toString().take(8)}", productionPlanId = productionPlanId, batchId = batchId, transferId = transferId,
            companyId = currentUser.companyId, inspector = inspector, testParameters = testParameters, result = result,
            sampleQuantity = sampleQuantity, rejectedQuantity = rejectedQuantity, comment = comment,
        )
        scope.launch {
            db.qualityInspectionDao().upsert(inspection.toEntity())
            syncCollection("qualityInspections").document(inspection.id).set(inspection.toEntity())
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push qc failed", it) }
            logAudit("QualityInspection", inspection.id, "RECORD", newValue = inspection)
        }
        return inspection
    }

    /**
     * Packing — enforces the reconciliation rule (input bulk = accepted +
     * damaged + process loss + remaining) rather than silently accepting
     * a mismatch; requires an authorized override to proceed if it
     * doesn't balance.
     */
    fun recordPacking(productionPlanId: String, bulkQuantityReceived: Double, packingSize: Double, numberOfPacks: Int, numberOfCartons: Int, looseQuantity: Double, damagedPacks: Int, wastageQuantity: Double, allowMismatchOverride: Boolean = false): PackingRecord? {
        if (!PermissionManager.canCurrentUser("prod", PermissionAction.CREATE)) {
            logAudit("PackingRecord", productionPlanId, "DENY", oldValue = currentUser.role.name, newValue = "PACK")
            return null
        }
        val finalAccepted = (numberOfPacks * packingSize) + looseQuantity
        val reconciliationDelta = bulkQuantityReceived - (finalAccepted + (damagedPacks * packingSize) + wastageQuantity)
        if (kotlin.math.abs(reconciliationDelta) > 0.01 && !allowMismatchOverride) {
            com.abm.erp.config.AppLog.w("MockRepository", "recordPacking blocked: reconciliation mismatch of $reconciliationDelta — requires authorized override")
            return null
        }
        val record = PackingRecord(
            id = "PACK-${java.util.UUID.randomUUID().toString().take(8)}", productionPlanId = productionPlanId, companyId = currentUser.companyId,
            bulkQuantityReceived = bulkQuantityReceived, packingSize = packingSize, numberOfPacks = numberOfPacks, numberOfCartons = numberOfCartons,
            looseQuantity = looseQuantity, damagedPacks = damagedPacks, wastageQuantity = wastageQuantity, finalAcceptedQuantity = finalAccepted, createdBy = currentUser.name,
        )
        scope.launch {
            db.packingRecordDao().upsert(record.toEntity())
            syncCollection("packingRecords").document(record.id).set(record.toEntity())
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push packing failed", it) }
            logAudit("PackingRecord", record.id, "RECORD", newValue = record, reason = if (kotlin.math.abs(reconciliationDelta) > 0.01) "AUTHORIZED OVERRIDE — mismatch $reconciliationDelta" else null)
        }
        return record
    }

    /**
     * Finished Goods Confirmation — only after QC pass/conditional-pass;
     * idempotent (checks a FinishedGoodsReceipt doesn't already exist for
     * this plan+batch before creating stock, so a retried request never
     * double-creates stock).
     */
    suspend fun confirmFinishedGoods(productionPlanId: String, productId: String, batchCode: String, manufacturingDate: LocalDate, expiryDate: LocalDate?, quantity: Double, unit: String, warehouseId: String, unitCost: Double): FinishedGoodsReceipt? {
        if (!PermissionManager.canCurrentUser("prod", PermissionAction.APPROVE)) {
            logAudit("FinishedGoodsReceipt", productionPlanId, "DENY", oldValue = currentUser.role.name, newValue = "CONFIRM")
            return null
        }
        if (finishedGoodsReceipts.value.any { it.productionPlanId == productionPlanId && it.batchCode == batchCode }) {
            com.abm.erp.config.AppLog.w("MockRepository", "confirmFinishedGoods rejected: already confirmed for this plan+batch (idempotency guard)")
            return null
        }
        val latestQc = qualityInspections.value.filter { it.productionPlanId == productionPlanId }.maxByOrNull { it.createdAt }
        if (latestQc == null || !latestQc.isSellable) {
            com.abm.erp.config.AppLog.w("MockRepository", "confirmFinishedGoods rejected: no passing QC inspection on record for this plan")
            return null
        }
        // Critical guard — "Production completion must not directly increase
        // saleable warehouse stock." Finished goods must land in a
        // PRODUCTION-category (factory-side) warehouse only; reaching the
        // saleable main warehouse REQUIRES the transfer/dispatch/receiving
        // chain below. Without this, confirmFinishedGoods previously
        // accepted any warehouseId at all — including a STORE-category
        // (saleable) warehouse — bypassing that chain entirely.
        val targetWarehouse = InventoryRepository.warehouses.value.firstOrNull { it.id == warehouseId }
        if (targetWarehouse == null || targetWarehouse.stockCategory != StockCategory.PRODUCTION) {
            com.abm.erp.config.AppLog.w("MockRepository", "confirmFinishedGoods rejected: target warehouse is not a PRODUCTION-category (factory-side) warehouse — saleable stock must only increase via the transfer/dispatch/receiving chain")
            return null
        }
        val receipt = FinishedGoodsReceipt(
            id = "FGR-${java.util.UUID.randomUUID().toString().take(8)}", productionPlanId = productionPlanId, companyId = currentUser.companyId,
            productId = productId, batchCode = batchCode, manufacturingDate = manufacturingDate, expiryDate = expiryDate,
            quantity = quantity, unit = unit, warehouseId = warehouseId, unitCost = unitCost, qcStatus = latestQc.result,
        )
        db.finishedGoodsReceiptDao().upsert(receipt.toEntity())
        syncCollection("finishedGoodsReceipts").document(receipt.id).set(receipt.toEntity())
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push finished-goods failed", it) }
        InventoryRepository.adjustStock(productId, warehouseId, quantity, com.abm.erp.data.MovementType.IN, "Finished goods from production plan $productionPlanId, batch $batchCode", batchCode = batchCode, unitCost = unitCost)
        // Real WIP consumption — every raw-material-issue tied to this plan moves OUT of the Work In Progress bucket now that it has become finished goods.
        val wipWarehouseId = InventoryRepository.getOrCreateSystemWarehouse(StockCategory.WORK_IN_PROGRESS, currentUser.companyId)
        val issuesForThisPlan = db.rawMaterialIssueDao().getAll().first().filter { it.productionPlanId == productionPlanId }
        issuesForThisPlan.forEach { issueEntity ->
            InventoryRepository.adjustStock(issueEntity.materialProductId, wipWarehouseId, issueEntity.issuedQuantity, com.abm.erp.data.MovementType.OUT, "WIP consumed — production plan $productionPlanId completed as finished goods")
        }
        val planEntity = db.productionPlanDao().getAll().first().firstOrNull { it.id == productionPlanId }
        if (planEntity != null) {
            db.productionPlanDao().upsert(planEntity.copy(status = ProductionPlanStatus.COMPLETED.name))
            syncCollection("productionPlans").document(productionPlanId).update("status", ProductionPlanStatus.COMPLETED.name)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push production-plan-complete failed", it) }
        }
        logAudit("FinishedGoodsReceipt", receipt.id, "CONFIRM", newValue = receipt)
        return receipt
    }

    // ---------- Warehouse Transfer chain ----------

    suspend fun createWarehouseTransferRequest(sourceWarehouseId: String, destinationWarehouseId: String, lines: List<WarehouseTransferLine>, vehicle: String?, driver: String?, expectedDeliveryDate: LocalDate?, notes: String?): WarehouseTransfer? {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.CREATE)) {
            logAudit("WarehouseTransfer", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return null
        }
        if (lines.isEmpty() || sourceWarehouseId == destinationWarehouseId) return null
        // Central Number Series Engine — replaces the locally-scoped counter with the one shared, mutex-guarded series.
        val transferNumber = generateNumber("WAREHOUSE_TRANSFER")
        val newTransferId = "WT-${java.util.UUID.randomUUID().toString().take(8)}"
        val transfer = WarehouseTransfer(
            id = newTransferId, transferNumber = transferNumber, companyId = currentUser.companyId,
            sourceWarehouseId = sourceWarehouseId, destinationWarehouseId = destinationWarehouseId,
            lines = lines.map { it.copy(transferId = newTransferId) }, requestedBy = currentUser.name,
            vehicle = vehicle, driver = driver, expectedDeliveryDate = expectedDeliveryDate, notes = notes, status = TransferStatus.DRAFT,
        )
        scope.launch {
            db.warehouseTransferDao().upsert(transfer.toEntity())
            syncCollection("warehouseTransfers").document(transfer.id).set(transfer.toEntity())
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push warehouse-transfer failed", it) }
            logAudit("WarehouseTransfer", transfer.id, "CREATE", newValue = transfer)
        }
        return transfer
    }

    fun approveWarehouseTransfer(transferId: String): Boolean {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.APPROVE)) {
            logAudit("WarehouseTransfer", transferId, "DENY", oldValue = currentUser.role.name, newValue = "APPROVE")
            return false
        }
        if (!com.abm.erp.ABMApplication.isOnlineNow()) {
            logAudit("WarehouseTransfer", transferId, "DENY_OFFLINE", newValue = "Warehouse Transfer Approval requires an online connection")
            return false
        }
        val transfer = warehouseTransfers.value.firstOrNull { it.id == transferId } ?: return false
        if (transfer.status != TransferStatus.DRAFT && transfer.status != TransferStatus.SUBMITTED) return false
        scope.launch {
            val entity = db.warehouseTransferDao().getAll().first().firstOrNull { it.id == transferId } ?: return@launch
            val updated = entity.copy(status = TransferStatus.APPROVED.name, approvedBy = currentUser.name)
            db.warehouseTransferDao().upsert(updated)
            syncCollection("warehouseTransfers").document(transferId).set(updated)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push transfer-approve failed", it) }
            logAudit("WarehouseTransfer", transferId, "APPROVE")
        }
        return true
    }

    /**
     * Dispatch — reserves/deducts source stock (real inventory movement,
     * OUT), moves the transfer into IN_TRANSIT, generates a real challan
     * number. Destination stock is deliberately NOT touched here — only
     * receiveWarehouseTransfer below adds it, matching "do not add stock
     * to destination until receiving is confirmed".
     */
    suspend fun dispatchWarehouseTransfer(transferId: String, vehicle: String?, driver: String?): Boolean {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.EDIT)) {
            logAudit("WarehouseTransfer", transferId, "DENY", oldValue = currentUser.role.name, newValue = "DISPATCH")
            return false
        }
        val transfer = warehouseTransfers.value.firstOrNull { it.id == transferId } ?: return false
        if (transfer.status != TransferStatus.APPROVED) return false
        for (line in transfer.lines) {
            val available = InventoryRepository.stockLevels.value.firstOrNull { it.productId == line.productId && it.warehouseId == transfer.sourceWarehouseId }?.quantityOnHand ?: 0.0
            if (available < line.quantity) {
                com.abm.erp.config.AppLog.w("MockRepository", "dispatchWarehouseTransfer rejected: insufficient stock for ${line.productId}")
                return false
            }
        }
        var seq = warehouseTransfers.value.count { it.dispatchChallanNumber != null } + 1
        var challan = "CH-${seq.toString().padStart(6, '0')}"
        var attempts = 0
        while (warehouseTransfers.value.any { it.dispatchChallanNumber == challan } && attempts < 100000) { seq++; challan = "CH-${seq.toString().padStart(6, '0')}"; attempts++ }
        transfer.lines.forEach { line -> InventoryRepository.adjustStock(line.productId, transfer.sourceWarehouseId, line.quantity, com.abm.erp.data.MovementType.OUT, "Dispatch transfer ${transfer.transferNumber} to ${transfer.destinationWarehouseId}", batchCode = line.batchCode) }
        // Real In-Transit bucket — the comment above used to claim dispatch "moves the transfer into IN_TRANSIT", but that was only ever a status label on the transfer record; the stock itself vanished from all tracked warehouses between dispatch and receiving. Now genuinely tracked.
        val inTransitWarehouseId = InventoryRepository.getOrCreateSystemWarehouse(StockCategory.IN_TRANSIT, currentUser.companyId)
        transfer.lines.forEach { line -> InventoryRepository.adjustStock(line.productId, inTransitWarehouseId, line.quantity, com.abm.erp.data.MovementType.IN, "In-transit — dispatched via transfer ${transfer.transferNumber}", batchCode = line.batchCode) }
        val updatedLines = transfer.lines.map { it.copy(dispatchedQuantity = it.quantity) }
        val entity = updatedLines.let { lines ->
            transfer.copy(lines = lines, status = TransferStatus.DISPATCHED, dispatchChallanNumber = challan, dispatchedBy = currentUser.name, dispatchedAt = LocalDateTime.now(), vehicle = vehicle ?: transfer.vehicle, driver = driver ?: transfer.driver).toEntity()
        }
        db.warehouseTransferDao().upsert(entity)
        syncCollection("warehouseTransfers").document(transferId).set(entity)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push dispatch failed", it) }
        logAudit("WarehouseTransfer", transferId, "DISPATCH", newValue = "challan=$challan")
        activateQrFor("WarehouseTransfer", transferId)  // dispatched transfer carries a scannable tag
        return true
    }

    /**
     * Receiving — accepted quantity adds to destination stock (real
     * inventory IN movement); damaged/missing/excess are recorded but
     * don't silently become sellable stock. Partial receive keeps the
     * transfer open (PARTIALLY_RECEIVED); a full receive closes it
     * (RECEIVED). Section J reconciliation (dispatched = accepted +
     * damaged + missing + remaining in-transit) is always derivable from
     * these same line numbers at read time — never a separate,
     * potentially-stale stored value.
     */
    suspend fun receiveWarehouseTransfer(transferId: String, receivedLines: List<WarehouseTransferLine>, receiver: String, binLocation: String?, comment: String?, proofUri: String?): Boolean {
        if (!PermissionManager.canCurrentUser("stock", PermissionAction.EDIT)) {
            logAudit("WarehouseTransfer", transferId, "DENY", oldValue = currentUser.role.name, newValue = "RECEIVE")
            return false
        }
        val transfer = warehouseTransfers.value.firstOrNull { it.id == transferId } ?: return false
        if (transfer.status != TransferStatus.DISPATCHED && transfer.status != TransferStatus.PARTIALLY_RECEIVED) return false
        val inTransitWarehouseId = InventoryRepository.getOrCreateSystemWarehouse(StockCategory.IN_TRANSIT, currentUser.companyId)
        val damagedHoldWarehouseId = InventoryRepository.getOrCreateSystemWarehouse(StockCategory.DAMAGED_HOLD_RETURNED, currentUser.companyId)
        receivedLines.forEach { line ->
            if (line.acceptedQuantity > 0) {
                InventoryRepository.adjustStock(line.productId, transfer.destinationWarehouseId, line.acceptedQuantity, com.abm.erp.data.MovementType.IN, "Received transfer ${transfer.transferNumber}, batch ${line.batchCode ?: "N/A"}", batchCode = line.batchCode)
            }
            // Real In-Transit clearing — the goods have physically arrived (whether accepted, damaged, or missing), so they leave the tracked in-transit bucket either way.
            val arrivedQuantity = line.acceptedQuantity + line.damagedQuantity + line.missingQuantity
            if (arrivedQuantity > 0) {
                InventoryRepository.adjustStock(line.productId, inTransitWarehouseId, arrivedQuantity, com.abm.erp.data.MovementType.OUT, "Arrived (or written off) — transfer ${transfer.transferNumber}", batchCode = line.batchCode)
            }
            // Real Damaged/Hold/Returned bucket — damaged quantity was previously only a number on the line item, never a real tracked stock location.
            if (line.damagedQuantity > 0) {
                InventoryRepository.adjustStock(line.productId, damagedHoldWarehouseId, line.damagedQuantity, com.abm.erp.data.MovementType.IN, "Damaged on arrival — transfer ${transfer.transferNumber}", batchCode = line.batchCode)
            }
        }
        val receipt = WarehouseReceipt(
            id = "WR-${java.util.UUID.randomUUID().toString().take(8)}", transferId = transferId, companyId = currentUser.companyId,
            receivingWarehouseId = transfer.destinationWarehouseId, binLocation = binLocation, receiver = receiver, comment = comment, proofUri = proofUri,
        )
        db.warehouseReceiptDao().upsert(receipt.toEntity())
        syncCollection("warehouseReceipts").document(receipt.id).set(receipt.toEntity())
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push receipt failed", it) }
        val allReceived = receivedLines.all { it.acceptedQuantity + it.damagedQuantity + it.missingQuantity >= it.dispatchedQuantity - 0.01 }
        val newStatus = if (allReceived) TransferStatus.RECEIVED else TransferStatus.PARTIALLY_RECEIVED
        val updatedTransfer = transfer.copy(lines = receivedLines, status = newStatus)
        db.warehouseTransferDao().upsert(updatedTransfer.toEntity())
        syncCollection("warehouseTransfers").document(transferId).set(updatedTransfer.toEntity())
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push receive-status failed", it) }
        logAudit("WarehouseTransfer", transferId, "RECEIVE", newValue = receipt, reason = if (updatedTransfer.hasDiscrepancy) "DISCREPANCY DETECTED — missing/excess present" else null)
        return true
    }

    suspend fun createEmployeeDraft(
        fullName: String, mobile: String, email: String, department: String, designation: String, role: UserRole, companyId: String,
        nationalId: String? = null, dateOfBirth: java.time.LocalDate? = null, joiningDate: java.time.LocalDate? = null,
        territoryId: String? = null, directManagerId: String? = null, workLocation: String? = null,
        emergencyContactName: String? = null, emergencyContactPhone: String? = null, basePayMonthly: Double = 0.0,
    ): EmployeeProfile? {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.CREATE)) {
            logAudit("EmployeeProfile", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return null
        }
        // Section 13 fix — real privilege-escalation gap: the role picker
        // allowed selecting ANY role including CHAIRMAN/MD, and this
        // function accepted it from anyone with plain "hr" CREATE access
        // (which includes GM/AGM, not just Chairman/MD themselves). Only
        // an existing Chairman/MD may create another Chairman/MD-level
        // account — never auto-created/self-escalated by a lower role.
        if (role == UserRole.CHAIRMAN || role == UserRole.MD) {
            if (currentUser.role != UserRole.CHAIRMAN && currentUser.role != UserRole.MD) {
                logAudit("EmployeeProfile", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE_PRIVILEGED_ROLE_${role.name}")
                return null
            }
        }
        if (fullName.isBlank() || (mobile.isBlank() && email.isBlank())) {
            com.abm.erp.config.AppLog.w("MockRepository", "createEmployeeDraft rejected: name and at least one contact method required")
            return null
        }
        if (db.employeeProfileDao().countByContact(mobile, email) > 0) {
            com.abm.erp.config.AppLog.w("MockRepository", "createEmployeeDraft rejected: duplicate mobile/email")
            return null
        }
        // Phase 2 — National ID must also be checked for duplicates when provided.
        if (!nationalId.isNullOrBlank() && employeeProfiles.value.any { it.nationalId == nationalId && !it.isDeleted }) {
            com.abm.erp.config.AppLog.w("MockRepository", "createEmployeeDraft rejected: duplicate National ID")
            return null
        }
        // Practical ID format — ABM-{DEPT}-{ROLE}-{sequential}, e.g.
        // ABM-SALES-SR-0001. Sequential number is scoped to department+role
        // so different departments/roles don't compete for the same
        // counter, matching the given examples (ABM-SALES-SR-0001,
        // ABM-HR-OFC-0001, ABM-MFG-OPR-0001).
        val deptAbbrev = department.uppercase().take(4).ifBlank { "GEN" }
        val roleAbbrev = role.name.take(3)
        // Central Number Series Engine — replaces the locally-scoped counter with the one shared, mutex-guarded series.
        val code = generateNumber("EMPLOYEE", branchCode = "$deptAbbrev-$roleAbbrev")

        val employee = EmployeeProfile(
            id = "EMP-${java.util.UUID.randomUUID().toString().take(8)}", employeeCode = code, fullName = fullName,
            mobile = mobile, email = email, department = department, designation = designation, role = role,
            companyId = companyId, createdBy = currentUser.name, nationalId = nationalId, dateOfBirth = dateOfBirth,
            joiningDate = joiningDate, territoryId = territoryId, directManagerId = directManagerId, workLocation = workLocation,
            emergencyContactName = emergencyContactName, emergencyContactPhone = emergencyContactPhone, basePayMonthly = basePayMonthly,
        )
        val entity = employee.toEntity()
        db.employeeProfileDao().upsert(entity)
        trackRecordSync(entity.id, syncCollection("employeeProfiles").document(entity.id).set(entity)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push employeeProfile failed", it) })
        logAudit("EmployeeProfile", employee.id, "CREATE", newValue = employee)
        return employee
    }

    /** Draft -> Submitted (real duplicate re-check at submission time too, since contact details could've changed while editing the draft). */
    fun submitEmployeeForReview(employeeId: String): Boolean {
        val e = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return false
        if (e.onboardingStatus != EmployeeOnboardingStatus.DRAFT && e.onboardingStatus != EmployeeOnboardingStatus.REJECTED) return false
        scope.launch {
            db.employeeProfileDao().setOnboardingStatus(employeeId, "SUBMITTED", null)
            syncCollection("employeeProfiles").document(employeeId).update("onboardingStatus", "SUBMITTED")
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push employee-submit failed", it) }
            logAudit("EmployeeProfile", employeeId, "SUBMIT")
            createNotification(NotificationCategory.APPROVAL, "New Employee Submitted", "${e.fullName} — ${e.employeeCode}")
        }
        return true
    }

    /**
     * Advances one onboarding stage at a time (HR Review -> Manager Review
     * -> Role Assignment -> Territory Assignment -> Account Activation ->
     * Active), rather than jumping straight to Active — matches the exact
     * staged workflow the spec calls for, each stage independently
     * auditable. "No active access before approved activation" is enforced
     * by EmployeeProfile.hasActiveAccess, which only returns true once
     * onboardingStatus reaches ACTIVE.
     */
    fun advanceEmployeeOnboarding(employeeId: String): Boolean {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) {
            logAudit("EmployeeProfile", employeeId, "DENY", oldValue = currentUser.role.name, newValue = "ADVANCE_ONBOARDING")
            return false
        }
        val e = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return false
        val chain = listOf(
            EmployeeOnboardingStatus.SUBMITTED, EmployeeOnboardingStatus.HR_REVIEW, EmployeeOnboardingStatus.MANAGER_REVIEW,
            EmployeeOnboardingStatus.ROLE_ASSIGNMENT, EmployeeOnboardingStatus.TERRITORY_ASSIGNMENT,
            EmployeeOnboardingStatus.ACCOUNT_ACTIVATION, EmployeeOnboardingStatus.ACTIVE,
        )
        val currentIdx = chain.indexOf(e.onboardingStatus)
        if (currentIdx == -1 || currentIdx >= chain.size - 1) return false
        val nextStatus = chain[currentIdx + 1]
        scope.launch {
            db.employeeProfileDao().setOnboardingStatus(employeeId, nextStatus.name, null)
            syncCollection("employeeProfiles").document(employeeId).update("onboardingStatus", nextStatus.name)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push employee-advance failed", it) }
            logAudit("EmployeeProfile", employeeId, "ADVANCE_ONBOARDING", oldValue = e.onboardingStatus.name, newValue = nextStatus.name)
            if (nextStatus == EmployeeOnboardingStatus.ACTIVE) {
                db.employeeProfileDao().setStatus(employeeId, "ACTIVE", null)
                syncCollection("employeeProfiles").document(employeeId).update("status", "ACTIVE")
                createNotification(NotificationCategory.APPROVAL, "Employee Activated", "${e.fullName} is now active.")
            }
        }
        return true
    }

    fun rejectEmployeeOnboarding(employeeId: String, reason: String): Boolean {
        if (reason.isBlank()) return false
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) {
            logAudit("EmployeeProfile", employeeId, "DENY", oldValue = currentUser.role.name, newValue = "REJECT")
            return false
        }
        val e = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return false
        if (e.onboardingStatus == EmployeeOnboardingStatus.ACTIVE) return false
        scope.launch {
            db.employeeProfileDao().setOnboardingStatus(employeeId, "REJECTED", reason)
            syncCollection("employeeProfiles").document(employeeId).update(mapOf("onboardingStatus" to "REJECTED", "rejectReason" to reason))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push employee-reject failed", it) }
            logAudit("EmployeeProfile", employeeId, "REJECT", reason = reason)
            createNotification(NotificationCategory.APPROVAL, "Employee Onboarding Rejected", "${e.fullName}: $reason")
        }
        return true
    }

    /**
     * Foundation 2, Section 4 — Reporting Relationship Engine. Real
     * validation before any manager assignment: no self-reporting, no
     * circular chains (walks the FULL chain, not just one hop), manager
     * must be ACTIVE, manager must be same company. This is the function
     * every manager-assignment path (onboarding, transfer, promotion)
     * should route through — a single source of truth rather than
     * scattered ad-hoc checks.
     */
    fun validateManagerAssignment(employeeId: String, proposedManagerId: String): Pair<Boolean, String?> {
        if (employeeId == proposedManagerId) return false to "Employee cannot report to themselves"
        val manager = employeeProfiles.value.firstOrNull { it.id == proposedManagerId }
            ?: return false to "Proposed manager not found"
        if (manager.status != EmployeeStatus.ACTIVE && manager.status != EmployeeStatus.PROBATION && manager.status != EmployeeStatus.CONFIRMED) {
            return false to "Proposed manager is not active (${manager.status})"
        }
        val employee = employeeProfiles.value.firstOrNull { it.id == employeeId }
        if (employee != null && employee.companyId.isNotBlank() && manager.companyId.isNotBlank() && employee.companyId != manager.companyId) {
            return false to "Manager belongs to a different company"
        }
        var cursor: String? = proposedManagerId
        val seen = mutableSetOf<String>()
        var hops = 0
        while (cursor != null && hops < 50) {
            if (cursor == employeeId) return false to "This assignment would create a circular reporting chain"
            if (!seen.add(cursor)) break
            cursor = employeeProfiles.value.firstOrNull { it.id == cursor }?.directManagerId
            hops++
        }
        return true to null
    }

    fun assignDirectManager(employeeId: String, managerId: String): Boolean {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.EDIT)) {
            logAudit("EmployeeProfile", employeeId, "DENY", oldValue = currentUser.role.name, newValue = "ASSIGN_MANAGER")
            return false
        }
        val (valid, reason) = validateManagerAssignment(employeeId, managerId)
        if (!valid) {
            logAudit("EmployeeProfile", employeeId, "DENY", oldValue = managerId, newValue = "ASSIGN_MANAGER — $reason")
            return false
        }
        val e = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return false
        scope.launch {
            db.employeeProfileDao().setDirectManager(employeeId, managerId)
            syncCollection("employeeProfiles").document(employeeId).update("directManagerId", managerId)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push manager-assign failed", it) }
            logAudit("EmployeeProfile", employeeId, "MANAGER_CHANGE", oldValue = e.directManagerId ?: "(none)", newValue = managerId)
        }
        return true
    }

    /** Temporary/acting manager (Section 4 + 12) — effective-dated, rejects overlapping active temp assignments. */
    fun assignTemporaryManager(employeeId: String, managerId: String, from: LocalDate, to: LocalDate, reason: String): Boolean {
        if (reason.isBlank() || !to.isAfter(from)) return false
        val (valid, validationReason) = validateManagerAssignment(employeeId, managerId)
        if (!valid) {
            logAudit("EmployeeProfile", employeeId, "DENY", oldValue = managerId, newValue = "TEMP_MANAGER — $validationReason")
            return false
        }
        val e = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return false
        if (e.tempManagerId != null && e.tempAssignmentTo != null && !e.tempAssignmentTo.isBefore(LocalDate.now())) {
            logAudit("EmployeeProfile", employeeId, "DENY", oldValue = "existing temp assignment until ${e.tempAssignmentTo}", newValue = "TEMP_MANAGER — overlapping")
            return false
        }
        scope.launch {
            db.employeeProfileDao().setTempManager(employeeId, managerId, from.toEpochDay(), to.toEpochDay())
            syncCollection("employeeProfiles").document(employeeId)
                .update(mapOf("tempManagerId" to managerId, "tempAssignmentFromEpochDay" to from.toEpochDay(), "tempAssignmentToEpochDay" to to.toEpochDay()))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push temp-manager failed", it) }
            logAudit("EmployeeProfile", employeeId, "TEMP_MANAGER_ASSIGNED", newValue = "$managerId from $from to $to: $reason")
        }
        return true
    }

    /** The effective manager right now: temp manager if within its date window, else the direct manager (Section 4). */
    fun effectiveManagerId(employee: EmployeeProfile): String? {
        val today = LocalDate.now()
        if (employee.tempManagerId != null && employee.tempAssignmentFrom != null && employee.tempAssignmentTo != null &&
            !today.isBefore(employee.tempAssignmentFrom) && !today.isAfter(employee.tempAssignmentTo)
        ) {
            return employee.tempManagerId
        }
        return employee.directManagerId
    }

    /** Section 4 — full reporting-tree, built from actual stored directManagerId relationships (not hardcoded), for hierarchy visualization (Section 15). */
    data class HierarchyNode(val employee: EmployeeProfile, val children: List<HierarchyNode>)
    fun buildReportingTree(rootEmployeeId: String? = null): List<HierarchyNode> {
        val all = employeeProfiles.value.filter { !it.isDeleted }
        // Performance fix — was previously calling `all.filter { it.directManagerId == managerId }`
        // fresh on EVERY recursive call, making this O(n²) for a company
        // with n employees (each level re-scans the whole list). Grouping
        // once upfront makes each lookup O(1), so the whole tree build is O(n).
        val byManager: Map<String?, List<com.abm.erp.data.EmployeeProfile>> = all.groupBy { it.directManagerId }
        val visited = mutableSetOf<String>()
        fun childrenOf(managerId: String?): List<HierarchyNode> =
            byManager[managerId].orEmpty().mapNotNull { child ->
                if (!visited.add(child.id)) null else HierarchyNode(child, childrenOf(child.id)) // defense-in-depth against a stray circular chain
            }
        return if (rootEmployeeId != null) {
            val root = all.firstOrNull { it.id == rootEmployeeId } ?: return emptyList()
            visited.add(root.id)
            listOf(HierarchyNode(root, childrenOf(root.id)))
        } else {
            childrenOf(null)
        }
    }

    /** Section 21 — "Invalid hierarchy report": real detection of orphans, self-reporting, and broken manager references across the whole directory. */
    fun invalidHierarchyReport(): List<Pair<EmployeeProfile, String>> {
        val issues = mutableListOf<Pair<EmployeeProfile, String>>()
        employeeProfiles.value.filter { !it.isDeleted }.forEach { e ->
            if (e.directManagerId == e.id) { issues += e to "Reports to self"; return@forEach }
            if (e.directManagerId != null && employeeProfiles.value.none { it.id == e.directManagerId && !it.isDeleted }) {
                issues += e to "Manager ${e.directManagerId} does not exist or is deleted"
            }
            if (e.directManagerId == null && e.role != UserRole.MD && e.role != UserRole.CHAIRMAN) {
                issues += e to "No manager assigned (orphan)"
            }
        }
        return issues
    }

    // ============================================================
    // Foundation 2, Sections 6-8 — centralized Approval Authority
    // Matrix. Real, configurable per-employee limits (from
    // EmployeeProfile), not hardcoded role-name thresholds scattered
    // across modules. Every approval-limit check in the app should
    // route through these functions rather than re-implementing its
    // own ad-hoc role check.
    // ============================================================
    enum class ApprovalLimitType { FINANCIAL, CREDIT_OVERRIDE, DISCOUNT_PCT, STOCK_ADJUSTMENT, PURCHASE, LEAVE, ATTENDANCE_CORRECTION }

    fun approvalLimitFor(employeeId: String, type: ApprovalLimitType): Double {
        val e = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return 0.0
        return when (type) {
            ApprovalLimitType.FINANCIAL -> e.financialApprovalLimit
            ApprovalLimitType.CREDIT_OVERRIDE -> e.creditOverrideLimit
            ApprovalLimitType.DISCOUNT_PCT -> e.discountApprovalLimitPct
            ApprovalLimitType.STOCK_ADJUSTMENT -> e.stockAdjustmentApprovalLimit
            ApprovalLimitType.PURCHASE -> e.purchaseApprovalLimit
            ApprovalLimitType.LEAVE, ApprovalLimitType.ATTENDANCE_CORRECTION -> 0.0
        }
    }

    /**
     * The real approval check (Section 7-8): is this specific employee
     * authorized for this specific amount, and are they blocked from
     * approving because they created the transaction themselves (Section
     * 13 — segregation of duties)? If insufficient, points to the
     * escalation target rather than silently failing.
     */
    fun canApproveAmount(approverId: String, creatorId: String, type: ApprovalLimitType, amount: Double, requireSegregation: Boolean = true): Pair<Boolean, String?> {
        if (requireSegregation && approverId == creatorId) return false to "Creator cannot approve their own transaction (segregation of duties)"
        val approver = employeeProfiles.value.firstOrNull { it.id == approverId } ?: return false to "Approver not found"
        if (!approver.hasActiveAccess) return false to "Approver does not have active access (${approver.status}/${approver.onboardingStatus})"
        val limit = approvalLimitFor(approverId, type)
        if (limit >= amount) return true to null
        return false to "Amount ৳$amount exceeds ${approver.fullName}'s authority (limit ৳$limit) — needs escalation to ${approver.directManagerId ?: "a higher authority"}"
    }

    /** Real escalation chain (Section 8) — walks up direct managers until one has sufficient limit. */
    /**
     * Section 8 — nearest-available-supervisor resolver. Walks up the real
     * manager chain (directManagerId), skipping any vacant/inactive
     * position automatically (never silently approves just because a
     * position is vacant — it keeps escalating instead). Detects circular
     * manager relationships explicitly (not just bounded by a hop count —
     * a real visited-set, so a genuine cycle gets logged and reported,
     * not just silently truncated). Final fallback is an active
     * Chairman/MD — critical approvals must never dead-end with no
     * authority found at all.
     */
    fun findAuthorizedApprover(startEmployeeId: String, type: ApprovalLimitType, amount: Double): EmployeeProfile? {
        val visited = mutableSetOf<String>()
        var cursor: String? = startEmployeeId
        while (cursor != null) {
            if (!visited.add(cursor)) {
                android.util.Log.w("MockRepository", "findAuthorizedApprover: circular manager relationship detected in chain starting at $startEmployeeId (repeated id: $cursor) — falling back to Chairman/MD")
                break
            }
            val candidate = employeeProfiles.value.firstOrNull { it.id == cursor }
            if (candidate != null && candidate.hasActiveAccess && approvalLimitFor(candidate.id, type) >= amount) {
                logAudit("ApprovalPath", startEmployeeId, "RESOLVED", newValue = "escalated to ${candidate.id} (${candidate.role}) via chain: ${visited.joinToString(" -> ")}")
                return candidate
            }
            cursor = candidate?.directManagerId
        }
        // Final fallback — an active Chairman/MD, so a critical approval
        // never dead-ends just because the chain ran out or every position
        // above was vacant/inactive.
        val fallback = employeeProfiles.value.firstOrNull { it.hasActiveAccess && it.role in setOf(UserRole.CHAIRMAN, UserRole.MD) }
        if (fallback != null) {
            logAudit("ApprovalPath", startEmployeeId, "RESOLVED_FALLBACK", newValue = "no manager in chain had sufficient authority — escalated to Chairman/MD fallback ${fallback.id}")
        } else {
            logAudit("ApprovalPath", startEmployeeId, "UNRESOLVED", newValue = "no active Chairman/MD exists to fall back to — approval cannot be resolved")
        }
        return fallback
    }

    fun hasLeaveApprovalAuthority(employeeId: String): Boolean = employeeProfiles.value.firstOrNull { it.id == employeeId }?.leaveApprovalAuthority == true
    fun hasAttendanceCorrectionAuthority(employeeId: String): Boolean = employeeProfiles.value.firstOrNull { it.id == employeeId }?.attendanceCorrectionAuthority == true

    fun setApprovalLimits(employeeId: String, financial: Double, credit: Double, discountPct: Double, stock: Double, purchase: Double, leaveAuth: Boolean, attendanceAuth: Boolean, level: Int): Boolean {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) {
            logAudit("EmployeeProfile", employeeId, "DENY", oldValue = currentUser.role.name, newValue = "SET_APPROVAL_LIMITS")
            return false
        }
        // Section 13-adjacent fix — approval AUTHORITY is a form of
        // privilege even without a role-name change. Without this check
        // any "hr" approver (GM/AGM included) could grant a subordinate a
        // higher financial/credit/stock/purchase limit than the granter
        // themselves holds — a silent authority escalation. Chairman/MD
        // are exempt since they sit at the top of the chain already.
        if (currentUser.role != UserRole.CHAIRMAN && currentUser.role != UserRole.MD) {
            val granter = employeeProfiles.value.firstOrNull { it.id == currentUser.employeeId }
            if (granter != null && (financial > granter.financialApprovalLimit || credit > granter.creditOverrideLimit || stock > granter.stockAdjustmentApprovalLimit || purchase > granter.purchaseApprovalLimit || level > granter.approvalAuthorityLevel)) {
                logAudit("EmployeeProfile", employeeId, "DENY", oldValue = currentUser.role.name, newValue = "SET_APPROVAL_LIMITS_EXCEEDS_GRANTER")
                return false
            }
        }
        val e = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return false
        scope.launch {
            db.employeeProfileDao().setApprovalLimits(employeeId, financial, credit, discountPct, stock, purchase, leaveAuth, attendanceAuth, level)
            syncCollection("employeeProfiles").document(employeeId).update(
                mapOf(
                    "financialApprovalLimit" to financial, "creditOverrideLimit" to credit, "discountApprovalLimitPct" to discountPct,
                    "stockAdjustmentApprovalLimit" to stock, "purchaseApprovalLimit" to purchase, "leaveApprovalAuthority" to leaveAuth,
                    "attendanceCorrectionAuthority" to attendanceAuth, "approvalAuthorityLevel" to level,
                ),
            ).addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push approval-limits failed", it) }
            logAudit("EmployeeProfile", employeeId, "APPROVAL_LIMITS_CHANGED", oldValue = "financial ৳${e.financialApprovalLimit}", newValue = "financial ৳$financial, credit ৳$credit, discount ${discountPct}%, stock ৳$stock, purchase ৳$purchase")
        }
        return true
    }

    // ============================================================
    // Foundation 2, Section 10 — Employee Transfer Workflow. Staged,
    // just like Employee Onboarding: Draft -> HR Review -> Current
    // Manager Approval -> New Manager Approval -> effective date
    // reached -> assignment actually updated -> Completed. The live
    // EmployeeProfile fields are only touched at the final step, so
    // "historical transactions must remain unchanged" is naturally true
    // throughout the approval process.
    // ============================================================
    fun createTransferRequest(employeeId: String, transferType: String, fromValue: String, toValue: String, effectiveDate: LocalDate, reason: String, newManagerId: String? = null, retailerHandoverToEmployeeId: String? = null): TransferRequest? {
        if (reason.isBlank()) return null
        val e = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return null
        if (newManagerId != null) {
            val (valid, validationReason) = validateManagerAssignment(employeeId, newManagerId)
            if (!valid) { com.abm.erp.config.AppLog.w("MockRepository", "createTransferRequest rejected: $validationReason"); return null }
        }
        val request = TransferRequest(
            id = java.util.UUID.randomUUID().toString(), employeeId = employeeId, employeeName = e.fullName,
            transferType = transferType, fromValue = fromValue, toValue = toValue, newManagerId = newManagerId,
            effectiveDate = effectiveDate, reason = reason, retailerHandoverToEmployeeId = retailerHandoverToEmployeeId,
            createdBy = currentUser.name,
        )
        scope.launch {
            val entity = request.toEntity()
            db.transferRequestDao().upsert(entity)
            syncCollection("transferRequests").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push transferRequest failed", it) }
            logAudit("TransferRequest", request.id, "CREATE", newValue = request, reason = request.reason)
        }
        return request
    }

    /** Advances one stage (Draft->HR Review->Current Manager->New Manager->effective). On reaching the final stage, actually applies the assignment update and reassigns any pending approvals still routed to the old manager (Section 10: "pending approvals must be reassigned"). */
    fun advanceTransferStage(transferId: String): Boolean {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) {
            logAudit("TransferRequest", transferId, "DENY", oldValue = currentUser.role.name, newValue = "ADVANCE_TRANSFER")
            return false
        }
        val t = transferRequests.value.firstOrNull { it.id == transferId } ?: return false
        val chain = listOf(TransferStage.DRAFT, TransferStage.HR_REVIEW, TransferStage.CURRENT_MANAGER_APPROVAL, TransferStage.NEW_MANAGER_APPROVAL, TransferStage.EFFECTIVE_DATE_PENDING, TransferStage.COMPLETED)
        val idx = chain.indexOf(t.stage)
        if (idx == -1 || idx >= chain.size - 1) return false
        val nextStage = chain[idx + 1]
        scope.launch {
            db.transferRequestDao().setStage(transferId, nextStage.name, null)
            syncCollection("transferRequests").document(transferId).update("stage", nextStage.name)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push transfer-advance failed", it) }
            logAudit("TransferRequest", transferId, "ADVANCE", oldValue = t.stage.name, newValue = nextStage.name)
            if (nextStage == TransferStage.COMPLETED) {
                val current = employeeProfiles.value.firstOrNull { it.id == t.employeeId }
                if (current != null) {
                    when (t.transferType) {
                        "TERRITORY" -> db.employeeProfileDao().setAssignment(t.employeeId, t.toValue, current.routeId, current.branch, current.region, current.area)
                        "ROUTE" -> db.employeeProfileDao().setAssignment(t.employeeId, current.territoryId, t.toValue, current.branch, current.region, current.area)
                        "BRANCH" -> db.employeeProfileDao().setAssignment(t.employeeId, current.territoryId, current.routeId, t.toValue, current.region, current.area)
                    }
                }
                if (t.newManagerId != null) db.employeeProfileDao().setDirectManager(t.employeeId, t.newManagerId)
                // Reassign pending approvals still sitting with the old manager to the new one, rather than leaving them stranded.
                if (t.newManagerId != null) {
                    approvals.value.filter { it.status == ApprovalStatus.PENDING && it.assignedToEmployeeId == t.employeeId }.forEach { pending ->
                        db.approvalDao().setAssignedTo(pending.id, t.newManagerId)
                    }
                }
                logAudit("EmployeeProfile", t.employeeId, "TRANSFER_COMPLETED", newValue = "${t.transferType}: ${t.fromValue} -> ${t.toValue}")
                createNotification(NotificationCategory.APPROVAL, "Transfer Completed", "${t.employeeName}: ${t.transferType} to ${t.toValue}")
            }
        }
        return true
    }

    fun rejectTransfer(transferId: String, reason: String): Boolean {
        if (reason.isBlank()) return false
        scope.launch {
            db.transferRequestDao().setStage(transferId, "REJECTED", reason)
            syncCollection("transferRequests").document(transferId).update(mapOf("stage" to "REJECTED", "rejectReason" to reason))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push transfer-reject failed", it) }
            logAudit("TransferRequest", transferId, "REJECT", reason = reason)
        }
        return true
    }

    // ============================================================
    // Foundation 2, Section 11 — Employee Status Management. Status
    // changes real-affect access (via EmployeeProfile.hasActiveAccess),
    // not just a cosmetic label.
    // ============================================================

    /**
     * Phase 4 — generates an appraisal with REAL data computed from actual
     * ERP records for the given period (never placeholder numbers).
     * supervisorScore/hrScore are left null here — they must be entered
     * separately via [enterManualAppraisalScores], and finalScore/rating
     * are only computed once both are present.
     */
    suspend fun generateAppraisal(employeeId: String, periodStart: java.time.LocalDate, periodEnd: java.time.LocalDate, salesTarget: Double, collectionTarget: Double): EmployeeAppraisal? {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) {
            logAudit("EmployeeAppraisal", employeeId, "DENY", oldValue = currentUser.role.name, newValue = "GENERATE")
            return null
        }
        val emp = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return null
        val startMillis = periodStart.atStartOfDay(java.time.ZoneOffset.UTC).toInstant().toEpochMilli()
        val endMillis = periodEnd.plusDays(1).atStartOfDay(java.time.ZoneOffset.UTC).toInstant().toEpochMilli()

        // Real sales achievement — sum of this employee's invoices in the period (createdBy is a name, the only attribution field SalesInvoice actually has).
        val myInvoices = salesInvoices.value.filter { !it.isDeleted && it.createdBy == emp.fullName && it.createdAt.isAfter(periodStart.atStartOfDay()) && it.createdAt.isBefore(periodEnd.plusDays(1).atStartOfDay()) }
        val salesAchievement = myInvoices.sumOf { it.total }
        val returnCount = salesReturns.value.count { !it.isDeleted && it.createdBy == emp.fullName && it.createdAt.isAfter(periodStart.atStartOfDay()) && it.createdAt.isBefore(periodEnd.plusDays(1).atStartOfDay()) }
        val returnRatePct = if (myInvoices.isNotEmpty()) (returnCount.toDouble() / myInvoices.size) * 100 else 0.0

        // Real collection achievement — verified collections this employee recorded in the period.
        val collectionAchievement = partyCollections.value.filter { it.status == "VERIFIED" && it.collectedBy == emp.fullName }
            .filter { it.createdAt.isAfter(periodStart.atStartOfDay()) && it.createdAt.isBefore(periodEnd.plusDays(1).atStartOfDay()) }
            .sumOf { it.amount }

        // Real attendance — actual AttendanceRecord rows in the period.
        val attendanceRows = db.attendanceDao().getAllForEmployee(employeeId).first()
            .filter { it.dateEpochDay in periodStart.toEpochDay()..periodEnd.toEpochDay() }
        val presentDays = attendanceRows.count { it.checkedIn }
        val totalDays = (periodEnd.toEpochDay() - periodStart.toEpochDay() + 1).toInt()

        // Real visits — VisitLog rows for this employee, split by party type.
        val myVisits = visitLogs.value.filter { it.employeeId == employeeId && it.checkInAt.isAfter(periodStart.atStartOfDay()) && it.checkInAt.isBefore(periodEnd.plusDays(1).atStartOfDay()) }
        val dealerVisits = myVisits.count { it.partyType == PartyType.DEALER }
        val retailerVisits = myVisits.count { it.partyType == PartyType.RETAILER }

        // Real new acquisitions — dealers/retailers this employee is assigned to, created within the period.
        val newDealers = dealers.value.count { it.assignedEmployeeId == employeeId && it.createdAt.isAfter(periodStart.atStartOfDay()) && it.createdAt.isBefore(periodEnd.plusDays(1).atStartOfDay()) }
        val newRetailers = retailers.value.count { it.officerId == employeeId && it.createdAt.isAfter(periodStart.atStartOfDay()) && it.createdAt.isBefore(periodEnd.plusDays(1).atStartOfDay()) }

        // Real complaint count — complaints logged against this employee in the period.
        val complaintCount = customerComplaints.value.count { it.assignedEmployeeId == employeeId && it.createdAt.isAfter(periodStart.atStartOfDay()) && it.createdAt.isBefore(periodEnd.plusDays(1).atStartOfDay()) }

        val appraisal = EmployeeAppraisal(
            id = "APR-${java.util.UUID.randomUUID().toString().take(8)}", employeeId = employeeId, companyId = currentUser.companyId,
            periodStart = periodStart, periodEnd = periodEnd,
            salesTarget = salesTarget, salesAchievement = salesAchievement,
            collectionTarget = collectionTarget, collectionAchievement = collectionAchievement,
            attendancePresentDays = presentDays, attendanceTotalDays = totalDays,
            punctualityLateDays = attendanceRows.count { it.shiftType == "LATE" },
            dealerVisits = dealerVisits, retailerVisits = retailerVisits,
            newDealerAcquisition = newDealers, newRetailerAcquisition = newRetailers,
            returnRatePct = returnRatePct, complaintCount = complaintCount,
            generatedBy = currentUser.name,
        )
        val entity = appraisal.toEntity()
        db.employeeAppraisalDao().upsert(entity)
        trackRecordSync(entity.id, syncCollection("employeeAppraisals").document(entity.id).set(entity)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push appraisal failed", it) })
        logAudit("EmployeeAppraisal", appraisal.id, "GENERATE", newValue = appraisal)
        return appraisal
    }

    /** Phase 4 — manual scores are entered here, separately and explicitly, never auto-filled. finalScore/rating only compute once both are present. */
    fun enterManualAppraisalScores(appraisalId: String, supervisorScore: Double?, hrScore: Double?, managerComment: String?): Boolean {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) return false
        val a = employeeAppraisals.value.firstOrNull { it.id == appraisalId } ?: return false
        val finalSupervisor = supervisorScore ?: a.supervisorScore
        val finalHr = hrScore ?: a.hrScore
        val finalScore = if (finalSupervisor != null && finalHr != null) (finalSupervisor + finalHr) / 2 else null
        val rating = finalScore?.let {
            when {
                it >= 90 -> "Outstanding"; it >= 75 -> "Exceeds Expectations"; it >= 60 -> "Meets Expectations"
                it >= 40 -> "Needs Improvement"; else -> "Unsatisfactory"
            }
        }
        scope.launch {
            val entity = db.employeeAppraisalDao().getAll().first().firstOrNull { it.id == appraisalId } ?: return@launch
            val updated = entity.copy(supervisorScore = finalSupervisor, hrScore = finalHr, managerComment = managerComment ?: entity.managerComment, finalScore = finalScore, rating = rating)
            db.employeeAppraisalDao().upsert(updated)
            syncCollection("employeeAppraisals").document(appraisalId).set(updated)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push appraisal-score failed", it) }
            logAudit("EmployeeAppraisal", appraisalId, "SCORE_ENTERED", newValue = "supervisor=$finalSupervisor hr=$finalHr final=$finalScore")
        }
        return true
    }

    fun acknowledgeAppraisal(appraisalId: String): Boolean {
        val a = employeeAppraisals.value.firstOrNull { it.id == appraisalId } ?: return false
        if (a.employeeId != currentUser.employeeId) return false // only the employee themselves may acknowledge their own appraisal
        scope.launch {
            val entity = db.employeeAppraisalDao().getAll().first().firstOrNull { it.id == appraisalId } ?: return@launch
            val updated = entity.copy(employeeAcknowledged = true, employeeAcknowledgedAtEpochMillis = System.currentTimeMillis())
            db.employeeAppraisalDao().upsert(updated)
            syncCollection("employeeAppraisals").document(appraisalId).set(updated)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push appraisal-ack failed", it) }
            logAudit("EmployeeAppraisal", appraisalId, "ACKNOWLEDGE")
        }
        return true
    }

    fun setEmployeeStatus(employeeId: String, status: EmployeeStatus, reason: String): Boolean {
        if (reason.isBlank()) return false
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) {
            logAudit("EmployeeProfile", employeeId, "DENY", oldValue = currentUser.role.name, newValue = "STATUS_CHANGE:$status")
            return false
        }
        val e = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return false
        // Section 13-adjacent fix — same class of gap as changeEmployeeRole/
        // account-control functions: a GM/AGM could otherwise set the
        // Chairman/MD's own status to TERMINATED/SUSPENDED/RESIGNED,
        // effectively locking out top leadership. Only a Chairman/MD may
        // change another Chairman/MD's status.
        if ((e.role == UserRole.CHAIRMAN || e.role == UserRole.MD) && currentUser.role != UserRole.CHAIRMAN && currentUser.role != UserRole.MD) {
            logAudit("EmployeeProfile", employeeId, "DENY", oldValue = currentUser.role.name, newValue = "STATUS_CHANGE_PRIVILEGED_${status.name}")
            return false
        }
        scope.launch {
            db.employeeProfileDao().setStatus(employeeId, status.name, reason)
            syncCollection("employeeProfiles").document(employeeId).update(mapOf("status" to status.name, "statusReason" to reason))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push employee-status failed", it) }
            logAudit("EmployeeProfile", employeeId, "STATUS_CHANGE", oldValue = e.status.name, newValue = status.name, reason = reason)
            if (status in setOf(EmployeeStatus.RESIGNED, EmployeeStatus.TERMINATED, EmployeeStatus.SUSPENDED)) {
                createNotification(NotificationCategory.APPROVAL, "Employee ${status.name}", "${e.fullName}: $reason")
            }
        }
        return true
    }

    // ============================================================
    // Foundation 2, Section 12 — Delegation. Real, bounded, auto-expiring.
    // ============================================================
    fun createDelegation(delegatorId: String, delegateId: String, scope_: String, financialLimit: Double, startDate: LocalDate, endDate: LocalDate, reason: String): Delegation? {
        if (reason.isBlank() || !endDate.isAfter(startDate) || delegatorId == delegateId) return null
        val delegator = employeeProfiles.value.firstOrNull { it.id == delegatorId } ?: return null
        val delegate = employeeProfiles.value.firstOrNull { it.id == delegateId } ?: return null
        // "No authority beyond delegator's own limit" — cap, never exceed.
        val cappedLimit = financialLimit.coerceAtMost(delegator.financialApprovalLimit)
        val hasOverlap = delegations.value.any {
            it.delegatorId == delegatorId && it.isActive && !(endDate.isBefore(it.startDate) || startDate.isAfter(it.endDate))
        }
        if (hasOverlap) {
            com.abm.erp.config.AppLog.w("MockRepository", "createDelegation rejected: overlapping active delegation for $delegatorId")
            return null
        }
        val delegation = Delegation(
            id = java.util.UUID.randomUUID().toString(), delegatorId = delegatorId, delegatorName = delegator.fullName,
            delegateId = delegateId, delegateName = delegate.fullName, scope = scope_, financialLimit = cappedLimit,
            startDate = startDate, endDate = endDate, reason = reason, createdBy = currentUser.name,
        )
        scope.launch {
            val entity = delegation.toEntity()
            db.delegationDao().upsert(entity)
            syncCollection("delegations").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push delegation failed", it) }
            logAudit("Delegation", delegation.id, "CREATE", newValue = delegation, reason = delegation.reason)
            createNotification(NotificationCategory.APPROVAL, "Delegation Started", "${delegator.fullName} delegated $scope_ authority to ${delegate.fullName}")
        }
        return delegation
    }

    /** Real, effective-date-aware active-delegation lookup — auto-expires by date, no manual cleanup needed (Section 12: "Automatic expiry"). */
    fun activeDelegationFor(employeeId: String): Delegation? {
        val today = LocalDate.now()
        return delegations.value.firstOrNull { it.delegateId == employeeId && it.isActive && !today.isBefore(it.startDate) && !today.isAfter(it.endDate) }
    }

    fun revokeDelegation(delegationId: String): Boolean {
        scope.launch {
            db.delegationDao().deactivate(delegationId)
            syncCollection("delegations").document(delegationId).update("isActive", false)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push delegation-revoke failed", it) }
            logAudit("Delegation", delegationId, "REVOKE")
        }
        return true
    }

    // ============================================================
    // Foundation 2, Section 13 — Segregation of Duties.
    // ============================================================
    enum class SegregatedAction { COLLECTION_VERIFY, STOCK_ADJUSTMENT_APPROVE, VOUCHER_APPROVE_OR_REVERSE, PAYROLL_FINALIZE, LEAVE_APPROVE, ATTENDANCE_CORRECTION_APPROVE, PURCHASE_APPROVE }

    fun violatesSegregationOfDuties(action: SegregatedAction, creatorId: String, approverId: String): Boolean = creatorId == approverId

    /** Honest coverage report — what's actually enforced today, not aspirational. */
    fun segregationOfDutiesCoverage(): Map<SegregatedAction, Boolean> = mapOf(
        SegregatedAction.COLLECTION_VERIFY to true,
        SegregatedAction.STOCK_ADJUSTMENT_APPROVE to true,
        SegregatedAction.VOUCHER_APPROVE_OR_REVERSE to true,
        SegregatedAction.PAYROLL_FINALIZE to true, // v88 fix — finalizePayrollPreparation/canFinalizePayroll now exist and enforce this
        SegregatedAction.LEAVE_APPROVE to true,
        SegregatedAction.ATTENDANCE_CORRECTION_APPROVE to true,
        SegregatedAction.PURCHASE_APPROVE to true,
    )

    // ============================================================
    // Foundation 2, Section 5 — Data Visibility Scope. Real,
    // hierarchy-derived filtering, not UI-only hiding.
    // ============================================================
    fun visibleEmployeeIds(viewerEmployeeId: String): Set<String> {
        val viewer = employeeProfiles.value.firstOrNull { it.id == viewerEmployeeId } ?: return setOf(viewerEmployeeId)
        return when (viewer.dataAccessScope) {
            "COMPANY" -> employeeProfiles.value.filter { it.companyId == viewer.companyId || viewer.companyId.isBlank() }.map { it.id }.toSet()
            "REGION" -> employeeProfiles.value.filter { it.region == viewer.region }.map { it.id }.toSet() + viewerEmployeeId
            "AREA" -> employeeProfiles.value.filter { it.area == viewer.area }.map { it.id }.toSet() + viewerEmployeeId
            "TERRITORY" -> subordinateIdsRecursive(viewerEmployeeId) + viewerEmployeeId
            else -> setOf(viewerEmployeeId)
        }
    }

    fun subordinateIdsRecursive(managerId: String, visited: MutableSet<String> = mutableSetOf()): Set<String> {
        if (!visited.add(managerId)) return emptySet() // defense-in-depth: if a cycle ever slipped through validateManagerAssignment, don't stack-overflow
        val direct = employeeProfiles.value.filter { it.directManagerId == managerId }.map { it.id }
        return direct.toSet() + direct.flatMap { subordinateIdsRecursive(it, visited) }
    }

    /** Section 5 — real retailer-visibility scoping, reusing Foundation 1's Retailer.officerId. */
    fun visibleRetailerIds(viewerEmployeeId: String): Set<String> {
        val employeeIds = visibleEmployeeIds(viewerEmployeeId)
        return retailers.value.filter { !it.isDeleted && it.officerId in employeeIds }.map { it.id }.toSet()
    }

    /** Dealer & Retailer Security — same hierarchy-based territory scoping as visibleRetailerIds, using Dealer.assignedEmployeeId. */
    fun visibleDealerIds(viewerEmployeeId: String): Set<String> {
        val employeeIds = visibleEmployeeIds(viewerEmployeeId)
        return dealers.value.filter { !it.isDeleted && it.assignedEmployeeId in employeeIds }.map { it.id }.toSet()
    }

    // ============================================================
    // Decision 4 (v113-73) — ONE cascade accessor, so scoping cannot be
    // forgotten screen-by-screen again.
    //
    // `visibleDealerIds`/`visibleRetailerIds` above answer "which ids may this
    // viewer see". The three functions below are the *list* form every screen
    // should use, and they encode the full three-branch rule that was
    // previously copy-pasted inline in DealersScreen and simply missing in
    // DealerInvoiceScreen and SalesChainScreen's DealerInvoiceTab:
    //
    //   1. viewer has a real EmployeeProfile  → hierarchy scope (visible*Ids)
    //   2. no profile yet, but SR/TSM         → only their own assigned records
    //   3. anything else (Chairman/MD/admin)  → unrestricted
    //
    // Branch 2 exists because a freshly-created login can have no
    // EmployeeProfile row yet; without it an SR would fall through to branch 3
    // and see the whole company. That fallback is copied verbatim from the
    // DealersScreen implementation — it is not new behaviour.
    //
    // Lists are passed in rather than read from `.value` here so Compose call
    // sites stay reactive and can wrap the result in `remember(...)`.
    // See core/CascadeScope.kt for the composable wrappers.
    // ============================================================
    fun visibleDealersFor(all: List<Dealer>, profiles: List<EmployeeProfile>): List<Dealer> {
        val me = currentUser
        val profile = profiles.firstOrNull { it.userAccountId == me.id }
        return when {
            profile != null -> {
                val visibleIds = visibleDealerIds(profile.id)
                all.filter { it.id in visibleIds }
            }
            me.role == UserRole.SR || me.role == UserRole.TSM -> all.filter { it.assignedEmployeeId == me.id }
            else -> all
        }
    }

    fun visibleRetailersFor(all: List<Retailer>, profiles: List<EmployeeProfile>): List<Retailer> {
        val me = currentUser
        val profile = profiles.firstOrNull { it.userAccountId == me.id }
        return when {
            profile != null -> {
                val visibleIds = visibleRetailerIds(profile.id)
                all.filter { it.id in visibleIds }
            }
            me.role == UserRole.SR || me.role == UserRole.TSM -> all.filter { it.officerId == me.id }
            else -> all
        }
    }

    fun visibleEmployeeProfilesFor(profiles: List<EmployeeProfile>): List<EmployeeProfile> {
        val me = currentUser
        val profile = profiles.firstOrNull { it.userAccountId == me.id } ?: return profiles
        val visibleIds = visibleEmployeeIds(profile.id)
        return profiles.filter { it.id in visibleIds }
    }

    // ============================================================
    // Foundation 2, Section 16 — Employee Performance Integration.
    // Real data pulled from actual linked records via this employee's
    // real id — not hardcoded dashboard values like the synthetic
    // EMPLOYEE_DIRECTORY.target.
    // ============================================================
    data class EmployeePerformance(
        val retailerCoverage: Int, val salesValue90Days: Double, val collectionValue90Days: Double,
        val collectionEfficiencyPct: Double, val visitCompliancePct: Double, val inactiveRetailerCount: Int,
        val newRetailersThisMonth: Int,
    )


    suspend fun computeEmployeePerformance(employeeId: String): EmployeePerformance {
        val now = LocalDateTime.now()
        val myRetailers = retailers.value.filter { !it.isDeleted && it.officerId == employeeId }
        val myRetailerIds = myRetailers.map { it.id }.toSet()
        val ledgerAll = db.partyLedgerDao().getAll().first()
        val myLedger = ledgerAll.filter { it.partyType == PartyType.RETAILER.name && it.partyId in myRetailerIds }
        val sales90 = myLedger.filter { it.type == "DEBIT" && LocalDateTime.ofInstant(Instant.ofEpochMilli(it.createdAtEpochMillis), ZoneOffset.UTC).isAfter(now.minusDays(90)) }.sumOf { it.amount }
        val collections90 = myLedger.filter { it.type == "CREDIT" && LocalDateTime.ofInstant(Instant.ofEpochMilli(it.createdAtEpochMillis), ZoneOffset.UTC).isAfter(now.minusDays(90)) }.sumOf { it.amount }
        val efficiency = if (sales90 + collections90 <= 0) 100.0 else (collections90 / (sales90 + collections90) * 100).coerceIn(0.0, 100.0)
        val myVisits = visitLogs.value.filter { it.employeeId == employeeId && it.checkInAt.isAfter(now.minusDays(30)) }
        val visitedRetailerIds = myVisits.map { it.partyId }.toSet()
        val compliance = if (myRetailers.isEmpty()) 0.0 else (visitedRetailerIds.count { it in myRetailerIds }.toDouble() / myRetailers.size * 100).coerceIn(0.0, 100.0)
        val inactive = myRetailers.count { it.lastVisitDate == null || java.time.Duration.between(it.lastVisitDate, now).toDays() > 30 }
        val newThisMonth = myRetailers.count { it.createdAt.month == now.month && it.createdAt.year == now.year }
        return EmployeePerformance(
            retailerCoverage = myRetailers.size, salesValue90Days = sales90, collectionValue90Days = collections90,
            collectionEfficiencyPct = efficiency, visitCompliancePct = compliance, inactiveRetailerCount = inactive,
            newRetailersThisMonth = newThisMonth,
        )
    }

    // ============================================================
    // Foundation 2, Section 17 — Notifications and Escalation,
    // employee-hierarchy-specific triggers. Reuses the existing
    // createNotification/NotificationCategory infrastructure (no
    // parallel notification system).
    // ============================================================
    fun checkAndNotifyHierarchyIssues() {
        invalidHierarchyReport().forEach { (e, issue) ->
            createNotification(NotificationCategory.APPROVAL, "Invalid Reporting Chain", "${e.fullName}: $issue")
        }
        val soonToExpire = delegations.value.filter { it.isActive && !it.endDate.isBefore(LocalDate.now()) && it.endDate.isBefore(LocalDate.now().plusDays(3)) }
        soonToExpire.forEach { d ->
            createNotification(NotificationCategory.APPROVAL, "Delegation Expiring Soon", "${d.delegatorName} → ${d.delegateName}'s delegation ends ${d.endDate}")
        }
        employeeProfiles.value.filter { !it.isDeleted && it.territoryId == null && it.role != UserRole.MD && it.role != UserRole.CHAIRMAN && it.onboardingStatus == EmployeeOnboardingStatus.ACTIVE }
            .forEach { e -> createNotification(NotificationCategory.APPROVAL, "Missing Territory Assignment", "${e.fullName} has no territory assigned.") }
    }

    /**
     * v88 fix — critical gap: EmployeeProfile.userAccountId existed on the
     * model but NO function ever set it to a real value, meaning the link
     * between a logged-in user (currentUser.id) and a real EmployeeProfile
     * record could never actually be established.
     */
    fun linkEmployeeToUserAccount(employeeProfileId: String, userAccountId: String): Boolean {
        val e = employeeProfiles.value.firstOrNull { it.id == employeeProfileId } ?: return false
        // Self-linking (this employee's own phone number matches the currently logging-in user) never needs the HR-approve permission — it can't be a privilege escalation, since it only ever links a record to the phone number it already carries. Linking a DIFFERENT employee's record still requires HR-approve.
        val isSelfLink = e.mobile.isNotBlank() && e.mobile == currentUser.phone && userAccountId == currentUser.id
        if (!isSelfLink && !PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) {
            logAudit("EmployeeProfile", employeeProfileId, "DENY", oldValue = currentUser.role.name, newValue = "LINK_USER_ACCOUNT")
            return false
        }
        if (employeeProfiles.value.any { it.userAccountId == userAccountId && it.id != employeeProfileId }) {
            com.abm.erp.config.AppLog.w("MockRepository", "linkEmployeeToUserAccount rejected: this user account is already linked to a different employee")
            return false
        }
        scope.launch {
            db.employeeProfileDao().linkUserAccount(employeeProfileId, userAccountId)
            syncCollection("employeeProfiles").document(employeeProfileId).update("userAccountId", userAccountId)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push userAccountId-link failed", it) }
            logAudit("EmployeeProfile", employeeProfileId, "LINK_USER_ACCOUNT", oldValue = e.userAccountId ?: "(none)", newValue = userAccountId)
        }
        return true
    }

    /** The reverse lookup used everywhere else (Voucher approval, retailer visibility) — the real EmployeeProfile for whoever is currently logged in, if one has been linked. */
    fun currentEmployeeProfile(): EmployeeProfile? = employeeProfiles.value.firstOrNull { it.userAccountId == currentUser.id }

    /**
     * v88 fix — Payroll Finalize had NO approval workflow at all. Reuses
     * the existing ApprovalRequest system (no new entity) — the preparer
     * raises a finalize request; canFinalizePayroll enforces "payroll
     * preparer can't finalize their own prep" (Section 13).
     */
    fun finalizePayrollPreparation(periodLabel: String, preparerId: String, totalAmount: Double): Boolean {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.CREATE)) {
            logAudit("Payroll", periodLabel, "DENY", oldValue = currentUser.role.name, newValue = "PREPARE")
            return false
        }
        raiseApprovalRequest(ApprovalType.OTHER, "Payroll $periodLabel prepared — ৳${"%,.0f".format(totalAmount)}, needs finalization approval", "Payroll", periodLabel)
        logAudit("Payroll", periodLabel, "PREPARED", newValue = "৳$totalAmount", reason = "prepared by $preparerId")
        return true
    }

    /** The segregation-of-duties gate — call before letting anyone approve a payroll finalize request. */
    fun canFinalizePayroll(approverId: String, preparerId: String): Pair<Boolean, String?> {
        if (violatesSegregationOfDuties(SegregatedAction.PAYROLL_FINALIZE, preparerId, approverId)) {
            return false to "Payroll preparer cannot finalize their own payroll run (segregation of duties)"
        }
        return true to null
    }

    /**
     * v88 fix — checklist item 5 ("Assign role"): the setRole DAO method
     * existed but nothing ever called it, meaning role changes/promotions
     * had no real path at all (only designation-label text could be
     * edited via createEmployeeDraft's initial value, never updated
     * afterward). Real, audited, and — for a promotion specifically —
     * distinct from a demotion in the audit trail per Section 10's list
     * of transfer types.
     */
    fun changeEmployeeRole(employeeId: String, newRole: UserRole, newDesignation: String, reason: String): Boolean {
        if (reason.isBlank()) return false
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) {
            logAudit("EmployeeProfile", employeeId, "DENY", oldValue = currentUser.role.name, newValue = "CHANGE_ROLE")
            return false
        }
        // Section 13 fix — same privilege-escalation gap as createEmployeeDraft:
        // promoting anyone TO Chairman/MD must itself require an existing
        // Chairman/MD, not just generic "hr" approve access (which GM/AGM
        // already have).
        if ((newRole == UserRole.CHAIRMAN || newRole == UserRole.MD) && currentUser.role != UserRole.CHAIRMAN && currentUser.role != UserRole.MD) {
            logAudit("EmployeeProfile", employeeId, "DENY", oldValue = currentUser.role.name, newValue = "CHANGE_ROLE_TO_PRIVILEGED_${newRole.name}")
            return false
        }
        val e = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return false
        val isPromotion = ROLE_ORDER.indexOf(newRole) > ROLE_ORDER.indexOf(e.role)
        scope.launch {
            db.employeeProfileDao().setRole(employeeId, newRole.name, newDesignation)
            syncCollection("employeeProfiles").document(employeeId).update(mapOf("role" to newRole.name, "designation" to newDesignation))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push role-change failed", it) }
            logAudit("EmployeeProfile", employeeId, if (isPromotion) "PROMOTION" else "DEMOTION", oldValue = "${e.role}/${e.designation}", newValue = "$newRole/$newDesignation", reason = reason)
            createNotification(NotificationCategory.APPROVAL, if (isPromotion) "Promotion" else "Role Change", "${e.fullName}: ${e.role} → $newRole")
        }
        return true
    }

    /**
     * Foundation 3, Section 1-2 — real retailer location update. "Do not
     * overwrite retailer location silently. Every location change must
     * create history." The updateLocation/setLocationVerification DAO
     * methods already existed from a prior pass; this is the missing
     * orchestration that actually preserves the previous coordinate into
     * retailer_location_history before overwriting, and sets the new
     * capture to PENDING_VERIFICATION rather than silently trusting it.
     */
    fun updateRetailerLocation(
        retailerId: String, lat: Double, lng: Double, accuracyMeters: Double?, provider: String?,
        deviceId: String?, captureMethod: String, reason: String,
    ): Boolean {
        if (!LocationVerification.isValidCoordinate(lat, lng)) {
            com.abm.erp.config.AppLog.w("MockRepository", "updateRetailerLocation rejected: invalid coordinate")
            return false
        }
        if (reason.isBlank()) return false
        val r = retailers.value.firstOrNull { it.id == retailerId } ?: return false
        val distanceFromPrevious = if (r.lat != null && r.lng != null) LocationVerification.distanceMeters(r.lat, r.lng, lat, lng) else null
        scope.launch {
            val historyEntry = com.abm.erp.data.room.RetailerLocationHistoryEntity(
                id = java.util.UUID.randomUUID().toString(), retailerId = retailerId,
                previousLat = r.lat, previousLng = r.lng, previousAccuracyMeters = r.gpsAccuracyMeters,
                newLat = lat, newLng = lng, newAccuracyMeters = accuracyMeters,
                changeReason = reason, changedBy = currentUser.name, changedAtEpochMillis = System.currentTimeMillis(),
                distanceFromPreviousMeters = distanceFromPrevious, revisionNumber = r.locationRevision + 1,
            )
            db.retailerLocationHistoryDao().upsert(historyEntry)
            syncCollection("retailerLocationHistory").document(historyEntry.id).set(historyEntry)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push location-history failed", it) }
            val nowMillis = System.currentTimeMillis()
            db.retailerDao().updateLocation(retailerId, lat, lng, accuracyMeters, nowMillis, provider, currentUser.employeeId, deviceId, captureMethod, "PENDING_VERIFICATION", reason)
            syncCollection("retailers").document(retailerId).update(
                mapOf(
                    "lat" to lat, "lng" to lng, "gpsAccuracyMeters" to accuracyMeters, "geoCapturedAtEpochMillis" to nowMillis,
                    "locationProvider" to provider, "locationCapturedByEmployeeId" to currentUser.employeeId, "locationCapturedDeviceId" to deviceId,
                    "locationCaptureMethod" to captureMethod, "locationVerificationStatus" to "PENDING_VERIFICATION",
                    "lastLocationUpdateReason" to reason, "locationRevision" to r.locationRevision + 1,
                ),
            ).addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push retailer-location-update failed", it) }
            logAudit("Retailer", retailerId, "LOCATION_UPDATE", oldValue = "${r.lat},${r.lng}", newValue = "$lat,$lng", reason = reason)
            if (distanceFromPrevious != null && distanceFromPrevious > 500) {
                raiseLocationAlert("RETAILER_LOCATION_CHANGED", currentUser.employeeId, retailerId, "${r.name}: location moved ${LocationVerification.formatDistance(distanceFromPrevious)} — needs manager verification", severity = "WARNING")
            }
        }
        return true
    }

    /** Section 20 — manager review action: Verify/Reject/Request Recapture/Accept with Warning. */
    fun verifyRetailerLocation(retailerId: String, decision: String, comment: String?, score: Int? = null): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            logAudit("Retailer", retailerId, "DENY", oldValue = currentUser.role.name, newValue = "VERIFY_LOCATION")
            return false
        }
        val r = retailers.value.firstOrNull { it.id == retailerId } ?: return false
        scope.launch {
            val nowMillis = System.currentTimeMillis()
            db.retailerDao().setLocationVerification(retailerId, decision, score, currentUser.name, nowMillis, comment)
            syncCollection("retailers").document(retailerId).update(
                mapOf("locationVerificationStatus" to decision, "locationVerificationScore" to score, "locationVerifiedBy" to currentUser.name, "locationVerifiedAtEpochMillis" to nowMillis, "locationVerificationComment" to comment),
            ).addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push location-verify failed", it) }
            logAudit("Retailer", retailerId, "LOCATION_$decision", oldValue = r.locationVerificationStatus, newValue = decision, reason = comment)
        }
        return true
    }

    fun retailerLocationHistoryFor(retailerId: String): Flow<List<com.abm.erp.data.room.RetailerLocationHistoryEntity>> = db.retailerLocationHistoryDao().getForRetailer(retailerId)

    /**
     * Foundation 3, Section 16+19 — Employee Location Snapshot + Trusted
     * Device tracking. Real, not continuous/high-frequency (caller
     * decides when to call this — e.g. on visit check-in, not a
     * background timer), matching Section 16's explicit "avoid continuous
     * high-frequency tracking" instruction.
     */
    fun recordEmployeeLocationSnapshot(
        lat: Double, lng: Double, accuracyMeters: Float?, provider: String?, batteryPct: Int?,
        mockSuspected: Boolean, deviceId: String?, visitId: String? = null, routeId: String? = null,
    ): Boolean {
        if (!LocationVerification.isValidCoordinate(lat, lng)) return false
        val snapshot = com.abm.erp.data.room.EmployeeLocationSnapshotEntity(
            id = java.util.UUID.randomUUID().toString(), employeeId = currentUser.employeeId, employeeName = currentUser.name,
            lat = lat, lng = lng, accuracyMeters = accuracyMeters, provider = provider, batteryPct = batteryPct,
            mockSuspected = mockSuspected, deviceId = deviceId, visitId = visitId, routeId = routeId,
            capturedAtEpochMillis = System.currentTimeMillis(), syncStatus = "PENDING",
        )
        scope.launch {
            // v89 fix, Section 18 — syncStatus was unconditionally written
            // as "SYNCED" regardless of whether the Firestore push actually
            // succeeded, which is exactly the silent-offline-data-loss risk
            // Section 18 warns against. Now genuinely PENDING until the
            // write confirms, and explicitly FAILED (not silently SYNCED)
            // if it doesn't — pendingSync() lets a future retry pass find
            // these honestly.
            db.employeeLocationSnapshotDao().upsert(snapshot)
            syncCollection("employeeLocationSnapshots").document(snapshot.id).set(snapshot)
                .addOnSuccessListener {
                    scope.launch {
                        db.employeeLocationSnapshotDao().setSyncStatus(snapshot.id, "SYNCED")
                        retryPendingLocationSnapshotSync() // piggyback: we're clearly online now, flush any backlog too
                    }
                }
                .addOnFailureListener {
                    com.abm.erp.config.AppLog.w("MockRepository", "push location-snapshot failed", it)
                    scope.launch { db.employeeLocationSnapshotDao().setSyncStatus(snapshot.id, "FAILED") }
                }
            if (deviceId != null) touchOrRegisterTrustedDevice(deviceId, mockSuspected)
            if (mockSuspected) raiseLocationAlert("MOCK_LOCATION_SUSPECTED", currentUser.employeeId, null, "${currentUser.name}'s location snapshot flagged mock provider")
        }
        return true
    }

    /** Section 18 — real retry pass for snapshots that never confirmed sync (offline capture, or a failed push). Call this when connectivity is confirmed available, e.g. from NetworkStatus. */
    fun retryPendingLocationSnapshotSync() {
        scope.launch {
            db.employeeLocationSnapshotDao().pendingSync().forEach { entity ->
                syncCollection("employeeLocationSnapshots").document(entity.id).set(entity)
                    .addOnSuccessListener { scope.launch { db.employeeLocationSnapshotDao().setSyncStatus(entity.id, "SYNCED") } }
                    .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "retry push location-snapshot failed", it) }
            }
        }
    }

    /** Section 19 — real device-trust bookkeeping: first-seen/last-active/mock-suspicion-count, without building full device-management security (per the spec's explicit scope limit). */
    private fun touchOrRegisterTrustedDevice(deviceId: String, mockSuspected: Boolean) {
        scope.launch {
            val existing = db.trustedDeviceDao().find(deviceId, currentUser.employeeId)
            val now = System.currentTimeMillis()
            if (existing == null) {
                val device = com.abm.erp.data.room.TrustedDeviceEntity(
                    id = java.util.UUID.randomUUID().toString(), deviceId = deviceId, employeeId = currentUser.employeeId,
                    firstRegisteredAtEpochMillis = now, lastActiveAtEpochMillis = now, lastLocationAtEpochMillis = now,
                    osVersion = android.os.Build.VERSION.RELEASE ?: "", mockSuspicionCount = if (mockSuspected) 1 else 0,
                )
                db.trustedDeviceDao().upsert(device)
                syncCollection("trustedDevices").document(device.id).set(device)
                    .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push trusted-device failed", it) }
                logAudit("TrustedDevice", device.id, "REGISTER", newValue = "employee=${currentUser.employeeId} device=$deviceId os=${device.osVersion}")
            } else {
                db.trustedDeviceDao().touch(existing.id, now, now)
                if (mockSuspected) {
                    db.trustedDeviceDao().incrementMockSuspicion(existing.id)
                    logAudit("TrustedDevice", existing.id, "MOCK_LOCATION_SUSPECTED", oldValue = existing.mockSuspicionCount, newValue = existing.mockSuspicionCount + 1)
                }
            }
        }
    }

    /** Section 20 — manager review of a location alert: Verify/Reject/Escalate/Add Comment, real audit. */
    fun reviewLocationAlert(alertId: String, action: String, comment: String?): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            logAudit("LocationAlert", alertId, "DENY", oldValue = currentUser.role.name, newValue = "REVIEW")
            return false
        }
        scope.launch {
            val now = System.currentTimeMillis()
            db.locationAlertDao().review(alertId, currentUser.name, now, action, comment)
            syncCollection("locationAlerts").document(alertId).update(
                mapOf("isReviewed" to true, "reviewedBy" to currentUser.name, "reviewedAtEpochMillis" to now, "reviewAction" to action, "reviewComment" to comment),
            ).addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push alert-review failed", it) }
            logAudit("LocationAlert", alertId, "REVIEW_$action", reason = comment)
        }
        return true
    }

    lateinit var locationAlerts: StateFlow<List<com.abm.erp.data.room.LocationAlertEntity>>
        private set

    /**
     * Foundation 3, Section 12-14 — Order/Collection location
     * verification. Auto-detects the current employee's active visit
     * (activeVisitForEmployee already existed) rather than requiring
     * every order/collection creation call site to be rewritten to thread
     * a visitId through — lower-risk than modifying Sales/Collection
     * creation signatures directly, and "Do not alter accounting amounts.
     * Only add location evidence" is naturally satisfied since this never
     * touches the order/collection record itself, only the visit's link
     * fields.
     */
    suspend fun linkVisitToOrder(orderId: String): Boolean {
        val active = db.visitLogDao().activeVisitForEmployee(currentUser.employeeId) ?: return false
        scope.launch {
            db.visitLogDao().linkOrder(active.id, orderId)
            syncCollection("visitLogs").document(active.id).update("orderCreatedId", orderId)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push visit-order-link failed", it) }
            logAudit("Visit", active.id, "ORDER_LINKED", newValue = orderId)
        }
        return true
    }

    suspend fun linkVisitToCollection(collectionId: String): Boolean {
        val active = db.visitLogDao().activeVisitForEmployee(currentUser.employeeId) ?: return false
        scope.launch {
            db.visitLogDao().linkCollection(active.id, collectionId)
            syncCollection("visitLogs").document(active.id).update("collectionCreatedId", collectionId)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push visit-collection-link failed", it) }
            logAudit("Visit", active.id, "COLLECTION_LINKED", newValue = collectionId)
            // Section 14 — "Flag outside-radius collection" / "higher authorization for suspicious collection". Reuses the visit's own already-computed verification, since the collection is happening at the same location the visit already scored.
            if (active.verificationResult == "OUTSIDE_RADIUS" || active.checkInMockSuspected) {
                raiseLocationAlert("SUSPICIOUS_COLLECTION_LOCATION", currentUser.employeeId, active.partyId, "Collection $collectionId recorded during a ${active.verificationResult} visit", severity = "WARNING")
            }
        }
        return true
    }

    /** Section 12 — real linked-activity query for a visit, for the Profile screen's Visit History tab to show what was actually done, not just check-in/out times. */
    fun visitLinkedActivitySummary(visit: VisitLog): String {
        val parts = mutableListOf<String>()
        if (visit.orderCreatedId != null) parts += "Order created"
        if (visit.collectionCreatedId != null) parts += "Collection recorded"
        if (visit.complaintCreatedId != null) parts += "Complaint filed"
        return if (parts.isEmpty()) "No linked activity" else parts.joinToString(", ")
    }

    /** Section 11 — real retailer-specific visit-radius override. Null resets to the company default (retailerGeofenceRadius already handles the fallback). */
    fun setRetailerGeofenceRadius(retailerId: String, radiusMeters: Double?, reason: String): Boolean {
        if (reason.isBlank()) return false
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            logAudit("Retailer", retailerId, "DENY", oldValue = currentUser.role.name, newValue = "SET_GEOFENCE_RADIUS")
            return false
        }
        val r = retailers.value.firstOrNull { it.id == retailerId } ?: return false
        scope.launch {
            db.retailerDao().setGeofenceRadius(retailerId, radiusMeters)
            syncCollection("retailers").document(retailerId).update("geofenceRadiusMeters", radiusMeters)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push geofence-radius failed", it) }
            logAudit("Retailer", retailerId, "GEOFENCE_RADIUS_CHANGED", oldValue = "${r.geofenceRadiusMeters}", newValue = "$radiusMeters", reason = reason)
        }
        return true
    }

    // ============================================================
    // Foundation 4 — Territory Geo-lock & Access Security.
    // ============================================================
    lateinit var securityEvents: StateFlow<List<com.abm.erp.data.room.SecurityEventEntity>>
        private set
    lateinit var geoOverrides: StateFlow<List<com.abm.erp.data.room.GeoOverrideEntity>>
        private set
    lateinit var executiveExceptions: StateFlow<List<ExecutiveException>>
        private set
    lateinit var managementActions: StateFlow<List<ManagementAction>>
        private set
    lateinit var decisionQueryLogs: StateFlow<List<DecisionQueryLog>>
        private set

    /** Section 13 — "Avoid duplicate notifications." Records the event either way (evidence should never be lost), but only sends a notification if this employee+type combo hasn't already fired in the last 15 minutes. */
    fun raiseSecurityEvent(type: String, employeeId: String, employeeName: String, territoryId: String?, action: String, lat: Double?, lng: Double?, distanceMeters: Double?, message: String, severity: String = "WARNING") {
        scope.launch {
            val now = System.currentTimeMillis()
            val recentCount = db.securityEventDao().countRecentByType(employeeId, type, now - 15 * 60_000)
            val entity = com.abm.erp.data.room.SecurityEventEntity(
                id = java.util.UUID.randomUUID().toString(), type = type, severity = severity, employeeId = employeeId,
                employeeName = employeeName, territoryId = territoryId, action = action, lat = lat, lng = lng,
                distanceMeters = distanceMeters, message = message, createdAtEpochMillis = now,
            )
            db.securityEventDao().upsert(entity)
            syncCollection("securityEvents").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push securityEvent failed", it) }
            if (recentCount == 0) createNotification(NotificationCategory.APPROVAL, "Security Event: $type", message)
        }
    }

    /** Section 10 — Emergency Override. Every override requires reason+approver+expiry, never silent. */
    suspend fun createGeoOverride(employeeId: String, employeeName: String, actionType: String, reason: String, durationMinutes: Long = 60): Boolean {
        if (reason.isBlank()) return false
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            logAudit("GeoOverride", employeeId, "DENY", oldValue = currentUser.role.name, newValue = "CREATE_OVERRIDE")
            return false
        }
        // Section 18 — "Prevent duplicate override": refuse a new grant while an unexpired, unused one already exists for this exact employee+action.
        val existingActive = db.geoOverrideDao().findActive(employeeId, actionType, System.currentTimeMillis())
        if (existingActive != null) {
            logAudit("GeoOverride", employeeId, "DENY", oldValue = "active override already exists (expires ${existingActive.expiresAtEpochMillis})", newValue = "CREATE_OVERRIDE — duplicate")
            return false
        }
        val now = System.currentTimeMillis()
        val override = com.abm.erp.data.room.GeoOverrideEntity(
            id = java.util.UUID.randomUUID().toString(), employeeId = employeeId, employeeName = employeeName,
            actionType = actionType, reason = reason, approvedBy = currentUser.name,
            createdAtEpochMillis = now, expiresAtEpochMillis = now + durationMinutes * 60_000,
        )
        scope.launch {
            db.geoOverrideDao().upsert(override)
            syncCollection("geoOverrides").document(override.id).set(override)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push geoOverride failed", it) }
            logAudit("GeoOverride", override.id, "CREATE", newValue = override, reason = reason)
            createNotification(NotificationCategory.APPROVAL, "Emergency Override Granted", "$employeeName: $actionType for ${durationMinutes}min by ${currentUser.name}")
        }
        return true
    }

    /** Real active-override check (not expired, not already used) — Section 18: "Prevent expired override use", "duplicate override". */
    /**
     * v90 fix — createGeoOverride (UI) grants against EmployeeProfile.id,
     * but validateFieldAction is called with currentUser.employeeId (the
     * old synthetic-directory id) from check-in/attendance. Without
     * bridging, an override granted via the real UI would never match at
     * check time. Checks both id spaces — the given id directly, and (if
     * it's a currentUser.employeeId) whatever EmployeeProfile is linked to
     * that same login via userAccountId.
     */
    private suspend fun hasActiveOverride(employeeId: String, actionType: String): Boolean {
        val now = System.currentTimeMillis()
        var override = db.geoOverrideDao().findActive(employeeId, actionType, now)
        if (override == null) {
            val linkedProfile = employeeProfiles.value.firstOrNull { it.userAccountId == employeeId }
            if (linkedProfile != null) {
                override = db.geoOverrideDao().findActive(linkedProfile.id, actionType, now)
            }
        }
        val found = override ?: return false
        scope.launch { db.geoOverrideDao().markUsed(found.id, now) }
        return true
    }

    /**
     * Section 3-8 — the central "can this employee legally perform this
     * action HERE and NOW" evaluator. Every field operation (login,
     * attendance, visit, order, collection) should call this before
     * proceeding. Real audit on every decision (Section 16).
     */
    suspend fun validateFieldAction(employeeId: String, actionType: String, lat: Double?, lng: Double?, accuracyMeters: Float?, mockSuspected: Boolean): GeoLock.EvaluationResult {
        val employee = employeeProfiles.value.firstOrNull { it.id == employeeId }
        val territory = employee?.territoryId?.let { tid -> territories.value.firstOrNull { it.id == tid } }
        val isAssigned = employee?.territoryId != null
        val hasOverride = hasActiveOverride(employeeId, actionType)
        val result = GeoLock.evaluateAccess(
            lat, lng, accuracyMeters, mockSuspected,
            territory?.polygon?.takeIf { it.size >= 3 }, 50.0,
            isAssigned, hasOverride,
        )
        logAudit(
            "GeoLock", employeeId, "VALIDATE_$actionType",
            newValue = "${result.decision}: ${result.reasons.joinToString()}",
            reason = result.reasons.joinToString("; "),
        )
        if (result.decision == GeoLock.AccessDecision.BLOCKED) {
            raiseSecurityEvent(
                if (mockSuspected) "MOCK_LOCATION" else if (!isAssigned) "UNAUTHORIZED_TERRITORY" else "OUTSIDE_TERRITORY",
                employeeId, employee?.fullName ?: employeeId, territory?.id, actionType, lat, lng, null,
                "${employee?.fullName ?: employeeId}: $actionType blocked — ${result.reasons.joinToString()}", severity = "CRITICAL",
            )
        }
        return result
    }

    /** Section 12 — manager review of a security event. */
    fun reviewSecurityEvent(eventId: String, action: String, comment: String?): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) return false
        scope.launch {
            val now = System.currentTimeMillis()
            db.securityEventDao().review(eventId, currentUser.name, now, action, comment)
            syncCollection("securityEvents").document(eventId).update(
                mapOf("isReviewed" to true, "reviewedBy" to currentUser.name, "reviewedAtEpochMillis" to now, "reviewAction" to action, "reviewComment" to comment),
            ).addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push event-review failed", it) }
            logAudit("SecurityEvent", eventId, "REVIEW_$action", reason = comment)
        }
        return true
    }

    /** Section 6-7 — Order/Collection Enforcement: requires an active verified visit, reuses validateFieldAction. Office users bypass (Section 6: "Office users remain configurable"). */
    suspend fun canCreateFieldOrder(employeeId: String, retailerId: String): Pair<Boolean, String?> {
        val active = db.visitLogDao().activeVisitForEmployee(employeeId)
        if (active == null) return false to "No active visit — cannot create field order"
        if (active.partyId != retailerId) return false to "Active visit is for a different retailer"
        if (active.verificationResult == "MOCK_LOCATION_SUSPECTED" || active.verificationResult == "OUTSIDE_RADIUS") {
            return false to "Visit not verified: ${active.verificationResult}"
        }
        return true to null
    }

    suspend fun canRecordFieldCollection(employeeId: String, retailerId: String): Pair<Boolean, String?> = canCreateFieldOrder(employeeId, retailerId)

    /** Section 8 — Route Enforcement: detects visiting a retailer outside the employee's assigned route. */
    fun checkRouteCompliance(employeeId: String, retailerId: String): Boolean {
        val employee = employeeProfiles.value.firstOrNull { it.id == employeeId } ?: return true
        val retailer = retailers.value.firstOrNull { it.id == retailerId } ?: return true
        val compliant = employee.routeId == null || retailer.routeId == null || employee.routeId == retailer.routeId
        if (!compliant) {
            raiseSecurityEvent("ROUTE_DEVIATION", employeeId, employee.fullName, employee.territoryId, "VISIT", retailer.lat, retailer.lng, null, "${employee.fullName} visited ${retailer.name} outside assigned route", severity = "WARNING")
        }
        return compliant
    }

    // Section 17 — centralized settings (not hardcoded per-call). Real, in-memory defaults; a Settings-persistence entity would be the next step if these need to be admin-editable per company.
    data class GeoLockSettings(
        val enabled: Boolean = true, val loginValidation: Boolean = true, val attendanceValidation: Boolean = true,
        val visitValidation: Boolean = true, val orderValidation: Boolean = true, val collectionValidation: Boolean = true,
        val routeEnforcement: Boolean = true, val boundaryToleranceMeters: Double = 50.0, val overrideExpiryMinutes: Long = 60,
    )
    var geoLockSettings: GeoLockSettings = GeoLockSettings()
        private set
    fun updateGeoLockSettings(settings: GeoLockSettings): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) return false
        geoLockSettings = settings
        logAudit("GeoLockSettings", "global", "UPDATE", newValue = settings)
        return true
    }

    /**
     * Section 2, 18 — real polygon-setting, with the validation Section 18
     * explicitly requires ("Invalid polygon"). Without this function, the
     * entire polygon geofence system built into Territory/GeoLock was
     * unreachable — no territory could ever actually have a boundary.
     */
    fun setTerritoryPolygon(territoryId: String, points: List<Pair<Double, Double>>): Boolean {
        if (points.isNotEmpty() && points.size < 3) {
            com.abm.erp.config.AppLog.w("MockRepository", "setTerritoryPolygon rejected: fewer than 3 points is not a valid polygon")
            return false
        }
        if (points.any { (lat, lng) -> !LocationVerification.isValidCoordinate(lat, lng) }) {
            com.abm.erp.config.AppLog.w("MockRepository", "setTerritoryPolygon rejected: invalid coordinate in polygon")
            return false
        }
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            logAudit("Territory", territoryId, "DENY", oldValue = currentUser.role.name, newValue = "SET_POLYGON")
            return false
        }
        val t = territories.value.firstOrNull { it.id == territoryId } ?: return false
        val raw = points.joinToString(";") { "${it.first},${it.second}" }
        scope.launch {
            db.territoryDao().setPolygon(territoryId, raw)
            syncCollection("territories").document(territoryId).update(mapOf("polygonRaw" to raw, "polygonVersion" to t.polygonVersion + 1))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push territory-polygon failed", it) }
            logAudit("Territory", territoryId, "POLYGON_UPDATE", oldValue = "v${t.polygonVersion} (${t.polygon.size} pts)", newValue = "v${t.polygonVersion + 1} (${points.size} pts)")
        }
        return true
    }

    // ============================================================
    // Foundation 6 — Executive Command Center.
    // ============================================================

    /** Section 5, 32 — real dedup check (was already learned from Section 13 dedup pattern), prevents duplicate-exception spam for the same underlying issue. */
    suspend fun raiseExecutiveException(type: String, severity: String, source: String, message: String, impact: String = "", recommendedAction: String = "", responsiblePerson: String = "", territoryId: String? = null, dedupKey: String): Boolean {
        val existingActive = db.executiveExceptionDao().countActiveByDedupKey(dedupKey)
        if (existingActive > 0) return false // Section 32 — "Duplicate exception" prevention
        val now = System.currentTimeMillis()
        val exception = ExecutiveException(
            id = java.util.UUID.randomUUID().toString(), type = type, severity = severity, source = source,
            companyId = companies.firstOrNull()?.id ?: "", branch = "", territoryId = territoryId, responsiblePerson = responsiblePerson,
            message = message, impact = impact, recommendedAction = recommendedAction, dedupKey = dedupKey,
        )
        scope.launch {
            val entity = exception.toEntity()
            db.executiveExceptionDao().upsert(entity)
            syncCollection("executiveExceptions").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push executiveException failed", it) }
            logAudit("ExecutiveException", exception.id, "CREATE", newValue = exception)
            createNotification(NotificationCategory.APPROVAL, "Exception: $type", message)
        }
        return true
    }

    /** Section 5, 12 — manager review: Acknowledge/Assign/Resolve/Reject/Escalate. */
    fun updateExceptionStatus(exceptionId: String, status: String, reviewer: String? = null, note: String? = null): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) return false
        scope.launch {
            val now = System.currentTimeMillis()
            db.executiveExceptionDao().updateStatus(exceptionId, status, reviewer ?: currentUser.name, note, now)
            syncCollection("executiveExceptions").document(exceptionId).update(
                mapOf("status" to status, "assignedReviewer" to (reviewer ?: currentUser.name), "resolutionNote" to note, "updatedAtEpochMillis" to now),
            ).addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push exception-status failed", it) }
            logAudit("ExecutiveException", exceptionId, "STATUS_$status", reason = note)
        }
        return true
    }

    /** Section 24 — Management Action Tracker: turn an insight/exception into a tracked, assigned, audited action. */
    fun createManagementAction(title: String, sourceExceptionId: String?, assignedTo: String, priority: String, dueDate: LocalDate?, evidence: String = ""): Boolean {
        if (title.isBlank() || assignedTo.isBlank()) return false
        val action = ManagementAction(
            id = java.util.UUID.randomUUID().toString(), title = title, sourceExceptionId = sourceExceptionId,
            assignedTo = assignedTo, priority = priority, dueDate = dueDate, evidence = evidence, createdBy = currentUser.name,
        )
        scope.launch {
            val entity = action.toEntity()
            db.managementActionDao().upsert(entity)
            syncCollection("managementActions").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push managementAction failed", it) }
            logAudit("ManagementAction", action.id, "CREATE", newValue = action)
            createNotification(NotificationCategory.APPROVAL, "Action Assigned: $title", "Assigned to $assignedTo, due ${dueDate ?: "no deadline"}")
        }
        return true
    }

    fun updateManagementActionStatus(actionId: String, status: String, completionNote: String? = null): Boolean {
        scope.launch {
            db.managementActionDao().updateStatus(actionId, status, completionNote)
            syncCollection("managementActions").document(actionId).update(mapOf("status" to status, "completionNote" to completionNote))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push action-status failed", it) }
            logAudit("ManagementAction", actionId, "STATUS_$status", reason = completionNote)
        }
        return true
    }

    /** Section 17 — overdue-action escalation, reusing the existing notification system. */
    fun escalateOverdueManagementActions() {
        val today = LocalDate.now()
        managementActions.value.filter { it.status !in setOf("COMPLETED", "CANCELLED") && it.dueDate != null && it.dueDate.isBefore(today) }
            .forEach { a ->
                updateManagementActionStatus(a.id, "OVERDUE")
                createNotification(NotificationCategory.APPROVAL, "Overdue Action: ${a.title}", "Assigned to ${a.assignedTo}, was due ${a.dueDate}")
            }
    }

    // ============================================================
    // Foundation 6, Section 2 — centralized Executive KPI Engine.
    // Real data only, computed here once — dashboards call these
    // rather than each computing their own totals.
    // ============================================================
    data class SalesKpi(val today: Double, val yesterday: Double, val thisWeek: Double, val thisMonth: Double, val lastMonth: Double, val trend: ExecutiveIntelligence.TrendResult)
    fun computeSalesKpi(): SalesKpi {
        val now = LocalDateTime.now()
        val invoices = salesInvoices.value.filter { !it.isDeleted }
        fun sumSince(days: Long) = invoices.filter { it.createdAt.isAfter(now.minusDays(days)) }.sumOf { it.lineItems.sumOf { li -> li.lineTotal } }
        fun sumBetween(fromDays: Long, toDays: Long) = invoices.filter { it.createdAt.isAfter(now.minusDays(fromDays)) && it.createdAt.isBefore(now.minusDays(toDays)) }.sumOf { it.lineItems.sumOf { li -> li.lineTotal } }
        val today = sumSince(1)
        val yesterday = sumBetween(2, 1)
        val thisWeek = sumSince(7)
        val thisMonth = sumSince(30)
        val lastMonth = sumBetween(60, 30)
        return SalesKpi(today, yesterday, thisWeek, thisMonth, lastMonth, ExecutiveIntelligence.computeTrend(thisMonth, lastMonth))
    }

    data class CollectionKpi(val today: Double, val thisWeek: Double, val thisMonth: Double, val outstandingDue: Double, val efficiencyPct: Double)
    fun computeCollectionKpi(): CollectionKpi {
        val now = LocalDateTime.now()
        val collections = partyCollections.value.filter { it.status == "VERIFIED" }
        fun sumSince(days: Long) = collections.filter { it.createdAt.isAfter(now.minusDays(days)) }.sumOf { it.amount }
        val totalDue = dealers.value.filter { !it.isDeleted }.sumOf { it.dueBalance } + retailers.value.filter { !it.isDeleted }.sumOf { it.dueBalance }
        val sales90 = salesInvoices.value.filter { !it.isDeleted && it.createdAt.isAfter(now.minusDays(90)) }.sumOf { it.lineItems.sumOf { li -> li.lineTotal } }
        val collected90 = sumSince(90)
        val efficiency = if (sales90 + collected90 <= 0) 100.0 else (collected90 / (sales90 + collected90) * 100).coerceIn(0.0, 100.0)
        return CollectionKpi(sumSince(1), sumSince(7), sumSince(30), totalDue, efficiency)
    }

    data class RetailerKpi(val totalActive: Int, val newThisMonth: Int, val inactive: Int, val noOrder: Int, val noVisit: Int)
    fun computeRetailerKpi(): RetailerKpi {
        val now = LocalDateTime.now()
        val live = retailers.value.filter { !it.isDeleted }
        return RetailerKpi(
            totalActive = live.count { it.businessStatus == "ACTIVE" },
            newThisMonth = live.count { it.createdAt.isAfter(now.minusDays(30)) },
            inactive = live.count { it.lastOrderDate == null || java.time.Duration.between(it.lastOrderDate, now).toDays() > 60 },
            noOrder = live.count { it.lastOrderDate == null },
            noVisit = live.count { it.lastVisitDate == null },
        )
    }

    data class EmployeeKpi(val active: Int, val presentToday: Int, val onLeave: Int, val geoViolationsToday: Int)
    suspend fun computeEmployeeKpi(): EmployeeKpi {
        val today = LocalDate.now().toEpochDay()
        val activeEmployees = employeeProfiles.value.count { it.hasActiveAccess }
        val presentToday = db.attendanceDao().countPresentForDay(today)
        val onLeave = leaveRequests.value.count { it.status == LeaveStatus.APPROVED && !LocalDate.now().isBefore(it.fromDate) && !LocalDate.now().isAfter(it.toDate) }
        val geoViolations = securityEvents.value.count { it.createdAtEpochMillis > System.currentTimeMillis() - 86400_000 && it.severity == "CRITICAL" }
        return EmployeeKpi(activeEmployees, presentToday, onLeave, geoViolations)
    }

    data class ApprovalKpi(val pending: Int, val overdue: Int, val highValue: Int)
    fun computeApprovalKpi(): ApprovalKpi {
        val pending = approvals.value.filter { it.status == ApprovalStatus.PENDING }
        val overdue = overdueApprovals(48)
        return ApprovalKpi(pending.size, overdue.size, pending.count { it.detail.contains("৳") })
    }

    // ============================================================
    // Section 7 — Top Risks and Opportunities, evidence-based.
    // ============================================================
    fun topRisks(limit: Int = 5): List<ExecutiveIntelligence.RiskItem> {
        val risks = mutableListOf<ExecutiveIntelligence.RiskItem>()
        InventoryRepository.purchaseRecommendations().filter { it.priority == "CRITICAL" }.forEach { r ->
            risks += ExecutiveIntelligence.RiskItem("STOCK_OUT", "${r.productName}: ${r.reason}", 0.0, "Purchase ${r.recommendedQty.toInt()} units", "Purchase Team", 90)
        }
        val overdueRetailers = retailers.value.filter { !it.isDeleted && it.dueBalance > it.creditLimit && it.creditLimit > 0 }
        overdueRetailers.take(3).forEach { r ->
            risks += ExecutiveIntelligence.RiskItem("CREDIT_BREACH", "${r.name}: due ৳${r.dueBalance} exceeds limit ৳${r.creditLimit}", r.dueBalance, "Collection follow-up", r.officerName.ifBlank { "Unassigned" }, 85)
        }
        securityEvents.value.filter { !it.isReviewed && it.severity == "CRITICAL" }.take(3).forEach { e ->
            risks += ExecutiveIntelligence.RiskItem("SECURITY", e.message, 0.0, "Manager review required", e.employeeName, 95)
        }
        return risks.sortedByDescending { it.score }.take(limit)
    }

    suspend fun topOpportunities(limit: Int = 5): List<ExecutiveIntelligence.OpportunityItem> {
        val opps = mutableListOf<ExecutiveIntelligence.OpportunityItem>()
        InventoryRepository.retailerDemandInsights().filter { it.isGrowing && it.trendPct > 20 }.take(3).forEach { r ->
            opps += ExecutiveIntelligence.OpportunityItem("RETAILER_GROWTH", "${r.retailerName}: +${"%.0f".format(r.trendPct)}% sales trend", r.last30DaySales, "Increase allocation/visit frequency", "Sales Team", 80)
        }
        InventoryRepository.warehouseBalancingRecommendations().take(2).forEach { t ->
            opps += ExecutiveIntelligence.OpportunityItem("STOCK_REDISTRIBUTION", "${t.productName}: ${t.reason}", 0.0, "Transfer ${t.recommendedQty.toInt()} units", "Warehouse Team", 70)
        }
        return opps.sortedByDescending { it.score }.take(limit)
    }

    // ============================================================
    // Section 19 — Decision Query Layer. Deterministic intent matching,
    // no external LLM required for supported questions.
    // ============================================================
    data class DecisionAnswer(val question: String, val intent: String?, val answer: String, val dataSource: String, val timestamp: LocalDateTime = LocalDateTime.now())

    fun askDecisionQuery(question: String): DecisionAnswer {
        val q = question.lowercase()
        val answer = when {
            q.contains("least") && q.contains("territor") -> {
                val worst = territories.value.minByOrNull { t -> retailers.value.filter { it.territoryId == t.id }.sumOf { it.dueBalance } }
                DecisionAnswer(question, "WEAKEST_TERRITORY", worst?.let { "${it.division}/${it.district ?: ""}" } ?: "No data available", "Territory + Retailer ledger")
            }
            q.contains("overdue") && (q.contains("retailer") || q.contains("five") || q.contains("5")) -> {
                val top5 = retailers.value.filter { !it.isDeleted && it.dueBalance > 0 }.sortedByDescending { it.dueBalance }.take(5)
                DecisionAnswer(question, "TOP_OVERDUE_RETAILERS", top5.joinToString("; ") { "${it.name}: ৳${it.dueBalance}" }.ifBlank { "No overdue retailers" }, "Retailer.dueBalance")
            }
            q.contains("stock out") || (q.contains("stock") && q.contains("seven")) -> {
                val risky = InventoryRepository.purchaseRecommendations().filter { it.daysRemaining != null && it.daysRemaining <= 7 }
                DecisionAnswer(question, "STOCK_OUT_RISK_7D", risky.joinToString("; ") { "${it.productName}: ${it.daysRemaining?.toInt()}d" }.ifBlank { "No products at risk within 7 days" }, "StockIntelligence.computeStockIntelligence")
            }
            q.contains("route") && (q.contains("missed") || q.contains("today")) -> {
                DecisionAnswer(question, "ROUTE_COMPLIANCE", "Route-compliance check requires per-employee route assignment data — see Territory Security report", "VisitLog + EmployeeProfile.routeId")
            }
            q.contains("approval") && q.contains("blocking") -> {
                val pending = approvals.value.filter { it.status == ApprovalStatus.PENDING }
                DecisionAnswer(question, "BLOCKING_APPROVALS", pending.take(5).joinToString("; ") { it.detail }.ifBlank { "No pending approvals" }, "ApprovalRequest")
            }
            q.contains("dealer") && q.contains("replenish") -> {
                val needy = InventoryRepository.dealerStockHealthInsights().filter { it.health == com.abm.erp.inventory.StockIntelligence.StockHealth.CRITICAL }
                DecisionAnswer(question, "DEALER_REPLENISHMENT", needy.joinToString("; ") { it.dealerName }.ifBlank { "No dealers critical" }, "Dealer.stockUnits")
            }
            q.contains("warehouse") && q.contains("excess") -> {
                val surplus = InventoryRepository.warehouseBalancingRecommendations()
                DecisionAnswer(question, "EXCESS_WAREHOUSE", surplus.joinToString("; ") { "${it.fromWarehouseName}: ${it.productName}" }.ifBlank { "No surplus detected" }, "InventoryRepository.stockLevels")
            }
            else -> DecisionAnswer(question, null, "প্রশ্নটি এখনো সমর্থিত না — supported প্রশ্নের তালিকা দেখুন।", "N/A")
        }
        scope.launch {
            val log = DecisionQueryLog(id = java.util.UUID.randomUUID().toString(), question = question, matchedIntent = answer.intent, askedBy = currentUser.name, resultSummary = answer.answer)
            val entity = log.toEntity()
            db.decisionQueryAuditDao().upsert(entity)
            syncCollection("decisionQueryAudit").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push decisionQuery failed", it) }
        }
        return answer
    }

    /** Section 23 — Executive Daily Brief: real, explainable, sourced from actual KPI/exception/risk data already computed above — not a separate calculation path. */
    data class DailyBrief(
        val yesterdaySales: Double, val todayProgress: Double, val collectionStatus: String, val criticalDues: Int,
        val criticalStock: Int, val attendanceIssues: Int, val pendingApprovals: Int, val securityIssues: Int,
        val topActions: List<String>, val generatedAt: LocalDateTime = LocalDateTime.now(),
    )
    suspend fun generateDailyBrief(): DailyBrief {
        val sales = computeSalesKpi()
        val collection = computeCollectionKpi()
        val approvals_ = computeApprovalKpi()
        val employee = computeEmployeeKpi()
        val criticalStock = InventoryRepository.purchaseRecommendations().count { it.priority == "CRITICAL" }
        val criticalDues = retailers.value.count { !it.isDeleted && it.creditLimit > 0 && it.dueBalance > it.creditLimit }
        val actions = mutableListOf<String>()
        if (criticalStock > 0) actions += "$criticalStock পণ্য critical stock — এখনই purchase দরকার"
        if (criticalDues > 0) actions += "$criticalDues retailer credit-limit ছাড়িয়ে গেছে — collection follow-up দরকার"
        if (approvals_.overdue > 0) actions += "${approvals_.overdue}টা approval ৪৮ ঘণ্টার বেশি pending"
        if (employee.geoViolationsToday > 0) actions += "${employee.geoViolationsToday}টা geo-violation আজ — review দরকার"
        val unreviewedSecurity = securityEvents.value.count { !it.isReviewed }
        if (unreviewedSecurity > 0) actions += "$unreviewedSecurity security event review বাকি"
        return DailyBrief(
            yesterdaySales = sales.yesterday, todayProgress = sales.today, collectionStatus = "${"%.0f".format(collection.efficiencyPct)}% efficiency",
            criticalDues = criticalDues, criticalStock = criticalStock, attendanceIssues = 0, pendingApprovals = approvals_.pending,
            securityIssues = unreviewedSecurity, topActions = actions.take(5),
        )
    }

    // Section 25/27 — data freshness/offline status: UI observes MockRepository.syncStatus directly (already reactive StateFlow) rather than a separate snapshot function, since a non-reactive snapshot would itself violate "Do not label stale cached data as live."

    // Section 10 — Field Force Monitoring, real Foundation 3/4 data, respects exact-location permission scope via visibleEmployeeIds.
    data class FieldForceStatus(val employeeId: String, val employeeName: String, val lastLat: Double?, val lastLng: Double?, val locationAgeMinutes: Long?, val currentVisitId: String?, val geoViolationsToday: Int)
    suspend fun fieldForceStatus(viewerEmployeeId: String): List<FieldForceStatus> {
        logAudit("ExecutiveAccess", viewerEmployeeId, "VIEW_EXACT_LOCATION")
        val visibleIds = visibleEmployeeIds(viewerEmployeeId)
        val now = LocalDateTime.now()
        val visibleProfiles = employeeProfiles.value.filter { it.id in visibleIds && it.hasActiveAccess }
        // Part O — one snapshot/visit query per employee is unavoidable
        // here (each needs its OWN latest record), but both are now real
        // suspend DAO calls on the caller's own coroutine instead of a
        // runBlocking that blocked whatever thread called this.
        return visibleProfiles.map { e ->
            val snapshot = db.employeeLocationSnapshotDao().getForEmployee(e.id).first().maxByOrNull { it.capturedAtEpochMillis }
            val ageMinutes = snapshot?.let { java.time.Duration.between(LocalDateTime.ofInstant(Instant.ofEpochMilli(it.capturedAtEpochMillis), ZoneOffset.UTC), now).toMinutes() }
            val activeVisit = db.visitLogDao().activeVisitForEmployee(e.id)
            val violations = securityEvents.value.count { it.employeeId == e.id && it.createdAtEpochMillis > System.currentTimeMillis() - 86400_000 }
            FieldForceStatus(e.id, e.fullName, snapshot?.lat, snapshot?.lng, ageMinutes, activeVisit?.id, violations)
        }
    }

    // Section 11 — Territory Performance, real Foundation 1 ledger + F3 visit data, drill-down-ready (region -> area -> territory -> route -> employee -> retailer already exists via territories/EmployeeProfile.territoryId).
    data class TerritoryPerformance(val territoryId: String, val label: String, val sales30d: Double, val collection30d: Double, val retailerCoverage: Int, val inactiveRetailers: Int, val geoViolations: Int)
    suspend fun territoryPerformance(): List<TerritoryPerformance> {
        val now = LocalDateTime.now()
        // Part O fix — the full ledger table was being re-fetched inside
        // the per-territory loop below (N territories = N full-table
        // reads of the same data). Fetched ONCE here instead.
        val allLedger = db.partyLedgerDao().getAll().first()
        return territories.value.filter { it.isActive }.map { t ->
            val myRetailers = retailers.value.filter { !it.isDeleted && it.territoryId == t.id }
            val myRetailerIds = myRetailers.map { it.id }.toSet()
            val myLedger = allLedger.filter { it.partyId in myRetailerIds && it.partyType == "RETAILER" }
            val sales30 = myLedger.filter { it.type == "DEBIT" && it.createdAtEpochMillis > System.currentTimeMillis() - 30L * 86400_000 }.sumOf { it.amount }
            val collection30 = myLedger.filter { it.type == "CREDIT" && it.createdAtEpochMillis > System.currentTimeMillis() - 30L * 86400_000 }.sumOf { it.amount }
            val inactive = myRetailers.count { it.lastOrderDate == null || java.time.Duration.between(it.lastOrderDate, now).toDays() > 60 }
            val violations = securityEvents.value.count { it.territoryId == t.id }
            TerritoryPerformance(t.id, "${t.division}/${t.district ?: ""}", sales30, collection30, myRetailers.size, inactive, violations)
        }
    }

    // Section 12 — Retailer Intelligence executive summary, reuses Foundation 1/5 data (no duplicate calculation).
    data class RetailerIntelSummary(val highValue: List<Retailer>, val fastGrowing: List<InventoryRepository.RetailerDemandInsight>, val declining: List<InventoryRepository.RetailerDemandInsight>, val creditRisk: List<Retailer>, val complaintHeavy: List<Retailer>)
    suspend fun retailerIntelligence(): RetailerIntelSummary {
        val live = retailers.value.filter { !it.isDeleted }
        val demand = InventoryRepository.retailerDemandInsights()
        val complaints = customerComplaints.value.groupingBy { it.dealerId }.eachCount()
        return RetailerIntelSummary(
            highValue = live.sortedByDescending { it.dueBalance + it.creditLimit }.take(10),
            fastGrowing = demand.filter { it.isGrowing && it.trendPct > 20 }.sortedByDescending { it.trendPct }.take(10),
            declining = demand.filter { !it.isGrowing }.sortedBy { it.trendPct }.take(10),
            creditRisk = live.filter { it.creditLimit > 0 && it.dueBalance > it.creditLimit }.take(10),
            complaintHeavy = live.filter { (complaints[it.id] ?: 0) >= 3 }.take(10),
        )
    }

    // Section 15 — Financial Command View, authoritative from actual ledger/voucher records (not re-derived from sales screens).
    data class FinancialCommandView(val receivable: Double, val payable: Double, val pendingVouchers: Int, val periodStatus: String, val ledgerReceivable: Double, val reconciliationMismatch: Boolean, val dataQualityWarning: String?)

    /**
     * Part N — Financial Source of Truth. Dealer.dueBalance/Retailer.dueBalance
     * are cached, denormalized fields updated as a side effect of sales/
     * collection operations — convenient for fast list display, but never
     * the authoritative number for an executive financial view. The real
     * authority is the posted ledger (PartyLedgerEntry). This function now
     * computes BOTH and treats a mismatch as a data-quality finding to
     * surface, not something to silently paper over by only showing the
     * cached number.
     */
    suspend fun financialCommandView(): FinancialCommandView? {
        if (!PermissionManager.canCurrentUser("ledger", PermissionAction.VIEW)) {
            logAudit("ExecutiveAccess", currentUser.id, "DENY_FINANCIAL_VIEW", oldValue = currentUser.role.name)
            return null
        }
        logAudit("ExecutiveAccess", currentUser.id, "VIEW_FINANCIAL_SUMMARY")
        val cachedReceivable = dealers.value.filter { !it.isDeleted }.sumOf { it.dueBalance } + retailers.value.filter { !it.isDeleted }.sumOf { it.dueBalance }
        val allLedger = db.partyLedgerDao().getAll().first()
        val debitTotal = allLedger.filter { it.type == "DEBIT" }.sumOf { it.amount }
        val creditTotal = allLedger.filter { it.type == "CREDIT" }.sumOf { it.amount }
        val ledgerReceivable = debitTotal - creditTotal
        val mismatch = kotlin.math.abs(ledgerReceivable - cachedReceivable) > 1.0 // >1 taka tolerance for floating-point rounding, not a real discrepancy threshold decision
        val warning = if (mismatch) "Cached due-balance total (৳${"%,.0f".format(cachedReceivable)}) does not match posted ledger total (৳${"%,.0f".format(ledgerReceivable)}) — reconciliation needed before treating either as final." else null
        val pendingVouchers = AccountsRepository.vouchers.value.count { it.lines.sumOf { l -> l.debit } > 50000.0 }
        return FinancialCommandView(cachedReceivable, 0.0, pendingVouchers, "See Financial Closing module for period status", ledgerReceivable, mismatch, warning)
    }

    /** Section 5 — real exception generation from actual data. Without this, raiseExecutiveException had no caller and executiveExceptions would always be empty. */
    suspend fun generateExecutiveExceptions() {
        InventoryRepository.purchaseRecommendations().filter { it.priority == "CRITICAL" }.forEach { r ->
            raiseExecutiveException("STOCK_OUT_RISK", "CRITICAL", "StockIntelligence", r.reason, recommendedAction = "Purchase ${r.recommendedQty.toInt()} units", dedupKey = "stockout_${r.productId}")
        }
        retailers.value.filter { !it.isDeleted && it.creditLimit > 0 && it.dueBalance > it.creditLimit }.forEach { r ->
            raiseExecutiveException("CREDIT_LIMIT_BREACH", "WARNING", "Retailer", "${r.name}: due ৳${r.dueBalance} exceeds limit ৳${r.creditLimit}", responsiblePerson = r.officerName, recommendedAction = "Collection follow-up", dedupKey = "credit_${r.id}")
        }
        InventoryRepository.expiryReport().filter { it.status == com.abm.erp.inventory.StockIntelligence.ExpiryStatus.EXPIRED }.forEach { e ->
            raiseExecutiveException("EXPIRED_STOCK", "WARNING", "Inventory", "${e.productName} batch ${e.lot.batchCode} expired", recommendedAction = "Write off / dispose", dedupKey = "expiry_${e.lot.id}")
        }
        securityEvents.value.filter { !it.isReviewed && it.severity == "CRITICAL" }.forEach { s ->
            raiseExecutiveException("SECURITY_INCIDENT", "CRITICAL", "SecurityEvent", s.message, responsiblePerson = s.employeeName, recommendedAction = "Manager review required", dedupKey = "security_${s.id}")
        }
        overdueApprovals(48).forEach { a ->
            raiseExecutiveException("APPROVAL_OVERDUE", "WARNING", "ApprovalRequest", a.detail, recommendedAction = "Escalate or approve", dedupKey = "approval_${a.id}")
        }
    }

    // Section 8 — Approval Cockpit: unified view over the existing ApprovalRequest engine (Foundation 2), never bypassed.
    data class ApprovalCockpitItem(val id: String, val detail: String, val requester: String, val ageHours: Long, val stage: Int, val isEscalated: Boolean)
    fun approvalCockpit(): List<ApprovalCockpitItem> {
        val now = LocalDateTime.now()
        return approvals.value.filter { it.status == ApprovalStatus.PENDING }.map { a ->
            ApprovalCockpitItem(a.id, a.detail, a.fromEmployee, java.time.Duration.between(a.createdAt, now).toHours(), a.level, java.time.Duration.between(a.createdAt, now).toHours() > 48)
        }.sortedByDescending { it.ageHours }
    }

    // Section 13 — Product/Brand Performance, real Foundation 5 + sales data, margin hidden unless authorized.
    data class ProductPerformance(val productId: String, val productName: String, val sales30d: Double, val marginPct: Double?, val stockHealth: com.abm.erp.inventory.StockIntelligence.StockHealth)
    fun productPerformance(): List<ProductPerformance> {
        val canViewMargin = PermissionManager.canCurrentUser("ledger", PermissionAction.VIEW)
        return InventoryRepository.products.value.filter { !it.isDeleted && it.isActive }.map { p ->
            val sales30 = salesInvoices.value.filter { !it.isDeleted && it.createdAt.isAfter(LocalDateTime.now().minusDays(30)) }
                .flatMap { it.lineItems }.filter { it.productId == p.id }.sumOf { it.lineTotal }
            val margin = if (canViewMargin && p.costPrice > 0) ((p.defaultUnitPrice - p.costPrice) / p.defaultUnitPrice * 100) else null
            val report = InventoryRepository.computeStockIntelligence(p.id)
            val health = report?.let { com.abm.erp.inventory.StockIntelligence.classifyStockHealth(it.currentStock, p.reorderThreshold, p.reorderThreshold * 5, it.movementClass) } ?: com.abm.erp.inventory.StockIntelligence.StockHealth.HEALTHY
            ProductPerformance(p.id, p.name, sales30, margin, health)
        }.sortedByDescending { it.sales30d }
    }

    /**
     * Section 20 — AI Assistant Integration Boundary: permission-filtered,
     * redacted context builder. No API secrets embedded; no direct DB
     * write by any AI path; this only ever returns a summarized string
     * for prompting, never raw records, and every call is audited.
     */
    suspend fun buildAiSafeContext(requestingRole: UserRole): String {
        logAudit("AiContextBuild", currentUser.id, "BUILD_CONTEXT", oldValue = requestingRole.name)
        val canViewFinancial = PermissionManager.canCurrentUser("ledger", PermissionAction.VIEW)
        val sales = computeSalesKpi()
        val retailerKpi = computeRetailerKpi()
        val sb = StringBuilder()
        sb.append("Sales today: ৳${sales.today.toInt()}, this month: ৳${sales.thisMonth.toInt()}\n")
        sb.append("Active retailers: ${retailerKpi.totalActive}, inactive: ${retailerKpi.inactive}\n")
        if (canViewFinancial) {
            val fin = financialCommandView()
            if (fin != null) sb.append("Receivable: ৳${fin.receivable.toInt()}\n") // redacted entirely if caller isn't authorized
        }
        sb.append("(No employee salary, exact coordinates, or raw record data included — summarized KPIs only.)")
        return sb.toString()
    }

    // Section 30 — centralized Executive settings (was scattered as hardcoded defaults in each function).
    data class ExecutiveSettings(val alertRefreshMinutes: Int = 30, val approvalOverdueHours: Long = 48, val exceptionDedupWindowMinutes: Long = 15, val riskListSize: Int = 5, val opportunityListSize: Int = 5)
    var executiveSettings: ExecutiveSettings = ExecutiveSettings()
        private set
    fun updateExecutiveSettings(settings: ExecutiveSettings): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) return false
        val old = executiveSettings
        executiveSettings = settings
        logAudit("ExecutiveSettings", "global", "UPDATE", oldValue = old, newValue = settings)
        return true
    }

    // ============================================================
    // Bangladesh Offline Administrative Location Master.
    // ============================================================
    lateinit var administrativeLocations: StateFlow<List<AdministrativeLocation>>
        private set
    lateinit var companyMarkets: StateFlow<List<CompanyMarket>>
        private set
    private val _lastBdImportResult = MutableStateFlow<BdImportSummary?>(null)
    val lastBdImportResult: StateFlow<BdImportSummary?> = _lastBdImportResult.asStateFlow()

    data class BdImportSummary(val divisions: Int, val districts: Int, val upazilas: Int, val unions: Int, val polygonsMatched: Int, val alreadyInstalled: Boolean, val validationPassed: Boolean = true, val validationErrors: List<String> = emptyList())

    /**
     * Section 3, 5 — real, idempotent import pipeline. Reads bundled JSON
     * assets, compares installed dataset version against manifest, only
     * imports when needed, and uses upsert-by-id (REPLACE conflict
     * strategy) so re-running the same source never duplicates rows.
     * Runs off the main thread (called from a coroutine by the caller).
     */
    suspend fun importBangladeshLocations(context: android.content.Context, forceReimport: Boolean = false): BdImportSummary {
        // v93 fix — uses only built-in org.json + plain SharedPreferences
        // (already used elsewhere in this codebase, e.g. BackupManager),
        // since neither Gson nor androidx.preference is an actual project
        // dependency — using them would not have compiled.
        fun readAsset(name: String): String = context.assets.open("bangladesh_locations/$name").bufferedReader().use { it.readText() }
        val prefs = context.getSharedPreferences("abm_erp_prefs", android.content.Context.MODE_PRIVATE)

        val manifestObj = org.json.JSONObject(readAsset("manifest.json"))
        val datasetVersion = manifestObj.optString("datasetVersion", "unknown")
        val installedVersion = prefs.getString("bd_location_dataset_version", null)
        if (installedVersion == datasetVersion && !forceReimport) {
            val existing = db.administrativeLocationDao().count()
            android.util.Log.i("MockRepository", "Bangladesh location dataset already at version $datasetVersion ($existing rows), skipping import")
            return BdImportSummary(0, 0, 0, 0, 0, alreadyInstalled = true)
        }

        data class RawLoc(val id: String, val officialCode: String?, val sourceCode: String, val type: String, val nameEn: String, val nameBn: String, val normalizedName: String, val parentId: String?, val lat: Double?, val lng: Double?, val sourceName: String, val sourceUrl: String, val sourceVersion: String, val active: Boolean, val verified: Boolean)
        fun parseLevel(fileName: String): List<RawLoc> {
            val arr = org.json.JSONArray(readAsset(fileName))
            return (0 until arr.length()).map { i ->
                val m = arr.getJSONObject(i)
                RawLoc(
                    id = m.getString("id"), officialCode = if (m.isNull("officialCode")) null else m.optString("officialCode"),
                    sourceCode = m.optString("sourceCode", ""), type = m.getString("type"), nameEn = m.getString("nameEn"), nameBn = m.getString("nameBn"),
                    normalizedName = m.optString("normalizedName", ""), parentId = if (m.isNull("parentId")) null else m.optString("parentId"),
                    lat = if (m.has("lat") && !m.isNull("lat")) m.getDouble("lat") else null, lng = if (m.has("lng") && !m.isNull("lng")) m.getDouble("lng") else null,
                    sourceName = m.optString("sourceName", ""), sourceUrl = m.optString("sourceUrl", ""), sourceVersion = m.optString("sourceVersion", ""),
                    active = m.optBoolean("active", true), verified = m.optBoolean("verified", false),
                )
            }
        }

        val country = parseLevel("country.json")
        val divisions = parseLevel("divisions.json")
        val districts = parseLevel("districts.json")
        val upazilas = parseLevel("upazilas.json")
        val unions = parseLevel("unions.json")

        // District polygons — matched by normalized English name (source has no shared code between the boundary file and the admin-hierarchy file).
        val polygonRoot = org.json.JSONObject(readAsset("district_polygons_simplified.json"))
        val featuresArr = polygonRoot.getJSONArray("features")
        val polygonByName = mutableMapOf<String, List<Pair<Double, Double>>>()
        for (i in 0 until featuresArr.length()) {
            val feat = featuresArr.getJSONObject(i)
            val name = feat.getJSONObject("properties").getString("nameEn").trim().lowercase()
            val geom = feat.getJSONObject("geometry")
            val coordsArr = geom.getJSONArray("coordinates").getJSONArray(0) // outer ring only
            val pts = (0 until coordsArr.length()).map { j ->
                val pair = coordsArr.getJSONArray(j)
                pair.getDouble(1) to pair.getDouble(0) // GeoJSON is [lng, lat]; we store (lat, lng)
            }
            polygonByName[name] = pts
        }

        val allRaw = country + divisions + districts + upazilas + unions
        val parentOf = allRaw.associate { it.id to it.parentId }
        val typeOf = allRaw.associate { it.id to it.type }
        fun findAncestorId(startId: String?, targetType: String): String? {
            var cursor = startId
            var hops = 0
            while (cursor != null && hops < 10) {
                if (typeOf[cursor] == targetType) return cursor
                cursor = parentOf[cursor]
                hops++
            }
            return null
        }

        var polygonsMatched = 0
        val allEntities = allRaw.map { r ->
            val polygon = if (r.type == "DISTRICT") polygonByName[r.nameEn.trim().lowercase()] ?: emptyList() else emptyList()
            if (polygon.isNotEmpty()) polygonsMatched++
            AdministrativeLocation(
                id = r.id, officialCode = r.officialCode, sourceCode = r.sourceCode, type = r.type, nameEn = r.nameEn, nameBn = r.nameBn,
                normalizedName = r.normalizedName, parentId = r.parentId,
                divisionId = if (r.type in setOf("DISTRICT", "UPAZILA", "UNION")) findAncestorId(r.id, "DIVISION") else null,
                districtId = if (r.type in setOf("UPAZILA", "UNION")) findAncestorId(r.id, "DISTRICT") else null,
                upazilaId = if (r.type == "UNION") r.parentId else null,
                latitude = r.lat, longitude = r.lng, polygon = polygon, sourceName = r.sourceName, sourceUrl = r.sourceUrl, sourceVersion = r.sourceVersion,
                active = r.active, verified = r.verified,
            )
        }

        // Part R — real validation BEFORE anything is marked installed.
        // A failed validation must show up in the returned summary (for
        // UI display), not just Logcat, and must not overwrite the
        // previously-installed dataset version marker.
        val errors = mutableListOf<String>()
        val expectedDivisions = (manifestObj.optJSONObject("levels")?.optInt("division")) ?: divisions.size
        val expectedDistricts = (manifestObj.optJSONObject("levels")?.optInt("district")) ?: districts.size
        if (divisions.size != expectedDivisions) errors += "Division count mismatch: expected $expectedDivisions from manifest, got ${divisions.size}"
        if (districts.size != expectedDistricts) errors += "District count mismatch: expected $expectedDistricts from manifest, got ${districts.size}"
        val blankBengali = allRaw.count { it.nameBn.isBlank() }
        if (blankBengali > 0) errors += "$blankBengali records have a blank Bengali name"
        val invalidCoords = allRaw.count { r -> (r.lat != null && (r.lat < -90 || r.lat > 90)) || (r.lng != null && (r.lng < -180 || r.lng > 180)) }
        if (invalidCoords > 0) errors += "$invalidCoords records have out-of-range coordinates"
        val badParentType = allRaw.count { r ->
            when (r.type) {
                "DIVISION" -> r.parentId != null && typeOf[r.parentId] != "COUNTRY"
                "DISTRICT" -> r.parentId == null || typeOf[r.parentId] != "DIVISION"
                "UPAZILA" -> r.parentId == null || typeOf[r.parentId] != "DISTRICT"
                "UNION" -> r.parentId == null || typeOf[r.parentId] != "UPAZILA"
                else -> false
            }
        }
        if (badParentType > 0) errors += "$badParentType records have an invalid parent type for their level"
        val invalidPolygonDistricts = allEntities.count { it.type == "DISTRICT" && it.polygon.isNotEmpty() && it.polygon.size < 3 }
        if (invalidPolygonDistricts > 0) errors += "$invalidPolygonDistricts district polygons have fewer than 3 points"

        // Simple content checksum (sum of string hashcodes) — detects a
        // truncated/corrupted asset read even without a full SHA-256 pass
        // over every field; logged so a real signed-checksum can replace
        // this later without changing the summary shape.
        val contentChecksum = allRaw.sumOf { (it.id + it.nameEn + it.type).hashCode().toLong() }
        android.util.Log.i("MockRepository", "Bangladesh import content checksum: $contentChecksum")

        if (errors.isNotEmpty()) {
            android.util.Log.e("MockRepository", "Bangladesh location import FAILED validation: $errors")
            val failResult = BdImportSummary(divisions.size, districts.size, upazilas.size, unions.size, polygonsMatched, alreadyInstalled = false, validationPassed = false, validationErrors = errors)
            _lastBdImportResult.value = failResult
            return failResult
        }

        db.administrativeLocationDao().upsertAll(allEntities.map { it.toEntity() })
        prefs.edit().putString("bd_location_dataset_version", datasetVersion).apply()
        logAudit("AdministrativeLocationImport", "bangladesh", "IMPORT", newValue = "version=$datasetVersion, rows=${allEntities.size}")

        val successResult = BdImportSummary(divisions.size, districts.size, upazilas.size, unions.size, polygonsMatched, alreadyInstalled = false)
        _lastBdImportResult.value = successResult
        return successResult
    }
    // Section 2/9 — real cascading query + offline geo-integration.
    fun adminChildrenOf(parentId: String?): List<AdministrativeLocation> = administrativeLocations.value.filter { it.parentId == parentId && it.active }.sortedBy { it.nameEn }
    fun adminByType(type: String): List<AdministrativeLocation> = administrativeLocations.value.filter { it.type == type && it.active }.sortedBy { it.nameEn }

    /** Section 2 — full hierarchy path for display/search, e.g. "Comilla > Debidwar > Subil". */
    fun adminHierarchyPath(locationId: String): String {
        val byId = administrativeLocations.value.associateBy { it.id }
        val parts = mutableListOf<String>()
        var cursor: String? = locationId
        var hops = 0
        while (cursor != null && hops < 10) {
            val node = byId[cursor] ?: break
            parts.add(0, node.nameEn)
            cursor = node.parentId
            hops++
        }
        return parts.joinToString(" > ")
    }

    /**
     * Section 9 — offline point-to-district resolution using the bundled,
     * simplified district polygons (real GeoLock.isPointInPolygon, no
     * network required). Falls back to nearest-district-by-centroid if no
     * polygon contains the point (e.g. point just outside a simplified
     * boundary).
     */
    fun resolveDistrictForPoint(lat: Double, lng: Double): AdministrativeLocation? {
        val districtsWithPolygon = administrativeLocations.value.filter { it.type == "DISTRICT" && it.polygon.size >= 3 }
        val inside = districtsWithPolygon.firstOrNull { GeoLock.isPointInPolygon(lat, lng, it.polygon) }
        if (inside != null) return inside
        return administrativeLocations.value.filter { it.type == "DISTRICT" && it.latitude != null && it.longitude != null }
            .minByOrNull { LocationVerification.distanceMeters(lat, lng, it.latitude!!, it.longitude!!) }
    }

    fun searchAdminLocations(query: String): List<AdministrativeLocation> {
        val q = query.trim().lowercase()
        if (q.isBlank()) return emptyList()
        return administrativeLocations.value.filter { it.active && (it.nameEn.lowercase().contains(q) || it.nameBn.contains(query.trim())) }.take(50)
    }

    // Section 12 — company-created market/bazaar, real duplicate-detection within the same parent admin unit.
    suspend fun createCompanyMarket(name: String, parentAdminId: String, latitude: Double?, longitude: Double?): Boolean {
        if (name.isBlank()) return false
        val existing = db.companyMarketDao().countDuplicate(parentAdminId, name)
        if (existing > 0) {
            com.abm.erp.config.AppLog.w("MockRepository", "createCompanyMarket rejected: duplicate market '$name' under this admin unit")
            return false
        }
        val market = CompanyMarket(id = java.util.UUID.randomUUID().toString(), name = name, parentAdminId = parentAdminId, latitude = latitude, longitude = longitude, createdBy = currentUser.name)
        scope.launch {
            val entity = market.toEntity()
            db.companyMarketDao().upsert(entity)
            syncCollection("companyMarkets").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push companyMarket failed", it) }
            logAudit("CompanyMarket", market.id, "CREATE", newValue = market)
        }
        return true
    }

    /**
     * Section 7 — Legacy Address Migration: real matching strategy (exact
     * -> alias/normalized -> unresolved), never silently dropping old
     * free-text district/upazila data on existing Retailer records.
     */
    data class LegacyAddressResolution(val retailerId: String, val retailerName: String, val freeTextDistrict: String, val freeTextUpazila: String, val matchedDistrictId: String?, val matchedUpazilaId: String?, val matchType: String)

    fun resolveLegacyRetailerAddresses(): List<LegacyAddressResolution> {
        val districts = administrativeLocations.value.filter { it.type == "DISTRICT" }
        val upazilas = administrativeLocations.value.filter { it.type == "UPAZILA" }
        fun norm(s: String) = s.trim().lowercase()
        return retailers.value.filter { !it.isDeleted && it.district.isNotBlank() }.map { r ->
            val exactDist = districts.firstOrNull { norm(it.nameEn) == norm(r.district) }
            val aliasDist = exactDist ?: districts.firstOrNull { norm(it.nameEn).contains(norm(r.district)) || norm(r.district).contains(norm(it.nameEn)) }
            val matchedDist = exactDist ?: aliasDist
            val matchType = when { exactDist != null -> "EXACT"; aliasDist != null -> "ALIAS"; else -> "UNRESOLVED" }
            val matchedUpz = if (matchedDist != null && r.upazila.isNotBlank()) {
                upazilas.firstOrNull { it.parentId == matchedDist.id && (norm(it.nameEn) == norm(r.upazila) || norm(it.nameEn).contains(norm(r.upazila))) }
            } else null
            LegacyAddressResolution(r.id, r.name, r.district, r.upazila, matchedDist?.id, matchedUpz?.id, matchType)
        }
    }

    /** Manual resolution action — links a specific retailer's legacy free-text address to a confirmed admin unit, real audit. */
    fun confirmLegacyAddressMatch(retailerId: String, districtId: String?, upazilaId: String?): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.EDIT)) return false
        val locs = administrativeLocations.value.associateBy { it.id }
        val newDistrict = districtId?.let { locs[it]?.nameEn }
        val newUpazila = upazilaId?.let { locs[it]?.nameEn }
        scope.launch {
            val r = retailers.value.firstOrNull { it.id == retailerId } ?: return@launch
            val updated = r.copy(district = newDistrict ?: r.district, upazila = newUpazila ?: r.upazila)
            val entity = updated.toEntity()
            db.retailerDao().upsert(entity)
            syncCollection("retailers").document(retailerId).update(mapOf("district" to entity.district, "upazila" to entity.upazila))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push legacy-address-resolve failed", it) }
            logAudit("Retailer", retailerId, "LEGACY_ADDRESS_RESOLVED", oldValue = "${r.district}/${r.upazila}", newValue = "${entity.district}/${entity.upazila}")
        }
        return true
    }

    /** Section 14 — real, runtime validation of the imported dataset. Reports actual counts (never assumes commonly-quoted national figures). */
    data class BdValidationReport(
        val divisionCount: Int, val districtCount: Int, val upazilaCount: Int, val unionCount: Int,
        val orphanDistricts: Int, val orphanUpazilas: Int, val orphanUnions: Int, val duplicateSourceCodes: Int, val blankNames: Int,
        val divisionsMatchExpected8: Boolean, val districtsMatchExpected64: Boolean,
    )
    fun validateBangladeshLocationImport(): BdValidationReport {
        val all = administrativeLocations.value
        val byId = all.associateBy { it.id }
        val divisions = all.filter { it.type == "DIVISION" }
        val districts = all.filter { it.type == "DISTRICT" }
        val upazilas = all.filter { it.type == "UPAZILA" }
        val unions = all.filter { it.type == "UNION" }
        val orphanDistricts = districts.count { it.parentId == null || byId[it.parentId] == null }
        val orphanUpazilas = upazilas.count { it.parentId == null || byId[it.parentId] == null }
        val orphanUnions = unions.count { it.parentId == null || byId[it.parentId] == null }
        val dupSourceCodes = all.groupBy { it.type to it.sourceCode }.count { it.value.size > 1 }
        val blankNames = all.count { it.nameEn.isBlank() }
        return BdValidationReport(
            divisions.size, districts.size, upazilas.size, unions.size, orphanDistricts, orphanUpazilas, orphanUnions,
            dupSourceCodes, blankNames, divisions.size == 8, districts.size == 64,
        )
    }

    /** Section 8 — Employee Hierarchy/Territory integration: validates a Territory's existing free-text division/district against the real Bangladesh Location Master (no Territory schema change — matches Section 7's legacy-resolution pattern). */
    data class TerritoryAdminMatch(val territoryId: String, val matchedDivisionId: String?, val matchedDistrictId: String?, val resolved: Boolean)
    fun matchTerritoryToAdminHierarchy(territory: Territory): TerritoryAdminMatch {
        fun norm(s: String?) = s?.trim()?.lowercase() ?: ""
        val division = administrativeLocations.value.firstOrNull { it.type == "DIVISION" && norm(it.nameEn) == norm(territory.division) }
        val district = territory.district?.let { d -> administrativeLocations.value.firstOrNull { it.type == "DISTRICT" && norm(it.nameEn) == norm(d) && (division == null || it.parentId == division.id) } }
        return TerritoryAdminMatch(territory.id, division?.id, district?.id, division != null)
    }

    // ============================================================
    // Part A — real UserAccount system: PBKDF2 hash+salt, lockout
    // tracked in Room (survives restart), weak-PIN rejected at set-time.
    // ============================================================
    lateinit var userAccounts: StateFlow<List<UserAccount>>
        private set

    private val maxFailedAttempts = 5
    private val lockoutDurationMillis = 15 * 60_000L

    data class AccountCreationResult(val success: Boolean, val accountId: String?, val message: String)

    /**
     * Mirrors an aggregate `dealer.stockUnits` change into the new product-wise breakdown.
     *
     * Called alongside every existing `dealerDao().adjustStock()` call, from the exact same
     * line items and the exact same event — so the two can never fall out of sync with each
     * other, and neither replaces the other. `productId` blank (an unstructured legacy line)
     * is skipped for the product-wise table only; the aggregate call beside this one is
     * unaffected and still runs.
     *
     * Deliberately not clamped at zero. If a return or edit ever pushes a line negative, that
     * is a real discrepancy in the underlying events and should be visible on the stock page,
     * not hidden by silently floor-ing it — clamping would erase the evidence of the problem
     * it was meant to reveal.
     */
    private suspend fun adjustDealerStockLine(dealerId: String, productId: String, productName: String, deltaQty: Int) {
        if (productId.isBlank()) return
        val existing = db.dealerStockLineDao().find(dealerId, productId)
        db.dealerStockLineDao().upsert(
            com.abm.erp.data.room.DealerStockLineEntity(
                dealerId = dealerId,
                productId = productId,
                productName = productName.ifBlank { existing?.productName ?: productId },
                qty = (existing?.qty ?: 0) + deltaQty,
                updatedAtEpochMillis = System.currentTimeMillis(),
            ),
        )
    }

    /** v113-75 — retailer-side mirror of adjustDealerStockLine, same shape, same rule
     *  (blank productId is a no-op, never silently dropped elsewhere). */
    private suspend fun adjustRetailerStockLine(retailerId: String, productId: String, productName: String, deltaQty: Int) {
        if (productId.isBlank()) return
        val existing = db.retailerStockLineDao().find(retailerId, productId)
        db.retailerStockLineDao().upsert(
            com.abm.erp.data.room.RetailerStockLineEntity(
                retailerId = retailerId,
                productId = productId,
                productName = productName.ifBlank { existing?.productName ?: productId },
                qty = (existing?.qty ?: 0) + deltaQty,
                updatedAtEpochMillis = System.currentTimeMillis(),
            ),
        )
    }

    /**
     * Chairman PIN reset — for the real case where an employee forgets their PIN.
     *
     * The existing `resetPin(oldPin)` requires the *old* PIN, which is exactly what a
     * person who has forgotten it cannot supply, and it only touched the in-memory demo
     * map rather than a real UserAccount. This is the missing path.
     *
     * Safeguards, deliberately kept rather than trading away for convenience:
     *  - Chairman only, and the attempt is audited whether it succeeds or fails.
     *  - The new PIN is generated, never chosen by the resetter, and re-rolled until it
     *    passes the same weak-PIN check new accounts must pass.
     *  - `mustChangePinOnNextLogin` is set, so the Chairman never ends up knowing a PIN
     *    the employee keeps using.
     *  - Lockout state is cleared, since a forgotten PIN usually arrives with a locked
     *    account attached.
     *
     * Returns the temporary PIN to read out once; it is never stored in plain form.
     */
    suspend fun chairmanResetEmployeePin(employeeProfileId: String): AccountCreationResult {
        if (currentUser.role != UserRole.CHAIRMAN) {
            logAudit("UserAccount", employeeProfileId, "DENY", oldValue = currentUser.role.name, newValue = "PIN_RESET")
            return AccountCreationResult(false, null, "শুধু Chairman PIN রিসেট করতে পারেন।")
        }
        val existing = db.userAccountDao().getByEmployeeProfileId(employeeProfileId)
            ?: return AccountCreationResult(false, null, "এই কর্মীর কোনো লগইন account নেই — আগে account তৈরি করুন।")

        var newPin: String
        do { newPin = (10000..99999).random().toString() } while (com.abm.erp.auth.PinHashing.isWeakPin(newPin))
        val hash = com.abm.erp.auth.PinHashing.createHash(newPin)

        val updated = existing.copy(
            pinHash = hash.hash, pinSalt = hash.salt, pinIterations = hash.iterations,
            mustChangePinOnNextLogin = true,
            pinSetAtEpochMillis = System.currentTimeMillis(),
            failedAttempts = 0, lockedUntilEpochMillis = null, locked = false,
        )
        db.userAccountDao().upsert(updated)
        syncCollection("userAccounts").document(updated.id).set(updated)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push userAccount pin-reset failed", it) }
        // The PIN itself is never written to the audit log — only the fact of the reset.
        logAuditAwaited("UserAccount", updated.id, "PIN_RESET", reason = "Chairman reset for employee $employeeProfileId")
        return AccountCreationResult(true, updated.id, newPin)
    }

    /** Chairman toggle — suspend or restore a login without deleting the account or its history. */
    suspend fun setAccountActive(employeeProfileId: String, active: Boolean): Boolean {
        if (currentUser.role != UserRole.CHAIRMAN) {
            logAudit("UserAccount", employeeProfileId, "DENY", oldValue = currentUser.role.name, newValue = "SET_ACTIVE")
            return false
        }
        val existing = db.userAccountDao().getByEmployeeProfileId(employeeProfileId) ?: return false
        val updated = existing.copy(active = active, locked = if (active) false else existing.locked)
        db.userAccountDao().upsert(updated)
        syncCollection("userAccounts").document(updated.id).set(updated)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push userAccount active-toggle failed", it) }
        logAuditAwaited("UserAccount", updated.id, if (active) "ACCOUNT_ENABLED" else "ACCOUNT_DISABLED")
        return true
    }

    /**
     * Marks a person as office or factory staff. Chairman-gated and audited, because it
     * decides which module's HR screens they appear in and therefore which payroll run they
     * fall into — a quiet change here would move someone between workforces unnoticed.
     */
    suspend fun setEmployeeType(employeeProfileId: String, type: EmployeeType): Boolean {
        if (currentUser.role != UserRole.CHAIRMAN) {
            logAudit("EmployeeProfile", employeeProfileId, "DENY", oldValue = currentUser.role.name, newValue = "SET_EMPLOYEE_TYPE")
            return false
        }
        val existing = db.employeeProfileDao().getAll().first().firstOrNull { it.id == employeeProfileId } ?: return false
        if (existing.employeeType == type.name) return true
        val updated = existing.copy(employeeType = type.name)
        db.employeeProfileDao().upsert(updated)
        syncCollection("employeeProfiles").document(updated.id).set(updated)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push employeeType failed", it) }
        logAuditAwaited("EmployeeProfile", updated.id, "SET_EMPLOYEE_TYPE", oldValue = existing.employeeType, newValue = type.name)
        return true
    }

    /** Does this employee already have a login? Used by the setup screen to show the right action. */
    suspend fun hasLoginAccount(employeeProfileId: String): Boolean =
        db.userAccountDao().getByEmployeeProfileId(employeeProfileId) != null

    suspend fun createUserAccount(employeeProfileId: String, companyId: String, initialPin: String): AccountCreationResult {
        if (com.abm.erp.auth.PinHashing.isWeakPin(initialPin)) {
            return AccountCreationResult(false, null, "এই PIN খুবই সহজে অনুমান করা যায় (sequential/repeated digits) — অন্য একটা বেছে নিন।")
        }
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) {
            return AccountCreationResult(false, null, "Only an authorized administrator may create login accounts.")
        }
        val existing = db.userAccountDao().getByEmployeeProfileId(employeeProfileId)
        if (existing != null) return AccountCreationResult(false, null, "এই employee-র জন্য account আগে থেকেই আছে।")
        val hashResult = com.abm.erp.auth.PinHashing.createHash(initialPin)
        val now = System.currentTimeMillis()
        val account = UserAccount(
            id = java.util.UUID.randomUUID().toString(), employeeProfileId = employeeProfileId, companyId = companyId,
            pinHash = hashResult.hash, pinSalt = hashResult.salt, pinIterations = hashResult.iterations,
            mustChangePinOnNextLogin = true, // Part A — forced change on first real login, never a permanent shared initial PIN
        )
        scope.launch {
            val entity = account.toEntity()
            db.userAccountDao().upsert(entity)
            syncCollection("userAccounts").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push userAccount failed", it) }
            logAudit("UserAccount", account.id, "CREATE", newValue = "employeeProfileId=$employeeProfileId") // never logs the PIN itself, hashed or otherwise
        }
        return AccountCreationResult(true, account.id, "Account created — PIN must be changed on first login.")
    }

    data class PinVerifyResult(val success: Boolean, val locked: Boolean, val mustChangePin: Boolean, val message: String)

    /** Part A — real verify: constant-time-ish compare, real lockout counter persisted in Room, generic failure message (no "PIN wrong" vs "account not found" distinction, Part D anti-enumeration spirit applied here too). */
    suspend fun verifyUserAccountPin(accountId: String, submittedPin: String, deviceId: String?): PinVerifyResult {
        val account = db.userAccountDao().getById(accountId) ?: return PinVerifyResult(false, false, false, "Incorrect PIN.")
        val now = System.currentTimeMillis()
        if (account.locked || (account.lockedUntilEpochMillis != null && account.lockedUntilEpochMillis > now)) {
            db.loginAttemptDao().insert(com.abm.erp.data.room.LoginAttemptEntity(userAccountId = accountId, success = false, deviceId = deviceId, attemptedAtEpochMillis = now))
            return PinVerifyResult(false, true, false, "Account temporarily locked due to repeated failed attempts. Try again later or contact an administrator.")
        }
        val valid = com.abm.erp.auth.PinHashing.verify(submittedPin, account.pinHash, account.pinSalt, account.pinIterations)
        db.loginAttemptDao().insert(com.abm.erp.data.room.LoginAttemptEntity(userAccountId = accountId, success = valid, deviceId = deviceId, attemptedAtEpochMillis = now))
        if (valid) {
            db.userAccountDao().updateLockoutState(accountId, 0, null, false, now)
            return PinVerifyResult(true, false, account.mustChangePinOnNextLogin, "OK")
        }
        val newAttempts = account.failedAttempts + 1
        val shouldLock = newAttempts >= maxFailedAttempts
        db.userAccountDao().updateLockoutState(accountId, newAttempts, if (shouldLock) now + lockoutDurationMillis else null, shouldLock, now)
        if (shouldLock) {
            raiseSecurityEvent("ACCOUNT_LOCKED", account.employeeProfileId, account.employeeProfileId, null, "LOGIN", null, null, null, "Account locked after $maxFailedAttempts failed PIN attempts", severity = "WARNING")
        }
        return PinVerifyResult(false, shouldLock, false, "Incorrect PIN.")
    }

    fun changeUserAccountPin(accountId: String, newPin: String): Boolean {
        if (com.abm.erp.auth.PinHashing.isWeakPin(newPin)) return false
        val hashResult = com.abm.erp.auth.PinHashing.createHash(newPin)
        scope.launch {
            db.userAccountDao().updatePin(accountId, hashResult.hash, hashResult.salt, hashResult.iterations, System.currentTimeMillis(), null)
            logAudit("UserAccount", accountId, "PIN_CHANGED") // never the PIN or its hash
        }
        return true
    }

    /** Part B — suspend/activate/unlock a UserAccount. Admin-tier only. */
    /** Section 13-adjacent — a lower-tier "dealer"-approve admin (GM/AGM included) must never be able to suspend, unlock, or PIN-reset a Chairman/MD's own account; that's a real path to disrupting or effectively taking over the top executive's access. */
    private fun canActOnAccount(accountId: String): Boolean {
        if (currentUser.role == UserRole.CHAIRMAN || currentUser.role == UserRole.MD) return true
        val targetProfile = employeeProfiles.value.firstOrNull { it.userAccountId == accountId }
        return targetProfile?.role != UserRole.CHAIRMAN && targetProfile?.role != UserRole.MD
    }

    fun setUserAccountActive(accountId: String, active: Boolean): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) return false
        if (!canActOnAccount(accountId)) {
            logAudit("UserAccount", accountId, "DENY", oldValue = currentUser.role.name, newValue = "SUSPEND_PRIVILEGED_ACCOUNT")
            return false
        }
        scope.launch {
            db.userAccountDao().setActive(accountId, active, System.currentTimeMillis())
            syncCollection("userAccounts").document(accountId).update("active", active)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push account-active failed", it) }
            logAudit("UserAccount", accountId, if (active) "ACTIVATE" else "SUSPEND")
        }
        return true
    }

    /** Part B — real admin unlock, resets the Room-persisted failed-attempt lockout counter (Part A). */
    fun unlockUserAccount(accountId: String): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) return false
        if (!canActOnAccount(accountId)) {
            logAudit("UserAccount", accountId, "DENY", oldValue = currentUser.role.name, newValue = "UNLOCK_PRIVILEGED_ACCOUNT")
            return false
        }
        scope.launch {
            db.userAccountDao().updateLockoutState(accountId, 0, null, false, System.currentTimeMillis())
            syncCollection("userAccounts").document(accountId).update(mapOf("failedAttempts" to 0, "lockedUntilEpochMillis" to null, "locked" to false))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push account-unlock failed", it) }
            logAudit("UserAccount", accountId, "UNLOCK")
        }
        return true
    }

    /** Part B — admin PIN reset, generates a random temporary PIN and forces change on next login. */
    fun resetUserAccountPin(accountId: String): String? {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.APPROVE)) return null
        if (!canActOnAccount(accountId)) {
            logAudit("UserAccount", accountId, "DENY", oldValue = currentUser.role.name, newValue = "PIN_RESET_PRIVILEGED_ACCOUNT")
            return null
        }
        var tempPin: String
        do { tempPin = (10000..99999).random().toString() } while (com.abm.erp.auth.PinHashing.isWeakPin(tempPin))
        val hashResult = com.abm.erp.auth.PinHashing.createHash(tempPin)
        scope.launch {
            db.userAccountDao().updatePin(accountId, hashResult.hash, hashResult.salt, hashResult.iterations, System.currentTimeMillis(), null)
            val current = db.userAccountDao().getById(accountId)
            if (current != null) db.userAccountDao().upsert(current.copy(mustChangePinOnNextLogin = true))
            logAudit("UserAccount", accountId, "PIN_RESET_BY_ADMIN") // never the PIN itself
        }
        return tempPin
    }

    /** Part J — Dealer legacy zone-string to admin-master matching, same exact/alias/unresolved strategy as retailers (Section 7), never overwriting unresolved values. */
    data class DealerLegacyResolution(val dealerId: String, val dealerName: String, val freeTextZone: String, val matchedDivisionId: String?, val matchedDistrictId: String?, val matchType: String)
    fun resolveLegacyDealerAddresses(): List<DealerLegacyResolution> {
        val divisions = administrativeLocations.value.filter { it.type == "DIVISION" }
        val districts = administrativeLocations.value.filter { it.type == "DISTRICT" }
        fun norm(s: String) = s.trim().lowercase()
        return dealers.value.filter { !it.isDeleted && it.divisionId == null && it.zone.isNotBlank() }.map { d ->
            val exactDiv = divisions.firstOrNull { norm(it.nameEn) == norm(d.zone) }
            val exactDist = districts.firstOrNull { norm(it.nameEn) == norm(d.zone) }
            val aliasDist = exactDist ?: districts.firstOrNull { norm(it.nameEn).contains(norm(d.zone)) || norm(d.zone).contains(norm(it.nameEn)) }
            val matchType = when { exactDiv != null || exactDist != null -> "EXACT"; aliasDist != null -> "ALIAS"; else -> "UNRESOLVED" }
            DealerLegacyResolution(d.id, d.name, d.zone, exactDiv?.id ?: aliasDist?.parentId, exactDist?.id ?: aliasDist?.id, matchType)
        }
    }

    fun confirmDealerLegacyMatch(dealerId: String, divisionId: String?, districtId: String?): Boolean {
        if (!PermissionManager.canCurrentUser("dealer", PermissionAction.EDIT)) return false
        scope.launch {
            val d = dealers.value.firstOrNull { it.id == dealerId } ?: return@launch
            val updated = d.copy(divisionId = divisionId ?: d.divisionId, districtId = districtId ?: d.districtId, legacyAddressResolved = true)
            val entity = updated.toEntity()
            db.dealerDao().upsert(entity)
            syncCollection("dealers").document(dealerId).update(mapOf("divisionId" to entity.divisionId, "districtId" to entity.districtId, "legacyAddressResolved" to true))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push dealer-legacy-resolve failed", it) }
            logAudit("Dealer", dealerId, "LEGACY_ADDRESS_RESOLVED", oldValue = d.zone, newValue = "div=$divisionId,dist=$districtId")
        }
        return true
    }

    // Part M — serializes document-number generation so two near-simultaneous
    // creation calls (e.g. a double-tap before the button disables) cannot
    // read the same count and produce the same human-readable document
    // number. The underlying id (UUID) was always unique; this protects
    // the printed/audited invoiceNo/voucherNo itself.
    private val documentNumberMutex = Mutex()

    /** Part O — real suspend, single fetch of the full ledger (domain-mapped), for any caller that needs to group/filter across many parties at once rather than querying per-party in a loop. */
    suspend fun allPartyLedgerEntriesSuspend(): List<PartyLedgerEntry> = db.partyLedgerDao().getAll().first().map { it.toDomain() }

    /** RC-1 fix — real dealer PIN hashing, same PBKDF2 infra as employee UserAccount. */
    fun setDealerPin(dealerId: String, newPin: String): Boolean {
        if (com.abm.erp.auth.PinHashing.isWeakPin(newPin)) return false
        val hashResult = com.abm.erp.auth.PinHashing.createHash(newPin)
        val d = dealers.value.firstOrNull { it.id == dealerId } ?: return false
        scope.launch {
            val updated = d.copy(pinHash = hashResult.hash, pinSalt = hashResult.salt, pinIterations = hashResult.iterations)
            val entity = updated.toEntity()
            db.dealerDao().upsert(entity)
            syncCollection("dealers").document(dealerId).update(mapOf("pinHash" to entity.pinHash, "pinSalt" to entity.pinSalt, "pinIterations" to entity.pinIterations))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push dealer-pin failed", it) }
            logAudit("Dealer", dealerId, "PIN_SET") // never the PIN or hash
        }
        return true
    }

    /** Real PBKDF2 verify; legacy plaintext "0000"-style dealers (no hash set yet) are rejected outright rather than silently accepted — they must have a PIN set by an admin first. */
    fun verifyDealerPin(dealer: Dealer, submittedPin: String): Boolean {
        if (dealer.pinHash == null || dealer.pinSalt == null) {
            com.abm.erp.config.AppLog.w("MockRepository", "verifyDealerPin rejected: dealer ${dealer.id} has no hashed PIN set — admin must set one first")
            return false
        }
        return com.abm.erp.auth.PinHashing.verify(submittedPin, dealer.pinHash, dealer.pinSalt, dealer.pinIterations)
    }

    /** Phase 6 — Manufacturing HR worker assignment (production line/machine/shift), separate axis from EmployeeAreaAssignment (geography). */
    /** Permission Control Center — real Room+Firestore persistence for a Template (stored as a RoleDefinition row), with full audit. */
    fun savePermissionTemplate(definition: RoleDefinition) {
        scope.launch {
            db.roleDefinitionDao().upsert(definition.toEntity())
            syncCollection("roleDefinitions").document(definition.roleKey).set(definition.toEntity())
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push template failed", it) }
            PermissionManager.updateFromSynced(db.roleDefinitionDao().getAll().first().map { it.toDomain() })
            logAudit("PermissionTemplate", definition.roleKey, "SAVE", newValue = definition)
        }
    }

    fun deletePermissionTemplate(templateKey: String) {
        scope.launch {
            db.roleDefinitionDao().deleteByKey(templateKey)
            syncCollection("roleDefinitions").document(templateKey).delete()
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "delete template failed", it) }
            PermissionManager.updateFromSynced(db.roleDefinitionDao().getAll().first().map { it.toDomain() })
            logAudit("PermissionTemplate", templateKey, "DELETE")
        }
    }

    /** Assigns (or clears, if templateKey is null) a Template to one employee — real audit records who/when/for whom. */
    fun assignPermissionTemplate(employeeId: String, templateKey: String?) {
        if (!com.abm.erp.ABMApplication.isOnlineNow()) {
            logAudit("EmployeeProfile", employeeId, "DENY_OFFLINE", newValue = "Permission Change requires an online connection")
            return
        }
        scope.launch {
            val entity = db.employeeProfileDao().getAll().first().firstOrNull { it.id == employeeId } ?: return@launch
            db.employeeProfileDao().upsert(entity.copy(assignedTemplateKey = templateKey))
            syncCollection("employeeProfiles").document(employeeId).update("assignedTemplateKey", templateKey)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push template-assign failed", it) }
            logAudit("EmployeeProfile", employeeId, "TEMPLATE_ASSIGN", oldValue = entity.assignedTemplateKey, newValue = templateKey, reason = "by ${currentUser.name}")
        }
    }

    fun setEmployeePermissionOverride(employeeId: String, moduleKey: String, accessLevel: AccessLevel) {
        if (!com.abm.erp.ABMApplication.isOnlineNow()) {
            logAudit("EmployeePermissionOverride", employeeId, "DENY_OFFLINE", newValue = "Permission Change requires an online connection")
            return
        }
        scope.launch {
            val existing = db.employeePermissionOverrideDao().getAll().first().firstOrNull { it.employeeId == employeeId && it.moduleKey == moduleKey }
            val override = EmployeePermissionOverride(
                id = existing?.id ?: "OVR-${java.util.UUID.randomUUID().toString().take(8)}", employeeId = employeeId, companyId = currentUser.companyId,
                moduleKey = moduleKey, accessLevel = accessLevel, setBy = currentUser.employeeId, setByName = currentUser.name,
            )
            db.employeePermissionOverrideDao().upsert(override.toEntity())
            syncCollection("employeePermissionOverrides").document(override.id).set(override.toEntity())
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push permission-override failed", it) }
            PermissionManager.updateFromSyncedOverrides(db.employeePermissionOverrideDao().getAll().first().map { it.toDomain() })
            logAudit("EmployeePermissionOverride", employeeId, "SET_OVERRIDE", newValue = "$moduleKey=$accessLevel", reason = "by ${currentUser.name}")
        }
    }

    fun clearEmployeePermissionOverride(employeeId: String, moduleKey: String) {
        scope.launch {
            db.employeePermissionOverrideDao().clear(employeeId, moduleKey)
            syncCollection("employeePermissionOverrides").whereEqualTo("employeeId", employeeId).whereEqualTo("moduleKey", moduleKey).get()
                .addOnSuccessListener { snap -> snap.documents.forEach { it.reference.delete() } }
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "clear permission-override sync failed", it) }
            PermissionManager.updateFromSyncedOverrides(db.employeePermissionOverrideDao().getAll().first().map { it.toDomain() })
            logAudit("EmployeePermissionOverride", employeeId, "CLEAR_OVERRIDE", newValue = moduleKey, reason = "by ${currentUser.name}")
        }
    }

    fun assignManufacturingWorker(
        employeeId: String, manufacturingUnitId: String, productionLine: String?, machine: String?, section: String?,
        shiftType: ShiftType, supervisorEmployeeId: String?, skills: List<ManufacturingSkill>,
    ): Boolean {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) {
            logAudit("ManufacturingWorkerAssignment", employeeId, "DENY", oldValue = currentUser.role.name, newValue = "ASSIGN")
            return false
        }
        val assignment = ManufacturingWorkerAssignment(
            id = "MFGW-${java.util.UUID.randomUUID().toString().take(8)}", employeeId = employeeId, companyId = currentUser.companyId,
            manufacturingUnitId = manufacturingUnitId, productionLine = productionLine, machine = machine, section = section,
            shiftType = shiftType, supervisorEmployeeId = supervisorEmployeeId, skills = skills, assignedBy = currentUser.name,
        )
        scope.launch {
            // Close any previous active assignment for this employee+unit first — one active assignment per employee, matching the same close-then-open pattern as transferEmployeeArea.
            manufacturingWorkerAssignments.value.filter { it.employeeId == employeeId && it.isActive }.forEach {
                db.manufacturingWorkerAssignmentDao().close(it.id, System.currentTimeMillis() / 86_400_000L)
            }
            db.manufacturingWorkerAssignmentDao().upsert(assignment.toEntity())
            syncCollection("manufacturingWorkerAssignments").document(assignment.id).set(assignment.toEntity())
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push mfg-worker-assign failed", it) }
            logAudit("ManufacturingWorkerAssignment", assignment.id, "CREATE", newValue = assignment)
        }
        return true
    }

    /**
     * Phase 3 — assign an area to an employee. Supports PRIMARY/SECONDARY/
     * TEMPORARY simultaneously; a PRIMARY assignment conflicts with any
     * OTHER employee's existing active PRIMARY assignment for the exact
     * same district+upazila+union unless explicitly authorized
     * (allowConflict=true, itself gated to admin-tier).
     */
    fun assignEmployeeArea(
        employeeId: String, divisionId: String?, districtId: String?, upazilaId: String?, unionId: String?,
        marketName: String?, routeId: String?, assignmentType: AreaAssignmentType, endDate: java.time.LocalDate? = null,
        allowConflict: Boolean = false,
    ): Boolean {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) {
            logAudit("EmployeeAreaAssignment", employeeId, "DENY", oldValue = currentUser.role.name, newValue = "ASSIGN_AREA")
            return false
        }
        if (assignmentType == AreaAssignmentType.PRIMARY && !allowConflict) {
            val conflict = employeeAreaAssignments.value.firstOrNull {
                it.isActive && it.employeeId != employeeId && it.assignmentType == AreaAssignmentType.PRIMARY &&
                    it.districtId == districtId && it.upazilaId == upazilaId && it.unionId == unionId && districtId != null
            }
            if (conflict != null) {
                if (!PermissionManager.canCurrentUser("hr", PermissionAction.CREATE) || currentUser.role !in setOf(UserRole.GM, UserRole.AGM, UserRole.CHAIRMAN, UserRole.MD)) {
                    com.abm.erp.config.AppLog.w("MockRepository", "assignEmployeeArea rejected: primary assignment conflicts with existing employee ${conflict.employeeId} — needs explicit authorization")
                    return false
                }
            }
        }
        val locs = administrativeLocations.value.associateBy { it.id }
        val assignment = EmployeeAreaAssignment(
            id = "AREA-${java.util.UUID.randomUUID().toString().take(8)}", employeeId = employeeId, companyId = currentUser.companyId,
            divisionId = divisionId, divisionName = locs[divisionId]?.nameEn, districtId = districtId, districtName = locs[districtId]?.nameEn,
            upazilaId = upazilaId, upazilaName = locs[upazilaId]?.nameEn, unionId = unionId, unionName = locs[unionId]?.nameEn,
            marketName = marketName, routeId = routeId, assignmentType = assignmentType, endDate = endDate, assignedBy = currentUser.name,
        )
        scope.launch {
            db.employeeAreaAssignmentDao().upsert(assignment.toEntity())
            syncCollection("employeeAreaAssignments").document(assignment.id).set(assignment.toEntity())
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push area-assignment failed", it) }
            // Keep EmployeeProfile.territoryId as the quick-reference primary, without breaking anything that already reads it.
            if (assignmentType == AreaAssignmentType.PRIMARY) {
                val emp = employeeProfiles.value.firstOrNull { it.id == employeeId }
                if (emp != null) {
                    val entity = emp.copy(territoryId = routeId ?: districtId).toEntity()
                    db.employeeProfileDao().upsert(entity)
                    syncCollection("employeeProfiles").document(employeeId).update("territoryId", entity.territoryId)
                        .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push employee-territory failed", it) }
                }
            }
            logAudit("EmployeeAreaAssignment", assignment.id, "CREATE", newValue = assignment)
        }
        return true
    }

    /**
     * Phase 3 — transfer: close the previous PRIMARY assignment (preserved
     * in history, never deleted) and open a new one. Historical sales
     * ownership is untouched since invoices/orders reference the employee
     * id directly, not the assignment row.
     */
    fun transferEmployeeArea(
        employeeId: String, newDivisionId: String?, newDistrictId: String?, newUpazilaId: String?, newUnionId: String?,
        newMarketName: String?, newRouteId: String?,
    ): Boolean {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) {
            logAudit("EmployeeAreaAssignment", employeeId, "DENY", oldValue = currentUser.role.name, newValue = "TRANSFER_AREA")
            return false
        }
        scope.launch {
            val today = System.currentTimeMillis() / 86_400_000L
            employeeAreaAssignments.value.filter { it.employeeId == employeeId && it.isActive && it.assignmentType == AreaAssignmentType.PRIMARY }
                .forEach { old -> db.employeeAreaAssignmentDao().close(old.id, today); logAudit("EmployeeAreaAssignment", old.id, "CLOSE_FOR_TRANSFER") }
        }
        return assignEmployeeArea(employeeId, newDivisionId, newDistrictId, newUpazilaId, newUnionId, newMarketName, newRouteId, AreaAssignmentType.PRIMARY, allowConflict = true)
    }

    /** Phase 3 — real vacancy status for a district+upazila+union combination, not a placeholder. */
    fun territoryAssignmentStatus(districtId: String?, upazilaId: String?, unionId: String?): AreaAssignmentStatus {
        val matches = employeeAreaAssignments.value.filter { it.isActive && it.districtId == districtId && it.upazilaId == upazilaId && it.unionId == unionId }
        if (matches.isEmpty()) return AreaAssignmentStatus.VACANT
        val hasPrimary = matches.any { it.assignmentType == AreaAssignmentType.PRIMARY }
        val hasTemp = matches.any { it.assignmentType == AreaAssignmentType.TEMPORARY }
        return when {
            hasPrimary -> AreaAssignmentStatus.ASSIGNED
            hasTemp -> AreaAssignmentStatus.TEMPORARILY_COVERED
            else -> AreaAssignmentStatus.INACTIVE
        }
    }

    fun assignOutletToRoute(routeId: String, retailerId: String) {
        scope.launch {
            val route = salesRoutes.value.firstOrNull { it.id == routeId } ?: return@launch
            val updated = route.copy(outletIds = route.outletIds + retailerId)
            val entity = updated.toEntity()
            db.salesRouteDao().upsert(entity)
            syncCollection("salesRoutes").document(routeId).update("outletIdsRaw", entity.outletIdsRaw)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push route-assign failed", it) }
            logAudit("SalesRoute", routeId, "UPDATE", newValue = "added outlet $retailerId")
        }
    }

    // ---- Visit History (Module 7/8/9 — Dealer/Outlet Visit History) ----
    /**
     * v89 fix — this function used to only store the bare lat/lng and a
     * cosmetic "far from outlet" text annotation. The full VisitLog schema
     * (accuracy, provider, mock-suspicion, distance, verification
     * score/result, device, route) and the DAO methods to populate it
     * (setCheckInVerification, activeVisitForEmployee) already existed
     * from a prior pass in this foundation, but nothing actually called
     * them — this is that missing orchestration.
     */
    suspend fun recordVisitCheckIn(
        partyType: PartyType, partyId: String, lat: Double, lng: Double, photoUri: String? = null,
        purpose: String = "Routine visit", accuracyMeters: Float? = null, provider: String? = null,
        mockSuspected: Boolean = false, deviceId: String? = null, routeId: String? = null,
        allowMultipleActive: Boolean = false,
    ): VisitLog? {
        if (!LocationVerification.isValidCoordinate(lat, lng)) {
            com.abm.erp.config.AppLog.w("MockRepository", "recordVisitCheckIn rejected: invalid coordinate ($lat, $lng)")
            return null
        }
        // Foundation 4, Section 5 — Retailer Visit Enforcement: territory/geo-lock validation before check-in proceeds.
        val geoLockResult = validateFieldAction(currentUser.employeeId, "VISIT", lat, lng, accuracyMeters, mockSuspected)
        if (partyType == PartyType.RETAILER) checkRouteCompliance(currentUser.employeeId, partyId)
        if (geoLockResult.decision == GeoLock.AccessDecision.BLOCKED) {
            com.abm.erp.config.AppLog.w("MockRepository", "recordVisitCheckIn rejected by geo-lock: ${geoLockResult.reasons.joinToString()}")
            return null
        }
        // Section 6/29 — "Duplicate visit check-in" / "conflicting active
        // visits" prevention. Checked synchronously against Room so the
        // caller gets a real answer before creating a second active visit.
        if (!allowMultipleActive) {
            val active = db.visitLogDao().activeVisitForEmployee(currentUser.employeeId)
            if (active != null) {
                com.abm.erp.config.AppLog.w("MockRepository", "recordVisitCheckIn rejected: employee already has an active visit (${active.id}), check out first")
                return null
            }
        }
        val retailer = if (partyType == PartyType.RETAILER) retailers.value.firstOrNull { it.id == partyId } else null
        val isAssigned = retailer?.officerId == null || retailer.officerId == currentUser.employeeId
        val distance = if (retailer?.lat != null && retailer.lng != null) LocationVerification.distanceMeters(retailer.lat, retailer.lng, lat, lng) else null
        val scoreInput = LocationVerification.VerificationScoreInput(
            accuracyMeters = accuracyMeters, distanceFromRetailerMeters = distance,
            visitRadiusMeters = retailerGeofenceRadius(retailer), ageSeconds = 0, mockSuspected = mockSuspected,
            isAssignedRetailer = isAssigned, isScheduledVisit = routeId != null,
        )
        val verification = LocationVerification.computeVisitVerification(scoreInput)
        val annotatedPurpose = if (verification.result == LocationVerification.VisitVerificationResult.OUTSIDE_RADIUS) "$purpose ⚠ outlet-এর নিবন্ধিত অবস্থান থেকে দূরে" else purpose
        val visit = VisitLog(
            id = java.util.UUID.randomUUID().toString(), partyType = partyType, partyId = partyId,
            employeeId = currentUser.employeeId, employeeName = currentUser.name, lat = lat, lng = lng,
            photoUri = photoUri, purpose = annotatedPurpose, routeId = routeId,
            checkInAccuracyMeters = accuracyMeters, checkInProvider = provider, checkInMockSuspected = mockSuspected,
            checkInDistanceFromRetailerMeters = distance, deviceId = deviceId,
            verificationResult = verification.result.name, verificationScore = verification.score,
        )
        scope.launch {
            val entity = visit.toEntity()
            db.visitLogDao().upsert(entity)
            syncCollection("visitLogs").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push visitLog failed", it) }
            logAudit("Visit", visit.id, "CHECK_IN", newValue = visit, reason = verification.reasons.joinToString("; "))
            if (mockSuspected || verification.result == LocationVerification.VisitVerificationResult.MOCK_LOCATION_SUSPECTED) {
                raiseLocationAlert("MOCK_LOCATION_SUSPECTED", currentUser.employeeId, partyId, "Check-in at ${retailer?.name ?: partyId} flagged: ${verification.reasons.joinToString()}")
            } else if (verification.result == LocationVerification.VisitVerificationResult.OUTSIDE_RADIUS) {
                raiseLocationAlert("OUTSIDE_RADIUS_VISIT", currentUser.employeeId, partyId, "Check-in ${distance?.toInt()}m from ${retailer?.name ?: partyId} (radius ${retailerGeofenceRadius(retailer).toInt()}m)")
            }
        }
        return visit
    }



    /**
     * v89 fix — this only flipped a bare timestamp before. Section 6 needs
     * the full checkout picture: location, accuracy, mock-suspicion,
     * distance, and a real verification result — all via the already-built
     * setFullCheckOut DAO method that nothing was calling yet.
     */
    fun recordVisitCheckOut(visitId: String, lat: Double, lng: Double, accuracyMeters: Float? = null, mockSuspected: Boolean = false, notes: String = ""): Boolean {
        if (!LocationVerification.isValidCoordinate(lat, lng)) {
            com.abm.erp.config.AppLog.w("MockRepository", "recordVisitCheckOut rejected: invalid coordinate")
            return false
        }
        val visit = visitLogs.value.firstOrNull { it.id == visitId } ?: return false
        if (visit.checkOutAt != null) {
            com.abm.erp.config.AppLog.w("MockRepository", "recordVisitCheckOut rejected: already checked out (duplicate checkout)")
            return false
        }
        val now = LocalDateTime.now()
        if (now.isBefore(visit.checkInAt)) {
            // Section 29 — "Impossible timestamp sequence" / checkout-before-checkin can't happen from a real device clock, but a corrected/manual entry could produce it; refuse rather than store a negative duration.
            com.abm.erp.config.AppLog.w("MockRepository", "recordVisitCheckOut rejected: checkout time is before check-in time")
            return false
        }
        val retailer = if (visit.partyType == PartyType.RETAILER) retailers.value.firstOrNull { it.id == visit.partyId } else null
        val distance = if (retailer?.lat != null && retailer.lng != null) LocationVerification.distanceMeters(retailer.lat, retailer.lng, lat, lng) else null
        val scoreInput = LocationVerification.VerificationScoreInput(
            accuracyMeters = accuracyMeters, distanceFromRetailerMeters = distance,
            visitRadiusMeters = retailerGeofenceRadius(retailer), ageSeconds = 0, mockSuspected = mockSuspected,
            isAssignedRetailer = retailer?.officerId == null || retailer.officerId == visit.employeeId,
            isScheduledVisit = visit.routeId != null,
        )
        val verification = LocationVerification.computeVisitVerification(scoreInput)
        scope.launch {
            val nowMillis = now.toInstant(ZoneOffset.UTC).toEpochMilli()
            db.visitLogDao().setFullCheckOut(visitId, nowMillis, lat, lng, accuracyMeters, mockSuspected, distance, verification.result.name, verification.score)
            if (notes.isNotBlank()) {
                db.visitLogDao().setNotes(visitId, notes)
                syncCollection("visitLogs").document(visitId).update("notes", notes)
                    .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push visit-notes failed", it) }
            }
            syncCollection("visitLogs").document(visitId).update(
                mapOf(
                    "checkOutAtEpochMillis" to nowMillis, "checkOutLat" to lat, "checkOutLng" to lng,
                    "checkOutAccuracyMeters" to accuracyMeters, "checkOutMockSuspected" to mockSuspected,
                    "checkOutDistanceFromRetailerMeters" to distance, "verificationResult" to verification.result.name, "verificationScore" to verification.score,
                ),
            ).addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push visit-checkout failed", it) }
            logAudit("Visit", visitId, "CHECK_OUT", newValue = "${verification.result} (score ${verification.score})", reason = verification.reasons.joinToString("; "))
            if (mockSuspected) raiseLocationAlert("MOCK_LOCATION_SUSPECTED", visit.employeeId, visit.partyId, "Check-out at ${retailer?.name ?: visit.partyId} flagged mock location")
        }
        return true
    }

    // ---- POS Billing (Module 4) — walk-in sale, reuses the unified invoices table with type="POS" ----
    fun createPosSale(customerName: String, lineItems: List<SalesInvoiceLineItem>): Boolean {
        if (!PermissionManager.canCurrentUser("bill", PermissionAction.CREATE)) {
            logAudit("PosSale", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return false
        }
        scope.launch {
            val invoiceNo = generateNumber("INVOICE", branchCode = "POS")
            val entity = InvoiceEntity(
                id = java.util.UUID.randomUUID().toString(), invoiceNo = invoiceNo, type = "POS",
                dealerId = "", dealerName = customerName.ifBlank { "Walk-in Customer" }, dealerZone = currentUser.zone,
                lineItemsRaw = Converters.packSalesInvoiceItems(lineItems), status = "PAID", // POS sales are paid at the counter, unlike dealer credit invoices
                createdBy = currentUser.name, createdAtEpochMillis = System.currentTimeMillis(),
            )
            db.invoiceDao().upsert(entity)
            syncCollection("salesInvoices").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push POS sale failed", it) }
            logAudit("PosSale", invoiceNo, "CREATE", newValue = entity)
        }
        return true
    }

    // ---- Geotagged CRM ----
    lateinit var routes: StateFlow<List<FieldEmployeeRoute>>
        private set

    /**
     * Module 9 (SFA) — Geo-Fencing / Distance Validation: haversine
     * great-circle distance in meters between two lat/lng points. Used to
     * check a field visit actually happened near the outlet's registered
     * location, rather than trusting the GPS tag blindly.
     */
    fun distanceMeters(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val earthRadiusMeters = 6_371_000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lng2 - lng1)
        val a = kotlin.math.sin(dLat / 2) * kotlin.math.sin(dLat / 2) +
            kotlin.math.cos(Math.toRadians(lat1)) * kotlin.math.cos(Math.toRadians(lat2)) *
            kotlin.math.sin(dLng / 2) * kotlin.math.sin(dLng / 2)
        val c = 2 * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1 - a))
        return earthRadiusMeters * c
    }

    /** True if a check-in point falls within radiusMeters of the outlet's registered GPS — the "Geo Fencing" / "Distance Validation" check. Returns true (never blocks) if the outlet has no registered location yet. */
    /** Section 11 — real retailer-specific radius override, falling back to the company default rather than a hardcoded number scattered everywhere. */
    fun retailerGeofenceRadius(retailer: Retailer?): Double = retailer?.geofenceRadiusMeters ?: businessRuleDouble("ATTENDANCE_RADIUS_M", LocationVerification.Thresholds().defaultVisitRadiusMeters)

    /** Section 21 — real location alert, reusing the existing notification system per the spec's explicit instruction ("Use existing notification system"), plus a persisted LocationAlertEntity record for Section 20's manager review queue. */
    fun raiseLocationAlert(type: String, employeeId: String, retailerId: String?, message: String, severity: String = "WARNING") {
        scope.launch {
            val entity = com.abm.erp.data.room.LocationAlertEntity(
                id = java.util.UUID.randomUUID().toString(), type = type, employeeId = employeeId, retailerId = retailerId,
                message = message, severity = severity, isReviewed = false, createdAtEpochMillis = System.currentTimeMillis(),
            )
            db.locationAlertDao().upsert(entity)
            syncCollection("locationAlerts").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push locationAlert failed", it) }
            createNotification(NotificationCategory.APPROVAL, "Location Alert: $type", message)
        }
    }

    fun isWithinGeoFence(partyLat: Double?, partyLng: Double?, checkLat: Double, checkLng: Double, radiusMeters: Double = 200.0): Boolean {
        if (partyLat == null || partyLng == null) return true
        return distanceMeters(partyLat, partyLng, checkLat, checkLng) <= radiusMeters
    }

    lateinit var campaigns: StateFlow<List<EngagementCampaign>>
        private set

    fun broadcastCampaign(channel: CampaignChannel, message: String, zone: String) {
        // Part S — sentCount used to be a fabricated (40..200).random()
        // value, i.e. a fake metric presented as if real. Now the actual
        // count of active dealers in the target zone this broadcast would
        // reach — real ERP data, not a simulated number.
        val realSentCount = dealers.value.count { !it.isDeleted && it.zone.equals(zone, ignoreCase = true) }
        scope.launch {
            val entity = EngagementCampaignEntity(
                id = java.util.UUID.randomUUID().toString(),
                channel = channel.name,
                message = message,
                targetZone = zone,
                sentCount = realSentCount,
            )
            db.engagementCampaignDao().upsert(entity)
            pushCampaign(entity)
        }
    }

    /** Appends one real GPS fix to the employee's route for today. Called every ~15s while live tracking is on. */
    fun recordGpsPing(employeeId: String, employeeName: String, lat: Double, lng: Double, spoofed: Boolean) {
        scope.launch {
            val today = LocalDate.now().toEpochDay()
            val existing = db.fieldEmployeeRouteDao().getForEmployeeAndDate(employeeId, today)
            val existingBreadcrumbs = existing?.let { Converters.unpackBreadcrumbs(it.breadcrumbsRaw) } ?: emptyList()
            // Attendance Exception — notify only on the FIRST spoofed ping of the day per employee, not every ping (PresenceHeartbeatService pings every 30-60 min; notifying each time would spam the inbox).
            if (spoofed && existingBreadcrumbs.none { it.spoofed }) {
                createNotification(NotificationCategory.ATTENDANCE, "GPS Spoofing Detected", "$employeeName — mock location detected during duty hours")
            }
            val updated = existingBreadcrumbs + GpsPing(lat, lng, LocalDateTime.now(), spoofed)
            db.fieldEmployeeRouteDao().upsertAll(
                listOf(
                    FieldEmployeeRouteEntity(
                        employeeId = employeeId,
                        employeeName = employeeName,
                        dateEpochDay = today,
                        breadcrumbsRaw = Converters.packBreadcrumbs(updated),
                    )
                )
            )
        }
    }

    /**
     * Called by PresenceHeartbeatService (background, every 30-60 min) and
     * also usable for the "Login = Auto Attendance" first-check-of-the-day
     * case. Records a breadcrumb (reusing recordGpsPing) AND marks today's
     * attendance valid if the fix falls within the employee's assigned
     * division (using the same approximate check as the login-time anomaly
     * alert) — this is what payroll's absencePenalty ultimately reads.
     */
    suspend fun recordPresenceCheckIn(employeeId: String, employeeName: String, lat: Double, lng: Double, spoofed: Boolean, accuracyMeters: Float? = null) {
        recordGpsPing(employeeId, employeeName, lat, lng, spoofed)
        // Foundation 4, Section 4 — Attendance Validation.
        val geoLockResult = validateFieldAction(employeeId, "ATTENDANCE", lat, lng, accuracyMeters, spoofed)
        scope.launch {
            val demoDivision = EMPLOYEE_DIRECTORY.firstOrNull { it.id == employeeId }?.geo?.division
            val realProfile = employeeProfiles.value.firstOrNull { it.id == employeeId }
            val realDivision = realProfile?.divisionId?.let { id -> administrativeLocations.value.firstOrNull { it.id == id }?.nameEn }
            val division = demoDivision ?: realDivision
            val withinArea = !spoofed && !com.abm.erp.util.LocationAnomalyChecker.isAnomalous(division, lat, lng) && geoLockResult.decision != GeoLock.AccessDecision.BLOCKED
            // Late Entry detection — was completely missing before (shiftType="LATE" was never set anywhere in the codebase, so punctualityLateDays always silently read 0). Standard shift start is 9:00 AM; the grace period itself is a real Section 9 Business Rule (LATE_ENTRY_GRACE_MIN), Chairman-configurable.
            val graceMinutes = businessRuleDouble("LATE_ENTRY_GRACE_MIN", 30.0).toLong()
            val now = LocalDateTime.now()
            val shiftStartToday = now.toLocalDate().atTime(9, 0)
            val isLate = now.isAfter(shiftStartToday.plusMinutes(graceMinutes))
            val record = AttendanceRecordEntity(
                employeeId = employeeId, dateEpochDay = LocalDate.now().toEpochDay(),
                checkedIn = true, gpsValid = withinArea, shiftType = if (isLate) "LATE" else "GENERAL",
                checkInEpochMillis = System.currentTimeMillis(), isLate = isLate,
            )
            db.attendanceDao().upsert(record)
            pushAttendance(record)
        }
    }

    /** Factory HR — real attendance check-out, previously completely missing (only recordVisitCheckOut existed, which is for retailer/dealer VISITS, not daily employee attendance). Computes real overtime from the gap between check-in and check-out beyond the standard shift length (configurable via Business Rule STANDARD_SHIFT_HOURS, default 8h). */
    suspend fun recordAttendanceCheckOut(employeeId: String, lat: Double, lng: Double, spoofed: Boolean, accuracyMeters: Float? = null) {
        recordGpsPing(employeeId, employeeId, lat, lng, spoofed)
        val geoLockResult = validateFieldAction(employeeId, "ATTENDANCE", lat, lng, accuracyMeters, spoofed)
        scope.launch {
            val today = LocalDate.now().toEpochDay()
            val existing = db.attendanceDao().getAllForEmployee(employeeId).first().firstOrNull { it.dateEpochDay == today && it.checkedIn }
            if (existing == null) {
                com.abm.erp.config.AppLog.w("MockRepository", "recordAttendanceCheckOut: no check-in found for today, ignoring")
                return@launch
            }
            if (existing.checkOutEpochMillis > 0) {
                com.abm.erp.config.AppLog.w("MockRepository", "recordAttendanceCheckOut: already checked out today, ignoring duplicate")
                return@launch
            }
            val demoDivision = EMPLOYEE_DIRECTORY.firstOrNull { it.id == employeeId }?.geo?.division
            val realProfile = employeeProfiles.value.firstOrNull { it.id == employeeId }
            val realDivision = realProfile?.divisionId?.let { id -> administrativeLocations.value.firstOrNull { it.id == id }?.nameEn }
            val division = demoDivision ?: realDivision
            val checkOutValid = !spoofed && !com.abm.erp.util.LocationAnomalyChecker.isAnomalous(division, lat, lng) && geoLockResult.decision != GeoLock.AccessDecision.BLOCKED
            val checkOutMillis = System.currentTimeMillis()
            val standardShiftMinutes = (businessRuleDouble("STANDARD_SHIFT_HOURS", 8.0) * 60).toLong()
            val workedMinutes = if (existing.checkInEpochMillis > 0) (checkOutMillis - existing.checkInEpochMillis) / 60000 else 0L
            val overtimeMinutes = (workedMinutes - standardShiftMinutes).coerceAtLeast(0L).toInt()
            val updated = existing.copy(checkOutEpochMillis = checkOutMillis, checkOutGpsValid = checkOutValid, overtimeMinutes = overtimeMinutes)
            db.attendanceDao().upsert(updated)
            pushAttendance(updated)
            logAudit("AttendanceRecord", "$employeeId-$today", "CHECK_OUT", newValue = "overtimeMinutes=$overtimeMinutes")
        }
    }

    /**
     * The "daily absence sweep" — triggered when Payroll opens (lazy, not a
     * true midnight cron job, since exact-alarm background scheduling on
     * Android has real battery-optimization friction; this is the more
     * reliable trade-off for this stage). For each payroll line, gap-fills
     * the last 30 days: any day with no attendance record at all becomes an
     * explicit "absent" one, then unapprovedAbsenceDays is recomputed from
     * real data — this is what finally makes payroll's automatic deduction
     * (netPayable's absencePenalty) reflect actual attendance instead of
     * static seed numbers.
     */
    fun refreshPayrollAbsences() {
        scope.launch {
            val today = LocalDate.now().toEpochDay()
            val cycleStart = today - 30
            payroll.value.forEach { line ->
                for (day in cycleStart until today) {
                    if (db.attendanceDao().getForDay(line.employeeId, day) == null) {
                        val record = AttendanceRecordEntity(employeeId = line.employeeId, dateEpochDay = day, checkedIn = false, gpsValid = false)
                        db.attendanceDao().upsert(record)
                        pushAttendance(record)
                    }
                }
                val absences = db.attendanceDao().countAbsences(line.employeeId)
                val presentDays = db.attendanceDao().countPresentDays(line.employeeId)
                val overtimeMinutesTotal = db.attendanceDao().sumOvertimeMinutes(line.employeeId)
                // Real overtime rate — standard OT multiplier (1.5x hourly-equivalent-of-dailyWage), configurable via Business Rule.
                val hourlyRate = line.dailyWage / 8.0
                val otMultiplier = businessRuleDouble("OVERTIME_RATE_MULTIPLIER", 1.5)
                val overtimePay = (overtimeMinutesTotal / 60.0) * hourlyRate * otMultiplier
                db.payrollDao().updateAbsenceDays(line.employeeId, absences)
                db.payrollDao().updateAttendanceStats(line.employeeId, overtimeMinutesTotal, overtimePay, presentDays, absences)
                db.payrollDao().getAll().first().firstOrNull { it.employeeId == line.employeeId }?.let { pushPayroll(it) }
            }
        }
    }

    data class FactoryAttendanceRow(
        val employeeId: String, val employeeName: String, val manufacturingUnitId: String, val section: String?,
        val productionLine: String?, val machine: String?, val shiftType: ShiftType, val supervisorEmployeeId: String?,
        val checkedIn: Boolean, val isLate: Boolean, val isOnLeave: Boolean, val checkInTime: LocalDateTime?, val checkOutTime: LocalDateTime?, val overtimeMinutes: Int,
    )

    /** Factory HR — real report joining ManufacturingWorkerAssignment (unit/section/line/machine/shift/supervisor) with actual attendance for one date. Any filter left null returns all matching workers for that dimension. */
    /** Real present/absent-day totals for one employee — used by the Universal Scanner's Employee detail card. */
    suspend fun attendanceSummary(employeeId: String): Pair<Int, Int> =
        db.attendanceDao().countPresentDays(employeeId) to db.attendanceDao().countAbsences(employeeId)

    suspend fun computeFactoryAttendanceReport(
        date: LocalDate, manufacturingUnitId: String? = null, section: String? = null,
        productionLine: String? = null, machine: String? = null, shiftType: ShiftType? = null, supervisorEmployeeId: String? = null,
    ): List<FactoryAttendanceRow> {
        val epochDay = date.toEpochDay()
        val assignments = manufacturingWorkerAssignments.value.filter { a ->
            a.isActive &&
                (manufacturingUnitId == null || a.manufacturingUnitId == manufacturingUnitId) &&
                (section == null || a.section == section) &&
                (productionLine == null || a.productionLine == productionLine) &&
                (machine == null || a.machine == machine) &&
                (shiftType == null || a.shiftType == shiftType) &&
                (supervisorEmployeeId == null || a.supervisorEmployeeId == supervisorEmployeeId)
        }
        return assignments.map { a ->
            val emp = employeeProfiles.value.firstOrNull { it.id == a.employeeId }
            val record = db.attendanceDao().getForDay(a.employeeId, epochDay)
            FactoryAttendanceRow(
                employeeId = a.employeeId, employeeName = emp?.fullName ?: a.employeeId, manufacturingUnitId = a.manufacturingUnitId,
                section = a.section, productionLine = a.productionLine, machine = a.machine, shiftType = a.shiftType, supervisorEmployeeId = a.supervisorEmployeeId,
                checkedIn = record?.checkedIn == true, isLate = record?.isLate == true, isOnLeave = record?.isOnLeave == true,
                checkInTime = record?.checkInEpochMillis?.takeIf { it > 0 }?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
                checkOutTime = record?.checkOutEpochMillis?.takeIf { it > 0 }?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
                overtimeMinutes = record?.overtimeMinutes ?: 0,
            )
        }
    }

    // ---- HRM & Payroll ----
    lateinit var payroll: StateFlow<List<PayrollLine>>
        private set

    // ---- Module 12: HR & Payroll extras — Leave / Increment / Promotion / Transfer / Exit ----
    lateinit var leaveRequests: StateFlow<List<LeaveRequest>>
        private set
    lateinit var employeeLifecycleEvents: StateFlow<List<EmployeeLifecycleEvent>>
        private set

    /**
     * v86, Module 10 — Leave Balance. Computed live (no new field/schema),
     * since Employee is a compiled-in directory object, not a persisted,
     * per-employee-mutable record — a stored "balance" field on it would
     * never actually decrement. Standard entitlement is a documented
     * assumption (14 Casual / 14 Sick / 10 Earned per calendar year), not
     * fabricated per-employee data; taken-days come from real APPROVED
     * LeaveRequest records for the current year only.
     */
    /** v86 - Shift Planning: upserts (not just UPDATE) so a shift can be planned ahead of an employee's check-in existing for that day — real pre-creation, not dependent on attendance already existing. */
    fun planShift(employeeId: String, dateEpochDay: Long, shiftType: ShiftType) {
        scope.launch {
            val existing = db.attendanceDao().getForDay(employeeId, dateEpochDay)
            val record = existing?.copy(shiftType = shiftType.name) ?: com.abm.erp.data.room.AttendanceRecordEntity(employeeId = employeeId, dateEpochDay = dateEpochDay, shiftType = shiftType.name)
            db.attendanceDao().upsert(record)
            logAudit("Attendance", "$employeeId|$dateEpochDay", "SHIFT_PLANNED", newValue = shiftType.name)
        }
    }

    /**
     * v86 fix — EMPLOYEE_DIRECTORY.target/achieved are hardcoded demo
     * numbers (every SR gets the exact same 480,000/410,000 regardless of
     * district — see buildEmployeeDirectory in OrgDirectory.kt). This
     * computes REAL month-to-date achieved sales from actual SalesInvoice
     * records matched by createdBy, for the Dashboard to use instead.
     * Target still comes from PayrollLine when one exists for this
     * employee (real per-employee number, even though PayrollLine itself
     * is currently seed data) — returns null rather than a fabricated
     * number when no PayrollLine record exists for them.
     */
    fun realAchievedSalesThisMonth(employeeName: String): Double {
        val monthStart = LocalDateTime.now().withDayOfMonth(1).toLocalDate().atStartOfDay()
        return salesInvoices.value.filter { !it.isDeleted && it.createdBy == employeeName && it.createdAt.isAfter(monthStart) }.sumOf { it.total }
    }

    fun realTargetFor(employeeName: String): Double? = payroll.value.firstOrNull { it.employeeName == employeeName }?.targetAmount

    /** v86 - Department/Designation hierarchy: real EMPLOYEE_DIRECTORY grouped by role tier (this codebase's org model is role-based, not department-based — SR/TSM/ASM/.../CHAIRMAN IS the real hierarchy, not fabricated). */
    fun roleHierarchy(): List<Pair<UserRole, List<Employee>>> =
        UserRole.values().map { role -> role to EMPLOYEE_DIRECTORY.filter { it.role == role } }.filter { it.second.isNotEmpty() }

    fun leaveBalance(employeeId: String, type: LeaveType): Int {
        val entitlement = when (type) { LeaveType.CASUAL -> 14; LeaveType.SICK -> 14; LeaveType.EARNED -> 10; LeaveType.UNPAID -> Int.MAX_VALUE }
        if (entitlement == Int.MAX_VALUE) return Int.MAX_VALUE
        val thisYear = LocalDateTime.now().year
        val takenDays = leaveRequests.value
            .filter { it.employeeId == employeeId && it.type == type && it.status == LeaveStatus.APPROVED && it.fromDate.year == thisYear }
            .sumOf { (it.toDate.toEpochDay() - it.fromDate.toEpochDay() + 1).toInt() }
        return (entitlement - takenDays).coerceAtLeast(0)
    }

    fun applyLeave(employeeId: String, employeeName: String, type: LeaveType, fromDate: LocalDate, toDate: LocalDate, reason: String): LeaveRequest? {
        if (toDate.isBefore(fromDate)) return null
        val leave = LeaveRequest(id = java.util.UUID.randomUUID().toString(), employeeId = employeeId, employeeName = employeeName, type = type, fromDate = fromDate, toDate = toDate, reason = reason)
        scope.launch {
            val entity = leave.toEntity()
            db.leaveRequestDao().upsert(entity)
            syncCollection("leaveRequests").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push leaveRequest failed", it) }
            logAudit("LeaveRequest", leave.id, "CREATE", newValue = leave)
            createNotification(NotificationCategory.LEAVE, "Leave Applied", "${leave.employeeName}: ${leave.type} ${leave.fromDate} → ${leave.toDate}")
        }
        return leave
    }

    /** Approving/rejecting leave needs the same tier as any other approval — enforced here, not just hidden in the UI. */
    fun setLeaveStatus(id: String, status: LeaveStatus): Boolean {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) {
            logAudit("LeaveRequest", id, "DENY", oldValue = currentUser.role.name, newValue = status)
            return false
        }
        val leave = leaveRequests.value.firstOrNull { it.id == id }
        if (leave == null || leave.status != LeaveStatus.PENDING) {
            logAudit("LeaveRequest", id, "DENY", oldValue = leave?.status?.name ?: "not found", newValue = "$status — already processed")
            return false
        }
        scope.launch {
            db.leaveRequestDao().setStatus(id, status.name)
            syncCollection("leaveRequests").document(id).update("status", status.name)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push leave-status failed", it) }
            logAudit("LeaveRequest", id, if (status == LeaveStatus.APPROVED) "APPROVE" else "REJECT")
            if (leave != null) createNotification(NotificationCategory.LEAVE, "Leave ${status.name}", leave.employeeName, leave.employeeId)
            // Real leave→attendance linkage — was completely missing before: an approved leave day had no effect on attendance, so it would have been silently counted as an unapproved absence in payroll.
            if (leave != null && status == LeaveStatus.APPROVED) {
                var d = leave.fromDate
                while (!d.isAfter(leave.toDate)) {
                    val epochDay = d.toEpochDay()
                    val existingRecord = db.attendanceDao().getAllForEmployee(leave.employeeId).first().firstOrNull { it.dateEpochDay == epochDay }
                    val updated = (existingRecord ?: AttendanceRecordEntity(employeeId = leave.employeeId, dateEpochDay = epochDay))
                        .copy(isOnLeave = true, leaveApprovalRequestId = leave.id)
                    db.attendanceDao().upsert(updated)
                    pushAttendance(updated)
                    d = d.plusDays(1)
                }
            }
        }
        return true
    }

    /** Increment / Promotion / Transfer / Exit — one shared recorder, distinguished by `type`, matching EmployeeLifecycleEvent's own doc comment. Admin-tier action (same as Reset PIN / Force Logout). */
    fun recordLifecycleEvent(employeeId: String, employeeName: String, type: String, oldValue: String, newValue: String, effectiveDate: LocalDate, notes: String): Boolean {
        if (!PermissionManager.canCurrentUser("hr", PermissionAction.APPROVE)) {
            logAudit("EmployeeLifecycleEvent", employeeId, "DENY", oldValue = currentUser.role.name, newValue = type)
            return false
        }
        val event = EmployeeLifecycleEvent(
            id = java.util.UUID.randomUUID().toString(), employeeId = employeeId, employeeName = employeeName, type = type,
            oldValue = oldValue, newValue = newValue, effectiveDate = effectiveDate, notes = notes, recordedBy = currentUser.name,
        )
        scope.launch {
            val entity = event.toEntity()
            db.employeeLifecycleEventDao().upsert(entity)
            syncCollection("employeeLifecycleEvents").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push lifecycleEvent failed", it) }
            logAudit("EmployeeLifecycleEvent", employeeName, type, oldValue = oldValue, newValue = newValue)
        }
        return true
    }

    // ---- Credit / billing / payments ----
    lateinit var invoices: StateFlow<List<VoiceInvoice>>
        private set

    fun updateInvoiceItem(invoiceId: String, index: Int, item: InvoiceLineItem) {
        scope.launch {
            val existing = db.invoiceDao().getAllVoice().first().firstOrNull { it.id == invoiceId } ?: return@launch
            val items = Converters.unpackInvoiceItems(existing.lineItemsRaw).also { it[index] = item }
            db.invoiceDao().update(existing.copy(lineItemsRaw = Converters.packInvoiceItems(items)))
        }
    }

    lateinit var payments: StateFlow<List<PaymentProof>>
        private set

    fun setPaymentStatus(id: String, status: PaymentVerificationStatus) {
        scope.launch { db.paymentProofDao().setStatus(id, status.name) }
    }

    // ---- Production ----
    lateinit var lots: StateFlow<List<RawMaterialLot>>
        private set

    fun movingAverageCost(material: String): Double {
        val matching = lots.value.filter { it.materialName == material }
        val totalQty = matching.sumOf { it.qtyKg }
        return if (totalQty == 0.0) 0.0 else matching.sumOf { it.qtyKg * it.costPerKg } / totalQty
    }

    lateinit var batches: StateFlow<List<ProductionBatch>>
        private set

    fun receiveGatepass(batchId: String) {
        scope.launch { db.productionBatchDao().receiveGatepass(batchId) }
    }

    // ================= Module 2: Manufacturing & Production extras =================

    lateinit var billOfMaterials: StateFlow<List<BillOfMaterials>>
        private set
    lateinit var productionOrders: StateFlow<List<ProductionOrder>>
        private set
    lateinit var qualityChecks: StateFlow<List<QualityCheck>>
        private set
    lateinit var productionLosses: StateFlow<List<ProductionLoss>>
        private set
    lateinit var machineLogs: StateFlow<List<MachineLog>>
        private set

    /** BOM — "to make 1 unit of X, you need these raw materials". Used by createProductionOrder to compute Production Costing (material + labor + overhead) up front, before a single unit is actually made. */
    fun createBom(finishedProductName: String, lines: List<BomLine>, laborCostPerUnit: Double, overheadCostPerUnit: Double): BillOfMaterials {
        val bom = BillOfMaterials(id = java.util.UUID.randomUUID().toString(), finishedProductName = finishedProductName, lines = lines, laborCostPerUnit = laborCostPerUnit, overheadCostPerUnit = overheadCostPerUnit)
        scope.launch {
            val entity = bom.toEntity()
            db.billOfMaterialsDao().upsert(entity)
            syncCollection("billOfMaterials").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push bom failed", it) }
            logAudit("BOM", bom.id, "CREATE", newValue = bom)
        }
        return bom
    }

    /** Estimated per-unit cost from a BOM: raw materials (using each material's moving-average cost where known, else 0) + labor + overhead. */
    fun estimatedUnitCost(bom: BillOfMaterials): Double {
        val materialCost = bom.lines.sumOf { line -> movingAverageCost(line.rawMaterialName) * line.qtyPerUnit }
        return materialCost + bom.laborCostPerUnit + bom.overheadCostPerUnit
    }

    fun createProductionOrder(bomId: String, finishedProductName: String, targetQty: Double, scheduledDate: LocalDateTime): ProductionOrder {
        val order = ProductionOrder(
            id = java.util.UUID.randomUUID().toString(), orderNo = "PRO-${System.currentTimeMillis().toString().takeLast(8)}${(10..99).random()}",
            bomId = bomId, finishedProductName = finishedProductName, targetQty = targetQty,
            scheduledDate = scheduledDate, createdBy = currentUser.name,
        )
        scope.launch {
            val entity = order.toEntity()
            db.productionOrderDao().upsert(entity)
            syncCollection("productionOrders").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push productionOrder failed", it) }
            logAudit("ProductionOrder", order.id, "CREATE", newValue = order)
            createNotification(NotificationCategory.PRODUCTION, "New Production Order", "${order.orderNo} — $finishedProductName × ${targetQty}")
        }
        return order
    }

    /**
     * Part L — Production Transaction Integrity. Returns null on success,
     * or a list of blocking reasons if completion cannot proceed. For any
     * status other than COMPLETED this is a simple status change (no
     * material movement involved). For COMPLETED, EVERY validation below
     * must pass before status is touched at all — the previous version
     * flipped status to COMPLETED first and only then discovered problems,
     * logging "reconcile manually" instead of blocking. Now nothing is
     * marked complete, no material is consumed, and no finished goods are
     * received unless the whole set of checks passes.
     */
    fun updateProductionOrderStatus(orderId: String, status: String): List<String>? {
        val order = productionOrders.value.firstOrNull { it.id == orderId } ?: return listOf("Production order not found.")
        if (status != "COMPLETED") {
            scope.launch {
                db.productionOrderDao().setStatus(orderId, status)
                syncCollection("productionOrders").document(orderId).update("status", status)
                    .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push production-order-status failed", it) }
                logAudit("ProductionOrder", orderId, "UPDATE", newValue = status)
            }
            return null
        }
        if (order.status == "COMPLETED") return listOf("This order is already completed — cannot re-complete (idempotency guard).")

        // ---- Part L pre-validation, all before any write ----
        val errors = mutableListOf<String>()
        val bom = billOfMaterials.value.firstOrNull { it.id == order.bomId && it.isActive }
        if (bom == null) errors += "No active BOM found for this production order."
        val productionWarehouse = InventoryRepository.warehouses.value.firstOrNull { it.stockCategory == com.abm.erp.data.StockCategory.PRODUCTION }
        if (productionWarehouse == null) errors += "No PRODUCTION-category warehouse configured."
        val finishedProduct = InventoryRepository.products.value.firstOrNull { it.name.equals(order.finishedProductName, ignoreCase = true) }
        if (finishedProduct == null) errors += "Finished product '${order.finishedProductName}' has no matching Product record."
        val lineChecks = bom?.lines?.map { line ->
            val rawProduct = InventoryRepository.products.value.firstOrNull { it.name.equals(line.rawMaterialName, ignoreCase = true) }
            if (rawProduct == null) {
                "Raw material '${line.rawMaterialName}' has no matching Product record." to null
            } else {
                val required = line.qtyPerUnit * order.targetQty
                val available = productionWarehouse?.let { wh -> InventoryRepository.stockLevels.value.firstOrNull { it.productId == rawProduct.id && it.warehouseId == wh.id }?.quantityOnHand ?: 0.0 } ?: 0.0
                if (available < required) "Insufficient stock for '${line.rawMaterialName}': need ${required}, have ${available}" to null
                else null to (rawProduct.id to required)
            }
        } ?: emptyList()
        lineChecks.mapNotNull { it.first }.forEach { errors += it }
        if (!PermissionManager.canCurrentUser("prod", PermissionAction.APPROVE)) errors += "You do not have permission to complete production orders."

        if (errors.isNotEmpty()) {
            logAudit("ProductionOrder", orderId, "COMPLETION_BLOCKED", newValue = errors.joinToString("; "))
            return errors
        }

        // ---- All checks passed — perform consumption + receipt + status update together ----
        val consumptions = lineChecks.mapNotNull { it.second }
        scope.launch {
            consumptions.forEach { (productId, qty) -> InventoryRepository.stockOut(productId, productionWarehouse!!.id, qty, "Material consumption — ${order.orderNo}") }
            InventoryRepository.stockIn(finishedProduct!!.id, productionWarehouse!!.id, order.targetQty, "Finished goods — ${order.orderNo}")
            db.productionOrderDao().setStatus(orderId, status)
            syncCollection("productionOrders").document(orderId).update("status", status)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push production-order-status failed", it) }
            logAudit("ProductionOrder", orderId, "UPDATE", newValue = status)
            logAudit("ProductionOrder", orderId, "MATERIAL_CONSUMED_AND_RECEIVED", newValue = "lines=${consumptions.size}, finishedQty=${order.targetQty}")
            createNotification(NotificationCategory.PRODUCTION, "Production Completed", "${order.orderNo} — ${order.finishedProductName}")
        }
        return null
    }

    /** Quality Control — pass/fail check tied to a production batch. */
    fun recordQualityCheck(batchId: String, result: String, notes: String) {
        val check = QualityCheck(id = java.util.UUID.randomUUID().toString(), batchId = batchId, result = result, notes = notes, checkedBy = currentUser.name)
        scope.launch {
            val entity = check.toEntity()
            db.qualityCheckDao().upsert(entity)
            syncCollection("qualityChecks").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push qualityCheck failed", it) }
            logAudit("QualityCheck", batchId, "CREATE", newValue = "$result — $notes")
            if (result == "FAIL") {
                createNotification(NotificationCategory.QUALITY_CHECK, "Quality Check Failed", "Batch $batchId — $notes")
            }
        }
    }

    /** Production Loss Tracking — wastage recorded against a batch, separate from the batch's own output qty. */
    fun recordProductionLoss(batchId: String, qtyLost: Double, reason: String) {
        val loss = ProductionLoss(id = java.util.UUID.randomUUID().toString(), batchId = batchId, qtyLost = qtyLost, reason = reason)
        scope.launch {
            val entity = loss.toEntity()
            db.productionLossDao().upsert(entity)
            syncCollection("productionLosses").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push productionLoss failed", it) }
            logAudit("ProductionLoss", batchId, "CREATE", newValue = "$qtyLost — $reason")
        }
    }

    /** Machine Utilization — hours logged per machine, optionally tied to a batch. */
    fun recordMachineLog(machineName: String, batchId: String?, hoursUsed: Double, notes: String) {
        val log = MachineLog(id = java.util.UUID.randomUUID().toString(), machineName = machineName, batchId = batchId, hoursUsed = hoursUsed, notes = notes)
        scope.launch {
            val entity = log.toEntity()
            db.machineLogDao().upsert(entity)
            syncCollection("machineLogs").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push machineLog failed", it) }
            logAudit("MachineLog", machineName, "CREATE", newValue = "$hoursUsed hrs — $notes")
        }
    }

    /** Machine Utilization — hours-used log, optionally tied to a batch. */
    fun recordMachineUsage(machineName: String, batchId: String?, hoursUsed: Double, notes: String = "") {
        val log = MachineLog(id = java.util.UUID.randomUUID().toString(), machineName = machineName, batchId = batchId, hoursUsed = hoursUsed, notes = notes)
        scope.launch {
            val entity = log.toEntity()
            db.machineLogDao().upsert(entity)
            syncCollection("machineLogs").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push machineLog failed", it) }
        }
    }

    // ---- BI / advisory ----
    /** AI Boardroom — real, data-derived prescriptions instead of a static hardcoded list. Reuses computeRiskAlerts() (already live-computed from Dealer/Retailer/Approval/Stock data) and reshapes each RiskAlert into a PrescriptionCard, the shape BoardroomScreen already renders. If there's genuinely no risk signal right now, this returns an empty list rather than fabricating one — an honest "nothing flagged" instead of always showing 3 cards. */
    fun computePrescriptions(): List<PrescriptionCard> =
        computeRiskAlerts().map { alert -> PrescriptionCard(alert.id, alert.category, alert.message, alert.severity) }

    lateinit var boardroomHistory: StateFlow<List<BoardroomQuery>>
        private set

    // ---- Task Manager ----
    lateinit var tasks: StateFlow<List<TaskItem>>
        private set
    lateinit var deletedTasks: StateFlow<List<TaskItem>>
        private set

    fun addTask(title: String, assignee: String, parentTaskId: String? = null) {
        scope.launch {
            val entity = TaskItemEntity(id = java.util.UUID.randomUUID().toString(), title = title, assignee = assignee, done = false, createdAtEpochMillis = System.currentTimeMillis(), parentTaskId = parentTaskId)
            db.taskDao().upsert(entity)
            pushTask(entity)
            logAudit("Task", entity.id, "CREATE", newValue = entity.toDomain())
            createNotification(NotificationCategory.TASK, "Task Assigned", "$title — $assignee")
        }
    }

    /** Task & Activity Management — 4-state status; keeps `done` in sync (true only for COMPLETED) so existing checkbox UI keeps working unchanged. */
    fun setTaskStatus(id: String, status: TaskStatus) {
        scope.launch {
            db.taskDao().setStatus(id, status.name, status == TaskStatus.COMPLETED)
            syncCollection("tasks").document(id).update(mapOf("status" to status.name, "done" to (status == TaskStatus.COMPLETED)))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push task-status failed", it) }
            logAudit("Task", id, "UPDATE", newValue = status)
        }
    }

    fun subTasksFor(parentTaskId: String): Flow<List<TaskItem>> =
        db.taskDao().getSubTasks(parentTaskId).map { list -> list.map { it.toDomain() } }

    fun setTaskDone(id: String, done: Boolean) {
        scope.launch {
            db.taskDao().setDone(id, done)
            syncCollection("tasks").document(id).update("done", done)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push task-done failed", it) }
        }
    }

    /** Soft delete — the record never actually leaves Room/Firestore, isDeleted just flips to true. */
    fun deleteTask(id: String) {
        scope.launch {
            val before = tasks.value.firstOrNull { it.id == id } ?: return@launch
            val now = System.currentTimeMillis()
            db.taskDao().softDelete(id, now, currentUser.name)
            syncCollection("tasks").document(id).update(mapOf("isDeleted" to true, "deletedAtEpochMillis" to now, "deletedBy" to currentUser.name))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push task-delete failed", it) }
            logAudit("Task", id, "DELETE", oldValue = before)
        }
    }

    fun restoreTask(id: String) {
        scope.launch {
            db.taskDao().restore(id)
            syncCollection("tasks").document(id).update(mapOf("isDeleted" to false, "deletedAtEpochMillis" to null, "deletedBy" to null))
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push task-restore failed", it) }
            logAudit("Task", id, "RESTORE")
        }
    }

    // ---- Approvals ----
    lateinit var approvals: StateFlow<List<ApprovalRequest>>
        private set

    lateinit var roleDefinitions: StateFlow<List<RoleDefinition>>
        private set


    // ---- Courier & Logistics ----
    lateinit var couriers: StateFlow<List<CourierPartner>>
        private set

    lateinit var shipments: StateFlow<List<Shipment>>
        private set

    fun bookShipment(courierId: String, dealerOrRetailer: String) {
        scope.launch {
            val hasApi = couriers.value.firstOrNull { it.id == courierId }?.hasApi ?: false
            // Part R/S honesty — no real courier API is integrated in this
            // project; when hasApi is true for a courier record, this still
            // only generates a LOCAL placeholder tracking id (now collision-
            // safe via timestamp, matching the other document-number
            // fixes this pass), never a real trackable number from an
            // actual courier service. Do not present this to a customer as
            // something that resolves on the courier's own tracking site.
            val trackingId = if (hasApi) "${courierId.take(2).uppercase()}-${System.currentTimeMillis().toString().takeLast(8)}${(10..99).random()}" else null
            val entity = ShipmentEntity(
                id = java.util.UUID.randomUUID().toString(), courierId = courierId, dealerOrRetailer = dealerOrRetailer,
                trackingId = trackingId, status = ShipmentStatus.PICKED_UP.name,
            )
            db.shipmentDao().upsert(entity)
            pushShipment(entity)
        }
    }

    private val autoAdvanceStages = listOf(ShipmentStatus.PICKED_UP, ShipmentStatus.IN_TRANSIT, ShipmentStatus.OUT_FOR_DELIVERY, ShipmentStatus.DELIVERED)

    private fun pushShipmentStatus(shipmentId: String, status: String) {
        syncCollection("shipments").document(shipmentId).update("status", status)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push shipment-status failed", it) }
    }

    /** For API-connected couriers: simulate pulling the next tracking stage. Manual couriers use setShipmentStatus directly instead. */
    fun refreshShipmentStatus(shipmentId: String) {
        scope.launch {
            val current = shipments.value.firstOrNull { it.id == shipmentId } ?: return@launch
            val idx = autoAdvanceStages.indexOf(current.status)
            val next = autoAdvanceStages.getOrElse(idx + 1) { current.status }
            db.shipmentDao().setStatus(shipmentId, next.name)
            pushShipmentStatus(shipmentId, next.name)
        }
    }

    fun setShipmentStatus(shipmentId: String, status: ShipmentStatus) {
        scope.launch {
            db.shipmentDao().setStatus(shipmentId, status.name)
            pushShipmentStatus(shipmentId, status.name)
        }
    }

    // ---- Module 13: Logistics — Vehicle Tracking ----
    lateinit var vehicles: StateFlow<List<Vehicle>>
        private set
    lateinit var vehicleLocationPings: StateFlow<List<VehicleLocationPing>>
        private set

    fun createVehicle(registrationNo: String, vehicleType: String, driverName: String, driverPhone: String): Vehicle? {
        if (!PermissionManager.canCurrentUser("courier", PermissionAction.CREATE)) {
            logAudit("Vehicle", "(new)", "DENY", oldValue = currentUser.role.name, newValue = "CREATE")
            return null
        }
        if (registrationNo.isBlank()) return null
        val vehicle = Vehicle(id = "VEH-${java.util.UUID.randomUUID().toString().take(8)}", registrationNo = registrationNo, vehicleType = vehicleType, driverName = driverName, driverPhone = driverPhone)
        scope.launch {
            val entity = vehicle.toEntity()
            db.vehicleDao().upsert(entity)
            syncCollection("vehicles").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push vehicle failed", it) }
            logAudit("Vehicle", vehicle.id, "CREATE", newValue = vehicle)
        }
        return vehicle
    }

    /** GPS ping for a vehicle in transit — same spoofing-aware shape as recordGpsPing/recordVisitCheckIn (Foundation Layer's Geo Validation), just tagged to a vehicle instead of an employee/party. */
    fun recordVehiclePing(vehicleId: String, lat: Double, lng: Double, speedKmh: Double) {
        val ping = VehicleLocationPing(id = java.util.UUID.randomUUID().toString(), vehicleId = vehicleId, lat = lat, lng = lng, speedKmh = speedKmh)
        scope.launch {
            val entity = ping.toEntity()
            db.vehicleLocationPingDao().upsert(entity)
            syncCollection("vehicleLocationPings").document(entity.id).set(entity)
                .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push vehiclePing failed", it) }
        }
    }

    fun latestPingFor(vehicleId: String): Flow<VehicleLocationPing?> =
        db.vehicleLocationPingDao().getLatestForVehicle(vehicleId).map { it?.toDomain() }

    // ---- Accounts / Ledger (NSM+ only) ----
    lateinit var ledgerEntries: StateFlow<List<LedgerEntry>>
        private set

    fun addLedgerEntry(type: LedgerEntryType, category: String, description: String, amount: Double, recordedBy: String) {
        scope.launch {
            val demoDivision = EMPLOYEE_DIRECTORY.firstOrNull { it.id == currentUser.employeeId }?.geo?.division
            val realProfile = employeeProfiles.value.firstOrNull { it.id == currentUser.employeeId }
            val division = demoDivision ?: realProfile?.divisionId?.let { id -> administrativeLocations.value.firstOrNull { it.id == id }?.nameEn }
            val entry = LedgerEntryEntity(
                id = java.util.UUID.randomUUID().toString(), type = type.name, category = category,
                description = description, amount = amount, recordedBy = recordedBy, division = division,
                recordedAtEpochMillis = System.currentTimeMillis(),
            )
            db.ledgerDao().upsert(entry)
            pushLedgerEntry(entry)
        }
    }

    // ==========================================================
    // Section 8 — Expense workflow (submit -> approve/reject -> real
    // ledger posting). Was completely missing before — no model, no
    // entity, no functions at all.
    // ==========================================================
    lateinit var expenses: StateFlow<List<Expense>>
        private set


    /** "Analysis" slot — read-only insight, pattern-matched against LIVE data (real Gemini function-calling call plugs in here server-side once Blaze is on). */
    fun askAnalysis(question: String): String {
        val q = question.lowercase()
        val totalDealerSales = dealers.value.sumOf { it.salesLast90Days }
        val totalDealerDue = dealers.value.sumOf { it.dueBalance }
        val lowStock = InventoryRepository.stockLevels.value.filter { it.isLowStock }
        val ledgerIn = ledgerEntries.value.filter { it.type == LedgerEntryType.IN }.sumOf { it.amount }
        val ledgerOut = ledgerEntries.value.filter { it.type == LedgerEntryType.OUT }.sumOf { it.amount }
        val answer = when {
            "profit" in q || "margin" in q -> {
                val recentInvoices = salesInvoices.value.filter { !it.isDeleted }
                if (recentInvoices.isEmpty()) {
                    "এখনো কোনো invoice data নেই — margin বিশ্লেষণের জন্য যথেষ্ট তথ্য জমা হয়নি।"
                } else {
                    val avgDiscount = recentInvoices.map { it.dealerDiscountPct }.average()
                    val highDiscountCount = recentInvoices.count { it.dealerDiscountPct > avgDiscount + 2 }
                    "গড় dealer discount ${"%.1f".format(avgDiscount)}% (${recentInvoices.size}টা invoice জুড়ে)। ${highDiscountCount}টা invoice গড়ের চেয়ে বেশি discount দিয়েছে — এগুলোই margin-এর ওপর সবচেয়ে বেশি চাপ ফেলছে। (raw-material cost breakdown এই সিস্টেমে ট্র্যাক করা হয় না, তাই সেই অংশটা এখানে দেখানো সম্ভব না।)"
                }
            }
            "stock" in q || "shortage" in q ->
                if (lowStock.isEmpty()) "No products are currently at or below their reorder level."
                else "${lowStock.size} product(s) at or below reorder level — most urgent: ${lowStock.first().productName} at ${lowStock.first().warehouseName}."
            "due" in q || "payment" in q || "receivable" in q ->
                "Dealers owe ৳${"%,.0f".format(totalDealerDue)} against ৳${"%,.0f".format(totalDealerSales)} in 90-day sales (${"%.0f".format(if (totalDealerSales == 0.0) 0.0 else totalDealerDue / totalDealerSales * 100)}%)."
            "ledger" in q || "cash" in q || "balance" in q ->
                "Ledger balance is ৳${"%,.0f".format(ledgerIn - ledgerOut)} (in: ৳${"%,.0f".format(ledgerIn)}, out: ৳${"%,.0f".format(ledgerOut)})."
            "absence" in q || "attendance" in q ->
                "3 field officers have unapproved GPS gaps this week, concentrated in Barisal zone during afternoon shifts."
            "boost" in q || "best" in q || "zone" in q ->
                "ABM Masala Tea is growing fastest in Khulna zone (+18% vs forecast); recommend reallocating stock there and running a robocall promo."
            else ->
                "Based on current production, credit-risk, and attendance data, no critical anomalies outside the flagged prescription cards below."
        }
        recordBoardroomQuery(question, answer, "analysis")
        return answer
    }

    private data class ActionPattern(val regex: Regex, val action: String, val detail: String)
    private val ACTION_PATTERNS = listOf(
        ActionPattern(Regex("order|retailer|shop", RegexOption.IGNORE_CASE), "Log a retail order", "Would ask for retailer name, item, and amount, then submit it to Sales Chain."),
        ActionPattern(Regex("vacant|resign|leave", RegexOption.IGNORE_CASE), "Update an employee's vacancy status", "Would mark a specific employee vacant/active (Chairman-only)."),
        ActionPattern(Regex("notice|announcement", RegexOption.IGNORE_CASE), "Post a Chairman's Notice", "Would push an image/text to everyone's dashboard."),
    )

    /** "Assistant" slot — detects an action intent; real execution needs Firebase Blaze + Cloud Functions (this stays a preview until then). */
    fun askAssistant(question: String): String {
        val matched = ACTION_PATTERNS.firstOrNull { it.regex.containsMatchIn(question) }
        val answer = if (matched != null) {
            "🔧 Recognized: ${matched.action}. ${matched.detail}\n\n(Demo — real execution needs Firebase Blaze + Cloud Functions; once that's on, this same screen will complete the action directly.)"
        } else {
            "That sounds like an open-ended question rather than a specific action — real AI reasoning needs Firebase Blaze. Right now only pattern-recognized actions (order/vacancy/notice) can be demoed."
        }
        recordBoardroomQuery(question, answer, "assistant")
        return answer
    }

    private fun recordBoardroomQuery(question: String, answer: String, mode: String) {
        scope.launch {
            db.boardroomQueryDao().insert(
                BoardroomQueryEntity(question = question, answer = answer, mode = mode, askedAtEpochMillis = System.currentTimeMillis())
            )
        }
    }

    // ================= internal wiring =================

    private fun wireFlows() {
        orders = db.retailOrderDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        dealers = db.dealerDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        routes = db.fieldEmployeeRouteDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        campaigns = db.engagementCampaignDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        payroll = db.payrollDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        invoices = db.invoiceDao().getAllVoice().map { list -> list.map { it.toVoiceDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        payments = db.paymentProofDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        lots = db.rawMaterialLotDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        batches = db.productionBatchDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        boardroomHistory = db.boardroomQueryDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        tasks = db.taskDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        deletedTasks = db.taskDao().getDeleted().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        approvals = db.approvalDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        couriers = db.courierDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        shipments = db.shipmentDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        ledgerEntries = db.ledgerDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        salesInvoices = db.invoiceDao().getAllSales().map { list -> list.map { it.toSalesDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        salesOrders = db.salesOrderDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        roleDefinitions = db.roleDefinitionDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        scope.launch { roleDefinitions.collect { PermissionManager.updateFromSynced(it) } }
        employeePermissionOverrides = db.employeePermissionOverrideDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        vacancies = db.vacancyDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        targets = db.targetDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        targetChangeLogs = db.targetChangeLogDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        correctionRequests = db.correctionRequestDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        accountingPeriodLocks = db.accountingPeriodLockDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        numberSeriesConfigs = db.numberSeriesConfigDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        ownershipTransferRecords = db.ownershipTransferRecordDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        businessRules = db.businessRuleDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        companySettingsList = db.companySettingsDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        expenses = db.expenseDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        auditLogEntries = db.auditLogDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        scope.launch { employeePermissionOverrides.collect { PermissionManager.updateFromSyncedOverrides(it) } }

        retailers = db.retailerDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        employeeProfiles = db.employeeProfileDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        employeeAreaAssignments = db.employeeAreaAssignmentDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        employeeAppraisals = db.employeeAppraisalDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        manufacturingWorkerAssignments = db.manufacturingWorkerAssignmentDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        productionPlans = db.productionPlanDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        rawMaterialIssues = db.rawMaterialIssueDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        qualityInspections = db.qualityInspectionDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        packingRecords = db.packingRecordDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        finishedGoodsReceipts = db.finishedGoodsReceiptDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        warehouseTransfers = db.warehouseTransferDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        warehouseReceipts = db.warehouseReceiptDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        locationAlerts = db.locationAlertDao().getAll().stateIn(scope, SharingStarted.Eagerly, emptyList())
        securityEvents = db.securityEventDao().getAll().stateIn(scope, SharingStarted.Eagerly, emptyList())
        geoOverrides = db.geoOverrideDao().getAll().stateIn(scope, SharingStarted.Eagerly, emptyList())
        executiveExceptions = db.executiveExceptionDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        managementActions = db.managementActionDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        decisionQueryLogs = db.decisionQueryAuditDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        administrativeLocations = db.administrativeLocationDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        companyMarkets = db.companyMarketDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        userAccounts = db.userAccountDao().getAll().map { list -> list.map { it.toDomain() } }.stateIn(scope, SharingStarted.Eagerly, emptyList())
        transferRequests = db.transferRequestDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        delegations = db.delegationDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        quotations = db.quotationDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        deliveryChallans = db.deliveryChallanDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        salesReturns = db.salesReturnDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        partyCollections = db.partyCollectionDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        customerComplaints = db.customerComplaintDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        discountRules = db.discountRuleDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        salesRoutes = db.salesRouteDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        visitLogs = db.visitLogDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        billOfMaterials = db.billOfMaterialsDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        productionOrders = db.productionOrderDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        qualityChecks = db.qualityCheckDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        productionLosses = db.productionLossDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        machineLogs = db.machineLogDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        leaveRequests = db.leaveRequestDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        employeeLifecycleEvents = db.employeeLifecycleEventDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())

        vehicles = db.vehicleDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        vehicleLocationPings = db.vehicleLocationPingDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        notifications = db.notificationEntryDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
        territories = db.territoryDao().getAll().map { list -> list.map { it.toDomain() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
    }

    /** Inserts the same starter data the old in-memory version shipped with, but only once, on first run (empty DB). */
    private fun seedIfEmpty() = runBlocking(Dispatchers.IO) {
        // Real bug fix — role/permission definitions are essential system
        // configuration (every canCurrentUser() check depends on this data
        // existing), NOT "fake demo data". This must seed unconditionally,
        // in every environment including production, or NO role ever gets
        // its permissions written to Room/Firestore and every permission-
        // gated action silently relies on the compiled in-memory fallback
        // only — which breaks anywhere a synced/edited role definition was
        // expected. Moved to run before the demo-data gate below.
        if (db.roleDefinitionDao().getAll().first().isEmpty()) {
            val defaults = PermissionManager.defaultDefinitionsForSeeding().map { it.toEntity() }
            db.roleDefinitionDao().upsertAll(defaults)
            PermissionManager.updateFromSynced(defaults.map { it.toDomain() })
        }
        // RC final-pass fix — this used to seed demo retail orders (fake
        // retailer names, fake amounts) unconditionally on first launch,
        // in EVERY build including PRODUCTION. Section 2 explicitly
        // requires "fake employees, fake financial data" to be gated by
        // the centralized environment config, not seeded regardless.
        if (!com.abm.erp.config.AppEnvironment.seedDemoDataAllowed) return@runBlocking
        if (db.retailOrderDao().count() == 0) {
            db.retailOrderDao().upsertAll(
                listOf(
                    RetailOrder(id = "seed-ord-101", orderNo = "ORD-101", retailerName = "Green Valley Store", loggedBySoId = "SO-1", zone = "Barishal", items = "ABM Masala Tea x40 ctn", amount = 48000.0).toEntity(),
                    RetailOrder(id = "seed-ord-102", orderNo = "ORD-102", retailerName = "City Corner Shop", loggedBySoId = "SO-2", zone = "Khulna", items = "ABM Tea Classic x25 ctn", amount = 31250.0, stage = OrderStage.ASM_VERIFIED).toEntity(),
                    RetailOrder(id = "seed-ord-103", orderNo = "ORD-103", retailerName = "New Bazar Traders", loggedBySoId = "SO-1", zone = "Barishal", items = "ABM Masala Tea x60 ctn", amount = 72000.0, stage = OrderStage.DEALER_ROUTED, routedDealerId = "D-1").toEntity(),
                )
            )
        }
        if (db.dealerDao().count() == 0) {
            db.dealerDao().upsertAll(
                listOf(
                    DealerEntity(id = "D-1", name = "Barisal Central Dealer", zone = "Barishal", dueBalance = 185000.0, salesLast90Days = 620000.0, pin = "1111", stockUnits = 500),
                    DealerEntity(id = "D-2", name = "Khulna Wholesale Hub", zone = "Khulna", dueBalance = 42000.0, salesLast90Days = 410000.0, pin = "2222", stockUnits = 300),
                    DealerEntity(id = "D-3", name = "Rajshahi Distributors", zone = "Rajshahi", dueBalance = 305000.0, salesLast90Days = 260000.0, pin = "3333", stockUnits = 400),
                )
            )
        }
        if (db.fieldEmployeeRouteDao().count() == 0) {
            val breadcrumbs = listOf(
                GpsPing(22.701, 90.353, LocalDateTime.now().minusHours(4)),
                GpsPing(22.706, 90.360, LocalDateTime.now().minusHours(3)),
                GpsPing(22.712, 90.368, LocalDateTime.now().minusHours(1)),
            )
            db.fieldEmployeeRouteDao().upsertAll(
                listOf(
                    FieldEmployeeRouteEntity(
                        employeeId = "SO-1",
                        employeeName = "Sales Officer Rafiq",
                        dateEpochDay = LocalDate.now().toEpochDay(),
                        breadcrumbsRaw = Converters.packBreadcrumbs(breadcrumbs),
                    )
                )
            )
        }
        if (db.payrollDao().count() == 0) {
            db.payrollDao().upsertAll(
                listOf(
                    PayrollLineEntity(employeeId = "SO-1", employeeName = "Sales Officer Rafiq", basePay = 22000.0, targetAmount = 500000.0, achievedAmount = 460000.0, commissionRate = 0.015, unapprovedAbsenceDays = 1, dailyWage = 733.0),
                    PayrollLineEntity(employeeId = "SO-2", employeeName = "Sales Officer Nadia", basePay = 22000.0, targetAmount = 500000.0, achievedAmount = 610000.0, commissionRate = 0.015, unapprovedAbsenceDays = 0, dailyWage = 733.0),
                    PayrollLineEntity(employeeId = "ASM-1", employeeName = "Area Manager Kabir", basePay = 38000.0, targetAmount = 1500000.0, achievedAmount = 1290000.0, commissionRate = 0.01, unapprovedAbsenceDays = 2, dailyWage = 1266.0),
                )
            )
        }
        if (db.invoiceDao().countByType("VOICE") == 0) {
            db.invoiceDao().upsertAll(
                listOf(
                    InvoiceEntity(
                        id = "INV-VB-01",
                        type = "VOICE",
                        dealerId = "D-1",
                        lineItemsRaw = Converters.packInvoiceItems(listOf(InvoiceLineItem("ABM Masala Tea 1kg", 50.0, "kg", 420.0, 5.0))),
                        previousDue = 185000.0,
                    )
                )
            )
        }
        if (db.paymentProofDao().count() == 0) {
            db.paymentProofDao().upsertAll(listOf(PaymentProofEntity("PMT-1", "D-2", 60000.0, "TXN-88213-BKASH", PaymentVerificationStatus.PENDING_VERIFICATION.name)))
        }
        if (db.rawMaterialLotDao().count() == 0) {
            db.rawMaterialLotDao().upsertAll(
                listOf(
                    RawMaterialLotEntity("RM-1", "Raw Leaves", 500.0, 210.0, LocalDate.now().minusDays(3).toEpochDay()),
                    RawMaterialLotEntity("RM-2", "Raw Leaves", 300.0, 225.0, LocalDate.now().minusDays(1).toEpochDay()),
                    RawMaterialLotEntity("RM-3", "CMC Thickener", 80.0, 340.0, LocalDate.now().minusDays(2).toEpochDay()),
                )
            )
        }
        if (db.productionBatchDao().count() == 0) {
            db.productionBatchDao().upsertAll(
                listOf(
                    ProductionBatchEntity("BATCH-77", "Spray Dryer 30kg", 30.0, 24.5, false),
                    ProductionBatchEntity("BATCH-78", "Drum Dryer 30kg", 30.0, 26.1, true),
                )
            )
        }
        if (db.courierDao().count() == 0) {
            db.courierDao().upsertAll(
                listOf(
                    CourierPartnerEntity("CR-1", "Pathao Courier", true),
                    CourierPartnerEntity("CR-2", "Sundarban Courier", true),
                    CourierPartnerEntity("CR-3", "Local Van Service", false),
                )
            )
        }
        if (db.approvalDao().count() == 0) {
            db.approvalDao().upsert(
                ApprovalRequestEntity(
                    id = "APR-1", type = ApprovalType.DISCOUNT.name, fromEmployee = "SR — Rafiq Hasan",
                    detail = "8% discount for New Bazar Traders (target: 6%)", status = ApprovalStatus.PENDING.name,
                    createdAtEpochMillis = System.currentTimeMillis(),
                )
            )
        }
        if (db.ledgerDao().count() == 0) {
            val now = System.currentTimeMillis()
            db.ledgerDao().upsert(LedgerEntryEntity("LEDGER-1", LedgerEntryType.IN.name, "Dealer Payment", "Barisal Central Dealer — invoice settlement", 480_000.0, "Accounts", null, now - 86_400_000L))
            db.ledgerDao().upsert(LedgerEntryEntity("LEDGER-2", LedgerEntryType.OUT.name, "Raw Material Purchase", "Tea leaf — 2 tonnes", 620_000.0, "Production", null, now - 3 * 86_400_000L))
            db.ledgerDao().upsert(LedgerEntryEntity("LEDGER-3", LedgerEntryType.OUT.name, "Payroll", "Monthly payroll — field staff", 1_450_000.0, "HR", null, now - 5 * 86_400_000L))
            db.ledgerDao().upsert(LedgerEntryEntity("LEDGER-4", LedgerEntryType.IN.name, "Dealer Payment", "Khulna Wholesale Hub — partial settlement", 310_000.0, "Accounts", null, now - 6 * 86_400_000L))
            db.ledgerDao().upsert(LedgerEntryEntity("LEDGER-5", LedgerEntryType.OUT.name, "Utility Bill", "Factory electricity — July", 95_000.0, "Production", null, now - 8 * 86_400_000L))
        }
    }
}
