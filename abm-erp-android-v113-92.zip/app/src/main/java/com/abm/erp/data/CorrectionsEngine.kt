package com.abm.erp.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.first
import java.time.LocalDateTime

// ============================================================================
// v113-81c Phase 4 — the Correction Request / Reversal engine, moved out of
// MockRepository.kt: submitCorrectionRequest, managerReviewCorrection,
// chairmanApproveCorrection (the ~180-line per-module reversal engine —
// invoice due/status REVERSED/CORRECTED, collection status, attendance,
// dealer/retailer soft-delete/edit, productionPlan CANCELLED, warehouse
// transfer, payroll), chairmanRejectCorrection, and the five private
// `applyFieldChange` overloads (one per entity type) used only by the
// reversal engine — they had no caller outside this group (verified by grep
// before moving), so they moved whole rather than being left behind orphaned.
//
// Same mechanics as the two prior phases: extension functions on the
// MockRepository object; every call site outside this file is unchanged;
// private-member access goes through the object's existing bridges
// (database / launchInRepoScope / qrSyncCollection). The reversal logic
// itself — the PROCESSING claim inside db.withTransaction, the per-module
// branch that undoes or corrects a record, every dealer/retailer due
// adjustment — is byte-for-byte what it was, just relocated.
// ============================================================================

// ==========================================================
// Section 1 — Data Correction & Reversal Workflow
// ==========================================================
/** Employee submits — never edits the record directly. */
fun MockRepository.submitCorrectionRequest(module: String, recordId: String, correctionType: CorrectionType, reason: String, proposedChangeJson: String, originalValueJson: String): CorrectionRequest? {
    if (reason.isBlank()) return null
    val req = CorrectionRequest(
        id = "COR-${java.util.UUID.randomUUID().toString().take(8)}", companyId = currentUser.companyId, module = module,
        recordId = recordId, correctionType = correctionType, reason = reason, proposedChangeJson = proposedChangeJson,
        originalValueJson = originalValueJson, requestedBy = currentUser.employeeId, requestedByName = currentUser.name, status = CorrectionRequestStatus.SUBMITTED,
    )
    launchInRepoScope {
        database.correctionRequestDao().upsert(req.toEntity())
        qrSyncCollection("correctionRequests").document(req.id).set(req.toEntity())
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push correction-request failed", it) }
        logAudit("CorrectionRequest", req.id, "SUBMIT", newValue = req)
        createNotification(NotificationCategory.APPROVAL, "Correction Request", "$module #$recordId — $reason")
    }
    return req
}

/** Manager review — moves to Chairman, never itself applies the change. */
fun MockRepository.managerReviewCorrection(requestId: String, comment: String?): Boolean {
    if (currentUser.role == UserRole.SR) return false // manager-tier and above only
    launchInRepoScope {
        val entity = database.correctionRequestDao().getAll().first().firstOrNull { it.id == requestId } ?: return@launchInRepoScope
        val updated = entity.copy(status = CorrectionRequestStatus.MANAGER_REVIEW.name, managerReviewedBy = currentUser.name, managerComment = comment)
        database.correctionRequestDao().upsert(updated)
        qrSyncCollection("correctionRequests").document(requestId).set(updated)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push correction-review failed", it) }
        logAudit("CorrectionRequest", requestId, "MANAGER_REVIEW", reason = comment)
    }
    return true
}

/**
 * Chairman-only final approval — creates BOTH a reversal entry
 * (undoing the original, referencing it) and a corrected replacement
 * entry, so the original record's history is never destroyed, only
 * superseded. The actual reversal/corrected record creation is
 * module-specific and is recorded here as an audit-tracked
 * reference pair; each module's own repository function is expected
 * to consume reversalEntryId/correctedEntryId to build the concrete
 * ledger/stock/attendance entries for its own domain.
 */
private fun MockRepository.parseProposedChange(raw: String): Map<String, String> =
    raw.split(",").mapNotNull { part -> val kv = part.split("="); if (kv.size == 2) kv[0].trim() to kv[1].trim() else null }.toMap()

/** Explicit, safe field-correction per entity type — deliberately NOT reflection-based (no kotlin-reflect dependency, no risk of silently mutating a field that shouldn't be correctable this way). Only the fields a real business correction would plausibly touch are supported; anything else is a no-op rather than a crash. */
private fun MockRepository.applyFieldChange(e: com.abm.erp.data.room.DealerEntity, field: String?, value: String?): com.abm.erp.data.room.DealerEntity = when (field) {
    "creditLimit" -> e.copy(creditLimit = value?.toDoubleOrNull() ?: e.creditLimit)
    "classification" -> e.copy(classification = value ?: e.classification)
    "zone" -> e.copy(zone = value ?: e.zone)
    "name" -> e.copy(name = value ?: e.name)
    else -> e
}

private fun MockRepository.applyFieldChange(e: com.abm.erp.data.room.RetailerEntity, field: String?, value: String?): com.abm.erp.data.room.RetailerEntity = when (field) {
    "creditLimit" -> e.copy(creditLimit = value?.toDoubleOrNull() ?: e.creditLimit)
    "classification" -> e.copy(classification = value ?: e.classification)
    "name" -> e.copy(name = value ?: e.name)
    else -> e
}

private fun MockRepository.applyFieldChange(e: com.abm.erp.data.room.ProductionPlanEntity, field: String?, value: String?): com.abm.erp.data.room.ProductionPlanEntity = when (field) {
    "plannedQuantity" -> e.copy(plannedQuantity = value?.toDoubleOrNull() ?: e.plannedQuantity)
    "status" -> e.copy(status = value ?: e.status)
    else -> e
}

private fun MockRepository.applyFieldChange(e: com.abm.erp.data.room.WarehouseTransferEntity, field: String?, value: String?): com.abm.erp.data.room.WarehouseTransferEntity = when (field) {
    "notes" -> e.copy(notes = value)
    "vehicle" -> e.copy(vehicle = value)
    "driver" -> e.copy(driver = value)
    else -> e
}

private fun MockRepository.applyFieldChange(e: com.abm.erp.data.room.PayrollLineEntity, field: String?, value: String?): com.abm.erp.data.room.PayrollLineEntity = when (field) {
    "basePay" -> e.copy(basePay = value?.toDoubleOrNull() ?: e.basePay)
    "targetAmount" -> e.copy(targetAmount = value?.toDoubleOrNull() ?: e.targetAmount)
    "achievedAmount" -> e.copy(achievedAmount = value?.toDoubleOrNull() ?: e.achievedAmount)
    else -> e
}

/**
 * Chairman-only final approval — this is the REAL "System creates
 * reversal, creates corrected record, preserves original history"
 * step for all 9 supported modules. proposedChangeJson is a simple
 * "key=value,key2=value2" packed map (parsed by parseProposedChange)
 * whose expected keys differ per module — documented per branch
 * below. The CorrectionRequest row itself is the permanent, never-
 * overwritten history of the original request; nothing here deletes
 * or edits a finalized record in place, it only posts an offsetting
 * reversal plus a new corrected entry/value.
 */
fun MockRepository.chairmanApproveCorrection(requestId: String): Boolean {
    if (currentUser.role != UserRole.CHAIRMAN) {
        logAudit("CorrectionRequest", requestId, "DENY", oldValue = currentUser.role.name, newValue = "APPROVE_CORRECTION")
        return false
    }
    val request = correctionRequests.value.firstOrNull { it.id == requestId } ?: return false
    if (request.status == CorrectionRequestStatus.APPLIED || request.status == CorrectionRequestStatus.REJECTED) return false // idempotency guard
    val params = parseProposedChange(request.proposedChangeJson)
    val reversalId = "REV-${java.util.UUID.randomUUID().toString().take(8)}"
    var correctedId: String? = null
    launchInRepoScope {
        // Atomic claim — check eligibility AND flip to PROCESSING inside one transaction, so a second
        // concurrent call (double-tap, or a call that started a moment earlier) sees PROCESSING/APPLIED
        // and aborts here, before any financial/stock/reversal side effect runs. This closes the gap the
        // previous version had: re-checking status was not enough on its own without also claiming it
        // atomically in the same transaction as that check.
        val claimed = database.withTransaction {
            val current = database.correctionRequestDao().getAll().first().firstOrNull { it.id == requestId }
            if (current == null || current.status == CorrectionRequestStatus.APPLIED.name || current.status == CorrectionRequestStatus.REJECTED.name || current.status == CorrectionRequestStatus.PROCESSING.name) {
                com.abm.erp.config.AppLog.w("MockRepository", "chairmanApproveCorrection rejected: request $requestId already ${current?.status ?: "missing"} (idempotency guard)")
                return@withTransaction false
            }
            database.correctionRequestDao().upsert(current.copy(status = CorrectionRequestStatus.PROCESSING.name))
            true
        }
        if (!claimed) return@launchInRepoScope
        when (request.module) {
            // params: partyType (DEALER|RETAILER), partyId, amount
            "Invoice" -> {
                val partyType = PartyType.values().firstOrNull { it.name == params["partyType"] } ?: PartyType.DEALER
                val partyId = params["partyId"] ?: ""
                val amount = params["amount"]?.toDoubleOrNull() ?: 0.0
                if (partyId.isNotBlank() && amount != 0.0) {
                    // A sale increased due balance by +amount; reversing it means crediting the party back (reducing due) by -amount.
                    if (partyType == PartyType.DEALER) database.dealerDao().adjustDueBalance(partyId, -amount) else database.retailerDao().adjustDueBalance(partyId, -amount)
                    postPartyLedgerEntry(partyType, partyId, "CREDIT", amount, "Invoice reversal — correction $requestId", request.recordId)
                    if (request.correctionType == CorrectionType.DELETE) {
                        // Delete Request — the original invoice record itself is marked REVERSED (a real, visible status), never silently hidden or hard-deleted.
                        database.invoiceDao().setStatus(request.recordId, "REVERSED")
                    }
                    if (request.correctionType == CorrectionType.EDIT) {
                        val newAmount = params["newAmount"]?.toDoubleOrNull() ?: amount
                        correctedId = "CORR-${java.util.UUID.randomUUID().toString().take(8)}"
                        if (partyType == PartyType.DEALER) database.dealerDao().adjustDueBalance(partyId, newAmount) else database.retailerDao().adjustDueBalance(partyId, newAmount)
                        postPartyLedgerEntry(partyType, partyId, "DEBIT", newAmount, "Corrected invoice — correction $requestId", correctedId!!)
                        database.invoiceDao().setStatus(request.recordId, "CORRECTED")
                    }
                }
            }
            // params: partyType, partyId, amount (a collection reduced due balance by -amount; reversing means re-adding it back)
            "Collection" -> {
                val partyType = PartyType.values().firstOrNull { it.name == params["partyType"] } ?: PartyType.DEALER
                val partyId = params["partyId"] ?: ""
                val amount = params["amount"]?.toDoubleOrNull() ?: 0.0
                if (partyId.isNotBlank() && amount != 0.0) {
                    if (partyType == PartyType.DEALER) database.dealerDao().adjustDueBalance(partyId, amount) else database.retailerDao().adjustDueBalance(partyId, amount)
                    postPartyLedgerEntry(partyType, partyId, "DEBIT", amount, "Collection reversal — correction $requestId", request.recordId)
                    if (request.correctionType == CorrectionType.DELETE) {
                        database.partyCollectionDao().setStatus(request.recordId, "REVERSED", currentUser.name, System.currentTimeMillis())
                    }
                    if (request.correctionType == CorrectionType.EDIT) {
                        val newAmount = params["newAmount"]?.toDoubleOrNull() ?: amount
                        correctedId = "CORR-${java.util.UUID.randomUUID().toString().take(8)}"
                        if (partyType == PartyType.DEALER) database.dealerDao().adjustDueBalance(partyId, -newAmount) else database.retailerDao().adjustDueBalance(partyId, -newAmount)
                        postPartyLedgerEntry(partyType, partyId, "CREDIT", newAmount, "Corrected collection — correction $requestId", correctedId!!)
                        database.partyCollectionDao().setStatus(request.recordId, "CORRECTED", currentUser.name, System.currentTimeMillis())
                    }
                }
            }
            // params: employeeId, dateEpochDay, checkedIn (true|false to correct to)
            "Attendance" -> {
                val employeeId = params["employeeId"] ?: ""
                val dateEpochDay = params["dateEpochDay"]?.toLongOrNull()
                if (employeeId.isNotBlank() && dateEpochDay != null) {
                    val rows = database.attendanceDao().getAllForEmployee(employeeId).first()
                    val existing = rows.firstOrNull { it.dateEpochDay == dateEpochDay }
                    if (existing != null && request.correctionType == CorrectionType.EDIT) {
                        val newCheckedIn = params["checkedIn"]?.toBooleanStrictOrNull() ?: existing.checkedIn
                        database.attendanceDao().upsert(existing.copy(checkedIn = newCheckedIn))
                        correctedId = "${employeeId}_$dateEpochDay"
                    } else if (existing != null && request.correctionType == CorrectionType.DELETE) {
                        database.attendanceDao().upsert(existing.copy(checkedIn = false, gpsValid = false))
                    }
                }
            }
            // params: field, newValue (e.g. field=creditLimit,newValue=50000)
            "Dealer" -> {
                val d = database.dealerDao().getAll().first().firstOrNull { it.id == request.recordId }
                if (d != null) {
                    if (request.correctionType == CorrectionType.DELETE) {
                        database.dealerDao().upsert(d.copy(isDeleted = true, deletedAtEpochMillis = System.currentTimeMillis(), deletedBy = currentUser.name))
                    } else {
                        val updated = applyFieldChange(d, params["field"], params["newValue"])
                        database.dealerDao().upsert(updated)
                        correctedId = request.recordId
                    }
                }
            }
            "Retailer" -> {
                val r = database.retailerDao().getAll().first().firstOrNull { it.id == request.recordId }
                if (r != null) {
                    if (request.correctionType == CorrectionType.DELETE) {
                        database.retailerDao().upsert(r.copy(isDeleted = true))
                    } else {
                        val updated = applyFieldChange(r, params["field"], params["newValue"])
                        database.retailerDao().upsert(updated)
                        correctedId = request.recordId
                    }
                }
            }
            // params: field, newValue — direct field correction on the plan/transfer entity, original values remain readable in this CorrectionRequest's own audit history
            "Production" -> {
                val p = database.productionPlanDao().getAll().first().firstOrNull { it.id == request.recordId }
                if (p != null) {
                    if (request.correctionType == CorrectionType.DELETE) {
                        database.productionPlanDao().upsert(p.copy(status = ProductionPlanStatus.CANCELLED.name))
                    } else {
                        database.productionPlanDao().upsert(applyFieldChange(p, params["field"], params["newValue"]))
                        correctedId = request.recordId
                    }
                }
            }
            "Warehouse" -> {
                val t = database.warehouseTransferDao().getAll().first().firstOrNull { it.id == request.recordId }
                if (t != null) {
                    if (request.correctionType == CorrectionType.DELETE) {
                        database.warehouseTransferDao().upsert(t.copy(status = TransferStatus.CANCELLED.name))
                    } else {
                        database.warehouseTransferDao().upsert(applyFieldChange(t, params["field"], params["newValue"]))
                        correctedId = request.recordId
                    }
                }
            }
            // params: productId, warehouseId, quantity (original), newQuantity (for EDIT only)
            "Stock" -> {
                val productId = params["productId"] ?: ""
                val warehouseId = params["warehouseId"] ?: ""
                val quantity = params["quantity"]?.toDoubleOrNull() ?: 0.0
                if (productId.isNotBlank() && quantity != 0.0) {
                    // Reversal — undoes the original movement, for both EDIT and DELETE.
                    val reverseType = if (quantity > 0) com.abm.erp.data.MovementType.OUT else com.abm.erp.data.MovementType.IN
                    InventoryRepository.adjustStock(productId, warehouseId, kotlin.math.abs(quantity), reverseType, "Stock correction reversal — $requestId")
                    // Corrected Replacement Entry — EDIT only; DELETE stops at the reversal, nothing new is posted.
                    if (request.correctionType == CorrectionType.EDIT) {
                        val newQuantity = params["newQuantity"]?.toDoubleOrNull() ?: quantity
                        if (newQuantity != 0.0) {
                            val correctType = if (newQuantity > 0) com.abm.erp.data.MovementType.IN else com.abm.erp.data.MovementType.OUT
                            InventoryRepository.adjustStock(productId, warehouseId, kotlin.math.abs(newQuantity), correctType, "Corrected stock entry — correction $requestId")
                            correctedId = "CORR-${java.util.UUID.randomUUID().toString().take(8)}"
                        }
                    }
                }
            }
            // params: field, newValue (EDIT); DELETE zeroes the line out rather than deleting the payroll record outright, preserving the employee's payroll history row
            "Payroll" -> {
                val p = database.payrollDao().getAll().first().firstOrNull { it.employeeId == request.recordId }
                if (p != null) {
                    if (request.correctionType == CorrectionType.DELETE) {
                        database.payrollDao().upsertAll(listOf(p.copy(basePay = 0.0, targetAmount = 0.0, achievedAmount = 0.0)))
                    } else {
                        database.payrollDao().upsertAll(listOf(applyFieldChange(p, params["field"], params["newValue"])))
                        correctedId = request.recordId
                    }
                }
            }
        }
        val entity = database.correctionRequestDao().getAll().first().firstOrNull { it.id == requestId } ?: return@launchInRepoScope
        val updated = entity.copy(status = CorrectionRequestStatus.APPLIED.name, chairmanApprovedBy = currentUser.name, reversalEntryId = reversalId, correctedEntryId = correctedId)
        database.correctionRequestDao().upsert(updated)
        qrSyncCollection("correctionRequests").document(requestId).set(updated)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push correction-approve failed", it) }
        logAudit("CorrectionRequest", requestId, "CHAIRMAN_APPROVE", oldValue = request.originalValueJson, newValue = "reversal=$reversalId corrected=$correctedId module=${request.module} proposed=${request.proposedChangeJson}")
    }
    return true
}

fun MockRepository.chairmanRejectCorrection(requestId: String, reason: String): Boolean {
    if (currentUser.role != UserRole.CHAIRMAN || reason.isBlank()) return false
    launchInRepoScope {
        val entity = database.correctionRequestDao().getAll().first().firstOrNull { it.id == requestId } ?: return@launchInRepoScope
        val updated = entity.copy(status = CorrectionRequestStatus.REJECTED.name, chairmanComment = reason)
        database.correctionRequestDao().upsert(updated)
        qrSyncCollection("correctionRequests").document(requestId).set(updated)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push correction-reject failed", it) }
        logAudit("CorrectionRequest", requestId, "CHAIRMAN_REJECT", reason = reason)
    }
    return true
}
