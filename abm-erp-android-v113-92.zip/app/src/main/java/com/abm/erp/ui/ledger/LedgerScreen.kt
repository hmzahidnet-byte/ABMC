package com.abm.erp.ui.ledger

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.abm.erp.core.BackToSubMenuLink
import com.abm.erp.core.GlassCard
import com.abm.erp.core.ModuleGradientHeader
import com.abm.erp.core.SubModuleGrid
import com.abm.erp.core.SubModuleItem
import com.abm.erp.data.*
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import java.time.format.DateTimeFormatter
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

private val DATE_FMT = DateTimeFormatter.ofPattern("d MMM, h:mm a")

/**
 * Module 11 — Accounts & Finance. "Quick Ledger" (the original single-entry
 * IN/OUT recorder) stays exactly as it was; the new tabs are the formal
 * Chart of Accounts / double-entry Voucher layer backed by AccountsRepository.
 * NSM+ only (see ROLE_MODULES — "ledger" isn't in the SR/TSM/ASM/RSM/DSM sets).
 */
class LedgerViewModel : ViewModel() {
    val ledgerEntries = MockRepository.ledgerEntries
    val currentUser get() = MockRepository.currentUser
    fun addLedgerEntry(type: LedgerEntryType, category: String, description: String, amount: Double, recordedBy: String) =
        MockRepository.addLedgerEntry(type, category, description, amount, recordedBy)

    // ---- Module 11: Chart of Accounts / Vouchers / Reports ----
    val accounts = AccountsRepository.accounts
    val vouchers = AccountsRepository.vouchers
    fun createAccount(code: String, name: String, type: AccountType) = AccountsRepository.createAccount(code, name, type)
    fun createVoucher(type: VoucherType, narration: String, lines: List<VoucherLine>) = AccountsRepository.createVoucher(type, narration, lines)
    fun deleteVoucher(id: String) = AccountsRepository.deleteVoucher(id)
    fun reverseVoucher(id: String, reason: String) = AccountsRepository.reverseVoucher(id, reason)
    fun trialBalance() = AccountsRepository.computeTrialBalance()
    fun profitAndLoss() = AccountsRepository.computeProfitAndLoss()
    fun balanceSheet() = AccountsRepository.computeBalanceSheet()
    fun cashBook() = AccountsRepository.cashBookEntries()
    fun bankBook() = AccountsRepository.bankBookEntries()
    fun canCreate() = PermissionManager.canCurrentUser("ledger", PermissionAction.CREATE)
    fun canDelete() = PermissionManager.canCurrentUser("ledger", PermissionAction.DELETE)
    fun canExport() = PermissionManager.canCurrentUser("ledger", PermissionAction.EXPORT)
}

@Composable
fun LedgerScreen(startTab: Int? = null, onBack: () -> Unit = {}, onNavigate: (String) -> Unit = {}, vm: LedgerViewModel = viewModel()) {
    var tab by remember { mutableStateOf<Int?>(startTab) }

    // ---- Mini-dashboard data (Enterprise Workspace redesign) ----
    val ledgerEntriesForMini by vm.ledgerEntries.collectAsState()
    val collectionsForMini by MockRepository.partyCollections.collectAsState()
    val expensesForMini by MockRepository.expenses.collectAsState()
    val dealersForMini by MockRepository.dealers.collectAsState()
    val retailersForMini by MockRepository.retailers.collectAsState()
    val today = java.time.LocalDate.now()
    val todayCollection = collectionsForMini.filter { it.createdAt.toLocalDate() == today }.sumOf { it.amount }
    val todayExpense = expensesForMini.filter { it.status == ExpenseStatus.APPROVED && it.createdAt.toLocalDate() == today }.sumOf { it.amount }
    val cashNet = ledgerEntriesForMini.filter { it.category.contains("Cash", ignoreCase = true) }
        .sumOf { if (it.type == LedgerEntryType.IN) it.amount else -it.amount }
    val bankNet = ledgerEntriesForMini.filter { it.category.contains("Bank", ignoreCase = true) }
        .sumOf { if (it.type == LedgerEntryType.IN) it.amount else -it.amount }
    val outstanding = dealersForMini.sumOf { it.dueBalance } + retailersForMini.sumOf { it.dueBalance }

    val subItems = listOf(
        SubModuleItem("quick", "Quick Ledger", "📒", 0xFF4E9CFF, 0xFF2E6FE0, Icons.Filled.MenuBook),
        SubModuleItem("coa", "Chart of Accounts", "🗂️", 0xFF8A6DFF, 0xFF5B3FE0, Icons.Filled.AccountTree),
        SubModuleItem("voucher", "Vouchers", "🧾", 0xFFFFB020, 0xFFE08A00, Icons.Filled.ReceiptLong),
        SubModuleItem("cashbank", "Cash & Bank Book", "🏦", 0xFF3DDC97, 0xFF1FA972, Icons.Filled.AccountBalance),
        SubModuleItem("trial", "Trial Balance", "⚖️", 0xFFE85D4A, 0xFFC03A2B, Icons.Filled.Balance),
        SubModuleItem("pl", "Profit & Loss", "📈", 0xFF3FA9F5, 0xFF1D78C7, Icons.Filled.TrendingUp),
        SubModuleItem("bs", "Balance Sheet", "📊", 0xFFB45CFF, 0xFF7A2EE0, Icons.Filled.PieChart),
    )
    Column(Modifier.fillMaxSize()) {
        if (startTab == null) {
        com.abm.erp.core.ModuleWorkspaceHeader("Accounts & Finance", "💰", 0xFF12C2A9, 0xFF0E9F8B, iconVector = Icons.Filled.AccountBalance, miniDashboard = {
            com.abm.erp.core.ModuleStat("Collection", "৳${"%,.0f".format(todayCollection)}", SuccessGreen)
            com.abm.erp.core.ModuleStat("Expense", "৳${"%,.0f".format(todayExpense)}", DangerRed)
            com.abm.erp.core.ModuleStat("Cash", "৳${"%,.0f".format(cashNet)}", TextPrimary)
            com.abm.erp.core.ModuleStat("Bank", "৳${"%,.0f".format(bankNet)}", TextPrimary)
            com.abm.erp.core.ModuleStat("Outstanding", "৳${"%,.0f".format(outstanding)}", if (outstanding > 0) WarningAmber else SuccessGreen)
        }, quickActions = {
            AssistChip(onClick = { onNavigate("expenses") }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.Payments, null, Modifier.size(16.dp)) }, label = { Text("Expense") })
            AssistChip(onClick = { tab = 2 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.ReceiptLong, null, Modifier.size(16.dp)) }, label = { Text("Voucher") })
            AssistChip(onClick = { tab = 3 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.Balance, null, Modifier.size(16.dp)) }, label = { Text("Reconcile") })
            AssistChip(onClick = { onNavigate("period_lock_center") }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.Lock, null, Modifier.size(16.dp)) }, label = { Text("Close Period") })
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("Voucher", "Expense", "Collection", "ChartOfAccount"))
        })
        } else {
            val taskKey = when (tab) { 0 -> "quick"; 1 -> "coa"; 2 -> "voucher"; 3 -> "cashbank"; 4 -> "trial"; 5 -> "pl"; else -> "bs" }
            val taskTitle = subItems.firstOrNull { it.key == taskKey }?.label ?: "Finance"
            com.abm.erp.core.TaskHeader(taskTitle, 0xFF12C2A9, 0xFF0E9F8B, onBack = onBack, iconVector = Icons.Filled.AccountBalance)
        }
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            if (tab == null) {
                SubModuleGrid(subItems) { key -> tab = when (key) { "quick" -> 0; "coa" -> 1; "voucher" -> 2; "cashbank" -> 3; "trial" -> 4; "pl" -> 5; else -> 6 } }
            } else {
                if (startTab == null) BackToSubMenuLink(onClick = { tab = null })
                when (tab) {
                    0 -> QuickLedgerTab(vm)
                    1 -> ChartOfAccountsTab(vm)
                    2 -> VouchersTab(vm)
                    3 -> CashBankBookTab(vm)
                    4 -> TrialBalanceTab(vm)
                    5 -> ProfitLossTab(vm)
                    else -> BalanceSheetTab(vm)
                }
            }
        }
    }
}

@Composable
private fun QuickLedgerTab(vm: LedgerViewModel) {
    val allEntries by vm.ledgerEntries.collectAsState()
    val viewerRole = vm.currentUser.role
    val viewerDivision = EMPLOYEE_DIRECTORY.firstOrNull { it.id == vm.currentUser.employeeId }?.geo?.division
    val entries = if (viewerRole == UserRole.CHAIRMAN) allEntries
        else allEntries.filter { it.division == null || it.division == viewerDivision }
    val totalIn = entries.filter { it.type == LedgerEntryType.IN }.sumOf { it.amount }
    val totalOut = entries.filter { it.type == LedgerEntryType.OUT }.sumOf { it.amount }
    val balance = totalIn - totalOut

    // ---- Accounts Excellence: Cash/Bank/Receivable/Payable — all from real data, no fabricated numbers ----
    val vouchersForSummary by vm.vouchers.collectAsState()
    val dealersForSummary by MockRepository.dealers.collectAsState()
    val suppliersForSummary by com.abm.erp.data.PurchaseRepository.suppliers.collectAsState()
    // "Cash"/"Bank" split is inferred from the account NAME the user typed in Chart of Accounts (e.g. "Cash in Hand", "City Bank a/c") — there's no dedicated cash-vs-bank flag on Voucher/VoucherLine, so this is a real-data heuristic, not a fabricated split.
    val cashMovement = remember(vouchersForSummary) {
        vouchersForSummary.flatMap { it.lines }.filter { it.accountName.contains("cash", ignoreCase = true) }.sumOf { it.debit - it.credit }
    }
    val bankMovement = remember(vouchersForSummary) {
        vouchersForSummary.flatMap { it.lines }.filter { it.accountName.contains("bank", ignoreCase = true) }.sumOf { it.debit - it.credit }
    }
    val totalReceivable = remember(dealersForSummary) { dealersForSummary.filter { it.dueBalance > 0 }.sumOf { it.dueBalance } }
    val totalPayable = remember(suppliersForSummary) { suppliersForSummary.filter { it.dueBalance > 0 }.sumOf { it.dueBalance } }

    var showAdd by remember { mutableStateOf(false) }
    var newType by remember { mutableStateOf(LedgerEntryType.IN) }
    var newCategory by remember { mutableStateOf("") }
    var newDescription by remember { mutableStateOf("") }
    var newAmount by remember { mutableStateOf("") }

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Running balance", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                Text(
                    "৳${"%,.0f".format(balance)}", style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold, color = if (balance >= 0) SuccessGreen else DangerRed,
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column {
                        Text("Total in", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("৳${"%,.0f".format(totalIn)}", color = SuccessGreen, fontWeight = FontWeight.SemiBold)
                    }
                    Column {
                        Text("Total out", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text("৳${"%,.0f".format(totalOut)}", color = DangerRed, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Accounts Summary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column { Text("Cash Movement", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(cashMovement)}", fontWeight = FontWeight.Bold, color = if (cashMovement >= 0) SuccessGreen else DangerRed) }
                    Column { Text("Bank Movement", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(bankMovement)}", fontWeight = FontWeight.Bold, color = if (bankMovement >= 0) SuccessGreen else DangerRed) }
                    Column { Text("Receivable", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(totalReceivable)}", fontWeight = FontWeight.Bold, color = WarningAmber) }
                    Column { Text("Payable", style = MaterialTheme.typography.labelSmall, color = TextSecondary); Text("৳${"%,.0f".format(totalPayable)}", fontWeight = FontWeight.Bold, color = DangerRed) }
                }
            }
        }

        item {
            if (!showAdd) {
                Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Record entry") }
            } else {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LedgerEntryType.values().forEach { t ->
                            FilterChip(
                                selected = newType == t, onClick = { newType = t },
                                label = { Text(if (t == LedgerEntryType.IN) "Money in" else "Money out") },
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newCategory, onValueChange = { newCategory = it }, label = { Text("Category") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newDescription, onValueChange = { newDescription = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newAmount, onValueChange = { newAmount = it }, label = { Text("Amount (৳)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                val amt = newAmount.toDoubleOrNull() ?: return@Button
                                if (newCategory.isBlank() || amt <= 0) return@Button
                                vm.addLedgerEntry(newType, newCategory, newDescription, amt, vm.currentUser.name)
                                newCategory = ""; newDescription = ""; newAmount = ""; showAdd = false
                            },
                        ) { Text("Save") }
                        OutlinedButton(onClick = { showAdd = false }) { Text("Cancel") }
                    }
                }
            }
        }

        item { Text("Recent entries", style = MaterialTheme.typography.titleMedium) }
        if (entries.isEmpty()) {
            item { com.abm.erp.core.WorkspaceEmptyState("এখনো কোনো লেজার এন্ট্রি নেই।", "📒") }
        }
        items(entries, key = { it.id }) { entry ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(entry.category, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(entry.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Text("${entry.recordedBy} · ${entry.recordedAt.format(DATE_FMT)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Text(
                        (if (entry.type == LedgerEntryType.IN) "+৳" else "−৳") + "%,.0f".format(entry.amount),
                        color = if (entry.type == LedgerEntryType.IN) SuccessGreen else DangerRed, fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
        if (entries.isEmpty()) {
            item { Text("No ledger entries yet.", color = TextSecondary) }
        }
    }
}

@Composable
private fun ChartOfAccountsTab(vm: LedgerViewModel) {
    val accountsRaw by vm.accounts.collectAsState()
    val vouchers by vm.vouchers.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var drilldownAccount by remember { mutableStateOf<com.abm.erp.data.ChartOfAccount?>(null) }
    var query by remember { mutableStateOf("") }
    val accounts = remember(accountsRaw, query) { if (query.isBlank()) accountsRaw else accountsRaw.filter { it.name.contains(query, ignoreCase = true) || it.code.contains(query, ignoreCase = true) } }

    Column(Modifier.fillMaxSize()) {
        if (vm.canCreate()) {
            Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add Account") }
            Spacer(Modifier.height(10.dp))
        }
        OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("Account নাম বা কোড দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (accounts.isEmpty()) {
                item { com.abm.erp.core.WorkspaceEmptyState("কোনো Account পাওয়া যায়নি।", "🗂️") }
            }
            AccountType.values().forEach { type ->
                val group = accounts.filter { it.type == type }
                if (group.isNotEmpty()) {
                    item { Text(type.name, style = MaterialTheme.typography.titleSmall, color = TextSecondary, fontWeight = FontWeight.Bold) }
                    items(group, key = { it.id }) { a ->
                        GlassCard(modifier = Modifier.fillMaxWidth().clickable { drilldownAccount = a }) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${a.code} — ${a.name}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                com.abm.erp.core.UniversalActionMenu(moduleReference = "ChartOfAccount", entityId = a.id, entityLabel = a.name, shareText = "${a.code} — ${a.name} (${a.type})", csvHeader = "Code,Name,Type", csvRow = com.abm.erp.core.toCsvRow(a.code, a.name, a.type))
                            }
                        }
                    }
                }
            }
        }
    }

    if (drilldownAccount != null) {
        val acc = drilldownAccount!!
        val entries = vouchers.flatMap { v -> v.lines.filter { it.accountName == acc.name }.map { line -> Triple(v.voucherNo, v.voucherDate, line) } }
            .sortedByDescending { it.second }
        val balance = entries.sumOf { it.third.debit - it.third.credit }
        Dialog(onDismissRequest = { drilldownAccount = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 500.dp)) {
                    Text("${acc.code} — ${acc.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Balance: ৳${"%,.0f".format(balance)}", style = MaterialTheme.typography.bodyMedium, color = if (balance >= 0) SuccessGreen else DangerRed)
                    Spacer(Modifier.height(10.dp))
                    if (entries.isEmpty()) {
                        Text("এই account-এ এখনো কোনো voucher entry নেই।", color = TextSecondary)
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(entries) { (voucherNo, date, line) ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text(voucherNo, style = MaterialTheme.typography.bodySmall)
                                        Text(date.toLocalDate().toString(), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                    }
                                    Text(if (line.debit > 0) "Dr ৳${"%.0f".format(line.debit)}" else "Cr ৳${"%.0f".format(line.credit)}", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    TextButton(onClick = { drilldownAccount = null }) { Text("Close") }
                }
            }
        }
    }

    if (showAdd) {
        Dialog(onDismissRequest = { showAdd = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var code by remember { mutableStateOf("") }
                var name by remember { mutableStateOf("") }
                var type by remember { mutableStateOf(AccountType.EXPENSE) }
                var expanded by remember { mutableStateOf(false) }
                Column(Modifier.padding(16.dp)) {
                    Text("New Account", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Account code (e.g. 5400)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Account name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(type.name) }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            AccountType.values().forEach { t -> DropdownMenuItem(text = { Text(t.name) }, onClick = { type = t; expanded = false }) }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { if (vm.createAccount(code, name, type) != null) showAdd = false },
                        enabled = code.isNotBlank() && name.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Create Account") }
                }
            }
        }
    }
}

@Composable
private fun VouchersTab(vm: LedgerViewModel) {
    val vouchers by vm.vouchers.collectAsState()
    var showNew by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var typeFilter by remember { mutableStateOf<String?>(null) }
    var accountFilter by remember { mutableStateOf<String?>(null) }
    var dateFilter by remember { mutableStateOf(0) }
    val voucherCutoff = when (dateFilter) {
        1 -> java.time.LocalDate.now().atStartOfDay()
        2 -> java.time.LocalDate.now().minusDays(7).atStartOfDay()
        3 -> java.time.LocalDate.now().minusDays(30).atStartOfDay()
        else -> null
    }
    val accountNames = remember(vouchers) { vouchers.flatMap { it.lines }.map { it.accountName }.distinct().sorted() }
    val filteredVouchers = remember(vouchers, searchQuery, typeFilter, accountFilter, dateFilter) {
        vouchers.filter { v ->
            (searchQuery.isBlank() || v.voucherNo.contains(searchQuery, ignoreCase = true) || v.narration.contains(searchQuery, ignoreCase = true)) &&
                (typeFilter == null || v.type.name == typeFilter) &&
                (accountFilter == null || v.lines.any { it.accountName == accountFilter }) &&
                (voucherCutoff == null || v.voucherDate.isAfter(voucherCutoff))
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            val context = androidx.compose.ui.platform.LocalContext.current
            com.abm.erp.core.ModuleActionBar(
                onExport = {
                    val header = "VoucherNo,Type,Narration,TotalDebit,TotalCredit\n"
                    val rows = filteredVouchers.joinToString("\n") { v -> com.abm.erp.core.toCsvRow(v.voucherNo, v.type, v.narration, v.totalDebit, v.totalCredit) }
                    val file = java.io.File(context.getExternalFilesDir(null), "vouchers_${System.currentTimeMillis()}.csv")
                    file.writeText(header + rows)
                    android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                },
                onShare = {
                    val summary = "Vouchers (${filteredVouchers.size})\n" + filteredVouchers.take(20).joinToString("\n") { "${it.voucherNo} (${it.type}) ৳${it.totalDebit}" }
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                    try { context.startActivity(android.content.Intent.createChooser(intent, "Vouchers")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                },
            )
        }
        // Decision 2 (v113-72) — over-limit voucher approvals are actioned here, in the
        // Vouchers tab that raised them (AccountsRepository → raiseApprovalRequest("Voucher")).
        com.abm.erp.core.ModuleApprovalSection(
            title = "Voucher অনুমোদনের অপেক্ষায়",
            entityTypes = setOf("Voucher"),
        )
        OutlinedTextField(value = searchQuery, onValueChange = { searchQuery = it }, placeholder = { Text("Voucher no/narration খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            FilterChip(selected = typeFilter == null, onClick = { typeFilter = null }, label = { Text("All Types") })
            com.abm.erp.data.VoucherType.values().forEach { t -> FilterChip(selected = typeFilter == t.name, onClick = { typeFilter = t.name }, label = { Text(t.name) }) }
        }
        if (accountNames.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                FilterChip(selected = accountFilter == null, onClick = { accountFilter = null }, label = { Text("All Accounts") })
                accountNames.forEach { a -> FilterChip(selected = accountFilter == a, onClick = { accountFilter = a }, label = { Text(a) }) }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            FilterChip(selected = dateFilter == 0, onClick = { dateFilter = 0 }, label = { Text("All") })
            FilterChip(selected = dateFilter == 1, onClick = { dateFilter = 1 }, label = { Text("Today") })
            FilterChip(selected = dateFilter == 2, onClick = { dateFilter = 2 }, label = { Text("Week") })
            FilterChip(selected = dateFilter == 3, onClick = { dateFilter = 3 }, label = { Text("Month") })
        }
        Spacer(Modifier.height(10.dp))
        if (vm.canCreate()) {
            Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("+ New Voucher") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (filteredVouchers.isEmpty()) {
                item { com.abm.erp.core.WorkspaceEmptyState("কোনো Voucher পাওয়া যায়নি — ফিল্টার পরিবর্তন করে দেখুন।", "🧾") }
            }
            items(filteredVouchers, key = { it.id }) { v ->
                val voucherAuditLog by MockRepository.activityLogFor("Voucher", v.id).collectAsState(initial = emptyList())
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${v.voucherNo} (${v.type})", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(v.narration.ifBlank { "—" }, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            v.lines.forEach { l ->
                                Text("  ${l.accountName}: Dr ৳${"%,.0f".format(l.debit)} / Cr ৳${"%,.0f".format(l.credit)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                        if (vm.canDelete()) {
                            TextButton(onClick = { vm.deleteVoucher(v.id) }) { Text("✕", color = DangerRed) }
                            var showReverse by remember { mutableStateOf(false) }
                            TextButton(onClick = { showReverse = true }) { Text("Reverse") }
                            if (showReverse) {
                                var reason by remember { mutableStateOf("") }
                                Dialog(onDismissRequest = { showReverse = false }) {
                                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                        Column(Modifier.padding(16.dp)) {
                                            Text("Reverse Voucher ${v.voucherNo}", style = MaterialTheme.typography.titleMedium)
                                            Spacer(Modifier.height(8.dp))
                                            OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason (required)") }, modifier = Modifier.fillMaxWidth())
                                            Spacer(Modifier.height(10.dp))
                                            Button(onClick = { if (reason.isNotBlank()) { vm.reverseVoucher(v.id, reason); showReverse = false } }, enabled = reason.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Confirm Reversal") }
                                        }
                                    }
                                }
                            }
                        }
                        val context = androidx.compose.ui.platform.LocalContext.current
                        TextButton(onClick = {
                            try {
                                val file = com.abm.erp.core.exportVoucherPdf(context, v)
                                com.abm.erp.core.shareStructuredPdf(context, file, "Voucher ${v.voucherNo}")
                            } catch (e: Exception) {
                                android.widget.Toast.makeText(context, "Voucher PDF তৈরি ব্যর্থ হয়েছে: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                            }
                        }) { Text("📄", style = MaterialTheme.typography.labelSmall) }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Voucher", entityId = v.id, entityLabel = v.voucherNo,
                            shareText = "${v.voucherNo} (${v.type})\n${v.narration}\nTotal: ৳${v.totalDebit}",
                            isDeleted = v.isDeleted,
                            recordStatus = "POSTED", // Task 4 — a Voucher is a posted ledger entry the moment it's created (no draft state exists), so it's always in the protected category; Archive shows disabled with an explanation instead of silently deleting ledger history.
                            onArchive = { vm.deleteVoucher(v.id) },
                            canArchive = vm.canDelete(),
                            csvHeader = "VoucherNo,Type,Narration,TotalDebit,TotalCredit",
                            csvRow = com.abm.erp.core.toCsvRow(v.voucherNo, v.type, v.narration, v.totalDebit, v.totalCredit),
                            historyLabel = "Voucher Timeline",
                            historyItems = voucherAuditLog.sortedByDescending { it.timestamp }.map { "${it.action} — ${it.performedBy} (${it.timestamp.toLocalDate()})" },
                        )
                    }
                }
            }
            if (filteredVouchers.isEmpty()) item { Text("এই ফিল্টারে কোনো Voucher নেই।", color = TextSecondary) }
        }
    }

    if (showNew) {
        Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                NewVoucherForm(vm) { showNew = false }
            }
        }
    }
}

@Composable
private fun NewVoucherForm(vm: LedgerViewModel, onDone: () -> Unit) {
    val accounts by vm.accounts.collectAsState()
    var type by remember { mutableStateOf(VoucherType.PAYMENT) }
    var narration by remember { mutableStateOf("") }
    val lines = remember { mutableStateListOf<VoucherLine>() }
    var drAccount by remember { mutableStateOf<ChartOfAccount?>(null) }
    var crAccount by remember { mutableStateOf<ChartOfAccount?>(null) }
    var amountText by remember { mutableStateOf("") }
    var costCenter by remember { mutableStateOf("") }
    var drExpanded by remember { mutableStateOf(false) }
    var crExpanded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.padding(16.dp).heightIn(max = 600.dp)) {
        Text("New Voucher", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            VoucherType.values().forEach { t -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t.name) }) }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = narration, onValueChange = { narration = it }, label = { Text("Narration") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        Text("সহজ double-entry — একটা Debit account আর একটা Credit account বেছে নিন, সমপরিমাণ টাকা দুই দিকে পোস্ট হবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(8.dp))
        Box {
            OutlinedButton(onClick = { drExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Debit: " + (drAccount?.name ?: "Select account")) }
            DropdownMenu(expanded = drExpanded, onDismissRequest = { drExpanded = false }) {
                accounts.forEach { a -> DropdownMenuItem(text = { Text("${a.code} ${a.name}") }, onClick = { drAccount = a; drExpanded = false }) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Box {
            OutlinedButton(onClick = { crExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Credit: " + (crAccount?.name ?: "Select account")) }
            DropdownMenu(expanded = crExpanded, onDismissRequest = { crExpanded = false }) {
                accounts.forEach { a -> DropdownMenuItem(text = { Text("${a.code} ${a.name}") }, onClick = { crAccount = a; crExpanded = false }) }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("Amount (৳)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = costCenter, onValueChange = { costCenter = it }, label = { Text("Cost Center (optional)") }, modifier = Modifier.fillMaxWidth())
        error?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 6.dp)) }
        val previewAmt = amountText.toDoubleOrNull()
        if (previewAmt != null && drAccount != null && crAccount != null) {
            Spacer(Modifier.height(10.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Journal Preview", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Dr ${drAccount!!.name}"); Text("৳${"%,.0f".format(previewAmt)}") }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Cr ${crAccount!!.name}"); Text("৳${"%,.0f".format(previewAmt)}") }
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = {
                val amt = amountText.toDoubleOrNull() ?: return@Button
                val dr = drAccount ?: return@Button
                val cr = crAccount ?: return@Button
                val voucherLines = listOf(
                    VoucherLine(accountId = dr.id, accountName = dr.name, debit = amt, credit = 0.0, costCenter = costCenter.ifBlank { null }),
                    VoucherLine(accountId = cr.id, accountName = cr.name, debit = 0.0, credit = amt, costCenter = costCenter.ifBlank { null }),
                )
                val created = vm.createVoucher(type, narration, voucherLines)
                if (created == null) error = "Voucher balance মেলেনি অথবা permission নেই।" else onDone()
            },
            enabled = drAccount != null && crAccount != null && amountText.toDoubleOrNull() != null,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Post Voucher") }
    }
}

@Composable
private fun CashBankBookTab(vm: LedgerViewModel) {
    var sub by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = sub) {
            Tab(selected = sub == 0, onClick = { sub = 0 }, text = { Text("Cash Book") })
            Tab(selected = sub == 1, onClick = { sub = 1 }, text = { Text("Bank Book") })
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("বিবরণ দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        val rowsRaw = if (sub == 0) vm.cashBook() else vm.bankBook()
        val rows = if (query.isBlank()) rowsRaw else rowsRaw.filter { (v, _) -> v.narration.contains(query, ignoreCase = true) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (rows.isEmpty()) {
                item { com.abm.erp.core.WorkspaceEmptyState("কোনো এন্ট্রি পাওয়া যায়নি।", "🏦") }
            }
            items(rows) { (voucher, line) ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${voucher.voucherNo} — ${voucher.narration.ifBlank { voucher.type.name }}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(voucher.createdAt.format(DATE_FMT), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text(
                            if (line.debit > 0) "+৳${"%,.0f".format(line.debit)}" else "−৳${"%,.0f".format(line.credit)}",
                            color = if (line.debit > 0) SuccessGreen else DangerRed, fontWeight = FontWeight.Bold,
                        )
                    }
                    if (sub == 1) {
                        val lineIndex = voucher.lines.indexOf(line)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = line.isReconciled, onCheckedChange = { AccountsRepository.toggleLineReconciled(voucher.id, lineIndex) })
                            Text(if (line.isReconciled) "Reconciled" else "Not reconciled", style = MaterialTheme.typography.labelSmall, color = if (line.isReconciled) SuccessGreen else TextSecondary)
                        }
                    }
                }
            }
            if (rows.isEmpty()) item { Text("এখনো কোনো এন্ট্রি নেই।", color = TextSecondary) }
        }
    }
}

@Composable
private fun TrialBalanceTab(vm: LedgerViewModel) {
    val rowsRaw = vm.trialBalance()
    val totalDebit = rowsRaw.sumOf { it.totalDebit }
    val totalCredit = rowsRaw.sumOf { it.totalCredit }
    var query by remember { mutableStateOf("") }
    val rows = if (query.isBlank()) rowsRaw else rowsRaw.filter { it.account.name.contains(query, ignoreCase = true) || it.account.code.contains(query, ignoreCase = true) }
    Column(Modifier.fillMaxSize()) {
        Text("Trial Balance", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("Account নাম বা কোড দিয়ে খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
            if (rows.isEmpty()) {
                item { com.abm.erp.core.WorkspaceEmptyState("কোনো Trial Balance ডেটা পাওয়া যায়নি।", "⚖️") }
            }
            items(rows) { r ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${r.account.code} ${r.account.name}", style = MaterialTheme.typography.bodySmall)
                    Text("Dr ৳${"%,.0f".format(r.netDebit)}  Cr ৳${"%,.0f".format(r.netCredit)}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Divider(modifier = Modifier.padding(vertical = 6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Total", fontWeight = FontWeight.Bold)
            Text("Dr ৳${"%,.0f".format(totalDebit)}  Cr ৳${"%,.0f".format(totalCredit)}", fontWeight = FontWeight.Bold, color = if (kotlin.math.abs(totalDebit - totalCredit) < 0.01) SuccessGreen else DangerRed)
        }
        val ccSummary = AccountsRepository.costCenterSummary()
        if (ccSummary.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Text("Cost Center Summary", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            ccSummary.forEach { (cc, pair) ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(cc, style = MaterialTheme.typography.bodySmall)
                    Text("Dr ৳${"%,.0f".format(pair.first)}  Cr ৳${"%,.0f".format(pair.second)}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        val closedPeriods by AccountsRepository.closedPeriods.collectAsState()
        val currentYearMonth = remember { java.time.LocalDate.now().let { "%04d-%02d".format(it.year, it.monthValue) } }
        Spacer(Modifier.height(10.dp))
        Text("Financial Closing", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        if (closedPeriods.contains(currentYearMonth)) {
            Text("$currentYearMonth is closed — no new vouchers can be posted this month.", color = DangerRed, style = MaterialTheme.typography.bodySmall)
        } else {
            Text("$currentYearMonth is open.", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(6.dp))
            var showConfirm by remember { mutableStateOf(false) }
            TextButton(onClick = { showConfirm = true }) { Text("Close $currentYearMonth", color = DangerRed) }
            if (showConfirm) {
                Dialog(onDismissRequest = { showConfirm = false }) {
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Close $currentYearMonth?", style = MaterialTheme.typography.titleMedium)
                            Text("এই মাসে আর কোনো নতুন voucher post করা যাবে না। এটা undo করা যায় না।", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            Spacer(Modifier.height(10.dp))
                            Button(onClick = { AccountsRepository.closePeriod(currentYearMonth); showConfirm = false }, colors = ButtonDefaults.buttonColors(containerColor = DangerRed), modifier = Modifier.fillMaxWidth()) { Text("Confirm Close") }
                        }
                    }
                }
            }
        }
        if (closedPeriods.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text("Closed periods: " + closedPeriods.joinToString(", "), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
    }
}

@Composable
private fun ProfitLossTab(vm: LedgerViewModel) {
    val (income, expense, net) = vm.profitAndLoss()
    Column(Modifier.fillMaxSize()) {
        Text("Profit & Loss", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Total Income"); Text("৳${"%,.0f".format(income)}", color = SuccessGreen, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Total Expense"); Text("৳${"%,.0f".format(expense)}", color = DangerRed, fontWeight = FontWeight.Bold) }
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Net Profit / (Loss)", fontWeight = FontWeight.Bold)
                Text("৳${"%,.0f".format(net)}", color = if (net >= 0) SuccessGreen else DangerRed, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@Composable
private fun BalanceSheetTab(vm: LedgerViewModel) {
    val (assets, liabilities, equity) = vm.balanceSheet()
    val totalAssets = assets.sumOf { it.netDebit }
    val totalLiabEquity = liabilities.sumOf { it.netCredit } + equity.sumOf { it.netCredit }
    Column(Modifier.fillMaxSize()) {
        Text("Balance Sheet", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (assets.isEmpty() && liabilities.isEmpty() && equity.isEmpty()) {
                item { com.abm.erp.core.WorkspaceEmptyState("কোনো Balance Sheet ডেটা নেই।", "📊") }
            }
            item { Text("Assets", fontWeight = FontWeight.Bold, color = TextSecondary) }
            items(assets) { r -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(r.account.name); Text("৳${"%,.0f".format(r.netDebit)}") } }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Total Assets", fontWeight = FontWeight.Bold); Text("৳${"%,.0f".format(totalAssets)}", fontWeight = FontWeight.Bold) } }
            item { Spacer(Modifier.height(10.dp)); Text("Liabilities", fontWeight = FontWeight.Bold, color = TextSecondary) }
            items(liabilities) { r -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(r.account.name); Text("৳${"%,.0f".format(r.netCredit)}") } }
            item { Spacer(Modifier.height(10.dp)); Text("Equity", fontWeight = FontWeight.Bold, color = TextSecondary) }
            items(equity) { r -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(r.account.name); Text("৳${"%,.0f".format(r.netCredit)}") } }
            item {
                Divider(modifier = Modifier.padding(vertical = 8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Liabilities + Equity", fontWeight = FontWeight.Bold)
                    Text("৳${"%,.0f".format(totalLiabEquity)}", fontWeight = FontWeight.Bold, color = if (kotlin.math.abs(totalAssets - totalLiabEquity) < 0.01) SuccessGreen else WarningAmber)
                }
            }
        }
    }
}
