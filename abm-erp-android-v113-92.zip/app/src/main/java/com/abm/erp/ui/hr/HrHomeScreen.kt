package com.abm.erp.ui.hr

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abm.erp.core.ModuleDrawerItem
import com.abm.erp.core.ModuleDrawerScaffold
import com.abm.erp.theme.TextSecondary

/**
 * HR — Employee Management System (sales-wing office HR). Mother module #3.
 *
 * Built to the person's HR draft. Everything here is **hosting** — the HR feature set
 * already exists as working code in `PayrollScreen`'s tabs, `EmployeeSetupScreen`,
 * `ComplaintBoxScreen`, and `VacancyTargetCenterScreen` (targets). No new schema, no
 * new repository function; this module gives them the one drawer-based home the draft
 * asks for, exactly the way DMS hosts the invoice/dealer tabs.
 *
 * `PayrollScreen(startTab = N)` is the hosting mechanism: with a non-null startTab it
 * renders its own compact `TaskHeader` + the one tab, never the full HRM dashboard —
 * that's the v113-71 TaskHeader behaviour, reused rather than re-implemented. Its
 * onBack returns the drawer selection to this module's own dashboard.
 *
 * The draft's card 9, "HR (Factory) Module", is deliberately a cross-reference, not a
 * copy: factory workforce lives inside FMS (ProductionScreen's Factory HRM tab), and
 * the person confirmed factory HR stays separate from office HR. Listing it here as a
 * drawer item would put one feature in two mother modules — against the one-home rule —
 * so this module simply doesn't list it, and FMS does.
 */
private val HR_COLOR_START = 0xFFDB2777
private val HR_COLOR_END = 0xFF9D174D

private val HR_ITEMS = listOf(
    ModuleDrawerItem("dashboard", "Dashboard", Icons.Filled.Home, "সারসংক্ষেপ"),
    ModuleDrawerItem("employees", "Employee List", Icons.Filled.Groups, "Directory & Full Report"),
    ModuleDrawerItem("attendance", "Attendance", Icons.Filled.Schedule, "Live Attendance & Field Tracking"),
    ModuleDrawerItem("target", "Target", Icons.Filled.TrackChanges, "Target Setting & Tracking"),
    ModuleDrawerItem("payroll", "Finance (Payroll)", Icons.Filled.CreditCard, "Salary & Financial Management"),
    ModuleDrawerItem("performance", "Performance", Icons.Filled.Insights, "Performance Analytics"),
    ModuleDrawerItem("add", "Employee Add / Management", Icons.Filled.PersonAdd, "Employee Administration"),
    ModuleDrawerItem("lifecycle", "Increment / Promotion / Transfer", Icons.Filled.Assignment, "Lifecycle Events"),
    ModuleDrawerItem("leave", "Leave Management", Icons.Filled.BeachAccess, "Leave & Approvals"),
    ModuleDrawerItem("complain", "Complain Box", Icons.Filled.MarkunreadMailbox, "Direct to Chairman"),
    ModuleDrawerItem("reports", "Reports", Icons.Filled.InsertChart, "HR Reports & Analytics"),
)

@Composable
fun HrHomeScreen(
    startKey: String? = null,
    onBackToHome: () -> Unit = {},
    onNavigate: (String) -> Unit = {},
) {
    var selected by remember { mutableStateOf(startKey ?: "dashboard") }

    ModuleDrawerScaffold(
        moduleName = "HR",
        moduleSubtitle = "Employee Management System",
        colorStart = HR_COLOR_START,
        colorEnd = HR_COLOR_END,
        moduleIcon = Icons.Filled.Groups,
        items = HR_ITEMS,
        selectedKey = selected,
        onSelect = { selected = it },
        onBackToHome = onBackToHome,
    ) { key ->
        // PayrollScreen's own tab indices, verified against its `when (tab)` block:
        // 0 attend · 1 payroll · 2 leave · 3 lifecycle · 4 directory · 5 empmgmt.
        val backToDash: () -> Unit = { selected = "dashboard" }
        when (key) {
            "dashboard" -> HrDashboardHost()
            // v113-85 — same approved browse pattern, employee-shaped (no ledger/graph:
            // employees aren't money-bearing parties here, so those would be empty).
            "employees" -> {
                val profiles = com.abm.erp.core.rememberVisibleEmployeeProfiles()
                com.abm.erp.core.ModuleBrowseList(
                    config = com.abm.erp.core.rememberEmployeeBrowseConfig(
                        departments = remember(profiles) { profiles.map { it.department }.filter { it.isNotBlank() }.distinct().sorted() },
                    ),
                    records = profiles,
                    onBack = backToDash,
                    onNavigate = onNavigate,
                )
            }
            "attendance" -> com.abm.erp.ui.hrm.PayrollScreen(startTab = 0, onBack = backToDash)
            "payroll" -> com.abm.erp.ui.hrm.PayrollScreen(startTab = 1, onBack = backToDash)
            "leave" -> com.abm.erp.ui.hrm.PayrollScreen(startTab = 2, onBack = backToDash)
            "lifecycle" -> com.abm.erp.ui.hrm.PayrollScreen(startTab = 3, onBack = backToDash)
            "add" -> com.abm.erp.ui.hrm.PayrollScreen(startTab = 5, onBack = backToDash)
            "target" -> com.abm.erp.ui.admin.VacancyTargetCenterScreen()
            "complain" -> com.abm.erp.ui.complaint.ComplaintBoxScreen()
            "performance" -> HrPerformanceTab()
            "reports" -> HrReportsTab()
            else -> HrDashboardHost()
        }
    }
}

/**
 * Compact HR dashboard. Deliberately NOT PayrollScreen(startTab = null) — that renders
 * the full old module dashboard (workspace header + tile grid), which inside the drawer
 * shell is precisely the "second dashboard before the task" clutter the TaskHeader fix
 * (v113-71) and the drawer redesign both exist to remove.
 */
@Composable
private fun HrDashboardHost() {
    val leaves by com.abm.erp.data.MockRepository.leaveRequests.collectAsState()
    val profiles by com.abm.erp.data.MockRepository.employeeProfiles.collectAsState()
    val today = java.time.LocalDate.now()
    val pendingLeaves = remember(leaves) { leaves.count { it.status == com.abm.erp.data.LeaveStatus.PENDING } }
    val onLeaveToday = remember(leaves) {
        leaves.count { it.status == com.abm.erp.data.LeaveStatus.APPROVED && !today.isBefore(it.fromDate) && !today.isAfter(it.toDate) }
    }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("HR Overview", style = MaterialTheme.typography.titleMedium, color = com.abm.erp.theme.TextPrimary)
        Spacer(Modifier.height(12.dp))
        com.abm.erp.core.GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Employee Profile", color = TextSecondary)
                Text("${profiles.size}", color = com.abm.erp.theme.TextPrimary)
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Pending Leave", color = TextSecondary)
                Text("$pendingLeaves", color = if (pendingLeaves > 0) com.abm.erp.theme.WarningAmber else com.abm.erp.theme.SuccessGreen)
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("আজ ছুটিতে", color = TextSecondary)
                Text("$onLeaveToday", color = com.abm.erp.theme.TextPrimary)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Attendance/Payroll/Leave-এর বিস্তারিত বাম মেনু থেকে খুলুন।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
    }
}

/**
 * v113-77 — Employee Performance, inside HR where the person's draft puts it.
 * Uses the existing `computeEmployeePerformance` (Foundation 2 §16) — real, per-
 * employee data from actual linked ledger/visit records, not the CRM tab's dealer
 * ranking (which is a different feature and stays where it is). Cascade-scoped: the
 * viewer only sees employees `visibleEmployeeProfilesFor` allows.
 */
@Composable
private fun HrPerformanceTab() {
    val profiles = com.abm.erp.core.rememberVisibleEmployeeProfiles()
    var selectedId by remember { mutableStateOf<String?>(null) }
    var perf by remember { mutableStateOf<com.abm.erp.data.MockRepository.EmployeePerformance?>(null) }

    LaunchedEffect(selectedId) {
        perf = selectedId?.let { com.abm.erp.data.MockRepository.computeEmployeePerformance(it) }
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Employee Performance", style = MaterialTheme.typography.titleMedium, color = com.abm.erp.theme.TextPrimary)
        Spacer(Modifier.height(8.dp))
        androidx.compose.foundation.lazy.LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(profiles, key = { it.id }) { p ->
                com.abm.erp.core.ModuleDrillRow(p.fullName, p.department) { selectedId = p.id }
            }
        }
    }

    val currentPerf = perf
    val currentId = selectedId
    if (currentId != null && currentPerf != null) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { selectedId = null; perf = null }) {
            androidx.compose.material3.Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        profiles.firstOrNull { it.id == currentId }?.fullName ?: "",
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Spacer(Modifier.height(10.dp))
                    HrPerfRow("Retailer Coverage", "${currentPerf.retailerCoverage}")
                    HrPerfRow("Sales (90d)", "৳${"%,.0f".format(currentPerf.salesValue90Days)}")
                    HrPerfRow("Collection (90d)", "৳${"%,.0f".format(currentPerf.collectionValue90Days)}")
                    HrPerfRow("Collection Efficiency", "${"%.0f".format(currentPerf.collectionEfficiencyPct)}%")
                    HrPerfRow("Visit Compliance (30d)", "${"%.0f".format(currentPerf.visitCompliancePct)}%")
                    HrPerfRow("Inactive Retailer", "${currentPerf.inactiveRetailerCount}")
                    HrPerfRow("New Retailer (this month)", "${currentPerf.newRetailersThisMonth}")
                }
            }
        }
    }
}

@Composable
private fun HrPerfRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextSecondary)
        Text(value, color = com.abm.erp.theme.TextPrimary)
    }
}

/** v113-77 — HR-scoped one-page report from existing flows. */
@Composable
private fun HrReportsTab() {
    val leaves by com.abm.erp.data.MockRepository.leaveRequests.collectAsState()
    val payroll by com.abm.erp.data.MockRepository.payroll.collectAsState()
    val profiles = com.abm.erp.core.rememberVisibleEmployeeProfiles()
    val today = java.time.LocalDate.now()
    val monthLeaves = remember(leaves) { leaves.filter { it.fromDate.month == today.month && it.fromDate.year == today.year } }
    val totalPayroll = remember(payroll) { payroll.sumOf { it.basePay + it.commission } }
    val totalOvertime = remember(payroll) { payroll.sumOf { it.overtimePay } }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("HR Report — ${today.month} ${today.year}", style = MaterialTheme.typography.titleMedium, color = com.abm.erp.theme.TextPrimary)
        Spacer(Modifier.height(10.dp))
        com.abm.erp.core.GlassCard(modifier = Modifier.fillMaxWidth()) {
            HrPerfRow("Employee Profile", "${profiles.size}")
            HrPerfRow("এই মাসের Leave আবেদন", "${monthLeaves.size}")
            HrPerfRow("Approved Leave", "${monthLeaves.count { it.status == com.abm.erp.data.LeaveStatus.APPROVED }}")
            HrPerfRow("Payroll (base+commission)", "৳${"%,.0f".format(totalPayroll)}")
            HrPerfRow("Overtime", "৳${"%,.0f".format(totalOvertime)}")
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "বিস্তারিত attendance/payroll/leave নিজ নিজ ট্যাবে — এটা এক-নজরের সারাংশ।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
    }
}
