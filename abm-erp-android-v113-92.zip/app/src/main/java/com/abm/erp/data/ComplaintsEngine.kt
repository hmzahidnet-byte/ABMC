package com.abm.erp.data

// ============================================================================
// v113-87 Phase 6 — the Customer-Complaint workflow group, moved out of
// MockRepository.kt: createCustomerComplaint, createRetailerComplaint (v113-77's
// partyType guard intact), assignCustomerComplaint, setCustomerComplaintStatus,
// resolveCustomerComplaint, rejectCustomerComplaint. Same extension-function
// mechanics as Phases 2-5; permission gates and audit logging byte-identical.
// ============================================================================

// ---- Collection (Module 7/8/10 — Dealer/Retailer Collection) ----
/** v86, Module 15 — real Customer Complaint workflow: New -> Assigned -> Investigating -> Resolved/Closed/Rejected, all persisted via Room + synced to Firestore, all state-transitions audit-logged. */
fun MockRepository.createCustomerComplaint(dealerId: String, dealerName: String, description: String, category: String, priority: String = "NORMAL", productId: String? = null, productName: String? = null, invoiceId: String? = null, invoiceNo: String? = null): CustomerComplaint? {
    if (description.isBlank()) return null
    val complaint = CustomerComplaint(
        id = java.util.UUID.randomUUID().toString(), complaintNo = "CMP-${1000 + customerComplaints.value.size + 1}",
        dealerId = dealerId, dealerName = dealerName, productId = productId, productName = productName,
        invoiceId = invoiceId, invoiceNo = invoiceNo, category = category, description = description,
        priority = priority, createdBy = currentUser.name,
    )
    launchInRepoScope {
        val entity = complaint.toEntity()
        database.customerComplaintDao().upsert(entity)
        qrSyncCollection("customerComplaints").document(entity.id).set(entity)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push customerComplaint failed", it) }
        logAudit("CustomerComplaint", complaint.id, "CREATE", newValue = complaint)
        createNotification(NotificationCategory.COMPLAINT, "New Complaint — ${complaint.complaintNo}", "$dealerName: $description")
    }
    return complaint
}

/**
 * v113-75 — RMS's Complaint card. Mirrors createCustomerComplaint exactly, just with
 * the party fields swapped: `dealerId`/`dealerName` stay empty (they have no default,
 * so an explicit "" is passed rather than silently reusing the retailer's own id/name
 * in the wrong slot), and `partyType`/`retailerId`/`retailerName` carry the real
 * identity instead. Same complaint-number sequence, same audit trail, same
 * notification category — a retailer complaint is not a lesser kind of record.
 */
fun MockRepository.createRetailerComplaint(retailerId: String, retailerName: String, description: String, category: String, priority: String = "NORMAL", productId: String? = null, productName: String? = null, invoiceId: String? = null, invoiceNo: String? = null): CustomerComplaint? {
    if (description.isBlank()) return null
    val complaint = CustomerComplaint(
        id = java.util.UUID.randomUUID().toString(), complaintNo = "CMP-${1000 + customerComplaints.value.size + 1}",
        dealerId = "", dealerName = "", partyType = PartyType.RETAILER, retailerId = retailerId, retailerName = retailerName,
        productId = productId, productName = productName,
        invoiceId = invoiceId, invoiceNo = invoiceNo, category = category, description = description,
        priority = priority, createdBy = currentUser.name,
    )
    launchInRepoScope {
        val entity = complaint.toEntity()
        database.customerComplaintDao().upsert(entity)
        qrSyncCollection("customerComplaints").document(entity.id).set(entity)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push customerComplaint failed", it) }
        logAudit("CustomerComplaint", complaint.id, "CREATE", newValue = complaint)
        createNotification(NotificationCategory.COMPLAINT, "New Complaint — ${complaint.complaintNo}", "$retailerName: $description")
    }
    return complaint
}

fun MockRepository.assignCustomerComplaint(complaintId: String, employeeId: String, employeeName: String): Boolean {
    if (!PermissionManager.canCurrentUser("complaint", PermissionAction.APPROVE)) {
        logAudit("CustomerComplaint", complaintId, "DENY", oldValue = currentUser.role.name, newValue = "ASSIGN")
        return false
    }
    val existing = customerComplaints.value.firstOrNull { it.id == complaintId }
    if (existing == null || existing.status == CustomerComplaintStatus.RESOLVED || existing.status == CustomerComplaintStatus.CLOSED || existing.status == CustomerComplaintStatus.REJECTED) return false
    launchInRepoScope {
        database.customerComplaintDao().assign(complaintId, CustomerComplaintStatus.ASSIGNED.name, employeeId, employeeName)
        qrSyncCollection("customerComplaints").document(complaintId)
            .update(mapOf("status" to CustomerComplaintStatus.ASSIGNED.name, "assignedEmployeeId" to employeeId, "assignedEmployeeName" to employeeName))
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push complaint-assign failed", it) }
        logAudit("CustomerComplaint", complaintId, "ASSIGN", newValue = employeeName)
    }
    return true
}

fun MockRepository.setCustomerComplaintStatus(complaintId: String, status: CustomerComplaintStatus): Boolean {
    // INVESTIGATING is a plain status move any assigned employee can make; terminal states go through resolve()/reject() below for the required note.
    if (status == CustomerComplaintStatus.RESOLVED || status == CustomerComplaintStatus.CLOSED || status == CustomerComplaintStatus.REJECTED) return false
    launchInRepoScope {
        database.customerComplaintDao().setStatus(complaintId, status.name)
        qrSyncCollection("customerComplaints").document(complaintId).update("status", status.name)
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push complaint-status failed", it) }
        logAudit("CustomerComplaint", complaintId, "STATUS_CHANGE", newValue = status.name)
    }
    return true
}

fun MockRepository.resolveCustomerComplaint(complaintId: String, resolutionNote: String, close: Boolean = false): Boolean {
    if (resolutionNote.isBlank()) return false
    val existing = customerComplaints.value.firstOrNull { it.id == complaintId }
    if (existing == null || existing.status == CustomerComplaintStatus.RESOLVED || existing.status == CustomerComplaintStatus.CLOSED || existing.status == CustomerComplaintStatus.REJECTED) return false
    val status = if (close) CustomerComplaintStatus.CLOSED else CustomerComplaintStatus.RESOLVED
    launchInRepoScope {
        val now = System.currentTimeMillis()
        database.customerComplaintDao().resolve(complaintId, status.name, resolutionNote, now)
        qrSyncCollection("customerComplaints").document(complaintId)
            .update(mapOf("status" to status.name, "resolutionNote" to resolutionNote, "resolvedAtEpochMillis" to now))
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push complaint-resolve failed", it) }
        logAudit("CustomerComplaint", complaintId, status.name, newValue = resolutionNote)
    }
    return true
}

fun MockRepository.rejectCustomerComplaint(complaintId: String, reason: String): Boolean {
    if (reason.isBlank()) return false
    launchInRepoScope {
        database.customerComplaintDao().resolve(complaintId, CustomerComplaintStatus.REJECTED.name, reason, System.currentTimeMillis())
        qrSyncCollection("customerComplaints").document(complaintId)
            .update(mapOf("status" to CustomerComplaintStatus.REJECTED.name, "resolutionNote" to reason))
            .addOnFailureListener { com.abm.erp.config.AppLog.w("MockRepository", "push complaint-reject failed", it) }
        logAudit("CustomerComplaint", complaintId, "REJECT", newValue = reason)
    }
    return true
}
