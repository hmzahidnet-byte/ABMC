package com.abm.erp.ui.scanner

import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.data.CodeRegistry
import com.abm.erp.data.resolveRegistered
import com.abm.erp.data.MockRepository
import com.abm.erp.theme.*
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

/**
 * Universal QR Scanner — ONE scan button, ONE central resolver, real
 * detail for all 6 required types. Previously scanning lived only inside
 * DealersScreen (Dealer/Retailer only, Employee/Carton just showed a
 * toast telling the person to go look elsewhere, Production Batch and
 * Warehouse/Delivery weren't recognized as types at all).
 */
@Composable
fun UniversalScannerScreen(onNavigate: (String) -> Unit = {}) {
    val context = LocalContext.current
    var resolved by remember { mutableStateOf<CodeRegistry.ResolveResult?>(null) }
    var lastScannedRaw by remember { mutableStateOf("") }

    var secureDenial by remember { mutableStateOf<String?>(null) }
    var offlineVerified by remember { mutableStateOf(false) }
    val scanScope = androidx.compose.runtime.rememberCoroutineScope()

    val scanLauncher = androidx.activity.compose.rememberLauncherForActivityResult(ScanContract()) { result ->
        val code = result?.contents ?: return@rememberLauncherForActivityResult
        lastScannedRaw = code
        secureDenial = null
        offlineVerified = false

        if (com.abm.erp.data.QrRegistry.isSecurePayload(code)) {
            // Secure path: the payload is one of ours, so it must pass full registry
            // validation — company isolation, token, status, expiry, permission. A
            // failure here never falls through to the legacy matcher; that would
            // defeat the point of revocation.
            resolved = null
            scanScope.launch {
                val online = com.abm.erp.util.NetworkStatus.isOnline(context)
                when (val res = com.abm.erp.data.QrRegistry.resolve(code, online)) {
                    is com.abm.erp.data.QrRegistry.Resolution.Allowed -> {
                        offlineVerified = res.offlineVerified
                        resolved = CodeRegistry.resolveRegistered(res.entityType, res.entityId)
                    }
                    is com.abm.erp.data.QrRegistry.Resolution.Denied -> {
                        secureDenial = res.reason
                    }
                }
            }
        } else {
            // Legacy path: a code printed before the secure registry existed, or a
            // supplier's own barcode. Still resolved so old tags keep working, but it
            // is labelled as unverified in the UI rather than presented as trusted.
            resolved = CodeRegistry.resolve(code)
            val r = resolved
            if (r is CodeRegistry.ResolveResult.Found) {
                MockRepository.logAudit(r.type.name, r.id, "QR_SCANNED_LEGACY", reason = "Unregistered code scanned by ${MockRepository.currentUser.name}")
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Universal QR Scanner", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(6.dp))
        Text("Employee, Retailer, Dealer, Product/Carton, Production Batch, Warehouse/Delivery, Invoice, Collection — সব এক জায়গা থেকে স্ক্যান করুন।", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { scanLauncher.launch(ScanOptions().setPrompt("QR/Barcode স্ক্যান করুন").setBeepEnabled(true).setOrientationLocked(false)) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("📷 Scan QR") }
        Spacer(Modifier.height(16.dp))

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            // A secure-registry denial takes precedence over everything: the record is not
            // shown, only the reason. Blueprint/Part 2 — never open a record because a
            // visible id happened to match.
            secureDenial?.let { reason ->
                com.abm.erp.core.WorkspaceErrorState(reason) { secureDenial = null }
            }
            if (offlineVerified && secureDenial == null && resolved != null) {
                Text(
                    "⚠ অফলাইন যাচাই — এই ডিভাইসে সংরক্ষিত তথ্য দিয়ে মিলানো হয়েছে; সার্ভারে বাতিল হয়েছে কিনা এখন নিশ্চিত করা যায়নি।",
                    color = com.abm.erp.theme.StatusAmber,
                    style = MaterialTheme.typography.labelSmall,
                )
                Spacer(Modifier.height(8.dp))
            }
            when (val r = if (secureDenial != null) null else resolved) {
                null -> if (secureDenial == null) Text("স্ক্যান করার জন্য উপরের বাটনে চাপুন।", color = TextSecondary)
                is CodeRegistry.ResolveResult.Invalid -> Text("অবৈধ কোড।", color = DangerRed)
                is CodeRegistry.ResolveResult.NotFound -> Text("কোনো মিলে যাওয়া রেকর্ড পাওয়া যায়নি: $lastScannedRaw", color = DangerRed)
                is CodeRegistry.ResolveResult.Ambiguous -> {
                    Text("⚠ এই কোড একাধিক রেকর্ডের সাথে মিলছে — ডেটা সমস্যা, Chairman-কে জানান।", color = DangerRed, fontWeight = FontWeight.Bold)
                    r.matches.forEach { (type, id) -> Text("• $type — $id", color = TextSecondary) }
                }
                is CodeRegistry.ResolveResult.Found -> ScanResultCard(r, onNavigate)
            }
        }
    }
}

@Composable
private fun ScanResultCard(result: CodeRegistry.ResolveResult.Found, onNavigate: (String) -> Unit) {
    val currentUser = MockRepository.currentUser
    // Real territory + permission validation — was completely missing
    // before: any resolved code's details were shown regardless of
    // whether this employee was even authorized to view that module, or
    // whether the specific record was inside their assigned territory.
    val (allowed, denyReason) = remember(result.id, result.type) {
        when (result.type) {
            CodeRegistry.CodeType.DEALER -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("dealer", com.abm.erp.data.PermissionAction.VIEW)) false to "Dealer তথ্য দেখার অনুমতি নেই।"
                else if (result.id !in MockRepository.visibleDealerIds(currentUser.employeeId)) false to "এই Dealer আপনার এলাকার বাইরে — অ্যাক্সেস নেই।"
                else true to null
            }
            CodeRegistry.CodeType.RETAILER -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("dealer", com.abm.erp.data.PermissionAction.VIEW)) false to "Retailer তথ্য দেখার অনুমতি নেই।"
                else if (result.id !in MockRepository.visibleRetailerIds(currentUser.employeeId)) false to "এই Retailer আপনার এলাকার বাইরে — অ্যাক্সেস নেই।"
                else true to null
            }
            CodeRegistry.CodeType.EMPLOYEE -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("hr", com.abm.erp.data.PermissionAction.VIEW)) false to "Employee তথ্য দেখার অনুমতি নেই।"
                else if (result.id !in MockRepository.visibleEmployeeIds(currentUser.employeeId)) false to "এই Employee আপনার hierarchy-র বাইরে — অ্যাক্সেস নেই।"
                else true to null
            }
            CodeRegistry.CodeType.CARTON, CodeRegistry.CodeType.PRODUCTION_BATCH -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("prod", com.abm.erp.data.PermissionAction.VIEW)) false to "Production তথ্য দেখার অনুমতি নেই।"
                else true to null
            }
            CodeRegistry.CodeType.WAREHOUSE_TRANSFER -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("stock", com.abm.erp.data.PermissionAction.VIEW)) false to "Warehouse তথ্য দেখার অনুমতি নেই।"
                else true to null
            }
            CodeRegistry.CodeType.INVOICE, CodeRegistry.CodeType.COLLECTION -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("bill", com.abm.erp.data.PermissionAction.VIEW)) false to "এই তথ্য দেখার অনুমতি নেই।"
                else true to null
            }
            CodeRegistry.CodeType.PRODUCT -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("inv", com.abm.erp.data.PermissionAction.VIEW)) false to "Product তথ্য দেখার অনুমতি নেই।"
                else true to null
            }
            CodeRegistry.CodeType.DELIVERY -> {
                if (!com.abm.erp.data.PermissionManager.canCurrentUser("stock", com.abm.erp.data.PermissionAction.VIEW)) false to "Delivery তথ্য দেখার অনুমতি নেই।"
                else true to null
            }
            CodeRegistry.CodeType.UNKNOWN -> true to null
        }
    }
    if (!allowed) {
        MockRepository.logAudit(result.type.name, result.id, "SCAN_ACCESS_DENIED", reason = denyReason)
        Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
            Text(denyReason ?: "অ্যাক্সেস নেই।", color = DangerRed, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
        }
        return
    }
    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            when (result.type) {
                CodeRegistry.CodeType.EMPLOYEE -> EmployeeScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.RETAILER -> RetailerScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.DEALER -> DealerScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.CARTON -> CartonScanDetail(result.id, result.extra)
                CodeRegistry.CodeType.PRODUCTION_BATCH -> ProductionBatchScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.WAREHOUSE_TRANSFER -> WarehouseTransferScanDetail(result.id)
                CodeRegistry.CodeType.INVOICE -> InvoiceScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.COLLECTION -> CollectionScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.PRODUCT -> ProductScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.DELIVERY -> DeliveryScanDetail(result.id, onNavigate)
                CodeRegistry.CodeType.UNKNOWN -> Text("অজানা কোড টাইপ।", color = TextSecondary)
            }
        }
    }
}

@Composable
private fun EmployeeScanDetail(employeeId: String, onNavigate: (String) -> Unit) {
    val profiles by MockRepository.employeeProfiles.collectAsState()
    val emp = profiles.firstOrNull { it.id == employeeId }
    var attendanceSummary by remember(employeeId) { mutableStateOf<Pair<Int, Int>?>(null) } // present, absent
    LaunchedEffect(employeeId) { attendanceSummary = MockRepository.attendanceSummary(employeeId) }
    Text("👤 Employee", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(emp?.fullName ?: employeeId, style = MaterialTheme.typography.titleMedium)
    Text("${emp?.designation ?: ""} — ${emp?.department ?: ""}", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
    Text("Employee Code: ${emp?.employeeCode ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    attendanceSummary?.let { (present, absent) ->
        Text("Attendance: $present দিন উপস্থিত, $absent দিন অনুপস্থিত", style = MaterialTheme.typography.bodySmall)
    } ?: com.abm.erp.core.WorkspaceLoadingState("Attendance লোড হচ্ছে…")
    Spacer(Modifier.height(8.dp))
    Text("Connected workflow", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TextButton(onClick = { onNavigate("hrm") }) { Text("Attendance") }
        TextButton(onClick = { onNavigate("hrm") }) { Text("Payroll") }
        TextButton(onClick = { onNavigate("enterprise_audit_center") }) { Text("Activity") }
    }
}

@Composable
private fun RetailerScanDetail(retailerId: String, onNavigate: (String) -> Unit) {
    val retailers by MockRepository.retailers.collectAsState()
    val orders by MockRepository.orders.collectAsState()
    val retailer = retailers.firstOrNull { it.id == retailerId }
    val latestOrder = orders.filter { it.retailerId == retailerId }.maxByOrNull { it.loggedAt }
    Text("🏪 Retailer", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(retailer?.name ?: retailerId, style = MaterialTheme.typography.titleMedium)
    Text("Code: ${retailer?.retailerCode ?: "—"} — Due: ৳${"%,.0f".format(retailer?.dueBalance ?: 0.0)}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    if (latestOrder != null) {
        Text("সর্বশেষ অর্ডার: ${latestOrder.orderNo} — ৳${"%,.0f".format(latestOrder.amount)} (${latestOrder.stage})", style = MaterialTheme.typography.bodySmall)
    } else {
        Text("কোনো সাম্প্রতিক অর্ডার পাওয়া যায়নি।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
    }
    Spacer(Modifier.height(8.dp))
    Text("Connected workflow", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TextButton(onClick = { onNavigate("sales") }) { Text("Order/Invoice") }
        TextButton(onClick = { onNavigate("dealers") }) { Text("Collection") }
        TextButton(onClick = { onNavigate("statement/RETAILER/$retailerId") }) { Text("Statement") }
    }
}

@Composable
private fun DealerScanDetail(dealerId: String, onNavigate: (String) -> Unit) {
    val dealers by MockRepository.dealers.collectAsState()
    val dealer = dealers.firstOrNull { it.id == dealerId }
    val ledger by remember(dealerId) { MockRepository.partyLedgerFor(com.abm.erp.data.PartyType.DEALER, dealerId) }.collectAsState(initial = emptyList())
    val latestLedgerEntries = ledger.sortedByDescending { it.createdAt }.take(5)
    Text("🏢 Dealer Dashboard", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(dealer?.name ?: dealerId, style = MaterialTheme.typography.titleMedium)
    Text("Code: ${dealer?.dealerCode ?: "—"} — Due: ৳${"%,.0f".format(dealer?.dueBalance ?: 0.0)}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Text("সর্বশেষ লেজার এন্ট্রি:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    if (latestLedgerEntries.isEmpty()) Text("কোনো এন্ট্রি নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
    latestLedgerEntries.forEach { Text("• ${it.type} ৳${"%,.0f".format(it.amount)} — ${it.reason}", style = MaterialTheme.typography.bodySmall) }
    Spacer(Modifier.height(8.dp))
    Text("Connected workflow", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TextButton(onClick = { onNavigate("sales") }) { Text("Invoice") }
        TextButton(onClick = { onNavigate("dealers") }) { Text("Collection") }
        // Opens THIS dealer's statement, not the generic ledger module.
        TextButton(onClick = { onNavigate("statement/DEALER/$dealerId") }) { Text("Statement") }
    }
}

@Composable
private fun CartonScanDetail(productionPlanId: String, cartonCode: String?) {
    val plans by MockRepository.productionPlans.collectAsState()
    val plan = plans.firstOrNull { it.id == productionPlanId }
    Text("📦 Product / Carton", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(cartonCode ?: "Carton", style = MaterialTheme.typography.titleMedium)
    Text("Batch: ${plan?.batchNumber ?: "—"} — Product: ${plan?.productId ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Text("Status: ${plan?.status ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(4.dp))
    Text("সম্পূর্ণ movement history-এর জন্য নিচের ব্যাচ বিস্তারিত দেখুন।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
}

@Composable
private fun ProductionBatchScanDetail(planId: String, onNavigate: (String) -> Unit) {
    val plans by MockRepository.productionPlans.collectAsState()
    val qc by MockRepository.qualityInspections.collectAsState()
    val plan = plans.firstOrNull { it.id == planId }
    val qcRecords = qc.filter { it.productionPlanId == planId }
    Text("🏭 Production Batch", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(plan?.batchNumber ?: planId, style = MaterialTheme.typography.titleMedium)
    Text("Product: ${plan?.productId ?: "—"} — Planned: ${plan?.plannedQuantity ?: 0.0} ${plan?.unit ?: ""}", style = MaterialTheme.typography.bodySmall)
    Text("Status: ${plan?.status ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Text("QC Inspections: ${qcRecords.size}টি", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    qcRecords.take(3).forEach { Text("• ${it.result}${it.testParameters?.let { p -> " — $p" } ?: ""}", style = MaterialTheme.typography.bodySmall) }
    Spacer(Modifier.height(8.dp))
    Text("Connected workflow", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TextButton(onClick = { onNavigate("production") }) { Text("QC") }
        TextButton(onClick = { onNavigate("production_warehouse") }) { Text("Transfer") }
        TextButton(onClick = { onNavigate("inventory") }) { Text("Warehouse") }
    }
}

@Composable
private fun WarehouseTransferScanDetail(transferId: String) {
    val transfers by MockRepository.warehouseTransfers.collectAsState()
    val transfer = transfers.firstOrNull { it.id == transferId }
    Text("🚚 Warehouse / Delivery", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(transfer?.transferNumber ?: transferId, style = MaterialTheme.typography.titleMedium)
    Text("${transfer?.sourceWarehouseId ?: "—"} → ${transfer?.destinationWarehouseId ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Text("Status: ${transfer?.status ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(4.dp))
    Text("${transfer?.lines?.size ?: 0}টি লাইন-আইটেম", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
}

@Composable
private fun InvoiceScanDetail(invoiceId: String, onNavigate: (String) -> Unit) {
    val invoices by MockRepository.salesInvoices.collectAsState()
    val invoice = invoices.firstOrNull { it.id == invoiceId }
    Text("🧾 Invoice", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(invoice?.invoiceNo ?: invoiceId, style = MaterialTheme.typography.titleMedium)
    Text(invoice?.dealerName ?: "—", style = MaterialTheme.typography.bodySmall)
    Text("৳${"%,.0f".format(invoice?.total ?: 0.0)} — Status: ${invoice?.status ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Text("Connected workflow", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        TextButton(onClick = { onNavigate("invoice_doc/$invoiceId") }) { Text("Open Invoice") }
        TextButton(onClick = { onNavigate("inventory") }) { Text("Stock") }
        TextButton(onClick = { onNavigate("ledger") }) { Text("Ledger") }
        TextButton(onClick = { onNavigate("billing") }) { Text("Delivery") }
    }
}

@Composable
private fun CollectionScanDetail(collectionId: String, onNavigate: (String) -> Unit) {
    val collections by MockRepository.partyCollections.collectAsState()
    val collection = collections.firstOrNull { it.id == collectionId }
    Text("💵 Collection", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(collection?.collectionNo ?: collectionId, style = MaterialTheme.typography.titleMedium)
    Text(collection?.partyName ?: "—", style = MaterialTheme.typography.bodySmall)
    Text("৳${"%,.0f".format(collection?.amount ?: 0.0)} — Status: ${collection?.status ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Button(onClick = { onNavigate("dealers") }) { Text("Dealer/Retailer workspace খুলুন") }
}

@Composable
private fun ProductScanDetail(productId: String, onNavigate: (String) -> Unit) {
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val product = products.firstOrNull { it.id == productId }
    Text("📦 Product", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(product?.name ?: productId, style = MaterialTheme.typography.titleMedium)
    Text("SKU: ${product?.sku ?: "—"} — ৳${"%,.0f".format(product?.defaultUnitPrice ?: 0.0)}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Button(onClick = { onNavigate("inventory") }) { Text("Inventory workspace খুলুন") }
}

@Composable
private fun DeliveryScanDetail(challanId: String, onNavigate: (String) -> Unit) {
    val challans by MockRepository.deliveryChallans.collectAsState()
    val challan = challans.firstOrNull { it.id == challanId }
    Text("🚛 Delivery", style = MaterialTheme.typography.labelMedium, color = GoldBright)
    Text(challan?.challanNo ?: challanId, style = MaterialTheme.typography.titleMedium)
    Text(challan?.partyName ?: "—", style = MaterialTheme.typography.bodySmall)
    Text("Vehicle: ${challan?.vehicleNo?.ifBlank { "—" } ?: "—"} — Driver: ${challan?.driverName?.ifBlank { "—" } ?: "—"}", style = MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(8.dp))
    Button(onClick = { onNavigate("billing") }) { Text("Billing workspace খুলুন") }
}
