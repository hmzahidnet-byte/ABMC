package com.abm.erp.core

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.data.ExpensePaymentMethod
import com.abm.erp.data.approveExpense
import com.abm.erp.data.rejectExpense
import com.abm.erp.data.submitExpense
import com.abm.erp.data.MockRepository
import com.abm.erp.data.PermissionAction
import com.abm.erp.data.PermissionManager
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * v113-82 — EXPENSE WORKSPACE (workspace contract, fourth implementation).
 * Fills the gap `ApprovalRouting.kt` flagged since v113-77 ("no FMS drawer item for
 * this yet"). One screen: category + amount + payment method + attachment note,
 * submit via the real `submitExpense` (which itself raises the ApprovalType.EXPENSE
 * request — nothing re-implemented), and the submitter's own expense history inline
 * with Approve/Reject for permission-holders via `approveExpense`/`rejectExpense`
 * (approval is what actually posts to the ledger — untouched, still only happens
 * there, never at submission).
 */
@Composable
fun ExpenseWorkspace() {
    val expenses by MockRepository.expenses.collectAsState()
    var category by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var method by remember { mutableStateOf(ExpensePaymentMethod.CASH) }
    var lastResult by remember { mutableStateOf<String?>(null) }
    var rejectFor by remember { mutableStateOf<String?>(null) }
    var rejectReason by remember { mutableStateOf("") }

    val amountValue = amount.toDoubleOrNull() ?: 0.0
    val canApprove = PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)
    val myExpenses = remember(expenses) { expenses.filter { !it.category.isBlank() }.sortedByDescending { it.createdAt } }

    val quickCategories = listOf("Utility Bill", "Office Supplies", "Transport", "Maintenance")

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Spacer(Modifier.height(4.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Expense Entry", fontWeight = FontWeight.Bold, color = TextPrimary)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    quickCategories.forEach { c -> AssistChip(onClick = { category = c }, label = { Text(c) }) }
                }
                OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("টাকার পরিমাণ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ExpensePaymentMethod.values().forEach { m ->
                        FilterChip(selected = method == m, onClick = { method = m }, label = { Text(m.name) })
                    }
                }
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("বিবরণ") }, modifier = Modifier.fillMaxWidth())
                Text(
                    "Approve হলে তবেই ledger-এ post হয় — জমা দেওয়ার সাথে সাথে না।",
                    style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                )
                if (!PermissionManager.canCurrentUser("bill", PermissionAction.CREATE)) {
                    Text("আপনার role-এ expense জমা দেওয়ার অনুমতি নেই।", color = DangerRed, style = MaterialTheme.typography.labelSmall)
                }
                Button(
                    onClick = {
                        val e = MockRepository.submitExpense(category, amountValue, description, method)
                        lastResult = if (e != null) "✔ জমা হয়েছে — approval-এর অপেক্ষায়।" else "✖ জমা হয়নি (category/amount বা অনুমতি চেক করুন)।"
                        if (e != null) { category = ""; amount = ""; description = "" }
                    },
                    enabled = category.isNotBlank() && amountValue > 0,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Expense জমা দিন") }
                lastResult?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = if (it.startsWith("✔")) SuccessGreen else DangerRed) }
            }
        }

        item { Text("Expense History (${myExpenses.size})", fontWeight = FontWeight.SemiBold, color = TextPrimary) }
        items(myExpenses.take(20), key = { it.id }) { e ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(e.expenseNo.ifBlank { e.id.take(8) }, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    StatusPill(e.status.name)
                }
                Text("${e.category} · ৳${"%,.0f".format(e.amount)} · ${e.paymentMethod}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                if (e.description.isNotBlank()) Text(e.description, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                if (e.status.name == "REJECTED" && e.rejectReason != null) {
                    Text("কারণ: ${e.rejectReason}", style = MaterialTheme.typography.labelSmall, color = DangerRed)
                }
                if (e.status.name == "PENDING" && canApprove) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { MockRepository.approveExpense(e.id) }) { Text("✓ Approve", color = SuccessGreen) }
                        TextButton(onClick = { rejectFor = e.id }) { Text("✗ Reject", color = DangerRed) }
                    }
                    if (rejectFor == e.id) {
                        OutlinedTextField(value = rejectReason, onValueChange = { rejectReason = it }, label = { Text("কারণ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Button(
                            onClick = { MockRepository.rejectExpense(e.id, rejectReason); rejectFor = null; rejectReason = "" },
                            enabled = rejectReason.isNotBlank(), modifier = Modifier.fillMaxWidth(),
                        ) { Text("Reject নিশ্চিত করুন", color = WarningAmber) }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
