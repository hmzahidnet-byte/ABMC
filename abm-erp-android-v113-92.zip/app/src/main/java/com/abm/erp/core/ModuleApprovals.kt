package com.abm.erp.core

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.data.ApprovalRequest
import com.abm.erp.data.escalateApproval
import com.abm.erp.data.forwardApproval
import com.abm.erp.data.setApprovalStatus
import com.abm.erp.data.ApprovalStatus
import com.abm.erp.data.ApprovalType
import com.abm.erp.data.MockRepository
import com.abm.erp.data.PermissionAction
import com.abm.erp.data.PermissionManager
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * Decision 2 (v113-72) — approvals are decentralised.
 *
 * There is no central Approvals inbox any more. Instead, each module renders
 * *its own* pending `ApprovalRequest` rows inline, in the tab the request is
 * actually about: LEAVE inside HRM's Leave tab, "Expense" inside Expenses,
 * "Voucher" inside Ledger's Voucher tab, "SalesInvoice" inside DMS's Dealer
 * Invoice tab, and so on.
 *
 * This is a shared *component*, not a shared *screen* — the same relationship
 * `TaskHeader` has to the module screens. Nothing here gathers records from
 * more than one module: every call site passes the narrow filter it owns.
 *
 * Deliberately NOT a LazyColumn: this is embedded inside module tabs that are
 * already inside a scrolling parent, and a nested lazy list in an unbounded
 * height constraint crashes at runtime.
 */
@Composable
fun ModuleApprovalSection(
    title: String = "অনুমোদনের অপেক্ষায়",
    entityTypes: Set<String> = emptySet(),
    approvalTypes: Set<ApprovalType> = emptySet(),
    modifier: Modifier = Modifier,
) {
    val approvals by MockRepository.approvals.collectAsState()

    // Filters are AND-ed only when both are supplied; an empty set means
    // "don't filter on this axis". A call site that passes neither would get
    // every approval in the system — which is exactly the central inbox this
    // replaces — so that case renders nothing instead.
    if (entityTypes.isEmpty() && approvalTypes.isEmpty()) return

    // remember(...) matters here: this runs inside module tabs that recompose on every
    // scroll/state change, and MockRepository.approvals can be long. Filtering raw in
    // composition would re-scan the whole list every frame — straight out of an 8.3ms
    // (120fps) budget. Keyed on the list identity, so it only re-filters on real change.
    val mine = remember(approvals, entityTypes, approvalTypes) {
        approvals.filter { req ->
            req.status == ApprovalStatus.PENDING &&
                (entityTypes.isEmpty() || req.entityType in entityTypes) &&
                (approvalTypes.isEmpty() || req.type in approvalTypes)
        }
    }
    if (mine.isEmpty()) return

    val canApprove = PermissionManager.canCurrentUser("approval", PermissionAction.APPROVE)
    var forwardDialogFor by remember { mutableStateOf<String?>(null) }

    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Spacer(Modifier.width(8.dp))
            Text("${mine.size}", style = MaterialTheme.typography.labelSmall, color = WarningAmber, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        mine.forEach { req ->
            ModuleApprovalCard(req, canApprove, onForward = { forwardDialogFor = req.id })
            Spacer(Modifier.height(8.dp))
        }
        Spacer(Modifier.height(4.dp))
    }

    forwardDialogFor?.let { reqId ->
        androidx.compose.ui.window.Dialog(onDismissRequest = { forwardDialogFor = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var employeeId by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp)) {
                    Text("Forward / Reassign", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = employeeId,
                        onValueChange = { employeeId = it },
                        label = { Text("Employee ID") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { MockRepository.forwardApproval(reqId, employeeId); forwardDialogFor = null },
                        enabled = employeeId.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm") }
                }
            }
        }
    }
}

@Composable
private fun ModuleApprovalCard(req: ApprovalRequest, canApprove: Boolean, onForward: () -> Unit) {
    var justDenied by remember(req.id) { mutableStateOf<String?>(null) }
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(req.type.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Pending", color = WarningAmber, style = MaterialTheme.typography.labelSmall)
                UniversalActionMenu(
                    moduleReference = "ApprovalRequest", entityId = req.id, entityLabel = req.type.name,
                    shareText = "${req.type} — ${req.fromEmployee}\n${req.detail}\nStatus: ${req.status}",
                    csvHeader = "Type,From,Detail,Status",
                    csvRow = toCsvRow(req.type, req.fromEmployee, req.detail, req.status),
                )
            }
        }
        if (req.fromEmployee.isNotBlank()) {
            Text(req.fromEmployee, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
        Text(req.detail, style = MaterialTheme.typography.bodyMedium)
        // Blueprint §34 — approvals are about latency, so waiting age, not a raw timestamp.
        WaitingAge(req.createdAt)
        if (req.escalated) Text("⚠ Escalated", color = WarningAmber, style = MaterialTheme.typography.labelSmall)
        req.assignedToEmployeeId?.let { Text("→ Forwarded to $it", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }

        if (canApprove) {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { if (!MockRepository.setApprovalStatus(req.id, ApprovalStatus.APPROVED)) justDenied = "Approve" },
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                ) { Text("Approve") }
                OutlinedButton(
                    onClick = { if (!MockRepository.setApprovalStatus(req.id, ApprovalStatus.REJECTED)) justDenied = "Reject" },
                ) { Text("Reject", color = DangerRed) }
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { MockRepository.escalateApproval(req.id) }) { Text("⬆ Escalate") }
                TextButton(onClick = onForward) { Text("↪ Forward/Reassign") }
            }
        }
        justDenied?.let {
            Spacer(Modifier.height(4.dp))
            Text(
                "⚠ $it permission denied for your role — blocked at the repository layer.",
                color = DangerRed, style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}
