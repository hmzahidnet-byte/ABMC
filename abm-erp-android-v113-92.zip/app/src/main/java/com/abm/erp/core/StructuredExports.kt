package com.abm.erp.core

import android.content.Context
import com.abm.erp.data.SalesInvoice
import java.io.File

/**
 * Task D — structured business-document export. Unlike the generic
 * title/body fallback in UniversalActionMenu.kt, this draws an actual
 * invoice layout: company header, reference, date, dealer, a real
 * line-item table (name/qty/unit price/discount/line total), subtotal,
 * discount amount, grand total, status and a footer — using ONLY fields
 * that genuinely exist on SalesInvoice. No fabricated line items or totals.
 *
 * This is the first of the requested structured templates to be
 * completed; Dealer Statement, Purchase Order, Production Sheet,
 * Voucher/Ledger record and Payslip still use the generic fallback as of
 * this version (see the v82 continuation report's honest gap list).
 */
fun exportSalesInvoicePdf(
    context: Context,
    invoice: SalesInvoice,
    /**
     * v113-87 — a REGISTRY payload from `QrRegistry.issue("SalesInvoice", id)`, issued by
     * the caller inside its own coroutine (this fn stays non-suspend for Canvas work).
     * The old hardcoded "INVOICE:<id>" string was scannable by NOTHING — the secure path
     * rejects non-registry payloads and the legacy CodeRegistry matcher knows invoiceNo,
     * not a prefixed id — so a broken QR was printed on every bill. Null now prints an
     * honest line instead of a dead code.
     */
    qrPayload: String? = null,
): File {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas

    val orange = android.graphics.Color.rgb(0xF8, 0x56, 0x06)
    val navy = android.graphics.Color.rgb(0x1B, 0x24, 0x30)
    val lightGray = android.graphics.Color.rgb(0xF4, 0xF6, 0xFA)
    val borderGray = android.graphics.Color.rgb(0xE5, 0xE9, 0xF0)
    val statusColor = when (invoice.status) {
        "PAID" -> android.graphics.Color.rgb(0x22, 0xA0, 0x6B)
        "CANCELLED" -> android.graphics.Color.rgb(0xE2, 0x4A, 0x3B)
        "PARTIALLY_PAID" -> android.graphics.Color.rgb(0xF5, 0xA6, 0x23)
        else -> android.graphics.Color.rgb(0x2E, 0x6F, 0xE0)
    }

    val headerPaint = android.graphics.Paint().apply { textSize = 22f; isFakeBoldText = true; color = android.graphics.Color.WHITE }
    val headerSubPaint = android.graphics.Paint().apply { textSize = 10f; color = android.graphics.Color.WHITE; alpha = 210 }
    val docTitlePaint = android.graphics.Paint().apply { textSize = 18f; isFakeBoldText = true; color = android.graphics.Color.WHITE }
    val labelPaint = android.graphics.Paint().apply { textSize = 10f; isFakeBoldText = true; color = android.graphics.Color.DKGRAY }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f; color = navy }
    val boldBodyPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true; color = navy }
    val totalPaint = android.graphics.Paint().apply { textSize = 15f; isFakeBoldText = true; color = navy }
    val footerPaint = android.graphics.Paint().apply { textSize = 9f; color = android.graphics.Color.GRAY }
    val fillPaint = android.graphics.Paint()
    val linePaint = android.graphics.Paint().apply { color = borderGray; strokeWidth = 1f }

    // ---- Branded header band ----
    fillPaint.color = orange
    canvas.drawRect(0f, 0f, 595f, 92f, fillPaint)
    // Same company settings the on-screen invoice reads, so the printed bill and the
    // screen cannot show different branding.
    val company = com.abm.erp.data.MockRepository.companySettings()
    canvas.drawText(company.companyName.ifBlank { "ABM ERP" }.uppercase(), 40f, 42f, headerPaint)
    canvas.drawText(
        listOfNotNull(company.companyAddress.ifBlank { null }, company.companyPhone.ifBlank { null })
            .joinToString(" · ").ifBlank { "Enterprise. Control. Growth." },
        40f, 58f, headerSubPaint,
    )
    canvas.drawText("INVOICE", 470f, 42f, docTitlePaint)
    canvas.drawText("No. ${invoice.invoiceNo}", 430f, 62f, headerSubPaint)
    canvas.drawText(invoice.createdAt.toLocalDate().toString(), 430f, 76f, headerSubPaint)

    // ---- QR verification code (top-right, below header) ----
    if (qrPayload != null) {
        val qrBitmap = com.abm.erp.util.QrCodeGenerator.generate(qrPayload, 200)
        canvas.drawBitmap(qrBitmap, null, android.graphics.RectF(495f, 100f, 555f, 160f), null)
        canvas.drawText("Scan to verify", 495f, 172f, footerPaint)
    } else {
        canvas.drawText("QR: not issued for this print", 470f, 110f, footerPaint)
    }

    var y = 130f
    // ---- Dealer details box ----
    fillPaint.color = lightGray
    canvas.drawRoundRect(android.graphics.RectF(40f, y, 470f, y + 70f), 8f, 8f, fillPaint)
    canvas.drawText("DEALER", 52f, y + 18f, labelPaint)
    canvas.drawText(invoice.dealerName, 52f, y + 34f, boldBodyPaint)
    canvas.drawText(invoice.dealerZone, 52f, y + 50f, bodyPaint)
    canvas.drawText("Payment Terms: ${if (invoice.status == "PAID") "Paid" else "Credit"}   ·   Courier: ${invoice.courier ?: "—"}", 52f, y + 64f, bodyPaint)
    y += 90f

    // ---- Line-item table ----
    fillPaint.color = navy
    canvas.drawRect(40f, y, 555f, y + 22f, fillPaint)
    val headerTextPaint = android.graphics.Paint().apply { textSize = 10f; isFakeBoldText = true; color = android.graphics.Color.WHITE }
    canvas.drawText("Item / Product", 48f, y + 15f, headerTextPaint)
    canvas.drawText("Qty", 300f, y + 15f, headerTextPaint)
    canvas.drawText("Rate", 360f, y + 15f, headerTextPaint)
    canvas.drawText("Disc%", 440f, y + 15f, headerTextPaint)
    canvas.drawText("Amount", 495f, y + 15f, headerTextPaint)
    y += 22f

    invoice.lineItems.forEachIndexed { idx, item ->
        if (y > 720f) return@forEachIndexed // page-overflow guard — stops adding rows rather than crashing; multi-page support is a future refinement
        if (idx % 2 == 1) { fillPaint.color = lightGray; canvas.drawRect(40f, y, 555f, y + 22f, fillPaint) }
        canvas.drawText(item.name.take(30), 48f, y + 15f, bodyPaint)
        canvas.drawText("${item.qty}", 300f, y + 15f, bodyPaint)
        canvas.drawText("৳${"%.0f".format(item.unitPrice)}", 360f, y + 15f, bodyPaint)
        canvas.drawText("${item.discountPct}%", 440f, y + 15f, bodyPaint)
        canvas.drawText("৳${"%.0f".format(item.lineTotal)}", 495f, y + 15f, boldBodyPaint)
        y += 22f
    }
    canvas.drawLine(40f, y, 555f, y, linePaint)
    y += 20f

    // ---- Totals ----
    canvas.drawText("Subtotal", 400f, y, bodyPaint)
    canvas.drawText("৳${"%.0f".format(invoice.subTotal)}", 495f, y, bodyPaint)
    y += 18f
    canvas.drawText("Discount (${invoice.dealerDiscountPct}%)", 400f, y, bodyPaint)
    canvas.drawText("৳${"%.0f".format(invoice.dealerDiscountAmt)}", 495f, y, bodyPaint)
    y += 14f
    fillPaint.color = orange
    canvas.drawRoundRect(android.graphics.RectF(370f, y, 555f, y + 34f), 6f, 6f, fillPaint)
    val totalWhitePaint = android.graphics.Paint().apply { textSize = 15f; isFakeBoldText = true; color = android.graphics.Color.WHITE }
    canvas.drawText("Total Amount", 382f, y + 22f, totalWhitePaint)
    canvas.drawText("৳${"%.0f".format(invoice.netAfterDiscount)}", 490f, y + 22f, totalWhitePaint)
    y += 55f

    // ---- Party balance (same source and fallback rule as the on-screen invoice) ----
    val liveDue = com.abm.erp.data.MockRepository.dealers.value.firstOrNull { it.id == invoice.dealerId }?.dueBalance ?: 0.0
    val hasSnapshot = invoice.closingDueSnapshot > 0.0 || invoice.previousDueSnapshot > 0.0
    val prevDue = if (hasSnapshot) invoice.previousDueSnapshot else (liveDue - invoice.total).coerceAtLeast(0.0)
    val totalDue = if (hasSnapshot) invoice.closingDueSnapshot else liveDue
    fillPaint.color = lightGray
    canvas.drawRoundRect(android.graphics.RectF(40f, y, 350f, y + 56f), 6f, 6f, fillPaint)
    canvas.drawText("Previous Due", 52f, y + 18f, bodyPaint)
    canvas.drawText("৳${"%,.0f".format(prevDue)}", 250f, y + 18f, bodyPaint)
    canvas.drawText("This Invoice", 52f, y + 34f, bodyPaint)
    canvas.drawText("৳${"%,.0f".format(invoice.total)}", 250f, y + 34f, bodyPaint)
    canvas.drawText("Total Due", 52f, y + 50f, boldBodyPaint)
    canvas.drawText("৳${"%,.0f".format(totalDue)}", 250f, y + 50f, boldBodyPaint)
    y += 70f

    // ---- Approval status badge ----
    val statusFillPaint = android.graphics.Paint().apply { color = statusColor }
    canvas.drawRoundRect(android.graphics.RectF(40f, y, 150f, y + 22f), 11f, 11f, statusFillPaint)
    val statusTextPaint = android.graphics.Paint().apply { textSize = 10f; isFakeBoldText = true; color = android.graphics.Color.WHITE }
    canvas.drawText(invoice.status, 52f, y + 15f, statusTextPaint)
    y += 50f

    // ---- Signature area ----
    canvas.drawLine(40f, y, 190f, y, linePaint)
    canvas.drawLine(230f, y, 380f, y, linePaint)
    canvas.drawLine(420f, y, 555f, y, linePaint)
    y += 14f
    canvas.drawText("Prepared By (${invoice.createdBy})", 40f, y, footerPaint)
    canvas.drawText("Checked By", 230f, y, footerPaint)
    canvas.drawText("Authorized By${invoice.signedByRole?.let { " ($it)" } ?: ""}", 420f, y, footerPaint)

    canvas.drawText("Generated ${java.time.LocalDateTime.now()} — ABM ERP", 40f, 815f, footerPaint)

    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "invoice_${invoice.invoiceNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/** Shared FileProvider-share step for every structured PDF below — one place to get the MIME type/authority/error-safety right instead of repeating it at each call site. */
fun shareStructuredPdf(context: Context, file: File, label: String) {
    val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(android.content.Intent.createChooser(intent, label))
}

/** Shared PDF-page bootstrap (company header + document title) reused by every structured template below, so each function only draws its own body content. */
private fun newInvoiceStylePage(title: String): Triple<android.graphics.pdf.PdfDocument, android.graphics.pdf.PdfDocument.Page, Float> {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas
    val headerPaint = android.graphics.Paint().apply { textSize = 20f; isFakeBoldText = true }
    val subHeaderPaint = android.graphics.Paint().apply { textSize = 12f; color = android.graphics.Color.DKGRAY }
    canvas.drawText("Mohona ERP", 40f, 45f, headerPaint)
    canvas.drawText(title, 40f, 67f, subHeaderPaint)
    return Triple(pdfDocument, page, 97f)
}

/**
 * Dealer Statement — Dealer profile + real PartyLedgerEntry history. Uses
 * MockRepository.partyLedgerFor's already-loaded Flow value at call time
 * (passed in as a plain List so this stays a non-suspend, non-Compose
 * function callable from anywhere).
 */
fun exportDealerStatementPdf(context: Context, dealer: com.abm.erp.data.Dealer, ledger: List<com.abm.erp.data.PartyLedgerEntry>): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("DEALER STATEMENT")
    val canvas = page.canvas
    val labelPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Dealer: ${dealer.name}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Zone: ${dealer.zone}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Classification: ${dealer.classification}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Current Due: ৳${"%.2f".format(dealer.dueBalance)}", 40f, y, totalPaint); y += 28f

    canvas.drawText("Date", 40f, y, labelPaint)
    canvas.drawText("Reason", 140f, y, labelPaint)
    canvas.drawText("Type", 380f, y, labelPaint)
    canvas.drawText("Amount", 460f, y, labelPaint)
    y += 6f
    canvas.drawLine(40f, y, 555f, y, bodyPaint)
    y += 16f
    if (ledger.isEmpty()) {
        canvas.drawText("Data unavailable — no ledger entries recorded yet.", 40f, y, bodyPaint)
    } else {
        ledger.forEach { entry ->
            if (y > 780f) return@forEach
            canvas.drawText("${entry.createdAt.toLocalDate()}", 40f, y, bodyPaint)
            canvas.drawText(entry.reason.take(30), 140f, y, bodyPaint)
            canvas.drawText(entry.type, 380f, y, bodyPaint)
            canvas.drawText("৳${"%.2f".format(entry.amount)}", 460f, y, bodyPaint)
            y += 16f
        }
    }
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "dealer_statement_${dealer.name.take(12)}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

fun exportPurchaseOrderPdf(context: Context, po: com.abm.erp.data.PurchaseOrder): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("PURCHASE ORDER")
    val canvas = page.canvas
    val labelPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("PO No: ${po.poNo}", 40f, y, bodyPaint)
    canvas.drawText("Date: ${po.createdAt.toLocalDate()}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Supplier: ${po.supplierName}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Status: ${po.status}", 40f, y, bodyPaint); y += 28f

    canvas.drawText("Item", 40f, y, labelPaint)
    canvas.drawText("Qty", 300f, y, labelPaint)
    canvas.drawText("Unit Cost", 370f, y, labelPaint)
    canvas.drawText("Amount", 480f, y, labelPaint)
    y += 6f
    canvas.drawLine(40f, y, 555f, y, bodyPaint)
    y += 16f
    po.lineItems.forEach { item ->
        if (y > 760f) return@forEach
        canvas.drawText(item.name.take(30), 40f, y, bodyPaint)
        canvas.drawText("${item.qty}", 300f, y, bodyPaint)
        canvas.drawText("৳${"%.2f".format(item.unitCost)}", 370f, y, bodyPaint)
        canvas.drawText("৳${"%.2f".format(item.lineTotal)}", 480f, y, bodyPaint)
        y += 18f
    }
    y += 12f
    canvas.drawLine(350f, y, 555f, y, bodyPaint)
    y += 22f
    canvas.drawText("Total:", 400f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(po.subTotal)}", 480f, y, totalPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "purchase_order_${po.poNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/** Production Sheet — ProductionOrder has no line-item breakdown in the current data model (BOM is a separate lookup by bomId this function doesn't join against), so this stays a header-level sheet rather than fabricating a materials table. */
fun exportProductionOrderPdf(context: Context, order: com.abm.erp.data.ProductionOrder): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("PRODUCTION SHEET")
    val canvas = page.canvas
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Order No: ${order.orderNo}", 40f, y, bodyPaint)
    canvas.drawText("Scheduled: ${order.scheduledDate.toLocalDate()}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Finished Product: ${order.finishedProductName}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Target Quantity: ${order.targetQty}", 40f, y, totalPaint); y += 22f
    canvas.drawText("Status: ${order.status}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("Created by: ${order.createdBy.ifBlank { "Data unavailable" }}", 40f, y, bodyPaint); y += 18f
    canvas.drawText("BOM Reference: ${order.bomId}", 40f, y, bodyPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "production_sheet_${order.orderNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

fun exportVoucherPdf(context: Context, voucher: com.abm.erp.data.Voucher): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("${voucher.type} VOUCHER")
    val canvas = page.canvas
    val labelPaint = android.graphics.Paint().apply { textSize = 11f; isFakeBoldText = true }
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Voucher No: ${voucher.voucherNo}", 40f, y, bodyPaint)
    canvas.drawText("Date: ${voucher.voucherDate.toLocalDate()}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Narration: ${voucher.narration.ifBlank { "Data unavailable" }}", 40f, y, bodyPaint); y += 28f

    canvas.drawText("Account", 40f, y, labelPaint)
    canvas.drawText("Debit", 350f, y, labelPaint)
    canvas.drawText("Credit", 460f, y, labelPaint)
    y += 6f
    canvas.drawLine(40f, y, 555f, y, bodyPaint)
    y += 16f
    voucher.lines.forEach { line ->
        if (y > 780f) return@forEach
        canvas.drawText(line.accountName.take(35), 40f, y, bodyPaint)
        canvas.drawText(if (line.debit > 0) "৳${"%.2f".format(line.debit)}" else "-", 350f, y, bodyPaint)
        canvas.drawText(if (line.credit > 0) "৳${"%.2f".format(line.credit)}" else "-", 460f, y, bodyPaint)
        y += 16f
    }
    y += 12f
    canvas.drawLine(300f, y, 555f, y, bodyPaint)
    y += 22f
    canvas.drawText("Total:", 250f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(voucher.totalDebit)}", 350f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(voucher.totalCredit)}", 460f, y, totalPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "voucher_${voucher.voucherNo}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}

/** Payslip — PayrollLine has no employee address/designation/period fields in the current model, so those are shown as "Data unavailable" rather than fabricated; every number shown (base pay, achievement%, commission, absence penalty, net payable) is a real stored/derived field. */
fun exportPayslipPdf(context: Context, line: com.abm.erp.data.PayrollLine): File {
    val (pdfDocument, page, startY) = newInvoiceStylePage("PAYSLIP")
    val canvas = page.canvas
    val bodyPaint = android.graphics.Paint().apply { textSize = 11f }
    val totalPaint = android.graphics.Paint().apply { textSize = 13f; isFakeBoldText = true }
    var y = startY
    canvas.drawText("Employee: ${line.employeeName}", 40f, y, bodyPaint)
    canvas.drawText("ID: ${line.employeeId}", 350f, y, bodyPaint); y += 18f
    canvas.drawText("Pay Period: Data unavailable (not tracked per-line yet)", 40f, y, bodyPaint); y += 28f

    canvas.drawText("Base Pay:", 40f, y, bodyPaint)
    canvas.drawText("৳${"%.2f".format(line.basePay)}", 300f, y, bodyPaint); y += 18f
    canvas.drawText("Target vs Achieved:", 40f, y, bodyPaint)
    canvas.drawText("৳${"%.2f".format(line.targetAmount)} / ৳${"%.2f".format(line.achievedAmount)} (${"%.0f".format(line.achievementPct)}%)", 300f, y, bodyPaint); y += 18f
    canvas.drawText("Commission:", 40f, y, bodyPaint)
    canvas.drawText("৳${"%.2f".format(line.commission)}", 300f, y, bodyPaint); y += 18f
    canvas.drawText("Unapproved Absence Days:", 40f, y, bodyPaint)
    canvas.drawText("${line.unapprovedAbsenceDays} (−৳${"%.2f".format(line.absencePenalty)})", 300f, y, bodyPaint); y += 24f
    canvas.drawLine(40f, y, 555f, y, bodyPaint); y += 20f
    canvas.drawText("Net Payable:", 40f, y, totalPaint)
    canvas.drawText("৳${"%.2f".format(line.netPayable)}", 300f, y, totalPaint)
    pdfDocument.finishPage(page)
    val file = File(context.getExternalFilesDir(null), "payslip_${line.employeeId}_${System.currentTimeMillis()}.pdf")
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    return file
}
