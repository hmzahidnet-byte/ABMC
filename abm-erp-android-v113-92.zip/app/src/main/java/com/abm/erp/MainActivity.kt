package com.abm.erp

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.fragment.app.FragmentActivity
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.abm.erp.data.MockRepository
import com.abm.erp.nav.Dest
import com.abm.erp.nav.ABMNavGraph
import com.abm.erp.theme.ABMErpTheme
import com.abm.erp.theme.TextSecondary
import com.abm.erp.ui.login.LoginScreen

/**
 * FragmentActivity (not plain ComponentActivity) because androidx.biometric's
 * BiometricPrompt requires a FragmentActivity host to attach its dialog to.
 * FragmentActivity is itself a ComponentActivity, so setContent{} below still
 * works exactly the same way.
 */
class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ABMErpTheme {
                var mode by remember { mutableStateOf("login") } // "login" | "staff" | "dealerLogin" | "dealer"
                var activeDealerId by remember { mutableStateOf<String?>(null) }

                when (mode) {
                    "staff" -> ABMApp(onLogout = { MockRepository.logout(this); mode = "login" })
                    "dealerLogin" -> com.abm.erp.ui.dealer.DealerLoginScreen(
                        onDealerChosen = { id -> activeDealerId = id; mode = "dealer" },
                        onBackToStaffLogin = { mode = "login" },
                    )
                    "dealer" -> com.abm.erp.ui.dealer.DealerHomeScreen(
                        dealerId = activeDealerId ?: "",
                        onLogout = { mode = "login" },
                    )
                    else -> LoginScreen(
                        activity = this,
                        onLoginSuccess = { mode = "staff" },
                        onDealerLoginRequested = { mode = "dealerLogin" },
                    )
                }
            }
        }
    }
}

private val destIcons = mapOf(
    Dest.Dashboard.route to Icons.Filled.Dashboard,
    Dest.Sales.route to Icons.Filled.PointOfSale,
    Dest.Inventory.route to Icons.Filled.Inventory2,
    Dest.Crm.route to Icons.Filled.Map,
    Dest.Hrm.route to Icons.Filled.Groups,
    Dest.Billing.route to Icons.Filled.ReceiptLong,
    Dest.Production.route to Icons.Filled.Factory,
    Dest.Boardroom.route to Icons.Filled.Insights, // "Master Advisory" boardroom slot
)

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun ABMApp(onLogout: () -> Unit = {}) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: Dest.Dashboard.route
    val currentUser by MockRepository.currentUserFlow.collectAsState()
    var showLogoutConfirm by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    var showRightMenu by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showActivityLogDialog by remember { mutableStateOf(false) }
    var showTrustedDevicesDialog by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(
                                    brush = Brush.linearGradient(listOf(com.abm.erp.theme.GoldBright, com.abm.erp.theme.Gold, com.abm.erp.theme.GoldDeep)),
                                    shape = CircleShape,
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("ABM", color = Color(0xFF241A08), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(currentUser.name, style = MaterialTheme.typography.titleSmall)
                            Text("${currentUser.role} · ${currentUser.zone}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { showSearch = true }) {
                        Icon(Icons.Filled.Search, contentDescription = "Search")
                    }
                    // QR moved out of the (now removed) bottom bar and up here beside search,
                    // at the same weight as search. It stays the fastest route into a record —
                    // one tap opens the camera directly, no intermediate menu.
                    IconButton(
                        onClick = { navController.navigate(Dest.UniversalScanner.route) { launchSingleTop = true } },
                        modifier = Modifier
                            .size(38.dp)
                            .background(com.abm.erp.theme.DarazOrange, RoundedCornerShape(11.dp)),
                    ) {
                        Icon(
                            Icons.Filled.QrCodeScanner,
                            contentDescription = "Universal QR Scanner",
                            tint = Color.White,
                            modifier = Modifier.size(21.dp),
                        )
                    }
                    Spacer(Modifier.width(4.dp))
                    Box {
                        IconButton(onClick = { showRightMenu = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
                        }
                        DropdownMenu(expanded = showRightMenu, onDismissRequest = { showRightMenu = false }) {
                            DropdownMenuItem(text = { Text("Profile") }, leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) }, onClick = { showRightMenu = false; showProfileDialog = true })
                            DropdownMenuItem(text = { Text("Activity Log") }, leadingIcon = { Icon(Icons.Filled.History, contentDescription = null) }, onClick = { showRightMenu = false; showActivityLogDialog = true })
                            DropdownMenuItem(text = { Text("Trusted Devices") }, leadingIcon = { Icon(Icons.Filled.PhoneAndroid, contentDescription = null) }, onClick = { showRightMenu = false; showTrustedDevicesDialog = true })
                            DropdownMenuItem(text = { Text("Sync Status") }, leadingIcon = { Icon(Icons.Filled.Sync, contentDescription = null) }, onClick = { showRightMenu = false; navController.navigate(Dest.SyncStatusCenter.route) { launchSingleTop = true } })
                            DropdownMenuItem(text = { Text("Backup") }, leadingIcon = { Icon(Icons.Filled.Backup, contentDescription = null) }, onClick = { showRightMenu = false; showBackupDialog = true })
                            DropdownMenuItem(text = { Text("Settings") }, leadingIcon = { Icon(Icons.Filled.Settings, contentDescription = null) }, onClick = { showRightMenu = false; navController.navigate(Dest.CompanySettingsCenter.route) { launchSingleTop = true } })
                            DropdownMenuItem(text = { Text("Help") }, leadingIcon = { Icon(Icons.Filled.HelpOutline, contentDescription = null) }, onClick = { showRightMenu = false; navController.navigate(Dest.Helpdesk.route) { launchSingleTop = true } })
                            Divider()
                            DropdownMenuItem(text = { Text("Logout") }, leadingIcon = { Icon(Icons.Filled.Logout, contentDescription = null) }, onClick = { showRightMenu = false; showLogoutConfirm = true })
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
        },
    ) { padding ->
        Box(Modifier.padding(padding)) {
            ABMNavGraph(navController = navController)
        }
    }

    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            title = { Text("Logout করবেন?") },
            text = { Text("আবার ঢুকতে PIN/biometric আবার লাগবে।") },
            confirmButton = {
                TextButton(onClick = { showLogoutConfirm = false; onLogout() }) { Text("হ্যাঁ, Logout") }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false }) { Text("বাতিল") }
            },
        )
    }
    if (showSearch) {
        com.abm.erp.ui.search.UniversalSearchDialog(
            onDismiss = { showSearch = false },
            onNavigate = { route -> showSearch = false; navController.navigate(route) { launchSingleTop = true } },
        )
    }
    if (showProfileDialog) {
        val profiles by MockRepository.employeeProfiles.collectAsState()
        val profile = profiles.firstOrNull { it.id == currentUser.employeeId }
        val company = remember(currentUser.companyId) { MockRepository.companySettings() }
        AlertDialog(
            onDismissRequest = { showProfileDialog = false },
            title = { Text("Profile") },
            text = {
                Column {
                    Text(currentUser.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Employee ID: ${profile?.employeeCode?.ifBlank { null } ?: currentUser.employeeId}", style = MaterialTheme.typography.bodySmall)
                    Text("Designation: ${profile?.designation?.ifBlank { null } ?: "—"}", style = MaterialTheme.typography.bodySmall)
                    Text("Company: ${company.companyName.ifBlank { "—" }}", style = MaterialTheme.typography.bodySmall)
                    Text("Territory: ${currentUser.zone}", style = MaterialTheme.typography.bodySmall)
                    Text("Phone: ${currentUser.phone.ifBlank { "—" }}", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = { showProfileDialog = false }) { Text("Close") } },
        )
    }
    if (showActivityLogDialog) {
        Dialog(onDismissRequest = { showActivityLogDialog = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                com.abm.erp.ui.dashboard.LoginActivityLogScreen(onClose = { showActivityLogDialog = false })
            }
        }
    }
    if (showTrustedDevicesDialog) {
        Dialog(onDismissRequest = { showTrustedDevicesDialog = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                com.abm.erp.ui.dashboard.TrustedDevicesScreen(onClose = { showTrustedDevicesDialog = false })
            }
        }
    }
    if (showBackupDialog) {
        Dialog(onDismissRequest = { showBackupDialog = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                com.abm.erp.ui.dashboard.BackupRecoveryScreen(onClose = { showBackupDialog = false })
            }
        }
    }
}
