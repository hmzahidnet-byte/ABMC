package com.abm.erp.core

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.MarkunreadMailbox
import androidx.compose.material.icons.filled.Send
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.data.Dealer
import com.abm.erp.data.EmployeeProfile
import com.abm.erp.data.MockRepository
import com.abm.erp.data.createCustomerComplaint
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.data.PartyType
import com.abm.erp.data.Product
import com.abm.erp.data.Retailer
import com.abm.erp.data.UserRole
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import kotlinx.coroutines.launch
import java.time.LocalDate

/**
 * v113-85 — per-module descriptors for the shared browse flow (ModuleBrowseFlow.kt).
 * Each is small on purpose: the screens live in one place, these only say what a
 * module's records look like and which drill-downs it genuinely has.
 *
 * Honest asymmetry, deliberately preserved rather than papered over:
 *  - Dealer and Retailer are money-bearing parties → they get Ledger, Calendar,
 *    Product Graph and 90-Day, all off real PartyLedger / invoice / collection data.
 *  - Employee is not a money-bearing party in this codebase — there is no employee
 *    ledger — so HR's browse flow shows identity, role/geo and status only, with no
 *    ledger/graph buttons. Rendering empty ones would imply data exists that doesn't.
 */

private fun classLabel(c: String) = when (c) { "A" -> "A-Class"; "C" -> "C-Class"; else -> "B-Class" }

// ── DMS · Dealer ───────────────────────────────────────────────────────────────

@Composable
// v113-274 — the person's own direct request: Dealer Detail should show
// (read-only — assigning/reassigning stays Chairman-panel-only, already
// true today since no edit UI for this exists anywhere else) who is
// actually responsible for this dealer — SO, and every manager above
// them, walking the real reporting chain (`directManagerId`, the same
// field `subordinateIdsRecursive` already uses for cascade scoping) up
// from `Dealer.assignedEmployeeId`, not a second, separate assignment
// mechanism. Each level labelled by that employee's own real `role`, not
// a hardcoded "SO/ASM/TSM/RSM" list — the actual chain for a given
// dealer may be shorter or use different role names, and this reads
// whatever is real rather than assuming a fixed depth.
fun dealerOfficerChainRows(dealer: Dealer): List<BrowseInfoRow> {
    val employees = MockRepository.employeeProfiles.value
    val chain = mutableListOf<com.abm.erp.data.EmployeeProfile>()
    var currentId = dealer.assignedEmployeeId
    val visited = mutableSetOf<String>()
    while (currentId != null && visited.add(currentId)) {
        val emp = employees.firstOrNull { it.id == currentId } ?: break
        chain.add(emp)
        currentId = emp.directManagerId
    }
    if (chain.isEmpty()) return listOf(BrowseInfoRow("দায়িত্বপ্রাপ্ত কর্মকর্তা", "নির্ধারিত নেই — Chairman Panel থেকে সেট করুন"))
    return chain.map { emp -> BrowseInfoRow(emp.role.name, emp.fullName) }
}

// v113-293 — the person's own real CI/Android-Studio errors: a
// @Composable function TYPE nested inside a standard-library generic
// (Pair<String, @Composable (...) -> Unit>) is a genuinely fragile
// pattern for the Compose compiler plugin's own type inference — it
// produced the exact real cascade reported (argument-type mismatches
// against an "ERROR CLASS: Unknown return lambda parameter type",
// meaning the compiler itself failed to resolve the expected type
// through the Pair's own generic parameter). A plain data class with a
// direct @Composable-typed property is the well-established, reliable
// alternative — the same direct-property shape `BrowseConfig.
// extraTabContent` itself already uses successfully, confirmed against
// that real declaration before designing this the same way.
private data class DealerTabEntry(val label: String, val content: @Composable (Dealer, (String) -> Unit) -> Unit)

@Composable
fun rememberDealerBrowseConfig(zones: List<String>): BrowseConfig<Dealer> {
    val invoices by MockRepository.salesInvoices.collectAsState()
    val collections by MockRepository.partyCollections.collectAsState()
    // v113-274 — the person's own direct instruction: Status Control,
    // Merge/Transfer, and Account (phone/login) shouldn't just have their
    // CONTENT gated (v113-267's fix) — they shouldn't appear as tabs at
    // all outside the Chairman panel. Built as one ordered list of
    // (label, content) pairs, filtered once by role, so extraTabs' own
    // labels and extraTabContent's own dispatch below always agree on
    // what's actually showing — removing a tab can never silently shift
    // a later tab's index into the wrong content, however many tabs a
    // Chairman vs a regular viewer ends up with.
    val isChairman = MockRepository.currentUser.role == UserRole.CHAIRMAN
    return remember(zones, invoices, collections, isChairman) {
        val allTabs: List<DealerTabEntry> = buildList {
            add(
                DealerTabEntry("Transactions") { d: Dealer, onNavigate: (String) -> Unit ->
                    PartyTransactionsTab(
                        partyType = PartyType.DEALER, partyId = d.id,
                        invoiceDocs = invoices.filter { !it.isDeleted && it.dealerId == d.id },
                        onNavigate = onNavigate,
                    )
                },
            )
            if (isChairman) add(DealerTabEntry("Status Control") { d: Dealer, _: (String) -> Unit -> DealerLifecycleControlTab(d) })
            if (isChairman) add(DealerTabEntry("Merge/Transfer") { d: Dealer, _: (String) -> Unit -> DealerMergeTransferTab(d) })
            add(DealerTabEntry("Stock") { d: Dealer, _: (String) -> Unit -> com.abm.erp.ui.dealer.DealerStockContent(d) })
            add(DealerTabEntry("Contact") { d: Dealer, _: (String) -> Unit -> DealerContactTab(d) })
            if (isChairman) add(DealerTabEntry("Account") { d: Dealer, _: (String) -> Unit -> DealerAccountControlTab(d) })
            add(DealerTabEntry("Complaint") { d: Dealer, _: (String) -> Unit -> DealerComplaintTab(d) })
            add(DealerTabEntry("Sales Report") { d: Dealer, _: (String) -> Unit -> DealerSalesReportTab(d) })
        }
        BrowseConfig(
            moduleName = "DMS", entityLabel = "Dealer",
            colorStart = 0xFF2563EB, colorEnd = 0xFF1E3A8A,
            idOf = { it.id },
            titleOf = { it.name },
            codeOf = { it.dealerCode.ifBlank { it.id.take(8).uppercase() } },
            subtitleOf = { "${it.phone.ifBlank { "ফোন নেই" }} · ${it.zone}" },
            categoryOf = { "${classLabel(it.classification)} Dealer" },
            isActiveOf = { it.isActive },
            photoUriOf = { it.photoUri },
            locationOf = { d -> if (d.lat != null && d.lng != null) d.lat to d.lng else null },
            searchMatches = { d, q -> d.name.contains(q, true) || d.dealerCode.contains(q, true) || d.phone.contains(q, true) || d.zone.contains(q, true) },
            facets = listOf(
                BrowseFacet("Area", zones) { d, o -> d.zone == o },
                BrowseFacet("Category", listOf("A", "B", "C")) { d, o -> d.classification == o },
                BrowseFacet("Status", listOf("Active", "Inactive")) { d, o -> (o == "Active") == d.isActive },
            ),
            infoRows = { d ->
                listOf(
                    BrowseInfoRow("Dealer Code", d.dealerCode.ifBlank { d.id.take(8).uppercase() }),
                    BrowseInfoRow("Dealer Name", d.name),
                    BrowseInfoRow("Owner Name", d.proprietorName.ifBlank { "—" }),
                    BrowseInfoRow("Phone", d.phone.ifBlank { "—" }),
                    BrowseInfoRow("Area / Zone", d.zone),
                    BrowseInfoRow("Address", d.address.ifBlank { "—" }),
                    BrowseInfoRow("Category", "${classLabel(d.classification)} Dealer"),
                    BrowseInfoRow("Status", if (d.isActive) "Active" else "Inactive"),
                    BrowseInfoRow("Join Date", d.createdAt.toLocalDate().toString()),
                    BrowseInfoRow("Credit Limit", if (d.creditLimit > 0) "৳${"%,.0f".format(d.creditLimit)}" else "নির্ধারিত নেই"),
                ) + dealerOfficerChainRows(d)
            },
            kpis = { d ->
                val inv = invoices.filter { !it.isDeleted && it.dealerId == d.id }
                val col = collections.filter { it.partyType == PartyType.DEALER && it.partyId == d.id && it.status == "VERIFIED" }
                listOf(
                    BrowseKpi("Total Sales", "৳${"%,.0f".format(inv.sumOf { it.total })}"),
                    BrowseKpi("Total Collection", "৳${"%,.0f".format(col.sumOf { it.amount })}", SuccessGreen),
                    BrowseKpi("Total Due", "৳${"%,.0f".format(d.dueBalance)}", if (d.dueBalance > 0) WarningAmber else SuccessGreen),
                )
            },
            hasLedger = true,
            activities = { d -> rememberPartyActivities(PartyType.DEALER, d.id) },
            hasGraph = true,
            slices = { d ->
                invoices.filter { !it.isDeleted && it.dealerId == d.id }
                    .flatMap { it.lineItems }.groupBy { it.name }
                    .map { (n, l) -> BrowseSlice(n, l.sumOf { it.lineTotal }) }
            },
            has90Day = true,
            summary90 = { d ->
                val cutoff = LocalDate.now().minusDays(90)
                val inv = invoices.filter { !it.isDeleted && it.dealerId == d.id && it.createdAt.toLocalDate() >= cutoff }
                val col = collections.filter { it.partyType == PartyType.DEALER && it.partyId == d.id && it.status == "VERIFIED" && it.createdAt.toLocalDate() >= cutoff }
                listOf(
                    BrowseKpi("Sales", "৳${"%,.0f".format(inv.sumOf { it.total })}"),
                    BrowseKpi("Collection", "৳${"%,.0f".format(col.sumOf { it.amount })}", SuccessGreen),
                    BrowseKpi("Due", "৳${"%,.0f".format(d.dueBalance)}", WarningAmber),
                    BrowseKpi("Invoices", "${inv.size}"),
                    BrowseKpi("Collections", "${col.size}"),
                    BrowseKpi("Stock Units", "${d.stockUnits}"),
                )
            },
            qrEntityType = "Dealer", // canonical registry type — same string activateQrFor uses at approval
            // v113-267 — the person's own confirmed decision: a new Dealer
            // submission no longer starts from the List screen's own "+
            // Add" button — it now lives inside the Approve/Chairman
            // panel's own "Dealer Add" section instead (see
            // DealerApprovalsShared, core/DmsHomeScreen.kt), right next to
            // the pending list it already showed. `addRoute = null` means
            // ModuleBrowseList's own "+ Add" button simply doesn't render
            // for Dealer anymore — not hidden, genuinely gone from here.
            addRoute = null,
            // v113-146 — real CSV import for dealers. Column names match what
            // `exportListAsCsv` writes plus the fields createDealer needs, so an
            // exported sheet edited in Excel round-trips. Each row goes through the
            // SAME createDealer the manual form uses, so permission/duplicate/
            // validation rules are identical and each failure reports its real reason.
            importCsv = { text ->
                val lines = text.lines().filter { it.isNotBlank() }
                if (lines.size < 2) {
                    CsvImport.ImportOutcome(0, 0, 0, emptyList(), "ফাইলে header ছাড়া কোনো row নেই।")
                } else {
                    val header = CsvImport.splitCsvLine(lines.first())
                    val (idx, missing) = CsvImport.headerIndex(header, listOf("Name", "Phone"))
                    if (missing != null) {
                        CsvImport.ImportOutcome(0, 0, 0, emptyList(), missing)
                    } else {
                        val results = mutableListOf<CsvImport.RowResult>()
                        lines.drop(1).forEachIndexed { i, raw ->
                            val cols = CsvImport.splitCsvLine(raw)
                            fun col(name: String): String = idx[name.lowercase()]?.let { cols.getOrNull(it) }.orEmpty()
                            val name = col("Name")
                            var reason: String? = null
                            val created = MockRepository.createDealer(
                                name = name, zone = col("Zone"), phone = col("Phone"), address = col("Address"),
                                onRejected = { r -> reason = r },
                            )
                            results.add(CsvImport.RowResult(i + 2, name.ifBlank { "(নামহীন)" }, created != null, reason))
                        }
                        CsvImport.ImportOutcome(results.size, results.count { it.ok }, results.count { !it.ok }, results)
                    }
                }
            },
            extraTabs = allTabs.map { it.label },
            // v113-274 — dispatch by real position in the SAME filtered
            // list extraTabs' own labels came from (tabIdx - 1, since
            // index 0 is always the built-in "Overview" tab, added
            // outside extraTabs by ModuleBrowseDetail itself — confirmed
            // directly against that code before relying on the offset)
            // — not a hand-maintained `when` block that has to be kept in
            // sync with the list above by hand.
            extraTabContent = { d, tabIdx, onNavigate -> allTabs.getOrNull(tabIdx - 1)?.content?.invoke(d, onNavigate) },
        )
    }
}

// v113-201 — Dealer lifecycle control tab: Pause / Suspend / Terminate /
// Reactivate, calling MockRepository.setDealerLifecycleStatus directly.
// v113-274 — the v113-267 comment below (itself already correcting a
// stale v113-201 claim) is, in turn, now out of date: it described the
// gate living "at extraTabContent's own tabIdx==2 branch" — that
// hand-maintained `when` block no longer exists. The real gate now lives
// in `allTabs`' own role filter inside rememberDealerBrowseConfig
// ("Status Control" only added to the list at all for a confirmed
// Chairman viewer) — this composable is still only ever actually
// composed for that same confirmed Chairman viewer, just reached via a
// different, safer mechanism (removing a tab from the list can't
// silently shift another tab's index, the way editing a `when` by hand
// could). The repository function's own server-side Chairman-only check
// stays as the real backend authority either way, unaffected by any of
// this.
@Composable
internal fun DealerLifecycleControlTab(dealer: Dealer) {
    var working by remember { mutableStateOf(false) }
    var result by remember(dealer.id) { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    // v113-274 — the person's own direct instruction at the time: a
    // simple toggle (On/Pause/Off) instead of the old 4-button panel
    // with a mandatory typed reason. The real backend
    // (setDealerLifecycleStatus) still requires a reason for its own
    // audit trail — kept, not removed — just auto-supplied here instead
    // of typed, since a toggle tap IS the reason.
    // v113-282 — the person's own follow-up, more specific this time:
    // Dealer Control should offer Hold/Active/Terminate/Suspend/
    // De-active explicitly, five words for what the real backend only
    // has four distinct states for (ACTIVE/PAUSED/SUSPENDED/
    // TERMINATED — confirmed directly against setDealerLifecycleStatus's
    // own accepted values) — "Hold" and "Suspend"/"De-active" read as
    // the person's own synonyms for Paused and Suspended respectively,
    // so TERMINATED (folded away in v113-274) is the one real 4th state
    // being asked back, not five genuinely distinct new ones.
    fun apply(newStatus: String, label: String) {
        working = true; result = null
        scope.launch {
            val ok = MockRepository.setDealerLifecycleStatus(dealer.id, newStatus, "Chairman panel — টগল করে $label করা হয়েছে", onRejected = { r -> result = "✖ $r" })
            if (ok) result = "✔ Status বদলে $label হয়েছে।"
            working = false
        }
    }

    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text("বর্তমান Status", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Text(dealer.status, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).border(1.dp, HairlineBorder, RoundedCornerShape(10.dp))) {
            listOf(
                Triple("ACTIVE", "Active", SuccessGreen), Triple("PAUSED", "Hold", WarningAmber),
                Triple("SUSPENDED", "Suspend", Color(0xFFE85D4A)), Triple("TERMINATED", "Terminate", com.abm.erp.theme.DangerRed),
            ).forEach { (status, label, color) ->
                val selected = dealer.status == status
                Box(
                    Modifier.weight(1f).background(if (selected) color.copy(alpha = 0.15f) else Color.Transparent)
                        .clickable(enabled = !working && !selected) { apply(status, label) }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) { Text(label, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, color = if (selected) color else TextSecondary) }
            }
        }
        result?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = if (it.startsWith("✔")) SuccessGreen else com.abm.erp.theme.DangerRed, style = MaterialTheme.typography.labelSmall)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Suspend/Terminate করলে dealer-এর নিজের login বন্ধ হয়ে যাবে এবং নতুন invoice করা যাবে না। Hold শুধু নতুন invoice বন্ধ করে, login চলবে। Terminate-ও reversible — যেকোনো সময় আবার Active করা যায় (স্থায়ীভাবে সরাতে নিচের Cancel ব্যবহার করুন)।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
    }
}

// v113-244 — the person's own direct follow-up: DealersScreen.kt's own
// legacy DealerDetailPanel (reached from its Directory tab, separate
// from search/scan which already correctly use ModuleBrowseDetail) was
// left alone at v113-236 specifically because two of its real
// capabilities — pending-application Approve/Reject, and Set/Reset Login
// PIN — had no equivalent anywhere in this Dealer config's own extraTabs
// yet. Built here, following the exact same pattern Retailer's own
// RetailerPinControlTab already established, so ModuleBrowseDetail
// genuinely has full parity with the legacy panel's two most
// consequential actions before anything gets redirected to it.
@Composable
internal fun DealerAccountControlTab(dealer: Dealer) {
    var newPin by remember(dealer.id) { mutableStateOf("") }
    var pinError by remember(dealer.id) { mutableStateOf<String?>(null) }
    var pinSaved by remember(dealer.id) { mutableStateOf(false) }

    // v113-274 — the person's own direct instruction: phone number/login
    // (PIN) is the one thing that actually belongs behind Chairman-only
    // now (this whole tab is only ever composed for a confirmed Chairman
    // viewer — see allTabs' own role filter above). The pending-approval
    // approve/reject shortcut that used to sit at the top of this same
    // tab is gone — genuinely redundant with the real "view full details,
    // then decide" flow the Approve panel already has (v113-264/265),
    // and having two different approve buttons in two different places
    // wasn't good hygiene. Call/SMS/WhatsApp/photo (routine, daily-use
    // for any field officer, not Chairman-specific material) moved to
    // their own real "Contact" tab below, open to everyone — splitting
    // this tab rather than making the whole thing Chairman-only would
    // have quietly taken those away from people who use them every day.
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text(
            if (dealer.pinHash != null) "একটা PIN আগে থেকেই সেট করা আছে — নতুন PIN দিলে সেটা বদলে যাবে।" else "এই dealer এখনো নিজের PIN দিয়ে login করতে পারবে না — একটা PIN সেট করুন।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(6.dp))
        Text("ফোন নম্বর: ${dealer.phone.ifBlank { "—" }}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = newPin, onValueChange = { newPin = it.filter(Char::isDigit).take(5); pinSaved = false },
            label = { Text("নতুন PIN (4-5 digit, একঘেয়ে/ক্রমিক না)") }, modifier = Modifier.fillMaxWidth(),
        )
        pinError?.let { Spacer(Modifier.height(4.dp)); Text(it, color = com.abm.erp.theme.DangerRed, style = MaterialTheme.typography.labelSmall) }
        if (pinSaved) { Spacer(Modifier.height(4.dp)); Text("✔ PIN সেট হয়েছে।", color = SuccessGreen, style = MaterialTheme.typography.labelSmall) }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                pinError = null
                if (!MockRepository.setDealerPin(dealer.id, newPin)) pinError = "খুব সহজ PIN — অন্যটা বেছে নিন।"
                else { pinSaved = true; newPin = "" }
            },
            enabled = newPin.length in 4..5,
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (dealer.pinHash != null) "Reset PIN" else "Set PIN") }
    }
}

// v113-274 — the routine, daily-use part split out of the old "Account"
// tab (Call/SMS/WhatsApp/photo) — kept open to everyone, since none of it
// is Chairman-specific; only PIN/login moved behind the role gate above.
@Composable
private fun DealerContactTab(dealer: Dealer) {
    val callContext = androidx.compose.ui.platform.LocalContext.current
    val photoScope = rememberCoroutineScope()
    var photoUploading by remember(dealer.id) { mutableStateOf(false) }
    val photoLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent(),
    ) { uri ->
        if (uri != null) {
            photoUploading = true
            photoScope.launch { MockRepository.uploadDealerPhoto(callContext, dealer.id, uri.toString()) { photoUploading = false } }
        }
    }

    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        if (dealer.phone.isNotBlank()) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                IconButton(onClick = {
                    try { callContext.startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:${dealer.phone}"))) }
                    catch (e: Exception) { android.widget.Toast.makeText(callContext, "Call করা যায়নি।", android.widget.Toast.LENGTH_SHORT).show() }
                }) { Icon(Icons.Filled.Call, contentDescription = "Call ${dealer.name}") }
                IconButton(onClick = {
                    try { callContext.startActivity(android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:${dealer.phone}"))) }
                    catch (e: Exception) { android.widget.Toast.makeText(callContext, "SMS app পাওয়া যায়নি।", android.widget.Toast.LENGTH_SHORT).show() }
                }) { Icon(Icons.Filled.MarkunreadMailbox, contentDescription = "SMS ${dealer.name}") }
                IconButton(onClick = {
                    try {
                        val digits = dealer.phone.filter { it.isDigit() }
                        val intl = if (digits.startsWith("880")) digits else "88" + digits.removePrefix("0").let { d -> if (d.startsWith("1")) "0$d" else d }
                        callContext.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://wa.me/$intl")))
                    } catch (e: Exception) { android.widget.Toast.makeText(callContext, "WhatsApp খোলা যায়নি।", android.widget.Toast.LENGTH_SHORT).show() }
                }) { Icon(Icons.Filled.Send, contentDescription = "WhatsApp ${dealer.name}") }
            }
            Spacer(Modifier.height(10.dp))
        }
        if (dealer.photoUri != null) {
            coil.compose.AsyncImage(
                model = dealer.photoUri, contentDescription = dealer.name,
                modifier = Modifier.fillMaxWidth().height(140.dp),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
            )
            Spacer(Modifier.height(6.dp))
        }
        OutlinedButton(onClick = { photoLauncher.launch("image/*") }, enabled = !photoUploading, modifier = Modifier.fillMaxWidth()) {
            Text(
                when {
                    photoUploading -> "আপলোড হচ্ছে…"
                    dealer.photoUri != null -> "📷 ছবি বদলান"
                    else -> "📷 Dealer-এর ছবি যোগ করুন"
                },
            )
        }
    }
}

// v113-249 — the person's own direct request: a Dealer-specific complaint
// box within Dealer's own rich detail — "শুধুমাত্র ডিলাররাই দিবে" (only
// dealers will submit here). CustomerComplaint already correctly
// separates Dealer/Retailer complaints via partyType (confirmed directly
// against the model — dealerId/dealerName for one, retailerId/
// retailerName for the other, not a shared generic partyId), so this is
// a real filter on real, already-separated data, not a new distinction.
@Composable
private fun DealerComplaintTab(dealer: Dealer) {
    val allComplaints by MockRepository.customerComplaints.collectAsState()
    val complaints = remember(allComplaints, dealer.id) {
        allComplaints.filter { it.partyType == PartyType.DEALER && it.dealerId == dealer.id && !it.isDeleted }.sortedByDescending { it.createdAt }
    }
    var showNew by remember(dealer.id) { mutableStateOf(false) }
    var description by remember(dealer.id) { mutableStateOf("") }
    var category by remember(dealer.id) { mutableStateOf("OTHER") }
    var priority by remember(dealer.id) { mutableStateOf("NORMAL") }
    var submitError by remember(dealer.id) { mutableStateOf<String?>(null) }
    val complaintScope = rememberCoroutineScope()

    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text("Complaint (${complaints.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
            TextButton(onClick = { showNew = true }) { Text("+ নতুন") }
        }
        if (complaints.isEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text("এই dealer-এর কোনো complaint নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        }
        Spacer(Modifier.height(6.dp))
        complaints.forEach { c ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(c.complaintNo, fontWeight = FontWeight.SemiBold, color = TextPrimary, style = MaterialTheme.typography.labelMedium)
                    Text(
                        c.status.name,
                        color = when (c.status) {
                            com.abm.erp.data.CustomerComplaintStatus.RESOLVED, com.abm.erp.data.CustomerComplaintStatus.CLOSED -> SuccessGreen
                            com.abm.erp.data.CustomerComplaintStatus.REJECTED -> com.abm.erp.theme.DangerRed
                            else -> WarningAmber
                        },
                        style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold,
                    )
                }
                Text("${c.category} · ${c.priority}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text(c.description, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                c.resolutionNote?.ifBlank { null }?.let {
                    Spacer(Modifier.height(4.dp))
                    Text("সমাধান: $it", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                }
            }
        }
    }

    if (showNew) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showNew = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                    Text("নতুন Complaint — ${dealer.name}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Category", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        listOf("QUALITY", "QUANTITY", "DELIVERY", "BILLING", "OTHER").forEach { cat ->
                            FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat, style = MaterialTheme.typography.labelSmall) })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Priority", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("LOW", "NORMAL", "HIGH", "URGENT").forEach { p ->
                            FilterChip(selected = priority == p, onClick = { priority = p }, label = { Text(p, style = MaterialTheme.typography.labelSmall) })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("বিবরণ") }, modifier = Modifier.fillMaxWidth())
                    submitError?.let { Spacer(Modifier.height(6.dp)); Text(it, color = com.abm.erp.theme.DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            complaintScope.launch {
                                val c = MockRepository.createCustomerComplaint(
                                    dealer.id, dealer.name, description.trim(), category, priority,
                                    onRejected = { r -> submitError = r },
                                )
                                if (c != null) { showNew = false; description = "" }
                            }
                        },
                        enabled = description.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("জমা দিন") }
                }
            }
        }
    }
}


// v113-227 — chairmanMergeDealers/chairmanTransferDealer were both fully
// real, Chairman-only functions with zero UI callers anywhere — found via
// the same proactive sweep as Retailer's own equivalent gap, fixed the
// same way, right after it (see this file's Retailer Actions tab for the
// fuller trace).
@Composable
internal fun DealerMergeTransferTab(dealer: Dealer) {
    val scope = rememberCoroutineScope()
    val allDealers by MockRepository.dealers.collectAsState()
    val profiles by MockRepository.employeeProfiles.collectAsState()
    var showMerge by remember(dealer.id) { mutableStateOf(false) }
    var showTransfer by remember(dealer.id) { mutableStateOf(false) }
    var actionMsg by remember(dealer.id) { mutableStateOf<String?>(null) }
    var actionError by remember(dealer.id) { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        actionMsg?.let { Text(it, color = SuccessGreen, style = MaterialTheme.typography.labelSmall) }
        actionError?.let { Text(it, color = com.abm.erp.theme.DangerRed, style = MaterialTheme.typography.labelSmall) }
        TextButton(onClick = { showTransfer = true }) { Text("Zone/Territory/Employee Transfer") }
        TextButton(onClick = { showMerge = true }) { Text("Merge Duplicate Dealer", color = com.abm.erp.theme.DangerRed) }
    }

    if (showTransfer) {
        var newZone by remember { mutableStateOf(dealer.zone) }
        var newAssignedEmployeeId by remember { mutableStateOf<String?>(null) }
        androidx.compose.ui.window.Dialog(onDismissRequest = { showTransfer = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                    Text("Transfer — ${dealer.name}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newZone, onValueChange = { newZone = it }, label = { Text("Zone") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Text("নতুন দায়িত্বপ্রাপ্ত Employee (ঐচ্ছিক)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    profiles.filter { it.hasActiveAccess }.take(30).forEach { p ->
                        Text(
                            p.fullName, fontWeight = if (newAssignedEmployeeId == p.id) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { newAssignedEmployeeId = p.id },
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            scope.launch {
                                actionError = null
                                val ok = MockRepository.chairmanTransferDealer(dealer.id, newZone.trim().ifBlank { null }, dealer.territoryId, newAssignedEmployeeId)
                                if (ok) { actionMsg = "Transfer সংরক্ষিত হয়েছে।"; showTransfer = false } else actionError = "সংরক্ষণ করা যায়নি।"
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm Transfer") }
                }
            }
        }
    }
    if (showMerge) {
        var duplicateId by remember { mutableStateOf<String?>(null) }
        androidx.compose.ui.window.Dialog(onDismissRequest = { showMerge = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                    Text("Merge Duplicate Into — ${dealer.name}", style = MaterialTheme.typography.titleMedium)
                    Text("এই dealer-টাই থাকবে (survivor)। নিচে থেকে duplicate-টা বেছে দিন — সেটা মুছে যাবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(Modifier.height(8.dp))
                    allDealers.filter { !it.isDeleted && it.id != dealer.id }.forEach { dup ->
                        Text(
                            "${dup.name} (${dup.dealerCode})", fontWeight = if (duplicateId == dup.id) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { duplicateId = dup.id },
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val dupId = duplicateId
                            if (dupId != null) {
                                scope.launch {
                                    actionError = null
                                    val ok = MockRepository.chairmanMergeDealers(dealer.id, dupId)
                                    if (ok) { actionMsg = "Merge সম্পন্ন হয়েছে।"; showMerge = false } else actionError = "সংরক্ষণ করা যায়নি।"
                                }
                            }
                        },
                        enabled = duplicateId != null, modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = com.abm.erp.theme.DangerRed),
                    ) { Text("Confirm Merge") }
                }
            }
        }
    }
}

// ── RMS · Retailer ─────────────────────────────────────────────────────────────

@Composable
fun rememberRetailerBrowseConfig(markets: List<String>): BrowseConfig<Retailer> {
    val orders by MockRepository.orders.collectAsState()
    val collections by MockRepository.partyCollections.collectAsState()
    return remember(markets, orders, collections) {
        BrowseConfig(
            moduleName = "RMS", entityLabel = "Retailer",
            colorStart = 0xFF0EA5A4, colorEnd = 0xFF0F766E,
            idOf = { it.id },
            titleOf = { it.name },
            codeOf = { it.retailerCode.ifBlank { it.id.take(8).uppercase() } },
            subtitleOf = { "${it.phone.ifBlank { "ফোন নেই" }} · ${it.market.ifBlank { "market নেই" }}" },
            categoryOf = { "${classLabel(it.classification)} Retailer" },
            isActiveOf = { it.isActive },
            photoUriOf = { it.photoUri },
            locationOf = { r -> if (r.lat != null && r.lng != null) r.lat to r.lng else null },
            searchMatches = { r, q -> r.name.contains(q, true) || r.retailerCode.contains(q, true) || r.phone.contains(q, true) || r.market.contains(q, true) },
            facets = listOf(
                BrowseFacet("Market", markets) { r, o -> r.market == o },
                BrowseFacet("Category", listOf("A", "B", "C")) { r, o -> r.classification == o },
                BrowseFacet("Status", listOf("Active", "Inactive")) { r, o -> (o == "Active") == r.isActive },
            ),
            infoRows = { r ->
                listOf(
                    BrowseInfoRow("Retailer Code", r.retailerCode.ifBlank { r.id.take(8).uppercase() }),
                    BrowseInfoRow("Retailer Name", r.name),
                    BrowseInfoRow("Owner Name", r.ownerName.ifBlank { "—" }),
                    BrowseInfoRow("Phone", r.phone.ifBlank { "—" }),
                    BrowseInfoRow("Market / Route", r.market.ifBlank { "—" }),
                    BrowseInfoRow("Address", r.address.ifBlank { "—" }),
                    BrowseInfoRow("Category", "${classLabel(r.classification)} Retailer"),
                    BrowseInfoRow("Status", if (r.isActive) "Active" else "Inactive"),
                    BrowseInfoRow("Join Date", r.createdAt.toLocalDate().toString()),
                    BrowseInfoRow("Credit Limit", if (r.creditLimit > 0) "৳${"%,.0f".format(r.creditLimit)}" else "নির্ধারিত নেই"),
                )
            },
            kpis = { r ->
                val myOrders = orders.filter { it.retailerId == r.id || (it.retailerId == null && it.retailerName == r.name) }
                val col = collections.filter { it.partyType == PartyType.RETAILER && it.partyId == r.id && it.status == "VERIFIED" }
                listOf(
                    BrowseKpi("Memo Total", "৳${"%,.0f".format(myOrders.sumOf { it.amount })}"),
                    BrowseKpi("Collection", "৳${"%,.0f".format(col.sumOf { it.amount })}", SuccessGreen),
                    BrowseKpi("Total Due", "৳${"%,.0f".format(r.dueBalance)}", if (r.dueBalance > 0) WarningAmber else SuccessGreen),
                )
            },
            hasLedger = true,
            activities = { r -> rememberPartyActivities(PartyType.RETAILER, r.id) },
            hasGraph = true,
            slices = { r ->
                orders.filter { it.retailerId == r.id || (it.retailerId == null && it.retailerName == r.name) }
                    .flatMap { it.lineItems }.groupBy { it.name }
                    .map { (n, l) -> BrowseSlice(n, l.sumOf { it.lineTotal }) }
            },
            has90Day = true,
            summary90 = { r ->
                val cutoff = LocalDate.now().minusDays(90)
                val myOrders = orders.filter { (it.retailerId == r.id || (it.retailerId == null && it.retailerName == r.name)) && it.loggedAt.toLocalDate() >= cutoff }
                val col = collections.filter { it.partyType == PartyType.RETAILER && it.partyId == r.id && it.status == "VERIFIED" && it.createdAt.toLocalDate() >= cutoff }
                listOf(
                    BrowseKpi("Memo Amount", "৳${"%,.0f".format(myOrders.sumOf { it.amount })}"),
                    BrowseKpi("Collection", "৳${"%,.0f".format(col.sumOf { it.amount })}", SuccessGreen),
                    BrowseKpi("Due", "৳${"%,.0f".format(r.dueBalance)}", WarningAmber),
                    BrowseKpi("Memos", "${myOrders.size}"),
                    BrowseKpi("Collections", "${col.size}"),
                )
            },
            qrEntityType = "Retailer",
            // v113-265 — RMS's own standalone "add" route removed along
            // with the rest of the standalone module; the real form
            // (AddRetailerForm) now lives inside DMS, reached the same
            // way Dealer's own addRoute already works.
            addRoute = "dms?key=newretailer",
            extraTabs = listOf("Transactions", "Login PIN", "Actions"),
            extraTabContent = { r, tabIdx, onNavigate ->
                when (tabIdx) {
                    1 -> PartyTransactionsTab(
                        partyType = PartyType.RETAILER, partyId = r.id,
                        memoDocs = orders.filter { it.retailerId == r.id || (it.retailerId == null && it.retailerName == r.name) },
                        onNavigate = onNavigate,
                    )
                    2 -> RetailerPinControlTab(r)
                    else -> RetailerActionsTab(r)
                }
            },
        )
    }
}

// v113-227 — mergeRetailers/overrideRetailerCreditCheck/transferRetailerRoute
// were all fully real, working, Chairman/authorized-role-gated functions
// with zero UI callers anywhere — found via the same proactive sweep that
// caught the check-out and vacancy-fill gaps. Same extraTab mechanism
// Dealer's own admin actions already use (verified the real tabIdx
// semantics — offset by 1 relative to extraTabs, since tab 0 is always
// the built-in Info panel — directly against ModuleBrowseFlow.kt before
// adding a third tab here, rather than assume from the existing two).
@Composable
private fun RetailerActionsTab(retailer: Retailer) {
    val scope = rememberCoroutineScope()
    val allRetailers by MockRepository.retailers.collectAsState()
    val routes by MockRepository.salesRoutes.collectAsState()
    var showMerge by remember(retailer.id) { mutableStateOf(false) }
    var showCreditOverride by remember(retailer.id) { mutableStateOf(false) }
    var showRouteTransfer by remember(retailer.id) { mutableStateOf(false) }
    var actionMsg by remember(retailer.id) { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        actionMsg?.let { Text(it, color = SuccessGreen, style = MaterialTheme.typography.labelSmall) }
        TextButton(onClick = { showCreditOverride = true }) { Text("Credit Check Override") }
        TextButton(onClick = { showRouteTransfer = true }) { Text("Route Transfer") }
        TextButton(onClick = { showMerge = true }) { Text("Merge Duplicate Retailer", color = com.abm.erp.theme.DangerRed) }
    }

    if (showCreditOverride) {
        var reason by remember { mutableStateOf("") }
        androidx.compose.ui.window.Dialog(onDismissRequest = { showCreditOverride = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Credit Check Override — ${retailer.name}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val ok = MockRepository.overrideRetailerCreditCheck(retailer.id, reason.trim())
                            if (ok) { actionMsg = "Override সংরক্ষিত হয়েছে।"; showCreditOverride = false }
                        },
                        enabled = reason.isNotBlank(), modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm Override") }
                }
            }
        }
    }
    if (showRouteTransfer) {
        var selectedRouteId by remember { mutableStateOf<String?>(null) }
        var reason by remember { mutableStateOf("") }
        androidx.compose.ui.window.Dialog(onDismissRequest = { showRouteTransfer = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    Text("Route Transfer — ${retailer.name}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    routes.filter { it.isActive }.forEach { rt ->
                        Text(
                            rt.name, fontWeight = if (selectedRouteId == rt.id) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { selectedRouteId = rt.id },
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val rid = selectedRouteId
                            if (rid != null) {
                                val ok = MockRepository.transferRetailerRoute(retailer.id, rid, reason.trim())
                                if (ok) { actionMsg = "Route transfer সংরক্ষিত হয়েছে।"; showRouteTransfer = false }
                            }
                        },
                        enabled = selectedRouteId != null && reason.isNotBlank(), modifier = Modifier.fillMaxWidth(),
                    ) { Text("Confirm Transfer") }
                }
            }
        }
    }
    if (showMerge) {
        var duplicateId by remember { mutableStateOf<String?>(null) }
        var reason by remember { mutableStateOf("") }
        androidx.compose.ui.window.Dialog(onDismissRequest = { showMerge = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp).heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                    Text("Merge Duplicate Into — ${retailer.name}", style = MaterialTheme.typography.titleMedium)
                    Text("এই retailer-টাই থাকবে (survivor)। নিচে থেকে duplicate-টা বেছে দিন — সেটা মুছে যাবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    Spacer(Modifier.height(8.dp))
                    allRetailers.filter { !it.isDeleted && it.id != retailer.id }.forEach { dup ->
                        Text(
                            "${dup.name} (${dup.retailerCode})", fontWeight = if (duplicateId == dup.id) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { duplicateId = dup.id },
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val dupId = duplicateId
                            if (dupId != null) {
                                val ok = MockRepository.mergeRetailers(retailer.id, dupId, reason.trim())
                                if (ok) { actionMsg = "Merge সম্পন্ন হয়েছে।"; showMerge = false }
                            }
                        },
                        enabled = duplicateId != null && reason.isNotBlank(), modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = com.abm.erp.theme.DangerRed),
                    ) { Text("Confirm Merge") }
                }
            }
        }
    }
}

// v113-203 — Retailer's own self-service-login PIN control, same shape as
// Dealer's Set/Reset PIN action in DealersScreen.kt (mirrors setDealerPin's
// UI exactly), just reached through the generic browse-detail extraTab
// mechanism instead of a bespoke screen, since Retailer has no equivalent
// of DealersScreen.kt — it's managed entirely through this shared flow.
@Composable
private fun RetailerPinControlTab(retailer: Retailer) {
    var newPin by remember(retailer.id) { mutableStateOf("") }
    var pinError by remember(retailer.id) { mutableStateOf<String?>(null) }
    var saved by remember(retailer.id) { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text(
            if (retailer.pinHash != null) "একটা PIN আগে থেকেই সেট করা আছে — নতুন PIN দিলে সেটা বদলে যাবে।" else "এই retailer এখনো নিজের PIN দিয়ে login করতে পারবে না — একটা PIN সেট করুন।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = newPin, onValueChange = { newPin = it.filter(Char::isDigit).take(5); saved = false },
            label = { Text("নতুন PIN (4-5 digit, একঘেয়ে/ক্রমিক না)") }, modifier = Modifier.fillMaxWidth(),
        )
        pinError?.let { Spacer(Modifier.height(4.dp)); Text(it, color = com.abm.erp.theme.DangerRed, style = MaterialTheme.typography.labelSmall) }
        if (saved) { Spacer(Modifier.height(4.dp)); Text("✔ PIN সেট হয়েছে।", color = SuccessGreen, style = MaterialTheme.typography.labelSmall) }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                pinError = null
                if (!MockRepository.setRetailerPin(retailer.id, newPin)) pinError = "খুব সহজ PIN — অন্যটা বেছে নিন।"
                else { saved = true; newPin = "" }
            },
            enabled = newPin.length in 4..5,
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (retailer.pinHash != null) "Reset PIN" else "Set PIN") }
    }
}

// ── HR · Employee ──────────────────────────────────────────────────────────────

@Composable
fun rememberEmployeeBrowseConfig(departments: List<String>): BrowseConfig<EmployeeProfile> =
    remember(departments) {
        BrowseConfig(
            moduleName = "HR", entityLabel = "Employee",
            auditEntityType = "EmployeeProfile",
            colorStart = 0xFFDB2777, colorEnd = 0xFF9D174D,
            idOf = { it.id },
            titleOf = { it.fullName },
            codeOf = { it.employeeCode.ifBlank { it.id.take(8).uppercase() } },
            subtitleOf = { "${it.designation.ifBlank { it.role.name }} · ${it.department.ifBlank { "বিভাগ নেই" }}" },
            categoryOf = { it.role.name },
            isActiveOf = { it.hasActiveAccess },
            photoUriOf = { it.profilePhotoUri },
            searchMatches = { e, q -> e.fullName.contains(q, true) || e.employeeCode.contains(q, true) || e.mobile.contains(q, true) || e.designation.contains(q, true) },
            facets = listOf(
                BrowseFacet("Department", departments) { e, o -> e.department == o },
                BrowseFacet("Status", listOf("Active", "Inactive")) { e, o -> (o == "Active") == e.hasActiveAccess },
            ),
            infoRows = { e ->
                listOf(
                    BrowseInfoRow("Employee ID", e.employeeCode.ifBlank { e.id.take(8).uppercase() }),
                    BrowseInfoRow("Full Name", e.fullName),
                    BrowseInfoRow("Designation", e.designation.ifBlank { "—" }),
                    BrowseInfoRow("Role (permission)", e.role.name),
                    BrowseInfoRow("Department", e.department.ifBlank { "—" }),
                    BrowseInfoRow("Mobile", e.mobile.ifBlank { "—" }),
                    BrowseInfoRow("Employment Status", e.status.name),
                    BrowseInfoRow("Access", if (e.hasActiveAccess) "Active" else "No active access"),
                    BrowseInfoRow("Joined", e.createdAt.toLocalDate().toString()),
                )
            },
            // No ledger/graph/90-day: employees are not money-bearing parties in this
            // codebase, so those drill-downs genuinely have no data behind them.
            // First registry type introduced from the card itself: employees were never
            // auto-issued at approval (unlike Dealer/Retailer), so the card's "Issue"
            // button is the entry point. resolve() is type-agnostic, so scans validate.
            qrEntityType = "Employee",
            addRoute = "hr_module?key=add",
            // v113-219 — the person's own direct request: Employee's detail
            // view should carry everything, exactly like Dealer's own
            // "Status Control"/"Transactions" extraTabs. The full management
            // console (onboarding actions, area assignment, appraisal,
            // login-account/PIN control, emergency override, role/status
            // change, manager/approval-limits/transfer/delegate) already
            // existed and worked — it lived in a separate "Employee
            // Management" tab, mechanically extracted (not rewritten) to
            // `EmployeeManagementPanel` in PayrollScreen.kt and called
            // directly here, so it's the exact same, already-tested
            // behaviour, just reachable from the one comprehensive place
            // now instead of a separate tab.
            extraTabs = listOf("Manage", "Salary"),
            extraTabContent = { emp, tabIdx, _ ->
                if (tabIdx == 1) com.abm.erp.ui.hrm.EmployeeManagementPanel(emp) else com.abm.erp.ui.hrm.EmployeeSalaryTab(emp)
            },
        )
    }


// ── FMS · Product / Stock ──────────────────────────────────────────────────────

/**
 * v113-86 — FMS's "list" is a PRODUCT list, not a party list. The record shape is
 * honestly different: no phone/owner/due, but sku/unit/price and per-warehouse stock.
 * The engine's capability flags carry that honestly — no Ledger and no 90-Day (a
 * product has no party ledger or due), but the Graph drill-down IS enabled and shows
 * the real per-warehouse stock split for that product, which is the product-shaped
 * equivalent of the dealer's product split.
 */
@Composable
fun rememberProductBrowseConfig(categories: List<String>): BrowseConfig<Product> {
    val stockLevels by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
    return remember(categories, stockLevels) {
        BrowseConfig(
            moduleName = "FMS", entityLabel = "Product",
            colorStart = 0xFFE85D4A, colorEnd = 0xFFC03A2B,
            idOf = { it.id },
            titleOf = { it.name },
            codeOf = { it.sku.ifBlank { it.id.take(8).uppercase() } },
            subtitleOf = { p ->
                val onHand = stockLevels.filter { it.productId == p.id }.sumOf { it.quantityOnHand }
                "${p.category.ifBlank { "category নেই" }} · Stock: ${"%,.0f".format(onHand)} ${p.unit}"
            },
            categoryOf = { it.category.ifBlank { "Uncategorised" } },
            isActiveOf = { it.isActive && !it.isDeleted },
            searchMatches = { pr, q -> pr.name.contains(q, true) || pr.sku.contains(q, true) || pr.category.contains(q, true) },
            facets = listOf(
                BrowseFacet("Category", categories) { pr, o -> pr.category == o },
                BrowseFacet("Status", listOf("Active", "Inactive")) { pr, o -> (o == "Active") == (pr.isActive && !pr.isDeleted) },
            ),
            infoRows = { pr ->
                val levels = stockLevels.filter { it.productId == pr.id }
                val onHand = levels.sumOf { it.quantityOnHand }
                listOf(
                    BrowseInfoRow("SKU", pr.sku.ifBlank { "—" }),
                    BrowseInfoRow("Product Name", pr.name),
                    BrowseInfoRow("Category", pr.category.ifBlank { "—" }),
                    BrowseInfoRow("Unit", pr.unit),
                    BrowseInfoRow("Sale Price", "৳${"%,.2f".format(pr.defaultUnitPrice)}"),
                    BrowseInfoRow("Cost Price", if (pr.costPrice > 0) "৳${"%,.2f".format(pr.costPrice)}" else "সেট করা নেই"),
                    BrowseInfoRow("On Hand (all warehouses)", "${"%,.0f".format(onHand)} ${pr.unit}"),
                    BrowseInfoRow("Reorder Threshold", "${"%,.0f".format(pr.reorderThreshold)} ${pr.unit}"),
                    BrowseInfoRow("Status", if (pr.isActive && !pr.isDeleted) "Active" else "Inactive"),
                    BrowseInfoRow("Created", pr.createdAt.toLocalDate().toString()),
                )
            },
            kpis = { pr ->
                val levels = stockLevels.filter { it.productId == pr.id }
                val onHand = levels.sumOf { it.quantityOnHand }
                listOf(
                    BrowseKpi("On Hand", "${"%,.0f".format(onHand)} ${pr.unit}"),
                    BrowseKpi("Stock Value", "৳${"%,.0f".format(onHand * pr.defaultUnitPrice)}"),
                    BrowseKpi("Warehouses", "${levels.count { it.quantityOnHand > 0 }}"),
                )
            },
            // Graph = per-warehouse stock split (the product-shaped "where is it" view).
            hasGraph = true,
            slices = { pr ->
                stockLevels.filter { it.productId == pr.id && it.quantityOnHand > 0 }
                    .map { BrowseSlice(it.warehouseName, it.quantityOnHand * pr.defaultUnitPrice) }
            },
            // No hasLedger / has90Day: a product has no party ledger and no due — the
            // engine simply won't render those buttons.
            graphTitle = "Warehouse Wise Stock", // default title says "Sales" — this graph is a stock split, not sales
            qrEntityType = "Product",
        )
    }
}

// ── shared helpers used by the configs ─────────────────────────────────────────

/** Real party ledger → browse activities. One place, both DMS and RMS. */
@Composable
private fun rememberPartyActivities(partyType: PartyType, partyId: String): List<BrowseActivity> {
    val entries by remember(partyType, partyId) { MockRepository.partyLedgerFor(partyType, partyId) }
        .collectAsState(initial = emptyList())
    return remember(entries) {
        entries.map { e ->
            BrowseActivity(
                date = e.createdAt.toLocalDate(),
                title = e.reason,
                kind = if (e.type == "DEBIT") "Invoice/Memo" else "Collection/Return",
                amount = e.amount,
                isDebit = e.type == "DEBIT",
                balanceAfter = e.balanceAfter,
            )
        }
    }
}

@Composable
// v113-280 — the person's own direct complaint: this list looked
// informative but tapping a row did nothing at all — Invoice rows were
// built from a bare (invoiceNo, amount, date) Triple that never even
// carried the real id to navigate with, and Collection rows had real
// data (including the verification proof photo) sitting right there but
// no `clickable` modifier to reach it. Redesigned to take the real
// typed domain objects directly instead of a stripped-down Triple, so
// every row can open its own real detail: Invoice → the same real
// `invoice_doc/{id}` document view the rest of the app already uses;
// Memo → the same real `MemoDocumentBody` RmsMemoWorkspace's own
// "দেখুন" button already opens, in a local dialog (the `memo_doc/{id}`
// nav route exists in NavGraph.kt but is never actually navigated to
// anywhere in the app — checked directly rather than assumed reachable
// — so the proven local-dialog pattern was used instead of a route that
// would have gone nowhere); Collection → a new detail dialog showing the
// real amount/method/status and, specifically, the verification proof
// photo the person named directly ("verifying photo etc").
private fun PartyTransactionsTab(
    partyType: PartyType,
    partyId: String,
    invoiceDocs: List<com.abm.erp.data.SalesInvoice> = emptyList(),
    memoDocs: List<com.abm.erp.data.RetailOrder> = emptyList(),
    onNavigate: (String) -> Unit,
) {
    val collections by MockRepository.partyCollections.collectAsState()
    val myCollections = remember(collections, partyId) {
        collections.filter { it.partyType == partyType && it.partyId == partyId }.sortedByDescending { it.createdAt }
    }
    var viewingMemoId by remember { mutableStateOf<String?>(null) }
    var viewingCollectionId by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxWidth()) {
        Text("Transactions", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(8.dp))
        if (invoiceDocs.isEmpty() && memoDocs.isEmpty() && myCollections.isEmpty()) Text("কোনো লেনদেন নেই।", color = TextSecondary)
        invoiceDocs.take(15).forEach { inv ->
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { onNavigate("invoice_doc/${inv.id}") }) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(inv.invoiceNo, fontWeight = FontWeight.SemiBold, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                        Text(inv.createdAt.toLocalDate().toString(), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("৳${"%,.0f".format(inv.total)}", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        memoDocs.take(15).forEach { order ->
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { viewingMemoId = order.id }) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(order.orderNo, fontWeight = FontWeight.SemiBold, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                        Text(order.loggedAt.toLocalDate().toString(), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("৳${"%,.0f".format(order.amount)}", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        myCollections.take(15).forEach { c ->
            GlassCard(modifier = Modifier.fillMaxWidth().clickable { viewingCollectionId = c.id }) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(c.collectionNo.ifBlank { c.id.take(8) }, fontWeight = FontWeight.SemiBold, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                        Text("Collection · ${c.method} · ${c.createdAt.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("৳${"%,.0f".format(c.amount)}", fontWeight = FontWeight.Bold, color = SuccessGreen)
                        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    viewingMemoId?.let { id ->
        val order = memoDocs.firstOrNull { it.id == id }
        androidx.compose.ui.window.Dialog(onDismissRequest = { viewingMemoId = null }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                if (order == null) {
                    Column(Modifier.padding(16.dp)) { Text("এই Memo আর নেই।", color = TextSecondary) }
                } else {
                    Column(Modifier.heightIn(max = 640.dp).verticalScroll(rememberScrollState())) {
                        com.abm.erp.ui.memo.MemoDocumentBody(order = order)
                        TextButton(onClick = { viewingMemoId = null }, modifier = Modifier.fillMaxWidth().padding(12.dp)) { Text("← ফিরে যান") }
                    }
                }
            }
        }
    }

    viewingCollectionId?.let { id ->
        val c = myCollections.firstOrNull { it.id == id }
        androidx.compose.ui.window.Dialog(onDismissRequest = { viewingCollectionId = null }) {
            Surface(shape = RoundedCornerShape(16.dp)) {
                if (c == null) {
                    Column(Modifier.padding(16.dp)) { Text("এই Collection আর নেই।", color = TextSecondary) }
                } else {
                    Column(Modifier.padding(16.dp).heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
                        Text("Collection Detail", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Spacer(Modifier.height(10.dp))
                        listOf(
                            "Collection No" to c.collectionNo.ifBlank { c.id.take(8) },
                            "Amount" to "৳${"%,.0f".format(c.amount)}", "Method" to c.method,
                            "Status" to c.status, "Date" to "${c.createdAt}",
                        ).forEach { (label, value) ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Text(value, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.Medium)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        if (c.proofUri != null) {
                            Text("Verification Proof", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Spacer(Modifier.height(4.dp))
                            coil.compose.AsyncImage(
                                model = c.proofUri, contentDescription = "লেনদেনের প্রমাণ",
                                modifier = Modifier.height(220.dp).fillMaxWidth().clip(RoundedCornerShape(10.dp)),
                                contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                            )
                        } else {
                            Text("⚠ কোনো প্রমাণের ছবি সংযুক্ত করা হয়নি।", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                        }
                        Spacer(Modifier.height(12.dp))
                        TextButton(onClick = { viewingCollectionId = null }, modifier = Modifier.fillMaxWidth()) { Text("Close") }
                    }
                }
            }
        }
    }
}

// v113-249 — the person's own direct request: a Dealer Sales Report,
// same shape as the one already built for Territory/Area Overview
// (Today/7/30/90-day + Custom date range, product-wise breakdown) —
// reused directly rather than a third variant of the same idea, just
// scoped to this one dealer's own invoices instead of a whole area's.
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
private fun DealerSalesReportTab(dealer: Dealer) {
    val allInvoices by MockRepository.salesInvoices.collectAsState()
    val dealerInvoicesAllTime = remember(allInvoices, dealer.id) {
        allInvoices.filter { !it.isDeleted && it.dealerId == dealer.id }
    }

    var rangeMode by remember { mutableStateOf(1) } // 0=Today 1=7 Days 2=30 Days 3=90 Days 4=Custom
    var customFrom by remember { mutableStateOf<java.time.LocalDate?>(null) }
    var customTo by remember { mutableStateOf<java.time.LocalDate?>(null) }
    var pickerFor by remember { mutableStateOf<String?>(null) }

    val today = java.time.LocalDate.now()
    val (fromDate, toDate) = when (rangeMode) {
        0 -> today to today
        1 -> today.minusDays(6) to today
        2 -> today.minusDays(29) to today
        3 -> today.minusDays(89) to today
        else -> (customFrom ?: today.minusDays(6)) to (customTo ?: today)
    }

    val rangeInvoices = remember(dealerInvoicesAllTime, fromDate, toDate) {
        dealerInvoicesAllTime.filter { val d = it.createdAt.toLocalDate(); !d.isBefore(fromDate) && !d.isAfter(toDate) }
    }
    val rangeTotal = rangeInvoices.sumOf { it.total }

    data class ProductRow(val name: String, val qty: Int, val value: Double)
    val productSales = remember(rangeInvoices) {
        rangeInvoices.flatMap { it.lineItems }
            .groupBy { it.name }
            .map { (name, lines) -> ProductRow(name, lines.sumOf { it.qty }, lines.sumOf { it.lineTotal }) }
            .sortedByDescending { it.value }.take(10)
    }
    val productMax = productSales.maxOfOrNull { it.value } ?: 0.0

    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Today", "7 Days", "30 Days", "90 Days", "Custom").forEachIndexed { i, label ->
                FilterChip(
                    selected = rangeMode == i,
                    onClick = { rangeMode = i; if (i == 4 && customFrom == null) pickerFor = "from" },
                    label = { Text(label, fontSize = 11.sp) },
                )
            }
        }
        if (rangeMode == 4) {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.weight(1f)) {
                    com.abm.erp.core.SecondaryButton("From: ${customFrom ?: "—"}", onClick = { pickerFor = "from" }, icon = Icons.Filled.CalendarMonth)
                }
                Box(Modifier.weight(1f)) {
                    com.abm.erp.core.SecondaryButton("To: ${customTo ?: "—"}", onClick = { pickerFor = "to" }, icon = Icons.Filled.CalendarMonth)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("মোট বিক্রি (${rangeInvoices.size} invoice)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text("৳${"%,.0f".format(rangeTotal)}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = com.abm.erp.theme.DarazOrange)
        }
        Spacer(Modifier.height(12.dp))
        Text("Product-wise", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        if (productSales.isEmpty()) {
            Text("এই সময়ে কোনো বিক্রি নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        } else {
            productSales.forEach { p ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(p.name, fontSize = 12.sp, color = TextPrimary, maxLines = 1, modifier = Modifier.weight(1f))
                        Text("${p.qty} · ৳${"%,.0f".format(p.value)}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    }
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.fillMaxWidth().height(5.dp).background(HairlineBorder, androidx.compose.foundation.shape.RoundedCornerShape(999.dp))) {
                        Box(
                            Modifier.fillMaxWidth(if (productMax > 0) (p.value / productMax).toFloat().coerceIn(0f, 1f) else 0f)
                                .fillMaxHeight().background(com.abm.erp.theme.DarazOrange, androidx.compose.foundation.shape.RoundedCornerShape(999.dp)),
                        )
                    }
                }
            }
        }
    }

    if (pickerFor != null) {
        val state = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { pickerFor = null },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { ms ->
                        val picked = java.time.Instant.ofEpochMilli(ms).atZone(java.time.ZoneOffset.UTC).toLocalDate()
                        if (pickerFor == "from") customFrom = picked else customTo = picked
                        rangeMode = 4
                    }
                    pickerFor = null
                }) { Text("ঠিক আছে") }
            },
            dismissButton = { TextButton(onClick = { pickerFor = null }) { Text("বাতিল") } },
        ) { DatePicker(state = state) }
    }
}
