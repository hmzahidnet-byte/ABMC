package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.Bn
import com.mohona.erp.data.demo.DemoRepository
import com.mohona.erp.domain.AccessPolicy
import com.mohona.erp.domain.RecordRef
import com.mohona.erp.domain.RecordStatus
import com.mohona.erp.domain.RecordType
import com.mohona.erp.domain.UserContext
import com.mohona.erp.domain.WingRegistry
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.BarChart
import com.mohona.erp.ui.components.BarSeries
import com.mohona.erp.ui.components.BnDate
import com.mohona.erp.ui.components.ChartCard
import com.mohona.erp.ui.components.DonutChart
import com.mohona.erp.ui.components.DonutPart
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.ImageHolder
import com.mohona.erp.ui.components.LineChart
import com.mohona.erp.ui.components.PreviewBadge
import com.mohona.erp.ui.components.PreviewBanner
import com.mohona.erp.ui.components.RelatedTile
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.SectionTitle
import com.mohona.erp.ui.components.UniversalCalendar
import com.mohona.erp.ui.components.iconForKey
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.ChartBlue
import com.mohona.erp.ui.theme.ChartTeal
import com.mohona.erp.ui.theme.OrangeDark
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.OrangeSoft
import com.mohona.erp.ui.theme.TextMuted
import java.math.BigDecimal
import java.math.RoundingMode

private fun UserContext.canSee(t: RecordType): Boolean =
    roles.any { it in AccessPolicy.rolesFor(t) } || ("EMPLOYEE_SELF" in roles && t in setOf(RecordType.EMPLOYEE, RecordType.ATTENDANCE_MONTH, RecordType.PAYROLL_MONTH))

/** Level 2: the Manufacturing Wing dashboard. Every number is computed from the demo repository (never hard-coded) for the selected date range. */
@Composable
fun WingDashboardScreen(
    wingId: String, ctx: UserContext, onBack: () -> Unit, onOpenModule: (String, String) -> Unit, onOpenList: (RecordType) -> Unit,
    onOpenRecord: (RecordRef) -> Unit, onSearch: () -> Unit, onNotifications: () -> Unit, onApprovals: () -> Unit, onReports: () -> Unit
) {
    val wing = WingRegistry.wing(wingId)
    if (wing == null) { EmptyState("এই উইং পাওয়া যায়নি।"); return }
    var filter by remember { mutableStateOf(BnDate.monthOf(DemoRepository.demoDate)) }
    var showCalendar by remember { mutableStateOf(false) }
    val kpis = DemoRepository.productKpis(filter.start, filter.end, ctx)
    val batches = DemoRepository.batchesInRange(filter.start, filter.end)
    val pending = DemoRepository.pendingApprovals(ctx)
    val activity = DemoRepository.productionDates()

    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
        Box(modifier = Modifier.background(Color.White)) {
            ScreenHeader(title = wing.nameBn, onBack = onBack, trailing = {
                IconButton(onClick = onSearch) { Icon(Icons.Filled.Search, contentDescription = "অনুসন্ধান", tint = OrangeDark) }
                IconButton(onClick = onNotifications) { Icon(Icons.Filled.Notifications, contentDescription = "বিজ্ঞপ্তি", tint = OrangeDark) }
            })
        }
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            PreviewBanner("ডেমো-ড্যাশবোর্ড: সব সংখ্যা নির্বাচিত তারিখ-পরিসরে ডেমো-তথ্য থেকে গণনা করা; ব্যাকএন্ড সংযুক্ত নয়, কিছুই সংরক্ষিত হয় না।")

            // date filter + universal calendar
            AppCard {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.CalendarMonth, contentDescription = null, tint = OrangePrimary)
                        Spacer(Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("তারিখ-পরিসর", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Text(BnDate.formatFilter(filter), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        }
                        OutlinedButton(onClick = { showCalendar = !showCalendar }) { Text(if (showCalendar) "বন্ধ" else "ক্যালেন্ডার") }
                    }
                    if (showCalendar) {
                        Spacer(Modifier.height(10.dp))
                        UniversalCalendar(filter, activity, { filter = it }, summaryText = Bn.digits(batches.size.toString()) + "টি ব্যাচ এই পরিসরে")
                    }
                }
            }

            // product image KPI (first six, then "view all"; zero-production products stay in the list)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("পণ্য — উৎপাদন (Poly)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text("সব পণ্য দেখুন", style = MaterialTheme.typography.labelLarge, color = OrangePrimary, modifier = Modifier.clickable { onOpenList(RecordType.PRODUCT) }.padding(6.dp))
            }
            if (kpis.isEmpty()) EmptyState("এই ভূমিকার জন্য কোনো পণ্য দেখানোর অনুমতি নেই।")
            kpis.take(6).chunked(2).forEach { pair ->
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Max), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { k ->
                        AppCard(modifier = Modifier.weight(1f).fillMaxHeight(), onClick = { onOpenRecord(k.product.ref) }) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                ImageHolder(k.product.imageTone, k.product.title, 56.dp)
                                Spacer(Modifier.height(8.dp))
                                Text(k.product.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(k.product.reference, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Spacer(Modifier.height(6.dp))
                                Text(Bn.num(k.producedPoly.toLong()) + " Poly", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = OrangeDark)
                                Text("ব্যাচ " + Bn.digits(k.batchCount.toString()) + "টি • মজুত " + Bn.num(k.fgAvailablePoly.toLong()) + " Poly", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                if (k.producedPoly == 0) Text("এই পরিসরে উৎপাদন নেই", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            }
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }

            // summary tiles (only what this role may see)
            val tiles = ArrayList<Triple<String, String, String>>()
            val produced = batches.sumOf { it.produced }
            tiles.add(Triple("উৎপাদিত (পরিসরে)", Bn.num(produced.toLong()) + " Poly", "production"))
            tiles.add(Triple("চলমান ব্যাচ", Bn.digits(DemoRepository.facts.batches.count { it.status == "IN_PROGRESS" }.toString()) + "টি", "production"))
            val hold = DemoRepository.facts.batches.filter { it.qc == "HOLD" }.sumOf { it.produced }
            tiles.add(Triple("QC হোল্ড", Bn.num(hold.toLong()) + " Poly", "qc_fg"))
            tiles.add(Triple("তৈরি পণ্য (উপলব্ধ)", Bn.num(kpis.sumOf { it.fgAvailablePoly }.toLong()) + " Poly", "qc_fg"))
            if (ctx.canSee(RecordType.RAW_MATERIAL)) {
                val stockValue = DemoRepository.materialPositions().values.fold(BigDecimal.ZERO) { a, p -> a.add(p.value) }
                tiles.add(Triple("কাঁচামাল মজুত-মূল্য", Bn.taka(stockValue.setScale(0, RoundingMode.HALF_UP).toLong()), "materials"))
            }
            if (ctx.canSee(RecordType.SUPPLIER)) tiles.add(Triple("সরবরাহকারী বকেয়া", Bn.taka(DemoRepository.totalSupplierDue().setScale(0, RoundingMode.HALF_UP).toLong()), "purchase"))
            if (ctx.canSee(RecordType.EMPLOYEE)) tiles.add(Triple("কর্মী", Bn.digits(DemoRepository.list(RecordType.EMPLOYEE, ctx).size.toString()) + " জন", "hr"))
            if (ctx.canSee(RecordType.MACHINE)) tiles.add(Triple("মেশিন / রক্ষণাবেক্ষণ অপেক্ষমাণ", Bn.digits(DemoRepository.list(RecordType.MACHINE, ctx).size.toString()) + " / " + Bn.digits(DemoRepository.list(RecordType.MAINTENANCE, ctx).count { DemoRepository.statusOf(it) == RecordStatus.PENDING }.toString()), "maintenance"))
            SectionTitle("এক নজরে")
            tiles.chunked(2).forEach { pair ->
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Max), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { t ->
                        AppCard(modifier = Modifier.weight(1f).fillMaxHeight(), onClick = { onOpenModule(wing.id, t.third) }) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(t.first, style = MaterialTheme.typography.labelMedium, color = TextMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(4.dp))
                                Text(t.second, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 2)
                            }
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }

            // analytics from the same data
            SectionTitle("উৎপাদন ও খরচ-বিশ্লেষণ")
            val byDate = DemoRepository.producedByDate(filter.start, filter.end).filter { it.second > 0 }
            if (byDate.isEmpty()) EmptyState("এই তারিখ-পরিসরে কোনো উৎপাদন নেই।")
            else ChartCard("দৈনিক উৎপাদন", "নির্বাচিত পরিসর (Poly)") {
                LineChart(byDate.map { Bn.digits(it.first.dayOfMonth.toString()) }, byDate.map { it.second.toDouble() }, "Poly")
            }
            val producedProducts = kpis.filter { it.producedPoly > 0 }
            if (producedProducts.isNotEmpty()) ChartCard("পণ্যভিত্তিক উৎপাদন", "নির্বাচিত পরিসর (Poly)") {
                BarChart(producedProducts.map { it.product.title.removePrefix("ইনস্ট্যান্ট ").take(9) }, listOf(BarSeries("উৎপাদন", producedProducts.map { it.producedPoly.toDouble() }, OrangePrimary)), "Poly")
            }
            if (ctx.canSee(RecordType.RAW_MATERIAL)) {
                val parts = DemoRepository.materialPositions().entries.sortedBy { it.key }.map { DonutPart(DemoRepository.facts.materialNames[it.key] ?: it.key, it.value.value.toDouble() / 1000.0, listOf(OrangePrimary, ChartBlue, ChartTeal, Color(0xFFE8A317))[(it.key.takeLast(1).toIntOrNull() ?: 1) % 4]) }
                ChartCard("কাঁচামাল মজুত-মূল্য", "চলমান ভারযুক্ত গড়, হাজার টাকা (ডেমো-গণনা)") {
                    DonutChart(parts, Bn.dec(parts.sumOf { it.value }, 0), "হাজার টাকা", "হাজার")
                }
            }
            val cost = DemoRepository.facts.batches.filter { it.accepted > 0 }.map { b ->
                val c = com.mohona.erp.domain.Costing.consumedCost(b.consumed, b.id, DemoRepository.costingResult.issueUnitCost)
                Pair(b.id, com.mohona.erp.domain.Costing.materialCostPerPoly(c, BigDecimal(b.accepted)))
            }.filter { it.second != null }
            if (cost.isNotEmpty()) ChartCard("উপাদান-খরচ প্রতি Poly (আংশিক)", "শ্রম, বিদ্যুৎ, মেশিন, ওভারহেড অন্তর্ভুক্ত নয়; পূর্ণ খরচ বা লাভ নয়") {
                BarChart(cost.map { it.first }, listOf(BarSeries("টাকা/Poly", cost.map { it.second!!.toDouble() }, ChartBlue)), "টাকা")
            }

            // alerts and pending approvals
            SectionTitle("সতর্কতা ও অনুমোদন")
            AppCard(onClick = onApprovals) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("অনুমোদনের অপেক্ষায়: " + Bn.digits(pending.size.toString()) + "টি", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text("অনুমোদন-কেন্দ্র খুলুন", style = MaterialTheme.typography.labelMedium, color = OrangePrimary)
                }
            }
            pending.take(3).forEach { RelatedTile(it, it.ref, ctx, onOpenRecord) }
            DemoRepository.list(RecordType.QC_RECORD, ctx).filter { DemoRepository.statusOf(it) == RecordStatus.HOLD }.forEach { RelatedTile(it, it.ref, ctx, onOpenRecord) }

            // modules
            SectionTitle("মডিউল")
            wing.modules.filter { WingRegistry.moduleVisibleFor(it, ctx) }.chunked(2).forEach { pair ->
                Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Max), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { m ->
                        AppCard(modifier = Modifier.weight(1f).fillMaxHeight(), onClick = { onOpenModule(wing.id, m.id) }) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Box(modifier = Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(OrangeSoft), contentAlignment = Alignment.Center) { Icon(iconForKey(m.iconKey), contentDescription = null, tint = OrangePrimary) }
                                Spacer(Modifier.height(8.dp))
                                Text(m.nameBn, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(m.descBn, style = MaterialTheme.typography.labelSmall, color = TextMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onApprovals) { Text("অনুমোদন-কেন্দ্র") }
                OutlinedButton(onClick = onReports) { Text("রিপোর্ট-কেন্দ্র") }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
