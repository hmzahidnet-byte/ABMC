package com.mohona.erp.domain

/** A module is a group of record types plus honest "planned" entries. Adding a wing = adding one WingSpec; navigation and screens are generic. */
data class ModuleSpec(
    val id: String,
    val nameBn: String,
    val descBn: String,
    val iconKey: String,
    val types: List<RecordType>,
    val planned: List<String> = emptyList()
)

data class WingSpec(val id: String, val nameBn: String, val descBn: String, val iconKey: String, val modules: List<ModuleSpec>)

object WingRegistry {
    val manufacturing = WingSpec(
        id = "mfg",
        nameBn = "উইং ১ — উৎপাদন",
        descBn = "কাঁচামাল থেকে তৈরি পণ্য পর্যন্ত ফ্যাক্টরির কাজ",
        iconKey = "factory",
        modules = listOf(
            ModuleSpec("products", "পণ্য ও রেসিপি", "পণ্য, BOM-সংস্করণ", "shopping", listOf(RecordType.PRODUCT, RecordType.BOM), listOf("পণ্যভিত্তিক Poly-রূপান্তর অনুমোদন (Pending)", "পণ্য-ছবি আপলোড (ব্যাকএন্ড-নির্ভর)")),
            ModuleSpec("materials", "কাঁচামাল", "কাঁচামাল, ফয়েল ও প্যাকেজিং", "inventory", listOf(RecordType.RAW_MATERIAL), listOf("ফিজিক্যাল স্টক যাচাই")),
            ModuleSpec("purchase", "ক্রয় ও সরবরাহকারী", "সরবরাহকারী, ক্রয় আদেশ, GRN, পরিশোধ", "receipt", listOf(RecordType.SUPPLIER, RecordType.PURCHASE_ORDER, RecordType.GRN, RecordType.PAYMENT_VOUCHER, RecordType.SUPPLIER_LEDGER), listOf("ক্রয়-ইনভয়েস", "ক্রয়-ফেরত", "সরবরাহকারীর কার্যকারিতা-বিশ্লেষণ")),
            ModuleSpec("production", "উৎপাদন", "ব্যাচ, মালামাল ইস্যু, প্রকৃত ব্যবহার", "factory", listOf(RecordType.BATCH, RecordType.MATERIAL_ISSUE, RecordType.CONSUMPTION), listOf("দৈনিক উৎপাদন-পরিকল্পনা (Production Plan)", "অপচয় ও ক্ষতি-বিশ্লেষণ")),
            ModuleSpec("qc_fg", "কিউসি ও তৈরি পণ্য", "পরীক্ষা, রিলিজ, তৈরি পণ্য গ্রহণ", "science", listOf(RecordType.QC_RECORD, RecordType.FG_RECEIPT), listOf("বাজার-ফেরত পুনঃপ্যাকেজিং")),
            ModuleSpec("costing", "খরচ", "ব্যাচ-খরচ (শুধু উপাদান-খরচ)", "trend", listOf(RecordType.BATCH_COST), listOf("শ্রম, বিদ্যুৎ, মেশিন ও ওভারহেড বণ্টন (নীতি Pending)")),
            ModuleSpec("warehouse", "গুদাম ও স্টক", "গুদাম, স্টক-চলাচল", "storage", listOf(RecordType.WAREHOUSE, RecordType.STOCK_MOVEMENT), listOf("স্টক-স্থানান্তর", "স্টক-সমন্বয় ও যাচাই")),
            ModuleSpec("hr", "ফ্যাক্টরি এইচআর", "কর্মী, উপস্থিতি, বেতন", "people", listOf(RecordType.EMPLOYEE, RecordType.ATTENDANCE_MONTH, RecordType.ATTENDANCE_DAY, RecordType.ATTENDANCE_EVENT, RecordType.PAYROLL_MONTH, RecordType.PAYSLIP), listOf("ছুটি", "শিফট-রোস্টার", "অগ্রিম/ঋণ", "পদোন্নতি/বদলি/সাসপেনশন ফর্ম")),
            ModuleSpec("maintenance", "মেশিন ও রক্ষণাবেক্ষণ", "মেশিন, রক্ষণাবেক্ষণ, ব্রেকডাউন, স্পেয়ার পার্টস", "build", listOf(RecordType.MACHINE, RecordType.MAINTENANCE, RecordType.BREAKDOWN, RecordType.SPARE_PART), listOf("স্পেয়ার পার্টস ক্রয়")),
            ModuleSpec("finance", "কারখানার অর্থ", "ব্যয়, ফ্যাক্টরি লাভ-ক্ষতি (শুধু এমডি)", "payments", listOf(RecordType.EXPENSE, RecordType.FACTORY_PNL), listOf("ব্যয়-ক্যাটাগরি ও কস্ট-সেন্টার", "নগদ/ব্যাংক রেকর্ড"))
        )
    )
    val wings: List<WingSpec> = listOf(manufacturing)

    fun wing(id: String): WingSpec? = wings.firstOrNull { it.id == id }
    fun module(wingId: String, moduleId: String): ModuleSpec? = wing(wingId)?.modules?.firstOrNull { it.id == moduleId }

    /** Records of the demo that a module offers; used for visibility (a module appears only if the user may open at least one of its types). */
    fun moduleVisibleFor(m: ModuleSpec, ctx: UserContext): Boolean =
        m.types.any { t -> ctx.roles.any { it in AccessPolicy.rolesFor(t) } || ("EMPLOYEE_SELF" in ctx.roles && t in selfTypes) }

    fun wingVisibleFor(w: WingSpec, ctx: UserContext): Boolean = w.modules.any { moduleVisibleFor(it, ctx) }

    private val selfTypes = setOf(RecordType.EMPLOYEE, RecordType.ATTENDANCE_MONTH, RecordType.PAYROLL_MONTH, RecordType.PAYSLIP)
}
