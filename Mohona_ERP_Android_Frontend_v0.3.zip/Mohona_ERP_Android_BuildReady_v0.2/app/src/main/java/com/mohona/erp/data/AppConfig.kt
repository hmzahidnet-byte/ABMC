package com.mohona.erp.data

import android.util.Base64
import com.mohona.erp.BuildConfig

/** Supabase connection settings (Connected Development mode). Only the PUBLIC anon/publishable key may be used. */
object AppConfig {
    val supabaseUrl: String = BuildConfig.SUPABASE_URL.trim().trimEnd('/')
    val anonKey: String = BuildConfig.SUPABASE_ANON_KEY.trim()

    val keyLooksPrivileged: Boolean
        get() {
            if (anonKey.startsWith("sb_secret_")) return true
            return try {
                val parts = anonKey.split(".")
                if (parts.size < 2) {
                    false
                } else {
                    val payload = String(Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP))
                    payload.contains("service_role")
                }
            } catch (e: Exception) {
                false
            }
        }

    val connectedConfigured: Boolean
        get() = supabaseUrl.startsWith("https://") && anonKey.isNotEmpty() && !keyLooksPrivileged

    val configProblem: String?
        get() = when {
            supabaseUrl.isEmpty() && anonKey.isEmpty() -> "সংযুক্ত মোড কনফিগার করা নেই। (প্রশাসক/ডেভেলপার local.properties-এ SUPABASE_URL ও SUPABASE_ANON_KEY দেবেন।)"
            keyLooksPrivileged -> "গোপন (service_role/secret) কী পাওয়া গেছে। নিরাপত্তার জন্য এটি ব্যবহার করা হবে না; শুধু anon/publishable কী দিন।"
            !supabaseUrl.startsWith("https://") -> "SUPABASE_URL অবশ্যই https:// দিয়ে শুরু হতে হবে।"
            anonKey.isEmpty() -> "SUPABASE_ANON_KEY দেওয়া হয়নি।"
            else -> null
        }
}
