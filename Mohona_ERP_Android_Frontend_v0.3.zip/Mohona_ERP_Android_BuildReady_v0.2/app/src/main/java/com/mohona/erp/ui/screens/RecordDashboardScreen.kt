package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.demo.DemoRepository
import com.mohona.erp.domain.Access
import com.mohona.erp.domain.AccessPolicy
import com.mohona.erp.domain.ActionPolicy
import com.mohona.erp.domain.DemoRecord
import com.mohona.erp.domain.RecordKind
import com.mohona.erp.domain.RecordRef
import com.mohona.erp.domain.RecordStatus
import com.mohona.erp.domain.RecordType
import com.mohona.erp.domain.UserContext
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.ImageHolder
import com.mohona.erp.ui.components.InfoRows
import com.mohona.erp.ui.components.KpiRow
import com.mohona.erp.ui.components.LineItemsSection
import com.mohona.erp.ui.components.PermissionDeniedState
import com.mohona.erp.ui.components.PreviewBadge
import com.mohona.erp.ui.components.PreviewBanner
import com.mohona.erp.ui.components.PrimaryActionRow
import com.mohona.erp.ui.components.QrDemoImage
import com.mohona.erp.ui.components.RecordMenu
import com.mohona.erp.ui.components.RelatedGroupsSection
import com.mohona.erp.ui.components.RelatedTile
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.SectionCard
import com.mohona.erp.ui.components.StatusBadge
import com.mohona.erp.ui.components.TimelineView
import com.mohona.erp.ui.components.rememberActionController
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.OrangeDark
import com.mohona.erp.ui.theme.OrangeSoft
import com.mohona.erp.ui.theme.TextMuted

/**
 * Levels 5-7: THE canonical dashboard for every record type (entity, transaction or event). Employee, Product, Batch, Purchase, Voucher, Stock
 * Movement, Machine, QC… all open this one screen; only the data decides which sections appear. Linked records open the same screen again,
 * so a user can walk Purchase → GRN → Stock → Issue → Batch without returning home.
 */
@Composable
fun RecordDashboardScreen(ref: RecordRef, ctx: UserContext, onBack: () -> Unit, onOpen: (RecordRef) -> Unit, onShowQr: (RecordRef) -> Unit) {
    val rec = DemoRepository.get(ref)
    var showAudit by remember(ref) { mutableStateOf(false) }
    val controller = rememberActionController(ctx, onShowQr) { r -> if (r == ref) showAudit = true else onOpen(r) }

    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
        if (rec == null) {
            Box(modifier = Modifier.background(Color.White)) { ScreenHeader(title = "রেকর্ড", onBack = onBack) }
            EmptyState("এই রেকর্ডটি পাওয়া যায়নি (অবৈধ বা মুছে-যাওয়া সংযোগ)।")
            return@Column
        }
        val access = AccessPolicy.canOpen(rec, ctx)
        if (access != Access.ALLOWED) {
            Box(modifier = Modifier.background(Color.White)) { ScreenHeader(title = ref.type.nameBn, onBack = onBack) }
            PermissionDeniedState(
                if (access == Access.WRONG_COMPANY) "এই রেকর্ড অন্য কোম্পানির (" + DemoRepository.companyName(rec.companyId) + ")। এক কোম্পানির লগইনে অন্য কোম্পানির ডেটা খোলে না।"
                else "এই ভূমিকার জন্য এই ধরনের রেকর্ড খোলার অনুমতি নেই।"
            )
            return@Column
        }
        val status = DemoRepository.statusOf(rec)
        val actions = ActionPolicy.actionsFor(rec, status, ctx)
        Box(modifier = Modifier.background(Color.White)) {
            ScreenHeader(title = rec.ref.type.nameBn, onBack = onBack, trailing = { RecordMenu(rec, actions, controller) })
        }
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            HeaderCard(rec, status)
            if (rec.note.isNotEmpty()) PreviewBanner(rec.note)
            CorrectionLinks(rec, ctx, onOpen)
            PrimaryActionRow(rec, actions, controller)
            KpiRow(rec.kpis)
            if (rec.info.isNotEmpty()) SectionCard("তথ্য") { InfoRows(rec.info) }
            if (rec.lines.isNotEmpty()) SectionCard(if (rec.ref.type.kind == RecordKind.TRANSACTION) "আইটেম-ভিত্তিক বিবরণ" else "উপাদান/লাইন") { LineItemsSection(rec.lines, rec.totals, ctx, onOpen) }
            if (rec.sensitive.isNotEmpty()) {
                SectionCard("সংবেদনশীল তথ্য", trailing = "প্রদর্শন-ইঙ্গিত") {
                    if (AccessPolicy.canSeeSensitive(rec, ctx)) InfoRows(rec.sensitive)
                    else PermissionDeniedState("বেতন ও ব্যক্তিগত তথ্য শুধু অনুমোদিত ভূমিকা (বা নিজ কর্মী) দেখতে পারেন।")
                }
            }
            SectionCard("সংযুক্ত রেকর্ড", trailing = "ট্যাপ করে খুলুন") { RelatedGroupsSection(rec.related, ctx, onOpen) }
            if (rec.ref.type.hasQr && rec.qrToken != null) QrSection(rec)
            if (rec.ref.type.kind == RecordKind.TRANSACTION) {
                SectionCard("অনুমোদন-টাইমলাইন") { TimelineView(DemoRepository.approvalOf(rec), "এই রেকর্ডে এখনো কোনো অনুমোদন-ধাপ নেই।") }
            }
            SectionCard("কার্যক্রম-ইতিহাস") { TimelineView(DemoRepository.historyOf(rec), "এখনো কোনো ইতিহাস নেই।") }
            if (showAudit) {
                SectionCard("অডিট-ইতিহাস", trailing = "ডেমো") {
                    if (AccessPolicy.canSeeAudit(ctx)) {
                        TimelineView(DemoRepository.historyOf(rec) + DemoRepository.approvalOf(rec), "অডিট-ঘটনা নেই।")
                        Text("আসল অডিট-চেইন ও হ্যাশ-যাচাই ব্যাকএন্ডে; এটি ডেমো-দৃশ্য।", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    } else PermissionDeniedState("অডিট-ইতিহাস দেখার অনুমতি নেই।")
                }
            }
            Text("কোম্পানি: " + DemoRepository.companyName(rec.companyId) + " • রেকর্ড: " + rec.ref.type.nameBn + " " + rec.ref.id, style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Spacer(Modifier.height(24.dp))
        }
    }
    controller.Dialogs()
}

@Composable
private fun HeaderCard(rec: DemoRecord, status: RecordStatus) {
    AppCard {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ImageHolder(rec.imageTone, rec.title, 64.dp)
                Spacer(Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(rec.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    if (rec.subtitle.isNotEmpty()) Text(rec.subtitle, style = MaterialTheme.typography.bodySmall, color = TextMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusBadge(status)
                Spacer(Modifier.width(8.dp))
                PreviewBadge("ডেমো")
            }
            Spacer(Modifier.height(8.dp))
            Text("রেফারেন্স: " + rec.reference + (if (rec.dateIso.isNotEmpty()) " • তারিখ: " + com.mohona.erp.data.Bn.digits(rec.dateIso) else ""), style = MaterialTheme.typography.labelMedium, color = TextMuted)
            Text(DemoRepository.companyName(rec.companyId), style = MaterialTheme.typography.labelMedium, color = OrangeDark)
        }
    }
}

/** Original -> Reversal -> Replacement traceability for corrected posted records. */
@Composable
private fun CorrectionLinks(rec: DemoRecord, ctx: UserContext, onOpen: (RecordRef) -> Unit) {
    val reversals = DemoRepository.allRecords.filter { it.reversalOf == rec.ref }
    val replacements = DemoRepository.allRecords.filter { it.replacementOf == rec.ref }
    if (rec.reversalOf == null && rec.replacementOf == null && reversals.isEmpty() && replacements.isEmpty()) return
    SectionCard("সংশোধন-সূত্র (মূল → Reversal → Replacement)") {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            rec.reversalOf?.let { o -> Text("এটি Reversal; মূল রেকর্ড:", style = MaterialTheme.typography.labelMedium); RelatedTile(DemoRepository.get(o), o, ctx, onOpen) }
            rec.replacementOf?.let { o -> Text("এটি Replacement; মূল রেকর্ড:", style = MaterialTheme.typography.labelMedium); RelatedTile(DemoRepository.get(o), o, ctx, onOpen) }
            if (reversals.isNotEmpty()) Text("বাতিল-সমন্বয় (Reversal):", style = MaterialTheme.typography.labelMedium)
            reversals.forEach { RelatedTile(it, it.ref, ctx, onOpen) }
            if (replacements.isNotEmpty()) Text("প্রতিস্থাপন (Replacement):", style = MaterialTheme.typography.labelMedium)
            replacements.forEach { RelatedTile(it, it.ref, ctx, onOpen) }
            Text("পোস্টকৃত রেকর্ড সরাসরি বদলানো বা মোছা যায় না; ভুল সংশোধন হয় Reversal + আলাদা-অনুমোদিত Replacement দিয়ে।", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        }
    }
}

@Composable
private fun QrSection(rec: DemoRecord) {
    SectionCard("QR ও পরিচয়", trailing = "ডেমো") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            QrDemoImage(rec.qrToken ?: rec.ref.id, 110.dp)
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("স্থায়ী অভ্যন্তরীণ আইডি: " + rec.ref.id, style = MaterialTheme.typography.labelMedium)
                Text("ব্যবসায়িক রেফারেন্স: " + rec.reference, style = MaterialTheme.typography.labelMedium)
                Text("QR-টোকেন: " + (rec.qrToken ?: "—"), style = MaterialTheme.typography.labelMedium)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text("QR-টোকেন স্থায়ী ডেটাবেস-আইডি নয়। স্ক্যান করলেই তথ্য খোলে না: সার্ভার অনুমতি যাচাই করবে। ছবিটি ডেমো, আসল স্ক্যানযোগ্য নয়।", style = MaterialTheme.typography.labelSmall, color = TextMuted)
    }
}
