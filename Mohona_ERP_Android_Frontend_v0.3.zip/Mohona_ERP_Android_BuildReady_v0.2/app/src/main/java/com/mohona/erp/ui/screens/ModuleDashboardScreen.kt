package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.Bn
import com.mohona.erp.data.demo.DemoRepository
import com.mohona.erp.domain.AccessPolicy
import com.mohona.erp.domain.Kpi
import com.mohona.erp.domain.RecordRef
import com.mohona.erp.domain.RecordType
import com.mohona.erp.domain.UserContext
import com.mohona.erp.domain.WingRegistry
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.KpiRow
import com.mohona.erp.ui.components.PreviewBanner
import com.mohona.erp.ui.components.RelatedTile
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.SectionCard
import com.mohona.erp.ui.components.StatusPill
import com.mohona.erp.ui.components.Tone
import com.mohona.erp.ui.components.iconForKey
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.OrangeSoft
import com.mohona.erp.ui.theme.TextMuted

/** Level 3: one module of a wing: counts, links into each record list, latest records, and honestly-labelled planned features. */
@Composable
fun ModuleDashboardScreen(wingId: String, moduleId: String, ctx: UserContext, onBack: () -> Unit, onOpenList: (RecordType) -> Unit, onOpenRecord: (RecordRef) -> Unit) {
    val module = WingRegistry.module(wingId, moduleId)
    if (module == null) {
        Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
            Box(modifier = Modifier.background(Color.White)) { ScreenHeader(title = "মডিউল", onBack = onBack) }
            EmptyState("এই মডিউল পাওয়া যায়নি।")
        }
        return
    }
    val types = module.types.filter { t -> ctx.roles.any { it in AccessPolicy.rolesFor(t) } || ("EMPLOYEE_SELF" in ctx.roles && t in setOf(RecordType.EMPLOYEE, RecordType.ATTENDANCE_MONTH, RecordType.PAYROLL_MONTH, RecordType.PAYSLIP)) }
    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
        Box(modifier = Modifier.background(Color.White)) { ScreenHeader(title = module.nameBn, onBack = onBack) }
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            PreviewBanner(module.descBn + " • ডেমো-তথ্য; ব্যাকএন্ড সংযুক্ত নয়")
            if (types.isEmpty()) EmptyState("এই ভূমিকার জন্য এই মডিউলে দেখানোর মতো কিছু নেই।")
            KpiRow(types.map { t -> Kpi(t.nameBn, Bn.digits(DemoRepository.list(t, ctx).size.toString()) + "টি") })
            types.forEach { t ->
                val items = DemoRepository.list(t, ctx)
                AppCard(onClick = { onOpenList(t) }) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(OrangeSoft), contentAlignment = Alignment.Center) { Icon(iconForKey(module.iconKey), contentDescription = null, tint = OrangePrimary) }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(t.pluralBn, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text(Bn.digits(items.size.toString()) + "টি রেকর্ড", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = TextMuted)
                    }
                }
            }
            val firstType = types.firstOrNull()
            if (firstType != null) {
                val latest = DemoRepository.list(firstType, ctx).sortedByDescending { it.dateIso }.take(3)
                if (latest.isNotEmpty()) SectionCard("সাম্প্রতিক " + firstType.nameBn) { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { latest.forEach { RelatedTile(it, it.ref, ctx, onOpenRecord) } } }
            }
            if (module.planned.isNotEmpty()) {
                SectionCard("পরিকল্পিত (এখনো তৈরি হয়নি)") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        module.planned.forEach { p ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                StatusPill("পরিকল্পিত", Tone.NEUTRAL)
                                Spacer(Modifier.width(8.dp))
                                Text(p, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
