package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.Bn
import com.mohona.erp.data.demo.DemoRepository
import com.mohona.erp.domain.AccessPolicy
import com.mohona.erp.domain.Costing
import com.mohona.erp.domain.RecordRef
import com.mohona.erp.domain.RecordType
import com.mohona.erp.domain.UserContext
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.BnDate
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.Hairline
import com.mohona.erp.ui.components.MenuAction
import com.mohona.erp.ui.components.PermissionDeniedState
import com.mohona.erp.ui.components.PreviewBanner
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.SearchField
import com.mohona.erp.ui.components.SectionTitle
import com.mohona.erp.ui.components.StatusPill
import com.mohona.erp.ui.components.Tone
import com.mohona.erp.ui.components.UniversalActionMenu
import com.mohona.erp.ui.components.UniversalCalendar
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.OrangeDark
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.TextMuted
import java.math.BigDecimal
import java.math.RoundingMode

class ReportRow(val cells: List<String>, val ref: RecordRef?)

/** A report = permission type + columns + a row builder over the demo repository. Export/print are listed as planned, never faked. */
class ReportDef(
    val id: String, val nameBn: String, val descBn: String, val gateType: RecordType, val dated: Boolean, val columns: List<String>,
    val build: (com.mohona.erp.ui.components.DateFilter, UserContext) -> List<ReportRow>
)

object Reports {
    private fun kpi(r: com.mohona.erp.domain.DemoRecord, label: String): String = r.kpis.firstOrNull { it.label == label }?.value ?: "—"

    val all: List<ReportDef> = listOf(
        ReportDef("daily_production", "দৈনিক উৎপাদন", "তারিখ অনুযায়ী ব্যাচ-উৎপাদন", RecordType.BATCH, true, listOf("তারিখ", "ব্যাচ", "পণ্য", "উৎপাদিত", "গৃহীত")) { f, ctx ->
            DemoRepository.batchesInRange(f.start, f.end).sortedBy { it.date }.mapNotNull { b ->
                val rec = DemoRepository.get(RecordRef(RecordType.BATCH, b.id)) ?: return@mapNotNull null
                if (rec.companyId !in ctx.companyIds) null else ReportRow(listOf(BnDate.format(b.date), b.id, DemoRepository.get(RecordRef(RecordType.PRODUCT, b.productId))?.title ?: b.productId, Bn.num(b.produced.toLong()), Bn.num(b.accepted.toLong())), rec.ref)
            }
        },
        ReportDef("product_production", "পণ্যভিত্তিক উৎপাদন", "প্রতিটি পণ্যের উৎপাদন (শূন্য-উৎপাদনও দেখানো হয়)", RecordType.PRODUCT, true, listOf("পণ্য", "উৎপাদিত Poly", "ব্যাচ", "মজুত Poly")) { f, ctx ->
            DemoRepository.productKpis(f.start, f.end, ctx).map { ReportRow(listOf(it.product.title, Bn.num(it.producedPoly.toLong()), Bn.digits(it.batchCount.toString()), Bn.num(it.fgAvailablePoly.toLong())), it.product.ref) }
        },
        ReportDef("batch_wise", "ব্যাচভিত্তিক উৎপাদন", "ব্যাচের অবস্থা ও পরিমাণ", RecordType.BATCH, true, listOf("ব্যাচ", "পরিকল্পিত", "উৎপাদিত", "অবস্থা")) { f, ctx ->
            DemoRepository.list(RecordType.BATCH, ctx).filter { r -> r.date?.let { f.contains(it) } ?: false }.map { r ->
                val fact = DemoRepository.facts.batches.firstOrNull { it.id == r.ref.id }
                ReportRow(listOf(r.ref.id, Bn.num((fact?.planned ?: 0).toLong()), Bn.num((fact?.produced ?: 0).toLong()), DemoRepository.statusOf(r).nameBn), r.ref)
            }
        },
        ReportDef("purchase", "কাঁচামাল ক্রয়", "পণ্য গ্রহণ (GRN) অনুযায়ী ক্রয়", RecordType.GRN, true, listOf("GRN", "তারিখ", "বিবরণ", "মূল্য")) { f, ctx ->
            DemoRepository.list(RecordType.GRN, ctx).filter { r -> r.date?.let { f.contains(it) } ?: false }.map { ReportRow(listOf(it.ref.id, Bn.digits(it.dateIso), it.subtitle, kpi(it, "মূল্য")), it.ref) }
        },
        ReportDef("supplier_due", "সরবরাহকারী বকেয়া", "সরবরাহকারীভিত্তিক বকেয়া (ইনভেন্টরি-মূল্যায়ন থেকে আলাদা)", RecordType.SUPPLIER, false, listOf("সরবরাহকারী", "বকেয়া")) { _, ctx ->
            DemoRepository.facts.supplierDues.entries.sortedBy { it.key }.mapNotNull { e ->
                val rec = DemoRepository.get(RecordRef(RecordType.SUPPLIER, e.key)) ?: return@mapNotNull null
                if (rec.companyId !in ctx.companyIds) null else ReportRow(listOf(rec.title, Bn.taka(e.value.setScale(0, RoundingMode.HALF_UP).toLong())), rec.ref)
            }
        },
        ReportDef("inventory", "কাঁচামাল মজুত", "চলমান ভারযুক্ত গড়ে মজুত-মূল্য (ডেমো-গণনা)", RecordType.RAW_MATERIAL, false, listOf("উপাদান", "মজুত", "মূল্য", "গড় একক-খরচ")) { _, ctx ->
            DemoRepository.materialPositions().entries.sortedBy { it.key }.map { e ->
                ReportRow(listOf(DemoRepository.facts.materialNames[e.key] ?: e.key, e.value.qty.stripTrailingZeros().toPlainString().let { Bn.digits(it) } + " " + (DemoRepository.facts.materialUnits[e.key] ?: ""), Bn.taka(e.value.value.setScale(0, RoundingMode.HALF_UP).toLong()), Bn.digits(e.value.avg.setScale(2, RoundingMode.HALF_UP).toPlainString())), RecordRef(RecordType.RAW_MATERIAL, e.key))
            }
        },
        ReportDef("fg_stock", "তৈরি পণ্য মজুত", "শুধু QC-গৃহীত (উপলব্ধ) Poly", RecordType.PRODUCT, false, listOf("পণ্য", "উপলব্ধ Poly")) { _, ctx ->
            DemoRepository.productKpis(DemoRepository.demoDate.minusYears(1), DemoRepository.demoDate, ctx).map { ReportRow(listOf(it.product.title, Bn.num(it.fgAvailablePoly.toLong())), it.product.ref) }
        },
        ReportDef("qc", "কিউসি", "পরীক্ষার ফল", RecordType.QC_RECORD, true, listOf("পরীক্ষা", "তারিখ", "অবস্থা")) { f, ctx ->
            DemoRepository.list(RecordType.QC_RECORD, ctx).filter { r -> r.date?.let { f.contains(it) } ?: false }.map { ReportRow(listOf(it.ref.id, Bn.digits(it.dateIso), DemoRepository.statusOf(it).nameBn), it.ref) }
        },
        ReportDef("material_cost", "উপাদান-খরচ প্রতি Poly (আংশিক)", "প্রকৃত ব্যবহৃত উপাদানের খরচ ÷ গৃহীত Poly — পূর্ণ খরচ বা লাভ নয়", RecordType.BATCH_COST, false, listOf("ব্যাচ", "উপাদান-খরচ", "গৃহীত Poly", "টাকা/Poly")) { _, ctx ->
            DemoRepository.facts.batches.filter { it.status != "IN_PROGRESS" }.map { b ->
                val c = Costing.consumedCost(b.consumed, b.id, DemoRepository.costingResult.issueUnitCost)
                val cpp = Costing.materialCostPerPoly(c, BigDecimal(b.accepted))
                ReportRow(listOf(b.id, Bn.taka(c.setScale(0, RoundingMode.HALF_UP).toLong()), Bn.num(b.accepted.toLong()), if (cpp == null) "গণনাযোগ্য নয়" else Bn.digits(cpp.toPlainString())), RecordRef(RecordType.BATCH, b.id))
            }
        },
        ReportDef("expense", "কারখানার ব্যয়", "ব্যয়-রেকর্ড", RecordType.EXPENSE, true, listOf("ব্যয়", "তারিখ", "অবস্থা", "পরিমাণ")) { f, ctx ->
            DemoRepository.list(RecordType.EXPENSE, ctx).filter { r -> r.date?.let { f.contains(it) } ?: false }.map { ReportRow(listOf(it.ref.id, Bn.digits(it.dateIso), DemoRepository.statusOf(it).nameBn, kpi(it, "পরিমাণ")), it.ref) }
        },
        ReportDef("attendance", "উপস্থিতি", "মাসিক উপস্থিতি-সারাংশ (ডেমো-পরিসর)", RecordType.ATTENDANCE_MONTH, false, listOf("কর্মী", "উপস্থিত", "দেরিতে", "অনুপস্থিত")) { _, ctx ->
            DemoRepository.list(RecordType.ATTENDANCE_MONTH, ctx).map { ReportRow(listOf(it.subtitle, kpi(it, "উপস্থিত"), kpi(it, "দেরিতে"), kpi(it, "অনুপস্থিত")), it.ref) }
        },
        ReportDef("payroll", "বেতন (ডেমো)", "খসড়া বেতন — পেরোল-অনুমতি নীতি Pending", RecordType.PAYROLL_MONTH, false, listOf("কর্মী", "মাস", "নিট (ডেমো)")) { _, ctx ->
            DemoRepository.list(RecordType.PAYROLL_MONTH, ctx).map { ReportRow(listOf(it.subtitle, "অক্টোবর ২০২৬", kpi(it, "নিট (ডেমো)")), it.ref) }
        },
        ReportDef("factory_pnl", "ফ্যাক্টরি লাভ-ক্ষতি (শুধু এমডি)", "নীতি অনুমোদিত না হওয়া পর্যন্ত কোনো সংখ্যা তৈরি হয় না", RecordType.FACTORY_PNL, false, listOf("বিবরণ", "অবস্থা")) { _, ctx ->
            DemoRepository.list(RecordType.FACTORY_PNL, ctx).map { ReportRow(listOf(it.title, DemoRepository.statusOf(it).nameBn), it.ref) }
        }
    )
    val planned = listOf("অপচয় ও ক্ষতি-রিপোর্ট", "মেশিন-রক্ষণাবেক্ষণ-রিপোর্ট", "ফিজিক্যাল স্টক যাচাই-রিপোর্ট", "কারখানার খতিয়ান-রিপোর্ট", "রেসিপি-ভ্যারিয়েন্স-রিপোর্ট")
    fun find(id: String): ReportDef? = all.firstOrNull { it.id == id }
    fun visibleFor(ctx: UserContext): List<ReportDef> = all.filter { d -> ctx.roles.any { it in AccessPolicy.rolesFor(d.gateType) } }
}

@Composable
fun ReportCenterScreen(ctx: UserContext, onBack: (() -> Unit)?, onOpenReport: (String) -> Unit) {
    val visible = Reports.visibleFor(ctx)
    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
        Box(modifier = Modifier.background(Color.White)) { if (onBack != null) ScreenHeader(title = "রিপোর্ট-কেন্দ্র", onBack = onBack) else Text("রিপোর্ট-কেন্দ্র", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(16.dp)) }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { PreviewBanner("সব রিপোর্ট ডেমো-তথ্য থেকে বানানো; PDF/ছবি/WhatsApp/প্রিন্ট এখনো তৈরি হয়নি (পরিকল্পিত)।") }
            if (visible.isEmpty()) item { EmptyState("এই ভূমিকার জন্য কোনো রিপোর্ট খোলা নেই।") }
            items(visible, key = { it.id }) { d ->
                AppCard(onClick = { onOpenReport(d.id) }) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(d.nameBn, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text(d.descBn, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    }
                }
            }
            item { SectionTitle("পরিকল্পিত রিপোর্ট") }
            items(Reports.planned, key = { it }) { p ->
                AppCard { Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { StatusPill("পরিকল্পিত", Tone.NEUTRAL); Spacer(Modifier.width(8.dp)); Text(p, style = MaterialTheme.typography.bodyMedium) } }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
fun ReportPreviewScreen(reportId: String, ctx: UserContext, onBack: () -> Unit, onOpen: (RecordRef) -> Unit) {
    val def = Reports.find(reportId)
    var filter by remember { mutableStateOf(BnDate.monthOf(DemoRepository.demoDate)) }
    var showCal by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
        if (def == null) { Box(modifier = Modifier.background(Color.White)) { ScreenHeader(title = "রিপোর্ট", onBack = onBack) }; EmptyState("এই রিপোর্ট পাওয়া যায়নি।"); return@Column }
        val menu = listOf(
            MenuAction("pdf", "PDF", Icons.Filled.PictureAsPdf, false, "পরিকল্পিত"),
            MenuAction("share", "ছবি / WhatsApp / ইমেইল", Icons.Filled.Share, false, "পরিকল্পিত"),
            MenuAction("print", "A4 / POS প্রিন্ট", Icons.Filled.Print, false, "পরিকল্পিত")
        )
        Box(modifier = Modifier.background(Color.White)) { ScreenHeader(title = def.nameBn, onBack = onBack, trailing = { UniversalActionMenu(menu) }) }
        if (ctx.roles.none { it in AccessPolicy.rolesFor(def.gateType) }) { PermissionDeniedState("এই রিপোর্ট দেখার অনুমতি নেই।"); return@Column }
        val rows = def.build(filter, ctx).filter { r -> query.isBlank() || r.cells.any { it.lowercase().contains(query.trim().lowercase()) } }
        Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            PreviewBanner(def.descBn + " • ডেমো-তথ্য")
            if (def.dated) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("তারিখ: " + BnDate.formatFilter(filter), style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = { showCal = !showCal }) { Text(if (showCal) "বন্ধ" else "ক্যালেন্ডার") }
                }
                if (showCal) AppCard { Column(modifier = Modifier.padding(14.dp)) { UniversalCalendar(filter, DemoRepository.productionDates() + DemoRepository.allRecords.mapNotNull { it.date }.toSet(), { filter = it }) } }
            }
            SearchField(query, { query = it }, "রিপোর্টের ভেতরে খুঁজুন")
            if (rows.isEmpty()) EmptyState("এই পরিসরে/ফিল্টারে কোনো সারি নেই।")
            else AppCard {
                Column(modifier = Modifier.horizontalScroll(rememberScrollState()).padding(12.dp)) {
                    Row { def.columns.forEach { c -> Text(c, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = OrangeDark, modifier = Modifier.width(130.dp)) } }
                    Hairline()
                    rows.forEach { r ->
                        Row(modifier = Modifier.then(if (r.ref != null) Modifier.clickable { onOpen(r.ref) } else Modifier).padding(vertical = 8.dp)) {
                            r.cells.forEachIndexed { i, cell -> Text(cell, style = MaterialTheme.typography.bodySmall, color = if (i == 0 && r.ref != null) OrangePrimary else MaterialTheme.colorScheme.onSurface, modifier = Modifier.width(130.dp)) }
                        }
                        Hairline()
                    }
                }
            }
            Text(Bn.digits(rows.size.toString()) + "টি সারি • সারিতে ট্যাপ করলে সংশ্লিষ্ট রেকর্ড খোলে", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        }
    }
}
