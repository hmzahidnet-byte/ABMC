package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.Bn
import com.mohona.erp.data.demo.DemoRepository
import com.mohona.erp.domain.RecordRef
import com.mohona.erp.domain.UserContext
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.PreviewBanner
import com.mohona.erp.ui.components.RecordCard
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.SearchField
import com.mohona.erp.ui.components.SectionTitle
import com.mohona.erp.ui.components.rememberActionController
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.TextMuted

/** Global search: company-scoped and permission-filtered; a result opens the canonical Record Dashboard. */
@Composable
fun SearchScreen(ctx: UserContext, onBack: () -> Unit, onOpen: (RecordRef) -> Unit, onShowQr: (RecordRef) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val controller = rememberActionController(ctx, onShowQr) { onOpen(it) }
    val results = DemoRepository.search(query, ctx)
    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
        Box(modifier = Modifier.background(Color.White)) { ScreenHeader(title = "অনুসন্ধান", onBack = onBack) }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { SearchField(query, { query = it }, "কর্মী-আইডি, পণ্য-কোড, সরবরাহকারী, লেনদেন, ব্যাচ, QR-কোড…") }
            item { PreviewBanner("ফলাফল শুধু আপনার কোম্পানি ও অনুমতির মধ্যে। প্রতিটি ফলাফল তার নিজস্ব ড্যাশবোর্ডে খোলে।") }
            if (query.isBlank()) item { EmptyState("খোঁজা শুরু করতে লিখুন। উদাহরণ: B-001, PO-006, রহিম, চিনি") }
            else if (results.isEmpty()) item { EmptyState("কিছু পাওয়া যায়নি।") }
            else item { Text(Bn.digits(results.size.toString()) + "টি ফলাফল", style = MaterialTheme.typography.labelMedium, color = TextMuted) }
            items(results, key = { it.ref.key }) { RecordCard(it, ctx, controller, onOpen) }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
    controller.Dialogs()
}

/** Shared Approval Center. Decisions here are SIMULATIONS in the demo and obey maker-checker: you cannot decide your own transaction. */
@Composable
fun ApprovalCenterScreen(ctx: UserContext, onBack: () -> Unit, onOpen: (RecordRef) -> Unit, onShowQr: (RecordRef) -> Unit) {
    val controller = rememberActionController(ctx, onShowQr) { onOpen(it) }
    val pending = DemoRepository.pendingApprovals(ctx)
    val decided = DemoRepository.decidedInSession(ctx)
    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
        Box(modifier = Modifier.background(Color.White)) { ScreenHeader(title = "অনুমোদন-কেন্দ্র", onBack = onBack) }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { PreviewBanner("ডেমো: অনুমোদন/ফেরত/প্রত্যাখ্যান শুধু এই সেশনের ভেতরে অবস্থা বদলায় (সিমুলেশন)। নিজের তৈরি লেনদেন নিজে অনুমোদন করা যায় না।") }
            item { SectionTitle("অপেক্ষমাণ (" + Bn.digits(pending.size.toString()) + ")") }
            if (pending.isEmpty()) item { EmptyState("এই মুহূর্তে অনুমোদনের অপেক্ষায় কিছু নেই।") }
            items(pending, key = { "p" + it.ref.key }) { RecordCard(it, ctx, controller, onOpen) }
            item { SectionTitle("এই সেশনে সিদ্ধান্ত-প্রাপ্ত — সিমুলেশন (" + Bn.digits(decided.size.toString()) + ")") }
            if (decided.isEmpty()) item { EmptyState("এখনো কোনো সিমুলেটেড সিদ্ধান্ত নেই।") }
            items(decided, key = { "d" + it.ref.key }) { RecordCard(it, ctx, controller, onOpen) }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
    controller.Dialogs()
}
