package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.Bn
import com.mohona.erp.data.demo.DemoRepository
import com.mohona.erp.domain.Access
import com.mohona.erp.domain.AccessPolicy
import com.mohona.erp.domain.RecordRef
import com.mohona.erp.domain.UserContext
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.PermissionDeniedState
import com.mohona.erp.ui.components.PreviewBanner
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.SectionCard
import com.mohona.erp.ui.components.StatusPill
import com.mohona.erp.ui.components.Tone
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.TextMuted

/** Each notification opens its related record; ones pointing at records the user may not open are hidden (nothing unauthorised leaks). */
@Composable
fun NotificationCenterScreen(ctx: UserContext, onBack: () -> Unit, onOpen: (RecordRef) -> Unit) {
    val all = DemoRepository.notifications
    val visible = all.filter { n -> DemoRepository.get(n.ref)?.let { it.companyId in ctx.companyIds && AccessPolicy.canOpen(it, ctx) == Access.ALLOWED } ?: false }
    val hidden = all.size - visible.size
    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
        Box(modifier = Modifier.background(Color.White)) { ScreenHeader(title = "বিজ্ঞপ্তি", onBack = onBack) }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { PreviewBanner("ডেমো-বিজ্ঞপ্তি। বাস্তব বিজ্ঞপ্তি (FCM) পরে। প্রতিটি বিজ্ঞপ্তি তার রেকর্ড খোলে।") }
            if (visible.isEmpty()) item { EmptyState("আপনার জন্য কোনো বিজ্ঞপ্তি নেই।") }
            items(visible, key = { it.id }) { n ->
                val status = DemoRepository.get(n.ref)?.let { DemoRepository.statusOf(it) }
                AppCard(onClick = { onOpen(n.ref) }) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(n.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text(n.detail, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                            if (status != null) { StatusPill(status.nameBn, Tone.NEUTRAL); Spacer(Modifier.width(8.dp)) }
                            Text(n.whenText + " • " + n.ref.type.nameBn + " " + n.ref.id, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                    }
                }
            }
            if (hidden > 0) item { Text(Bn.digits(hidden.toString()) + "টি বিজ্ঞপ্তি আপনার অনুমতির বাইরে বলে দেখানো হয়নি।", style = MaterialTheme.typography.labelSmall, color = TextMuted) }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

/** Chairman-only governance entry point. Group authority (Chairman) and company authority (MD) stay distinct; unresolved controls stay Pending. */
@Composable
fun ChairmanScreen(ctx: UserContext, authorizedCompanyIds: Set<String>, onBack: () -> Unit, onSelectCompany: (String) -> Unit, onOpenWing: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
        Box(modifier = Modifier.background(Color.White)) { ScreenHeader(title = "চেয়ারম্যান নিয়ন্ত্রণ", onBack = onBack) }
        if ("CHAIRMAN" !in ctx.roles) { PermissionDeniedState("এই মডিউল শুধু অনুমোদিত চেয়ারম্যান-অ্যাক্সেসে।"); return@Column }
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            PreviewBanner("ডেমো-পূর্বরূপ: শাসন-নিয়ন্ত্রণগুলো এখনো ব্যাকএন্ড-নির্ভর; অমীমাংসিত নীতি 'Pending' রাখা হয়েছে।")
            SectionCard("অনুমোদিত কোম্পানি-তদারকি") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    authorizedCompanyIds.sorted().forEach { id ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(DemoRepository.companyName(id), modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            if (id == ctx.companyId) StatusPill("বর্তমান", Tone.GOOD) else OutlinedButton(onClick = { onSelectCompany(id) }) { Text("এই কোম্পানি দেখুন") }
                        }
                    }
                    OutlinedButton(onClick = onOpenWing) { Text("উইং ১ খুলুন (বর্তমান কোম্পানি)") }
                }
            }
            SectionCard("শাসন-নিয়ন্ত্রণ") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("পদ-নিয়ন্ত্রণ", "ভূমিকা ও অনুমতি ব্যবস্থাপনা", "অনুমোদন-ক্রম", "অ্যাকাউন্ট-নিয়ন্ত্রণ", "অনুমোদিত ঘোষণা", "ব্যবস্থাপনা-সেটিংস", "শাসন-ইতিহাস").forEach { g ->
                        Row(verticalAlignment = Alignment.CenterVertically) { StatusPill("Pending", Tone.WARN); Spacer(Modifier.width(8.dp)); Text(g, style = MaterialTheme.typography.bodyMedium) }
                    }
                }
            }
            SectionCard("সীমানা") {
                Text("• চেয়ারম্যান = গ্রুপ-স্তরের অনুমোদিত তদারকি; এমডি = নিজ কোম্পানির কর্তৃত্ব।\n• ফ্যাক্টরি লাভ-ক্ষতি শুধু সংশ্লিষ্ট কোম্পানির এমডি; চেয়ারম্যানকে স্বয়ংক্রিয়ভাবে দেওয়া হয়নি।\n• কোম্পানি-মধ্যবর্তী লেনদেন বন্ধ।", style = MaterialTheme.typography.bodySmall, color = TextMuted)
            }
        }
    }
}
