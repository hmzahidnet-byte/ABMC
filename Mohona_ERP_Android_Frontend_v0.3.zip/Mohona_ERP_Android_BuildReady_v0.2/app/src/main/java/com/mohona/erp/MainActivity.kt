package com.mohona.erp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.mohona.erp.data.demo.DemoRepository
import com.mohona.erp.ui.components.ErrorState
import com.mohona.erp.ui.navigation.MohonaApp
import com.mohona.erp.ui.theme.MohonaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Structured demo data (assets/demo/demo_data.json). A load failure is shown as an error screen instead of crashing.
        val demoError: String? = try {
            DemoRepository.load(applicationContext)
            null
        } catch (e: Exception) {
            "ডেমো-তথ্য লোড করা যায়নি: " + (e.message ?: e.javaClass.simpleName)
        }
        setContent {
            MohonaTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color.White) {
                    if (demoError != null) ErrorState(demoError) else MohonaApp()
                }
            }
        }
    }
}
