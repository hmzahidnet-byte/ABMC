package com.mohona.erp.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.Bn
import com.mohona.erp.ui.theme.ChartBlue
import com.mohona.erp.ui.theme.DividerGray
import com.mohona.erp.ui.theme.OrangeDark
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.TextMuted

/** Card wrapper used by every chart. Chart data in v0.1 is ALWAYS sample data and is labelled so. */
@Composable
fun ChartCard(title: String, subtitle: String, content: @Composable () -> Unit) {
    AppCard {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
                PreviewBadge()
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

private fun slotIndex(x: Float, width: Float, n: Int): Int {
    if (n <= 0 || width <= 0f) return 0
    val slot = width / n
    val i = (x / slot).toInt()
    return if (i < 0) 0 else if (i > n - 1) n - 1 else i
}

/** Interactive line chart: tap or drag to read a value. */
@Composable
fun LineChart(
    labels: List<String>,
    values: List<Double>,
    unit: String,
    modifier: Modifier = Modifier,
    lineColor: Color = OrangePrimary
) {
    var selected by remember { mutableIntStateOf(if (values.isEmpty()) 0 else values.size - 1) }
    Column(modifier = modifier.fillMaxWidth()) {
        val headline = if (selected in values.indices && selected in labels.indices) {
            labels[selected] + ": " + Bn.dec(values[selected]) + " " + unit
        } else ""
        Text(text = headline, style = MaterialTheme.typography.titleSmall, color = OrangeDark, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        val maxV = (values.maxOrNull() ?: 1.0).coerceAtLeast(1.0)
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .pointerInput(values) {
                    detectTapGestures { off -> selected = slotIndex(off.x, size.width.toFloat(), values.size) }
                }
                .pointerInput(values) {
                    detectHorizontalDragGestures { change, _ ->
                        change.consume()
                        selected = slotIndex(change.position.x, size.width.toFloat(), values.size)
                    }
                }
        ) {
            val w = size.width
            val h = size.height
            val pad = 10.dp.toPx()
            val n = values.size
            if (n > 0) {
                val slot = w / n
                for (g in 0..3) {
                    val y = pad + (h - 2 * pad) * g / 3f
                    drawLine(DividerGray, Offset(0f, y), Offset(w, y), 1.dp.toPx())
                }
                fun px(i: Int): Float = slot * (i + 0.5f)
                fun py(v: Double): Float = h - pad - (v / maxV).toFloat() * (h - 2 * pad)

                val fill = Path()
                fill.moveTo(px(0), h - pad)
                values.forEachIndexed { i, v -> fill.lineTo(px(i), py(v)) }
                fill.lineTo(px(n - 1), h - pad)
                fill.close()
                drawPath(fill, Brush.verticalGradient(listOf(lineColor.copy(alpha = 0.28f), Color.Transparent), 0f, h))

                val line = Path()
                values.forEachIndexed { i, v ->
                    if (i == 0) line.moveTo(px(i), py(v)) else line.lineTo(px(i), py(v))
                }
                drawPath(line, lineColor, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))

                if (selected in 0 until n) {
                    drawLine(lineColor.copy(alpha = 0.35f), Offset(px(selected), pad), Offset(px(selected), h - pad), 1.5.dp.toPx())
                }
                values.forEachIndexed { i, v ->
                    val r = if (i == selected) 7.dp.toPx() else 4.dp.toPx()
                    drawCircle(Color.White, r + 2.dp.toPx(), Offset(px(i), py(v)))
                    drawCircle(lineColor, r, Offset(px(i), py(v)))
                }
            }
        }
        Row(modifier = Modifier.fillMaxWidth()) {
            labels.forEachIndexed { i, l ->
                Text(
                    text = l,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (i == selected) OrangeDark else TextMuted,
                    maxLines = 1
                )
            }
        }
    }
}

data class BarSeries(val name: String, val values: List<Double>, val color: Color)

/** Interactive bar chart with one or more series. Tap a group to read its values. */
@Composable
fun BarChart(
    labels: List<String>,
    series: List<BarSeries>,
    unit: String,
    modifier: Modifier = Modifier
) {
    var selected by remember { mutableIntStateOf(0) }
    Column(modifier = modifier.fillMaxWidth()) {
        if (series.size > 1) {
            Row {
                series.forEach { s ->
                    Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(s.color))
                    Spacer(Modifier.width(4.dp))
                    Text(text = s.name, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(Modifier.width(14.dp))
                }
            }
            Spacer(Modifier.height(6.dp))
        }
        val sel = if (selected in labels.indices) selected else 0
        val head = StringBuilder()
        if (labels.isNotEmpty()) {
            head.append(labels[sel]).append(": ")
            series.forEachIndexed { k, s ->
                if (k > 0) head.append(" | ")
                if (sel in s.values.indices) {
                    if (series.size > 1) head.append(s.name).append(" ")
                    head.append(Bn.dec(s.values[sel], if (unit == "ইউনিট") 0 else 1)).append(" ").append(unit)
                }
            }
        }
        Text(text = head.toString(), style = MaterialTheme.typography.titleSmall, color = OrangeDark, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        var maxV = 1.0
        series.forEach { s -> s.values.forEach { v -> if (v > maxV) maxV = v } }
        val maxValue = maxV
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .pointerInput(labels) {
                    detectTapGestures { off -> selected = slotIndex(off.x, size.width.toFloat(), labels.size) }
                }
        ) {
            val w = size.width
            val h = size.height
            val pad = 10.dp.toPx()
            val n = labels.size
            if (n > 0 && series.isNotEmpty()) {
                val slot = w / n
                for (g in 0..3) {
                    val y = pad + (h - 2 * pad) * g / 3f
                    drawLine(DividerGray, Offset(0f, y), Offset(w, y), 1.dp.toPx())
                }
                val groupWidth = slot * 0.64f
                val barWidth = groupWidth / series.size
                for (i in 0 until n) {
                    val groupLeft = slot * i + (slot - groupWidth) / 2f
                    series.forEachIndexed { k, s ->
                        if (i < s.values.size) {
                            val bh = (s.values[i] / maxValue).toFloat() * (h - 2 * pad)
                            val alpha = if (i == sel) 1f else 0.55f
                            drawRoundRect(
                                color = s.color.copy(alpha = alpha),
                                topLeft = Offset(groupLeft + barWidth * k + 2.dp.toPx(), h - pad - bh),
                                size = Size(barWidth - 4.dp.toPx(), bh),
                                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                            )
                        }
                    }
                }
            }
        }
        Row(modifier = Modifier.fillMaxWidth()) {
            labels.forEachIndexed { i, l ->
                Text(
                    text = l,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (i == sel) OrangeDark else TextMuted,
                    maxLines = 1
                )
            }
        }
    }
}

data class DonutPart(val label: String, val value: Double, val color: Color)

/** Donut chart with a tappable legend; the tapped segment is emphasised. */
@Composable
fun DonutChart(parts: List<DonutPart>, centerTop: String, centerBottom: String, valueSuffix: String) {
    var selected by remember { mutableIntStateOf(-1) }
    val total = parts.sumOf { it.value }.coerceAtLeast(1.0)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(150.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(150.dp)) {
                val inset = 20.dp.toPx()
                val d = size.minDimension - 2 * inset
                var start = -90f
                parts.forEachIndexed { i, p ->
                    val sweepFull = (p.value / total * 360.0).toFloat()
                    val sw = if (i == selected) 30.dp.toPx() else 22.dp.toPx()
                    drawArc(
                        color = if (selected == -1 || i == selected) p.color else p.color.copy(alpha = 0.35f),
                        startAngle = start,
                        sweepAngle = (sweepFull - 2f).coerceAtLeast(1f),
                        useCenter = false,
                        topLeft = Offset(inset, inset),
                        size = Size(d, d),
                        style = Stroke(width = sw)
                    )
                    start += sweepFull
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = centerTop, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(text = centerBottom, style = MaterialTheme.typography.labelSmall, color = TextMuted)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            parts.forEachIndexed { i, p ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { selected = if (selected == i) -1 else i }
                        .padding(vertical = 6.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(p.color))
                    Spacer(Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = p.label, style = MaterialTheme.typography.bodySmall)
                        Text(
                            text = Bn.dec(p.value) + " " + valueSuffix + "  (" + Bn.dec(p.value / total * 100.0, 0) + "%)",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (i == selected) OrangeDark else TextMuted
                        )
                    }
                }
            }
        }
    }
}

/** Horizontal ratio bar (no canvas): used for due-collection ageing. */
@Composable
fun RatioBar(label: String, valueText: String, fraction: Float, color: Color) {
    val f = if (fraction < 0f) 0f else if (fraction > 1f) 1f else fraction
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Text(text = label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            Text(text = valueText, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(DividerGray)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(5.dp))
                    .background(color)
            )
        }
    }
}

// ---------- Ready-made sample-data charts used on the dashboard and the reports tab ----------

@Composable
fun SalesTrendChart() {
    ChartCard(title = "বিক্রয়ের ধারা", subtitle = "গত ৬ মাস (লাখ টাকা)") {
        LineChart(
            labels = listOf("জুন", "জুলাই", "আগস্ট", "সেপ্টে", "অক্টো", "নভে"),
            values = listOf(18.5, 22.0, 19.8, 25.4, 28.1, 31.2),
            unit = "লাখ টাকা"
        )
    }
}

@Composable
fun ProductionComparisonChart() {
    ChartCard(title = "উৎপাদন তুলনা", subtitle = "পরিকল্পিত বনাম প্রকৃত (ইউনিট)") {
        BarChart(
            labels = listOf("সপ্তাহ ১", "সপ্তাহ ২", "সপ্তাহ ৩", "সপ্তাহ ৪"),
            series = listOf(
                BarSeries("পরিকল্পিত", listOf(1200.0, 1300.0, 1250.0, 1400.0), ChartBlue),
                BarSeries("প্রকৃত", listOf(1150.0, 1320.0, 1180.0, 1390.0), OrangePrimary)
            ),
            unit = "ইউনিট"
        )
    }
}

@Composable
fun ProductSalesChart() {
    ChartCard(title = "পণ্য-ভিত্তিক বিক্রয়", subtitle = "চলতি মাস (লাখ টাকা)") {
        BarChart(
            labels = listOf("পণ্য-ক", "পণ্য-খ", "পণ্য-গ", "পণ্য-ঘ", "পণ্য-ঙ"),
            series = listOf(BarSeries("বিক্রয়", listOf(42.0, 35.0, 28.0, 19.0, 12.0), OrangePrimary)),
            unit = "লাখ টাকা"
        )
    }
}

@Composable
fun StockSummaryChart() {
    ChartCard(title = "স্টক সারসংক্ষেপ", subtitle = "মজুতের মূল্য (লাখ টাকা)") {
        DonutChart(
            parts = listOf(
                DonutPart("কাঁচামাল", 120.0, OrangePrimary),
                DonutPart("প্রক্রিয়াধীন", 40.0, ChartBlue),
                DonutPart("তৈরি পণ্য", 108.0, com.mohona.erp.ui.theme.ChartTeal)
            ),
            centerTop = Bn.dec(268.0, 0),
            centerBottom = "লাখ টাকা",
            valueSuffix = "লাখ"
        )
    }
}

@Composable
fun DueCollectionOverview() {
    ChartCard(title = "বকেয়া আদায়", subtitle = "মোট বকেয়া ৮৫ লাখ টাকার মধ্যে") {
        RatioBar("আদায় হয়েছে", Bn.dec(52.0, 0) + " লাখ", 52f / 85f, com.mohona.erp.ui.theme.GoodGreen)
        RatioBar("এখনো বকেয়া", Bn.dec(33.0, 0) + " লাখ", 33f / 85f, OrangePrimary)
        Spacer(Modifier.height(6.dp))
        Text(text = "বকেয়ার বয়স", style = MaterialTheme.typography.labelMedium, color = TextMuted)
        RatioBar("০–৩০ দিন", Bn.dec(18.0, 0) + " লাখ", 18f / 33f, com.mohona.erp.ui.theme.ChartBlue)
        RatioBar("৩১–৬০ দিন", Bn.dec(9.0, 0) + " লাখ", 9f / 33f, com.mohona.erp.ui.theme.WarnAmber)
        RatioBar("৬০+ দিন", Bn.dec(6.0, 0) + " লাখ", 6f / 33f, com.mohona.erp.ui.theme.BadRed)
    }
}
