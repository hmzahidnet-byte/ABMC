package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.Roles
import com.mohona.erp.data.demo.DemoRepository
import com.mohona.erp.domain.UserContext
import com.mohona.erp.domain.WingRegistry
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.MohonaLogo
import com.mohona.erp.ui.components.PreviewBadge
import com.mohona.erp.ui.components.iconForKey
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.OrangeDark
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.OrangeSoft
import com.mohona.erp.ui.theme.TextMuted

/** Level 1: only the Wings this user is authorised to see. No KPIs, charts or operational tables here (they belong inside a Wing). */
@Composable
fun GlobalHomeScreen(
    ctx: UserContext,
    authorizedCompanyIds: Set<String>,
    isPreview: Boolean,
    unreadNotifications: Int,
    onOpenWing: (String) -> Unit,
    onSearch: () -> Unit,
    onNotifications: () -> Unit,
    onProfile: () -> Unit,
    onChairman: () -> Unit,
    onSelectCompany: (String) -> Unit
) {
    val wings = WingRegistry.wings.filter { WingRegistry.wingVisibleFor(it, ctx) }
    var companyMenu by remember { mutableStateOf(false) }
    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray).verticalScroll(rememberScrollState())) {
        Row(
            modifier = Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MohonaLogo(size = 42.dp)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onSearch) { Icon(Icons.Filled.Search, contentDescription = "অনুসন্ধান", tint = OrangeDark) }
            IconButton(onClick = onNotifications) { Icon(Icons.Filled.Notifications, contentDescription = "বিজ্ঞপ্তি", tint = OrangeDark) }
            IconButton(onClick = onProfile) { Icon(Icons.Filled.Person, contentDescription = "প্রোফাইল", tint = OrangeDark) }
        }

        Column(modifier = Modifier.padding(16.dp)) {
            Text("মোহনা কনসোর্টিয়াম", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(Roles.namesOf(ctx.roles), style = MaterialTheme.typography.bodyMedium, color = TextMuted)
            Spacer(Modifier.height(10.dp))
            // company context (Chairman may switch between authorised companies; everyone else sees their own, fixed)
            Box {
                Row(
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(OrangeSoft)
                        .then(if (authorizedCompanyIds.size > 1) Modifier.clickable { companyMenu = true } else Modifier)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(DemoRepository.companyName(ctx.companyId), style = MaterialTheme.typography.labelLarge, color = OrangeDark, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (authorizedCompanyIds.size > 1) Icon(Icons.Filled.ArrowDropDown, contentDescription = "কোম্পানি বদলান", tint = OrangeDark)
                }
                DropdownMenu(expanded = companyMenu, onDismissRequest = { companyMenu = false }) {
                    authorizedCompanyIds.sorted().forEach { id ->
                        DropdownMenuItem(text = { Text(DemoRepository.companyName(id)) }, onClick = { companyMenu = false; onSelectCompany(id) })
                    }
                }
            }
            if (authorizedCompanyIds.size > 1) Text("গ্রুপ-স্তরের তদারকি: কোম্পানি বদলালে ডেটা-প্রসঙ্গ আলাদা থাকে", style = MaterialTheme.typography.labelSmall, color = TextMuted, modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(8.dp))
            if (isPreview) PreviewBadge("ডেমো-মোড • নমুনা তথ্য • কিছুই সংরক্ষিত হয় না") else PreviewBadge("সংযুক্ত মোড: ব্যবসায়িক পর্দা এখনো ডেমো-তথ্যে")
        }

        Text("আপনার উইং", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (wings.isEmpty()) {
                AppCard { EmptyState("এই ভূমিকার জন্য কোনো উইং খোলা নেই। অনুমোদিত নিয়ম অনুযায়ী ব্যবসায়িক তথ্যে প্রবেশ নেই; প্রোফাইল দেখতে ওপরের আইকনে চাপুন।") }
            }
            wings.forEach { w ->
                AppCard(onClick = { onOpenWing(w.id) }) {
                    Row(modifier = Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(60.dp).clip(RoundedCornerShape(18.dp)).background(OrangeSoft), contentAlignment = Alignment.Center) {
                            Icon(iconForKey(w.iconKey), contentDescription = null, tint = OrangePrimary, modifier = Modifier.size(32.dp))
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(w.nameBn, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(w.descBn, style = MaterialTheme.typography.bodySmall, color = TextMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = TextMuted)
                    }
                }
            }
            if ("CHAIRMAN" in ctx.roles) {
                AppCard(onClick = onChairman) {
                    Row(modifier = Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(60.dp).clip(RoundedCornerShape(18.dp)).background(OrangeSoft), contentAlignment = Alignment.Center) {
                            Icon(iconForKey("check"), contentDescription = null, tint = OrangePrimary, modifier = Modifier.size(32.dp))
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("চেয়ারম্যান নিয়ন্ত্রণ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("অনুমোদিত গ্রুপ-তদারকি ও শাসন-নিয়ন্ত্রণ", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                        }
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = TextMuted)
                    }
                }
            }
            Text("ভবিষ্যতের অন্যান্য উইং নিশ্চিত হলে এখানে একই কাঠামোতে যুক্ত হবে; এখন শুধু উইং ১ প্রস্তুত।", style = MaterialTheme.typography.labelSmall, color = TextMuted, modifier = Modifier.padding(vertical = 8.dp))
        }
        Spacer(Modifier.height(24.dp))
    }
}
