package com.mohona.erp.domain

import java.time.LocalDate

/** ENTITY = a master/thing, TRANSACTION = a business document with a workflow, EVENT = a dated fact/line that belongs to something else. */
enum class RecordKind { ENTITY, TRANSACTION, EVENT }

/** Every business record type that has (or will have) its own canonical dashboard. [code] is the stable route identity. */
enum class RecordType(val code: String, val nameBn: String, val pluralBn: String, val kind: RecordKind, val hasQr: Boolean = false) {
    EMPLOYEE("emp", "কর্মী", "কর্মী-তালিকা", RecordKind.ENTITY, true),
    PRODUCT("prd", "পণ্য", "পণ্য-তালিকা", RecordKind.ENTITY, true),
    RAW_MATERIAL("mat", "কাঁচামাল", "কাঁচামাল-তালিকা", RecordKind.ENTITY),
    SUPPLIER("sup", "সরবরাহকারী", "সরবরাহকারী-তালিকা", RecordKind.ENTITY),
    WAREHOUSE("wh", "গুদাম", "গুদাম-তালিকা", RecordKind.ENTITY),
    MACHINE("mc", "মেশিন", "মেশিন-তালিকা", RecordKind.ENTITY),
    SPARE_PART("spr", "স্পেয়ার পার্টস", "স্পেয়ার পার্টস-তালিকা", RecordKind.ENTITY),
    BOM("bom", "রেসিপি / BOM", "BOM-তালিকা", RecordKind.ENTITY),
    BATCH("bat", "উৎপাদন ব্যাচ", "ব্যাচ-তালিকা", RecordKind.TRANSACTION, true),
    PURCHASE_ORDER("po", "ক্রয় আদেশ", "ক্রয় আদেশ-তালিকা", RecordKind.TRANSACTION, true),
    GRN("grn", "পণ্য গ্রহণ (GRN)", "GRN-তালিকা", RecordKind.TRANSACTION),
    PAYMENT_VOUCHER("pv", "পরিশোধ ভাউচার", "পরিশোধ ভাউচার-তালিকা", RecordKind.TRANSACTION),
    SUPPLIER_LEDGER("sl", "সরবরাহকারী খতিয়ান-লিপি", "সরবরাহকারী খতিয়ান", RecordKind.EVENT),
    STOCK_MOVEMENT("sm", "স্টক-চলাচল", "স্টক-চলাচল-তালিকা", RecordKind.EVENT),
    MATERIAL_ISSUE("iss", "মালামাল ইস্যু", "মালামাল ইস্যু-তালিকা", RecordKind.TRANSACTION),
    CONSUMPTION("con", "প্রকৃত ব্যবহার", "প্রকৃত ব্যবহার-তালিকা", RecordKind.TRANSACTION),
    BATCH_COST("bc", "ব্যাচ-খরচ", "ব্যাচ-খরচ-তালিকা", RecordKind.EVENT),
    QC_RECORD("qc", "কিউসি পরীক্ষা", "কিউসি-তালিকা", RecordKind.TRANSACTION),
    FG_RECEIPT("fgr", "তৈরি পণ্য গ্রহণ", "তৈরি পণ্য গ্রহণ-তালিকা", RecordKind.TRANSACTION),
    ATTENDANCE_MONTH("atm", "মাসিক উপস্থিতি", "মাসিক উপস্থিতি", RecordKind.ENTITY),
    ATTENDANCE_DAY("atd", "দৈনিক উপস্থিতি", "দৈনিক উপস্থিতি", RecordKind.EVENT),
    ATTENDANCE_EVENT("ate", "উপস্থিতি-ইভেন্ট", "উপস্থিতি-ইভেন্ট", RecordKind.EVENT),
    PAYROLL_MONTH("prm", "মাসিক বেতন", "মাসিক বেতন-তালিকা", RecordKind.TRANSACTION),
    PAYSLIP("psl", "পে-স্লিপ", "পে-স্লিপ-তালিকা", RecordKind.TRANSACTION),
    MAINTENANCE("mnt", "রক্ষণাবেক্ষণ", "রক্ষণাবেক্ষণ-তালিকা", RecordKind.TRANSACTION),
    BREAKDOWN("brk", "ব্রেকডাউন", "ব্রেকডাউন-তালিকা", RecordKind.EVENT),
    EXPENSE("exp", "ব্যয়", "ব্যয়-তালিকা", RecordKind.TRANSACTION),
    FACTORY_PNL("pnl", "ফ্যাক্টরি লাভ-ক্ষতি", "ফ্যাক্টরি লাভ-ক্ষতি", RecordKind.ENTITY);

    companion object {
        fun fromName(name: String): RecordType? = values().firstOrNull { it.name == name }
        fun fromCode(code: String): RecordType? = values().firstOrNull { it.code == code }
    }
}

enum class StatusTone { NEUTRAL, GOOD, WARN, BAD, INFO }

enum class RecordStatus(val nameBn: String, val tone: StatusTone) {
    DRAFT("খসড়া", StatusTone.NEUTRAL),
    SUBMITTED("অনুমোদনের অপেক্ষায়", StatusTone.WARN),
    APPROVED("অনুমোদিত", StatusTone.GOOD),
    POSTED("পোস্টকৃত", StatusTone.GOOD),
    RETURNED("ফেরত", StatusTone.WARN),
    REJECTED("প্রত্যাখ্যাত", StatusTone.BAD),
    CANCELLED("বাতিল", StatusTone.BAD),
    REVERSED("বাতিল-সমন্বয়কৃত (Reversed)", StatusTone.BAD),
    ACTIVE("সক্রিয়", StatusTone.GOOD),
    INACTIVE("নিষ্ক্রিয়", StatusTone.NEUTRAL),
    ON_LEAVE("ছুটিতে", StatusTone.WARN),
    COMPLETED("সম্পন্ন", StatusTone.GOOD),
    IN_PROGRESS("চলমান", StatusTone.INFO),
    QC_HOLD("QC হোল্ড", StatusTone.WARN),
    HOLD("হোল্ড", StatusTone.WARN),
    ACCEPTED("গৃহীত", StatusTone.GOOD),
    PENDING("অপেক্ষমাণ", StatusTone.WARN),
    SUPERSEDED("পুরোনো সংস্করণ", StatusTone.NEUTRAL),
    PRESENT("উপস্থিত", StatusTone.GOOD),
    LATE("দেরিতে", StatusTone.WARN),
    ABSENT("অনুপস্থিত", StatusTone.BAD);

    companion object {
        fun fromName(name: String): RecordStatus = values().firstOrNull { it.name == name } ?: ACTIVE
    }
}

/** Stable identity of a record: its type plus its permanent internal id (NOT the QR token and NOT necessarily the printed reference). */
data class RecordRef(val type: RecordType, val id: String) {
    val key: String get() = type.name + "/" + id

    companion object {
        fun parse(key: String): RecordRef? {
            val i = key.indexOf('/')
            if (i <= 0) return null
            val t = RecordType.fromName(key.substring(0, i)) ?: return null
            return RecordRef(t, key.substring(i + 1))
        }
    }
}

data class Kpi(val label: String, val value: String, val note: String = "")
data class InfoRow(val label: String, val value: String)
data class LineItem(val name: String, val qty: String, val unit: String, val unitPrice: String, val amount: String, val ref: RecordRef?)
data class RelatedGroup(val type: RecordType, val refs: List<RecordRef>)
data class HistoryEvent(val whenText: String, val title: String, val detail: String, val actor: String, val simulated: Boolean = false)

data class DemoRecord(
    val ref: RecordRef,
    val title: String,
    val reference: String,
    val status: RecordStatus,
    val companyId: String,
    val dateIso: String,
    val subtitle: String,
    val createdBy: String?,
    val imageTone: Int,
    val qrToken: String?,
    val kpis: List<Kpi>,
    val info: List<InfoRow>,
    val sensitive: List<InfoRow>,
    val lines: List<LineItem>,
    val totals: List<InfoRow>,
    val related: List<RelatedGroup>,
    val history: List<HistoryEvent>,
    val approval: List<HistoryEvent>,
    val reversalOf: RecordRef?,
    val replacementOf: RecordRef?,
    val note: String
) {
    val date: LocalDate? get() = if (dateIso.length == 10) runCatching { LocalDate.parse(dateIso) }.getOrNull() else null
}

data class DemoCompany(val id: String, val name: String)
data class DemoNotification(val id: String, val title: String, val detail: String, val ref: RecordRef, val whenText: String)

/** Who is looking. In Preview this is a visual simulation only; real access control is enforced by the backend (RLS/RPC). */
data class UserContext(
    val name: String,
    val employeeId: String,
    val roles: List<String>,
    val companyId: String,
    val companyIds: Set<String>,
    val isPreview: Boolean
)
