package com.mohona.erp.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import com.mohona.erp.ui.theme.TextMuted

/** One entry of the universal ⋮ menu. Disabled entries are visibly disabled and carry a hint; they never pretend to work. */
data class MenuAction(
    val id: String,
    val label: String,
    val icon: ImageVector,
    val enabled: Boolean,
    val hint: String? = null,
    val onClick: () -> Unit = {}
)

/**
 * The ONE shared contextual three-dot menu (owner term "Universal Key"; it is not a database identifier).
 * v0.2 builds the list locally; later it will be server-driven (api.v1_get_available_actions) so only authorized,
 * relevant actions appear for the current user and record state.
 */
@Composable
fun UniversalActionMenu(actions: List<MenuAction>, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(modifier = modifier) {
        IconButton(onClick = { open = true }) {
            Icon(Icons.Filled.MoreVert, contentDescription = "আরও কাজ")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            actions.forEach { a ->
                DropdownMenuItem(
                    text = {
                        Column {
                            Text(text = a.label)
                            if (a.hint != null) {
                                Text(text = a.hint, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            }
                        }
                    },
                    leadingIcon = { Icon(a.icon, contentDescription = null) },
                    enabled = a.enabled,
                    onClick = {
                        open = false
                        a.onClick()
                    }
                )
            }
        }
    }
}

private const val PLANNED = "পরিকল্পিত"
private const val NEEDS_BACKEND = "ব্যাকএন্ড যুক্ত হলে চালু হবে"

/**
 * Standard action catalog for a record. Only what truly works in v0.2 is enabled:
 * copy-reference (real clipboard) and the demo QR view. Everything else is listed as planned/disabled so the
 * final menu shape is visible without faking functionality.
 */
@Composable
fun rememberRecordActions(
    reference: String,
    onShowQr: (() -> Unit)? = null,
    withContact: Boolean = false
): List<MenuAction> {
    val context = LocalContext.current
    val list = ArrayList<MenuAction>()
    list.add(
        MenuAction("copy_reference", "রেফারেন্স কপি", Icons.Filled.ContentCopy, true, null) {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("reference", reference))
            Toast.makeText(context, "রেফারেন্স কপি হয়েছে", Toast.LENGTH_SHORT).show()
        }
    )
    list.add(MenuAction("view_history", "ইতিহাস", Icons.Filled.History, false, NEEDS_BACKEND))
    list.add(
        MenuAction(
            "qr_view", "QR দেখুন (ডেমো)", Icons.Filled.QrCode2,
            onShowQr != null, if (onShowQr == null) PLANNED else "নমুনা QR-পর্দা",
            onShowQr ?: {}
        )
    )
    list.add(MenuAction("qr_generate", "QR তৈরি/প্রিন্ট", Icons.Filled.QrCode2, false, NEEDS_BACKEND))
    list.add(MenuAction("share_visual", "WhatsApp-এ হুবহু পর্দা-ছবি", Icons.Filled.Share, false, PLANNED))
    list.add(MenuAction("export_image", "JPG/PNG সংরক্ষণ", Icons.Filled.Share, false, PLANNED))
    list.add(MenuAction("export_pdf", "PDF", Icons.Filled.PictureAsPdf, false, PLANNED))
    list.add(MenuAction("print_a4", "A4 প্রিন্ট", Icons.Filled.Print, false, PLANNED))
    list.add(MenuAction("print_pos", "POS রসিদ প্রিন্ট", Icons.Filled.Print, false, PLANNED))
    if (withContact) {
        list.add(MenuAction("call", "কল করুন", Icons.Filled.Call, false, NEEDS_BACKEND))
        list.add(MenuAction("whatsapp", "WhatsApp বার্তা", Icons.AutoMirrored.Filled.Send, false, NEEDS_BACKEND))
        list.add(MenuAction("email", "ইমেইল", Icons.Filled.Email, false, NEEDS_BACKEND))
    }
    return list
}
