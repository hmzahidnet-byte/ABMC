package com.mohona.erp.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mohona.erp.domain.UserContext
import kotlinx.coroutines.launch

enum class AppMode { PREVIEW, CONNECTED }

data class SessionState(
    val mode: AppMode = AppMode.PREVIEW,
    val profile: UserProfile? = null,
    val loading: Boolean = false,
    val error: String? = null
)

/**
 * Shared authentication & session layer.
 * - PREVIEW: a local demo profile; no network, nothing saved; the chosen roles only change what the demo shows.
 * - CONNECTED: sign-in (authentication) then a separate live permission fetch (authorization). Tokens live only in memory
 *   and are discarded on logout. Roles shown come from the server, never from a client-side choice.
 */
const val DEMO_COMPANY_1 = "C1"
const val DEMO_COMPANY_2 = "C2"

class SessionViewModel : ViewModel() {
    var state by mutableStateOf(SessionState())
        private set

    private var tokens: AuthTokens? = null

    /** Company currently in view (group-level roles may switch; everybody else is fixed to their own company). */
    var selectedCompanyId by mutableStateOf(DEMO_COMPANY_1)
        private set

    fun authorizedCompanyIds(): Set<String> {
        val roles = state.profile?.roleCodes ?: emptyList()
        return if ("CHAIRMAN" in roles) setOf(DEMO_COMPANY_1, DEMO_COMPANY_2) else setOf(DEMO_COMPANY_1)
    }

    fun selectCompany(id: String) {
        if (id in authorizedCompanyIds()) selectedCompanyId = id
    }

    /** Visual-simulation context. In Preview it carries no backend authority. */
    fun userContext(): UserContext? {
        val p = state.profile ?: return null
        val company = if (selectedCompanyId in authorizedCompanyIds()) selectedCompanyId else DEMO_COMPANY_1
        return UserContext(p.name, p.employeeId, p.roleCodes, company, setOf(company), p.isPreview)
    }

    private val repository: AuthRepository? =
        if (AppConfig.connectedConfigured) SupabaseAuthRepository(AppConfig.supabaseUrl, AppConfig.anonKey) else null

    fun selectMode(mode: AppMode) {
        state = state.copy(mode = mode, error = null)
    }

    fun startPreview(primaryRole: String, secondaryRole: String?) {
        tokens = null
        selectedCompanyId = DEMO_COMPANY_1
        com.mohona.erp.data.demo.DemoRepository.resetSimulation()
        state = SessionState(mode = AppMode.PREVIEW, profile = PreviewProfiles.forRoles(primaryRole, secondaryRole))
    }

    fun loginConnected(loginId: String, password: String, onSuccess: () -> Unit) {
        val repo = repository
        if (repo == null) {
            state = state.copy(error = AppConfig.configProblem ?: "সংযুক্ত মোড কনফিগার করা নেই।")
            return
        }
        if (loginId.isBlank() || password.isEmpty()) {
            state = state.copy(error = "লগইন আইডি ও পাসওয়ার্ড দিন।")
            return
        }
        viewModelScope.launch {
            state = state.copy(loading = true, error = null)
            // Step 1: authentication
            val signIn = repo.signIn(loginId, password)
            val t = signIn.getOrNull()
            if (t == null) {
                state = state.copy(loading = false, error = signIn.exceptionOrNull()?.message ?: "লগইন ব্যর্থ হয়েছে।")
                return@launch
            }
            // Step 2: authorization (live from the backend)
            val authz = repo.fetchAuthorization(t)
            val a = authz.getOrNull()
            if (a == null) {
                repo.signOut(t)
                state = state.copy(loading = false, error = authz.exceptionOrNull()?.message ?: "অনুমতি আনা যায়নি।")
                return@launch
            }
            tokens = t
            state = SessionState(
                mode = AppMode.CONNECTED,
                profile = UserProfile(
                    name = loginId.trim(),
                    roleCodes = a.roleCodes,
                    companyName = "কোম্পানি আইডি: " + a.organizationId.take(8),
                    companyCode = a.organizationId.take(8),
                    isPreview = false,
                    permissions = a.permissions,
                    organizationId = a.organizationId,
                    employeeId = a.employeeId
                )
            )
            onSuccess()
        }
    }

    /** Clears the session immediately; the server-side sign-out is best-effort. */
    fun logout() {
        val t = tokens
        val repo = repository
        tokens = null
        selectedCompanyId = DEMO_COMPANY_1
        if (com.mohona.erp.data.demo.DemoRepository.isLoaded) com.mohona.erp.data.demo.DemoRepository.resetSimulation()
        state = SessionState(mode = state.mode)
        if (t != null && repo != null) {
            viewModelScope.launch { repo.signOut(t) }
        }
    }
}
