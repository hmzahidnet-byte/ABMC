package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.AppMode
import com.mohona.erp.data.Bn
import com.mohona.erp.data.ModuleKeys
import com.mohona.erp.data.RoleAccess
import com.mohona.erp.data.Roles
import com.mohona.erp.data.SessionState
import com.mohona.erp.data.UserProfile
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.KeyValueRow
import com.mohona.erp.ui.components.MohonaLogo
import com.mohona.erp.ui.components.PreviewBadge
import com.mohona.erp.ui.components.PreviewBanner
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.OrangeDark
import com.mohona.erp.ui.theme.OrangeSoft
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.TextMuted

@Composable
fun ProfileScreen(session: SessionState, profile: UserProfile, onLogout: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundGray)
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MohonaLogo(size = 34.dp)
            Spacer(Modifier.size(12.dp))
            Text("প্রোফাইল", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        }
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier.size(84.dp).clip(CircleShape).background(OrangeSoft),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Person, contentDescription = null, tint = OrangeDark, modifier = Modifier.size(46.dp))
                }
                Spacer(Modifier.height(8.dp))
                Text(profile.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(Roles.namesOf(profile.roleCodes), style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                Spacer(Modifier.height(6.dp))
                PreviewBadge(if (session.mode == AppMode.PREVIEW) "প্রিভিউ মোড" else "সংযুক্ত মোড (Staging)")
            }

            AppCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("ব্যবহারকারীর তথ্য", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    KeyValueRow("নাম / লগইন", profile.name)
                    KeyValueRow("ভূমিকা", Roles.namesOf(profile.roleCodes))
                    KeyValueRow("ভূমিকার কোড", if (profile.roleCodes.isEmpty()) "—" else profile.roleCodes.joinToString(", "))
                    KeyValueRow("প্রবেশের ধরন", if (profile.isPreview) "প্রিভিউ (নমুনা)" else "সংযুক্ত (Staging)")
                    if (!profile.isPreview) {
                        KeyValueRow("সার্ভার-অনুমতি", Bn.digits(profile.permissions.size.toString()) + "টি")
                        val scopes = profile.permissions.map { it.scope }.distinct().joinToString(", ")
                        KeyValueRow("পরিধি (Scope) কোড", if (scopes.isEmpty()) "—" else scopes)
                    }
                }
            }

            AppCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("কোম্পানির তথ্য", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    KeyValueRow("কোম্পানি", profile.companyName)
                    KeyValueRow("কোড", profile.companyCode)
                    KeyValueRow("লোগো", "প্লেসহোল্ডার (আসল লোগো পরে)")
                    if (profile.isPreview) KeyValueRow("তথ্যের উৎস", "নমুনা")
                }
            }

            AppCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("নিরাপত্তা-নোট", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "• প্রিভিউ ভূমিকা শুধু ডেমো-পর্দা বদলায়; কোনো ব্যাকএন্ড-অধিকার দেয় না।\n" +
                            "• প্রকৃত অনুমতি সার্ভারের RLS/RPC নিয়ন্ত্রণ করে; অ্যাপ শুধু দেখানোর ইঙ্গিত দেয়।\n" +
                            "• প্রতি কোম্পানির জন্য আলাদা লগইন; এক কোম্পানির লগইনে অন্য কোম্পানির তথ্য নেই।\n" +
                            "• কোম্পানির মধ্যে লেনদেন বন্ধ। ফ্যাক্টরি লাভ-ক্ষতি শুধু সংশ্লিষ্ট কোম্পানির এমডির।\n" +
                            "• VAT/Tax ও CCTV এই অ্যাপে নেই।",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            }

            OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text("লগআউট")
            }
            Text(
                "সংস্করণ ০.৩.০ • ফ্রন্টএন্ড ডেমো (ডেমো-তথ্য)",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

