package com.mohona.erp.domain

import java.math.BigDecimal
import java.math.RoundingMode

/**
 * Moving Weighted Average valuation (owner-approved method OD-05). The ROUNDING below (value 2 dp, unit cost 4 dp, HALF_UP) is a DEMO choice
 * and is NOT an approved policy. Issues are costed at the average at the moment of issue; returns re-enter at the batch's issue cost;
 * stock can never go negative (an attempt throws). Posted history is never recomputed.
 */
data class StockEvent(val materialId: String, val date: String, val seq: Int, val kind: String, val qty: BigDecimal, val price: BigDecimal?, val batchId: String?)
data class MaterialPosition(val qty: BigDecimal, val value: BigDecimal, val avg: BigDecimal)
data class CostingResult(val positions: Map<String, MaterialPosition>, val issueUnitCost: Map<String, BigDecimal>)

object Costing {
    private val ZERO = BigDecimal.ZERO

    fun run(events: List<StockEvent>): CostingResult {
        val qty = HashMap<String, BigDecimal>()
        val value = HashMap<String, BigDecimal>()
        val avg = HashMap<String, BigDecimal>()
        val issueUnit = HashMap<String, BigDecimal>()
        val ordered = events.sortedWith(compareBy<StockEvent> { it.date }.thenBy { it.seq })
        for (e in ordered) {
            val m = e.materialId
            val q0 = qty[m] ?: ZERO
            val v0 = value[m] ?: ZERO
            val a0 = avg[m] ?: ZERO
            when (e.kind) {
                "RECEIPT" -> {
                    val add = (e.qty.multiply(e.price ?: error("receipt without price"))).setScale(2, RoundingMode.HALF_UP)
                    val q1 = q0.add(e.qty); val v1 = v0.add(add)
                    qty[m] = q1; value[m] = v1; avg[m] = v1.divide(q1, 4, RoundingMode.HALF_UP)
                }
                "ISSUE" -> {
                    require(q0 >= e.qty) { "negative stock for $m on ${e.date}" }
                    val cost = e.qty.multiply(a0).setScale(2, RoundingMode.HALF_UP)
                    val q1 = q0.subtract(e.qty); val v1 = v0.subtract(cost)
                    issueUnit[(e.batchId ?: "") + "/" + m] = a0
                    qty[m] = q1; value[m] = v1
                    if (q1.signum() > 0) avg[m] = v1.divide(q1, 4, RoundingMode.HALF_UP)
                }
                "RETURN" -> {
                    val unit = issueUnit[(e.batchId ?: "") + "/" + m] ?: error("return without issue")
                    val add = e.qty.multiply(unit).setScale(2, RoundingMode.HALF_UP)
                    val q1 = q0.add(e.qty); val v1 = v0.add(add)
                    qty[m] = q1; value[m] = v1; avg[m] = v1.divide(q1, 4, RoundingMode.HALF_UP)
                }
                else -> error("unknown stock event kind " + e.kind)
            }
        }
        val positions = HashMap<String, MaterialPosition>()
        for (m in qty.keys) positions[m] = MaterialPosition(qty[m] ?: ZERO, value[m] ?: ZERO, avg[m] ?: ZERO)
        return CostingResult(positions, issueUnit)
    }

    /** Material cost per Poly = actual consumed material cost / accepted Poly. NULL (never a division by zero) when nothing was accepted. */
    fun materialCostPerPoly(consumedCost: BigDecimal, acceptedPoly: BigDecimal): BigDecimal? =
        if (acceptedPoly.signum() <= 0) null else consumedCost.divide(acceptedPoly, 2, RoundingMode.HALF_UP)

    fun consumedCost(consumed: Map<String, BigDecimal>, batchId: String, issueUnit: Map<String, BigDecimal>): BigDecimal {
        var total = ZERO
        for ((m, q) in consumed) {
            val unit = issueUnit[batchId + "/" + m] ?: error("no issue cost for $batchId/$m")
            total = total.add(q.multiply(unit).setScale(2, RoundingMode.HALF_UP))
        }
        return total
    }
}
