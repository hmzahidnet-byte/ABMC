package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.Bn
import com.mohona.erp.data.demo.DemoRepository
import com.mohona.erp.domain.RecordRef
import com.mohona.erp.domain.RecordType
import com.mohona.erp.domain.UserContext
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.BnDate
import com.mohona.erp.ui.components.DateFilter
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.FilterChips
import com.mohona.erp.ui.components.PreviewBanner
import com.mohona.erp.ui.components.RecordCard
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.SearchField
import com.mohona.erp.ui.components.UniversalCalendar
import com.mohona.erp.ui.components.rememberActionController
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.TextMuted

/** Level 4: searchable, filterable list of ONE record type. Each card opens the canonical Record Dashboard. */
@Composable
fun RecordListScreen(type: RecordType, ctx: UserContext, onBack: () -> Unit, onOpen: (RecordRef) -> Unit, onShowQr: (RecordRef) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var statusFilter by rememberSaveable { mutableStateOf<String?>(null) }
    var useDate by rememberSaveable { mutableStateOf(false) }
    var filter by remember { mutableStateOf(BnDate.monthOf(DemoRepository.demoDate)) }
    val controller = rememberActionController(ctx, onShowQr) { onOpen(it) }

    val all = DemoRepository.list(type, ctx)
    val statuses = all.map { DemoRepository.statusOf(it).nameBn }.distinct()
    val dated = type.kind != com.mohona.erp.domain.RecordKind.ENTITY
    val q = query.trim().lowercase()
    val shown = all.filter { r ->
        (q.isEmpty() || r.title.lowercase().contains(q) || r.reference.lowercase().contains(q) || r.subtitle.lowercase().contains(q)) &&
            (statusFilter == null || DemoRepository.statusOf(r).nameBn == statusFilter) &&
            (!useDate || (r.date != null && filter.contains(r.date!!)))
    }
    val activity = all.mapNotNull { it.date }.toSet()

    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
        Box(modifier = Modifier.background(Color.White)) { ScreenHeader(title = type.pluralBn, onBack = onBack) }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { PreviewBanner("ডেমো-তালিকা • " + DemoRepository.companyName(ctx.companyId)) }
            item { SearchField(query, { query = it }, "নাম, আইডি বা রেফারেন্স দিয়ে খুঁজুন") }
            if (statuses.size > 1) item { FilterChips(statuses, statusFilter) { statusFilter = it } }
            if (dated) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { useDate = !useDate }) { Text(if (useDate) "তারিখ-ফিল্টার বন্ধ করুন" else "তারিখ দিয়ে ছাঁকুন") }
                    }
                }
                if (useDate) item { AppCard { Column(modifier = Modifier.padding(14.dp)) { UniversalCalendar(filter, activity, { filter = it }, summaryText = Bn.digits(shown.size.toString()) + "টি রেকর্ড") } } }
            }
            item { Text(Bn.digits(shown.size.toString()) + "টি রেকর্ড", style = MaterialTheme.typography.labelMedium, color = TextMuted) }
            if (all.isEmpty()) item { EmptyState("এই ভূমিকা ও কোম্পানির জন্য দেখানোর মতো কোনো রেকর্ড নেই।") }
            else if (shown.isEmpty()) item { EmptyState("খোঁজ বা ফিল্টারের সাথে মিলছে এমন কোনো রেকর্ড নেই।") }
            items(shown, key = { it.ref.key }) { rec -> RecordCard(rec, ctx, controller, onOpen) }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
    controller.Dialogs()
}
