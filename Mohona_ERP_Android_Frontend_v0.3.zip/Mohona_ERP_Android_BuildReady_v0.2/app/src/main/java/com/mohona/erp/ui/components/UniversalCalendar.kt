package com.mohona.erp.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.Bn
import com.mohona.erp.ui.theme.DividerGray
import com.mohona.erp.ui.theme.OrangeDark
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.OrangeSoft
import com.mohona.erp.ui.theme.TextMuted
import java.time.LocalDate
import java.time.YearMonth

/**
 * The ONE calendar / date filter used by every module (dashboard, lists, reports).
 * Daily, weekly, monthly and custom-range selection; Saturday-first Bengali calendar; an orange dot marks days that have activity
 * (activity comes from real, permission-filtered repository data, never from a constant).
 */
@Composable
fun UniversalCalendar(
    filter: DateFilter,
    activityDates: Set<LocalDate>,
    onChange: (DateFilter) -> Unit,
    modifier: Modifier = Modifier,
    summaryText: String? = null
) {
    var shown by remember { mutableStateOf(YearMonth.from(filter.start)) }
    var pendingStart by remember { mutableStateOf<LocalDate?>(null) }

    Column(modifier = modifier.fillMaxWidth()) {
        // mode selector
        Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(com.mohona.erp.ui.theme.BackgroundGray).padding(3.dp)) {
            CalendarMode.values().forEach { m ->
                val sel = m == filter.mode
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (sel) Color.White else Color.Transparent)
                        .clickable {
                            pendingStart = null
                            val base = filter.start
                            onChange(
                                when (m) {
                                    CalendarMode.DAY -> BnDate.dayOf(base)
                                    CalendarMode.WEEK -> BnDate.weekOf(base)
                                    CalendarMode.MONTH -> BnDate.monthOf(base)
                                    CalendarMode.RANGE -> DateFilter(CalendarMode.RANGE, filter.start, filter.end)
                                }
                            )
                        }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(m.nameBn, style = MaterialTheme.typography.labelMedium, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, color = if (sel) OrangeDark else TextMuted)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        // month navigation
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { shown = shown.minusMonths(1) }) { Icon(Icons.Filled.KeyboardArrowLeft, contentDescription = "আগের মাস") }
            Text(BnDate.formatMonth(shown), modifier = Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            IconButton(onClick = { shown = shown.plusMonths(1) }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "পরের মাস") }
        }
        Row(modifier = Modifier.fillMaxWidth()) {
            BnDate.weekdaysSatFirst.forEach { w ->
                Text(w, modifier = Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelSmall, color = TextMuted, maxLines = 1)
            }
        }
        Spacer(Modifier.height(4.dp))
        val first = shown.atDay(1)
        val offset = BnDate.satIndex(first.dayOfWeek)
        val days = shown.lengthOfMonth()
        val rows = (offset + days + 6) / 7
        for (r in 0 until rows) {
            Row(modifier = Modifier.fillMaxWidth()) {
                for (c in 0 until 7) {
                    val dayNo = r * 7 + c - offset + 1
                    if (dayNo < 1 || dayNo > days) {
                        Spacer(Modifier.weight(1f).aspectRatio(1f))
                    } else {
                        val date = shown.atDay(dayNo)
                        DayCell(
                            date = date,
                            selected = filter.contains(date),
                            edge = date == filter.start || date == filter.end,
                            hasActivity = date in activityDates,
                            modifier = Modifier.weight(1f)
                        ) {
                            when (filter.mode) {
                                CalendarMode.DAY -> onChange(BnDate.dayOf(date))
                                CalendarMode.WEEK -> onChange(BnDate.weekOf(date))
                                CalendarMode.MONTH -> onChange(BnDate.monthOf(date))
                                CalendarMode.RANGE -> {
                                    val ps = pendingStart
                                    if (ps == null) {
                                        pendingStart = date
                                        onChange(DateFilter(CalendarMode.RANGE, date, date))
                                    } else {
                                        pendingStart = null
                                        onChange(if (date.isBefore(ps)) DateFilter(CalendarMode.RANGE, date, ps) else DateFilter(CalendarMode.RANGE, ps, date))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(OrangePrimary))
            Spacer(Modifier.size(6.dp))
            Text("উৎপাদন/কার্যক্রম আছে", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        }
        Text(
            text = "নির্বাচিত: " + BnDate.formatFilter(filter) + (if (filter.mode == CalendarMode.RANGE && pendingStart != null) " (শেষ তারিখ বেছে নিন)" else ""),
            style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = OrangeDark, modifier = Modifier.padding(top = 6.dp)
        )
        if (summaryText != null) Text(summaryText, style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Text("ব্যবসায়িক তারিখ: Asia/Dhaka • ইতিহাস-দেখা মানে সম্পাদনার অনুমতি নয়", style = MaterialTheme.typography.labelSmall, color = TextMuted, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun DayCell(date: LocalDate, selected: Boolean, edge: Boolean, hasActivity: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .aspectRatio(1f)
            .padding(1.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (edge) OrangePrimary else if (selected) OrangeSoft else Color.Transparent)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = Bn.digits(date.dayOfMonth.toString()),
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (edge) FontWeight.Bold else FontWeight.Normal,
            color = if (edge) Color.White else MaterialTheme.colorScheme.onSurface
        )
        Box(modifier = Modifier.padding(top = 2.dp).size(5.dp).clip(CircleShape).background(if (hasActivity) (if (edge) Color.White else OrangePrimary) else Color.Transparent))
    }
}
