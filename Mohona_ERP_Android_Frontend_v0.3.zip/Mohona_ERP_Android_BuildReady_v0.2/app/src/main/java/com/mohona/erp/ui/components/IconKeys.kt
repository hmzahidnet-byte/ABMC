package com.mohona.erp.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Factory
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storage
import androidx.compose.ui.graphics.vector.ImageVector

/** Registry icon keys -> vectors (keeps the domain layer free of UI types). */
fun iconForKey(key: String): ImageVector = when (key) {
    "factory" -> Icons.Filled.Factory
    "inventory" -> Icons.Filled.Inventory2
    "people" -> Icons.Filled.People
    "payments" -> Icons.Filled.Payments
    "science" -> Icons.Filled.Science
    "build" -> Icons.Filled.Build
    "receipt" -> Icons.Filled.Receipt
    "storage" -> Icons.Filled.Storage
    "shopping" -> Icons.Filled.ShoppingCart
    "check" -> Icons.Filled.CheckCircle
    "qr" -> Icons.Filled.QrCodeScanner
    "report", "trend" -> Icons.Filled.Assessment
    "person" -> Icons.Filled.Person
    "calendar" -> Icons.Filled.CalendarMonth
    else -> Icons.Filled.Description
}
