package com.mohona.erp.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mohona.erp.R
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.ChartBlue
import com.mohona.erp.ui.theme.DividerGray
import com.mohona.erp.ui.theme.GoodGreen
import com.mohona.erp.ui.theme.OrangeDark
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.OrangeSoft
import com.mohona.erp.ui.theme.TextMuted
import com.mohona.erp.ui.theme.WarnAmber

/** Company logo. Placeholder drawable: replace res/drawable/mohona_logo.xml with the real logo. */
@Composable
fun MohonaLogo(size: Dp = 40.dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(id = R.drawable.mohona_logo),
        contentDescription = "মোহনা লোগো",
        modifier = modifier.size(size)
    )
}

/** Header used on every inner screen: back button + title. */
@Composable
fun ScreenHeader(title: String, onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে")
        }
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f)
        )
        trailing()
    }
}

/** Small label shown on every piece of sample/demo content. */
@Composable
fun PreviewBadge(text: String = "নমুনা তথ্য", modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(OrangeSoft)
            .padding(horizontal = 10.dp, vertical = 3.dp)
    ) {
        Text(text = text, style = MaterialTheme.typography.labelSmall, color = OrangeDark, fontWeight = FontWeight.Medium)
    }
}

enum class Tone { NEUTRAL, GOOD, WARN, BAD, INFO }

@Composable
fun StatusPill(text: String, tone: Tone = Tone.NEUTRAL) {
    val color = when (tone) {
        Tone.GOOD -> GoodGreen
        Tone.WARN -> WarnAmber
        Tone.BAD -> BadRed
        Tone.INFO -> ChartBlue
        Tone.NEUTRAL -> TextMuted
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 10.dp, vertical = 3.dp)
    ) {
        Text(text = text, style = MaterialTheme.typography.labelSmall, color = color, fontWeight = FontWeight.Medium)
    }
}

/** Banner explaining that content is sample data and nothing is saved or posted. */
@Composable
fun PreviewBanner(
    text: String = "এটি নমুনা তথ্যসহ প্রিভিউ। কোনো বাস্তব লেনদেন সংরক্ষণ বা পোস্ট হয় না।",
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(OrangeSoft)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Info, contentDescription = null, tint = OrangeDark, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(text = text, style = MaterialTheme.typography.bodySmall, color = OrangeDark)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = modifier.padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
fun AppCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val base = modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(18.dp))
    val cardModifier = if (onClick != null) base.clickable(onClick = onClick) else base
    Card(
        modifier = cardModifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        content()
    }
}

/** Summary card with a coloured icon chip. */
@Composable
fun SummaryCard(
    title: String,
    value: String,
    caption: String,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    AppCard(modifier = modifier) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(OrangeSoft),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = OrangePrimary, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.weight(1f))
                PreviewBadge()
            }
            Spacer(Modifier.height(10.dp))
            Text(text = title, style = MaterialTheme.typography.labelMedium, color = TextMuted)
            Text(text = value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(text = caption, style = MaterialTheme.typography.labelSmall, color = TextMuted)
        }
    }
}

@Composable
fun Hairline(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(DividerGray)
    )
}

@Composable
fun ColumnSpacer(h: Dp = 12.dp) {
    Spacer(Modifier.height(h))
}

@Composable
fun KeyValueRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = TextMuted)
        Spacer(Modifier.width(12.dp))
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun GrayBackground(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier = modifier.background(BackgroundGray)) { content() }
}

/** Loading / empty / error states used by list screens and (later) every backend-backed screen. */
@Composable
fun LoadingState(message: String = "লোড হচ্ছে…", modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator(color = OrangePrimary, modifier = Modifier.size(32.dp))
        Spacer(Modifier.height(12.dp))
        Text(text = message, style = MaterialTheme.typography.bodyMedium, color = TextMuted, textAlign = TextAlign.Center)
    }
}

@Composable
fun EmptyState(message: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.size(56.dp).clip(CircleShape).background(OrangeSoft),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Info, contentDescription = null, tint = OrangeDark)
        }
        Spacer(Modifier.height(12.dp))
        Text(text = message, style = MaterialTheme.typography.bodyMedium, color = TextMuted, textAlign = TextAlign.Center)
    }
}

@Composable
fun ErrorState(message: String, onRetry: (() -> Unit)? = null, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = message, style = MaterialTheme.typography.bodyMedium, color = BadRed, textAlign = TextAlign.Center)
        if (onRetry != null) {
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onRetry) { Text("আবার চেষ্টা করুন") }
        }
    }
}

/** Single-line text that never overflows its row on small screens. */
@Composable
fun EllipsisText(text: String, modifier: Modifier = Modifier, color: Color = Color.Unspecified) {
    Text(text = text, modifier = modifier, color = color, maxLines = 1, overflow = TextOverflow.Ellipsis)
}
