package com.mohona.erp.data

import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Result of AUTHENTICATION (who you are). Kept in memory only; never written to disk in v0.2. */
class AuthTokens(val accessToken: String, val refreshToken: String?)

/** Result of AUTHORIZATION (what the backend lets this login do), read live from the server. */
data class ConnectedAuthorization(
    val employeeId: String,
    val organizationId: String,
    val roleCodes: List<String>,
    val permissions: List<PermissionGrant>
)

enum class AuthFailureKind { INVALID_CREDENTIALS, NO_ACTIVE_ACCOUNT, BACKEND_NOT_READY, NETWORK, SERVER }

class AuthFailure(val kind: AuthFailureKind, message: String) : Exception(message)

interface AuthRepository {
    suspend fun signIn(loginId: String, password: String): Result<AuthTokens>
    suspend fun fetchAuthorization(tokens: AuthTokens): Result<ConnectedAuthorization>
    suspend fun signOut(tokens: AuthTokens)
}

/**
 * Connected-development repository against Supabase Staging, using ONLY the public anon key.
 * - The user types the exact login ID that was provisioned for THIS company account (OD-02). The app does not
 *   derive e-mail addresses from company codes.
 * - Authentication (signIn) and authorization (fetchAuthorization -> api.v1_get_my_permissions) are separate steps.
 */
class SupabaseAuthRepository(
    private val baseUrl: String,
    private val anonKey: String
) : AuthRepository {

    override suspend fun signIn(loginId: String, password: String): Result<AuthTokens> =
        withContext(Dispatchers.IO) {
            try {
                val json = post(
                    "/auth/v1/token?grant_type=password",
                    JSONObject().put("email", loginId.trim()).put("password", password),
                    bearer = null,
                    schema = null
                )
                val access = json.getString("access_token")
                val refresh = if (json.has("refresh_token")) json.optString("refresh_token") else null
                Result.success(AuthTokens(access, refresh))
            } catch (e: ApiException) {
                Result.failure<AuthTokens>(
                    if (e.httpCode == 400 || e.httpCode == 401 || e.httpCode == 422) {
                        AuthFailure(
                            AuthFailureKind.INVALID_CREDENTIALS,
                            "এই লগইন আইডি ও পাসওয়ার্ডে কোনো অ্যাকাউন্ট পাওয়া যায়নি। অ্যাকাউন্ট প্রদান (Provisioning) হয়েছে কি না প্রশাসকের কাছে যাচাই করুন।"
                        )
                    } else {
                        AuthFailure(AuthFailureKind.SERVER, "সার্ভার ত্রুটি (কোড " + e.httpCode + ")।")
                    }
                )
            } catch (e: Exception) {
                Result.failure<AuthTokens>(networkFailure())
            }
        }

    override suspend fun fetchAuthorization(tokens: AuthTokens): Result<ConnectedAuthorization> =
        withContext(Dispatchers.IO) {
            try {
                val perms = post("/rest/v1/rpc/v1_get_my_permissions", JSONObject(), bearer = tokens.accessToken, schema = "api")
                if (perms.has("error")) {
                    Result.failure<ConnectedAuthorization>(
                        AuthFailure(
                            AuthFailureKind.NO_ACTIVE_ACCOUNT,
                            "প্রমাণীকরণ সফল, কিন্তু এই লগইন কোনো সক্রিয় কোম্পানি-কর্মী অ্যাকাউন্টের সাথে যুক্ত নয় (অথবা অ্যাকাউন্ট, কর্মী বা কোম্পানি সক্রিয় নয়)।"
                        )
                    )
                } else {
                    val roles = ArrayList<String>()
                    val ra = perms.optJSONArray("roles")
                    if (ra != null) for (i in 0 until ra.length()) roles.add(ra.optString(i))
                    val grants = ArrayList<PermissionGrant>()
                    val pa: JSONArray? = perms.optJSONArray("permissions")
                    if (pa != null) {
                        for (i in 0 until pa.length()) {
                            val o = pa.optJSONObject(i)
                            if (o != null) grants.add(PermissionGrant(o.optString("code"), o.optString("scope")))
                        }
                    }
                    Result.success(
                        ConnectedAuthorization(
                            employeeId = perms.optString("employee_id"),
                            organizationId = perms.optString("organization_id"),
                            roleCodes = roles,
                            permissions = grants
                        )
                    )
                }
            } catch (e: ApiException) {
                Result.failure<ConnectedAuthorization>(
                    when (e.httpCode) {
                        404 -> AuthFailure(AuthFailureKind.BACKEND_NOT_READY, "সার্ভারে অনুমতি-ফাংশন পাওয়া যায়নি। ব্যাকএন্ড Migration Staging-এ প্রয়োগ হয়েছে কি না দেখুন।")
                        401, 403 -> AuthFailure(AuthFailureKind.NO_ACTIVE_ACCOUNT, "সেশন বৈধ নয় বা অনুমতি নেই। আবার লগইন করুন।")
                        else -> AuthFailure(AuthFailureKind.SERVER, "সার্ভার ত্রুটি (কোড " + e.httpCode + ")।")
                    }
                )
            } catch (e: Exception) {
                Result.failure<ConnectedAuthorization>(networkFailure())
            }
        }

    /** Ends THIS device's session on the server (scope=local). Failures are ignored: the app clears local state anyway. */
    override suspend fun signOut(tokens: AuthTokens) {
        withContext(Dispatchers.IO) {
            try {
                post("/auth/v1/logout?scope=local", null, bearer = tokens.accessToken, schema = null, allowEmpty = true)
            } catch (e: Exception) {
                // intentionally ignored
            }
        }
    }

    private fun networkFailure(): AuthFailure =
        AuthFailure(AuthFailureKind.NETWORK, "সার্ভারের সাথে যোগাযোগ করা যায়নি। ইন্টারনেট ও কনফিগারেশন দেখুন।")

    private fun post(path: String, body: JSONObject?, bearer: String?, schema: String?, allowEmpty: Boolean = false): JSONObject {
        val conn = URL(baseUrl + path).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.doOutput = true
            conn.setRequestProperty("apikey", anonKey)
            conn.setRequestProperty("Content-Type", "application/json")
            if (bearer != null) conn.setRequestProperty("Authorization", "Bearer $bearer")
            if (schema != null) {
                conn.setRequestProperty("Content-Profile", schema)
                conn.setRequestProperty("Accept-Profile", schema)
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body?.toString() ?: "{}") }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw ApiException(code, text)
            if (text.isBlank() && allowEmpty) return JSONObject()
            return JSONObject(text)
        } finally {
            conn.disconnect()
        }
    }
}

class ApiException(val httpCode: Int, message: String) : Exception(message)
