package com.mohona.erp.ui.theme

import androidx.compose.ui.graphics.Color

val OrangePrimary = Color(0xFFF36B21)
val OrangeDark = Color(0xFFD9550C)
val OrangeSoft = Color(0xFFFFF0E5)
val BackgroundWhite = Color(0xFFFFFFFF)
val BackgroundGray = Color(0xFFF4F5F7)
val TextDark = Color(0xFF1F2430)
val TextMuted = Color(0xFF6B7280)
val DividerGray = Color(0xFFE5E7EB)
val GoodGreen = Color(0xFF2E9E5B)
val WarnAmber = Color(0xFFE8A317)
val BadRed = Color(0xFFD64545)
val ChartBlue = Color(0xFF3B82F6)
val ChartTeal = Color(0xFF14B8A6)
