package com.mohona.erp.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.demo.DemoRepository
import com.mohona.erp.domain.Access
import com.mohona.erp.domain.AccessPolicy
import com.mohona.erp.domain.RecordRef
import com.mohona.erp.domain.UserContext
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.ErrorState
import com.mohona.erp.ui.components.KeyValueRow
import com.mohona.erp.ui.components.PermissionDeniedState
import com.mohona.erp.ui.components.PreviewBanner
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.SectionCard
import com.mohona.erp.ui.components.StatusBadge
import com.mohona.erp.ui.components.TimelineView
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.TextDark
import com.mohona.erp.ui.theme.TextMuted

/**
 * Scan tab. The camera scanner is NOT part of this build (button disabled). A token can be typed or picked from the demo list;
 * resolution is local to the demo and always followed by an authorization check, because a QR token never grants access by itself.
 */
@Composable
fun ScannerScreen(onOpenCode: (String) -> Unit) {
    var manual by remember { mutableStateOf("") }
    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray).verticalScroll(rememberScrollState())) {
        Box(modifier = Modifier.background(Color.White).fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp)) {
            Text("স্ক্যান", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        }
        Column(modifier = Modifier.padding(16.dp)) {
            Box(modifier = Modifier.fillMaxWidth().height(240.dp).clip(RoundedCornerShape(22.dp)).background(TextDark), contentAlignment = Alignment.Center) {
                Canvas(modifier = Modifier.size(190.dp)) {
                    val len = 36.dp.toPx(); val sw = 5.dp.toPx(); val w = size.width; val h = size.height
                    fun corner(x: Float, y: Float, dx: Float, dy: Float) {
                        drawRoundRect(OrangePrimary, Offset(minOf(x, x + dx * len), y - sw / 2), Size(len, sw), CornerRadius(sw))
                        drawRoundRect(OrangePrimary, Offset(x - sw / 2, minOf(y, y + dy * len)), Size(sw, len), CornerRadius(sw))
                    }
                    corner(0f, 0f, 1f, 1f); corner(w, 0f, -1f, 1f); corner(0f, h, 1f, -1f); corner(w, h, -1f, -1f)
                }
                Text("ক্যামেরা-স্ক্যানার এই সংস্করণে নেই", color = Color.White, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 48.dp))
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("ক্যামেরা চালু করুন (শীঘ্রই)") }
            Spacer(Modifier.height(16.dp))
            AppCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("QR-টোকেন লিখুন", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = manual, onValueChange = { manual = it }, label = { Text("QR-টোকেন") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { onOpenCode(manual.trim()) }, enabled = manual.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("সমাধান করুন") }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("ডেমো QR-টোকেন (ট্যাপ করুন)", style = MaterialTheme.typography.labelLarge, color = TextMuted)
            Spacer(Modifier.height(6.dp))
            listOf("QR-BAT-001" to "উৎপাদন ব্যাচ B-001", "QR-EMP-7311" to "কর্মী (রহিম উদ্দিন)", "QR-PRD-4201" to "পণ্য (ক্লাসিক)", "QR-PRD-C2-001" to "অন্য কোম্পানির পণ্য (অনুমতি-পরীক্ষা)", "QR-UNKNOWN-1" to "অজানা টোকেন (ত্রুটি-পরীক্ষা)").forEach { (tok, label) ->
                OutlinedButton(onClick = { onOpenCode(tok) }, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) { Text(label + " • " + tok, maxLines = 1) }
            }
            Spacer(Modifier.height(12.dp))
            PreviewBanner("QR শুধু রেকর্ড চিহ্নিত করে। অনুমোদন, পোস্টিং বা নিরাপত্তা-নিয়ম এড়ায় না; খোলার আগে অনুমতি-যাচাই হয়।")
        }
    }
}

/** Journey F: QR token -> resolved preview (non-sensitive) -> authorised detail dashboard -> related history. */
@Composable
fun QrPreviewScreen(token: String, ctx: UserContext, onBack: () -> Unit, onOpenRecord: (RecordRef) -> Unit) {
    val ref = DemoRepository.qrTarget(token)
    val rec = ref?.let { DemoRepository.get(it) }
    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray)) {
        Box(modifier = Modifier.background(Color.White)) { ScreenHeader(title = "QR-ফল", onBack = onBack) }
        if (rec == null) {
            ErrorState("এই QR-টোকেন চেনা যায়নি বা বাতিল। রেকর্ড খোলা হয়নি।")
            return@Column
        }
        val access = AccessPolicy.canOpen(rec, ctx)
        if (access != Access.ALLOWED) {
            PermissionDeniedState(if (access == Access.WRONG_COMPANY) "এই QR অন্য কোম্পানির রেকর্ডের। কোনো তথ্য দেখানো হয়নি।" else "এই QR-এর রেকর্ড দেখার অনুমতি নেই। কোনো তথ্য দেখানো হয়নি।")
            return@Column
        }
        Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)) {
            PreviewBanner("ডেমো-সমাধান: প্রিভিউ শুধু অ-সংবেদনশীল তথ্য দেখায়; পূর্ণ বিবরণ অনুমতি-যাচাইয়ের পর।")
            SectionCard("সমাধানকৃত রেকর্ড") {
                Text(rec.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) { StatusBadge(DemoRepository.statusOf(rec)) }
                KeyValueRow("ধরন", rec.ref.type.nameBn)
                KeyValueRow("রেফারেন্স", rec.reference)
                KeyValueRow("কোম্পানি", DemoRepository.companyName(rec.companyId))
                KeyValueRow("QR-টোকেন", token)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { onOpenRecord(rec.ref) }, modifier = Modifier.fillMaxWidth()) { Text("পূর্ণ বিবরণ খুলুন") }
            }
            SectionCard("সম্পর্কিত ইতিহাস (সাম্প্রতিক)") { TimelineView(DemoRepository.historyOf(rec).takeLast(3), "ইতিহাস নেই।") }
        }
    }
}
