package com.mohona.erp.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Light theme only. Dark mode is intentionally disabled (owner decision).
private val MohonaColors = lightColorScheme(
    primary = OrangePrimary,
    onPrimary = Color.White,
    primaryContainer = OrangeSoft,
    onPrimaryContainer = OrangeDark,
    secondary = OrangeDark,
    onSecondary = Color.White,
    secondaryContainer = OrangeSoft,
    onSecondaryContainer = OrangeDark,
    background = BackgroundWhite,
    onBackground = TextDark,
    surface = BackgroundWhite,
    onSurface = TextDark,
    surfaceVariant = BackgroundGray,
    onSurfaceVariant = TextMuted,
    outline = DividerGray,
    error = BadRed,
    onError = Color.White
)

@Composable
fun MohonaTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = Color.White.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = true
            }
        }
    }
    MaterialTheme(
        colorScheme = MohonaColors,
        typography = Typography(),
        content = content
    )
}
