package com.mohona.erp.data

import java.util.Locale
import kotlin.math.abs

/** Bangla digit and Taka formatting helpers. */
object Bn {
    private val digitMap = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

    fun digits(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            if (c in '0'..'9') sb.append(digitMap[c - '0']) else sb.append(c)
        }
        return sb.toString()
    }

    /** South-Asian grouping: 12,34,567 */
    fun num(n: Long): String {
        val neg = n < 0
        val s = abs(n).toString()
        val grouped: String = if (s.length <= 3) {
            s
        } else {
            val last3 = s.takeLast(3)
            var rest = s.dropLast(3)
            val parts = ArrayList<String>()
            while (rest.length > 2) {
                parts.add(0, rest.takeLast(2))
                rest = rest.dropLast(2)
            }
            if (rest.isNotEmpty()) parts.add(0, rest)
            parts.joinToString(",") + "," + last3
        }
        return digits((if (neg) "-" else "") + grouped)
    }

    fun dec(d: Double, places: Int = 1): String =
        digits(String.format(Locale.US, "%." + places + "f", d))

    fun taka(n: Long): String = "৳ " + num(n)
}
