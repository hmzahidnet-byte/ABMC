package com.mohona.erp.ui.navigation

import android.net.Uri
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mohona.erp.data.SessionViewModel
import com.mohona.erp.data.demo.DemoRepository
import com.mohona.erp.domain.RecordRef
import com.mohona.erp.domain.RecordType
import com.mohona.erp.domain.UserContext
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.screens.ApprovalCenterScreen
import com.mohona.erp.ui.screens.ChairmanScreen
import com.mohona.erp.ui.screens.GlobalHomeScreen
import com.mohona.erp.ui.screens.LoginScreen
import com.mohona.erp.ui.screens.ModuleDashboardScreen
import com.mohona.erp.ui.screens.NotificationCenterScreen
import com.mohona.erp.ui.screens.ProfileScreen
import com.mohona.erp.ui.screens.QrPreviewScreen
import com.mohona.erp.ui.screens.RecordDashboardScreen
import com.mohona.erp.ui.screens.RecordListScreen
import com.mohona.erp.ui.screens.ReportCenterScreen
import com.mohona.erp.ui.screens.ReportPreviewScreen
import com.mohona.erp.ui.screens.ScannerScreen
import com.mohona.erp.ui.screens.SearchScreen
import com.mohona.erp.ui.screens.WingDashboardScreen

/**
 * Stable route identity for the whole app. A record is ALWAYS opened through [RECORD_PATTERN] (type + id), so one canonical dashboard serves
 * every entry point (lists, related links, search, notifications, QR, reports). Company context travels with the session, not the URL.
 */
object Routes {
    const val LOGIN = "login"
    const val HOME = "home"
    const val SEARCH = "search"
    const val SCAN = "scan"
    const val REPORTS = "reports"
    const val PROFILE = "profile"
    const val NOTIFICATIONS = "notifications"
    const val APPROVALS = "approvals"
    const val CHAIRMAN = "chairman"

    const val WING_PATTERN = "wing/{wingId}"
    const val MODULE_PATTERN = "module/{wingId}/{moduleId}"
    const val LIST_PATTERN = "list/{typeCode}"
    const val RECORD_PATTERN = "record/{typeCode}/{id}"
    const val REPORT_PATTERN = "report/{reportId}"
    const val QR_PATTERN = "qr/{token}"

    fun wing(id: String) = "wing/" + Uri.encode(id)
    fun module(wingId: String, moduleId: String) = "module/" + Uri.encode(wingId) + "/" + Uri.encode(moduleId)
    fun list(type: RecordType) = "list/" + type.code
    fun record(ref: RecordRef) = "record/" + ref.type.code + "/" + Uri.encode(ref.id)
    fun report(id: String) = "report/" + Uri.encode(id)
    fun qr(token: String) = "qr/" + Uri.encode(token)
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab(Routes.HOME, "হোম", Icons.Filled.Home),
    Tab(Routes.SEARCH, "অনুসন্ধান", Icons.Filled.Search),
    Tab(Routes.SCAN, "স্ক্যান", Icons.Filled.QrCodeScanner),
    Tab(Routes.REPORTS, "রিপোর্ট", Icons.Filled.Assessment),
    Tab(Routes.PROFILE, "প্রোফাইল", Icons.Filled.Person)
)

private fun NavController.goToTab(route: String) {
    navigate(route) {
        popUpTo(Routes.HOME) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun MohonaApp() {
    val session: SessionViewModel = viewModel()
    val nav = rememberNavController()
    val backStackEntry by nav.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBar = tabs.any { it.route == currentRoute }
    val state = session.state
    val ctx = session.userContext()

    val openRecord: (RecordRef) -> Unit = { nav.navigate(Routes.record(it)) }
    val showQr: (RecordRef) -> Unit = { ref -> DemoRepository.get(ref)?.qrToken?.let { nav.navigate(Routes.qr(it)) } }

    Scaffold(
        containerColor = Color.White,
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = Color.White) {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = currentRoute == t.route,
                            onClick = { nav.goToTab(t.route) },
                            icon = { Icon(t.icon, contentDescription = t.label) },
                            label = { Text(t.label, maxLines = 1) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(navController = nav, startDestination = Routes.LOGIN, modifier = Modifier.padding(padding)) {
            composable(Routes.LOGIN) {
                LoginScreen(
                    session = state,
                    onSelectMode = { session.selectMode(it) },
                    onStartPreview = { primary, secondary ->
                        session.startPreview(primary, secondary)
                        nav.navigate(Routes.HOME) { popUpTo(Routes.LOGIN) { inclusive = true } }
                    },
                    onConnectedLogin = { loginId, password ->
                        session.loginConnected(loginId, password) {
                            nav.navigate(Routes.HOME) { popUpTo(Routes.LOGIN) { inclusive = true } }
                        }
                    }
                )
            }
            composable(Routes.HOME) {
                Guard(ctx, nav) { c ->
                    GlobalHomeScreen(
                        ctx = c, authorizedCompanyIds = session.authorizedCompanyIds(), isPreview = c.isPreview,
                        unreadNotifications = DemoRepository.notifications.size,
                        onOpenWing = { nav.navigate(Routes.wing(it)) },
                        onSearch = { nav.goToTab(Routes.SEARCH) },
                        onNotifications = { nav.navigate(Routes.NOTIFICATIONS) },
                        onProfile = { nav.goToTab(Routes.PROFILE) },
                        onChairman = { nav.navigate(Routes.CHAIRMAN) },
                        onSelectCompany = { session.selectCompany(it) }
                    )
                }
            }
            composable(Routes.SEARCH) { Guard(ctx, nav) { c -> SearchScreen(c, { nav.goToTab(Routes.HOME) }, openRecord, showQr) } }
            composable(Routes.SCAN) { Guard(ctx, nav) { _ -> ScannerScreen { token -> nav.navigate(Routes.qr(token)) } } }
            composable(Routes.REPORTS) { Guard(ctx, nav) { c -> ReportCenterScreen(c, null) { nav.navigate(Routes.report(it)) } } }
            composable(Routes.PROFILE) {
                Guard(ctx, nav) { _ ->
                    val p = state.profile
                    if (p != null) ProfileScreen(state, p) {
                        session.logout()
                        nav.navigate(Routes.LOGIN) { popUpTo(nav.graph.id) { inclusive = true } }
                    }
                }
            }
            composable(Routes.NOTIFICATIONS) { Guard(ctx, nav) { c -> NotificationCenterScreen(c, { nav.popBackStack() }, openRecord) } }
            composable(Routes.APPROVALS) { Guard(ctx, nav) { c -> ApprovalCenterScreen(c, { nav.popBackStack() }, openRecord, showQr) } }
            composable(Routes.CHAIRMAN) {
                Guard(ctx, nav) { c ->
                    ChairmanScreen(c, session.authorizedCompanyIds(), { nav.popBackStack() }, { session.selectCompany(it) }) { nav.navigate(Routes.wing("mfg")) }
                }
            }
            composable(Routes.WING_PATTERN, arguments = listOf(navArgument("wingId") { type = NavType.StringType })) { e ->
                val id = e.arguments?.getString("wingId") ?: ""
                Guard(ctx, nav) { c ->
                    WingDashboardScreen(
                        wingId = id, ctx = c, onBack = { nav.popBackStack() },
                        onOpenModule = { w, m -> nav.navigate(Routes.module(w, m)) },
                        onOpenList = { nav.navigate(Routes.list(it)) },
                        onOpenRecord = openRecord,
                        onSearch = { nav.goToTab(Routes.SEARCH) },
                        onNotifications = { nav.navigate(Routes.NOTIFICATIONS) },
                        onApprovals = { nav.navigate(Routes.APPROVALS) },
                        onReports = { nav.goToTab(Routes.REPORTS) }
                    )
                }
            }
            composable(Routes.MODULE_PATTERN, arguments = listOf(navArgument("wingId") { type = NavType.StringType }, navArgument("moduleId") { type = NavType.StringType })) { e ->
                val w = e.arguments?.getString("wingId") ?: ""
                val m = e.arguments?.getString("moduleId") ?: ""
                Guard(ctx, nav) { c -> ModuleDashboardScreen(w, m, c, { nav.popBackStack() }, { nav.navigate(Routes.list(it)) }, openRecord) }
            }
            composable(Routes.LIST_PATTERN, arguments = listOf(navArgument("typeCode") { type = NavType.StringType })) { e ->
                val type = RecordType.fromCode(e.arguments?.getString("typeCode") ?: "")
                Guard(ctx, nav) { c ->
                    if (type == null) EmptyState("এই তালিকা পাওয়া যায়নি।")
                    else RecordListScreen(type, c, { nav.popBackStack() }, openRecord, showQr)
                }
            }
            composable(Routes.RECORD_PATTERN, arguments = listOf(navArgument("typeCode") { type = NavType.StringType }, navArgument("id") { type = NavType.StringType })) { e ->
                val type = RecordType.fromCode(e.arguments?.getString("typeCode") ?: "")
                val id = e.arguments?.getString("id") ?: ""
                Guard(ctx, nav) { c ->
                    if (type == null) EmptyState("এই রেকর্ড-ধরন পাওয়া যায়নি।")
                    else RecordDashboardScreen(RecordRef(type, id), c, { nav.popBackStack() }, openRecord, showQr)
                }
            }
            composable(Routes.REPORT_PATTERN, arguments = listOf(navArgument("reportId") { type = NavType.StringType })) { e ->
                val id = e.arguments?.getString("reportId") ?: ""
                Guard(ctx, nav) { c -> ReportPreviewScreen(id, c, { nav.popBackStack() }, openRecord) }
            }
            composable(Routes.QR_PATTERN, arguments = listOf(navArgument("token") { type = NavType.StringType })) { e ->
                val token = e.arguments?.getString("token") ?: ""
                Guard(ctx, nav) { c -> QrPreviewScreen(token, c, { nav.popBackStack() }, openRecord) }
            }
        }
    }
}

/** If the process was recreated without a session, send the user back to the login screen. */
@Composable
private fun Guard(ctx: UserContext?, nav: NavController, content: @Composable (UserContext) -> Unit) {
    if (ctx == null) {
        LaunchedEffect(Unit) { nav.navigate(Routes.LOGIN) { popUpTo(nav.graph.id) { inclusive = true } } }
    } else {
        content(ctx)
    }
}
