package com.mohona.erp.core

/**
 * Shared QR infrastructure (Core service, not a wing feature).
 * A QR code is only a revocable, opaque pointer to a record (QR identity). It is NOT the record's database identity
 * and NOT an authority: resolving a code never bypasses authorization, approvals, posting rules or idempotency.
 */
enum class QrEntityType(val nameBn: String) {
    EMPLOYEE("কর্মী"),
    DEALER("ডিলার"),
    RETAILER("রিটেইলার"),
    PRODUCT("পণ্য"),
    BATCH("ব্যাচ"),
    INVOICE("ইনভয়েস"),
    TRANSACTION("লেনদেন"),
    ATTENDANCE("হাজিরা"),
    WAREHOUSE("গুদাম")
}

enum class QrResolutionStatus { DEMO_SAMPLE, NOT_VERIFIED }

data class QrResolution(
    val code: String,
    val status: QrResolutionStatus,
    val entityType: QrEntityType?,
    val noteBn: String
)

interface QrResolver {
    fun resolve(code: String): QrResolution
}

/**
 * Preview resolver: no backend lookup exists yet. It only recognises sample codes ("DEMO-...") and says honestly
 * that everything else is NOT verified. The backend implementation (api.v1_qr_resolve) will replace this class.
 */
class PreviewQrResolver : QrResolver {
    override fun resolve(code: String): QrResolution {
        if (code.startsWith("DEMO-VCH")) return QrResolution(code, QrResolutionStatus.DEMO_SAMPLE, QrEntityType.TRANSACTION, "নমুনা ভাউচার-কোড; সার্ভারে যাচাই হয়নি।")
        if (code.startsWith("DEMO-")) return QrResolution(code, QrResolutionStatus.DEMO_SAMPLE, null, "নমুনা কোড; সার্ভারে যাচাই হয়নি।")
        return QrResolution(code, QrResolutionStatus.NOT_VERIFIED, null, "এই কোড সার্ভারে যাচাই করা হয়নি। প্রিভিউ সংস্করণে কোনো রেকর্ড খোলা যায় না।")
    }
}
