package com.mohona.erp.data.demo

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import com.mohona.erp.domain.ActionId
import com.mohona.erp.domain.ActionPolicy
import com.mohona.erp.domain.AccessPolicy
import com.mohona.erp.domain.Access
import com.mohona.erp.domain.Costing
import com.mohona.erp.domain.CostingResult
import com.mohona.erp.domain.DemoCompany
import com.mohona.erp.domain.DemoNotification
import com.mohona.erp.domain.DemoRecord
import com.mohona.erp.domain.HistoryEvent
import com.mohona.erp.domain.InfoRow
import com.mohona.erp.domain.Kpi
import com.mohona.erp.domain.LineItem
import com.mohona.erp.domain.RecordRef
import com.mohona.erp.domain.RecordStatus
import com.mohona.erp.domain.RecordType
import com.mohona.erp.domain.RelatedGroup
import com.mohona.erp.domain.StockEvent
import com.mohona.erp.domain.UserContext
import java.math.BigDecimal
import java.time.LocalDate
import org.json.JSONArray
import org.json.JSONObject

data class BatchFact(
    val id: String, val productId: String, val date: LocalDate, val planned: Int, val produced: Int, val accepted: Int,
    val status: String, val qc: String, val consumed: Map<String, BigDecimal>, val waste: Map<String, BigDecimal>
)

data class DemoFacts(val events: List<StockEvent>, val batches: List<BatchFact>, val supplierDues: Map<String, BigDecimal>, val materialNames: Map<String, String>, val materialUnits: Map<String, String>)

class ParsedDemo(
    val demoDate: LocalDate,
    val meId: String,
    val companies: List<DemoCompany>,
    val records: List<DemoRecord>,
    val notifications: List<DemoNotification>,
    val qr: Map<String, RecordRef>,
    val facts: DemoFacts,
    val expectedJson: JSONObject
)

/** DTO boundary: turns the bundled demo JSON into domain objects. A future Supabase adapter will produce the same domain objects. */
object DemoJson {
    fun parse(text: String): ParsedDemo {
        val root = JSONObject(text)
        val companies = ArrayList<DemoCompany>()
        val ca = root.getJSONArray("companies")
        for (i in 0 until ca.length()) { val c = ca.getJSONObject(i); companies.add(DemoCompany(c.getString("id"), c.getString("name"))) }
        val records = ArrayList<DemoRecord>()
        val ra = root.getJSONArray("records")
        for (i in 0 until ra.length()) records.add(record(ra.getJSONObject(i)))
        val notifications = ArrayList<DemoNotification>()
        val na = root.getJSONArray("notifications")
        for (i in 0 until na.length()) {
            val n = na.getJSONObject(i)
            val ref = RecordRef.parse(n.getString("ref")) ?: continue
            notifications.add(DemoNotification(n.getString("id"), n.getString("title"), n.getString("detail"), ref, n.getString("when")))
        }
        val qr = HashMap<String, RecordRef>()
        val qo = root.getJSONObject("qr")
        for (k in qo.keys()) RecordRef.parse(qo.getString(k))?.let { qr[k] = it }
        return ParsedDemo(LocalDate.parse(root.getString("demoDate")), root.getString("meId"), companies, records, notifications, qr, facts(root.getJSONObject("facts")), root.getJSONObject("expected"))
    }

    private fun pairs(a: JSONArray?): List<List<String>> {
        val out = ArrayList<List<String>>()
        if (a == null) return out
        for (i in 0 until a.length()) {
            val r = a.getJSONArray(i); val row = ArrayList<String>()
            for (j in 0 until r.length()) row.add(r.getString(j))
            out.add(row)
        }
        return out
    }

    private fun events(a: JSONArray?): List<HistoryEvent> =
        pairs(a).map { HistoryEvent(it[0], it[1], it.getOrElse(2) { "" }, it.getOrElse(3) { "" }) }

    private fun record(o: JSONObject): DemoRecord {
        val type = RecordType.fromName(o.getString("type")) ?: error("unknown type " + o.getString("type"))
        val lines = ArrayList<LineItem>()
        val la = o.optJSONArray("lines")
        if (la != null) for (i in 0 until la.length()) {
            val l = la.getJSONObject(i)
            val refText = l.optString("ref", "")
            lines.add(LineItem(l.getString("name"), l.optString("qty", ""), l.optString("unit", ""), l.optString("price", ""), l.optString("amount", ""), lineRef(refText)))
        }
        val related = ArrayList<RelatedGroup>()
        val rg = o.optJSONArray("related")
        if (rg != null) for (i in 0 until rg.length()) {
            val g = rg.getJSONObject(i)
            val t = RecordType.fromName(g.getString("type")) ?: continue
            val refs = ArrayList<RecordRef>()
            val ar = g.getJSONArray("refs")
            for (j in 0 until ar.length()) RecordRef.parse(ar.getString(j))?.let { refs.add(it) }
            related.add(RelatedGroup(t, refs))
        }
        return DemoRecord(
            ref = RecordRef(type, o.getString("id")), title = o.getString("title"), reference = o.optString("reference", o.getString("id")),
            status = RecordStatus.fromName(o.optString("status", "ACTIVE")), companyId = o.optString("company", "C1"), dateIso = o.optString("date", ""),
            subtitle = o.optString("subtitle", ""), createdBy = if (o.isNull("createdBy")) null else o.optString("createdBy"), imageTone = o.optInt("imageTone", 0),
            qrToken = if (o.isNull("qrToken")) null else o.optString("qrToken"),
            kpis = pairs(o.optJSONArray("kpis")).map { Kpi(it[0], it[1], it.getOrElse(2) { "" }) },
            info = pairs(o.optJSONArray("info")).map { InfoRow(it[0], it[1]) },
            sensitive = pairs(o.optJSONArray("sensitive")).map { InfoRow(it[0], it[1]) },
            lines = lines, totals = pairs(o.optJSONArray("totals")).map { InfoRow(it[0], it[1]) }, related = related,
            history = events(o.optJSONArray("history")), approval = events(o.optJSONArray("approval")),
            reversalOf = if (o.isNull("reversalOf")) null else RecordRef.parse(o.optString("reversalOf")),
            replacementOf = if (o.isNull("replacementOf")) null else RecordRef.parse(o.optString("replacementOf")),
            note = o.optString("note", "")
        )
    }

    /** Line references use a short prefix: MAT/…, PO/…, SPR/…, BAT/… */
    private fun lineRef(s: String): RecordRef? {
        val i = s.indexOf('/')
        if (i <= 0) return null
        val type = when (s.substring(0, i)) {
            "MAT" -> RecordType.RAW_MATERIAL; "PO" -> RecordType.PURCHASE_ORDER; "SPR" -> RecordType.SPARE_PART; "BAT" -> RecordType.BATCH
            else -> return null
        }
        return RecordRef(type, s.substring(i + 1))
    }

    private fun decimals(o: JSONObject?): Map<String, BigDecimal> {
        val m = HashMap<String, BigDecimal>()
        if (o != null) for (k in o.keys()) m[k] = BigDecimal(o.getString(k))
        return m
    }

    private fun facts(o: JSONObject): DemoFacts {
        val ev = ArrayList<StockEvent>()
        val ea = o.getJSONArray("events")
        for (i in 0 until ea.length()) {
            val e = ea.getJSONObject(i)
            ev.add(StockEvent(e.getString("material"), e.getString("date"), e.getInt("seq"), e.getString("kind"), BigDecimal(e.getString("qty")),
                if (e.isNull("price")) null else BigDecimal(e.getString("price")), if (e.isNull("batch")) null else e.getString("batch")))
        }
        val bt = ArrayList<BatchFact>()
        val ba = o.getJSONArray("batches")
        for (i in 0 until ba.length()) {
            val b = ba.getJSONObject(i)
            bt.add(BatchFact(b.getString("id"), b.getString("product"), LocalDate.parse(b.getString("date")), b.getInt("planned"), b.getInt("produced"), b.getInt("accepted"),
                b.getString("status"), b.getString("qc"), decimals(b.optJSONObject("consumed")), decimals(b.optJSONObject("waste"))))
        }
        val mats = o.getJSONObject("materials")
        val names = HashMap<String, String>(); val units = HashMap<String, String>()
        for (k in mats.keys()) { names[k] = mats.getJSONObject(k).getString("name"); units[k] = mats.getJSONObject(k).getString("unit") }
        return DemoFacts(ev, bt, decimals(o.getJSONObject("supplierDues")), names, units)
    }
}

data class ProductKpi(val product: DemoRecord, val producedPoly: Int, val batchCount: Int, val fgAvailablePoly: Int)

/**
 * Structured DEMO repository. Everything shown is fictional and internally consistent (generated and verified by tools/gen_demo.py).
 * Simulated workflow actions change only this in-memory overlay; nothing is saved, posted or sent anywhere.
 */
object DemoRepository {
    private var parsed: ParsedDemo? = null
    private var byRef: Map<RecordRef, DemoRecord> = emptyMap()
    private var costing: CostingResult? = null

    // simulated overlay (cleared on logout/reset)
    private val statusOverride = mutableStateMapOf<String, RecordStatus>()
    private val extraHistory = mutableStateMapOf<String, List<HistoryEvent>>()
    private val extraApproval = mutableStateMapOf<String, List<HistoryEvent>>()

    val isLoaded: Boolean get() = parsed != null

    fun load(context: Context) {
        if (parsed != null) return
        val text = context.assets.open("demo/demo_data.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        loadFromJson(text)
    }

    fun loadFromJson(text: String) {
        val p = DemoJson.parse(text)
        parsed = p
        byRef = p.records.associateBy { it.ref }
        costing = Costing.run(p.facts.events)
        resetSimulation()
    }

    private fun data(): ParsedDemo = parsed ?: error("DemoRepository is not loaded")

    fun resetSimulation() { statusOverride.clear(); extraHistory.clear(); extraApproval.clear() }

    val demoDate: LocalDate get() = data().demoDate
    val meId: String get() = data().meId
    val companies: List<DemoCompany> get() = data().companies
    val facts: DemoFacts get() = data().facts
    val costingResult: CostingResult get() = costing ?: error("costing not run")
    val allRecords: List<DemoRecord> get() = data().records
    val notifications: List<DemoNotification> get() = data().notifications
    val expectedJson: JSONObject get() = data().expectedJson
    fun companyName(id: String): String = companies.firstOrNull { it.id == id }?.name ?: id

    fun get(ref: RecordRef): DemoRecord? = byRef[ref]
    fun statusOf(rec: DemoRecord): RecordStatus = statusOverride[rec.ref.key] ?: rec.status
    fun historyOf(rec: DemoRecord): List<HistoryEvent> = rec.history + (extraHistory[rec.ref.key] ?: emptyList())
    fun approvalOf(rec: DemoRecord): List<HistoryEvent> = rec.approval + (extraApproval[rec.ref.key] ?: emptyList())
    fun qrTarget(token: String): RecordRef? = data().qr[token.trim()]

    fun list(type: RecordType, ctx: UserContext): List<DemoRecord> =
        allRecords.filter { it.ref.type == type && it.companyId in ctx.companyIds && AccessPolicy.canOpen(it, ctx) == Access.ALLOWED }.sortedBy { it.ref.id }

    fun search(query: String, ctx: UserContext, limit: Int = 60): List<DemoRecord> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        return allRecords.filter {
            it.companyId in ctx.companyIds && AccessPolicy.canOpen(it, ctx) == Access.ALLOWED &&
                (it.title.lowercase().contains(q) || it.reference.lowercase().contains(q) || it.ref.id.lowercase().contains(q) || it.subtitle.lowercase().contains(q) || (it.qrToken?.lowercase() == q))
        }.take(limit)
    }

    /** Records currently waiting for a checker's decision, visible to this user. */
    fun pendingApprovals(ctx: UserContext): List<DemoRecord> =
        allRecords.filter { statusOf(it) == RecordStatus.SUBMITTED && it.companyId in ctx.companyIds && AccessPolicy.canOpen(it, ctx) == Access.ALLOWED }

    fun decidedInSession(ctx: UserContext): List<DemoRecord> =
        allRecords.filter { statusOverride.containsKey(it.ref.key) && it.companyId in ctx.companyIds && AccessPolicy.canOpen(it, ctx) == Access.ALLOWED }

    /** Applies a SIMULATED workflow action to the in-memory overlay. Returns false if the action is not currently allowed. */
    fun applyAction(rec: DemoRecord, action: ActionId, ctx: UserContext, reason: String): Boolean {
        val allowed = ActionPolicy.actionsFor(rec, statusOf(rec), ctx).firstOrNull { it.id == action && it.enabled && it.simulated } ?: return false
        val next = ActionPolicy.resultingStatus(action) ?: return false
        statusOverride[rec.ref.key] = next
        val ev = HistoryEvent("ডেমো-সেশন", ActionPolicy.actionTitle(action), (if (reason.isNotBlank()) "কারণ: $reason • " else "") + "সিমুলেশন — ডেটাবেসে কিছুই সংরক্ষিত হয়নি", ctx.name, simulated = true)
        extraHistory[rec.ref.key] = (extraHistory[rec.ref.key] ?: emptyList()) + ev
        if (action == ActionId.APPROVE || action == ActionId.RETURN || action == ActionId.REJECT || action == ActionId.SUBMIT)
            extraApproval[rec.ref.key] = (extraApproval[rec.ref.key] ?: emptyList()) + ev
        return allowed.simulated
    }

    // ------------------------------------------------------------------ manufacturing aggregates (computed from facts, never hard-coded)
    fun productKpis(from: LocalDate, to: LocalDate, ctx: UserContext): List<ProductKpi> {
        val products = list(RecordType.PRODUCT, ctx)
        return products.map { p ->
            val own = facts.batches.filter { it.productId == p.ref.id }
            val inRange = own.filter { !it.date.isBefore(from) && !it.date.isAfter(to) }
            val fg = own.filter { it.qc == "ACCEPTED" && !it.date.isAfter(demoDate) }.sumOf { it.accepted }
            ProductKpi(p, inRange.sumOf { it.produced }, inRange.size, fg)
        }
    }

    fun productionDates(): Set<LocalDate> = facts.batches.map { it.date }.toSet()
    fun batchesInRange(from: LocalDate, to: LocalDate): List<BatchFact> = facts.batches.filter { !it.date.isBefore(from) && !it.date.isAfter(to) }
    fun producedByDate(from: LocalDate, to: LocalDate): List<Pair<LocalDate, Int>> =
        batchesInRange(from, to).groupBy { it.date }.map { (d, l) -> Pair(d, l.sumOf { it.produced }) }.sortedBy { it.first }
    fun materialPositions(): Map<String, com.mohona.erp.domain.MaterialPosition> = costingResult.positions
    fun totalSupplierDue(): BigDecimal = facts.supplierDues.values.fold(BigDecimal.ZERO) { a, b -> a.add(b) }
}
