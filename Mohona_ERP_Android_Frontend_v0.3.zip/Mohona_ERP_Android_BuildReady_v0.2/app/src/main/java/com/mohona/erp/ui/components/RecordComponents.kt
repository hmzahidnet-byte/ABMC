package com.mohona.erp.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.demo.DemoRepository
import com.mohona.erp.domain.Access
import com.mohona.erp.domain.AccessPolicy
import com.mohona.erp.domain.ActionDef
import com.mohona.erp.domain.ActionId
import com.mohona.erp.domain.ActionPolicy
import com.mohona.erp.domain.DemoRecord
import com.mohona.erp.domain.HistoryEvent
import com.mohona.erp.domain.InfoRow
import com.mohona.erp.domain.Kpi
import com.mohona.erp.domain.LineItem
import com.mohona.erp.domain.RecordRef
import com.mohona.erp.domain.RecordStatus
import com.mohona.erp.domain.RecordType
import com.mohona.erp.domain.RelatedGroup
import com.mohona.erp.domain.StatusTone
import com.mohona.erp.domain.UserContext
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.DividerGray
import com.mohona.erp.ui.theme.OrangeDark
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.OrangeSoft
import com.mohona.erp.ui.theme.TextDark
import com.mohona.erp.ui.theme.TextMuted

// ------------------------------------------------------------------ small building blocks

private val toneBg = listOf(OrangeSoft, Color(0xFFE8F1FF), Color(0xFFE6F6EC), Color(0xFFFFF4D6), Color(0xFFF3E8FF), Color(0xFFE0F5F3), Color(0xFFFFE5E5))
private val toneFg = listOf(OrangeDark, Color(0xFF1D4ED8), Color(0xFF15803D), Color(0xFFB45309), Color(0xFF7E22CE), Color(0xFF0F766E), Color(0xFFB91C1C))

/** Clean placeholder used wherever a product photo / avatar / image is missing (no image should ever show a broken box). */
@Composable
fun ImageHolder(tone: Int, label: String, size: Dp = 48.dp, modifier: Modifier = Modifier, round: Boolean = false) {
    val i = ((tone % toneBg.size) + toneBg.size) % toneBg.size
    val shape = if (round) CircleShape else RoundedCornerShape(14.dp)
    Box(modifier = modifier.size(size).clip(shape).background(toneBg[i]), contentAlignment = Alignment.Center) {
        val initial = label.trim().removePrefix("নমুনা:").trim().take(1)
        Text(text = initial, color = toneFg[i], fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun StatusBadge(status: RecordStatus) {
    val tone = when (status.tone) {
        StatusTone.GOOD -> Tone.GOOD
        StatusTone.WARN -> Tone.WARN
        StatusTone.BAD -> Tone.BAD
        StatusTone.INFO -> Tone.INFO
        StatusTone.NEUTRAL -> Tone.NEUTRAL
    }
    StatusPill(status.nameBn, tone)
}

@Composable
fun KpiCard(kpi: Kpi, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White)
            .padding(12.dp)
    ) {
        Text(kpi.label, style = MaterialTheme.typography.labelSmall, color = TextMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(4.dp))
        Text(kpi.value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextDark)
        if (kpi.note.isNotEmpty()) Text(kpi.note, style = MaterialTheme.typography.labelSmall, color = TextMuted)
    }
}

@Composable
fun KpiRow(kpis: List<Kpi>) {
    if (kpis.isEmpty()) return
    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        kpis.forEach { KpiCard(it, Modifier.width(170.dp)) }
    }
}

@Composable
fun SectionCard(title: String, modifier: Modifier = Modifier, trailing: String? = null, content: @Composable () -> Unit) {
    AppCard(modifier = modifier) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                if (trailing != null) Text(trailing, style = MaterialTheme.typography.labelSmall, color = TextMuted)
            }
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
fun InfoRows(rows: List<InfoRow>) {
    rows.forEachIndexed { i, r ->
        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
            Text(r.label, style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Text(r.value, style = MaterialTheme.typography.bodyMedium)
        }
        if (i < rows.lastIndex) Hairline()
    }
}

@Composable
fun PermissionDeniedState(message: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(modifier = Modifier.size(56.dp).clip(CircleShape).background(Color(0xFFFFE5E5)), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Lock, contentDescription = null, tint = BadRed)
        }
        Spacer(Modifier.height(12.dp))
        Text("অনুমতি নেই", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        Text(message, style = MaterialTheme.typography.bodySmall, color = TextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
        Text("এটি প্রিভিউ-ইঙ্গিত; আসল নিয়ন্ত্রণ সার্ভারে (RLS/RPC)।", style = MaterialTheme.typography.labelSmall, color = TextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
fun SearchField(value: String, onChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true, modifier = modifier.fillMaxWidth(),
        placeholder = { Text(placeholder, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
        trailingIcon = { if (value.isNotEmpty()) Icon(Icons.Filled.Close, contentDescription = "মুছুন", modifier = Modifier.clickable { onChange("") }) },
        keyboardOptions = KeyboardOptions.Default,
        shape = RoundedCornerShape(14.dp)
    )
}

/** Single-select chip row (null = all). */
@Composable
fun FilterChips(options: List<String>, selected: String?, onSelect: (String?) -> Unit) {
    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("সব", selected == null) { onSelect(null) }
        options.forEach { o -> Chip(o, selected == o) { onSelect(if (selected == o) null else o) } }
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (selected) OrangePrimary else Color.White).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = if (selected) Color.White else TextDark, maxLines = 1)
    }
}

// ------------------------------------------------------------------ records in lists and as related tiles

@Composable
fun RecordCard(rec: DemoRecord, ctx: UserContext, controller: ActionController, onOpen: (RecordRef) -> Unit) {
    val status = DemoRepository.statusOf(rec)
    val actions = ActionPolicy.actionsFor(rec, status, ctx)
    AppCard(onClick = { onOpen(rec.ref) }) {
        Row(modifier = Modifier.padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            if (rec.ref.type.kind != com.mohona.erp.domain.RecordKind.EVENT) ImageHolder(rec.imageTone, rec.title, 44.dp)
            else Box(modifier = Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(BackgroundGray), contentAlignment = Alignment.Center) { Text(rec.ref.type.nameBn.take(1), color = TextMuted, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(rec.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (rec.subtitle.isNotEmpty()) Text(rec.subtitle, style = MaterialTheme.typography.bodySmall, color = TextMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusBadge(status)
                    Spacer(Modifier.width(8.dp))
                    Text(rec.reference, style = MaterialTheme.typography.labelSmall, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            RecordMenu(rec, actions, controller)
        }
    }
}

@Composable
fun RecordMenu(rec: DemoRecord, actions: List<ActionDef>, controller: ActionController) {
    val items = actions.map { a ->
        MenuAction(a.id.name, a.label, iconFor(a.id), a.enabled, a.hint, onClick = { controller.handle(rec, a) })
    }
    UniversalActionMenu(items)
}

private fun iconFor(id: ActionId) = when (id) {
    ActionId.COPY_REFERENCE -> Icons.Filled.ContentCopy
    ActionId.VIEW_QR -> Icons.Filled.QrCode2
    ActionId.VIEW_AUDIT -> Icons.Filled.History
    ActionId.EDIT_DRAFT -> Icons.Filled.Edit
    ActionId.SUBMIT -> Icons.AutoMirrored.Filled.Send
    ActionId.RECALL -> Icons.Filled.Refresh
    ActionId.APPROVE -> Icons.Filled.CheckCircle
    ActionId.RETURN -> Icons.AutoMirrored.Filled.ArrowBack
    ActionId.REJECT -> Icons.Filled.Close
    ActionId.CANCEL -> Icons.Filled.Close
    ActionId.CORRECT -> Icons.Filled.Build
    ActionId.EXPORT -> Icons.Filled.PictureAsPdf
    ActionId.PRINT -> Icons.Filled.Print
    ActionId.SHARE -> Icons.Filled.Share
}

/** A tappable tile for a linked record. Locked tiles explain why instead of silently hiding the link. */
@Composable
fun RelatedTile(target: DemoRecord?, ref: RecordRef, ctx: UserContext, onOpen: (RecordRef) -> Unit) {
    if (target == null) {
        Text("সংযুক্ত রেকর্ড পাওয়া যায়নি: " + ref.id, style = MaterialTheme.typography.labelSmall, color = BadRed, modifier = Modifier.padding(vertical = 6.dp))
        return
    }
    val access = AccessPolicy.canOpen(target, ctx)
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(BackgroundGray).clickable { onOpen(ref) }.padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(target.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(target.reference + (if (target.subtitle.isNotEmpty()) " • " + target.subtitle else ""), style = MaterialTheme.typography.labelSmall, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        if (access == Access.ALLOWED) StatusBadge(DemoRepository.statusOf(target))
        else Icon(Icons.Filled.Lock, contentDescription = "অনুমতি নেই", tint = TextMuted, modifier = Modifier.size(18.dp))
    }
}

@Composable
fun RelatedGroupsSection(groups: List<RelatedGroup>, ctx: UserContext, onOpen: (RecordRef) -> Unit) {
    if (groups.isEmpty()) {
        EmptyState("এই রেকর্ডের সাথে কোনো সংযুক্ত রেকর্ড নেই।")
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        groups.sortedBy { it.type.ordinal }.forEach { g ->
            var expanded by remember { mutableStateOf(false) }
            val shown = if (expanded) g.refs else g.refs.take(4)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(g.type.nameBn + " (" + com.mohona.erp.data.Bn.digits(g.refs.size.toString()) + ")", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = OrangeDark)
                shown.forEach { r -> RelatedTile(DemoRepository.get(r), r, ctx, onOpen) }
                if (g.refs.size > 4) Text(if (expanded) "কম দেখুন" else "আরও " + com.mohona.erp.data.Bn.digits((g.refs.size - 4).toString()) + "টি দেখুন", style = MaterialTheme.typography.labelMedium, color = OrangePrimary, modifier = Modifier.clickable { expanded = !expanded }.padding(vertical = 4.dp))
            }
        }
    }
}

@Composable
fun LineItemsSection(lines: List<LineItem>, totals: List<InfoRow>, ctx: UserContext, onOpen: (RecordRef) -> Unit) {
    lines.forEachIndexed { i, l ->
        val target = l.ref
        Column(modifier = Modifier.fillMaxWidth().then(if (target != null) Modifier.clickable { onOpen(target) } else Modifier).padding(vertical = 6.dp)) {
            Text(l.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, color = if (target != null) OrangeDark else TextDark)
            val detail = listOf(l.qty + (if (l.unit.isNotEmpty()) " " + l.unit else ""), if (l.unitPrice.isNotEmpty()) "একক " + l.unitPrice else "").filter { it.isNotBlank() }.joinToString("  •  ")
            if (detail.isNotEmpty()) Text(detail, style = MaterialTheme.typography.labelSmall, color = TextMuted)
            if (l.amount.isNotEmpty()) Text(l.amount, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        }
        if (i < lines.lastIndex) Hairline()
    }
    if (totals.isNotEmpty()) {
        Spacer(Modifier.height(8.dp))
        Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(OrangeSoft).padding(10.dp)) {
            Column {
                totals.forEach { t ->
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Text(t.label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Text(t.value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun TimelineView(events: List<HistoryEvent>, emptyText: String) {
    if (events.isEmpty()) {
        Text(emptyText, style = MaterialTheme.typography.bodySmall, color = TextMuted)
        return
    }
    Column {
        events.forEachIndexed { i, e ->
            Row(modifier = Modifier.fillMaxWidth()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(18.dp)) {
                    Box(modifier = Modifier.padding(top = 5.dp).size(10.dp).clip(CircleShape).background(if (e.simulated) com.mohona.erp.ui.theme.WarnAmber else OrangePrimary))
                    if (i < events.lastIndex) Box(modifier = Modifier.width(2.dp).height(34.dp).background(DividerGray))
                }
                Spacer(Modifier.width(8.dp))
                Column(modifier = Modifier.padding(bottom = 10.dp)) {
                    Text(e.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    if (e.detail.isNotEmpty()) Text(e.detail, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    Text(e.whenText + (if (e.actor.isNotEmpty()) " • " + e.actor else ""), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    if (e.simulated) PreviewBadge("সিমুলেশন")
                }
            }
        }
    }
}

/** Decorative stand-in for a QR symbol. It is NOT a valid QR code; real QR generation/printing needs the backend QR registry. */
@Composable
fun QrDemoImage(seed: String, size: Dp = 150.dp) {
    val n = 21
    var state = seed.hashCode().toLong() and 0x7fffffffL
    if (state == 0L) state = 12345L
    val cells = BooleanArray(n * n)
    for (i in cells.indices) {
        state = (state * 1103515245L + 12345L) and 0x7fffffffL
        cells[i] = (state shr 16) % 2L == 0L
    }
    Canvas(modifier = Modifier.size(size).background(Color.White)) {
        val cell = this.size.width / n
        for (r in 0 until n) for (c in 0 until n) {
            val finder = (r < 7 && c < 7) || (r < 7 && c >= n - 7) || (r >= n - 7 && c < 7)
            if (!finder && cells[r * n + c]) drawRect(TextDark, Offset(c * cell, r * cell), Size(cell, cell))
        }
        fun finderAt(r0: Int, c0: Int) {
            drawRect(OrangeDark, Offset(c0 * cell, r0 * cell), Size(7 * cell, 7 * cell))
            drawRect(Color.White, Offset((c0 + 1) * cell, (r0 + 1) * cell), Size(5 * cell, 5 * cell))
            drawRect(OrangeDark, Offset((c0 + 2) * cell, (r0 + 2) * cell), Size(3 * cell, 3 * cell))
        }
        finderAt(0, 0); finderAt(0, n - 7); finderAt(n - 7, 0)
    }
}

// ------------------------------------------------------------------ action controller (shared by every list and detail screen)

class ActionRequest(val rec: DemoRecord, val action: ActionDef)

/**
 * One handler for the contextual ⋮ menu everywhere. Real effects: copy reference (clipboard), open QR preview, open audit. Workflow actions are
 * SIMULATIONS: they ask for confirmation (and a reason where required), change only the in-memory overlay and add a history event labelled as simulated.
 */
class ActionController(
    private val ctx: UserContext,
    private val context: Context,
    private val onShowQr: (RecordRef) -> Unit,
    private val onShowAudit: (RecordRef) -> Unit,
    private val pending: androidx.compose.runtime.MutableState<ActionRequest?>
) {
    fun handle(rec: DemoRecord, a: ActionDef) {
        if (!a.enabled) return
        when (a.id) {
            ActionId.COPY_REFERENCE -> {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("reference", rec.reference))
                Toast.makeText(context, "রেফারেন্স কপি হয়েছে", Toast.LENGTH_SHORT).show()
            }
            ActionId.VIEW_QR -> onShowQr(rec.ref)
            ActionId.VIEW_AUDIT -> onShowAudit(rec.ref)
            else -> if (a.simulated) pending.value = ActionRequest(rec, a)
        }
    }

    @Composable
    fun Dialogs() {
        val req = pending.value ?: return
        var reason by remember(req) { mutableStateOf("") }
        val needReason = req.action.needsReason
        AlertDialog(
            onDismissRequest = { pending.value = null },
            title = { Text(req.action.label + "?") },
            text = {
                Column {
                    Text(req.rec.title, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text("এটি সিমুলেশন: শুধু এই ডেমো-সেশনের ভেতরে অবস্থা বদলাবে; ডেটাবেসে কিছুই সংরক্ষিত বা পোস্ট হবে না।", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    if (needReason) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ (বাধ্যতামূলক)") }, modifier = Modifier.fillMaxWidth())
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        DemoRepository.applyAction(req.rec, req.action.id, ctx, reason.trim())
                        Toast.makeText(context, "সিমুলেশন: " + ActionPolicy.actionTitle(req.action.id), Toast.LENGTH_SHORT).show()
                        pending.value = null
                    },
                    enabled = !needReason || reason.isNotBlank(),
                    colors = if (req.action.destructive) ButtonDefaults.buttonColors(containerColor = BadRed) else ButtonDefaults.buttonColors(containerColor = OrangePrimary)
                ) { Text("নিশ্চিত করুন") }
            },
            dismissButton = { TextButton(onClick = { pending.value = null }) { Text("থাক") } }
        )
    }
}

@Composable
fun rememberActionController(ctx: UserContext, onShowQr: (RecordRef) -> Unit, onShowAudit: (RecordRef) -> Unit): ActionController {
    val context = LocalContext.current
    val pending = remember { mutableStateOf<ActionRequest?>(null) }
    return ActionController(ctx, context, onShowQr, onShowAudit, pending)
}

/** Primary workflow buttons shown under a record header: only actions that are enabled right now. */
@Composable
fun PrimaryActionRow(rec: DemoRecord, actions: List<ActionDef>, controller: ActionController) {
    val primary = actions.filter { it.enabled && it.simulated }
    val blocked = actions.filter { !it.enabled && (it.id == ActionId.APPROVE || it.id == ActionId.CORRECT) }
    if (primary.isEmpty() && blocked.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (primary.isNotEmpty()) {
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                primary.forEach { a ->
                    if (a.id == ActionId.APPROVE || a.id == ActionId.SUBMIT) Button(onClick = { controller.handle(rec, a) }, colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary)) { Text(a.label) }
                    else OutlinedButton(onClick = { controller.handle(rec, a) }) { Text(a.label) }
                }
            }
            Text("এই বোতামগুলো সিমুলেশন — কিছুই সংরক্ষিত বা পোস্ট হয় না।", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        }
        blocked.forEach { b -> Text(b.label + ": " + (b.hint ?: ""), style = MaterialTheme.typography.labelSmall, color = TextMuted) }
    }
}
