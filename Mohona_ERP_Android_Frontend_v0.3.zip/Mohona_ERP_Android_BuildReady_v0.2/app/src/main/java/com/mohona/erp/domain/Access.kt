package com.mohona.erp.domain

/**
 * UI-ONLY visibility and action HINTS. They mirror the role/permission matrix seed (Appendix F) so the demo looks right, but they NEVER
 * grant anything: real access is decided server-side (RLS/RPC). Where the matrix is silent the hint says "Pending" instead of inventing a rule.
 */
enum class Access { ALLOWED, WRONG_COMPANY, NO_PERMISSION }

object AccessPolicy {
    // txn.view / party.view / inv.view / hr.* holders in the Appendix F seed (see backend/supabase/migrations/…0400_seed_roles_permissions.sql)
    private val OPS = setOf("MD", "WING_HEAD", "STOREKEEPER", "PROD_SUPERVISOR", "QC_OFFICER", "PURCHASE_OFFICER", "CHAIRMAN", "AUDITOR")
    private val PARTY = setOf("CHAIRMAN", "MD", "WING_HEAD", "FIN_MANAGER", "ACCOUNTANT", "PURCHASE_OFFICER", "AUDITOR")
    private val FIN = setOf("CHAIRMAN", "MD", "WING_HEAD", "FIN_MANAGER", "ACCOUNTANT", "CASHIER", "AUDITOR")
    private val HR = setOf("MD", "WING_HEAD", "HR_OFFICER")
    private val ATTENDANCE = setOf("WING_HEAD", "HR_OFFICER", "PROD_SUPERVISOR")
    private val MD_ONLY = setOf("MD")
    val APPROVERS = setOf("CHAIRMAN", "MD", "WING_HEAD", "FIN_MANAGER")
    val AUDIT_VIEW = setOf("CHAIRMAN", "MD", "AUDITOR")

    fun rolesFor(type: RecordType): Set<String> = when (type) {
        RecordType.EMPLOYEE, RecordType.PAYROLL_MONTH, RecordType.PAYSLIP -> HR
        RecordType.ATTENDANCE_MONTH, RecordType.ATTENDANCE_DAY, RecordType.ATTENDANCE_EVENT -> ATTENDANCE   // hr.attendance.view holders only (MD is not listed in the matrix)
        RecordType.SUPPLIER, RecordType.PURCHASE_ORDER -> PARTY + OPS
        RecordType.PAYMENT_VOUCHER, RecordType.SUPPLIER_LEDGER, RecordType.EXPENSE -> FIN
        RecordType.FACTORY_PNL -> MD_ONLY
        else -> OPS + FIN
    }

    /** The employee a record belongs to (self-service view), if any. */
    private fun ownerEmployee(rec: DemoRecord): String? {
        if (rec.ref.type == RecordType.EMPLOYEE) return rec.ref.id
        for (g in rec.related) if (g.type == RecordType.EMPLOYEE && g.refs.size == 1) return g.refs[0].id
        return null
    }

    fun canOpen(rec: DemoRecord, ctx: UserContext): Access {
        if (rec.companyId !in ctx.companyIds) return Access.WRONG_COMPANY
        if (rec.ref.type == RecordType.FACTORY_PNL) return if ("MD" in ctx.roles) Access.ALLOWED else Access.NO_PERMISSION
        if (ctx.roles.any { it in rolesFor(rec.ref.type) }) return Access.ALLOWED
        // EMPLOYEE_SELF sees only its own HR records
        val t = rec.ref.type
        val selfTypes = setOf(RecordType.EMPLOYEE, RecordType.ATTENDANCE_MONTH, RecordType.ATTENDANCE_DAY, RecordType.ATTENDANCE_EVENT, RecordType.PAYROLL_MONTH, RecordType.PAYSLIP)
        if ("EMPLOYEE_SELF" in ctx.roles && t in selfTypes && ownerEmployee(rec) == ctx.employeeId) return Access.ALLOWED
        return Access.NO_PERMISSION
    }

    /** Salary/personal data: HR roles, or the employee themself. (A payroll-permission rule is NOT in the approved matrix: shown as a hint only.) */
    fun canSeeSensitive(rec: DemoRecord, ctx: UserContext): Boolean {
        if (rec.ref.type == RecordType.FACTORY_PNL) return "MD" in ctx.roles
        if (ctx.roles.any { it in HR }) return true
        return "EMPLOYEE_SELF" in ctx.roles && ownerEmployee(rec) == ctx.employeeId
    }

    fun canSeeAudit(ctx: UserContext): Boolean = ctx.roles.any { it in AUDIT_VIEW }

    /** Roles that may create/submit a given transaction type (from txn.create/submit, proc.po.manage, inv.*, mfg.* holders). */
    fun makerRoles(type: RecordType): Set<String> = when (type) {
        RecordType.PURCHASE_ORDER -> setOf("PURCHASE_OFFICER", "WING_HEAD", "ACCOUNTANT", "CASHIER")
        RecordType.PAYMENT_VOUCHER, RecordType.EXPENSE -> setOf("ACCOUNTANT", "CASHIER", "WING_HEAD")
        RecordType.GRN, RecordType.FG_RECEIPT, RecordType.MATERIAL_ISSUE -> setOf("STOREKEEPER", "PURCHASE_OFFICER", "PROD_SUPERVISOR", "WING_HEAD")
        RecordType.BATCH, RecordType.CONSUMPTION, RecordType.MAINTENANCE -> setOf("PROD_SUPERVISOR", "WING_HEAD")
        RecordType.QC_RECORD -> setOf("QC_OFFICER")
        RecordType.PAYROLL_MONTH, RecordType.PAYSLIP -> setOf("HR_OFFICER")
        else -> emptySet()
    }
}

enum class ActionId { COPY_REFERENCE, VIEW_QR, VIEW_AUDIT, EDIT_DRAFT, SUBMIT, RECALL, APPROVE, RETURN, REJECT, CANCEL, CORRECT, EXPORT, PRINT, SHARE }

data class ActionDef(
    val id: ActionId,
    val label: String,
    val enabled: Boolean,
    val hint: String? = null,
    val simulated: Boolean = false,
    val needsReason: Boolean = false,
    val destructive: Boolean = false
)

/** Which actions a record offers RIGHT NOW: depends on type, effective status, role and company. Irrelevant actions are omitted; blocked ones say why. */
object ActionPolicy {
    private const val PLANNED = "পরিকল্পিত"
    private const val SIM = "সিমুলেশন"

    fun actionsFor(rec: DemoRecord, status: RecordStatus, ctx: UserContext): List<ActionDef> {
        val out = ArrayList<ActionDef>()
        out.add(ActionDef(ActionId.COPY_REFERENCE, "রেফারেন্স কপি", true))
        if (rec.ref.type.hasQr) out.add(ActionDef(ActionId.VIEW_QR, "QR দেখুন (ডেমো)", true))
        out.add(
            if (AccessPolicy.canSeeAudit(ctx)) ActionDef(ActionId.VIEW_AUDIT, "অডিট-ইতিহাস", true)
            else ActionDef(ActionId.VIEW_AUDIT, "অডিট-ইতিহাস", false, "অনুমতি নেই (audit.view)")
        )
        if (rec.ref.type.kind == RecordKind.TRANSACTION) addWorkflowActions(rec, status, ctx, out)
        out.add(ActionDef(ActionId.EXPORT, "PDF / ছবি সংরক্ষণ", false, PLANNED))
        out.add(ActionDef(ActionId.SHARE, "WhatsApp-এ শেয়ার", false, PLANNED))
        out.add(ActionDef(ActionId.PRINT, "A4 / POS প্রিন্ট", false, PLANNED))
        return out
    }

    private fun addWorkflowActions(rec: DemoRecord, status: RecordStatus, ctx: UserContext, out: MutableList<ActionDef>) {
        val mine = rec.createdBy != null && rec.createdBy == ctx.employeeId
        val maker = ctx.roles.any { it in AccessPolicy.makerRoles(rec.ref.type) }
        val approver = ctx.roles.any { it in AccessPolicy.APPROVERS }
        when (status) {
            RecordStatus.DRAFT, RecordStatus.RETURNED -> {
                out.add(ActionDef(ActionId.EDIT_DRAFT, "খসড়া সম্পাদনা", false, "ফর্ম ব্যাকএন্ড যুক্ত হলে চালু হবে"))
                if (maker && mine) out.add(ActionDef(ActionId.SUBMIT, "অনুমোদনের জন্য জমা", true, SIM, simulated = true))
                else out.add(ActionDef(ActionId.SUBMIT, "অনুমোদনের জন্য জমা", false, if (!mine) "শুধু প্রস্তুতকারী জমা দিতে পারেন" else "এই ভূমিকার জমা-অনুমতি নেই"))
                if (mine) out.add(ActionDef(ActionId.CANCEL, "বাতিল", true, SIM, simulated = true, needsReason = true, destructive = true))
            }
            RecordStatus.SUBMITTED -> {
                if (mine) out.add(ActionDef(ActionId.RECALL, "জমা ফিরিয়ে নিন", true, SIM, simulated = true))
                if (approver) {
                    val own = if (mine) "নিজের তৈরি লেনদেন নিজে অনুমোদন করা যায় না (Maker-Checker)" else null
                    out.add(ActionDef(ActionId.APPROVE, "অনুমোদন", own == null, own ?: SIM, simulated = true))
                    out.add(ActionDef(ActionId.RETURN, "ফেরত পাঠান", own == null, own ?: SIM, simulated = true, needsReason = true))
                    out.add(ActionDef(ActionId.REJECT, "প্রত্যাখ্যান", own == null, own ?: SIM, simulated = true, needsReason = true, destructive = true))
                }
                if (mine) out.add(ActionDef(ActionId.CANCEL, "বাতিল", true, SIM, simulated = true, needsReason = true, destructive = true))
            }
            RecordStatus.APPROVED, RecordStatus.POSTED ->
                out.add(ActionDef(ActionId.CORRECT, "সংশোধন (Reversal + Replacement)", false, "পোস্টকৃত রেকর্ড সরাসরি বদলানো যায় না; সংশোধন ব্যাকএন্ড-অনুমোদন-ওয়ার্কফ্লোতে হবে"))
            else -> Unit
        }
    }

    /** The status a simulated action leads to, or null if the action does not change status. */
    fun resultingStatus(action: ActionId): RecordStatus? = when (action) {
        ActionId.SUBMIT -> RecordStatus.SUBMITTED
        ActionId.RECALL -> RecordStatus.DRAFT
        ActionId.APPROVE -> RecordStatus.APPROVED
        ActionId.RETURN -> RecordStatus.RETURNED
        ActionId.REJECT -> RecordStatus.REJECTED
        ActionId.CANCEL -> RecordStatus.CANCELLED
        else -> null
    }

    fun actionTitle(action: ActionId): String = when (action) {
        ActionId.SUBMIT -> "জমা দেওয়া হয়েছে"
        ActionId.RECALL -> "জমা ফিরিয়ে নেওয়া হয়েছে"
        ActionId.APPROVE -> "অনুমোদিত"
        ActionId.RETURN -> "ফেরত পাঠানো হয়েছে"
        ActionId.REJECT -> "প্রত্যাখ্যাত"
        ActionId.CANCEL -> "বাতিল"
        else -> ""
    }
}
