package com.mohona.erp.ui.components

import com.mohona.erp.data.Bn
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId

enum class CalendarMode(val nameBn: String) { DAY("দিন"), WEEK("সপ্তাহ"), MONTH("মাস"), RANGE("কাস্টম") }

data class DateFilter(val mode: CalendarMode, val start: LocalDate, val end: LocalDate) {
    fun contains(d: LocalDate): Boolean = !d.isBefore(start) && !d.isAfter(end)
}

/** Bengali date display and the business-date rules (Bangladesh week starts on Saturday; business date = Asia/Dhaka). */
object BnDate {
    val months = listOf("জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর")
    val weekdaysSatFirst = listOf("শনি", "রবি", "সোম", "মঙ্গল", "বুধ", "বৃহ", "শুক্র")
    val dhaka: ZoneId = ZoneId.of("Asia/Dhaka")

    fun dhakaToday(): LocalDate = LocalDate.now(dhaka)

    fun format(d: LocalDate): String = Bn.digits(d.dayOfMonth.toString()) + " " + months[d.monthValue - 1] + " " + Bn.digits(d.year.toString())
    fun formatMonth(ym: YearMonth): String = months[ym.monthValue - 1] + " " + Bn.digits(ym.year.toString())

    fun formatFilter(f: DateFilter): String =
        if (f.start == f.end) format(f.start) else format(f.start) + " – " + format(f.end)

    /** Index of a day in a Saturday-first week (Saturday = 0 … Friday = 6). */
    fun satIndex(dow: DayOfWeek): Int = (dow.value + 1) % 7

    fun weekOf(d: LocalDate): DateFilter {
        val start = d.minusDays(satIndex(d.dayOfWeek).toLong())
        return DateFilter(CalendarMode.WEEK, start, start.plusDays(6))
    }

    fun monthOf(d: LocalDate): DateFilter {
        val ym = YearMonth.from(d)
        return DateFilter(CalendarMode.MONTH, ym.atDay(1), ym.atEndOfMonth())
    }

    fun dayOf(d: LocalDate): DateFilter = DateFilter(CalendarMode.DAY, d, d)
}
