package com.mohona.erp

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

/** Static navigation-integrity checks on the source itself: every route pattern is registered in the NavHost and every navigate() target is a declared route builder. */
class RoutesTest {
    private val nav = File("src/main/java/com/mohona/erp/ui/navigation/AppNavigation.kt").readText(Charsets.UTF_8)

    @Test fun everyRoutePatternHasAComposableDestination() {
        val patterns = Regex("const val (\\w+_PATTERN) =").findAll(nav).map { it.groupValues[1] }.toList()
        assertTrue(patterns.size >= 6)
        for (p in patterns) assertTrue("no composable for $p", nav.contains("composable(Routes.$p") || nav.contains("Routes.$p,"))
        val plain = Regex("const val ([A-Z]+) = \"[a-z]+\"").findAll(nav).map { it.groupValues[1] }.filter { !it.endsWith("_PATTERN") }.toList()
        for (r in plain) assertTrue("no composable for $r", nav.contains("composable(Routes.$r)"))
    }

    @Test fun everyNavigateCallUsesADeclaredRoute() {
        val used = Regex("nav\\.navigate\\(Routes\\.(\\w+)").findAll(nav).map { it.groupValues[1] }.toSet()
        for (u in used) assertTrue("unknown route builder $u", nav.contains("const val $u =") || nav.contains("fun $u("))
    }

    @Test fun oneCanonicalRecordScreenOnly() {
        val screens = File("src/main/java/com/mohona/erp/ui/screens").listFiles()!!.map { it.readText(Charsets.UTF_8) }.joinToString("\n")
        assertTrue(Regex("fun RecordDashboardScreen\\(").findAll(screens).count() == 1)
        assertTrue("no per-type detail screens", !Regex("fun (Employee|Product|Supplier|Batch|Purchase|Transaction)\\w*DetailScreen").containsMatchIn(screens))
    }
}
