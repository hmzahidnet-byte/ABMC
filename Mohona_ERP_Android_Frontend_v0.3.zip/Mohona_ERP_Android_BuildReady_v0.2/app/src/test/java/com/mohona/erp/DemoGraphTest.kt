package com.mohona.erp

import com.mohona.erp.data.demo.DemoJson
import com.mohona.erp.data.demo.DemoRepository
import com.mohona.erp.domain.Access
import com.mohona.erp.domain.AccessPolicy
import com.mohona.erp.domain.ActionId
import com.mohona.erp.domain.ActionPolicy
import com.mohona.erp.domain.Costing
import com.mohona.erp.domain.RecordKind
import com.mohona.erp.domain.RecordRef
import com.mohona.erp.domain.RecordStatus
import com.mohona.erp.domain.RecordType
import com.mohona.erp.domain.UserContext
import com.mohona.erp.domain.WingRegistry
import java.io.File
import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/** JVM tests over the REAL bundled demo JSON. They check graph integrity, the costing arithmetic (against numbers computed independently by tools/gen_demo.py), and the access/action rules. */
class DemoGraphTest {
    private lateinit var text: String

    @Before
    fun setUp() {
        text = File("src/main/assets/demo/demo_data.json").readText(Charsets.UTF_8)
        DemoRepository.loadFromJson(text)
    }

    private fun ctx(vararg roles: String, company: String = "C1", me: String = "EMP-100") =
        UserContext("পরীক্ষা", me, roles.toList(), company, setOf(company), true)

    // ---------------------------------------------------------------- graph integrity
    @Test fun everyRelatedLinkResolvesAndIsSymmetricAndStaysInsideTheCompany() {
        val all = DemoRepository.allRecords
        assertTrue(all.size > 100)
        for (r in all) for (g in r.related) for (x in g.refs) {
            val other = DemoRepository.get(x)
            assertNotNull("dangling link ${r.ref.key} -> ${x.key}", other)
            assertTrue("asymmetric ${r.ref.key} -> ${x.key}", other!!.related.any { gg -> r.ref in gg.refs })
            assertEquals("cross-company link ${r.ref.key} -> ${x.key}", r.companyId, other.companyId)
        }
    }

    @Test fun lineReferencesNotificationsAndQrTokensResolve() {
        for (r in DemoRepository.allRecords) for (l in r.lines) l.ref?.let { assertNotNull("line target ${it.key}", DemoRepository.get(it)) }
        for (n in DemoRepository.notifications) assertNotNull(DemoRepository.get(n.ref))
        for (r in DemoRepository.allRecords) r.qrToken?.let { assertEquals(r.ref, DemoRepository.qrTarget(it)) }
    }

    @Test fun everyRecordTypeUsedInTheDataHasItsCanonicalDashboardTypeAndModule() {
        val inModules = WingRegistry.wings.flatMap { it.modules }.flatMap { it.types }.toSet()
        for (t in DemoRepository.allRecords.map { it.ref.type }.toSet()) assertTrue("type $t is not reachable from any module", t in inModules)
    }

    @Test fun correctionChainIsTraceable() {
        val orig = DemoRepository.get(RecordRef(RecordType.PAYMENT_VOUCHER, "PV-003"))!!
        val rev = DemoRepository.get(RecordRef(RecordType.PAYMENT_VOUCHER, "PV-003R"))!!
        val rep = DemoRepository.get(RecordRef(RecordType.PAYMENT_VOUCHER, "PV-004"))!!
        assertEquals(RecordStatus.REVERSED, orig.status)
        assertEquals(orig.ref, rev.reversalOf); assertEquals(orig.ref, rep.replacementOf)
    }

    @Test fun journeyLinksExist() {
        fun linked(a: String, at: RecordType, b: String, bt: RecordType) =
            DemoRepository.get(RecordRef(at, a))!!.related.any { g -> g.refs.any { it == RecordRef(bt, b) } }
        // A: purchase -> GRN -> stock -> issue -> batch -> QC -> FG -> cost
        assertTrue(linked("PO-001", RecordType.PURCHASE_ORDER, "GRN-001", RecordType.GRN))
        assertTrue(linked("GRN-001", RecordType.GRN, "MAT-001", RecordType.RAW_MATERIAL))
        assertTrue(DemoRepository.get(RecordRef(RecordType.RAW_MATERIAL, "MAT-001"))!!.related.any { it.type == RecordType.STOCK_MOVEMENT })
        assertTrue(linked("ISS-001", RecordType.MATERIAL_ISSUE, "B-001", RecordType.BATCH))
        assertTrue(linked("QC-001", RecordType.QC_RECORD, "B-001", RecordType.BATCH))
        assertTrue(linked("FGR-001", RecordType.FG_RECEIPT, "B-001", RecordType.BATCH))
        assertTrue(linked("BC-001", RecordType.BATCH_COST, "B-001", RecordType.BATCH))
        // B: employee -> attendance month -> day -> event; payroll -> payslip
        assertTrue(linked("ATM-101-202610", RecordType.ATTENDANCE_MONTH, "EMP-101", RecordType.EMPLOYEE))
        assertTrue(linked("ATD-101-20261001", RecordType.ATTENDANCE_DAY, "ATM-101-202610", RecordType.ATTENDANCE_MONTH))
        assertTrue(linked("ATE-101-20261001-IN", RecordType.ATTENDANCE_EVENT, "ATD-101-20261001", RecordType.ATTENDANCE_DAY))
        assertTrue(linked("PSL-101-202610", RecordType.PAYSLIP, "PRM-101-202610", RecordType.PAYROLL_MONTH))
        // D: machine -> maintenance -> breakdown -> spare part -> expense
        assertTrue(linked("MC-002", RecordType.MACHINE, "MNT-001", RecordType.MAINTENANCE))
        assertTrue(linked("MNT-001", RecordType.MAINTENANCE, "BRK-001", RecordType.BREAKDOWN))
        assertTrue(linked("BRK-001", RecordType.BREAKDOWN, "SPR-001", RecordType.SPARE_PART))
        assertTrue(linked("SPR-001", RecordType.SPARE_PART, "EXP-001", RecordType.EXPENSE))
        // E: warehouse -> item stock -> movement -> source document -> batch
        assertTrue(linked("MAT-001", RecordType.RAW_MATERIAL, "WH-RM", RecordType.WAREHOUSE))
        assertTrue(DemoRepository.allRecords.any { it.ref.type == RecordType.STOCK_MOVEMENT && it.related.any { g -> g.type == RecordType.BATCH } })
    }

    // ---------------------------------------------------------------- costing (independent numbers from tools/gen_demo.py)
    private fun expectedMap(group: String): org.json.JSONObject = DemoRepository.expectedJson.getJSONObject(group)

    @Test fun movingWeightedAverageMatchesIndependentCalculation() {
        val res = Costing.run(DemoRepository.facts.events)
        val exp = expectedMap("wac_final")
        for (m in exp.keys()) {
            val e = exp.getJSONObject(m); val p = res.positions[m]!!
            assertEquals("qty $m", 0, BigDecimal(e.getString("qty")).compareTo(p.qty))
            assertEquals("value $m", 0, BigDecimal(e.getString("value")).compareTo(p.value))
            assertEquals("avg $m", 0, BigDecimal(e.getString("avg")).compareTo(p.avg))
        }
        val iu = expectedMap("issue_unit")
        for (k in iu.keys()) assertEquals("issue unit $k", 0, BigDecimal(iu.getString(k)).compareTo(res.issueUnitCost[k]!!))
    }

    @Test fun materialCostPerPolyMatchesAndNeverDividesByZero() {
        val res = Costing.run(DemoRepository.facts.events)
        val exp = expectedMap("material_cost_per_poly"); val tot = expectedMap("batch_material_cost")
        for (b in DemoRepository.facts.batches) {
            val cost = Costing.consumedCost(b.consumed, b.id, res.issueUnitCost)
            assertEquals("batch cost ${b.id}", 0, BigDecimal(tot.getString(b.id)).compareTo(cost))
            val cpp = Costing.materialCostPerPoly(cost, BigDecimal(b.accepted))
            if (exp.isNull(b.id)) assertNull("no accepted output => no per-Poly cost for ${b.id}", cpp)
            else assertEquals("cost/Poly ${b.id}", 0, BigDecimal(exp.getString(b.id)).compareTo(cpp!!))
        }
        assertNull(Costing.materialCostPerPoly(BigDecimal("100"), BigDecimal.ZERO))
    }

    @Test fun stockNeverGoesNegative() {
        val bad = DemoRepository.facts.events + com.mohona.erp.domain.StockEvent("MAT-001", "2026-12-31", 9999, "ISSUE", BigDecimal("999999"), null, "B-X")
        var threw = false
        try { Costing.run(bad) } catch (e: IllegalArgumentException) { threw = true }
        assertTrue("an issue larger than stock must be refused", threw)
    }

    @Test fun reconciliationIssuedEqualsConsumedPlusReturnedPlusLoss() {
        for (b in DemoRepository.facts.batches.filter { it.status != "IN_PROGRESS" }) {
            val rec = DemoRepository.get(RecordRef(RecordType.CONSUMPTION, "CON-" + b.id.takeLast(3)))!!
            assertTrue(rec.info.any { it.value.contains("ইস্যু = ব্যবহৃত + ফেরত + ক্ষতি") })
        }
    }

    @Test fun supplierDuesMatchExpected() {
        val exp = expectedMap("supplier_due")
        for ((s, due) in DemoRepository.facts.supplierDues) assertEquals(0, BigDecimal(exp.getString(s)).compareTo(due))
    }

    // ---------------------------------------------------------------- company isolation and access
    @Test fun otherCompanyRecordsAreDeniedAndNeverListed() {
        val c1 = ctx("MD")
        val c2rec = DemoRepository.get(RecordRef(RecordType.PRODUCT, "PRD-C2-001"))!!
        assertEquals(Access.WRONG_COMPANY, AccessPolicy.canOpen(c2rec, c1))
        assertTrue(DemoRepository.list(RecordType.PRODUCT, c1).none { it.companyId != "C1" })
        assertTrue(DemoRepository.search("অন্য কোম্পানি", c1).isEmpty())
        assertEquals(Access.ALLOWED, AccessPolicy.canOpen(c2rec, ctx("CHAIRMAN", company = "C2")))
    }

    @Test fun factoryPnlIsMdOnlyEvenForChairman() {
        val pnl = DemoRepository.get(RecordRef(RecordType.FACTORY_PNL, "PNL-202610"))!!
        assertEquals(Access.ALLOWED, AccessPolicy.canOpen(pnl, ctx("MD")))
        assertEquals(Access.NO_PERMISSION, AccessPolicy.canOpen(pnl, ctx("CHAIRMAN")))
        assertEquals(Access.NO_PERMISSION, AccessPolicy.canOpen(pnl, ctx("FIN_MANAGER")))
        assertTrue(pnl.sensitive.any { it.value.contains("কোনো সংখ্যা তৈরি করা হয়নি") })
    }

    @Test fun roleVisibilityFollowsTheMatrixHints() {
        val emp = DemoRepository.get(RecordRef(RecordType.EMPLOYEE, "EMP-101"))!!
        assertEquals(Access.ALLOWED, AccessPolicy.canOpen(emp, ctx("HR_OFFICER")))
        assertEquals(Access.NO_PERMISSION, AccessPolicy.canOpen(emp, ctx("CASHIER")))
        assertEquals(Access.NO_PERMISSION, AccessPolicy.canOpen(emp, ctx("EMPLOYEE_SELF", me = "EMP-103")))
        assertEquals(Access.ALLOWED, AccessPolicy.canOpen(emp, ctx("EMPLOYEE_SELF", me = "EMP-101")))
        assertTrue(AccessPolicy.canSeeSensitive(emp, ctx("HR_OFFICER"))); assertFalse(AccessPolicy.canSeeSensitive(emp, ctx("QC_OFFICER")))
        assertTrue(WingRegistry.wings.none { WingRegistry.wingVisibleFor(it, ctx("TECH_ADMIN")) })
        assertTrue(WingRegistry.wings.none { WingRegistry.wingVisibleFor(it, ctx("EMERGENCY_ADMIN")) })
        assertTrue(WingRegistry.wings.all { WingRegistry.wingVisibleFor(it, ctx("MD")) })
    }

    // ---------------------------------------------------------------- workflow actions and maker-checker
    @Test fun makerCheckerNoSelfApprovalAndSimulatedApprovalFlow() {
        val po6 = DemoRepository.get(RecordRef(RecordType.PURCHASE_ORDER, "PO-006"))!!
        val po7 = DemoRepository.get(RecordRef(RecordType.PURCHASE_ORDER, "PO-007"))!!
        val md = ctx("MD")
        // PO-006 was made by EMP-103: the MD (EMP-100) may approve it
        val a = ActionPolicy.actionsFor(po6, DemoRepository.statusOf(po6), md).first { it.id == ActionId.APPROVE }
        assertTrue(a.enabled && a.simulated)
        // PO-007 is MY draft: I may submit it but never approve my own submitted transaction
        val sub = ActionPolicy.actionsFor(po7, RecordStatus.DRAFT, ctx("PURCHASE_OFFICER")).first { it.id == ActionId.SUBMIT }
        assertTrue(sub.enabled)
        val own = ActionPolicy.actionsFor(po7, RecordStatus.SUBMITTED, md).first { it.id == ActionId.APPROVE }
        assertFalse("own transaction must not be approvable", own.enabled)
        // a role without approval authority sees no approve action at all
        assertTrue(ActionPolicy.actionsFor(po6, RecordStatus.SUBMITTED, ctx("STOREKEEPER")).none { it.id == ActionId.APPROVE })
        // simulated approval changes only the overlay and adds a simulated history event
        DemoRepository.resetSimulation()
        assertTrue(DemoRepository.applyAction(po6, ActionId.APPROVE, md, ""))
        assertEquals(RecordStatus.APPROVED, DemoRepository.statusOf(po6))
        assertTrue(DemoRepository.historyOf(po6).last().simulated)
        assertEquals(RecordStatus.SUBMITTED, po6.status)                 // the base record is untouched
        assertFalse(DemoRepository.applyAction(po6, ActionId.APPROVE, md, ""))   // not submitted any more
        DemoRepository.resetSimulation()
        assertEquals(RecordStatus.SUBMITTED, DemoRepository.statusOf(po6))
    }

    @Test fun postedRecordsOfferNoEditDeleteOrDirectChange() {
        val pv = DemoRepository.get(RecordRef(RecordType.PAYMENT_VOUCHER, "PV-001"))!!
        val acts = ActionPolicy.actionsFor(pv, RecordStatus.POSTED, ctx("ACCOUNTANT"))
        assertTrue(acts.none { it.id == ActionId.EDIT_DRAFT || it.id == ActionId.CANCEL || it.id == ActionId.SUBMIT })
        val correct = acts.first { it.id == ActionId.CORRECT }
        assertFalse(correct.enabled)
        assertTrue(acts.filter { it.id == ActionId.EXPORT || it.id == ActionId.PRINT || it.id == ActionId.SHARE }.none { it.enabled })
    }

    // ---------------------------------------------------------------- production rules visible in data
    @Test fun qcHoldStockIsNotAvailableAndZeroProductionProductsStayListed() {
        val kp = DemoRepository.productKpis(java.time.LocalDate.parse("2026-10-01"), java.time.LocalDate.parse("2026-10-31"), ctx("MD"))
        assertEquals(6, kp.size)                                                    // all C1 products, including those with no production
        assertTrue(kp.any { it.producedPoly == 0 })
        val elaichi = kp.first { it.product.ref.id == "PRD-002" }
        assertEquals(780, elaichi.producedPoly); assertEquals(0, elaichi.fgAvailablePoly)  // produced but QC-held => not available
        assertEquals(1945, kp.first { it.product.ref.id == "PRD-001" }.fgAvailablePoly)
    }

    @Test fun everyBatchNamesTheExactBomVersionUsed() {
        for (b in DemoRepository.allRecords.filter { it.ref.type == RecordType.BATCH }) {
            val ver = b.info.first { it.label.startsWith("ব্যবহৃত BOM") }.value
            val bomId = ver.substringBefore(" ")
            assertNotNull(DemoRepository.get(RecordRef(RecordType.BOM, bomId)))
            assertTrue(b.related.any { g -> g.type == RecordType.BOM && g.refs.any { it.id == bomId } })
        }
        assertEquals(RecordStatus.SUPERSEDED, DemoRepository.get(RecordRef(RecordType.BOM, "BOM-001-V1"))!!.status)
    }

    @Test fun noFabricatedPolyConversionAndNoVatOrCctvAnywhere() {
        for (p in DemoRepository.allRecords.filter { it.ref.type == RecordType.PRODUCT && it.companyId == "C1" })
            assertTrue(p.info.any { it.label == "Poly-রূপান্তর" && it.value.contains("Pending") })
        val blob = DemoRepository.allRecords.joinToString(" ") { it.title + it.subtitle + it.info.joinToString { i -> i.value } }.lowercase()
        assertFalse(blob.contains("vat")); assertFalse(blob.contains("cctv"))
    }

    @Test fun jsonParserRejectsGarbageWithoutHidingIt() {
        var threw = false
        try { DemoJson.parse("{ not json") } catch (e: Exception) { threw = true }
        assertTrue(threw)
    }
}
