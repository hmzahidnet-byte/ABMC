# No custom rules needed for the debug build in v0.1.
