# Build Verification Report — Android v0.3

| Item | Result |
| --- | --- |
| Gradle Sync / Kotlin compile / Debug APK / run on a phone | **UNVERIFIED — never executed** (no Android SDK, Gradle, kotlinc or network in the authoring environment) |
| JVM unit tests (`DemoGraphTest`, `RoutesTest`) | **Written, NOT executed** |
| GitHub Actions run of this revision | **Pending** |

## Checks that WERE run (not compilation)
- `tools/gen_demo.py`: graph integrity (no dangling/asymmetric/cross-company links), non-negative stock, supplier ledger = dues, deterministic output.
- Python mirror of every JVM-test expectation against the real demo JSON: all hold.
- Static checks over 33 main + 2 test Kotlin files: bracket balance, project-import resolution (0 unresolved), no duplicate public top-level names, identifier/extension-import resolution (remaining findings are known false positives: `.size`, `.width`, `Triple`, BuildConfig constants).

## Biggest compile risks (cannot be excluded without a compiler)
Large amount of new Compose code (~4,800 Kotlin lines total); lambda-to-composable conversions; icon names from `material-icons-extended`; `ActionController.Dialogs()` member composable; `rememberSaveable` with nullable state; unit-test use of `mutableStateMapOf` outside Compose.

## Unchanged from v0.2
Versions: Gradle 8.9, AGP 8.5.2, Kotlin 2.0.20, Compose BOM 2024.09.00, compileSdk 34, minSdk 26, Java 17. Added only: `testImplementation` JUnit 4.13.2 and org.json 20231013. Backend untouched.
