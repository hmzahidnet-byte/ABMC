# Backend foundation (preserved, unchanged)
Supabase/PostgreSQL migrations, SQL tests, spikes S1–S3, release gate, Appendix A–H. **Nothing here has been executed against PostgreSQL/Supabase**; only the release-gate Python tests were run locally (12/12 pass; log in docs/EVIDENCE).
