# নিরাপত্তা-দাবির তালিকা: কোনটি অফলাইনে প্রমাণিত, কোনটি Staging ছাড়া প্রমাণ অসম্ভব

**পড়ার নিয়ম:** “অফলাইনে প্রমাণিত” মানে আমার পরিবেশে ৮২টি Python Test (`backend/ops/test_mohona_ops.py`) টুলের **যুক্তি** যাচাই করেছে, **মক করা Database** দিয়ে। এটি আসল PostgreSQL/Supabase/GitHub-এর আচরণের প্রমাণ নয়। আসল আচরণ বোঝা যাবে শুধু Staging-এ চালালে।

## ক. অফলাইনে প্রমাণিত (টুল/Workflow-ফাইলের যুক্তি)
| দাবি | প্রমাণ |
| --- | --- |
| Production Reference না থাকলে, অবৈধ হলে বা Staging-এর সমান হলে Workflow সঙ্গে সঙ্গে বন্ধ | Test: `MandatoryProductionRef`, `Identity` |
| লিংকের প্রজেক্ট ≠ ঘোষিত Staging / টাইপ-করা নিশ্চিতকরণ ভুল / Supabase-ছাড়া Host / Production-লিংক — সব প্রত্যাখ্যাত | `Identity` |
| Marker না থাকলে, Challenge না মিললে বা Challenge দুর্বল হলে সব বন্ধ; ডেটাবেসে শুধু Hash যায়, টোকেন নয় | `IndependentIdentityMarker` |
| Workflow নিজে Marker বানায় না | `ApplyFlow.test_ops_bookkeeping_never_creates_the_identity_marker` |
| Apply-এর আগে ফাইল, Commit, Manifest-হ্যাশ, Plan-হ্যাশ আবার যাচাই; যেকোনো পরিবর্তনে Apply বন্ধ; ফাইল-লোড ও চালানোর মাঝে বদলালেও (TOCTOU) বন্ধ | `ApplyFlow`, `ManifestAndHashes` |
| প্রতিটি Migration এক Transaction-এ; প্রথম ব্যর্থতায় থামা; ব্যর্থতার রিপোর্ট | `ApplyFlow` |
| Credentials কখনো GITHUB_ENV-এ লেখা হয় না; নতুন লাইন/NUL/Query-parameter ইনজেকশন প্রত্যাখ্যাত; Ambient `PG*` ভেরিয়েবল বাতিল; Password কখনো কমান্ড-লাইনে যায় না | `MandatoryProductionRef`, `CredentialHandling`, `WorkflowFile` |
| psql-এর Error, Summary ও Challenge লগ থেকে মুছে ফেলা (Redaction) | `CredentialHandling` |
| Test/Probe/প্রয়োজনীয় ফাইল অনুপস্থিত হলে, বা কোনো Test-ID সোর্স থেকে সরে গেলে Fail (Skip নয়) | `GateFlow`, `check_dependencies` |
| Gate: ৫৬টি নির্ধারিত ID-র যেকোনোটি Fail/অনুপস্থিত, কোনো Category-তে Negative Test না থাকা, Probe-এ ফাঁক বা Probe না চলা — সবই Gate Fail | `GateFlow` |
| Workflow শুধু Manual; শুধু দুটি Secret; প্রতি Checkout নির্দিষ্ট Commit-এ; Artifact-বিশ্বাস নেই; Apply Job-এ আলাদা Environment | `WorkflowFile` |
| ৯টি Migration-ফাইল নাম/ক্রম/নিষিদ্ধ-বাক্য যাচাইয়ে পাস; `E_AUTH` সংশোধন উপস্থিত ও মূল ফাইল সংরক্ষিত | `StaticValidation`, `SourceFilesGuard` |

## খ. Staging-এ চালানো ছাড়া প্রমাণ **অসম্ভব**
| দাবি | কেন অফলাইনে সম্ভব নয় | কীভাবে প্রমাণ হবে |
| --- | --- | --- |
| লিংকের `postgres.<ref>`-ইউজার সত্যিই ওই প্রজেক্টে পৌঁছায় (Supabase Pooler-এর আচরণ) | এটি Supabase-এর আচরণ সম্পর্কে আমার **অযাচাইকৃত অনুমান** | প্রথম Run + Marker-যাচাই |
| **URL-যাচাইয়ের সীমা:** লিংকের লেখা শুধু “দাবি”; ভুল প্রজেক্টের Credential লিংকের Reference বদলে দিলেও লেখা ঠিক দেখাবে না, কিন্তু আমরা সার্ভারের পরিচয় এই লেখা থেকে পাই না | URL-ভিত্তিক যাচাই সার্ভার-পরিচয়ের প্রমাণ নয় | **স্বাধীন Marker/Challenge** (ধাপ ২) — Dashboard-এ আপনার চোখে নিশ্চিত প্রজেক্টে তৈরি; একটি ভিন্ন Database এটি মেটাতে পারে না যদি না আপনি সেখানেও Marker বসান |
| Marker-যাচাইয়ের SQL (`sha256`, `convert_to`) PostgreSQL ১৭/Supabase-এ ঠিকমতো চলে | আমার পরিবেশে PostgreSQL নেই | প্রথম Run |
| ৯টি Migration বাস্তবে ত্রুটিহীন প্রয়োগ হয় (`SET ROLE erp_owner`, `CREATE ROLE`, ইত্যাদি অনুমতি) | অচালিত | Apply |
| সারণি/ফাংশন/Seed-সংখ্যা প্রত্যাশামতো (৩৪/১৭/৫৮-১৭-১৬৩) | প্রত্যাশা স্ক্রিপ্টে-গণনা; বাস্তব Database-মাপ নয় | Gate |
| **সব ৫৬টি SQL Test-এর আসল আচরণ**: RLS, Company-বিচ্ছিন্নতা, Permission, Ledger, Idempotency, Maker-Checker, Privilege | Test লেখা, কখনো চালানো হয়নি; SQL-এ ভুলও থাকতে পারে | Gate (ব্যর্থ হলে সেটি আবিষ্কার, ব্যর্থতা নয়) |
| `erp_owner` `auth.sessions` পড়তে পারে; `auth.uid()` GUC থেকে Claim পড়ে; `SET ROLE authenticated` চলে | Supabase-এর অভ্যন্তরীণ অনুমতি অযাচাইকৃত | `T-AUTH-1` ও `T-ISO-*` |
| anon/authenticated/service_role/authenticator ও কাস্টম Role-এর আসল অনুমতি (Supabase-এর ডিফল্ট Grant সহ) | আসল Supabase Role-মডেল ছাড়া জানা যায় না | `T-PRIV-1…8` ও Privilege Probe |
| `service_role` BYPASSRLS — **নকশাগতভাবে** RLS এড়ায়; আমাদের সুরক্ষা = টেবিল/ফাংশনে কোনো অনুমতি না দেওয়া | Supabase-এ এটি পরিবর্তনযোগ্য নয়; শুধু অনুমতির অনুপস্থিতি যাচাইযোগ্য | `T-PRIV-1,4,5` |
| PostgREST-এ শুধু `api` স্কিমা প্রকাশিত | Dashboard-সেটিংস; SQL-এ দেখা যায় না | **হাতে** Settings > API দেখুন; পরে S৩-এ REST-পরীক্ষা |
| RLS Policy-র Function-অনুমতি: `authenticated`-এর টেবিল-অনুমতিই নেই, তাই সরাসরি Select **বন্ধ-হয়ে-ব্যর্থ** (fail-closed); RLS-যুক্তি পরীক্ষা হয় Test-only Grant দিয়ে (Rollback হয়) | নকশার সিদ্ধান্ত; উৎপাদনে অ্যাপ টেবিল ছোঁয় না | `T-ISO-*` (+ `T-PRIV-1`) |
| GitHub Environment-এর Required reviewers/Branch-সীমা কার্যকর | GitHub-এর সেটিংস, Repository-ফাইলে নেই | আপনি Apply-এর সময় “Review deployments” দেখে নিশ্চিত হবেন |
| GitHub-এর নিজের Secret-Masking, Runner-এর Process-দৃশ্যমানতা, তৃতীয়-পক্ষ Action (`actions/*`, Tag-ভিত্তিক, SHA-পিন নয়) | প্ল্যাটফর্ম-বিশ্বাস; সরবরাহ-শৃঙ্খলের ঝুঁকি অবশিষ্ট | ভবিষ্যতে Action-গুলো যাচাইকৃত SHA-তে পিন |
| Validate ও Apply-এর **মধ্যে** কেউ Dashboard থেকে Database বদলালে ধরা | শুধু Apply-এর শুরুতে History-হ্যাশ মেলানো হয়; এরপরের হস্তক্ষেপ ধরা নেই | সতর্কতা + এক-সময়ে-একটি-Run (concurrency); অবশিষ্ট ঝুঁকি |

## ঘ. v3 সংযোজন: কোনটি কীভাবে প্রমাণিত
| দাবি | অফলাইনে প্রমাণিত (মক-করা GitHub API সহ) | Staging/GitHub-এ চালানো ছাড়া অপ্রমাণিত |
| --- | --- | --- |
| Apply Job নিজেই মূল Branch পুনঃযাচাই করে; মান না থাকলে বন্ধ (fail-closed) | ✔ `PolicyGates` | GitHub আসলে `GITHUB_REF_NAME`/default_branch কী দেয় — ধরে নেওয়া |
| Reviewer-অনুমোদন আসলে রেকর্ড হয়েছে কি না GitHub API থেকে প্রমাণ; নইলে Apply/Post-check বন্ধ | ✔ যুক্তি | API-এন্ডপয়েন্ট (`…/actions/runs/{id}/approvals`) ও তার ক্ষেত্রগুলো আমার **স্মৃতি-নির্ভর, যাচাইহীন**; `GITHUB_TOKEN`-এ `actions: read` যথেষ্ট কি না — প্রথম `approval-check` Run-এ দেখা যাবে। ব্যর্থ হলে বন্ধ-হয়ে-ব্যর্থ (Apply আটকায়), ফাঁক খোলে না |
| সফল validate-only Run (একই Commit, `workflow_dispatch`, একই Workflow, ৭২ঘ) ছাড়া Apply নেই | ✔ যুক্তি | Run-এর `display_title`/`path`/`head_sha` ক্ষেত্রগুলোর আসল রূপ অযাচাইকৃত |
| Final File Checklist: ফাইল বাদ বা পুরোনো সংস্করণ থাকলে Static ধাপ Fail | ✔ `LayoutChecks` | — |
| Migration-ফাইলের ক্রম/নির্ভরতা (কোন Object আগে তৈরি) | ✔ স্ট্যাটিক (পার্সার নয়; ফরোয়ার্ড-রেফারেন্স ও অনুপস্থিত Object ধরা পড়ে) | SQL-এর সিনট্যাক্স ও আসল চলা — শুধু Staging-এ |
| `E_AUTH` সংশোধনের কাঠামো (এক CASE/ELSE/END, বন্ধনী মিলেছে, নির্ভর-ফাংশন আগে তৈরি) | ✔ | আসল আচরণ: `T-PERM-1`, `T-PERM-6…8`, `T-AUTH-1` Staging-এ |

## গ. নতুন এক আবিষ্কার (Test নকশার সময়)
`core.fn_get_my_permissions()` কখনো `E_AUTH` ফেরত দিতে পারত না (`jsonb_build_object` কখনো NULL নয়)। কোনো Migration এখনো কোথাও প্রয়োগ হয়নি বলে ফাইলটি স্থানে সংশোধন করা হয়েছে; মূল ফাইল `backend/supabase/original_unapplied/`-এ, কারণ ও SHA `CHANGES_BEFORE_FIRST_APPLY.md`-এ। এটি **চালিয়ে যাচাই হয়নি**।
