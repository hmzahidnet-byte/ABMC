# Staging Migration Workflow — ফোন থেকে ব্যবহারের সহজ নির্দেশিকা

> **সততা-নোট:** Workflow ও টুল লেখা হয়েছে এবং **৮২টি অফলাইন** Test সফলভাবে চালানো হয়েছে (Database ছাড়া)। কোন নিরাপত্তা-দাবি অফলাইনে প্রমাণিত আর কোনটি শুধু Staging-এ চালিয়ে প্রমাণযোগ্য, তা `SECURITY_CLAIMS_BN.md`-এ আছে। কিন্তু Workflow নিজে GitHub-এ **এখনো চালানো হয়নি**, আর কোনো Migration কোনো Database-এ **প্রয়োগ হয়নি**। Supabase/GitHub-এর মেনুর নাম সংস্করণভেদে সামান্য আলাদা হতে পারে (আমি আপনার স্ক্রিন দেখিনি)।

**ব্যবহারের ক্রম (এই ক্রম ভাঙা যাবে না):** ধাপ ০ ফাইল বসানো → ধাপ ১–৩ প্রস্তুতি → ধাপ ৪ `approval-check` → ধাপ ৫ `validate-only` → ধাপ ৬ **Log ও Summary দেখা/পাঠানো** → (পর্যালোচনার পর) ধাপ ৭ `apply`। **validate-only-এর Log ও Summary না দেখে কোনো Migration Apply করা যাবে না** — Workflow নিজেও এটি প্রযুক্তিগতভাবে আটকায় (সফল validate-only Run-এর নম্বর ছাড়া Apply চলে না)।

**মূল নিরাপত্তা-নিয়ম:** এই Workflow **শুধু Staging**-এ চলে। Production-এর কোনো পাসওয়ার্ড/লিংক এখানে কখনো দেবেন না। কোনো পাসওয়ার্ড বা কী কখনো চ্যাটে, ছবিতে বা Repository-র ফাইলে লিখবেন না।

## ধাপ ০ — ফাইল বসানো ও “Final File Checklist” মেলানো
1. **শুধু `Mohona_P0_Consolidated_Overlay_v3.zip`** ব্যবহার করুন; পুরোনো v1/v2 Patch আলাদাভাবে আর বসাবেন না (সব ফাইলের চূড়ান্ত রূপ v3-তে আছে)। ZIP-এর ফাইলগুলো Repository-তে **একই পথে** বসান (পুরোনো ফাইল অতিক্রম করে)। অনুলিপি-পেস্টের বদলে ফাইল-আপলোড/Git ব্যবহার করুন, যাতে ফাইলের বাইট অক্ষত থাকে।
2. `backend/ops/FINAL_FILE_CHECKLIST.md` খুলে প্রতিটি ফাইল Repository-তে আছে কি এবং লাইন-সংখ্যা মেলে কি দেখুন।
3. কোনো ফাইল বাদ পড়লে বা পুরোনো সংস্করণ থাকলে Workflow-এর প্রথম (Static) ধাপ **নিজেই ধরে ফেলে**: “MISSING FILE …” বা “WRONG VERSION of … expected N lines”। (লাইন-শেষ CRLF/LF ও শেষ নতুন-লাইনের পার্থক্যে ভুল সতর্কতা আসে না।)

## ধাপ ১ — Supabase থেকে তথ্য নিন (Staging এবং Production-এর Project Reference দুটিই লাগবে)
1. Supabase-এ আপনার **Staging** প্রজেক্ট খুলুন (নাম যেমন `mohona-erp-staging`)। Production নয়।
2. **Project Reference ID** খুঁজুন (প্রজেক্ট-সেটিংসের General পাতায় থাকে; ছোট হাতের অক্ষর-সংখ্যার ~২০ অক্ষরের কোড)। এটি `STAGING_PROJECT_REF`।
3. **Database Connection String** নিন: প্রজেক্টের Connect (সংযোগ) অংশে **“Session pooler”** ধরনের `postgresql://…` লিংকটি কপি করুন। লিংকের `[YOUR-PASSWORD]` জায়গায় আপনার Database-পাসওয়ার্ড বসান। (Session pooler বেছে নিন, কারণ GitHub-এর মেশিন IPv4 ব্যবহার করে। পাসওয়ার্ডে বিশেষ চিহ্ন থাকলে সেটি URL-এনকোডেড হতে হবে।) এটি `STAGING_DB_URL` — **একদম গোপন**।
4. **Production প্রজেক্টের Reference ID** (শুধু ID; Production-এর পাসওয়ার্ড বা লিংক কোথাও দেবেন না)। এটি `PRODUCTION_PROJECT_REF` — **এখন বাধ্যতামূলক**। দুটি ID এক হলে Workflow সঙ্গে সঙ্গে বন্ধ হয়।
5. একটি **গোপন চ্যালেঞ্জ-টোকেন** বানান: কমপক্ষে ৩২ অক্ষরের এলোমেলো লেখা (ফোনের পাসওয়ার্ড-জেনারেটর ব্যবহার করুন; এটি অন্য কোথাও ব্যবহার করবেন না)। এটি `STAGING_CHALLENGE`।

## ধাপ ২ — স্বাধীন পরিচয়-চিহ্ন (Marker): Staging-এর নিজের Dashboard থেকে, একবার
কেন: লিংকের লেখা শুধু “দাবি” করে কোন প্রজেক্ট; ভুল পাসওয়ার্ড/লিংক বসালেও লেখা ঠিক দেখাতে পারে। তাই একটি **দ্বিতীয়, স্বাধীন প্রমাণ** লাগে: আপনি Staging প্রজেক্টের **নিজের Dashboard-এর SQL Editor** খুলে (ওপরে প্রজেক্টের নাম Staging কি না চোখে দেখে নিন) নিচের কোড চালান। `<আপনার-টোকেন>` জায়গায় ধাপ ১-এর `STAGING_CHALLENGE` হুবহু বসান। ডেটাবেসে টোকেন নয়, শুধু তার SHA-256 হ্যাশ থাকে।

```sql
create schema if not exists ops;
create table if not exists ops.environment_marker (
  id boolean primary key default true check (id),
  value text not null,
  challenge_sha256 text not null,
  created_at timestamptz not null default now()
);
insert into ops.environment_marker (value, challenge_sha256)
values ('staging', encode(sha256(convert_to('<আপনার-টোকেন>', 'UTF8')), 'hex'))
on conflict (id) do nothing;
```
**কখনো Production-এ এটি চালাবেন না।** এই Marker ছাড়া Workflow কিছুই করে না (`validate-only`-ও না) এবং Workflow নিজে এটি বানায় না। (প্রথম চালানোয় SQL-এর সিনট্যাক্স ভুল দেখালে আমাকে ত্রুটিটি পাঠান; এই কোড এখনো কোনো Database-এ চালানো হয়নি।)

## ধাপ ৩ — GitHub-এ দুটি Environment বানান
ফোনের ব্রাউজারে GitHub খুলে “Desktop site” চালু করলে সহজ হয়।
Repository → **Settings → Environments → New environment**।

**ক) Environment: `staging-validate`**
- Environment secrets → **Add secret**: `STAGING_DB_URL` (ধাপ ১-এর লিংক) এবং `STAGING_CHALLENGE` (ধাপ ১-এর টোকেন)।
- Environment variables → **Add variable**: `STAGING_PROJECT_REF` (Staging-এর Reference ID) এবং `PRODUCTION_PROJECT_REF` (Production-এর Reference ID — **বাধ্যতামূলক**)।

**খ) Environment: `staging-apply`**
- একই দুটি secret (`STAGING_DB_URL`, `STAGING_CHALLENGE`) এবং একই দুটি variable (`STAGING_PROJECT_REF`, `PRODUCTION_PROJECT_REF`) এখানেও দিন।
- **Required reviewers** চালু করে নিজেকে যোগ করুন। (আপনি একাই ব্যবহারকারী হলে “Prevent self-review” **চালু করবেন না**।)
- **Deployment branches** → “Selected branches” → `main` (আপনার মূল Branch)।
- **যাচাই করুন (GitHub সেটিংস ফাইল থেকে প্রমাণ করা যায় না):** Apply চালানোর সময় অবশ্যই “Review deployments” অনুমোদন চাইতে হবে। না চাইলে `staging-apply`-এ Required reviewers চালু নেই — সঙ্গে সঙ্গে থামুন ও ঠিক করুন।

একবার Secret সেভ করলে আর দেখা যায় না; ভুল হলে মুছে নতুন করে দিন।

## ধাপ ৪ — Reviewer-নিয়ম আসলে সক্রিয় কি না, Apply-এর আগে প্রমাণ করুন (`approval-check`)
GitHub-এর Environment-সেটিংস Repository-ফাইল থেকে যাচাই করা যায় না; তাই এই আলাদা পরীক্ষা (কোনো Database ছোঁয় না):
1. Actions → “Staging Migrations (manual)” → Run workflow → **mode = `approval-check`**, `confirm_project_ref` = Staging Reference ID।
2. “Reviewer approval check” Job-এ GitHub “Review deployments” চাইবে → **Approve** করুন।
3. Job সবুজ হলে Summary-তে লেখা থাকবে “a recorded reviewer approval exists for staging-apply” এবং কে অনুমোদন দিয়েছেন (লগে `Reviewer approval recorded … by: <নাম>`)।
4. **যদি “Review deployments” একেবারেই না আসে** (Job সরাসরি চলে গেলে) তাহলে `staging-apply`-এ Required reviewers চালু নেই — Workflow “no recorded reviewer approval” বলে **নিজে ব্যর্থ হবে**। Settings → Environments → staging-apply-তে Required reviewers চালু করে আবার চালান।
এই পরীক্ষা সবুজ না হলে ধাপ ৫-এর পরে এগোবেন না।

## ধাপ ৫ — শুধু যাচাই (`validate-only`; কিছু বদলায় না)
1. Repository → **Actions** → বাঁদিকের তালিকা থেকে **“Staging Migrations (manual)”** → **Run workflow**।
2. **mode** = `validate-only` (Branch অবশ্যই মূল Branch); **confirm_project_ref** = Project Reference ID হুবহু টাইপ করুন; **Run workflow**।
3. ধাপ ১ (Static) নিজে চলবে। ধাপ ২ শুরুর আগে GitHub আপনাকে **“Review deployments”** দেখাতে পারে (Environment-এ reviewer দিলে); **Approve** করুন।
4. শেষে Run-এর **Summary** পাতায় দেখুন: Static ফল (কমিট ও Manifest-হ্যাশসহ), “URL-level identity check passed”, “Independent marker/challenge: verified”, এবং “Migration plan: Applied … Pending …”। প্রথমবার সব ৯টি Pending থাকাই স্বাভাবিক।
5. কোথাও লাল ✗ হলে ভেতরে ক্লিক করে ত্রুটির বার্তা দেখুন (পাসওয়ার্ড কখনো দেখাবে না) এবং আমাকে সেই বার্তা পাঠান।

## ধাপ ৬ — Log ও Summary দেখুন ও পাঠান; **এর আগে Apply নয়**
Run সবুজ হলে নিচের সবকটি স্ক্রিনশট (বা কপি) আমাকে ও আপনার স্বতন্ত্র Technical Reviewer-কে পাঠান; আমরা পর্যালোচনা না করা পর্যন্ত থামুন:
- Run-এর ঠিকানা (URL) — শেষের সংখ্যাটি (`…/actions/runs/<সংখ্যা>`) আপনার `validated_run_id`।
- Summary পাতা: (ক) Static validation — Commit, Manifest-হ্যাশ, ৯টি ফাইল, “PASSED”; (খ) URL-level identity passed; (গ) “Independent marker/challenge: verified”; (ঘ) “Migration plan: Applied 0 | Pending 9”।
- Job-গুলোর লগে লাল লাইন বা “WARNING” আছে কি না।
**যাচাই-র লক্ষণ:** ৯টি Pending, Applied ০, Marker verified, কোনো ত্রুটি নেই। অন্যথায় থামুন।

## ধাপ ৭ — প্রয়োগ (Apply) — শুধু ধাপ ৬-এর পর্যালোচনা শেষে
শুধু ধাপ ৪ ও ৫ সবুজ এবং ধাপ ৬-এর পর্যালোচনা শেষ হলে (এবং **Commit অপরিবর্তিত** থাকলে; Commit বদলালে আবার ধাপ ৫):
1. **Run workflow** → **mode** = `apply`; **confirm_project_ref** = Reference ID; **confirm_apply** = `APPLY-TO-STAGING` (হুবহু); **validated_run_id** = ধাপ ৬-এর সফল validate-only Run-এর সংখ্যা। Workflow নিজে যাচাই করে: Run-টি সফল, একই Commit-এর, `validate-only`, এবং ৭২ ঘণ্টার মধ্যের — নইলে Apply বন্ধ।
2. যাচাই-ধাপ শেষে **“Apply”** Job আপনার **Approve** চাইবে (staging-apply Environment)। অনুমোদনের পর Job নিজে আবার সব যাচাই করে (মূল Branch, GitHub-এ রেকর্ড-হওয়া Reviewer-অনুমোদন, আগের validate-only Run, ফাইল, Commit, Manifest-হ্যাশ, Marker, Database-History); যাচাই-এর পর কিছু বদলে থাকলে প্রয়োগ **বন্ধ**। অনুমোদন দিলে ৯টি Migration একে একে প্রয়োগ হবে — প্রতিটি **এক Transaction-এ**; কোনোটি ব্যর্থ হলে সেটি পুরোপুরি ফেরত (Rollback) হয়ে পরের ধাপ বন্ধ।
3. সফল হলে একই Job-এ **P0 Database Gate** চলে (সারণি/ফাংশন/Seed গণনা, SQL Test, Privilege Probe)। ফল Summary ও Artifact **apply-and-gate-reports**-এ।

## যে ফল পেলে P0 Gate “পাস” নয়
- মাপা সারণি/ফাংশন/Seed-সংখ্যা প্রত্যাশার (`backend/ops/expected.json`) সাথে না মিললে।
- ৫৬টি নির্ধারিত Test-ID-র **যেকোনো একটি** Fail বা ফলাফল-অনুপস্থিত হলে (শুধু PASS গোনা যথেষ্ট নয়)।
- Coverage: privilege, rls, company_isolation, permission, ledger, idempotency, approval, audit — প্রতিটি বিভাগে সব Test পাস এবং অন্তত একটি **Negative** (নিষিদ্ধ কাজ আটকানো) Test পাস না হলে।
- Privilege Probe-এ **কোনো একটি ফাঁক** (`holes > 0`) বা Probe না চললে — এটি **Blocker**।
- মনে রাখবেন: এই Workflow শুধু E৫–E৭ মাপে। E১–E৪, E৮–E১০ (APK, PG-সংস্করণ, Auth-সময়, Android-সংযুক্ত-লগইন, প্রমাণ-প্যাক) আলাদা; তাই “Gate পাস” মানে পুরো P0 শেষ নয়।

## ব্যর্থ হলে (Recovery)
**কীভাবে বুঝবেন:** Run লাল; Artifact `apply-and-gate-reports`-এর `apply-report.md`-এ লেখা থাকে কোন ফাইল ব্যর্থ, কোন ফাইলগুলো সফল, আর Database-এর বর্তমান অবস্থা।

| পরিস্থিতি | কী হয়েছে | কী করবেন |
| --- | --- | --- |
| **একটি Migration ব্যর্থ** | ওই ফাইলটি এক Transaction-এ ছিল, তাই পুরো ফেরত; আগের ফাইলগুলো সফল ও History-তে লেখা; পরেরগুলো চলেনি | `apply-report.md` আমাকে পাঠান। যে ফাইল **কখনো সফলভাবে প্রয়োগ হয়নি**, সেটি আমি **সংশোধন** করব (নিয়ম অনুযায়ী অনুমোদিত); তারপর আবার `validate-only` → `apply`। **প্রয়োগ-হওয়া ফাইল কখনো বদলাবে না**। |
| **“MODIFIED-AFTER-APPLY”** | প্রয়োগ-হওয়া ফাইল কেউ বদলেছে (Hash মেলেনি) | ফাইলটি আগের অবস্থায় ফেরত দিন; পরিবর্তন লাগলে **নতুন Forward Migration** (নতুন তারিখ-নামের ফাইল) যোগ হবে। History হাতে ঠিক করবেন না। |
| **“OUT-OF-ORDER” / “APPLIED-BUT-MISSING”** | History আর Repository মিলছে না | কিছু চালাবেন না; Summary আমাকে পাঠান। |
| **“Identity”/“PRODUCTION”/“IDENTICAL” ত্রুটি** | লিংক ঘোষিত Staging-এর নয়, Production, বা দুটি Reference এক | সঙ্গে সঙ্গে থামুন; Secret/Variable ঠিক করুন; কিছু চলার আগেই বন্ধ হয়েছে। |
| **“independent marker NOT found / FAILED”** | ধাপ ২-এর Marker নেই, বা টোকেন মেলেনি (ভুল Database হতে পারে) | কিছু চালাবেন না। Dashboard-এ Staging প্রজেক্টটি চোখে নিশ্চিত করে ধাপ ২ আবার করুন; `STAGING_CHALLENGE` Secret মিলিয়ে দেখুন। |
| **“files changed between validation and apply” / “history changed” / “commit changed”** | যাচাই ও প্রয়োগের মাঝে কিছু বদলেছে | Apply বন্ধ হয়েছে (সঠিক আচরণ)। আবার `validate-only` থেকে শুরু করুন। |
| **“MISSING FILE” / “WRONG VERSION of …”** | Patch অসম্পূর্ণ বা পুরোনো ফাইল | `FINAL_FILE_CHECKLIST.md` মিলিয়ে নির্দেশিত ফাইলটি v3 Overlay থেকে আবার বসান। |
| **“no recorded reviewer approval”** | `staging-apply`-এ Required reviewers সক্রিয় নয় | ধাপ ৪। |
| **“validated_run_id … required / DIFFERENT commit / not a validate-only run / older than 72 hours”** | আগের validate-only প্রমাণ নেই বা মেলে না | ধাপ ৫ আবার চালিয়ে নতুন Run-এর সংখ্যা দিন। |
| **“required file missing” / “test id … not present”** | Repository-তে Test বা Probe ফাইল নেই/বদলানো | ফাইলটি ফিরিয়ে দিন; Workflow এটি Skip করে না, Fail করে। |
| **Test Fail / Privilege-ফাঁক** | Migration সফল কিন্তু নিরাপত্তা/হিসাব-নকশায় ত্রুটি | `p0-gate-report.md` পাঠান; আমি নতুন Forward Migration বা সংশোধন লিখব; ফাঁক না মেটা পর্যন্ত P0 পাস নয়। |
| **Database এলোমেলো মনে হচ্ছে** | অজানা অবস্থা | Staging-এ সবচেয়ে নিরাপদ: Supabase-এ **নতুন Staging প্রজেক্ট** খুলে Secret বদলে শুরু থেকে আবার। (পুরোনো Staging প্রজেক্ট মুছুন নিজে, Production নয়।) স্বয়ংক্রিয় “Reset” বানানো হয়নি, কারণ সেটি বিপজ্জনক। |

**Migration-ফ্রিজ নিয়ম:** কোনো ফাইল প্রথম সফল প্রয়োগের পর বদলানো নিষিদ্ধ (Workflow Hash মিলিয়ে ধরে ফেলে)। পরবর্তী সব বদল নতুন Forward Migration।

## ফোনে নিরাপদে চালানোর টিপস
- পাসওয়ার্ড/লিংক কাউকে পাঠাবেন না; স্ক্রিনশটে Secret-এর মান আসতে দেবেন না।
- ভুল করে কোথাও লিংক প্রকাশ হয়ে গেলে: Supabase-এ Database-পাসওয়ার্ড বদলান, তারপর GitHub Secret হালনাগাদ করুন।
- Workflow খুঁজে না পেলে Repository-তে `.github/workflows/staging-migrations.yml` ফাইলটি আছে কি এবং Branch `main` কি দেখুন।
- “Review deployments” বোতাম না এলে Environment-এ Required reviewers চালু আছে কি দেখুন।
