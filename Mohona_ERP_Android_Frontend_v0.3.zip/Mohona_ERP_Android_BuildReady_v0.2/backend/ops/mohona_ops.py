#!/usr/bin/env python3
"""Mohona ERP — Staging migration operations (standard library only).

Sub-commands (all configuration comes from environment variables so that no secret ever appears on a command line):
  static    validate migration files offline (names, order, forbidden statements) and write a manifest
  identity  prove the connection string points at the declared STAGING project (never Production)
  plan      read the applied-migration history from the database and compute what is pending (read-only)
  apply     create the ops bookkeeping objects and apply pending migrations one file at a time (single transaction per file)
  checks    post-apply verification: object counts, SQL tests, privilege probe -> P0 gate verdict
  approval  prove (via the GitHub API) that a reviewer really approved THIS run for the staging-apply environment; default-branch only
  write-layout  (developer helper, never run by CI) regenerate backend/ops/file_manifest.json after an intentional change

Secrets: STAGING_DB_URL and STAGING_CHALLENGE are read from the environment only. Nothing secret is ever written to GITHUB_ENV, argv or logs;
connection settings are rebuilt in-process for every psql call and every output is redacted.
"""
import datetime, hashlib, json, os, re, subprocess, sys, urllib.request
from urllib.parse import urlparse, unquote

NAME_RE = re.compile(r'^(\d{14})_([a-z0-9_]+)\.sql$')
APPLY_PHRASE = 'APPLY-TO-STAGING'

# Statement-initial patterns only (so that e.g. "before truncate" inside a trigger definition is not flagged).
FORBIDDEN = [
    (r'(?im)^\s*drop\s+database\b', 'DROP DATABASE'),
    (r'(?im)^\s*drop\s+schema\b', 'DROP SCHEMA'),
    (r'(?im)^\s*drop\s+role\b', 'DROP ROLE'),
    (r'(?im)^\s*truncate\b', 'TRUNCATE'),
    (r'(?is)\balter\s+(?:role|user)\b[^;]*\bpassword\b', 'ALTER ROLE/USER ... PASSWORD'),
    (r'(?ims)^\s*grant\b[^;]*\bon\s+(?:all\s+)?(?:tables?|sequences?)\b[^;]*\bto\b[^;]*\b(?:anon|authenticated|public|service_role)\b', 'table/sequence GRANT to an API role'),
    (r'(?i)(?<!no)bypassrls', 'BYPASSRLS'),
    (r'(?im)^\s*copy\b[^;]*\bprogram\b', 'COPY ... PROGRAM'),
    (r'(?m)^\s*\\', 'psql meta-command'),
]

# ----------------------------------------------------------------------------- helpers

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        h.update(f.read())
    return h.hexdigest()

def sql_lit(s):
    return "'" + str(s).replace("'", "''") + "'"

def secret_values():
    vals = set()
    url = os.environ.get('STAGING_DB_URL', '')
    if url:
        vals.add(url)
        try:
            u = urlparse(url)
            if u.password:
                vals.add(u.password); vals.add(unquote(u.password))
        except Exception:
            pass
    pw = os.environ.get('PGPASSWORD', '')
    if pw:
        vals.add(pw)
    gh = os.environ.get('GH_TOKEN', '')
    if gh:
        vals.add(gh)
    ch = os.environ.get('STAGING_CHALLENGE', '')
    if ch:
        vals.add(ch.strip())
        vals.add(hashlib.sha256(ch.strip().encode('utf-8')).hexdigest())
    return {v for v in vals if v and len(v) >= 4}

def redact(text):
    for v in sorted(secret_values(), key=len, reverse=True):
        text = text.replace(v, '***')
    return text

def say(msg):
    print(redact(str(msg)), flush=True)

def summary(md):
    path = os.environ.get('GITHUB_STEP_SUMMARY')
    if path:
        with open(path, 'a', encoding='utf-8') as f:
            f.write(redact(md) + '\n')


REF_RE = re.compile(r'^[a-z0-9]{16,32}$')

def has_control_chars(text):
    return any(ord(c) < 32 or ord(c) == 127 for c in text)

def validate_refs(staging_ref, production_ref):
    """Both project references are MANDATORY and must differ."""
    errors = []
    if not staging_ref:
        errors.append('STAGING_PROJECT_REF variable is missing in this GitHub Environment')
    if not production_ref:
        errors.append('PRODUCTION_PROJECT_REF variable is REQUIRED (the workflow must know which project it must never touch)')
    for name, val in (('STAGING_PROJECT_REF', staging_ref), ('PRODUCTION_PROJECT_REF', production_ref)):
        if val and not REF_RE.match(val):
            errors.append('%s is not a valid project reference (16-32 lowercase letters/digits)' % name)
    if staging_ref and production_ref and staging_ref == production_ref:
        errors.append('STAGING and PRODUCTION project references are IDENTICAL: workflow stopped immediately')
    return errors

def manifest_hash(manifest):
    canon = json.dumps([[m['filename'], m['sha256']] for m in manifest], separators=(',', ':'))
    return hashlib.sha256(canon.encode('utf-8')).hexdigest()

def plan_hash(plan):
    canon = json.dumps({'applied': [[m['filename'], m['sha256']] for m in plan['applied']],
                        'pending': [[m['filename'], m['sha256']] for m in plan['pending']]}, separators=(',', ':'))
    return hashlib.sha256(canon.encode('utf-8')).hexdigest()

def challenge_hash(token):
    return hashlib.sha256(token.strip().encode('utf-8')).hexdigest()

def github_output(key, value):
    """Only hex digests / commit SHAs are ever written here (no newline possible)."""
    path = os.environ.get('GITHUB_OUTPUT')
    if path and re.fullmatch(r'[0-9a-f]{40,64}', str(value)):
        with open(path, 'a', encoding='utf-8') as f:
            f.write('%s=%s\n' % (key, value))

def git_head():
    r = subprocess.run(['git', 'rev-parse', 'HEAD'], capture_output=True, text=True)
    return r.stdout.strip() if r.returncode == 0 else ''

def check_dependencies(expected, root):
    """Offline completeness check: every file the gate relies on must exist, every expected test id must be present in its SQL
    file, every category must contain a negative test. Missing anything = failure (never a silent skip)."""
    errors = []
    for rel in expected.get('required_files', []):
        if not os.path.isfile(os.path.join(root, rel)):
            errors.append('required file missing: ' + rel)
    probe = expected.get('probe_file')
    if not probe or not os.path.isfile(os.path.join(root, probe)):
        errors.append('privilege probe file missing: %s' % probe)
    tdir = expected.get('test_dir', '')
    all_ids = set()
    for fn, ids in expected.get('test_files', {}).items():
        path = os.path.join(root, tdir, fn)
        if not os.path.isfile(path):
            errors.append('test file missing: %s/%s' % (tdir, fn))
            continue
        text = open(path, encoding='utf-8').read()
        for tid in ids:
            all_ids.add(tid)
            if "'" + tid + "'" not in text:
                errors.append('test id %s is not present in %s (a test was removed or renamed)' % (tid, fn))
    for tid in expected.get('tests', {}):
        if tid not in all_ids:
            errors.append('test id %s is not mapped to any test file' % tid)
    neg = set(expected.get('negative_ids', []))
    for cat, ids in expected.get('categories', {}).items():
        if not any(i in neg for i in ids):
            errors.append('coverage category "%s" has no negative test' % cat)
        for i in ids:
            if i not in expected.get('tests', {}):
                errors.append('category %s references unknown test id %s' % (cat, i))
    for needed in ('privilege', 'rls', 'company_isolation', 'permission', 'ledger', 'idempotency'):
        if needed not in expected.get('categories', {}):
            errors.append('required coverage category missing: ' + needed)
    return errors

def static_gate(directory, expected, root):
    """Everything that can be proven offline. Used by `static` and again inside the approved `apply` job."""
    errors, manifest = validate_files(directory)
    errors += check_dependencies(expected, root)
    errors += verify_layout(root)
    if os.path.isdir(directory):
        errors += check_sql_dependencies(directory)
    sha = os.environ.get('GITHUB_SHA', '')
    if sha:
        head = git_head()
        if head != sha:
            errors.append('checked-out commit does not match the commit this workflow run was started from')
        pinned = os.environ.get('EXPECTED_GIT_SHA', '')
        if pinned and pinned != sha:
            errors.append('commit changed between validation and apply')
    return errors, manifest, manifest_hash(manifest)


# ----------------------------------------------------------------------------- branch policy, GitHub-API gates

def branch_errors():
    """Default-branch policy, re-checked inside every job that touches the database. Fails closed: both values must be present."""
    ref, default = os.environ.get('GITHUB_REF_NAME', ''), os.environ.get('DEFAULT_BRANCH', '')
    if not ref or not default:
        return ['branch policy cannot be verified (GITHUB_REF_NAME / DEFAULT_BRANCH missing)']
    if os.environ.get('GITHUB_REF_TYPE', 'branch') != 'branch':
        return ['this workflow runs only from a branch, not from a tag']
    if ref != default:
        return ['this job runs only on the default branch (%s), not on %s' % (default, ref)]
    return []

def gh_api(path):
    token = os.environ.get('GH_TOKEN', '')
    if not token:
        raise RuntimeError('GH_TOKEN is not available (the job needs permissions: actions: read)')
    req = urllib.request.Request('https://api.github.com' + path, headers={
        'Authorization': 'Bearer ' + token, 'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'mohona-ops'})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode('utf-8'))

def _repo_and_run():
    repo, run = os.environ.get('GITHUB_REPOSITORY', ''), os.environ.get('GITHUB_RUN_ID', '')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repo) or not re.fullmatch(r'\d{1,20}', run):
        raise RuntimeError('GITHUB_REPOSITORY / GITHUB_RUN_ID missing or malformed')
    return repo, run

def approval_errors(environment='staging-apply'):
    """Proves the required-reviewer rule is ACTIVE: a job in a protected environment only starts after a recorded approval.
    If the environment has no required reviewers there is no approval record, and this check blocks the run."""
    try:
        repo, run = _repo_and_run()
        data = gh_api('/repos/%s/actions/runs/%s/approvals' % (repo, run))
    except Exception as e:
        return ['cannot verify the reviewer approval (%s): fail-closed' % e.__class__.__name__]
    good = [a for a in (data if isinstance(data, list) else []) if a.get('state') == 'approved'
            and any(env.get('name') == environment for env in (a.get('environments') or []))]
    if not good:
        return ['no recorded reviewer approval for environment "%s": Required reviewers are probably NOT active. Stop and fix the environment.' % environment]
    who = ', '.join(sorted({(a.get('user') or {}).get('login', '?') for a in good}))
    say('Reviewer approval recorded for "%s" by: %s' % (environment, who))
    return []

def prior_validation_errors(max_age_hours=72):
    """Apply is only possible after a SUCCESSFUL validate-only run of this same workflow on this same commit (typed run id)."""
    rid = os.environ.get('VALIDATED_RUN_ID', '').strip()
    if not re.fullmatch(r'\d{1,20}', rid):
        return ['validated_run_id (the numeric id of your successful validate-only run) is required for apply']
    try:
        repo, this_run = _repo_and_run()
        if rid == this_run:
            return ['validated_run_id cannot be this run itself']
        run = gh_api('/repos/%s/actions/runs/%s' % (repo, rid))
    except Exception as e:
        return ['cannot verify the validate-only run (%s): fail-closed' % e.__class__.__name__]
    errs = []
    sha = os.environ.get('GITHUB_SHA', '')
    if run.get('status') != 'completed' or run.get('conclusion') != 'success':
        errs.append('the referenced run did not complete successfully')
    if run.get('head_sha') != sha or not sha:
        errs.append('the referenced run was for a DIFFERENT commit (validate again on this commit)')
    if run.get('event') != 'workflow_dispatch':
        errs.append('the referenced run was not a manual run')
    if not str(run.get('path', '')).endswith('staging-migrations.yml'):
        errs.append('the referenced run is not this workflow')
    if ' | validate-only | ' not in str(run.get('display_title', '')):
        errs.append('the referenced run was not a validate-only run')
    try:
        done = datetime.datetime.fromisoformat(str(run.get('updated_at', '')).replace('Z', '+00:00'))
        if (datetime.datetime.now(datetime.timezone.utc) - done).total_seconds() > max_age_hours * 3600:
            errs.append('the referenced validate-only run is older than %d hours (validate again)' % max_age_hours)
    except ValueError:
        errs.append('cannot read the time of the referenced run')
    return errs

# ----------------------------------------------------------------------------- SQL dependency order (offline)

_DEF_TABLE = re.compile(r'(?im)^\s*create\s+(?:unlogged\s+)?table\s+(?:if\s+not\s+exists\s+)?([a-z_]+\.[a-z_0-9]+)')
_DEF_FUNC = re.compile(r'(?im)^\s*create\s+(?:or\s+replace\s+)?function\s+([a-z_]+\.[a-z_0-9]+)')
_REF = re.compile(r'\b(core|finance|hr|api|svc)\.([a-z_][a-z_0-9]*)')

def check_sql_dependencies(directory):
    """Every project-schema object (core./finance./hr./api./svc.) must be created in an EARLIER migration or earlier in the same file
    than its first use. Catches ordering mistakes before a database ever sees the files. (Not a SQL parser: syntax is proven only by running.)"""
    errors, known = [], set()
    for name in sorted(n for n in os.listdir(directory) if n.endswith('.sql')):
        code = re.sub(r"'(?:[^']|'')*'", "''", strip_sql_comments(open(os.path.join(directory, name), encoding='utf-8').read()))   # string literals (e.g. permission codes like 'hr.employee.view') are not references
        defs = [(mm.start(), mm.group(1).lower()) for mm in _DEF_TABLE.finditer(code)] + [(mm.start(), mm.group(1).lower()) for mm in _DEF_FUNC.finditer(code)]
        here = {}
        for pos, ident in defs:
            here.setdefault(ident, pos)
        for mm in _REF.finditer(code):
            ident = (mm.group(1) + '.' + mm.group(2)).lower()
            if ident in known:
                continue
            if ident in here and here[ident] <= mm.start():
                continue
            errors.append('%s: %s is used before it is created' % (name, ident))
        known |= set(here)
    return sorted(set(errors))

# ----------------------------------------------------------------------------- file layout (nothing dropped when patches are combined)

LAYOUT_FILES = [
    '.github/workflows/staging-migrations.yml',
    'backend/ops/mohona_ops.py', 'backend/ops/test_mohona_ops.py', 'backend/ops/expected.json',
    'backend/ops/GUIDE_BN.md', 'backend/ops/SECURITY_CLAIMS_BN.md', 'backend/ops/FINAL_FILE_CHECKLIST.md',
    'backend/spikes/S2_privileges.sql',
    'backend/docs/DECISIONS.md', 'backend/docs/EVIDENCE/README.md',
    'backend/supabase/CHANGES_BEFORE_FIRST_APPLY.md',
    'backend/supabase/original_unapplied/20261104000900_authz_rls_api.ORIGINAL.sql',
    'backend/supabase/migrations/20261104000100_foundation.sql',
    'backend/supabase/migrations/20261104000200_core_org_identity.sql',
    'backend/supabase/migrations/20261104000300_core_rbac.sql',
    'backend/supabase/migrations/20261104000400_seed_roles_permissions.sql',
    'backend/supabase/migrations/20261104000500_core_audit_security.sql',
    'backend/supabase/migrations/20261104000600_core_transactions.sql',
    'backend/supabase/migrations/20261104000700_core_approvals.sql',
    'backend/supabase/migrations/20261104000800_finance_lite.sql',
    'backend/supabase/migrations/20261104000900_authz_rls_api.sql',
    'backend/supabase/tests/t_od02_od03_isolation.sql', 'backend/supabase/tests/t_roles_registry.sql', 'backend/supabase/tests/t_ledger_audit.sql',
    'backend/supabase/tests/t_rls_permission_idempotency.sql', 'backend/supabase/tests/t_privilege_model.sql',
    'backend/supabase/tests/t_live_authz_isolation.sql', 'backend/supabase/tests/t_ledger_negative_approval.sql',
]
LAYOUT_MANIFEST = 'backend/ops/file_manifest.json'

def normalized_bytes(path):
    """Content with LF line endings and exactly one trailing newline, so a copy-paste from a phone does not cause a false alarm."""
    text = open(path, 'rb').read().decode('utf-8')
    text = text.replace('\r\n', '\n').replace('\r', '\n').rstrip('\n') + '\n'
    return text.encode('utf-8')

def layout_entry(path):
    b = normalized_bytes(path)
    return {'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b), 'lines': b.count(b'\n')}

def verify_layout(root):
    mpath = os.path.join(root, LAYOUT_MANIFEST)
    if not os.path.isfile(mpath):
        return ['%s is missing (copy it from the patch)' % LAYOUT_MANIFEST]
    manifest = json.load(open(mpath, encoding='utf-8')).get('files', {})
    errors = []
    for rel in LAYOUT_FILES:
        if rel not in manifest:
            errors.append('layout manifest does not list %s' % rel)
            continue
        path = os.path.join(root, rel)
        if not os.path.isfile(path):
            errors.append('MISSING FILE (a patch was not applied completely): ' + rel)
            continue
        got, want = layout_entry(path), manifest[rel]
        if got['sha256'] != want['sha256']:
            errors.append('WRONG VERSION of %s: expected %d lines / %d bytes, found %d lines / %d bytes (an older patch version or a partial edit)' % (rel, want['lines'], want['bytes'], got['lines'], got['bytes']))
    return errors

def write_layout(root):
    files = {rel: layout_entry(os.path.join(root, rel)) for rel in LAYOUT_FILES}
    with open(os.path.join(root, LAYOUT_MANIFEST), 'w', encoding='utf-8') as f:
        json.dump({'_comment': 'SHA-256 of the final P0 files (line endings normalised). Regenerate ONLY after an intentional, reviewed change: python3 backend/ops/mohona_ops.py write-layout', 'files': files}, f, indent=1)
    return files

# ----------------------------------------------------------------------------- static validation

def strip_sql_comments(sql):
    return re.sub(r'--[^\n]*', '', sql)

def validate_files(directory):
    """Returns (errors, manifest). manifest = [{'filename','sha256'}] in apply order."""
    errors, manifest = [], []
    if not os.path.isdir(directory):
        return ['migration directory not found: ' + directory], []
    names = sorted(n for n in os.listdir(directory) if n.endswith('.sql'))
    others = sorted(n for n in os.listdir(directory) if not n.endswith('.sql') and not n.startswith('.'))
    for o in others:
        errors.append('unexpected non-SQL file in migrations directory: ' + o)
    if not names:
        errors.append('no migration files found')
    stamps = []
    for n in names:
        m = NAME_RE.match(n)
        if not m:
            errors.append('bad file name (expected YYYYMMDDHHMMSS_snake_case.sql): ' + n)
            continue
        stamps.append(m.group(1))
        path = os.path.join(directory, n)
        raw = open(path, encoding='utf-8').read()
        if not raw.strip():
            errors.append('empty migration: ' + n)
        code = strip_sql_comments(raw)
        for pat, label in FORBIDDEN:
            if re.search(pat, code):
                errors.append('forbidden statement (%s) in %s' % (label, n))
        sets = len(re.findall(r'(?im)^\s*set\s+role\b', code))
        resets = len(re.findall(r'(?im)^\s*reset\s+role\b', code))
        if sets != resets:
            errors.append('unbalanced SET ROLE / RESET ROLE (%d/%d) in %s' % (sets, resets, n))
        manifest.append({'filename': n, 'sha256': sha256_file(path)})
    if len(set(stamps)) != len(stamps):
        errors.append('duplicate migration timestamps')
    if stamps != sorted(stamps):
        errors.append('migration timestamps are not in ascending order')
    return errors, manifest

# ----------------------------------------------------------------------------- identity

def parse_db_url(url):
    """Strict parser. Rejects control characters (newline/NUL injection), query parameters and unknown schemes."""
    url = (url or '').strip()
    if has_control_chars(url):
        raise ValueError('connection string contains a control character')
    u = urlparse(url)
    if u.scheme not in ('postgres', 'postgresql'):
        raise ValueError('connection string must start with postgresql://')
    if u.query or u.params or u.fragment:
        raise ValueError('connection string must not contain query parameters')
    parsed = {'user': unquote(u.username or ''), 'password': unquote(u.password or ''),
              'host': u.hostname or '', 'port': str(u.port or 5432), 'db': (u.path or '/postgres').lstrip('/') or 'postgres'}
    for k, v in parsed.items():
        if has_control_chars(v):
            raise ValueError('decoded %s contains a control character' % k)
    if not parsed['user'] or not parsed['password'] or not parsed['host']:
        raise ValueError('connection string must contain user, password and host')
    return parsed

def derive_ref(user, host):
    if user.startswith('postgres.'):
        return user.split('.', 1)[1]
    m = re.match(r'^db\.([a-z0-9]+)\.supabase\.co$', host)
    return m.group(1) if m else None

def verify_identity(url, expected_ref, confirm_ref, production_ref=None):
    """URL-LEVEL check only (see backend/ops/SECURITY_CLAIMS_BN.md): it proves what the connection string CLAIMS, not which server answers.
    The independent proof is the database marker + challenge (verify_marker). Returns (errors, parsed); messages never contain secrets."""
    errors, parsed = [], None
    errors += validate_refs(expected_ref, production_ref)
    if not url:
        return errors + ['STAGING_DB_URL secret is missing in this GitHub Environment'], None
    try:
        parsed = parse_db_url(url)
    except ValueError as e:
        return errors + ['STAGING_DB_URL is not acceptable: %s' % e], None
    ref = derive_ref(parsed['user'], parsed['host'])
    host = parsed['host']
    if confirm_ref != expected_ref:
        errors.append('the project reference you typed does not match STAGING_PROJECT_REF')
    if not (host.endswith('.supabase.com') or host.endswith('.supabase.co')):
        errors.append('host is not a Supabase host')
    if ref is None:
        errors.append('cannot derive the project reference from the connection string (use the Supabase pooler URL or db.<ref>.supabase.co)')
    elif expected_ref and ref != expected_ref:
        errors.append('the connection string points to a DIFFERENT project than STAGING_PROJECT_REF')
    if production_ref and ref == production_ref:
        errors.append('PRODUCTION project detected in the connection string: this workflow refuses to run against Production')
    return errors, parsed

def mask_ref(ref):
    return (ref[:3] + '***' + ref[-2:]) if ref and len(ref) > 6 else '***'

# ----------------------------------------------------------------------------- plan

def compute_plan(manifest, history):
    """manifest: list of {'filename','sha256'} in order; history: dict filename -> sha256 (already applied)."""
    errors = []
    names = [m['filename'] for m in manifest]
    for m in manifest:
        fn = m['filename']
        if fn in history and history[fn] != m['sha256']:
            errors.append('MODIFIED-AFTER-APPLY: %s (applied files are immutable; add a new forward migration)' % fn)
    for fn in history:
        if fn not in names:
            errors.append('APPLIED-BUT-MISSING-IN-REPO: %s' % fn)
    seen_pending = False
    for m in manifest:
        if m['filename'] in history:
            if seen_pending:
                errors.append('OUT-OF-ORDER: %s is applied although an earlier file is still pending' % m['filename'])
        else:
            seen_pending = True
    pending = [m for m in manifest if m['filename'] not in history]
    applied = [m for m in manifest if m['filename'] in history]
    return {'applied': applied, 'pending': pending, 'errors': errors}

# ----------------------------------------------------------------------------- psql

def pg_env():
    """Connection settings for ONE subprocess call, rebuilt from the secret each time. Ambient PG* variables are discarded so nothing
    can redirect the connection, and nothing is ever persisted (no GITHUB_ENV)."""
    url = os.environ.get('STAGING_DB_URL', '')
    if not url:
        raise RuntimeError('STAGING_DB_URL is not set for this step')
    p = parse_db_url(url)
    env = {k: v for k, v in os.environ.items() if not k.startswith('PG') and k not in ('STAGING_DB_URL', 'STAGING_CHALLENGE', 'GH_TOKEN')}
    env.update({'PGHOST': p['host'], 'PGPORT': p['port'], 'PGUSER': p['user'], 'PGDATABASE': p['db'], 'PGPASSWORD': p['password'],
                'PGSSLMODE': 'require', 'PGCONNECT_TIMEOUT': '20', 'PGAPPNAME': 'mohona-ops'})
    return env

def psql(sql=None, stdin=None, file=None, tuples=False, single_tx=False):
    cmd = ['psql', '-X', '-q', '-v', 'ON_ERROR_STOP=1']
    if tuples:
        cmd += ['-At']
    if single_tx:
        cmd += ['--single-transaction']
    if sql is not None:
        cmd += ['-c', sql]
    elif file is not None:
        cmd += ['-f', file]
    else:
        cmd += ['-f', '-']
    p = subprocess.run(cmd, input=stdin, capture_output=True, text=True, env=pg_env())
    return p.returncode, redact(p.stdout), redact(p.stderr)

def read_history():
    rc, out, err = psql("select to_regclass('ops.applied_migrations') is not null", tuples=True)
    if rc != 0:
        raise RuntimeError('cannot query the database: ' + err.strip().splitlines()[-1] if err.strip() else 'cannot query the database')
    if out.strip() != 't':
        return {}, False
    rc, out, err = psql("select filename || E'\\t' || sha256 from ops.applied_migrations order by filename", tuples=True)
    if rc != 0:
        raise RuntimeError('cannot read ops.applied_migrations')
    hist = {}
    for line in out.splitlines():
        if '\t' in line:
            a, b = line.split('\t', 1)
            hist[a.strip()] = b.strip()
    return hist, True

OPS_SQL = """
create schema if not exists ops;
create table if not exists ops.applied_migrations (
  filename   text primary key,
  sha256     text not null,
  applied_at timestamptz not null default now(),
  run_id     text,
  git_sha    text,
  applied_by text
);
"""

def verify_marker():
    """INDEPENDENT identity proof. The marker row is created by the owner by hand inside the Staging project's own dashboard (never by this
    tool) and stores only the SHA-256 of a secret challenge. A different database cannot satisfy this unless someone repeated that manual step
    there. Returns a list of errors (empty = proven)."""
    token = os.environ.get('STAGING_CHALLENGE', '').strip()
    if len(token) < 16:
        return ['STAGING_CHALLENGE secret is missing or shorter than 16 characters']
    if has_control_chars(token):
        return ['STAGING_CHALLENGE contains a control character']
    rc, out, err = psql("select to_regclass('ops.environment_marker') is not null", tuples=True)
    if rc != 0:
        return ['cannot query the database to verify the environment marker']
    if out.strip() != 't':
        return ['independent identity marker NOT found: create ops.environment_marker in the Staging dashboard first (backend/ops/GUIDE_BN.md, step 3)']
    rc, out, err = psql(stdin="select (value = 'staging' and challenge_sha256 = %s) from ops.environment_marker" % sql_lit(challenge_hash(token)), tuples=True)
    if rc != 0 or out.strip() != 't':
        return ['independent identity check FAILED: the database marker/challenge does not match STAGING_CHALLENGE (wrong database?)']
    return []

# ----------------------------------------------------------------------------- results / gate

def parse_results(text):
    rows = []
    for line in text.splitlines():
        if line.startswith('RESULT|'):
            parts = line.split('|', 3)
            if len(parts) >= 3:
                rows.append((parts[1], parts[2], parts[3] if len(parts) > 3 else ''))
    return rows

def evaluate_tests(rows, expected_counts):
    """Gate rule: any FAIL/ERROR = fail; every expected test id must appear at least the expected number of times."""
    problems = []
    found = {}
    for tid, status, note in rows:
        found[tid] = found.get(tid, 0) + 1
        if status != 'PASS':
            problems.append('%s %s: %s' % (tid, status, note))
    for tid, n in expected_counts.items():
        if found.get(tid, 0) < n:
            problems.append('%s: expected %d result(s), found %d (missing result = fail)' % (tid, n, found.get(tid, 0)))
    return problems

def evaluate_objects(found_tables, expected_tables, fn_count, expected_fn, api_fns, expected_api, seeds, expected_seeds):
    problems = []
    missing = sorted(set(expected_tables) - set(found_tables))
    extra = sorted(set(found_tables) - set(expected_tables))
    if missing:
        problems.append('missing tables: ' + ', '.join(missing))
    if extra:
        problems.append('unexpected extra tables (explain or update expected.json): ' + ', '.join(extra))
    if fn_count != expected_fn:
        problems.append('function count %s != expected %s' % (fn_count, expected_fn))
    if sorted(api_fns) != sorted(expected_api):
        problems.append('api functions %s != expected %s' % (sorted(api_fns), sorted(expected_api)))
    for k, v in expected_seeds.items():
        if seeds.get(k) != v:
            problems.append('seed count %s = %s, expected %s' % (k, seeds.get(k), v))
    return problems

def parse_probe(output):
    lines = [l for l in output.splitlines() if l.strip()]
    holes, bad = None, []
    for l in lines:
        if re.fullmatch(r'\d+', l.strip()):
            holes = int(l.strip())
        else:
            parts = l.split('|')
            if len(parts) >= 3 and parts[2].strip() == 'f':
                bad.append('%s / %s' % (parts[1].strip(), parts[0].strip()))
    return holes, bad

# ----------------------------------------------------------------------------- commands

def repo_root():
    return os.environ.get('REPO_ROOT', '.')

def load_expected():
    default = os.path.join(repo_root(), 'backend/ops/expected.json')
    return json.load(open(os.environ.get('EXPECTED', default), encoding='utf-8'))

def evaluate_coverage(rows, expected):
    """Every category must be fully present, fully passing AND contain at least one passing NEGATIVE test."""
    problems = []
    by = {}
    for tid, status, _ in rows:
        by.setdefault(tid, []).append(status)
    neg = set(expected.get('negative_ids', []))
    for cat, ids in expected.get('categories', {}).items():
        passing_neg = 0
        for i in ids:
            st = by.get(i)
            if not st:
                problems.append('coverage: %s (%s) produced no result' % (i, cat)); continue
            if any(x != 'PASS' for x in st):
                problems.append('coverage: %s (%s) did not pass' % (i, cat)); continue
            if i in neg:
                passing_neg += 1
        if passing_neg == 0:
            problems.append('coverage: category "%s" has no PASSING negative test' % cat)
    return problems

def coverage_matrix(rows, expected):
    by = {}
    for tid, status, _ in rows:
        by.setdefault(tid, []).append(status)
    neg = set(expected.get('negative_ids', []))
    lines = ['| category | tests passing / expected | negative tests passing |', '| --- | --- | --- |']
    for cat, ids in expected.get('categories', {}).items():
        ok = [i for i in ids if by.get(i) and all(x == 'PASS' for x in by[i])]
        n_ok = [i for i in ok if i in neg]
        n_all = [i for i in ids if i in neg]
        lines.append('| %s | %d / %d | %d / %d |' % (cat, len(ok), len(ids), len(n_ok), len(n_all)))
    return lines

def cmd_static():
    directory = os.environ.get('MIGRATIONS_DIR', 'backend/supabase/migrations')
    out = os.environ.get('MANIFEST_OUT', 'manifest.json')
    expected = load_expected()
    errors, manifest, mh = static_gate(directory, expected, repo_root())
    if os.environ.get('MODE') == 'apply' and os.environ.get('CONFIRM_APPLY', '') != APPLY_PHRASE:
        errors.append('apply mode requires typing exactly %s in confirm_apply' % APPLY_PHRASE)
    if os.environ.get('MODE') == 'apply' and not re.fullmatch(r'\d{1,20}', os.environ.get('VALIDATED_RUN_ID', '').strip()):
        errors.append('apply mode requires validated_run_id: the numeric id of a successful validate-only run on this commit')
    ref = os.environ.get('GITHUB_REF_NAME'); default = os.environ.get('DEFAULT_BRANCH')
    if ref and default and ref != default:
        errors.append('this workflow only runs on the default branch (%s), not %s' % (default, ref))
    with open(out, 'w', encoding='utf-8') as f:
        json.dump(manifest, f, indent=2)
    github_output('manifest_hash', mh)
    github_output('git_sha', os.environ.get('GITHUB_SHA', ''))
    md = ['### Static validation', '', 'Commit: `%s`' % os.environ.get('GITHUB_SHA', 'local')[:12], 'Manifest hash: `%s`' % mh[:16], 'Files: %d' % len(manifest)]
    md += ['- `%s`  `%s`' % (m['filename'], m['sha256'][:12]) for m in manifest]
    md += ['', '**FAILED**'] + ['- ' + e for e in errors] if errors else ['', '**PASSED** (names, order, forbidden statements, required files, test coverage map, commit pin)']
    summary('\n'.join(md))
    for e in errors:
        say('ERROR: ' + e)
    say('static validation: %s (%d files)' % ('FAILED' if errors else 'passed', len(manifest)))
    return 1 if errors else 0

def cmd_identity():
    url = os.environ.get('STAGING_DB_URL', '')
    errors, parsed = verify_identity(url, os.environ.get('EXPECTED_REF', ''), os.environ.get('CONFIRM_REF', ''), os.environ.get('PRODUCTION_REF', ''))
    if errors:
        for e in errors:
            say('IDENTITY ERROR: ' + e)
        summary('### Identity check FAILED\n' + '\n'.join('- ' + e for e in errors))
        return 1
    # Values were validated to contain no control characters, so these workflow commands cannot be injected into.
    print('::add-mask::' + parsed['password'])
    token = os.environ.get('STAGING_CHALLENGE', '').strip()
    if token and not has_control_chars(token):
        print('::add-mask::' + token)
    ref = derive_ref(parsed['user'], parsed['host'])
    say('URL-level identity OK (%s): project matches STAGING_PROJECT_REF, differs from the mandatory PRODUCTION_PROJECT_REF, typed confirmation matches. '
        'This proves what the string CLAIMS; the independent marker check follows.' % mask_ref(ref))
    summary('### URL-level identity check passed\nProject `%s`. Independent database marker verification runs next.' % mask_ref(ref))
    return 0

def cmd_plan():
    manifest = json.load(open(os.environ.get('MANIFEST', 'manifest.json'), encoding='utf-8'))
    errors = verify_marker()
    if errors:
        for e in errors:
            say('IDENTITY ERROR: ' + e)
        summary('### Independent identity check FAILED\n' + '\n'.join('- ' + e for e in errors))
        return 1
    hist, has_table = read_history()
    plan = compute_plan(manifest, hist)
    ph = plan_hash(plan)
    plan['plan_hash'] = ph
    md = ['### Migration plan (read-only)', '', 'Independent marker/challenge: **verified**', 'Plan hash: `%s`' % ph[:16],
          'Applied: %d  |  Pending: %d' % (len(plan['applied']), len(plan['pending']))]
    md += ['- applied: `%s`' % m['filename'] for m in plan['applied']]
    md += ['- PENDING: `%s`' % m['filename'] for m in plan['pending']]
    if not has_table:
        md.append('- history table `ops.applied_migrations` does not exist yet (created at first apply)')
    if plan['errors']:
        md += ['', '**PLAN FAILED**'] + ['- ' + e for e in plan['errors']]
    with open(os.environ.get('PLAN_OUT', 'plan.json'), 'w', encoding='utf-8') as f:
        json.dump(plan, f, indent=2)
    github_output('plan_hash', ph)
    summary('\n'.join(md))
    say('plan: applied=%d pending=%d errors=%d' % (len(plan['applied']), len(plan['pending']), len(plan['errors'])))
    for e in plan['errors']:
        say('PLAN ERROR: ' + e)
    return 1 if plan['errors'] else 0

def cmd_approval():
    errors = branch_errors() + approval_errors()
    for e in errors:
        say('APPROVAL CHECK FAILED: ' + e)
    summary('### Reviewer-approval check %s' % ('FAILED\n' + '\n'.join('- ' + e for e in errors) if errors else 'passed: a recorded reviewer approval exists for staging-apply on this run'))
    return 1 if errors else 0

def cmd_write_layout():
    files = write_layout(repo_root())
    say('layout manifest written for %d files' % len(files))
    return 0

def cmd_apply():
    directory = os.environ.get('MIGRATIONS_DIR', 'backend/supabase/migrations')
    expected = load_expected()
    # 0. policy gates re-checked directly inside the apply job (default branch, real reviewer approval, prior successful validate-only run)
    gate = branch_errors() + approval_errors() + prior_validation_errors()
    if gate:
        for e in gate:
            say('APPLY BLOCKED: ' + e)
        summary('### Apply blocked\n' + '\n'.join('- ' + e for e in gate))
        return 1
    # 1. everything provable offline is proven AGAIN inside this approved job, against freshly read files
    errors, manifest, mh = static_gate(directory, expected, repo_root())
    for key, label in (('EXPECTED_MANIFEST_HASH', 'manifest hash'), ('EXPECTED_PLAN_HASH', 'plan hash'), ('EXPECTED_GIT_SHA', 'commit SHA')):
        if not os.environ.get(key):
            errors.append('%s of the validated run is missing: apply refuses to run without it' % label)
    if os.environ.get('EXPECTED_MANIFEST_HASH') and os.environ['EXPECTED_MANIFEST_HASH'] != mh:
        errors.append('migration files changed between validation and apply (manifest hash differs)')
    if errors:
        for e in errors:
            say('APPLY BLOCKED: ' + e)
        summary('### Apply blocked\n' + '\n'.join('- ' + e for e in errors))
        return 1
    # 2. independent identity proof, then history and plan must be exactly what was validated
    ierr = verify_marker()
    if ierr:
        for e in ierr:
            say('APPLY BLOCKED: ' + e)
        return 1
    hist, _ = read_history()
    plan = compute_plan(manifest, hist)
    if plan['errors']:
        for e in plan['errors']:
            say('PLAN ERROR: ' + e)
        return 1
    if plan_hash(plan) != os.environ['EXPECTED_PLAN_HASH']:
        say('APPLY BLOCKED: the database migration history changed between validation and apply')
        return 1
    rc, out, err = psql(stdin=OPS_SQL, single_tx=True)
    if rc != 0:
        say('could not create ops bookkeeping objects:\n' + err[-1500:])
        return 1
    done, failed = [], None
    for m in plan['pending']:
        fn = m['filename']
        raw = open(os.path.join(directory, fn), 'rb').read()
        if hashlib.sha256(raw).hexdigest() != m['sha256']:
            failed = (fn, 'file content changed on disk after validation; nothing from this file was executed')
            break
        sql = raw.decode('utf-8')
        stmt = sql + '\ninsert into ops.applied_migrations (filename, sha256, run_id, git_sha, applied_by) values (%s, %s, %s, %s, %s);\n' % (
            sql_lit(fn), sql_lit(m['sha256']), sql_lit(os.environ.get('GITHUB_RUN_ID', '')), sql_lit(os.environ.get('GITHUB_SHA', '')), sql_lit(os.environ.get('GITHUB_ACTOR', '')))
        say('applying %s ...' % fn)
        rc, out, err = psql(stdin=stmt, single_tx=True)
        if rc != 0:
            failed = (fn, '\n'.join(err.strip().splitlines()[-30:]))
            break
        done.append(fn)
    hist_after, _ = read_history()
    rep = ['# Migration apply report', '', 'Commit: `%s`' % os.environ.get('GITHUB_SHA', '')[:12], 'Applied in this run: %d' % len(done)] + ['- `%s`' % f for f in done]
    rep += ['', 'History now records %d file(s).' % len(hist_after)]
    if failed:
        rep += ['', '## FAILED at `%s`' % failed[0], '', 'This file ran inside ONE transaction and was rolled back completely (or was never started).',
                'Database state = the files listed above (verified from `ops.applied_migrations`). Later files were NOT run.',
                '', '```', failed[1], '```', '', 'Recovery: see backend/ops/GUIDE_BN.md, section "ব্যর্থ হলে".']
    with open(os.environ.get('REPORT_OUT', 'apply-report.md'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(rep) + '\n')
    summary('\n'.join(rep))
    return 1 if failed else 0

def cmd_checks():
    exp = load_expected()
    root = repo_root()
    problems = {'dependencies': check_dependencies(exp, root), 'identity': [], 'objects': [], 'tests': [], 'coverage': [], 'probe': []}
    rows = []

    def finish():
        gate = 'PASS' if not any(problems.values()) else 'FAIL'
        rep = ['# P0 database gate report (E5-E7 subset)', '', '**Verdict: %s**' % gate, '',
               'Covered here: dependencies, independent identity, object counts (E5), privilege probe (E6), SQL tests with coverage (E7). '
               '**Not evaluated here:** E1-E4, E8-E10 (APK, PG version, apply log, auth timing, Android connected login, evidence pack).', '']
        if rows:
            rep += ['## Coverage matrix', ''] + coverage_matrix(rows, exp) + ['', '## Test results (%d lines)' % len(rows), ''] + ['- `%s` %s %s' % r for r in rows]
        for k, v in problems.items():
            rep += ['', '## %s: %s' % (k, 'OK' if not v else 'PROBLEMS')] + ['- ' + p for p in v]
        text = '\n'.join(rep) + '\n'
        with open(os.environ.get('REPORT_OUT', 'p0-gate-report.md'), 'w', encoding='utf-8') as f:
            f.write(redact(text))
        summary(text)
        say('P0 database gate: ' + gate)
        return 0 if gate == 'PASS' else 1

    if problems['dependencies']:
        return finish()                       # a missing file is a hard failure: nothing else is trusted
    problems['identity'] = verify_marker()
    if problems['identity']:
        return finish()
    # objects
    schemas = ','.join(sql_lit(x) for x in exp['schemas'])
    rc, out, err = psql("select table_schema || '.' || table_name from information_schema.tables where table_type='BASE TABLE' and table_schema in (%s)" % schemas, tuples=True)
    tables = out.split() if rc == 0 else []
    fschemas = ','.join(sql_lit(x) for x in exp['function_schemas'])
    rc2, out2, _ = psql("select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname in (%s)" % fschemas, tuples=True)
    rc3, out3, _ = psql("select p.proname from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname = 'api'", tuples=True)
    seeds = {}
    for tbl in exp['seed_counts']:
        r, o, _ = psql('select count(*) from %s' % tbl, tuples=True)
        seeds[tbl] = int(o.strip()) if r == 0 and o.strip().isdigit() else None
    if rc != 0 or rc2 != 0 or rc3 != 0:
        problems['objects'].append('could not query catalog objects')
    else:
        problems['objects'] = evaluate_objects(tables, exp['tables'], int(out2.strip()), exp['function_count'], out3.split(), exp['api_functions'], seeds, exp['seed_counts'])
    # tests: exactly the files listed in expected.json; a missing file or a psql error is a FAIL, never a skip
    for fn in sorted(exp['test_files']):
        r, o, e = psql(file=os.path.join(root, exp['test_dir'], fn), tuples=True)
        got = parse_results(o)
        if r != 0:
            got.append((fn, 'ERROR', (e.strip().splitlines() or ['psql failed'])[-1]))
        rows += got
    problems['tests'] = evaluate_tests(rows, exp['tests'])
    problems['coverage'] = evaluate_coverage(rows, exp)
    # privilege probe (dynamic attempts as anon / authenticated / service_role)
    r, o, e = psql(file=os.path.join(root, exp['probe_file']), tuples=True)
    if r != 0:
        problems['probe'].append('probe script failed to run: ' + (e.strip().splitlines() or ['error'])[-1])
    else:
        holes, bad = parse_probe(o)
        if holes is None:
            problems['probe'].append('probe printed no hole-count')
        elif holes > 0 or bad:
            problems['probe'].append('CRITICAL SECURITY HOLE(S): %d; %s' % (holes, '; '.join(bad)))
    return finish()

COMMANDS = {'static': cmd_static, 'identity': cmd_identity, 'plan': cmd_plan, 'apply': cmd_apply, 'checks': cmd_checks, 'approval': cmd_approval, 'write-layout': cmd_write_layout}

if __name__ == '__main__':
    if len(sys.argv) != 2 or sys.argv[1] not in COMMANDS:
        print('usage: mohona_ops.py {%s}' % '|'.join(COMMANDS)); sys.exit(2)
    try:
        sys.exit(COMMANDS[sys.argv[1]]())
    except Exception as exc:
        print(redact('FATAL: %s: %s' % (exc.__class__.__name__, exc))); sys.exit(1)
