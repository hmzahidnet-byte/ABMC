# Final File Checklist (P0 — বেস v0.2 + Patch v1 + v2 + v3 = Consolidated Overlay v3)

**ব্যবহার:** শুধু `Mohona_P0_Consolidated_Overlay_v3.zip` বসান (v1/v2 আলাদাভাবে নয়)। প্রতিটি ফাইল Repository-তে একই পথে থাকতে হবে; লাইন-সংখ্যা GitHub-এর ফাইল-পাতার ওপরে দেখা যায়। Workflow-এর Static ধাপ প্রতিটি ফাইলের SHA-256 `backend/ops/file_manifest.json` থেকে মিলিয়ে অনুপস্থিত/পুরোনো ফাইল **নিজেই ধরে ফেলে**।

| # | পথ | উৎস | লাইন | বাইট |
| --- | --- | --- | --- | --- |
| 1 | `.github/workflows/staging-migrations.yml` | v1 → v2 → **v3** | 282 | 11344 |
| 2 | `backend/ops/mohona_ops.py` | v1 → v2 → **v3** | 862 | 44908 |
| 3 | `backend/ops/test_mohona_ops.py` | v1 → v2 → **v3** | 563 | 43882 |
| 4 | `backend/ops/expected.json` | v1 → v2 (v3 অপরিবর্তিত) | 330 | 6107 |
| 5 | `backend/ops/GUIDE_BN.md` | v1 → v2 → **v3** | 113 | 22634 |
| 6 | `backend/ops/SECURITY_CLAIMS_BN.md` | v2 → **v3** | 50 | 12187 |
| 7 | `backend/ops/FINAL_FILE_CHECKLIST.md` | **v3 (নতুন)** | (এই ফাইল) | — |
| 8 | `backend/spikes/S2_privileges.sql` | বেস v0.2 | 31 | 2072 |
| 9 | `backend/docs/DECISIONS.md` | v1 | 25 | 5037 |
| 10 | `backend/docs/EVIDENCE/README.md` | v1 | 6 | 482 |
| 11 | `backend/supabase/CHANGES_BEFORE_FIRST_APPLY.md` | v2 | 13 | 1366 |
| 12 | `backend/supabase/original_unapplied/20261104000900_authz_rls_api.ORIGINAL.sql` | v2 | 99 | 5573 |
| 13 | `backend/supabase/migrations/20261104000100_foundation.sql` | বেস v0.2 | 46 | 2200 |
| 14 | `backend/supabase/migrations/20261104000200_core_org_identity.sql` | বেস v0.2 | 132 | 6816 |
| 15 | `backend/supabase/migrations/20261104000300_core_rbac.sql` | বেস v0.2 | 56 | 2691 |
| 16 | `backend/supabase/migrations/20261104000400_seed_roles_permissions.sql` | বেস v0.2 | 251 | 15568 |
| 17 | `backend/supabase/migrations/20261104000500_core_audit_security.sql` | বেস v0.2 | 102 | 5604 |
| 18 | `backend/supabase/migrations/20261104000600_core_transactions.sql` | বেস v0.2 | 147 | 7412 |
| 19 | `backend/supabase/migrations/20261104000700_core_approvals.sql` | বেস v0.2 | 115 | 6446 |
| 20 | `backend/supabase/migrations/20261104000800_finance_lite.sql` | বেস v0.2 | 140 | 7067 |
| 21 | `backend/supabase/migrations/20261104000900_authz_rls_api.sql` | বেস → v2 (E_AUTH সংশোধন) | 102 | 5970 |
| 22 | `backend/supabase/tests/t_od02_od03_isolation.sql` | বেস v0.2 | 61 | 6310 |
| 23 | `backend/supabase/tests/t_roles_registry.sql` | বেস v0.2 | 13 | 1754 |
| 24 | `backend/supabase/tests/t_ledger_audit.sql` | বেস v0.2 | 56 | 5252 |
| 25 | `backend/supabase/tests/t_rls_permission_idempotency.sql` | v1 | 43 | 3222 |
| 26 | `backend/supabase/tests/t_privilege_model.sql` | v2 | 100 | 5886 |
| 27 | `backend/supabase/tests/t_live_authz_isolation.sql` | v2 | 126 | 9871 |
| 28 | `backend/supabase/tests/t_ledger_negative_approval.sql` | v2 | 67 | 7494 |

**এই তালিকার বাইরে ফাইল:** `backend/ops/file_manifest.json` (v3, নতুন; হ্যাশ-তালিকা), `backend/docs/EVIDENCE/ops_offline_tests_v3_*.log` (v3 Test-লগ)।
**ঐতিহাসিক, ইচ্ছাকৃতভাবে চূড়ান্ত তালিকার বাইরে:** `backend/docs/EVIDENCE/ops_offline_tests_20261105T055623Z.log` (v1, ৪২ Test) ও `…_v2_….log` (v2, ৮২ Test) — রাখা বা সরানো দুটিই নিরাপদ।

**মিলন-প্রমাণ:** v1 Patch-এর ৯টি ও v2 Patch-এর ১৩টি ফাইলের প্রতিটি হয় এই তালিকায় আছে, নয়তো ঐতিহাসিক লগ। বাদ-পড়া ফাইল: **নেই**।
**সীমা:** লাইন-সংখ্যা ও হ্যাশ ফাইলের উপস্থিতি/সংস্করণ প্রমাণ করে; ফাইলের ভেতরের SQL ঠিকঠাক চলে কি না নয়।
