"""Offline tests for mohona_ops.py (no database, no network). Run:  python3 backend/ops/test_mohona_ops.py -v"""
import json, os, shutil, subprocess, sys, tempfile, unittest
from unittest import mock
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mohona_ops as m

HERE = os.path.dirname(os.path.abspath(__file__))
REAL_MIGRATIONS = os.path.join(HERE, '..', 'supabase', 'migrations')
ROOT = os.path.normpath(os.path.join(HERE, '..', '..'))
EXPECTED_PATH = os.path.join(HERE, 'expected.json')
PROD = 'prodprodprodprodprod'
STG = 'abcdefghijklmnop'
GOOD = "set role erp_owner;\ncreate table t (id int);\nreset role;\n"

def mk(files):
    d = tempfile.mkdtemp()
    for name, text in files.items():
        open(os.path.join(d, name), 'w', encoding='utf-8').write(text)
    return d

class StaticValidation(unittest.TestCase):
    def test_real_migrations_pass(self):
        errors, manifest = m.validate_files(REAL_MIGRATIONS)
        self.assertEqual(errors, []); self.assertEqual(len(manifest), 9)
    def test_good_dir(self):
        e, man = m.validate_files(mk({'20261104000100_a.sql': GOOD, '20261104000200_b.sql': GOOD}))
        self.assertEqual(e, []); self.assertEqual([x['filename'] for x in man], ['20261104000100_a.sql', '20261104000200_b.sql'])
    def test_bad_name(self):
        e, _ = m.validate_files(mk({'001_init.sql': GOOD})); self.assertTrue(any('bad file name' in x for x in e))
    def test_duplicate_timestamp(self):
        e, _ = m.validate_files(mk({'20261104000100_a.sql': GOOD, '20261104000100_b.sql': GOOD})); self.assertTrue(any('duplicate' in x for x in e))
    def test_forbidden_statements(self):
        for sql, label in [('drop schema core cascade;', 'DROP SCHEMA'), ('DROP DATABASE x;', 'DROP DATABASE'), ('truncate core.employees;', 'TRUNCATE'),
                           ('alter role bob with password \'x\';', 'PASSWORD'), ('grant select on all tables in schema core to anon;', 'GRANT'),
                           ('grant all on table core.employees to authenticated;', 'GRANT'), ('create role r bypassrls;', 'BYPASSRLS'),
                           ('\\! rm -rf /', 'meta-command'), ("copy t from program 'x';", 'PROGRAM')]:
            e, _ = m.validate_files(mk({'20261104000100_a.sql': sql + '\n'}))
            self.assertTrue(any(label in x for x in e), (sql, e))
    def test_allowed_look_alikes(self):
        ok = "create trigger tg before truncate on t for each statement execute function f();\ngrant usage on schema api to authenticated;\ncreate role erp_owner nologin nobypassrls;\n-- drop schema in a comment\n"
        e, _ = m.validate_files(mk({'20261104000100_a.sql': ok})); self.assertEqual(e, [])
    def test_unbalanced_set_role(self):
        e, _ = m.validate_files(mk({'20261104000100_a.sql': 'set role erp_owner;\ncreate table t(id int);\n'})); self.assertTrue(any('unbalanced' in x for x in e))
    def test_empty_dir_and_stray_file(self):
        e, _ = m.validate_files(mk({})); self.assertTrue(any('no migration files' in x for x in e))
        e, _ = m.validate_files(mk({'20261104000100_a.sql': GOOD, 'notes.txt': 'x'})); self.assertTrue(any('non-SQL' in x for x in e))
    def test_apply_requires_typed_phrase(self):
        d = mk({'20261104000100_a.sql': GOOD}); out = os.path.join(tempfile.mkdtemp(), 'man.json')
        env = {'MIGRATIONS_DIR': d, 'MANIFEST_OUT': out, 'MODE': 'apply', 'CONFIRM_APPLY': 'yes', 'REPO_ROOT': ROOT, 'EXPECTED': EXPECTED_PATH}
        with mock.patch.dict(os.environ, env, clear=False):
            self.assertEqual(m.cmd_static(), 1)
        self.assertIn('apply mode requires', json.dumps(['apply mode requires']))
        env['CONFIRM_APPLY'] = m.APPLY_PHRASE; env['VALIDATED_RUN_ID'] = '123'
        with mock.patch.dict(os.environ, env, clear=False):
            self.assertEqual(m.cmd_static(), 0)
    def test_default_branch_only(self):
        d = mk({'20261104000100_a.sql': GOOD})
        env = {'MIGRATIONS_DIR': d, 'MANIFEST_OUT': os.path.join(tempfile.mkdtemp(), 'x.json'), 'MODE': 'validate-only', 'GITHUB_REF_NAME': 'feature-x', 'DEFAULT_BRANCH': 'main', 'REPO_ROOT': ROOT, 'EXPECTED': EXPECTED_PATH}
        with mock.patch.dict(os.environ, env, clear=False):
            self.assertEqual(m.cmd_static(), 1)

class Plan(unittest.TestCase):
    man = [{'filename': 'a.sql', 'sha256': '1'}, {'filename': 'b.sql', 'sha256': '2'}, {'filename': 'c.sql', 'sha256': '3'}]
    def test_all_pending(self):
        p = m.compute_plan(self.man, {}); self.assertEqual(len(p['pending']), 3); self.assertEqual(p['errors'], [])
    def test_prefix_applied(self):
        p = m.compute_plan(self.man, {'a.sql': '1', 'b.sql': '2'}); self.assertEqual([x['filename'] for x in p['pending']], ['c.sql']); self.assertEqual(p['errors'], [])
    def test_modified_after_apply(self):
        p = m.compute_plan(self.man, {'a.sql': 'CHANGED'}); self.assertTrue(any('MODIFIED-AFTER-APPLY' in e for e in p['errors']))
    def test_applied_but_missing(self):
        p = m.compute_plan(self.man, {'z.sql': '9'}); self.assertTrue(any('APPLIED-BUT-MISSING' in e for e in p['errors']))
    def test_out_of_order(self):
        p = m.compute_plan(self.man, {'b.sql': '2'}); self.assertTrue(any('OUT-OF-ORDER' in e for e in p['errors']))
    def test_all_applied(self):
        p = m.compute_plan(self.man, {'a.sql': '1', 'b.sql': '2', 'c.sql': '3'}); self.assertEqual(p['pending'], []); self.assertEqual(p['errors'], [])

URL = 'postgresql://postgres.abcdefghijklmnop:S3cr%40t-Pass@aws-0-ap-southeast-1.pooler.supabase.com:5432/postgres'
class Identity(unittest.TestCase):
    def ok(self, **kw):
        a = dict(url=URL, expected_ref=STG, confirm_ref=STG, production_ref=PROD); a.update(kw)
        return m.verify_identity(a['url'], a['expected_ref'], a['confirm_ref'], a['production_ref'])
    def test_pass(self): self.assertEqual(self.ok()[0], [])
    def test_direct_host_form(self):
        e, _ = self.ok(url='postgresql://postgres:pw12345@db.abcdefghijklmnop.supabase.co:5432/postgres'); self.assertEqual(e, [])
    def test_wrong_project(self): self.assertTrue(any('DIFFERENT project' in x for x in self.ok(expected_ref='zzzzzzzzzzzzzzzz', confirm_ref='zzzzzzzzzzzzzzzz')[0]))
    def test_typed_mismatch(self): self.assertTrue(any('typed' in x for x in self.ok(confirm_ref='abcdefghijklmnoq')[0]))
    def test_production_refused(self): self.assertTrue(any('PRODUCTION' in x for x in self.ok(production_ref=STG)[0]))
    def test_not_supabase_host(self):
        e, _ = self.ok(url='postgresql://postgres.abcdefghijklmnop:pw12345@localhost:5432/postgres'); self.assertTrue(any('not a Supabase host' in x for x in e))
    def test_missing_secret_and_variable(self):
        self.assertTrue(self.ok(url='')[0]); self.assertTrue(any('STAGING_PROJECT_REF' in x for x in self.ok(expected_ref='', confirm_ref='')[0]))
    def test_bad_scheme(self): self.assertTrue(self.ok(url='mysql://a:b@c/d')[0])
    def test_errors_never_contain_password(self):
        errs = ' '.join(self.ok(expected_ref='x', confirm_ref='y')[0] + self.ok(url='postgresql://postgres.q:S3cr%40t-Pass@localhost/db')[0])
        self.assertNotIn('S3cr', errs)
    def test_mask_ref(self): self.assertEqual(m.mask_ref('abcdefghijklmnop'), 'abc***op')

class Redaction(unittest.TestCase):
    def test_password_and_url_removed(self):
        with mock.patch.dict(os.environ, {'STAGING_DB_URL': URL, 'PGPASSWORD': 'S3cr@t-Pass'}):
            out = m.redact('error connecting %s with S3cr%%40t-Pass and S3cr@t-Pass' % URL)
        self.assertNotIn('S3cr', out); self.assertNotIn('pooler.supabase.com', out)

class Parsing(unittest.TestCase):
    def test_results(self):
        rows = m.parse_results('noise\nRESULT|T1|PASS|ok\nRESULT|T2|FAIL|bad note|with pipe\n'); self.assertEqual(rows, [('T1', 'PASS', 'ok'), ('T2', 'FAIL', 'bad note|with pipe')])
    def test_tests_gate(self):
        self.assertEqual(m.evaluate_tests([('T1', 'PASS', '')], {'T1': 1}), [])
        self.assertTrue(m.evaluate_tests([('T1', 'FAIL', 'x')], {'T1': 1}))
        self.assertTrue(any('missing result' in p for p in m.evaluate_tests([], {'T1': 1})))
        self.assertTrue(m.evaluate_tests([('T1', 'PASS', '')], {'T1': 2}))
    def test_objects(self):
        base = dict(found_tables=['a.x'], expected_tables=['a.x'], fn_count=1, expected_fn=1, api_fns=['f'], expected_api=['f'], seeds={'s': 1}, expected_seeds={'s': 1})
        self.assertEqual(m.evaluate_objects(**base), [])
        self.assertTrue(m.evaluate_objects(**dict(base, found_tables=['a.x', 'a.y'])))
        self.assertTrue(m.evaluate_objects(**dict(base, found_tables=[])))
        self.assertTrue(m.evaluate_objects(**dict(base, fn_count=2)))
        self.assertTrue(m.evaluate_objects(**dict(base, seeds={'s': 2})))
    def test_probe(self):
        self.assertEqual(m.parse_probe('select core.organizations|anon|t|permission denied\n0\n'), (0, []))
        h, bad = m.parse_probe('select core.organizations|anon|f|executed without error\n1\n'); self.assertEqual(h, 1); self.assertTrue(bad)

def apply_env(d, man, hist=None, **extra):
    plan = m.compute_plan(man, hist or {})
    env = {'MIGRATIONS_DIR': d, 'REPORT_OUT': os.path.join(tempfile.mkdtemp(), 'rep.md'), 'REPO_ROOT': ROOT, 'EXPECTED': EXPECTED_PATH,
           'EXPECTED_MANIFEST_HASH': m.manifest_hash(man), 'EXPECTED_PLAN_HASH': m.plan_hash(plan), 'EXPECTED_GIT_SHA': 'a' * 40}
    env.update(extra)
    return env

class ApplyFlow(unittest.TestCase):
    def setUp(self):
        self.d = mk({'20261104000100_a.sql': GOOD, '20261104000200_b.sql': GOOD, '20261104000300_c.sql': GOOD})
        errs, self.man = m.validate_files(self.d); self.assertEqual(errs, [])
        self.calls = []
    def fake_psql(self, fail_on=None):
        def f(sql=None, stdin=None, file=None, tuples=False, single_tx=False):
            if stdin is not None and 'applied_migrations (' in stdin and 'create table t' in stdin:
                self.calls.append(stdin)
                if fail_on and fail_on in stdin:
                    return 1, '', 'ERROR: relation exists\nLINE 1'
            return 0, '', ''
        return f
    def run_apply(self, env, history=None, fail_on=None, marker=None, branch=None, approval=None, prior=None):
        with mock.patch.dict(os.environ, env), mock.patch.object(m, 'psql', self.fake_psql(fail_on)), \
             mock.patch.object(m, 'read_history', lambda: (history or {}, True)), mock.patch.object(m, 'verify_marker', lambda: marker or []), \
             mock.patch.object(m, 'branch_errors', lambda: branch or []), mock.patch.object(m, 'approval_errors', lambda: approval or []), \
             mock.patch.object(m, 'prior_validation_errors', lambda: prior or []):
            return m.cmd_apply()
    def test_stops_at_first_failure_and_reports(self):
        env = apply_env(self.d, self.man)
        rc = self.run_apply(env, fail_on='20261104000200_b.sql')
        self.assertEqual(rc, 1); self.assertEqual(len(self.calls), 2)       # c.sql was never attempted
        rep = open(env['REPORT_OUT'], encoding='utf-8').read()
        self.assertIn('FAILED at `20261104000200_b.sql`', rep); self.assertIn('rolled back completely', rep)
        self.assertIn('insert into ops.applied_migrations', self.calls[0])
    def test_success_applies_all_in_order(self):
        rc = self.run_apply(apply_env(self.d, self.man)); self.assertEqual(rc, 0); self.assertEqual(len(self.calls), 3)
    def test_refuses_when_history_inconsistent(self):
        env = apply_env(self.d, self.man)
        self.assertEqual(self.run_apply(env, history={'20261104000100_a.sql': 'tampered'}), 1); self.assertEqual(self.calls, [])
    def test_blocks_if_database_history_changed_since_validation(self):
        env = apply_env(self.d, self.man)                                   # plan hash = nothing applied
        self.assertEqual(self.run_apply(env, history={'20261104000100_a.sql': self.man[0]['sha256']}), 1); self.assertEqual(self.calls, [])
    def test_blocks_if_files_changed_between_validation_and_apply(self):
        env = apply_env(self.d, self.man)                                   # hashes of the validated state
        open(os.path.join(self.d, '20261104000200_b.sql'), 'a', encoding='utf-8').write('\n-- tampered after validation\n')
        self.assertEqual(self.run_apply(env), 1); self.assertEqual(self.calls, [])
    def test_blocks_if_file_changes_after_static_gate_toctou(self):
        env = apply_env(self.d, self.man)
        real_gate = m.static_gate
        def gate_then_tamper(*a, **k):
            r = real_gate(*a, **k)
            open(os.path.join(self.d, '20261104000100_a.sql'), 'a', encoding='utf-8').write('\n-- changed after the gate\n')
            return r
        with mock.patch.object(m, 'static_gate', gate_then_tamper):
            rc = self.run_apply(env)
        self.assertEqual(rc, 1); self.assertEqual(self.calls, [])
        self.assertIn('changed on disk', open(env['REPORT_OUT'], encoding='utf-8').read())
    def test_blocks_without_validated_pins(self):
        for key in ('EXPECTED_MANIFEST_HASH', 'EXPECTED_PLAN_HASH', 'EXPECTED_GIT_SHA'):
            env = apply_env(self.d, self.man); env.pop(key)
            self.calls.clear(); self.assertEqual(self.run_apply(env), 1, key); self.assertEqual(self.calls, [], key)
    def test_blocks_on_commit_mismatch(self):
        env = apply_env(self.d, self.man, GITHUB_SHA='b' * 40)
        with mock.patch.object(m, 'git_head', lambda: 'c' * 40):
            self.assertEqual(self.run_apply(env), 1)
        self.assertEqual(self.calls, [])
    def test_blocks_if_commit_changed_since_validation(self):
        env = apply_env(self.d, self.man, GITHUB_SHA='b' * 40, EXPECTED_GIT_SHA='a' * 40)
        with mock.patch.object(m, 'git_head', lambda: 'b' * 40):
            self.assertEqual(self.run_apply(env), 1)
        self.assertEqual(self.calls, [])
    def test_blocks_when_independent_marker_fails(self):
        self.assertEqual(self.run_apply(apply_env(self.d, self.man), marker=['marker mismatch']), 1); self.assertEqual(self.calls, [])
    def test_each_failed_policy_gate_blocks_apply_and_runs_nothing(self):
        for kw in ({'branch': ['not default branch']}, {'approval': ['no approval recorded']}, {'prior': ['no validate-only run']}):
            self.calls.clear(); self.assertEqual(self.run_apply(apply_env(self.d, self.man), **kw), 1, kw); self.assertEqual(self.calls, [], kw)
    def test_ops_bookkeeping_never_creates_the_identity_marker(self):
        self.assertNotIn('environment_marker', m.OPS_SQL)

class GateFlow(unittest.TestCase):
    exp = json.load(open(EXPECTED_PATH, encoding='utf-8'))
    def make_psql(self, fail_id=None, drop_id=None, holes=0, extra_table=False, error_file=None, calls=None):
        exp = self.exp
        def fake(sql=None, stdin=None, file=None, tuples=False, single_tx=False):
            if calls is not None: calls.append(file or sql or 'stdin')
            if sql and sql.startswith('select table_schema'):
                t = list(exp['tables']) + (['core.rogue'] if extra_table else []); return 0, '\n'.join(t), ''
            if sql and 'count(*) from pg_proc' in sql: return 0, str(exp['function_count']), ''
            if sql and 'p.proname' in sql: return 0, '\n'.join(exp['api_functions']), ''
            if sql and sql.startswith('select count(*) from core.'): return 0, str(exp['seed_counts'][sql.split('from ')[1]]), ''
            if file and file.endswith('S2_privileges.sql'):
                return 0, 'select core.organizations|anon|%s|x\n%d\n' % ('f' if holes else 't', holes), ''
            if file and os.path.basename(file).startswith('t_'):
                name = os.path.basename(file)
                if error_file == name: return 3, '', 'ERROR: permission denied for table x'
                lines = []
                for i in exp['test_files'][name]:
                    if i == drop_id: continue
                    lines += ['RESULT|%s|%s|n' % (i, 'FAIL' if i == fail_id else 'PASS')] * exp['tests'][i]
                return 0, '\n'.join(lines), ''
            return 0, '', ''
        return fake
    def run_gate(self, root=None, marker=None, **kw):
        d = tempfile.mkdtemp(); env = {'EXPECTED': EXPECTED_PATH, 'REPO_ROOT': root or ROOT, 'REPORT_OUT': os.path.join(d, 'r.md')}
        with mock.patch.dict(os.environ, env), mock.patch.object(m, 'psql', self.make_psql(**kw)), mock.patch.object(m, 'verify_marker', lambda: marker or []):
            rc = m.cmd_checks()
        return rc, open(os.path.join(d, 'r.md'), encoding='utf-8').read()
    def test_all_green_passes_and_prints_coverage(self):
        rc, rep = self.run_gate(); self.assertEqual(rc, 0, rep); self.assertIn('Verdict: PASS', rep); self.assertIn('Coverage matrix', rep)
    def test_each_critical_category_failure_blocks_gate(self):
        for tid in ('T307', 'T-ISO-2', 'T-RLS-3', 'T-PERM-4', 'T-PERM-6', 'T291', 'T-LDG-2', 'T-IDEM-1', 'T-APR-1', 'T-PRIV-1', 'T-PRIV-8', 'T-AUTH-1', 'T-AUD-2'):
            rc, rep = self.run_gate(fail_id=tid); self.assertEqual(rc, 1, tid); self.assertIn('Verdict: FAIL', rep)
    def test_a_missing_result_blocks_gate_even_if_everything_else_passes(self):
        rc, rep = self.run_gate(drop_id='T-ISO-3'); self.assertEqual(rc, 1); self.assertIn('T-ISO-3', rep)
    def test_psql_error_in_a_test_file_blocks_gate(self):
        rc, rep = self.run_gate(error_file='t_live_authz_isolation.sql'); self.assertEqual(rc, 1); self.assertIn('ERROR', rep)
    def test_privilege_hole_is_a_blocker(self):
        rc, rep = self.run_gate(holes=2); self.assertEqual(rc, 1); self.assertIn('CRITICAL SECURITY HOLE', rep)
    def test_unexpected_extra_table_blocks_gate(self):
        rc, rep = self.run_gate(extra_table=True); self.assertEqual(rc, 1); self.assertIn('rogue', rep)
    def test_failed_independent_identity_stops_everything(self):
        calls = []; rc, rep = self.run_gate(marker=['marker mismatch'], calls=calls); self.assertEqual(rc, 1); self.assertEqual(calls, [])
    def test_missing_test_file_fails_and_runs_nothing(self):
        root = tempfile.mkdtemp(); shutil.copytree(os.path.join(ROOT, 'backend'), os.path.join(root, 'backend'))
        os.remove(os.path.join(root, 'backend', 'supabase', 'tests', 't_privilege_model.sql'))
        calls = []; rc, rep = self.run_gate(root=root, calls=calls); self.assertEqual(rc, 1); self.assertIn('test file missing', rep); self.assertEqual(calls, [])
    def test_missing_probe_file_fails(self):
        root = tempfile.mkdtemp(); shutil.copytree(os.path.join(ROOT, 'backend'), os.path.join(root, 'backend'))
        os.remove(os.path.join(root, 'backend', 'spikes', 'S2_privileges.sql'))
        rc, rep = self.run_gate(root=root); self.assertEqual(rc, 1); self.assertIn('probe', rep.lower())
    def test_removed_test_id_literal_is_detected_offline(self):
        root = tempfile.mkdtemp(); shutil.copytree(os.path.join(ROOT, 'backend'), os.path.join(root, 'backend'))
        f = os.path.join(root, 'backend', 'supabase', 'tests', 't_ledger_negative_approval.sql')
        t = open(f, encoding='utf-8').read().replace("'T-LDG-2'", "'RENAMED'"); open(f, 'w', encoding='utf-8').write(t)
        errs = m.check_dependencies(json.load(open(EXPECTED_PATH, encoding='utf-8')), root); self.assertTrue(any('T-LDG-2' in e for e in errs))
    def test_coverage_requires_a_passing_negative_test_in_every_category(self):
        exp = json.load(open(EXPECTED_PATH, encoding='utf-8'))
        rows = []
        for i, n in exp['tests'].items():
            rows += [(i, 'FAIL' if i in exp['categories']['ledger'] and i in exp['negative_ids'] else 'PASS', '')] * n
        problems = m.evaluate_coverage(rows, exp); self.assertTrue(any('ledger' in p for p in problems))
    def test_real_expected_file_is_self_consistent(self):
        self.assertEqual(m.check_dependencies(json.load(open(EXPECTED_PATH, encoding='utf-8')), ROOT), [])

class WorkflowFile(unittest.TestCase):
    path = os.path.join(ROOT, '.github', 'workflows', 'staging-migrations.yml')
    def load(self):
        try:
            import yaml
        except ImportError:
            self.skipTest('pyyaml not installed')
        text = open(self.path, encoding='utf-8').read()
        return yaml.safe_load(text), text
    def test_manual_only_least_privilege_two_secrets(self):
        d, text = self.load(); on = d.get('on', d.get(True))
        self.assertEqual(list(on.keys()), ['workflow_dispatch'])
        self.assertEqual(d['permissions'], {'contents': 'read'})
        import re
        self.assertEqual(sorted(set(re.findall(r'secrets\.(\w+)', text))), ['STAGING_CHALLENGE', 'STAGING_DB_URL'])
        self.assertNotIn('secrets.', text.split('jobs:')[0])
    def test_environments_and_job_wiring(self):
        d, _ = self.load(); j = d['jobs']
        self.assertNotIn('environment', j['static'])
        self.assertEqual(j['db-validate']['environment'], 'staging-validate')
        self.assertEqual(j['apply']['environment'], 'staging-apply'); self.assertEqual(j['post-checks']['environment'], 'staging-apply')
        self.assertEqual(sorted(j['apply']['needs']), ['db-validate', 'static'])
        self.assertEqual(set(j['static']['outputs']), {'manifest_hash', 'git_sha'}); self.assertIn('plan_hash', j['db-validate']['outputs'])
    def test_apply_pins_everything_it_validated(self):
        d, _ = self.load(); steps = d['jobs']['apply']['steps']
        env = [st for st in steps if 'Re-validate everything' in st.get('name', '')][0]['env']
        for k in ('EXPECTED_GIT_SHA', 'EXPECTED_MANIFEST_HASH', 'EXPECTED_PLAN_HASH', 'STAGING_CHALLENGE'):
            self.assertIn(k, env)
    def test_no_secret_persistence_and_no_unpinned_checkout(self):
        _, text = self.load()
        self.assertNotIn('GITHUB_ENV', text); self.assertNotIn('download-artifact', text); self.assertNotIn('set -x', text)
        self.assertEqual(text.count('actions/checkout@v4'), text.count('ref: ${{ github.sha }}'))
        self.assertEqual(text.count('persist-credentials: false'), text.count('actions/checkout@v4'))

class MandatoryProductionRef(unittest.TestCase):
    def env(self, **kw):
        e = {'STAGING_DB_URL': URL, 'EXPECTED_REF': STG, 'CONFIRM_REF': STG, 'PRODUCTION_REF': PROD, 'GITHUB_ENV': os.path.join(tempfile.mkdtemp(), 'genv')}
        e.update(kw); return e
    def test_validate_refs(self):
        self.assertEqual(m.validate_refs(STG, PROD), [])
        self.assertTrue(any('REQUIRED' in x for x in m.validate_refs(STG, '')))
        self.assertTrue(any('IDENTICAL' in x for x in m.validate_refs(STG, STG)))
        self.assertTrue(m.validate_refs('SHORT', PROD)); self.assertTrue(m.validate_refs(STG, 'bad ref!'))
    def test_identity_stops_without_or_with_equal_production_ref(self):
        for prod in ('', STG):
            with mock.patch.dict(os.environ, self.env(PRODUCTION_REF=prod)): self.assertEqual(m.cmd_identity(), 1, prod)
    def test_identity_passes_and_writes_nothing_to_github_env(self):
        e = self.env(); open(e['GITHUB_ENV'], 'w').close()
        with mock.patch.dict(os.environ, e): self.assertEqual(m.cmd_identity(), 0)
        self.assertEqual(os.path.getsize(e['GITHUB_ENV']), 0)

class CredentialHandling(unittest.TestCase):
    def test_newline_injection_rejected(self):
        for bad in ('postgresql://postgres.abcdefghijklmnop:pw%0AEVIL=1@aws-0-x.pooler.supabase.com:5432/postgres',
                    'postgresql://postgres.abcdefghijklmnop:pw%0D%0AEVIL=1@aws-0-x.pooler.supabase.com:5432/postgres',
                    'postgresql://postgres.abcdefghijklmnop:pw\nEVIL=1@aws-0-x.pooler.supabase.com:5432/postgres',
                    'postgresql://postgres.abcdefghijklmnop:pw%00x@aws-0-x.pooler.supabase.com:5432/postgres'):
            with self.assertRaises(ValueError): m.parse_db_url(bad)
            errs, _ = m.verify_identity(bad, STG, STG, PROD); self.assertTrue(errs)
    def test_query_parameters_and_missing_parts_rejected(self):
        for bad in (URL + '?options=-c%20search_path%3Devil', 'postgresql://aws-0-x.pooler.supabase.com/postgres', 'postgresql://u@aws-0-x.pooler.supabase.com/postgres'):
            with self.assertRaises(ValueError): m.parse_db_url(bad)
    def test_surrounding_whitespace_is_trimmed_not_trusted(self):
        self.assertEqual(m.parse_db_url('  ' + URL + '\n')['user'], 'postgres.' + STG)
    def test_special_characters_decoded_once(self):
        self.assertEqual(m.parse_db_url(URL)['password'], 'S3cr@t-Pass')
    def test_pg_env_is_rebuilt_clean(self):
        amb = {'STAGING_DB_URL': URL, 'STAGING_CHALLENGE': 'x' * 20, 'PGSERVICE': 'evil', 'PGOPTIONS': '-c search_path=evil', 'PGHOST': 'evil.example.com', 'KEEP': '1'}
        with mock.patch.dict(os.environ, amb):
            env = m.pg_env()
        self.assertEqual(env['PGHOST'], 'aws-0-ap-southeast-1.pooler.supabase.com'); self.assertEqual(env['PGSSLMODE'], 'require')
        self.assertNotIn('PGSERVICE', env); self.assertNotIn('PGOPTIONS', env); self.assertNotIn('STAGING_DB_URL', env); self.assertNotIn('STAGING_CHALLENGE', env); self.assertEqual(env['KEEP'], '1')
    def test_error_output_from_psql_is_redacted(self):
        cp = subprocess.CompletedProcess(args=[], returncode=2, stdout='', stderr='FATAL: password authentication failed for S3cr@t-Pass at ' + URL)
        with mock.patch.dict(os.environ, {'STAGING_DB_URL': URL}), mock.patch.object(subprocess, 'run', return_value=cp):
            rc, out, err = m.psql(sql='select 1')
        self.assertEqual(rc, 2); self.assertNotIn('S3cr', err); self.assertNotIn('pooler.supabase.com', err)
    def test_argv_never_contains_the_password(self):
        seen = {}
        def fake_run(cmd, **kw):
            seen['cmd'] = cmd; return subprocess.CompletedProcess(cmd, 0, '', '')
        with mock.patch.dict(os.environ, {'STAGING_DB_URL': URL}), mock.patch.object(subprocess, 'run', fake_run):
            m.psql(sql='select 1'); m.psql(stdin='select 2')
        self.assertNotIn('S3cr', ' '.join(seen['cmd']))
    def test_step_summary_and_challenge_are_redacted(self):
        f = os.path.join(tempfile.mkdtemp(), 'sum.md'); tok = 'challenge-token-0123456789'
        with mock.patch.dict(os.environ, {'STAGING_DB_URL': URL, 'STAGING_CHALLENGE': tok, 'GITHUB_STEP_SUMMARY': f}):
            m.summary('leak %s and %s and %s' % (URL, tok, m.challenge_hash(tok)))
        t = open(f, encoding='utf-8').read(); self.assertNotIn(tok, t); self.assertNotIn('S3cr', t); self.assertNotIn(m.challenge_hash(tok), t)
    def test_github_output_accepts_only_hex(self):
        f = os.path.join(tempfile.mkdtemp(), 'out'); 
        with mock.patch.dict(os.environ, {'GITHUB_OUTPUT': f}):
            m.github_output('ok', 'a' * 64); m.github_output('bad', 'x\ninjected=1'); m.github_output('bad2', 'not-hex' * 8)
        self.assertEqual(open(f).read(), 'ok=' + 'a' * 64 + '\n')

class IndependentIdentityMarker(unittest.TestCase):
    TOKEN = 'challenge-token-0123456789'
    def fake(self, table_exists=True, match=True, rc_query=0):
        def f(sql=None, stdin=None, file=None, tuples=False, single_tx=False):
            if sql and 'to_regclass' in sql: return rc_query, ('t' if table_exists else 'f'), ''
            if stdin and 'challenge_sha256' in stdin:
                self.sent = stdin; return 0, ('t' if match else 'f'), ''
            return 0, '', ''
        return f
    def run_marker(self, token=None, **kw):
        with mock.patch.dict(os.environ, {'STAGING_CHALLENGE': self.TOKEN if token is None else token}), mock.patch.object(m, 'psql', self.fake(**kw)):
            return m.verify_marker()
    def test_proven_only_when_marker_exists_and_challenge_matches(self):
        self.assertEqual(self.run_marker(), [])
        self.assertIn(m.challenge_hash(self.TOKEN), self.sent); self.assertNotIn(self.TOKEN, self.sent)      # only the hash is ever sent
    def test_absent_marker_fails_and_explains(self): self.assertTrue(any('NOT found' in e for e in self.run_marker(table_exists=False)))
    def test_wrong_database_fails(self): self.assertTrue(any('FAILED' in e for e in self.run_marker(match=False)))
    def test_weak_or_missing_challenge_fails(self):
        self.assertTrue(self.run_marker(token='short')); self.assertTrue(self.run_marker(token=''))
    def test_query_error_fails(self): self.assertTrue(self.run_marker(rc_query=2))
    def test_plan_stops_before_reading_history_when_marker_fails(self):
        d = tempfile.mkdtemp(); mp = os.path.join(d, 'man.json'); json.dump([], open(mp, 'w'))
        called = []
        with mock.patch.dict(os.environ, {'MANIFEST': mp, 'PLAN_OUT': os.path.join(d, 'p.json')}), mock.patch.object(m, 'verify_marker', lambda: ['nope']), \
             mock.patch.object(m, 'read_history', lambda: called.append(1) or ({}, True)):
            self.assertEqual(m.cmd_plan(), 1)
        self.assertEqual(called, [])

class ManifestAndHashes(unittest.TestCase):
    def test_manifest_hash_deterministic_and_sensitive(self):
        a = [{'filename': 'a.sql', 'sha256': '1'}, {'filename': 'b.sql', 'sha256': '2'}]
        self.assertEqual(m.manifest_hash(a), m.manifest_hash(list(a)))
        self.assertNotEqual(m.manifest_hash(a), m.manifest_hash([a[0], {'filename': 'b.sql', 'sha256': '3'}]))
        self.assertNotEqual(m.manifest_hash(a), m.manifest_hash(list(reversed(a))))
        self.assertNotEqual(m.manifest_hash(a), m.manifest_hash(a[:1]))
    def test_plan_hash_changes_when_history_changes(self):
        man = [{'filename': 'a.sql', 'sha256': '1'}, {'filename': 'b.sql', 'sha256': '2'}]
        self.assertNotEqual(m.plan_hash(m.compute_plan(man, {})), m.plan_hash(m.compute_plan(man, {'a.sql': '1'})))

class SourceFilesGuard(unittest.TestCase):
    def read(self, *p): return open(os.path.join(ROOT, 'backend', *p), encoding='utf-8').read()
    def test_privilege_model_test_covers_real_supabase_roles_and_catalogs(self):
        t = self.read('supabase', 'tests', 't_privilege_model.sql')
        for needle in ("'anon'", "'authenticated'", "'service_role'", "'authenticator'", 'has_table_privilege', 'has_sequence_privilege', 'has_schema_privilege',
                       'has_function_privilege', 'aclexplode', 'pg_auth_members', 'rolbypassrls', "'erp_owner'"):
            self.assertIn(needle, t, needle)
    def test_live_test_uses_real_runtime_role_switching_and_negative_writes(self):
        t = self.read('supabase', 'tests', 't_live_authz_isolation.sql')
        for needle in ('set local role authenticated', 'request.jwt.claims', 'insufficient_privilege', 'fn_session_alive', "'T-AUTH-1'", 'forged', 'TEST-ONLY'):
            self.assertIn(needle, t, needle)
        self.assertLess(t.index("'T-AUTH-1'"), t.index('create or replace function core.fn_session_alive'))   # the real check runs BEFORE the substitution
    def test_e_auth_fix_is_present_and_original_preserved(self):
        fixed = self.read('supabase', 'migrations', '20261104000900_authz_rls_api.sql')
        orig = self.read('supabase', 'original_unapplied', '20261104000900_authz_rls_api.ORIGINAL.sql')
        self.assertIn("case when core.fn_current_employee_id() is null then jsonb_build_object('error', 'E_AUTH')", fixed)
        self.assertNotIn("select coalesce(jsonb_build_object(", fixed); self.assertIn("select coalesce(jsonb_build_object(", orig)
        self.assertTrue(os.path.isfile(os.path.join(ROOT, 'backend', 'supabase', 'CHANGES_BEFORE_FIRST_APPLY.md')))
    def test_migrations_still_pass_static_validation(self):
        errors, man = m.validate_files(REAL_MIGRATIONS); self.assertEqual(errors, []); self.assertEqual(len(man), 9)


class PolicyGates(unittest.TestCase):
    def env(self, **kw):
        e = {'GITHUB_REF_NAME': 'main', 'DEFAULT_BRANCH': 'main', 'GITHUB_REPOSITORY': 'owner/repo', 'GITHUB_RUN_ID': '555', 'GITHUB_SHA': 'a' * 40}
        e.update(kw); return e
    def test_branch_policy(self):
        with mock.patch.dict(os.environ, self.env()): self.assertEqual(m.branch_errors(), [])
        with mock.patch.dict(os.environ, self.env(GITHUB_REF_NAME='feature')): self.assertTrue(m.branch_errors())
        with mock.patch.dict(os.environ, self.env(GITHUB_REF_TYPE='tag')): self.assertTrue(m.branch_errors())
        for missing in ('GITHUB_REF_NAME', 'DEFAULT_BRANCH'):
            e = self.env(); e.pop(missing)
            with mock.patch.dict(os.environ, e, clear=True): self.assertTrue(m.branch_errors(), missing)       # fail closed
    def test_apply_itself_rechecks_the_default_branch_without_mocks(self):
        d = mk({'20261104000100_a.sql': GOOD}); errs, man = m.validate_files(d); calls = []
        env = dict(apply_env(d, man), **self.env(GITHUB_REF_NAME='feature-x'))
        with mock.patch.dict(os.environ, env), mock.patch.object(m, 'approval_errors', lambda: []), mock.patch.object(m, 'prior_validation_errors', lambda: []), \
             mock.patch.object(m, 'psql', lambda *a, **k: calls.append(1) or (0, '', '')):
            self.assertEqual(m.cmd_apply(), 1)
        self.assertEqual(calls, [])
    def approvals(self, payload):
        return lambda path: payload
    def test_reviewer_approval_must_be_recorded_for_the_right_environment(self):
        ok = [{'state': 'approved', 'user': {'login': 'owner'}, 'environments': [{'name': 'staging-apply'}]}]
        with mock.patch.dict(os.environ, self.env()):
            with mock.patch.object(m, 'gh_api', self.approvals(ok)): self.assertEqual(m.approval_errors(), [])
            for bad in ([], [{'state': 'rejected', 'environments': [{'name': 'staging-apply'}]}], [{'state': 'approved', 'environments': [{'name': 'staging-validate'}]}], {'message': 'x'}):
                with mock.patch.object(m, 'gh_api', self.approvals(bad)):
                    errs = m.approval_errors(); self.assertTrue(errs); self.assertTrue(any('NOT active' in e or 'approval' in e for e in errs))
            def boom(path): raise OSError('network')
            with mock.patch.object(m, 'gh_api', boom): self.assertTrue(any('fail-closed' in e for e in m.approval_errors()))
    def good_run(self, **kw):
        now = __import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()
        r = {'status': 'completed', 'conclusion': 'success', 'head_sha': 'a' * 40, 'event': 'workflow_dispatch', 'path': '.github/workflows/staging-migrations.yml',
             'display_title': 'Staging Migrations | validate-only | ' + 'a' * 40, 'updated_at': now}
        r.update(kw); return r
    def test_prior_validate_only_run_is_required_and_checked(self):
        with mock.patch.dict(os.environ, self.env(VALIDATED_RUN_ID='444')):
            with mock.patch.object(m, 'gh_api', lambda p: self.good_run()): self.assertEqual(m.prior_validation_errors(), [])
            for bad in ({'conclusion': 'failure'}, {'status': 'in_progress'}, {'head_sha': 'b' * 40}, {'event': 'push'}, {'path': '.github/workflows/other.yml'},
                        {'display_title': 'Staging Migrations | post-checks-only | ' + 'a' * 40}, {'display_title': 'Staging Migrations | apply | ' + 'a' * 40},
                        {'updated_at': '2020-01-01T00:00:00Z'}, {'updated_at': 'garbage'}):
                with mock.patch.object(m, 'gh_api', lambda p, bad=bad: self.good_run(**bad)): self.assertTrue(m.prior_validation_errors(), bad)
    def test_prior_validation_id_rules(self):
        for rid in ('', 'abc', '12 34', '555'):                                   # 555 = this very run
            with mock.patch.dict(os.environ, self.env(VALIDATED_RUN_ID=rid)), mock.patch.object(m, 'gh_api', lambda p: self.good_run()):
                self.assertTrue(m.prior_validation_errors(), rid)
        def boom(path): raise OSError('x')
        with mock.patch.dict(os.environ, self.env(VALIDATED_RUN_ID='444')), mock.patch.object(m, 'gh_api', boom):
            self.assertTrue(any('fail-closed' in e for e in m.prior_validation_errors()))
    def test_gh_api_needs_a_token_and_the_token_is_redacted_everywhere(self):
        with mock.patch.dict(os.environ, {'GH_TOKEN': ''}, clear=False):
            with self.assertRaises(RuntimeError): m.gh_api('/x')
        with mock.patch.dict(os.environ, {'GH_TOKEN': 'ghs_secrettoken123456', 'STAGING_DB_URL': URL}):
            self.assertNotIn('ghs_secret', m.redact('boom ghs_secrettoken123456')); self.assertNotIn('GH_TOKEN', m.pg_env())
    def test_approval_command(self):
        ok = [{'state': 'approved', 'user': {'login': 'owner'}, 'environments': [{'name': 'staging-apply'}]}]
        with mock.patch.dict(os.environ, self.env()):
            with mock.patch.object(m, 'gh_api', self.approvals(ok)): self.assertEqual(m.cmd_approval(), 0)
            with mock.patch.object(m, 'gh_api', self.approvals([])): self.assertEqual(m.cmd_approval(), 1)
        with mock.patch.dict(os.environ, self.env(GITHUB_REF_NAME='feature')), mock.patch.object(m, 'gh_api', self.approvals(ok)): self.assertEqual(m.cmd_approval(), 1)
    def test_apply_mode_demands_a_numeric_validated_run_id_in_the_static_gate(self):
        d = mk({'20261104000100_a.sql': GOOD})
        for rid, expect in (('', 1), ('abc', 1), ('4242', 0)):
            env = {'MIGRATIONS_DIR': d, 'MANIFEST_OUT': os.path.join(tempfile.mkdtemp(), 'x.json'), 'MODE': 'apply', 'CONFIRM_APPLY': m.APPLY_PHRASE, 'VALIDATED_RUN_ID': rid, 'REPO_ROOT': ROOT, 'EXPECTED': EXPECTED_PATH}
            with mock.patch.dict(os.environ, env): self.assertEqual(m.cmd_static(), expect, rid)

class SqlDependencyAndAuthFix(unittest.TestCase):
    def test_real_migrations_have_no_ordering_problems(self): self.assertEqual(m.check_sql_dependencies(REAL_MIGRATIONS), [])
    def test_forward_reference_and_missing_object_are_caught(self):
        d = mk({'20260101000000_a.sql': 'create function core.f1() returns int language sql as $$ select core.f2() $$;\ncreate function core.f2() returns int language sql as $$ select 1 $$;\n'})
        self.assertTrue(any('core.f2' in e for e in m.check_sql_dependencies(d)))
        d = mk({'20260101000000_a.sql': 'create table core.t (id int references core.missing(id));\n'}); self.assertTrue(any('core.missing' in e for e in m.check_sql_dependencies(d)))
    def test_string_literals_are_not_references(self):
        d = mk({'20260101000000_a.sql': "insert into x values ('hr.employee.view');\n"}); self.assertEqual(m.check_sql_dependencies(d), [])
    def test_e_auth_function_structure_and_dependencies(self):
        import re
        t = open(os.path.join(ROOT, 'backend', 'supabase', 'migrations', '20261104000900_authz_rls_api.sql'), encoding='utf-8').read()
        body = re.sub(r'--[^\n]*', '', re.search(r'create function core\.fn_get_my_permissions\(\).*?\$\$(.*?)\$\$;', t, re.S).group(1))
        self.assertEqual((len(re.findall(r'\bcase\b', body)), len(re.findall(r'\bend\b', body)), len(re.findall(r'\belse\b', body))), (1, 1, 1))
        self.assertEqual(body.count('('), body.count(')'))
        self.assertTrue(body.strip().startswith("select case when core.fn_current_employee_id() is null then jsonb_build_object('error', 'E_AUTH') else jsonb_build_object("))
        order = [x for x in re.findall(r'create function (core\.\w+)', t)]
        for dep in ('core.fn_current_employee_id', 'core.fn_current_org_id'):
            self.assertLess(order.index(dep), order.index('core.fn_get_my_permissions'))
        for tbl in ('core.user_roles', 'core.role_permissions', 'core.permissions'):
            self.assertIn('create table ' + tbl, open(os.path.join(ROOT, 'backend', 'supabase', 'migrations', '20261104000300_core_rbac.sql'), encoding='utf-8').read())

class LayoutChecks(unittest.TestCase):
    def fresh_root(self):
        root = tempfile.mkdtemp()
        for rel in m.LAYOUT_FILES + [m.LAYOUT_MANIFEST]:
            dst = os.path.join(root, rel); os.makedirs(os.path.dirname(dst), exist_ok=True); shutil.copy(os.path.join(ROOT, rel), dst)
        return root
    def test_real_layout_is_complete_and_current(self):
        self.assertEqual(m.verify_layout(ROOT), [])
        for rel in m.LAYOUT_FILES: self.assertTrue(os.path.isfile(os.path.join(ROOT, rel)), rel)
    def test_missing_file_is_reported(self):
        r = self.fresh_root(); os.remove(os.path.join(r, 'backend/supabase/tests/t_privilege_model.sql'))
        self.assertTrue(any('MISSING FILE' in e and 't_privilege_model' in e for e in m.verify_layout(r)))
    def test_older_patch_version_is_reported_with_line_counts(self):
        r = self.fresh_root(); open(os.path.join(r, 'backend/ops/mohona_ops.py'), 'w', encoding='utf-8').write('# the v1 tool\n')
        errs = m.verify_layout(r); self.assertTrue(any('WRONG VERSION' in e and 'mohona_ops.py' in e and 'lines' in e for e in errs))
    def test_crlf_and_missing_final_newline_do_not_cause_false_alarms(self):
        r = self.fresh_root(); f = os.path.join(r, 'backend/ops/GUIDE_BN.md')
        t = open(f, 'rb').read().decode('utf-8').replace('\n', '\r\n').rstrip('\r\n'); open(f, 'wb').write(t.encode('utf-8'))
        self.assertEqual(m.verify_layout(r), [])
    def test_missing_manifest_and_unlisted_file(self):
        r = self.fresh_root(); os.remove(os.path.join(r, m.LAYOUT_MANIFEST)); self.assertTrue(any('file_manifest.json' in e for e in m.verify_layout(r)))
    def test_static_gate_fails_on_a_stale_file(self):
        r = self.fresh_root(); open(os.path.join(r, 'backend/ops/expected.json'), 'a').write('\n\n')
        self.assertEqual(m.verify_layout(r), [])                                  # extra trailing newlines are normalised away
        open(os.path.join(r, 'backend/ops/expected.json'), 'a').write('{}')
        self.assertTrue(m.verify_layout(r))

class WorkflowPolicy(unittest.TestCase):
    def load(self):
        try: import yaml
        except ImportError: self.skipTest('pyyaml not installed')
        text = open(os.path.join(ROOT, '.github', 'workflows', 'staging-migrations.yml'), encoding='utf-8').read(); return yaml.safe_load(text), text
    def test_run_title_modes_and_inputs(self):
        d, text = self.load(); on = d.get('on', d.get(True))['workflow_dispatch']['inputs']
        self.assertIn('${{ inputs.mode }}', d['run-name']); self.assertIn('${{ github.sha }}', d['run-name'])
        self.assertEqual(on['mode']['options'], ['approval-check', 'validate-only', 'apply', 'post-checks-only']); self.assertEqual(on['mode']['default'], 'approval-check')
        self.assertIn('validated_run_id', on)
    def test_database_jobs_recheck_default_branch_and_apply_checks_actions_read_only_where_needed(self):
        d, text = self.load(); j = d['jobs']
        for name in ('db-validate', 'apply', 'post-checks', 'approval-check'):
            self.assertIn('github.event.repository.default_branch', j[name]['if'], name)
        self.assertEqual(d['permissions'], {'contents': 'read'})
        for name in ('apply', 'post-checks', 'approval-check'): self.assertEqual(j[name]['permissions'], {'contents': 'read', 'actions': 'read'}, name)
        for name in ('static', 'db-validate'): self.assertNotIn('permissions', j[name])
        self.assertEqual(j['approval-check']['environment'], 'staging-apply'); self.assertIn("inputs.mode != 'approval-check'", j['db-validate']['if'])
    def test_apply_step_receives_every_pin_and_gate_input(self):
        d, _ = self.load(); env = [st for st in d['jobs']['apply']['steps'] if 'Re-validate everything' in st.get('name', '')][0]['env']
        for k in ('VALIDATED_RUN_ID', 'GH_TOKEN', 'DEFAULT_BRANCH', 'EXPECTED_GIT_SHA', 'EXPECTED_MANIFEST_HASH', 'EXPECTED_PLAN_HASH', 'STAGING_CHALLENGE', 'STAGING_DB_URL'): self.assertIn(k, env)
    def test_github_token_only_in_jobs_that_have_actions_read(self):
        d, _ = self.load()
        for name, job in d['jobs'].items():
            uses = any('GH_TOKEN' in (st.get('env') or {}) for st in job['steps'])
            self.assertEqual(uses, name in ('apply', 'post-checks', 'approval-check'), name)

if __name__ == '__main__':
    unittest.main()
