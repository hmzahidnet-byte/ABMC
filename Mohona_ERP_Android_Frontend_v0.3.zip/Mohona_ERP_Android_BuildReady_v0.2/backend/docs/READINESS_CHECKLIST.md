# Implementation Readiness Checklist (2026-11-04)
Evidence rule: "done" needs a file in `docs/EVIDENCE/`.

| Item | State | Evidence |
| --- | --- | --- |
| Owner decisions OD-01..04 recorded | **Done** | `docs/DECISIONS.md` |
| Repository structure | **Done** | this tree |
| Release gate (OD-01) implemented | **Done (local)** | `docs/EVIDENCE/release_gate_tests_*.log` |
| Independent reviewer named | **Open — blocks Production only** | `release/REVIEWER.json` empty |
| Staging Supabase project exists | **Open — needs owner** | `docs/SUPABASE_STAGING_SETUP.md` |
| Spike S1 (version/extensions) | Script written, **not run** | `spikes/S1_pg_version_extensions.sql` |
| Spike S2 (privileges) | Script written, **not run** | `spikes/S2_privileges.sql` |
| Spike S3 (auth/revocation) | Script written, **not run** | `spikes/S3_auth_session_revocation.py` |
| Migrations applied to any database | **No** | — |
| SQL tests executed | **No (0)** | — |
| First-slice RPCs implementation-ready | **25 of 31** (1 written in SQL; 6 not ready: outbox, QR×2, action menu, export×2) | Appendix G |
| Test count | **319 documented**: 302 active, 12 need revision, 5 superseded; executed **3** (T300–T302), passed **3** | Appendix H |
| Android project | Structure only, nothing built | `app/` |
