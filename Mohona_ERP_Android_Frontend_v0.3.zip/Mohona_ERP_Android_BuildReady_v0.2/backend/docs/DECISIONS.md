# Decision Register (authoritative for this repository)
Status words: **OWNER APPROVED** = the owner's own written decision. **PROPOSED** = not approved. **IMPLEMENTED/TESTED** only with evidence.

## Owner-Approved on 2026-11-04
| ID | Decision | Where it is applied | Implementation state |
| --- | --- | --- | --- |
| OD-01 | Production changes (code, schema, security policy, migration, important config) need independent technical review. Reviewer named later; Dev/Staging never blocked. Developer cannot self-approve. Evidence, approval record, Git commit/tag and version kept. No reviewer ⇒ Production Release **BLOCKED**. Emergency releases only under a safe auditable rule and only with Owner approval. | `release/REVIEWER.json`, `release/approvals/`, `scripts/check_release_gate.py`; Audit Report §7/§9; Baseline register; Appendix H T300–T302 | Gate script **implemented and executed locally** (12/12 cases pass). Reviewer not yet named ⇒ gate currently BLOCKED (correct). CI wiring: pending. |
| OD-02 | A person working in several companies has a **separate login account per company**; separate role/permission/scope/session per company; no cross-company access or permission inheritance; Group authority separate; suspending one account never affects another. | Appendix E (`employee_accounts` Δ); migrations `…0200`, `…0300`, `…0900`; Appendix H T303–T306 | SQL **written, not executed**. Supabase Auth identity mapping **unverified** (Spike S3). |
| OD-03 | First version: no cross-company financial transaction, stock transfer, ledger posting or payment/collection adjustment. Enforced in backend and database, not only UI. Future change needs new Owner approval + accounting rules + independent security review. | Composite FKs `(id, organization_id)` in all migrations (esp. `…0800`); Appendix E, G; Appendix H T307–T310 | SQL **written, not executed**. Stock/Party parts not yet written. |
| OD-04 | The 17 roles of Appendix F are approved with its initial matrix as authoritative reference. Role names/IDs stable. Enforcement in RPC, RLS, live authorization (never UI only). Maker-Checker and SoD kept. Factory P&L only the company's MD. Tech Admin has no business data. EMERGENCY_ADMIN approved but its incomplete break-glass policy is **not** approved. Future-Wing placeholder permissions stay disabled until that Wing is designed and tested. First slice activates only needed permissions. | Appendix F; migrations `…0300`, `…0400` (`registered` vs `active`); Appendix H T311–T315 | Seed SQL **written, not executed**. |


## Owner-Approved on 2026-11-05 (Manufacturing Wing)
| ID | Decision | Notes |
| --- | --- | --- |
| OD-05 | **Moving Weighted Average** costing for the applicable raw-material inventory valuation pools | Recorded as Owner-Approved by the owner's explicit instruction of 2026-11-05. Closes the valuation-method part of Pending #1. Negative stock (#7) remains Pending (proposal: prohibited). Rounding/precision rules to be proposed in the S5 design. |
| OD-06 | **Finished Goods unit = POLY** (not PCS); raw materials keep their real measurement units | Same instruction. **Product-specific Poly conversion rules remain PENDING**: each product's conversion needs the owner's written approval before any live costing. No silent conversion, no assumed fixed quantity. |
| R-C1 | **First-slice "Material Cost per Poly" must never be shown as Full Production Cost or Actual Profit** | Binding display rule. Allowed label: "উপাদান-খরচ প্রতি Poly (আংশিক: শ্রম, বিদ্যুৎ, মেশিন, ওভারহেড অন্তর্ভুক্ত নয়)". Unsold finished goods are never revenue; projected profit is never shown as realized profit. |

## Also Owner-Approved earlier
Native Android (Kotlin/Compose, Bangla light UI); Supabase/PostgreSQL (PG17 target, subject to verification); multiple separate legal companies; Chairman Group-level, MD per company; Reversal + Replacement with independent approval (Option B); Maker-Checker, no self-approval; immutable ledgers; no VAT/Tax; no CCTV; Universal QR; "Universal Key" = ⋮ Action Menu; exact visual sharing; factory attendance by designated QR device with PIN and authorised HR backup; GAP-05 (legacy ERP) = **NOT APPLICABLE — GREENFIELD**.

## NOT approved (still PROPOSED / open)
Product-specific Poly conversions (per product), GRNI accounting treatment, WIP accounting policy, overhead allocation and abnormal-loss treatment, negative stock (#7), stock reservation (#27), backdate limit (#22), Token lifetime (O31).
Backdate limit (#22), voucher numbering mode (#15), separate post step (#21), reversal date rule (#37), stock valuation/negative stock/GRNI, Group-chairman steps, period close/reopen, fiscal-year boundary, DR targets, retention periods, handover/custody policies, emergency approvers, public QR verification, printer models. The code implements #15/#21/#22/#37 as **settings with Proposed defaults** until the owner decides.
