# Evidence folder
Raw logs and reports, named by date. Present now:
- `release_gate_tests_*.log` — Python release-gate tests (12 cases, executed locally).
- `ops_offline_tests_*.log` — offline tests of the Staging migration tool (42 cases, executed locally; **no database involved**).
Not yet present (will be created by the Staging workflow): apply reports, P0 database gate reports, privilege-probe output, Auth-timing evidence.
Never commit keys, passwords or personal data.
