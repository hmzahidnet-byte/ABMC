# Starting Supabase Staging (owner task, ~20 minutes)
Goal: one **separate Staging project** (never Production) so Spike S1–S3 can run.

1. Create (or open) your Supabase account/organisation and create a new project named `mohona-erp-staging`. Pick a region close to Bangladesh (record which one). Keep the **database password** yourself; do not send it to anyone.
2. Open the SQL editor, paste `spikes/S1_pg_version_extensions.sql`, run it, and send the **result screenshot** (PostgreSQL version and extension rows). No keys or passwords in the screenshot.
3. Tell the developer the project reference. The developer then installs the Supabase CLI, runs `supabase link --project-ref <ref>` and `supabase db push` to apply `supabase/migrations/`, then runs `spikes/S2_privileges.sql` and `spikes/S3_auth_session_revocation.py` (keys are read from environment variables, never committed).
4. Anything that fails is reported as-is; failures are evidence, not embarrassment.

What this proves: the real PostgreSQL version (PG17 target), whether the privilege model works on Supabase, and how fast a revoked login stops working.
