#!/usr/bin/env python3
"""Production release gate (OD-01). Exit 0 = ALLOWED, exit 1 = BLOCKED. Standard library only.
Usage: check_release_gate.py <version> [--root <repo>] [--head <sha>]"""
import argparse, json, os, re, subprocess, sys

def _git_head(root):
    try:
        return subprocess.check_output(["git", "-C", root, "rev-parse", "HEAD"], stderr=subprocess.DEVNULL, text=True).strip()
    except Exception:
        return None

def check(version, root=".", head=None, commit_authors=()):
    reasons = []
    cfg_path = os.path.join(root, "release", "REVIEWER.json")
    if not os.path.isfile(cfg_path):
        return False, ["REVIEWER_CONFIG_MISSING"]
    cfg = json.load(open(cfg_path, encoding="utf-8"))
    reviewers = [str(r).strip().lower() for r in cfg.get("reviewers", []) if str(r).strip()]
    if not reviewers:
        reasons.append("REVIEWER_NOT_ASSIGNED")
    ap_path = os.path.join(root, "release", "approvals", f"{version}.json")
    if not os.path.isfile(ap_path):
        reasons.append("APPROVAL_RECORD_MISSING")
        return False, reasons
    ap = json.load(open(ap_path, encoding="utf-8"))
    author = str(ap.get("author", "")).strip().lower()
    reviewer = str(ap.get("reviewer", "")).strip().lower()
    if not author: reasons.append("AUTHOR_MISSING")
    if not reviewer: reasons.append("REVIEWER_MISSING_IN_RECORD")
    if reviewer and reviewers and reviewer not in reviewers: reasons.append("REVIEWER_NOT_AUTHORISED")
    if reviewer and (reviewer == author or reviewer in [a.strip().lower() for a in commit_authors]): reasons.append("REVIEWER_IS_AUTHOR")
    if ap.get("reviewer_decision") != "approved": reasons.append("NOT_APPROVED")
    sha = str(ap.get("git_commit", ""))
    if not re.fullmatch(r"[0-9a-f]{40}", sha): reasons.append("COMMIT_INVALID")
    actual = head if head is not None else _git_head(root)
    if actual and sha and sha != actual: reasons.append("COMMIT_MISMATCH")
    if ap.get("git_tag") != f"v{version}": reasons.append("TAG_MISMATCH")
    files = ap.get("evidence_files") or []
    if not files: reasons.append("EVIDENCE_MISSING")
    for f in files:
        fp = os.path.join(root, f)
        if not (os.path.isfile(fp) and os.path.getsize(fp) > 0): reasons.append(f"EVIDENCE_FILE_MISSING:{f}")
    if ap.get("emergency"):
        if not ap.get("owner_approval_ref"): reasons.append("EMERGENCY_WITHOUT_OWNER_APPROVAL")
        if not cfg.get("owner_emergency_exceptions_enabled"): reasons.append("EMERGENCY_EXCEPTIONS_DISABLED")
    return (not reasons), reasons

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("version"); ap.add_argument("--root", default="."); ap.add_argument("--head")
    a = ap.parse_args()
    ok, reasons = check(a.version, a.root, a.head)
    print(json.dumps({"version": a.version, "decision": "ALLOWED" if ok else "BLOCKED", "reasons": reasons}, ensure_ascii=False))
    sys.exit(0 if ok else 1)

if __name__ == "__main__":
    main()
