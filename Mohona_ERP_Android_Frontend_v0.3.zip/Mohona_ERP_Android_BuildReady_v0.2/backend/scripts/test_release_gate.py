"""Tests T300-T302 (OD-01 release gate). Run: python3 -m unittest scripts.test_release_gate -v  (from the repo root)."""
import json, os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(__file__))
from check_release_gate import check

SHA = "a" * 40

def make(reviewers, record, files=("release/evidence/0.1.0/notes.md",), emergency_switch=False):
    root = tempfile.mkdtemp()
    os.makedirs(os.path.join(root, "release", "approvals")); os.makedirs(os.path.join(root, "release", "evidence", "0.1.0"))
    json.dump({"reviewers": reviewers, "owner_emergency_exceptions_enabled": emergency_switch}, open(os.path.join(root, "release", "REVIEWER.json"), "w"))
    for f in files:
        p = os.path.join(root, f); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write("evidence")
    if record is not None:
        json.dump(record, open(os.path.join(root, "release", "approvals", "0.1.0.json"), "w"))
    return root

def good(**kw):
    r = {"version": "0.1.0", "git_commit": SHA, "git_tag": "v0.1.0", "author": "dev", "reviewer": "rev", "reviewer_decision": "approved",
         "evidence_files": ["release/evidence/0.1.0/notes.md"], "emergency": False, "owner_approval_ref": None}
    r.update(kw); return r

class ReleaseGate(unittest.TestCase):
    # T300: no reviewer assigned -> BLOCKED
    def test_T300_blocked_when_reviewer_unassigned(self):
        ok, why = check("0.1.0", make([], good()), head=SHA)
        self.assertFalse(ok); self.assertIn("REVIEWER_NOT_ASSIGNED", why)
    def test_T300_blocked_without_approval_record(self):
        ok, why = check("0.1.0", make(["rev"], None), head=SHA)
        self.assertFalse(ok); self.assertIn("APPROVAL_RECORD_MISSING", why)
    # T301: developer cannot approve own work
    def test_T301_reviewer_equal_author_rejected(self):
        ok, why = check("0.1.0", make(["dev"], good(author="dev", reviewer="dev")), head=SHA)
        self.assertFalse(ok); self.assertIn("REVIEWER_IS_AUTHOR", why)
    def test_T301_reviewer_matching_a_commit_author_rejected(self):
        ok, why = check("0.1.0", make(["rev"], good()), head=SHA, commit_authors=["Rev"])
        self.assertFalse(ok); self.assertIn("REVIEWER_IS_AUTHOR", why)
    def test_T301_unlisted_reviewer_rejected(self):
        ok, why = check("0.1.0", make(["someone"], good(reviewer="rev")), head=SHA)
        self.assertFalse(ok); self.assertIn("REVIEWER_NOT_AUTHORISED", why)
    # T302: evidence, commit/tag integrity, emergency rule
    def test_T302_missing_evidence_rejected(self):
        ok, why = check("0.1.0", make(["rev"], good(evidence_files=["release/evidence/0.1.0/none.md"])), head=SHA)
        self.assertFalse(ok); self.assertTrue(any(w.startswith("EVIDENCE_FILE_MISSING") for w in why))
    def test_T302_commit_mismatch_rejected(self):
        ok, why = check("0.1.0", make(["rev"], good()), head="b" * 40)
        self.assertFalse(ok); self.assertIn("COMMIT_MISMATCH", why)
    def test_T302_tag_mismatch_rejected(self):
        ok, why = check("0.1.0", make(["rev"], good(git_tag="v9")), head=SHA)
        self.assertFalse(ok); self.assertIn("TAG_MISMATCH", why)
    def test_T302_not_approved_rejected(self):
        ok, why = check("0.1.0", make(["rev"], good(reviewer_decision="changes_requested")), head=SHA)
        self.assertFalse(ok); self.assertIn("NOT_APPROVED", why)
    def test_T302_emergency_without_owner_approval_rejected(self):
        ok, why = check("0.1.0", make(["rev"], good(emergency=True), emergency_switch=True), head=SHA)
        self.assertFalse(ok); self.assertIn("EMERGENCY_WITHOUT_OWNER_APPROVAL", why)
    def test_T302_emergency_blocked_while_owner_switch_off(self):
        ok, why = check("0.1.0", make(["rev"], good(emergency=True, owner_approval_ref="OWNER-1")), head=SHA)
        self.assertFalse(ok); self.assertIn("EMERGENCY_EXCEPTIONS_DISABLED", why)
    def test_complete_record_allowed(self):
        ok, why = check("0.1.0", make(["rev"], good()), head=SHA)
        self.assertTrue(ok, why)

if __name__ == "__main__":
    unittest.main()
