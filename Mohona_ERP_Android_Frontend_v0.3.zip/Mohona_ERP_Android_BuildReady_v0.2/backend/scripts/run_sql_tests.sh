#!/usr/bin/env bash
# Runs migrations then the SQL tests against a PostgreSQL given by $DATABASE_URL and writes an evidence log.
# LOCAL (plain Postgres): set LOCAL_STUB=1 to load supabase/tests/stub/auth_stub.sql first. NEVER use LOCAL_STUB=1 on Supabase.
set -euo pipefail
: "${DATABASE_URL:?set DATABASE_URL}"
cd "$(dirname "$0")/.."
LOG="docs/EVIDENCE/sql_tests_$(date -u +%Y%m%dT%H%M%SZ).log"
{
  echo "# SQL test run $(date -u +%FT%TZ)  DATABASE: $(psql "$DATABASE_URL" -Atc 'select version()')"
  [ "${LOCAL_STUB:-0}" = "1" ] && psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/stub/auth_stub.sql
  for f in supabase/migrations/*.sql; do echo "## migrate $f"; psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$f"; done
  for f in supabase/tests/t_*.sql; do echo "## test $f"; psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -At -f "$f" | grep '^RESULT|' || echo "RESULT|$f|FAIL|no result lines"; done
} 2>&1 | tee "$LOG"
echo "Evidence: $LOG"; ! grep -q '|FAIL|' "$LOG"
