# Appendix G — সম্পূর্ণ RPC/API ক্যাটালগ ও First-Slice ৩১ Contract (OD-০১–০৪ প্রযোজ্য)

> **অবস্থা:** Owner-Approved নিয়ম (OD-০১ Release-Gate, OD-০২ কোম্পানি-ভিত্তিক Login, OD-০৩ Intercompany বন্ধ, OD-০৪ ১৭ Role) এই ক্যাটালগে প্রযোজ্য; RPC-গুলোর নিজস্ব Contract **Proposed**। **SQL-এ লেখা: ১টি (`rpc_get_my_permissions`) — চালানো হয়নি।** সব `rpc_*` আসলে `api.v1_*` Wrapper → `core.*`। **Slice-০-র ১৪টির পূর্ণ Input/Output** Baseline §৬.৩-এ; বাকিগুলোর পূর্ণ Contract ওই RPC-র Milestone-শুরুতে লেখা হবে (তখন কীওয়ার্ড-মিল নয়, Test-ভিত্তিক)। সাধারণ নিয়ম: Idempotency Key, Live Authorization (লক-পরে), Error-কোড-ক্যাটালগ (Appendix-নয়, Baseline §৬.৩ + নিচে), Audit-ঘটনা, `lock_timeout`।

**বাদ/অচল নাম:** `rpc_chairman_override` (→ `rpc_group_override`); `rpc_name` স্থানধারক মাত্র। **গণনা:** ক্যাটালগে মোট **৮৭**টি RPC/ফাংশন — Appendix C (Inventory) থেকে ২৮টি, **নতুন চিহ্নিত ৫৯টি** (পাঠ-RPC, Period, Finance-lite, Succession, QR/Action/Export, Notification ইত্যাদি)। **Test-বন্ধন (স্বয়ংক্রিয় মিল):** ৮৭টির মধ্যে মাত্র ৬টির সাথে Test-পাঠ থেকে RPC-নাম মিলেছে; বাকিগুলো “বাঁধা হয়নি”। এটি **Confirmed Missing Specification**: Milestone-শুরুতে প্রতিটি RPC-র Test-বন্ধন বাধ্যতামূলক।

## Lock-টেমপ্লেট

| কোড | ক্রম |
| --- | --- |
| LT-R | কোনো Business-Lock নেই (শুধু পাঠ; RLS) |
| LT-D | L১o KS → L১b KS → L২ |
| LT-S | L১o → L১b → L১c KS → L২ → L৩ |
| LT-A | L১o → L১b → L২ → L৩ [→ L৪p Auto-post] |
| LT-P | L১o → L১b → L২ → L৪p KS → L৪a → L৫…L৮ → L৯ → L১০ |
| LT-C | L১o → L১b → L২ → L৪ [→ L৪p(P_rev, P_rep)] |
| LT-I | L১o → L১b (প্রভাবিত কর্মী UPDATE; `authz_epoch`+১) → লেখা |
| LT-H | L১o → L১b (দুজন UPDATE) → L১s → L১k → (Snapshot: L৬–L৮) → L১০ |
| LT-O | L১a? → L১o UPDATE (দুই-ধাপ Suspend); Group-পথ |
| LT-W | Class-S Allowlist; Business-অবস্থা বদলায় না |
| LT-Y | L১o → L১b → L৪p UPDATE (Close/Reopen)  |
| LT-Q | L১o → L১b → Entity-সারি KS → লেখা |

## ক্যাটালগ

| # | RPC | Domain | Actor/Permission | Scope | Lock | Idempotent | Audit-ঘটনা | অবস্থা-পরিবর্তন/ফল | সংশ্লিষ্ট Test (স্বয়ংক্রিয় মিল) | Milestone | উৎস |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | `rpc_get_my_permissions` | Auth | লগইন | — | LT-R | — | `—` | Live Permission-তালিকা (UI-ইঙ্গিত) | বাঁধা হয়নি | First Vertical Slice | Inventory |
| 2 | `rpc_create_employee` | IAM | `iam.user.create` (Maker-Checker) | O | LT-I | হ্যাঁ | `employee_created` | → `active` | বাঁধা হয়নি | Foundation | **নতুন** |
| 3 | `rpc_update_employee` | HR | `hr.employee.edit` | O | LT-I | হ্যাঁ | `employee_updated` | — | বাঁধা হয়নি | Later Wing | **নতুন** |
| 4 | `rpc_assign_role` | IAM | `iam.role.assign` (MC, aal2) | O/G | LT-I | হ্যাঁ | `role_assigned` | Grant | বাঁধা হয়নি | Foundation | Inventory |
| 5 | `rpc_revoke_role` | IAM | `iam.role.assign` | O/G | LT-I | হ্যাঁ | `role_revoked` | Revoke; Journal-এন্ট্রি | বাঁধা হয়নি | Foundation | **নতুন** |
| 6 | `rpc_set_permission_override` | IAM | `iam.override.set` (aal2) | O | LT-I | হ্যাঁ | `override_set` | Override | বাঁধা হয়নি | Production Gate | Inventory |
| 7 | `rpc_clear_permission_override` | IAM | `iam.override.set` | O | LT-I | হ্যাঁ | `override_cleared` | — | বাঁধা হয়নি | Production Gate | **নতুন** |
| 8 | `rpc_create_delegation` | Approval | `approval.delegate` | O | LT-I | হ্যাঁ | `delegation_created` | সময়-বদ্ধ | বাঁধা হয়নি | Later Wing | Inventory |
| 9 | `rpc_end_delegation` | Approval | `approval.delegate` | O | LT-I | হ্যাঁ | `delegation_ended` | — | বাঁধা হয়নি | Later Wing | **নতুন** |
| 10 | `rpc_terminate_employee` | HR | `hr.employee.terminate` (aal2) | O/G | LT-H | হ্যাঁ | `employee_terminated` | `terminated`; Container সাময়িক-ধারক/`no_custodian`; QR/Device/Session বাতিল (Switch-ভেতরে/Worker) | বাঁধা হয়নি | Manufacturing | Inventory (Succession-ক্রমে সংশোধিত) |
| 11 | `rpc_suspend_employee` | HR | `hr.employee.terminate` | O | LT-H | হ্যাঁ | `employee_suspended` | `suspended` | বাঁধা হয়নি | Manufacturing | **নতুন** |
| 12 | `rpc_reinstate_employee` | HR | `hr.employee.terminate` (নতুন Maker-Checker) | O | LT-H | হ্যাঁ | `employee_reinstated` | `active` | বাঁধা হয়নি | Manufacturing | **নতুন** |
| 13 | `rpc_register_device` | Auth | নিজে | S | LT-Q | হ্যাঁ | `device_registered` | Device-নিবন্ধন | বাঁধা হয়নি | Foundation | **নতুন** |
| 14 | `rpc_revoke_device` | Auth | `iam.user.create`/নিজে | O/S | LT-I | হ্যাঁ | `device_revoked` | — | বাঁধা হয়নি | Production Gate | **নতুন** |
| 15 | `svc_revoke_sessions` | Auth | Class-S Worker | O | LT-W | হ্যাঁ | `sessions_revoked` | Supabase Sign-out (Outbox-চালিত) | বাঁধা হয়নি | Foundation | **নতুন** |
| 16 | `rpc_create_organization` | Org | Chairman (aal2) | G | LT-O | হ্যাঁ | `org_created` | → `provisioning` | T101 | Production Gate | Inventory |
| 17 | `rpc_activate_organization` | Org | প্রথম MD | O | LT-O | হ্যাঁ | `org_activated` | → `active` | বাঁধা হয়নি | Production Gate | Inventory |
| 18 | `rpc_activate_self` | Org | আমন্ত্রিত MD (aal2) | O | LT-O | হ্যাঁ | `md_activated` | — | বাঁধা হয়নি | Production Gate | Inventory |
| 19 | `rpc_cancel_provisioning` | Org | Chairman | G | LT-O | হ্যাঁ | `org_cancelled` | → `cancelled` | বাঁধা হয়নি | Production Gate | Inventory |
| 20 | `rpc_replace_first_md_invitation` | Org | Chairman | G | LT-O | হ্যাঁ | `invitation_replaced` | — | বাঁধা হয়নি | Production Gate | Inventory |
| 21 | `rpc_suspend_organization` | Org | Chairman (aal2) | G | LT-O | হ্যাঁ | `org_suspending` | `active`→`suspending` (ধাপ ১) | বাঁধা হয়নি | Production Gate | Inventory |
| 22 | `svc_suspension_worker` | Org | Class-S Worker | O | LT-W | হ্যাঁ | `org_suspended` | `suspending`→`suspended` (ধাপ ২ Drain) | বাঁধা হয়নি | Production Gate | **নতুন** |
| 23 | `rpc_unsuspend_organization` | Org | Chairman (aal2) | G | LT-O | হ্যাঁ | `org_unsuspended` | → `active` | বাঁধা হয়নি | Production Gate | Inventory |
| 24 | `rpc_create_approval_rule_version` | Approval | `approval.rule.manage` (aal2) | O | LT-I | হ্যাঁ | `rule_version_created` | `draft` | বাঁধা হয়নি | First Vertical Slice | Inventory |
| 25 | `rpc_publish_approval_rule_version` | Approval | `approval.rule.manage` (aal2) | O | LT-I | হ্যাঁ | `rule_version_published` | `active` (পুরোনোটি `retired`) | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 26 | `rpc_create_draft` | Txn | `txn.create` | O/W | LT-D | হ্যাঁ | `txn_created` | → `draft` | বাঁধা হয়নি | First Vertical Slice | Inventory |
| 27 | `rpc_update_draft` | Txn | `txn.create` (নিজের) | O/W | LT-D | হ্যাঁ | `txn_updated` | নতুন Version | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 28 | `rpc_delete_draft` | Txn | নিজের Draft | O/W | LT-D | হ্যাঁ | `draft_deleted` | আর্কাইভে কপি | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 29 | `rpc_submit` | Txn | `txn.submit` | O/W | LT-S | হ্যাঁ | `txn_submitted` | `draft`→`submitted`→`pending`; `txn_date`/Rule-Version Freeze | বাঁধা হয়নি | First Vertical Slice | Inventory |
| 30 | `rpc_approve` | Approval | `approval.approve` (Snapshot-সদস্য) | O/W | LT-A | হ্যাঁ | `approved/rejected` | `pending`→`approved`/`rejected` | T01, T103 | First Vertical Slice | Inventory |
| 31 | `rpc_return` | Approval | `approval.approve` | O/W | LT-A | হ্যাঁ | `txn_returned` | → `returned` | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 32 | `rpc_reassign_approver` | Approval | `approval.reassign` (MC) | O | LT-A | হ্যাঁ | `approver_reassigned` | ধাপ-Approver বদল | বাঁধা হয়নি | First Vertical Slice | Inventory |
| 33 | `rpc_post` | Txn | `txn.post` | O/W | LT-P | হ্যাঁ | `txn_posted` | `approved`→`posted`; Ledger-সারি; নম্বর | T50 | First Vertical Slice | Inventory |
| 34 | `rpc_get_transaction` | Txn | `txn.view` | Scope | LT-R | — | `—` | Detail (Mask-সম্মত) | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 35 | `rpc_list_transactions` | Txn | `txn.view` | Scope | LT-R | — | `—` | তালিকা, পৃষ্ঠা-ভাগ | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 36 | `rpc_get_pending_approvals` | Approval | `approval.view` | Scope | LT-R | — | `—` | আমার অপেক্ষমাণ ধাপ | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 37 | `rpc_request_correction` | Correction | `txn.correct.request` | O/W | LT-C | হ্যাঁ | `correction_requested` | `open` | বাঁধা হয়নি | First Vertical Slice | Inventory |
| 38 | `rpc_approve_correction` | Correction | `correction.approve` | O | LT-C | হ্যাঁ | `correction_approved` | `approved` | বাঁধা হয়নি | First Vertical Slice | **নতুন** (বা `rpc_approve`-ধরন) |
| 39 | `fn_execute_correction` | Correction | ভেতরের (System-পথ) | — | LT-C | হ্যাঁ | `reversal_posted` | Reversal Posted; `reversed` | বাঁধা হয়নি | First Vertical Slice | Inventory |
| 40 | `rpc_create_replacement_draft` | Correction | `txn.create` | O/W | LT-C | হ্যাঁ | `replacement_drafted` | Replacement Draft (আলাদা অনুমোদন) | T90 | First Vertical Slice | Inventory |
| 41 | `rpc_close_correction_without_replacement` | Correction | অনুমোদনসহ | O | LT-C | হ্যাঁ | `correction_abandoned` | `abandoned` | বাঁধা হয়নি | First Vertical Slice | Inventory |
| 42 | `rpc_create_fiscal_year` | Period | `fin.period.close`-শ্রেণি (প্রস্তাব) | O | LT-Y | হ্যাঁ | `fiscal_year_created` | বর্ষ ও Period-সংজ্ঞা | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 43 | `rpc_close_period` | Period | `fin.period.close` (aal2) | O | LT-Y | হ্যাঁ | `period_closed` | `open`→`closed`; Blocker-যাচাই | বাঁধা হয়নি | Production Gate | **নতুন** |
| 44 | `rpc_reopen_period` | Period | `fin.period.reopen` (aal2; #৬১) | O | LT-Y | হ্যাঁ | `period_reopened` | — | বাঁধা হয়নি | Production Gate | **নতুন** |
| 45 | `rpc_create_account` | Finance | `fin.cash.view`-উচ্চ (প্রস্তাব: Finance-প্রধান) | O | LT-I | হ্যাঁ | `account_created` | Slice-০ Chart | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 46 | `rpc_get_ledger` | Finance | `fin.cash.view` | Scope | LT-R | — | `—` | Account-Ledger | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 47 | `rpc_get_trial_balance` | Finance | `fin.report.view` | Scope | LT-R | — | `—` | Trial Balance | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 48 | `rpc_get_cash_book` | Finance | `fin.cash.view` | Scope | LT-R | — | `—` | Cash Book | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 49 | `rpc_verify_audit` | Audit | `audit.verify` | O/G | LT-R | — | `audit_verified` | যাচাই-ফল | T32 | Production Gate | Inventory |
| 50 | `rpc_get_audit_trail` | Audit | `audit.view` | O/G | LT-R | — | `—` | Audit-তালিকা (Mask) | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 51 | `rpc_confirm_external_checkpoint` | Audit | Auditor/MD | O/G | LT-I | হ্যাঁ | `checkpoint_confirmed` | — | বাঁধা হয়নি | Production Gate | Inventory |
| 52 | `svc_seal_audit` | Audit | Class-S | O/G | LT-W | হ্যাঁ | `audit_sealed` | Seal (xmin-Watermark) | বাঁধা হয়নি | Production Gate | **নতুন** |
| 53 | `rpc_register_document` | Documents | নিজের Scope | O | LT-Q | হ্যাঁ | `document_registered` | — | বাঁধা হয়নি | Later Wing | Inventory |
| 54 | `rpc_link_document` | Documents | নিজের Scope | O | LT-Q | হ্যাঁ | `document_linked` | Append-only | বাঁধা হয়নি | Later Wing | Inventory |
| 55 | `rpc_get_document_url` | Documents | Scope | O | LT-R | — | `document_url_issued` | ছোট-মেয়াদি Signed URL (ইস্যু-লগ) | বাঁধা হয়নি | Later Wing | **নতুন** |
| 56 | `rpc_declare_break_glass` | Emergency | `break_glass.declare` (দ্বৈত) | O | LT-I | হ্যাঁ | `break_glass_declared` | সময়-বদ্ধ Authority | T46 | Production Gate | Inventory |
| 57 | `rpc_group_override` | Group | Chairman (aal2) | G | LT-O | হ্যাঁ | `group_override` | Group-পথ | বাঁধা হয়নি | Production Gate | Inventory (পুরোনো `rpc_chairman_override` অচল) |
| 58 | `svc_process_outbox` | Outbox | Class-S | O | LT-W | হ্যাঁ | `—` | Notification/Worker | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 59 | `rpc_list_notifications` | Notify | নিজে | S | LT-R | — | `—` | — | বাঁধা হয়নি | Later Wing | **নতুন** |
| 60 | `rpc_mark_notification_read` | Notify | নিজে | S | LT-Q | হ্যাঁ | `—` | — | বাঁধা হয়নি | Later Wing | **নতুন** |
| 61 | `rpc_register_fcm_token` | Notify | নিজে | S | LT-Q | হ্যাঁ | `—` | Termination-এ revoked | বাঁধা হয়নি | Later Wing | **নতুন** |
| 62 | `rpc_handover_initiate` | Succession | `hr.assignment.manage` | O | LT-H | হ্যাঁ | `handover_initiated` | `initiated` | বাঁধা হয়নি | Manufacturing | **নতুন** |
| 63 | `rpc_handover_prepare_snapshot` | Succession | সিস্টেম/Finance/Store | O | LT-H | হ্যাঁ | `snapshot_prepared` | Snapshot Rev ১; `handover_freeze` | বাঁধা হয়নি | Manufacturing | **নতুন** |
| 64 | `rpc_handover_record_count` | Succession | পুরোনো+নতুন+সাক্ষী | O | LT-H | হ্যাঁ | `count_recorded` | `verifying` | বাঁধা হয়নি | Manufacturing | **নতুন** |
| 65 | `rpc_handover_record_variance` | Succession | সিস্টেম | O | LT-H | হ্যাঁ | `variance_recorded` | Variance Case খোলা; Snapshot আচ্ছাদিত | বাঁধা হয়নি | Manufacturing | **নতুন** |
| 66 | `rpc_handover_approve` | Succession | `hr.handover.approve` (aal2) | O | LT-H | হ্যাঁ | `handover_approved` | `approval`→ | বাঁধা হয়নি | Manufacturing | **নতুন** |
| 67 | `rpc_handover_activate` | Succession | সিস্টেম/Scheduler | O | LT-H | হ্যাঁ | `handover_effective` | **Atomic Switch** + Snapshot-বৈধতা-পুনর্যাচাই | বাঁধা হয়নি | Manufacturing | **নতুন** |
| 68 | `rpc_handover_close` | Succession | Approver | O | LT-H | হ্যাঁ | `handover_closed` | `closed` | বাঁধা হয়নি | Manufacturing | **নতুন** |
| 69 | `rpc_handover_cancel_or_pause` | Succession | Authority | O | LT-H | হ্যাঁ | `handover_paused` | Freeze মুক্ত | বাঁধা হয়নি | Manufacturing | **নতুন** |
| 70 | `rpc_variance_assign_investigator` | Succession | MD | O | LT-Q | হ্যাঁ | `investigator_assigned` | স্বাধীনতা-Check | বাঁধা হয়নি | Manufacturing | **নতুন** |
| 71 | `rpc_variance_propose_resolution` | Succession | তদন্তকারী | O | LT-Q | হ্যাঁ | `resolution_proposed` | — | বাঁধা হয়নি | Manufacturing | **নতুন** |
| 72 | `rpc_variance_approve_resolution` | Succession | `variance.resolve.approve` | O | LT-Q | হ্যাঁ | `resolution_approved` | — | বাঁধা হয়নি | Manufacturing | **নতুন** |
| 73 | `rpc_variance_execute_resolution` | Succession | Poster | O | LT-C | হ্যাঁ | `resolution_executed` | Correction-পথে Post; `V_open` হালনাগাদ | বাঁধা হয়নি | Manufacturing | **নতুন** |
| 74 | `rpc_set_recovery_authorized` | Succession | Authority + আইন-সূত্র | O | LT-Q | হ্যাঁ | `recovery_authorized` | Liability Gate মুক্ত | বাঁধা হয়নি | Manufacturing | **নতুন** |
| 75 | `api.v1_qr_issue` | QR | `qr.issue` | O | LT-Q | হ্যাঁ | `qr_issued` | একটি সক্রিয় প্রতি (entity, purpose) | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 76 | `api.v1_qr_resolve` | QR | লগইন + Scope | O | LT-R | `client_event_id` | `qr_scanned (Class-S লেখা)` | মাস্কড সারাংশ + Action | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 77 | `api.v1_qr_revoke` | QR | `qr.revoke` | O | LT-Q | হ্যাঁ | `qr_revoked` | `revoked` | বাঁধা হয়নি | Later Wing | **নতুন** |
| 78 | `api.v1_qr_replace` | QR | `qr.issue` | O | LT-Q | হ্যাঁ | `qr_replaced` | নতুন Token | বাঁধা হয়নি | Later Wing | **নতুন** |
| 79 | `api.v1_get_available_actions` | Action | লগইন | Scope | LT-R | — | `—` | অনুমোদিত ও প্রাসঙ্গিক Action | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 80 | `api.v1_create_export_snapshot` | Export | `export.*` | Scope | LT-R | `snapshot_ref` | `export_snapshot` | Mask-করা Payload | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 81 | `api.v1_confirm_export_share` | Export | `export.share` | Scope | LT-R | হ্যাঁ | `—` | পুনঃ-Authorization | বাঁধা হয়নি | First Vertical Slice | **নতুন** |
| 82 | `api.v1_record_export_event` | Export | নিজে | O | LT-W | `client_event_id` | `export_event` | Class-S | বাঁধা হয়নি | Later Wing | **নতুন** |
| 83 | `api.v1_get_contact_channels` | Contact | `contact.view` | Scope | LT-R | — | `—` | Visibility-ফিল্টার | বাঁধা হয়নি | Later Wing | **নতুন** |
| 84 | `api.v1_upsert_contact_channel` | Contact | `contact.edit` | Scope | LT-Q | হ্যাঁ | `contact_edited` | — | বাঁধা হয়নি | Later Wing | **নতুন** |
| 85 | `api.v1_register_print_device` | Export | নিজে | S | LT-Q | হ্যাঁ | `—` | — | বাঁধা হয়নি | Later Wing | **নতুন** |
| 86 | `api.v1_record_attendance_scan` | Attendance | নিবন্ধিত Kiosk | O | LT-Q | `client_event_id` | `attendance_recorded` | accepted/flagged/rejected | বাঁধা হয়নি | Later Wing | **নতুন** |
| 87 | `rpc_record_manual_attendance` | Attendance | `hr.attendance.manual` (MC) | O | LT-Q | হ্যাঁ | `attendance_manual` | কারণ; নিজের নয় | বাঁধা হয়নি | Later Wing | **নতুন** |

## Error-কোড-ক্যাটালগ (প্রস্তাব; G৬)

| কোড | অর্থ | Client-আচরণ |
| --- | --- | --- |
| `E_AUTH` | Authority/Session অবৈধ | লগইন-পুনরায় |
| `E_PERM` | Permission নেই | বার্তা; Retry নয় |
| `E_SCOPE` | Scope-বহির্ভূত | বার্তা |
| `E_MFA` | `aal2` দরকার | Step-up |
| `E_STATE` | অবস্থা অনুপযুক্ত (Gate, লেনদেন, Container) | রিফ্রেশ |
| `E_STALE` | পরিবর্তনশীল Client-ID Lock-পরে অমিল | রিফ্রেশ ও পুনরায় |
| `E_SELF_APPROVAL` | নিজের অনুমোদন | বার্তা |
| `E_PERIOD_CLOSED` / `E_PERIOD_ORDER` | Period বন্ধ/ক্রম-লঙ্ঘন | বার্তা |
| `E_CONFLICT` | Idempotency-Key ভিন্ন Payload-এ | নতুন Key |
| `E_LOCK_TIMEOUT` | Lock-অপেক্ষা-সীমা | একই Key-তে Retry |
| `E_RATE` | Rate-Limit | বিলম্বে Retry |
| `E_VALIDATION` | ইনপুট অবৈধ | ক্ষেত্র-ভিত্তিক বার্তা |
## First-Slice ৩১টি RPC: Contract, Test-বন্ধন ও প্রস্তুতি (২০২৬-১১-০৪)

**সংজ্ঞা — Implementation-ready:** (১) Contract সম্পূর্ণ (Input, Output, Validation, Error, Audit); (২) নির্ভরশীল সব সারণি Migration-এ **লেখা**; (৩) ≥ ১টি Test বাঁধা; (৪) কোনো অমীমাংসিত ব্লকিং সিদ্ধান্ত নেই। **ঠিক “*” চিহ্ন:** #১৫ নম্বর-ধরন, #২১ আলাদা Post-ধাপ, #২২ Backdate-সীমা, #৩৭ Reversal-তারিখ এখনো **Owner-অনুমোদিত নয়**; কোড এগুলো **Setting-চালিত, Proposed-ডিফল্টসহ** লিখবে। “Implementation-ready” ≠ Implemented ≠ Tested।

**ফল: ৩১-এর মধ্যে 25 Implementation-ready (তার মধ্যে ১টি SQL-এ লেখা), 6 Not ready।** SQL-এ লেখা 1; **চালানো ০; Test-পাস ০।** Test-বন্ধন (স্বয়ংক্রিয় এলাকা-মিল + স্পষ্ট ID) পর্যালোচনা-সাপেক্ষ।

| # | RPC | Input | Output | Validation/Authorization | Error | Audit | Test | নির্ভরতা (সারণি) | প্রস্তুতি |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | `rpc_get_my_permissions` | — | {employee_id, organization_id, roles[], permissions[{code,scope}]} বা {error:E_AUTH} | লগইন + সক্রিয় Session/Account/Employee/Company | E_AUTH | `—` | T24, T41, T04, T65, T35, T311–T315 | roles, role_permissions, user_roles, employee_accounts | **SQL-এ লেখা** (০০০৯); চালানো হয়নি |
| 2 | `rpc_create_approval_rule_version` | transaction_type_id, wing_id?, steps[{no,mode,count,role}], reason, key | rule_version_id (`draft`) | `approval.rule.manage`, aal2; role_code বৈধ | E_PERM, E_MFA, E_VALIDATION | `rule_version_created` | T27, T44, T67, T71 | approval_rules/versions/steps, roles | Implementation-ready |
| 3 | `rpc_publish_approval_rule_version` | rule_version_id, key | `active` (পুরোনো `retired`) | `approval.rule.manage`, aal2; প্রতি Rule-এ একটিই active | E_PERM, E_STATE | `rule_version_published` | T27, T44, T67, T71 | approval_rules/versions | Implementation-ready |
| 4 | `rpc_create_draft` | type_code, wing_id, txn_date, voucher{kind,cash_account,counter_account,amount,narration}, key | txn_id (`draft`, version 1) | `txn.create`; Wing/Account একই কোম্পানির (Composite FK); amount > 0; তারিখ #22 নীতি | E_PERM, E_SCOPE, E_VALIDATION, E_PERIOD_CLOSED | `txn_created` | T57, T58, T76, T88, T66, T298; কোম্পানি-বিচ্ছিন্নতা: T36, T94, T95, T303–T307 | transaction_types/registry/versions, cash_vouchers, accounts, idempotency | Implementation-ready* |
| 5 | `rpc_update_draft` | txn_id, expected_version, ফিল্ড, key | নতুন version | নিজের Draft/Returned; `E_STALE` যদি Version অমিল | E_STATE, E_STALE | `txn_updated` | T57, T58, T76, T88, T66, T298 | registry/versions | Implementation-ready |
| 6 | `rpc_delete_draft` | txn_id, key | archived | নিজের Draft | E_STATE | `draft_deleted` | T57, T58, T76, T88, T66, T298 | registry, deleted_drafts_archive | Implementation-ready |
| 7 | `rpc_submit` | txn_id, expected_version, key | status `pending`; request_id; Rule-Version বাঁধা | `txn.submit`; Maker=Creator; Rule আছে; Period-আগাম-সতর্কতা | E_STATE, E_PERM, E_NO_RULE | `txn_submitted` | T66, T01, T20, T57, T58 | registry, approval_* , rules | Implementation-ready |
| 8 | `rpc_approve` | request_step_id, decision(approve/reject), reason?, key | step/request অবস্থা | `approval.approve`; Snapshot-সদস্য; **Maker ≠ Approver** (RPC + Trigger) | E_SELF_APPROVAL, E_PERM, E_STATE, E_MFA | `approved/rejected` | T01, T20, T27, T44, T06 | approval_actions/steps/requests | Implementation-ready |
| 9 | `rpc_return` | request_step_id, reason, key | `returned` | `approval.approve` | E_STATE | `txn_returned` | T01, T20, T27, T44, T06 | approval_* | Implementation-ready |
| 10 | `rpc_reassign_approver` | request_step_id, new_approver, key | eligible_snapshot হালনাগাদ | `approval.reassign` (Maker-Checker); নতুন Approver ≠ Maker | E_PERM, E_SELF_APPROVAL | `approver_reassigned` | T01, T20, T27, T44, T06 | approval_request_steps | Implementation-ready |
| 11 | `rpc_post` | txn_id, key | `posted`, txn_no, ledger_entry_ids | `txn.post`; Approved; Period খোলা; সক্রিয় Account; ভারসাম্য; **একক Posting-পথ** | E_PERM, E_STATE, E_PERIOD_CLOSED, E_UNBALANCED, E_POSTING_PATH | `txn_posted` | T57, T58, T26, T51, T91, T291, T295, T296, T297, T13, T15; কোম্পানি-বিচ্ছিন্নতা: T36, T94, T95, T303–T307 | ledger_entries, account_balances, periods, sequences, accounts | Implementation-ready* |
| 12 | `rpc_get_transaction` | txn_id | Detail (Mask-সম্মত) | `txn.view` + Scope | E_SCOPE | `—` | T36, T94 | registry/versions | Implementation-ready |
| 13 | `rpc_list_transactions` | filters, page | তালিকা | `txn.view` | E_SCOPE | `—` | T36, T94 | registry | Implementation-ready |
| 14 | `rpc_get_pending_approvals` | page | আমার অপেক্ষমাণ ধাপ | `approval.view` | E_PERM | `—` | T01, T20, T27, T44, T06 | approval_request_steps | Implementation-ready |
| 15 | `rpc_request_correction` | txn_id, reason, key | correction_id (`open`) | `txn.correct.request`; txn `posted`; একটিই চলমান | E_STATE, E_CONFLICT | `correction_requested` | T28, T29, T50, T53, T56, T62, T118, T292 | corrections | Implementation-ready |
| 16 | `rpc_approve_correction` | correction_id, key | `approved` | `correction.approve` (≠ Requester) | E_SELF_APPROVAL, E_PERM | `correction_approved` | T28, T29, T50, T53, T56, T62, T118, T292 | corrections, approval_* | Implementation-ready |
| 17 | `fn_execute_correction` | correction_id | Reversal Posted; `reversed` | ভেতরের; Reversal-তারিখ = আজকের খোলা Period (#৩৭ প্রস্তাব) | E_PERIOD_CLOSED | `reversal_posted` | T28, T29, T50, T53, T56, T62, T118, T292 | corrections, ledger, links | Implementation-ready* |
| 18 | `rpc_create_replacement_draft` | correction_id, key | Replacement Draft (আলাদা অনুমোদন, F৪) | `txn.create`; `reversed` Correction | E_STATE | `replacement_drafted` | T28, T29, T50, T53, T56, T62, T118, T292 | corrections, registry | Implementation-ready |
| 19 | `rpc_close_correction_without_replacement` | correction_id, reason, key | `abandoned` | অনুমোদনসহ | E_STATE | `correction_abandoned` | T28, T29, T50, T53, T56, T62, T118, T292 | corrections | Implementation-ready |
| 20 | `rpc_create_fiscal_year` | name, start, end, periods[], key | fiscal_year_id | `fin.period.close`-শ্রেণি (প্রস্তাব: FIN_MANAGER/MD); অধিক্রমণ নেই | E_PERM, E_PERIOD_ORDER | `fiscal_year_created` | T91, T297 | fiscal_years, accounting_periods | Implementation-ready |
| 21 | `rpc_create_account` | code, name_bn, type, parent?, is_cash, key | account_id | FIN_MANAGER/MD; কোম্পানি-ভিত্তিক Code অনন্য | E_PERM, E_CONFLICT | `account_created` | T36, T94, T303–T307 | accounts | Implementation-ready |
| 22 | `rpc_get_ledger` | account_id, range, page | Ledger-সারি + চলমান Balance | `fin.cash.view` | E_SCOPE | `—` | T293, T294 | ledger_entries | Implementation-ready |
| 23 | `rpc_get_trial_balance` | period_id | অ্যাকাউন্ট-ভিত্তিক ডেবিট/ক্রেডিট | `fin.report.view` | E_PERM | `—` | T293, T294 | ledger, accounts | Implementation-ready |
| 24 | `rpc_get_cash_book` | cash_account_id, range | Cash Book | `fin.cash.view` | E_SCOPE | `—` | T293, T294 | ledger | Implementation-ready |
| 25 | `rpc_get_audit_trail` | entity_ref | range | Audit-তালিকা (Mask) | `audit.view` | E_PERM | `—` | T30, T31, T32, T33, T316–T319 | audit_logs | Implementation-ready |
| 26 | `svc_process_outbox` | (Worker) | — | Class-S Allowlist | — | `—` | Test এখনো বাঁধা নয় | `outbox_events` (Migration-এ **নেই**) | **Not ready:** সারণি অলিখিত |
| 27 | `api.v1_qr_issue` | entity_ref, purpose | token, print_check_code | `qr.issue` | E_PERM | `qr_issued` | T241, T242, T246, T256 | `qr_codes` (Migration-এ **নেই**) | **Not ready:** সারণি অলিখিত |
| 28 | `api.v1_qr_resolve` | token, context | মাস্কড সারাংশ + Action | লগইন + Scope | — | `qr_scanned` | T242, T243, T245, T247, T248 | `qr_codes`, `qr_scan_events` | **Not ready:** সারণি অলিখিত |
| 29 | `api.v1_get_available_actions` | entity_ref, context | Action-তালিকা | লগইন | — | `—` | T265–T268 | `action_registry` | **Not ready:** সারণি অলিখিত |
| 30 | `api.v1_create_export_snapshot` | entity_ref, mask_profile, purpose | Mask-করা Payload | `export.*` | E_PERM | `export_snapshot` | T273, T277, T278 | `export_snapshots` | **Not ready:** সারণি অলিখিত |
| 31 | `api.v1_confirm_export_share` | snapshot_ref | ok/E_* | `export.share` | E_AUTH | `—` | T279 | `export_snapshots` | **Not ready:** সারণি অলিখিত |