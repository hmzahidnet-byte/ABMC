# Appendix A — Column Dictionary (Part 1 Core Spec, v0.2.1–v0.2.2 যুগের Base; স্বয়ংক্রিয়ভাবে Transcript থেকে নেওয়া, শব্দে শব্দে)

> **সতর্কতা:** এটি Baseline-এর **Base**; v0.2.2–v0.2.9-এর পরিবর্তন Appendix B (Delta Register)-এ। কোড/DDL লেখার আগে A+B একত্র করে যাচাই করতে হবে। কোনো Test চালানো হয়নি।


### `core.approval_actions` [A]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `request_id` | uuid | NN | FK→approval_requests | |
| `step_no` | int | NN | | |
| `approver_id` | uuid | NN | FK→employees | যিনি আসলে কাজ করলেন |
| `acting_for_id` | uuid | | FK→employees | Delegation-এ যাঁর হয়ে |
| `delegation_id` | uuid | | FK→approval_delegations | |
| `action` | text | NN | CHECK `approve`/`reject`/`return`/`override_approve`/`override_reject`/`override_move` | |
| `reason` | text | | CHECK `action = 'approve'` অথবা NN | Reject/Return/Override-এ কারণ বাধ্যতামূলক (**Final**) |
| `txn_version` | int | NN | | Request-এর `txn_version`-এর সমান |
| `override_rule_version_id` | uuid | | FK→approval_rule_versions | `override_move`-এ নতুন Rule |
| `session_ref` | uuid | | | Auth Session ID |

সীমা: UK (`request_id`, `step_no`, `approver_id`)। Constraint Trigger: `approver_id` এবং `acting_for_id` কোনোটিই লেনদেনের `submitted_by` বা `created_by` হতে পারবে না (Self-approval নিষিদ্ধ, **Final**)।


### `core.approval_delegations` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `delegator_id` | uuid | NN | FK→employees | |
| `delegate_id` | uuid | NN | FK→employees | CHECK `delegator_id <> delegate_id` |
| `scope_type`, `scope_id` | text, uuid | | CHECK `organization`/`wing`/`department` | সীমা না দিলে Delegator-এর নিজের Scope |
| `transaction_type_id` | uuid | | FK→transaction_types | নির্দিষ্ট ধরনেই সীমিত করতে |
| `amount_limit` | numeric(18,2) | | | |
| `effective_from`, `effective_to` | timestamptz | NN | CHECK `effective_to > effective_from` | মেয়াদ বাধ্যতামূলক (**Final**) |
| `reason` | text | NN | | |
| `status` | text | NN | CHECK `active`/`revoked`/`expired` | |
| `approved_by` | uuid | NN | FK→employees | Chairman বা MD |

Delegation Delegator-এর নিজের ক্ষমতার বেশি হতে পারে না (No-escalation)।


### `core.approval_request_steps` [S]
PK = (`request_id`, `step_no`)।

| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `request_id` | uuid | NN | FK→approval_requests | |
| `step_no` | int | NN | | |
| `mode`, `required_count` | text, int | NN | Rule-এর কপি | |
| `approved_count` | int | NN | default 0, CHECK ≤ `required_count` | |
| `status` | text | NN | CHECK `waiting`/`active`/`done`/`skipped` | |
| `eligible_approver_ids` | uuid[] | NN | | ধাপ সক্রিয় হওয়ার মুহূর্তের Snapshot (**Pending #৩৫**) |
| `activated_at`, `completed_at` | timestamptz | | | |


### `core.approval_requests` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `txn_id` | uuid | NN | FK→transaction_registry | |
| `txn_version` | int | NN | | Submit-এর সময়ের Version |
| `rule_version_id` | uuid | NN | FK→approval_rule_versions | Submit-এর সময় বাঁধা (**Pending #১১**-এর প্রস্তাব) |
| `amount_snapshot` | numeric(18,2) | | | Band বাছার টাকা |
| `status` | text | NN | CHECK `pending`/`approved`/`rejected`/`returned`/`cancelled`/`recalled`/`superseded` | |
| `current_step_no` | int | | | |
| `submitted_by` | uuid | NN | FK→employees | |
| `submitted_at` | timestamptz | NN | default `now()` | |
| `completed_at` | timestamptz | | | |
| `superseded_by_id` | uuid | | FK→approval_requests | Chairman নতুন Rule-এ সরালে |
| `is_override` | boolean | NN | default false | |

সীমা: UK (`txn_id`, `txn_version`); UK (`txn_id`) যেখানে `status = 'pending'` (এক লেনদেনে একটিই চালু Request)।


### `core.approval_rule_steps` [A]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `rule_version_id` | uuid | NN | FK→approval_rule_versions | |
| `step_no` | int | NN | CHECK ≥ 1 | |
| `amount_from` | numeric(18,2) | NN | default 0 | |
| `amount_to` | numeric(18,2) | | CHECK ফাঁকা বা > `amount_from` | ফাঁকা = সীমাহীন |
| `approver_type` | text | NN | CHECK `position`/`role`/`employee`/`reporting_manager`/`md_final` | |
| `approver_ref` | uuid | | | Position/Role/Employee-এর `id`; `reporting_manager` ও `md_final`-এ ফাঁকা |
| `approver_scope` | text | NN | CHECK `own_wing`/`own_department`/`any`, default `own_wing` | |
| `mode` | text | NN | CHECK `any_one`/`all`/`n_of_m`, default `any_one` | |
| `required_count` | int | NN | CHECK ≥ 1, default 1 | `n_of_m`-এ N |

সীমা: UK (`rule_version_id`, `amount_from`, `step_no`); একই `step_no`-তে টাকার পরিসর ওভারল্যাপ নিষিদ্ধ। প্রকাশের সময় RPC যাচাই করে পরিসরগুলো ০ থেকে সীমাহীন পর্যন্ত ফাঁকহীন।


### `core.approval_rule_versions` [S]
সক্রিয় হওয়ার পর শুধু `status` ও `effective_to` বদলায় (Trigger)।

| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `rule_id` | uuid | NN | FK→approval_rules | |
| `version_no` | int | NN | UK (`rule_id`, `version_no`) | |
| `status` | text | NN | CHECK `draft`/`active`/`retired` | প্রতি Rule-এ একটিই `active` |
| `effective_from` | timestamptz | NN | CHECK ≥ তৈরির সময় | অতীত-প্রভাবী নয় |
| `effective_to` | timestamptz | | | |
| `change_reason` | text | NN | | |


### `core.approval_rules` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `transaction_type_id` | uuid | NN | FK→transaction_types | |
| `wing_id` | uuid | | FK→wings | ফাঁকা = সব Wing-এর জন্য সাধারণ Rule |
| `name` | text | NN | | |
| `status` | text | NN | CHECK `active`/`inactive` | |
| `current_version_id` | uuid | | FK→approval_rule_versions (deferrable) | |

সীমা: একই (`transaction_type_id`, `wing_id`)-এ একটিই `active` Rule (`wing_id` ফাঁকা ধরে আলাদা গণনা)। Wing-নির্দিষ্ট Rule সাধারণটির ওপর অগ্রাধিকার পায়।


### `core.audit_logs` [A]
`occurred_at` ধরে মাসিক Range Partition। লেখা হয় শুধু `core.fn_write_audit()` দিয়ে (ক্লায়েন্টের `EXECUTE` নেই), এবং মূল কাজের **একই Transaction-এ**; তাই কাজ Rollback হলে তার Audit সারিও যায়। ব্যর্থ চেষ্টার রেকর্ড যায় `security_events`-এ।

| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `id` | bigint identity | NN | PK | |
| `occurred_at` | timestamptz | NN | default `now()` | Partition Key |
| `actor_user_id` | uuid | | | Auth UID; ফাঁকা = সিস্টেম Job |
| `actor_employee_id` | uuid | | FK→employees | |
| `wing_id`, `department_id` | uuid | | FK | Scope-ভিত্তিক পড়ার জন্য |
| `module` | text | NN | | |
| `record_table`, `record_id` | text | NN | | |
| `action` | text | NN | | |
| `old_value`, `new_value` | jsonb | | | |
| `reason` | text | | | Critical Action-এ NN (RPC বাধ্য করে) |
| `approval_request_id` | uuid | | FK→approval_requests | |
| `txn_id` | uuid | | FK→transaction_registry | |
| `session_ref` | uuid | | | |
| `request_id` | text | | | এক অনুরোধের সব সারি জোড়ার সূত্র |
| `is_override` | boolean | NN | default false | Chairman Override চিহ্নিত |
| `row_hash` | text | NN | | সব ক্ষেত্রের Canonical SHA-256 |


### `core.audit_seals` [A]
v0.2.1-এ প্রতিটি সারিতে `prev_hash` রাখার কথা ছিল; কিন্তু সব Critical লেনদেন একটি Chain-এর মাথায় লাইনে দাঁড়ালে Throughput থেমে যায়। তাই এখন সারি আলাদা Hash করে, আর পর্যায়ক্রমে একটি **Seal Job** ব্যাচ ধরে Chain বানায়। **Proposed।**

| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `id` | bigint identity | NN | PK | |
| `from_audit_id`, `to_audit_id` | bigint | NN | CHECK `to >= from` | |
| `row_count` | int | NN | | |
| `batch_hash` | text | NN | | ক্রমানুসারে `row_hash`-গুলোর Hash |
| `prev_seal_hash` | text | NN | | প্রথমটিতে নির্দিষ্ট প্রারম্ভিক মান |
| `seal_hash` | text | NN | UK | `batch_hash`, `prev_seal_hash`, পরিসর ও `sealed_at`-এর Hash |
| `sealed_at` | timestamptz | NN | | |
| `external_ref` | text | | | বাইরের Checkpoint-এর পরিচয় (**Pending #২৯**) |
| `external_confirmed_at` | timestamptz | | | |

**Seal-এর সূক্ষ্মতা:** `bigint identity` মান ক্রমানুসারে Commit নাও হতে পারে; লম্বা Transaction-এর নিচু `id` পরে Commit হতে পারে। তাই Job শুধু `now() − নিরাপত্তা-বিরতি` আগের সারি Seal করে (বিরতি Database-এর `statement_timeout` ও `idle_in_transaction_session_timeout`-এর চেয়ে বেশি; মান **Pending #৩৬**) এবং পরিসরের সারির সংখ্যা মিলে না গেলে Seal পিছিয়ে দেয়।


### `core.corrections` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `correction_txn_id` | uuid | NN | UK, FK→transaction_registry | এই Correction-এর নিজস্ব লেনদেন/Approval |
| `correction_type` | text | NN | CHECK `financial`/`stock`/`attendance`/`other_data` | |
| `original_txn_id` | uuid | | FK→transaction_registry | সংশোধনের লক্ষ্য লেনদেন |
| `target_table`, `target_id` | text, uuid | | | লেনদেন নয় এমন লক্ষ্য (যেমন Attendance) |
| `status` | text | NN | CHECK `requested`/`approved`/`rejected`/`executed`/`cancelled` | |
| `reason` | text | NN | | **Final** |
| `evidence_document_id` | uuid | NN | | প্রমাণ বাধ্যতামূলক (**Final**); FK `documents` আসার পর |
| `proposed_changes` | jsonb | NN | | পুরোনো ও নতুন মান, অথবা Replacement-এর পূর্ণ বিবরণ |
| `reversal_txn_id` | uuid | | FK→transaction_registry | |
| `replacement_txn_id` | uuid | | FK→transaction_registry | |
| `executed_at`, `executed_by` | timestamptz, uuid | | | |

CHECK: `original_txn_id` অথবা (`target_table` + `target_id`), ঠিক একটি। সীমা: একই লক্ষ্যে একটিই খোলা Correction (UK যেখানে `status IN ('requested','approved')`)।


### `core.deleted_drafts_archive` [A]
Delete = লজিকাল (Registry সারিতে `deleted_at`), আর পূর্ণ কপি এখানে। এতে FK ও ইতিহাস অক্ষত থাকে। v0.2.1-এ “Delete” শব্দের অর্থ এটাই।

| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `txn_id` | uuid | NN | UK, FK→transaction_registry | |
| `deleted_by` | uuid | NN | FK→employees | |
| `reason` | text | NN | | |
| `full_snapshot` | jsonb | NN | | Header ও Line-সহ |
| `snapshot_hash` | text | NN | | |


### `core.departments` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `wing_id` | uuid | NN | FK→wings | |
| `parent_department_id` | uuid | | FK→departments | গাছ; চক্র Trigger-এ নিষিদ্ধ |
| `code` | text | NN | UK (`wing_id`, `code`) | |
| `name` | text | NN | | |
| `status` | text | NN | CHECK `active`/`inactive` | |


### `core.device_registry` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `device_id` | text | NN | UK | স্থিতিশীল Device পরিচয় |
| `device_type` | text | NN | CHECK `factory_scanner`/`staff_phone`/`tablet`/`other` | |
| `label` | text | NN | | |
| `wing_id` | uuid | NN | FK→wings | |
| `status` | text | NN | CHECK `pending`/`active`/`revoked`, default `pending` | |
| `registered_by`, `activated_by` | uuid | | FK→employees | নিবন্ধনকারী ও সক্রিয়কারী আলাদা |
| `activated_at`, `revoked_at` | timestamptz | | | |
| `revoked_by`, `revoke_reason` | uuid, text | | | |
| `public_key` | text | | | ঐচ্ছিক; স্বাক্ষরিত অনুরোধের জন্য |


### `core.document_sequences` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `wing_id` | uuid | NN | FK→wings | |
| `series_key` | text | NN | | |
| `fiscal_year` | int | NN | | Fiscal Period টেবিল (ভাগ ২) আসার পর সংজ্ঞা চূড়ান্ত |
| `prefix` | text | NN | | |
| `width` | int | NN | default 6 | |
| `mode` | text | NN | CHECK `unique_only`/`gapless`, default `unique_only` | **Pending #১৫** |
| `sequence_name` | text | | | `unique_only`-তে Postgres Sequence |
| `last_no` | bigint | NN | default 0 | `gapless`-এর Counter |

সীমা: UK (`wing_id`, `series_key`, `fiscal_year`)। ফরম্যাট: `{prefix}-{fiscal_year}-{সংখ্যা, width অনুযায়ী শূন্য-ভরা}`।

**নম্বর বসানো (`core.fn_assign_txn_no`):** Post-এর Transaction-এর ভেতরেই। `unique_only`: Sequence থেকে পরের মান, Lock নেই, তবে Rollback-এ ফাঁক পড়তে পারে। `gapless`: Counter সারি `FOR UPDATE` Lock করে বাড়ানো; Post শেষ না হওয়া পর্যন্ত সারিটি Lock থাকে, তাই একই Series-এ Post লাইনে দাঁড়ায়; Rollback হলে Counter-ও ফেরে, ফাঁক পড়ে না।


### `core.employee_accounts`
PK = `employee_id` (একজনের একটিই Login)।

| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `employee_id` | uuid | NN | PK, FK→employees | |
| `auth_user_id` | uuid | NN | UK, FK→`auth.users(id)` `ON DELETE RESTRICT` | Auth User কখনো মোছা হয় না |
| `account_status` | text | NN | CHECK `active`/`disabled`/`locked`, default `active` | |
| `mfa_required` | boolean | NN | default false | Chairman/MD-র জন্য true বাধ্যতামূলক |
| `linked_at` | timestamptz | NN | default `now()` | |
| `disabled_at`, `disabled_reason` | timestamptz, text | | | |
| `last_forced_signout_at` | timestamptz | | | |

নিয়ম: `resigned`/`terminated` Employee-র অ্যাকাউন্ট অবশ্যই `disabled` (RPC ও Trigger দুই স্তরে)।


### `core.employee_history` [A]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `employee_id` | uuid | NN | FK→employees | |
| `event_type` | text | NN | CHECK `joined`/`promotion`/`demotion`/`transfer`/`position_change`/`manager_change`/`suspension`/`reinstatement`/`resignation`/`termination` | |
| `effective_on` | date | NN | | |
| `old_position_id`, `new_position_id` | uuid | | FK→positions | |
| `old_department_id`, `new_department_id` | uuid | | FK→departments | |
| `old_manager_id`, `new_manager_id` | uuid | | FK→employees | |
| `salary_change_ref` | uuid | | | `hr`-এর বেতন-পরিবর্তন রেকর্ড (ভাগ ৩) |
| `reason` | text | NN | | |
| `approval_request_id` | uuid | | FK→approval_requests | Promotion/Demotion/Transfer/Termination-এ Approval Toggle চালু থাকলে NN (RPC যাচাই) |\\\"}}}]}\",
  \"ref\": {
    \"id\": \"f43012c9-1909\",
    \"object\": \"node\"
  }
}"
    },
    "approval_options": null,
    "approval_key": null,
    "approval_key_legacy": null,
    "is_mcp_app": false,
    "hidden_in_chat": false,
    "mcp_server_url": "https://api.anthropic.com/v1/pages/mcp"
  },
  {
    "start_timestamp": "2026-11-03T10:28:29.675675Z",
    "stop_timestamp": "2026-11-03T10:28:29.675748Z",
    "flags": null,
    "type": "tool_result",
    "tool_use_id": "toolu_01CrGWayDdBamPuwpkTYPSsq",
    "name": "Claude Docs:update",
    "content": [
      {
        "type": "text",
        "text": "{\"verdict\":\"allow\",\"rev\":3,\"session\":\"mysjbetn44p\",\"xml\":\"<doc op='0'><paragraph id='mysjbetn44p.2427' h='58348b63' heading='2'>২. Organiz…</paragraph><paragraph id='.2460' h='5b344707'><text id='.2461'>Employee P…</text><text id='.2586'><bold>Proposed।</bold></text></paragraph><paragraph id='.2595' h='3667221b' heading='3'><text id='.2596'><code>core.organ…</code></text><text id='.2614'> [S]</text></paragraph><table id='.2618' h='e08faed1'><gap blocks='4'/></table><paragraph id='.2763' h='864856a5' heading='3'><text id='.2764'><code>core.wings</code></text><text id='.2774'> [S]</text></paragraph><table id='.2778' h='682c0b30'><gap blocks='5'/></table><paragraph id='.2981' h='a6282b61' heading='3'><text id='.2982'><code>core.depar…</code></text><text id='.2998'> [S]</text></paragraph><table id='.3002' h='15bfc387'><gap blocks='6'/></table><paragraph id='.3251' h='731a47b5' heading='3'><text id='.3252'><code>core.positions</code></text><text id='.3266'> [S]</text></paragraph><table id='.3270' h='0157a200'><gap blocks='6'/></table><paragraph id='.3563' h='a5d22475' heading='3'><text id='.3564'><code>core.employees</code></text><text id='.3578'> [S]</text></paragraph><table id='.3582' h='dfbf339c'><gap blocks='10'/></table><paragraph id='.4126' h='cc58ba43'><text id='.4127'>এই টেবিলে </text><text id='.4137'><code>DELETE</code></text><text id='.4143'> Privilege…</text><text id='.4199'><code>hr.employe…</code></text><text id='.4218'>-এ (ভাগ ৩)।</text></paragraph><paragraph id='.4229' h='c716a53b' heading='3'><text id='.4230'><code>core.emplo…</code></text></paragraph><paragraph id='.4252' h='7b8aae80'><text id='.4253'>PK = </text><text id='.4258'><code>employee_id</code></text><text id='.4269'> (একজনের এ…</text></paragraph><table id='.4291' h='b2458841'><gap blocks='8'/></table><paragraph id='.4768' h='57318a49'><text id='.4769'>নিয়ম: </text><text id='.4776'><code>resigned</code></text><text id='.4784'>/</text><text id='.4785'><code>terminated</code></text><text id='.4795'> Employee-…</text><text id='.4825'><code>disabled</code></text><text id='.4833'> (RPC ও Tr…</text></paragraph><paragraph id='.4860' h='b3baa37f' heading='3'><text id='.4861'><code>core.emplo…</code></text><text id='.4884'> [S]</text></paragraph><table id='.4888' h='749ccc75'><gap blocks='8'/></table><paragraph id='.5238' h='059943f9'><text id='.5239'>সীমা: (</text><text id='.5246'><code>employee_id</code></text><text id='.5257'>, </text><text id='.5259'><code>position_id</code></text><text id='.5270'>) জুড়ে তা…</text><text id='.5368'><code>UK (employ…</code></text><text id='.5426'>)।</text></paragraph><paragraph id='.5428' h='484543de' heading='3'><text id='.5429'><code>core.repor…</code></text><text id='.5457'> [S]</text></paragraph><table id='.5461' h='8512409e'><gap blocks='5'/></table><paragraph id='.5698' h='4a8363e8'><text id='.5699'>সীমা: </text><text id='.5705'><code>employee_i…</code></text><text id='.5730'>; একজনের এ…</text><text id='.5750'><code>reports_to</code></text><text id='.5760'>; Trigger …</text></paragraph><paragraph id='.5807' h='a913ee1d' heading='3'><text id='.5808'><code>core.emplo…</code></text><text id='.5829'> [A]</text></paragraph><table id='.5833' h='06fc4838'><gap blocks='10'/></table></doc>\",\"data\":{\"notices\":[{\"code\":\"pending_ended\",\"ids\":[\"mysjbetn44p.328\"],\"as\":\"resolved\",\"opIndex\":0}]}}"
      }
    ],
    "is_error": false,
    "structured_content": null,
    "meta": {
      "authoredByOthers": false,
      "sharedOutsideOrg": false
    },
    "message": null,
    "integration_name": "Claude Docs",
    "mcp_server_url": "https://api.anthropic.com/v1/pages/mcp",
    "integration_icon_url": null,
    "icon_name": null,
    "display_content": {
      "type": "json_block",
      "json_block": "{
  \"verdict\": \"allow\",
  \"rev\": 3,
  \"session\": \"mysjbetn44p\",
  \"xml\": \"<doc op='0'><paragraph id='mysjbetn44p.2427' h='58348b63' heading='2'>২. Organiz…</paragraph><paragraph id='.2460' h='5b344707'><text id='.2461'>Employee P…</text><text id='.2586'><bold>Proposed।</bold></text></paragraph><paragraph id='.2595' h='3667221b' heading='3'><text id='.2596'><code>core.organ…</code></text><text id='.2614'> [S]</text></paragraph><table id='.2618' h='e08faed1'><gap blocks='4'/></table><paragraph id='.2763' h='864856a5' heading='3'><text id='.2764'><code>core.wings</code></text><text id='.2774'> [S]</text></paragraph><table id='.2778' h='682c0b30'><gap blocks='5'/></table><paragraph id='.2981' h='a6282b61' heading='3'><text id='.2982'><code>core.depar…</code></text><text id='.2998'> [S]</text></paragraph><table id='.3002' h='15bfc387'><gap blocks='6'/></table><paragraph id='.3251' h='731a47b5' heading='3'><text id='.3252'><code>core.positions</code></text><text id='.3266'> [S]</text></paragraph><table id='.3270' h='0157a200'><gap blocks='6'/></table><paragraph id='.3563' h='a5d22475' heading='3'><text id='.3564'><code>core.employees</code></text><text id='.3578'> [S]</text></paragraph><table id='.3582' h='dfbf339c'><gap blocks='10'/></table><paragraph id='.4126' h='cc58ba43'><text id='.4127'>এই টেবিলে </text><text id='.4137'><code>DELETE</code></text><text id='.4143'> Privilege…</text><text id='.4199'><code>hr.employe…</code></text><text id='.4218'>-এ (ভাগ ৩)।</text></paragraph><paragraph id='.4229' h='c716a53b' heading='3'><text id='.4230'><code>core.emplo…</code></text></paragraph><paragraph id='.4252' h='7b8aae80'><text id='.4253'>PK = </text><text id='.4258'><code>employee_id</code></text><text id='.4269'> (একজনের এ…</text></paragraph><table id='.4291' h='b2458841'><gap blocks='8'/></table><paragraph id='.4768' h='57318a49'><text id='.4769'>নিয়ম: </text><text id='.4776'><code>resigned</code></text><text id='.4784'>/</text><text id='.4785'><code>terminated</code></text><text id='.4795'> Employee-…</text><text id='.4825'><code>disabled</code></text><text id='.4833'> (RPC ও Tr…</text></paragraph><paragraph id='.4860' h='b3baa37f' heading='3'><text id='.4861'><code>core.emplo…</code></text><text id='.4884'> [S]</text></paragraph><table id='.4888' h='749ccc75'><gap blocks='8'/></table><paragraph id='.5238' h='059943f9'><text id='.5239'>সীমা: (</text><text id='.5246'><code>employee_id</code></text><text id='.5257'>, </text><text id='.5259'><code>position_id</code></text><text id='.5270'>) জুড়ে তা…</text><text id='.5368'><code>UK (employ…</code></text><text id='.5426'>)।</text></paragraph><paragraph id='.5428' h='484543de' heading='3'><text id='.5429'><code>core.repor…</code></text><text id='.5457'> [S]</text></paragraph><table id='.5461' h='8512409e'><gap blocks='5'/></table><paragraph id='.5698' h='4a8363e8'><text id='.5699'>সীমা: </text><text id='.5705'><code>employee_i…</code></text><text id='.5730'>; একজনের এ…</text><text id='.5750'><code>reports_to</code></text><text id='.5760'>; Trigger …</text></paragraph><paragraph id='.5807' h='a913ee1d' heading='3'><text id='.5808'><code>core.emplo…</code></text><text id='.5829'> [A]</text></paragraph><table id='.5833' h='06fc4838'><gap blocks='10'/></table></doc>\",
  \"data\": {
    \"notices\": [
      {
        \"code\": \"pending_ended\",
        \"ids\": [
          \"mysjbetn44p.328\"
        ],
        \"as\": \"resolved\",
        \"opIndex\": 0
      }
    ]
  }
}"
    },
    "hidden_in_chat": false
  },
  {
    "start_timestamp": "2026-11-03T10:28:30.531325Z",
    "stop_timestamp": "2026-11-03T10:28:41.808333Z",
    "flags": null,
    "type": "thinking",
    "thinking": "",
    "summaries": [
      {
        "summary": "Drafting the permissions and scope tables for the schema."
      },
      {
        "summary": "Defining the permission codes and their action values."
      },
      {
        "summary": "Mapping how permission scope rules apply to each role."
      }
    ],
    "cut_off": false,
    "truncated": false,
    "hidden": false,
    "thinking_hidden": true,
    "alternative_display_type": null,
    "signature": null
  },
  {
    "start_timestamp": "2026-11-03T10:28:41.808413Z",
    "stop_timestamp": "2026-11-03T10:28:58.121057Z",
    "flags": null,
    "type": "tool_use",
    "id": "toolu_01DYEKVk8hdLDi5WRyacrghA",
    "name": "Claude Docs:update",
    "input": {
      "container": {
        "id": "7100045d-5c9d-44ce-bb65-c27f892b5438",
        "kind": "project"
      },
      "engine": "prose",
      "payload": "{\"ops\":[{\"op\":\"replace\",\"target\":{\"kind\":\"blocks\",\"ids\":[\"mysjbetn44p.329\"]},\"with\":{\"as\":\"markdown\",\"from\":{\"kind\":\"inline\",\"content\":\"## ৩. Role, Permission ও Scope টেবিল

Permission = কাজের কোড (`module.action`); Role = Permission-এর সেট; Scope বসে Role-Assignment বা ব্যক্তিগত Override-এ। v0.2.1-এর `data_access_scopes` আলাদা টেবিল **বাদ** দেওয়া হলো, কারণ Scope দুই জায়গায় থাকলে সত্যের উৎস দ্বিগুণ হয়; এখন Scope থাকে শুধু `user_roles` ও `user_permission_overrides`-এ। **Proposed।**


### `core.employee_positions` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `employee_id` | uuid | NN | FK→employees | |
| `position_id` | uuid | NN | FK→positions | |
| `wing_id` | uuid | NN | FK→wings | Position-এর Wing-এর সমান (Trigger) |
| `is_primary` | boolean | NN | default false | |
| `effective_from` | date | NN | | |
| `effective_to` | date | | CHECK ≥ `effective_from` | |
| `history_id` | uuid | | FK→employee_history | |

সীমা: (`employee_id`, `position_id`) জুড়ে তারিখ-পরিসর ওভারল্যাপ নিষিদ্ধ (Exclusion Constraint); একজনের একটিই চালু Primary Position (`UK (employee_id) WHERE is_primary AND effective_to IS NULL`)।


### `core.employees` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `employee_no` | text | NN | UK | Sequence থেকে, কখনো পুনর্ব্যবহার নয় (**Final**); ফরম্যাট **Pending #৩৩** |
| `full_name` | text | NN | | |
| `full_name_bn` | text | | | |
| `phone`, `email` | text | | | Unique নয় (একই ফোন পরিবারে হতে পারে); সতর্কতা RPC-তে |
| `joined_on` | date | NN | | |
| `primary_wing_id` | uuid | NN | FK→wings | |
| `employment_status` | text | NN | CHECK `active`/`suspended`/`resigned`/`terminated`, default `active` | |
| `separated_on` | date | | CHECK: `resigned`/`terminated` হলে NN | |
| `separated_effective_at` | timestamptz | | | Login বন্ধের সময় |

এই টেবিলে `DELETE` Privilege নেই। NID, ব্যাংক, ঠিকানার মতো ব্যক্তিগত তথ্য `hr.employee_private`-এ (ভাগ ৩)।


### `core.function_registry` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `purpose` | text | NN | CHECK `validator`/`posting`/`reverse` | |
| `regprocedure_text` | text | NN | UK (`purpose`, `regprocedure_text`) | যেমন `inventory.fn_post_grn(uuid)`; Schema-সহ পূর্ণ Signature |
| `schema_name` | text | NN | CHECK Allowlist (`core`, `inventory`, `finance`, `mfg`, `hr`) | |
| `contract_version` | int | NN | CHECK ≥ 1 | |
| `status` | text | NN | CHECK `draft`/`active`/`retired` | |
| `callable_for_reversal` | boolean | NN | default false | `retired` হলেও পুরোনো লেনদেনের Reversal-এ ডাকা যাবে কি না |
| `definition_checksum` | text | NN | | নিবন্ধনের সময়ের ফাংশন-সংজ্ঞার SHA-256 |
| `effective_from`, `effective_to` | timestamptz | | | |
| `change_reason` | text | NN | | |

**সংযুক্ত পরিবর্তন:** `transaction_types`-এর `validator_function`, `posting_function`, `reverse_function` (text) বাদ; তার বদলে `validator_fn_id`, `posting_fn_id`, `reverse_fn_id` (FK→function_registry)। `transaction_registry`-তে নতুন `posting_fn_id` (Post-এর সময় যে Version চলেছিল) ও `reverse_fn_id` (সেটির জোড়া)।


### `core.idempotency_records` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `actor_id` | uuid | NN | FK→employees | |
| `rpc_name` | text | NN | | |
| `idempotency_key` | text | NN | | Client-জেনারেটেড UUID |
| `request_hash` | text | NN | | Canonical Input-এর Hash |
| `response` | jsonb | NN | | |
| `txn_id` | uuid | | | |
| `client_uuid` | uuid | | | Offline Draft ম্যাপিং |
| `expires_at` | timestamptz | NN | | ধারণ-কাল **Pending #৩২** |

সীমা: UK (`actor_id`, `rpc_name`, `idempotency_key`)।

**আচরণ:** Record RPC-র নিজের Transaction-এর ভেতরেই `INSERT … ON CONFLICT DO NOTHING` দিয়ে বসে। একই Key-তে দ্বিতীয় Request Unique Index-এ অপেক্ষা করে: প্রথমটি Commit হলে সংরক্ষিত `response` ফেরত পায় (`replayed: true`); Rollback হলে নিজে কাজ করে। তাই `in_progress` অবস্থা লাগে না। Key এক, Input আলাদা হলে `E_IDEMPOTENCY_MISMATCH`। অনুমতি বা যাচাইয়ে ব্যর্থ Request-এর Record সংরক্ষিত হয় না।\\\"}}}]}\",
  \"ref\": {
    \"id\": \"f43012c9-1909\",
    \"object\": \"node\"
  }
}"
    },
    "approval_options": null,
    "approval_key": null,
    "approval_key_legacy": null,
    "is_mcp_app": false,
    "hidden_in_chat": false,
    "mcp_server_url": "https://api.anthropic.com/v1/pages/mcp"
  },
  {
    "start_timestamp": "2026-11-03T10:30:13.420102Z",
    "stop_timestamp": "2026-11-03T10:30:13.420171Z",
    "flags": null,
    "type": "tool_result",
    "tool_use_id": "toolu_01SPS8Cmgai7cKtKRJpKougu",
    "name": "Claude Docs:update",
    "content": [
      {
        "type": "text",
        "text": "{\"verdict\":\"allow\",\"rev\":6,\"session\":\"mysjbetn44p\",\"xml\":\"<doc op='0'><paragraph id='mysjbetn44p.15920' h='022913ed' heading='2'>৫. Transac…</paragraph><paragraph id='.15969' h='e887b466'><text id='.15970'>প্রতিটি লে…</text><text id='.16107'><bold>Proposed।</bold></text></paragraph><paragraph id='.16116' h='d6ca3547' heading='3'><text id='.16117'><code>core.trans…</code></text><text id='.16139'> [S]</text></paragraph><table id='.16143' h='3dbe2219'><gap blocks='12'/></table><paragraph id='.16783' h='21d65420'><text id='.16784'>পরিবর্তন v…</text><text id='.16837'><code>material_fields</code></text><text id='.16852'>) বাদ। Pen…</text></paragraph><paragraph id='.16971' h='01d8a726' heading='3'><text id='.16972'><code>core.trans…</code></text><text id='.16997'> [S]</text></paragraph><table id='.17001' h='3bfe1497'><gap blocks='19'/></table><paragraph id='.18209' h='767abe01'><text id='.18210'>CHECK: </text><text id='.18217'><code>posting_st…</code></text><text id='.18245'> হলে </text><text id='.18250'><code>approval_s…</code></text><text id='.18278'>; </text><text id='.18280'><code>posted</code></text><text id='.18286'>/</text><text id='.18287'><code>voided</code></text><text id='.18293'> হলে </text><text id='.18298'><code>txn_no</code></text><text id='.18304'> ও </text><text id='.18307'><code>posted_at</code></text><text id='.18316'> NN; </text><text id='.18321'><code>deleted_at</code></text><text id='.18331'> NN হলে </text><text id='.18339'><code>posting_st…</code></text><text id='.18366'> ও </text><text id='.18369'><code>approval_status</code></text><text id='.18384'> </text><text id='.18385'><code>draft</code></text><text id='.18390'>/</text><text id='.18391'><code>returned</code></text><text id='.18399'>। State Ma…</text><text id='.18447'><code>posted → voided</code></text><text id='.18462'>) পাস করে।…</text><text id='.18492'><code>draft</code></text><text id='.18497'> ও </text><text id='.18500'><code>returned</code></text><text id='.18508'> অবস্থায়।</text></paragraph><paragraph id='.18518' h='5d3fe193' heading='3'><text id='.18519'><code>core.trans…</code></text><text id='.18544'> [A]</text></paragraph><table id='.18548' h='e42d0da8'><gap blocks='6'/></table><paragraph id='.18842' h='b2306752' heading='3'><text id='.18843'><code>core.delet…</code></text><text id='.18870'> [A]</text></paragraph><paragraph id='.18874' h='42b8bfbe'><text id='.18875'>Delete = ল…</text><text id='.18908'><code>deleted_at</code></text><text id='.18918'>), আর পূর্…</text></paragraph><table id='.19004' h='849b2009'><gap blocks='6'/></table><paragraph id='.19230' h='a9bcac15' heading='3'><text id='.19231'><code>core.docum…</code></text><text id='.19254'> [S]</text></paragraph><table id='.19258' h='2ed84cd5'><gap blocks='9'/></table><paragraph id='.19676' h='658e1f8d'><text id='.19677'>সীমা: UK (</text><text id='.19687'><code>wing_id</code></text><text id='.19694'>, </text><text id='.19696'><code>series_key</code></text><text id='.19706'>, </text><text id='.19708'><code>fiscal_year</code></text><text id='.19719'>)। ফরম্যাট: </text><text id='.19731'><code>{prefix}-{…</code></text><text id='.19788'>।</text></paragraph><paragraph id='.19789' h='d3997681'><text id='.19790'><bold>নম্বর বসানো (</bold></text><text id='.19803'><bold><code>core.fn_as…</code></bold></text><text id='.19824'><bold>):</bold></text><text id='.19826'> Post-এর T…</text><text id='.19858'><code>unique_only</code></text><text id='.19869'>: Sequence…</text><text id='.19937'><code>gapless</code></text><text id='.19944'>: Counter সারি </text><text id='.19959'><code>FOR UPDATE</code></text><text id='.19969'> Lock করে …</text></paragraph><paragraph id='.20112' h='ee08e0f2' heading='3'><text id='.20113'><code>core.idemp…</code></text><text id='.20137'> [S]</text></paragraph><table id='.20141' h='c28dd203'><gap blocks='9'/></table><paragraph id='.20493' h='039132cc'><text id='.20494'>সীমা: UK (</text><text id='.20504'><code>actor_id</code></text><text id='.20512'>, </text><text id='.20514'><code>rpc_name</code></text><text id='.20522'>, </text><text id='.20524'><code>idempotency_key</code></text><text id='.20539'>)।</text></paragraph><paragraph id='.20541' h='4c8b22f2'><text id='.20542'><bold>আচরণ:</bold></text><text id='.20547'> Record RP…</text><text id='.20589'><code>INSERT … O…</code></text><text id='.20620'> দিয়ে বসে…</text><text id='.20716'><code>response</code></text><text id='.20724'> ফেরত পায় (</text><text id='.20736'><code>replayed: true</code></text><text id='.20750'>); Rollbac…</text><text id='.20784'><code>in_progress</code></text><text id='.20795'> অবস্থা লা…</text><text id='.20836'><code>E_IDEMPOTE…</code></text><text id='.20858'>। অনুমতি ব…</text></paragraph></doc>\",\"data\":{\"notices\":[{\"code\":\"pending_ended\",\"ids\":[\"mysjbetn44p.331\"],\"as\":\"resolved\",\"opIndex\":0}]}}"
      }
    ],
    "is_error": false,
    "structured_content": null,
    "meta": {
      "authoredByOthers": false,
      "sharedOutsideOrg": false
    },
    "message": null,
    "integration_name": "Claude Docs",
    "mcp_server_url": "https://api.anthropic.com/v1/pages/mcp",
    "integration_icon_url": null,
    "icon_name": null,
    "display_content": {
      "type": "json_block",
      "json_block": "{
  \"verdict\": \"allow\",
  \"rev\": 6,
  \"session\": \"mysjbetn44p\",
  \"xml\": \"<doc op='0'><paragraph id='mysjbetn44p.15920' h='022913ed' heading='2'>৫. Transac…</paragraph><paragraph id='.15969' h='e887b466'><text id='.15970'>প্রতিটি লে…</text><text id='.16107'><bold>Proposed।</bold></text></paragraph><paragraph id='.16116' h='d6ca3547' heading='3'><text id='.16117'><code>core.trans…</code></text><text id='.16139'> [S]</text></paragraph><table id='.16143' h='3dbe2219'><gap blocks='12'/></table><paragraph id='.16783' h='21d65420'><text id='.16784'>পরিবর্তন v…</text><text id='.16837'><code>material_fields</code></text><text id='.16852'>) বাদ। Pen…</text></paragraph><paragraph id='.16971' h='01d8a726' heading='3'><text id='.16972'><code>core.trans…</code></text><text id='.16997'> [S]</text></paragraph><table id='.17001' h='3bfe1497'><gap blocks='19'/></table><paragraph id='.18209' h='767abe01'><text id='.18210'>CHECK: </text><text id='.18217'><code>posting_st…</code></text><text id='.18245'> হলে </text><text id='.18250'><code>approval_s…</code></text><text id='.18278'>; </text><text id='.18280'><code>posted</code></text><text id='.18286'>/</text><text id='.18287'><code>voided</code></text><text id='.18293'> হলে </text><text id='.18298'><code>txn_no</code></text><text id='.18304'> ও </text><text id='.18307'><code>posted_at</code></text><text id='.18316'> NN; </text><text id='.18321'><code>deleted_at</code></text><text id='.18331'> NN হলে </text><text id='.18339'><code>posting_st…</code></text><text id='.18366'> ও </text><text id='.18369'><code>approval_status</code></text><text id='.18384'> </text><text id='.18385'><code>draft</code></text><text id='.18390'>/</text><text id='.18391'><code>returned</code></text><text id='.18399'>। State Ma…</text><text id='.18447'><code>posted → voided</code></text><text id='.18462'>) পাস করে।…</text><text id='.18492'><code>draft</code></text><text id='.18497'> ও </text><text id='.18500'><code>returned</code></text><text id='.18508'> অবস্থায়।</text></paragraph><paragraph id='.18518' h='5d3fe193' heading='3'><text id='.18519'><code>core.trans…</code></text><text id='.18544'> [A]</text></paragraph><table id='.18548' h='e42d0da8'><gap blocks='6'/></table><paragraph id='.18842' h='b2306752' heading='3'><text id='.18843'><code>core.delet…</code></text><text id='.18870'> [A]</text></paragraph><paragraph id='.18874' h='42b8bfbe'><text id='.18875'>Delete = ল…</text><text id='.18908'><code>deleted_at</code></text><text id='.18918'>), আর পূর্…</text></paragraph><table id='.19004' h='849b2009'><gap blocks='6'/></table><paragraph id='.19230' h='a9bcac15' heading='3'><text id='.19231'><code>core.docum…</code></text><text id='.19254'> [S]</text></paragraph><table id='.19258' h='2ed84cd5'><gap blocks='9'/></table><paragraph id='.19676' h='658e1f8d'><text id='.19677'>সীমা: UK (</text><text id='.19687'><code>wing_id</code></text><text id='.19694'>, </text><text id='.19696'><code>series_key</code></text><text id='.19706'>, </text><text id='.19708'><code>fiscal_year</code></text><text id='.19719'>)। ফরম্যাট: </text><text id='.19731'><code>{prefix}-{…</code></text><text id='.19788'>।</text></paragraph><paragraph id='.19789' h='d3997681'><text id='.19790'><bold>নম্বর বসানো (</bold></text><text id='.19803'><bold><code>core.fn_as…</code></bold></text><text id='.19824'><bold>):</bold></text><text id='.19826'> Post-এর T…</text><text id='.19858'><code>unique_only</code></text><text id='.19869'>: Sequence…</text><text id='.19937'><code>gapless</code></text><text id='.19944'>: Counter সারি </text><text id='.19959'><code>FOR UPDATE</code></text><text id='.19969'> Lock করে …</text></paragraph><paragraph id='.20112' h='ee08e0f2' heading='3'><text id='.20113'><code>core.idemp…</code></text><text id='.20137'> [S]</text></paragraph><table id='.20141' h='c28dd203'><gap blocks='9'/></table><paragraph id
…"
    },
    "hidden_in_chat": false
  },
  {
    "start_timestamp": "2026-11-03T10:30:14.403857Z",
    "stop_timestamp": "2026-11-03T10:30:23.190067Z",
    "flags": null,
    "type": "thinking",
    "thinking": "",
    "summaries": [
      {
        "summary": "Defining correction tables for financial and other data."
      },
      {
        "summary": "Specifying constraints linking corrections to their original transactions."
      },
      {
        "summary": "Checking reversal and replacement rules for corrections."
      }
    ],
    "cut_off": false,
    "truncated": false,
    "hidden": false,
    "thinking_hidden": true,
    "alternative_display_type": null,
    "signature": null
  },
  {
    "start_timestamp": "2026-11-03T10:30:23.190172Z",
    "stop_timestamp": "2026-11-03T10:30:36.187536Z",
    "flags": null,
    "type": "tool_use",
    "id": "toolu_01SjxeUnknbGrrtYfn6X2cpg",
    "name": "Claude Docs:update",
    "input": {
      "container": {
        "id": "7100045d-5c9d-44ce-bb65-c27f892b5438",
        "kind": "project"
      },
      "engine": "prose",
      "payload": "{\"ops\":[{\"op\":\"replace\",\"target\":{\"kind\":\"blocks\",\"ids\":[\"mysjbetn44p.332\"]},\"with\":{\"as\":\"markdown\",\"from\":{\"kind\":\"inline\",\"content\":\"## ৬. Correction ও Reversal টেবিল

Correction নিজেও একটি লেনদেন (ধরন `CORRECTION`), তাই একই Approval Engine, Idempotency ও Audit তাতে চলে। Posted লেনদেন কখনো সরাসরি বদলায় না (**Final**)। **Proposed** নকশা:


### `core.organizations` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `name` | text | NN | UK | |
| `legal_name` | text | | | |
| `status` | text | NN | CHECK `active`/`inactive`, default `active` | |


### `core.permissions`
Catalog টেবিল; বদলায় শুধু Migration দিয়ে (অ্যাপ বা RPC দিয়ে নয়)।

| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `id` | uuid | NN | PK | |
| `code` | text | NN | UK | যেমন `purchase.approve` |
| `module` | text | NN | | |
| `action` | text | NN | | |
| `description` | text | | | |
| `is_sensitive` | boolean | NN | default false | Financial, Salary, Sensitive Document, Audit: দিতে Approval লাগবে |
| `allowed_scope_levels` | text[] | NN | | কোন স্তরে দেওয়া যায় (`organization`/`wing`/`department`/`warehouse`/`employee`) |
| `status` | text | NN | CHECK `active`/`retired` | |
| `created_at` | timestamptz | NN | | |

গুরুত্বপূর্ণ: Audit মোছা, Posted Ledger বদলানো বা Security বাইপাসের কোনো Permission Catalog-এ **নেই**। অস্তিত্বহীন Permission কাউকে দেওয়াই যায় না, তাই Chairman-ও এগুলো করতে পারেন না (**Final**)।


### `core.positions` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `department_id` | uuid | NN | FK→departments | |
| `code` | text | NN | UK (`department_id`, `code`) | |
| `title` | text | NN | | Designation তালিকা **Pending #৮**; শুরুতে ফাঁকা |
| `level` | int | NN | CHECK ≥ 0 | স্তর, Approval-এ তুলনার জন্য |
| `status` | text | NN | CHECK `active`/`inactive` | |


### `core.reporting_relationships` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `employee_id` | uuid | NN | FK→employees | |
| `manager_id` | uuid | NN | FK→employees | |
| `relation_type` | text | NN | CHECK `reports_to`/`supervisor`/`functional` | |
| `effective_from`, `effective_to` | date | NN, | CHECK ≥ | |

সীমা: `employee_id <> manager_id`; একজনের একটিই চালু `reports_to`; Trigger চক্র আটকায়; Manager সক্রিয় হতে হবে।


### `core.role_permissions` [S]
ইতিহাস রাখতে সারি মোছা হয় না; বন্ধ করতে `effective_to` বসে।

| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `role_id` | uuid | NN | FK→roles | |
| `permission_id` | uuid | NN | FK→permissions | |
| `effective_from` | timestamptz | NN | default `now()` | |
| `effective_to` | timestamptz | | CHECK ≥ `effective_from` | |
| `reason` | text | NN | | |

সীমা: UK (`role_id`, `permission_id`) যেখানে `effective_to IS NULL`।


### `core.roles` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `code` | text | NN | UK | যেমন `CHAIRMAN`, `MD` |
| `name` | text | NN | | |
| `description` | text | | | |
| `is_system` | boolean | NN | default false | সিস্টেম Role মোছা/নাম বদল নয় |
| `status` | text | NN | CHECK `active`/`inactive` | |


### `core.security_events` [A]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `id` | bigint identity | NN | PK | |
| `occurred_at` | timestamptz | NN | default `now()` | |
| `event_type` | text | NN | CHECK `permission_denied`/`scope_denied`/`session_invalid`/`mfa_required`/`inactive_actor`/`idempotency_mismatch`/`escalation_attempt`/`integrity_failure`/`break_glass_used`/`other` | |
| `severity` | text | NN | CHECK `info`/`warning`/`critical` | |
| `actor_employee_id`, `actor_user_id` | uuid | | | |
| `rpc_name` | text | | | |
| `detail` | jsonb | | | |
| `source` | text | NN | CHECK `rpc`/`trigger`/`job`/`external` | |


### `core.security_settings` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `key` | text | NN | UK | যেমন `idempotency_retention_days`, `audit_seal_lag_seconds`, `device_activation_roles` |
| `value` | jsonb | NN | | |
| `reason` | text | NN | | প্রতিটি পরিবর্তন Audit-এ |

Access Token-এর মেয়াদ Supabase Auth সেটিংসে ঠিক হয়; এখানে শুধু রেফারেন্সের জন্য মান লেখা থাকবে (**Pending #২৮**)।\\\"}}}]}\",
  \"ref\": {
    \"id\": \"f43012c9-1909\",
    \"object\": \"node\"
  }
}"
    },
    "approval_options": null,
    "approval_key": null,
    "approval_key_legacy": null,
    "is_mcp_app": false,
    "hidden_in_chat": false,
    "mcp_server_url": "https://api.anthropic.com/v1/pages/mcp"
  },
  {
    "start_timestamp": "2026-11-03T10:31:11.188292Z",
    "stop_timestamp": "2026-11-03T10:31:11.188347Z",
    "flags": null,
    "type": "tool_result",
    "tool_use_id": "toolu_01RMYThH32D3maVxR8PLvYGL",
    "name": "Claude Docs:update",
    "content": [
      {
        "type": "text",
        "text": "{\"verdict\":\"allow\",\"rev\":8,\"session\":\"mysjbetn44p\",\"xml\":\"<doc op='0'><paragraph id='mysjbetn44p.23607' h='db40121a' heading='2'>৭. Audit এ…</paragraph><paragraph id='.23648' h='69710550' heading='3'><text id='.23649'><code>core.audit_logs</code></text><text id='.23664'> [A]</text></paragraph><paragraph id='.23668' h='978161a3'><text id='.23669'><code>occurred_at</code></text><text id='.23680'> ধরে মাসিক…</text><text id='.23722'><code>core.fn_wr…</code></text><text id='.23743'> দিয়ে (ক্…</text><text id='.23764'><code>EXECUTE</code></text><text id='.23771'> নেই), এবং…</text><text id='.23792'><bold>একই Transa…</bold></text><text id='.23809'>; তাই কাজ …</text><text id='.23881'><code>security_events</code></text><text id='.23896'>-এ।</text></paragraph><table id='.23899' h='f515def6'><gap blocks='17'/></table><paragraph id='.24677' h='1fb19cc7' heading='3'><text id='.24678'><code>core.audit…</code></text><text id='.24694'> [A]</text></paragraph><paragraph id='.24698' h='8878a75f'><text id='.24699'>v0.2.1-এ প…</text><text id='.24723'><code>prev_hash</code></text><text id='.24732'> রাখার কথা…</text><text id='.24882'><bold>Seal Job</bold></text><text id='.24890'> ব্যাচ ধরে…</text><text id='.24915'><bold>Proposed।</bold></text></paragraph><table id='.24924' h='1f622103'><gap blocks='10'/></table><paragraph id='.25427' h='47bcfa08'><text id='.25428'><bold>Seal-এর সূ…</bold></text><text id='.25446'> </text><text id='.25447'><code>bigint identity</code></text><text id='.25462'> মান ক্রমা…</text><text id='.25526'><code>id</code></text><text id='.25528'> পরে Commi…</text><text id='.25563'><code>now() − নি…</code></text><text id='.25586'> আগের সারি…</text><text id='.25625'><code>statement_…</code></text><text id='.25642'> ও </text><text id='.25645'><code>idle_in_tr…</code></text><text id='.25680'>-এর চেয়ে …</text><text id='.25700'><bold>Pending #৩৬</bold></text><text id='.25711'>) এবং পরিস…</text></paragraph><paragraph id='.25769' h='999bc24f' heading='3'><text id='.25770'><code>core.secur…</code></text><text id='.25790'> [A]</text></paragraph><table id='.25794' h='d68105bc'><gap blocks='9'/></table><paragraph id='.26296' h='e88e6e47' heading='3'><text id='.26297'><code>core.devic…</code></text><text id='.26317'> [S]</text></paragraph><table id='.26321' h='8b95eed4'><gap blocks='10'/></table><paragraph id='.26839' h='9dcde498' heading='3'><text id='.26840'><code>core.sessi…</code></text><text id='.26859'> [A]</text></paragraph><table id='.26863' h='1792dc5b'><gap blocks='8'/></table><paragraph id='.27197' h='f65c2b05'>উৎস: Edge …</paragraph><paragraph id='.27296' h='8035626b' heading='3'><text id='.27297'><code>core.sensi…</code></text><text id='.27322'> [S]</text></paragraph><table id='.27326' h='c4458bfe'><gap blocks='6'/></table><paragraph id='.27670' h='e011226f'><text id='.27671'>প্রাথমিক ত…</text><text id='.27688'><bold>Proposed</bold></text><text id='.27696'>; চূড়ান্ত </text><text id='.27707'><bold>Pending #২৮</bold></text><text id='.27718'>): </text><text id='.27721'><code>rpc_chairm…</code></text><text id='.27742'> (aal2), </text><text id='.27751'><code>rpc_assign_role</code></text><text id='.27766'> (aal2), </text><text id='.27775'><code>rpc_set_pe…</code></text><text id='.27802'>, </text><text id='.27804'><code>rpc_termin…</code></text><text id='.27826'>, </text><text id='.27828'><code>rpc_create…</code></text><text id='.27860'>, </text><text id='.27862'><code>rpc_post</code></text><text id='.27870'>, </text><text id='.27872'><code>rpc_approve</code></text><text id='.27883'>, পাশাপাশি…</text></paragraph><paragraph id='.27926' h='22cc67e1' heading='3'><text id='.27927'><code>core.secur…</code></text><text id='.27949'> [S]</text></paragraph><table id='.27953' h='ea731566'><gap blocks='4'/></table><paragraph id='.28162' h='15d802f9'><text id='.28163'>Access Tok…</text><text id='.28261'><bold>Pending #২৮</bold></text><text id='.28272'>)।</text></paragraph></doc>\",\"data\":{\"notices\":[{\"code\":\"pending_ended\",\"ids\":[\"mysjbetn44p.333\"],\"as\":\"resolved\",\"opIndex\":0}]}}"
      }
    ],
    "is_error": false,
    "structured_content": null,
    "meta": {
      "authoredByOthers": false,
      "sharedOutsideOrg": false
    },
    "message": null,
    "integration_name": "Claude Docs",
    "mcp_server_url": "https://api.anthropic.com/v1/pages/mcp",
    "integration_icon_url": null,
    "icon_name": null,
    "display_content": {
      "type": "json_block",
      "json_block": "{
  \"verdict\": \"allow\",
  \"rev\": 8,
  \"session\": \"mysjbetn44p\",
  \"xml\": \"<doc op='0'><paragraph id='mysjbetn44p.23607' h='db40121a' heading='2'>৭. Audit এ…</paragraph><paragraph id='.23648' h='69710550' heading='3'><text id='.23649'><code>core.audit_logs</code></text><text id='.23664'> [A]</text></paragraph><paragraph id='.23668' h='978161a3'><text id='.23669'><code>occurred_at</code></text><text id='.23680'> ধরে মাসিক…</text><text id='.23722'><code>core.fn_wr…</code></text><text id='.23743'> দিয়ে (ক্…</text><text id='.23764'><code>EXECUTE</code></text><text id='.23771'> নেই), এবং…</text><text id='.23792'><bold>একই Transa…</bold></text><text id='.23809'>; তাই কাজ …</text><text id='.23881'><code>security_events</code></text><text id='.23896'>-এ।</text></paragraph><table id='.23899' h='f515def6'><gap blocks='17'/></table><paragraph id='.24677' h='1fb19cc7' heading='3'><text id='.24678'><code>core.audit…</code></text><text id='.24694'> [A]</text></paragraph><paragraph id='.24698' h='8878a75f'><text id='.24699'>v0.2.1-এ প…</text><text id='.24723'><code>prev_hash</code></text><text id='.24732'> রাখার কথা…</text><text id='.24882'><bold>Seal Job</bold></text><text id='.24890'> ব্যাচ ধরে…</text><text id='.24915'><bold>Proposed।</bold></text></paragraph><table id='.24924' h='1f622103'><gap blocks='10'/></table><paragraph id='.25427' h='47bcfa08'><text id='.25428'><bold>Seal-এর সূ…</bold></text><text id='.25446'> </text><text id='.25447'><code>bigint identity</code></text><text id='.25462'> মান ক্রমা…</text><text id='.25526'><code>id</code></text><text id='.25528'> পরে Commi…</text><text id='.25563'><code>now() − নি…</code></text><text id='.25586'> আগের সারি…</text><text id='.25625'><code>statement_…</code></text><text id='.25642'> ও </text><text id='.25645'><code>idle_in_tr…</code></text><text id='.25680'>-এর চেয়ে …</text><text id='.25700'><bold>Pending #৩৬</bold></text><text id='.25711'>) এবং পরিস…</text></paragraph><paragraph id='.25769' h='999bc24f' heading='3'><text id='.25770'><code>core.secur…</code></text><text id='.25790'> [A]</text></paragraph><table id='.25794' h='d68105bc'><gap blocks='9'/></table><paragraph id='.26296' h='e88e6e47' heading='3'><text id='.26297'><code>core.devic…</code></text><text id='.26317'> [S]</text></paragraph><table id='.26321' h='8b95eed4'><gap blocks='10'/></table><paragraph id='.26839' h='9dcde498' heading='3'><text id='.26840'><code>core.sessi…</code></text><text id='.26859'> [A]</text></paragraph><table id='.26863' h='1792dc5b'><gap blocks='8'/></table><paragraph id='.27197' h='f65c2b05'>উৎস: Edge …</paragraph><paragraph id='.27296' h='8035626b' heading='3'><text id='.27297'><code>core.sensi…</code></text><text id='.27322'> [S]</text></paragraph><table id='.27326' h='c4458bfe'><gap blocks='6'/></table><paragraph id='.27670' h='e011226f'><text id='.27671'>প্রাথমিক ত…</text><text id='.27688'><bold>Proposed</bold></text><text id='.27696'>; চূড়ান্ত </text><text id='.27707'><bold>Pending #২৮</bold></text><text id='.27718'>): </text><text id='.27721'><code>rpc_chairm…</code></text><text id='.27742'> (aal2), </text><text id='.27751'><code>rpc_assign_role</code></text><text id='.27766'> (aal2), </text><text id='.27775'><code>rpc_set_pe…</code></text><text id='.27802'>, </text><text id='.27804'><code>rpc_termin…</code></text><text id='.27826'>, </text><text id='.27828'><code>rpc_create…</code></text><text id='.27860'>, </text><text id='.27862'><code>rpc_post</code></text><text id='.27870'>, </text><text id='.27872'><code>rpc_approve</code></text><text id='.27883'>, পাশাপাশি…</text></paragraph><paragraph id='.27926' h='22cc67e1' heading='3'><text id='.27927'><code>core.secur…</code></text><text id='.27949'> [S]</text></paragraph><table id='.27953' h='ea731566'><gap blocks='4'/></tab
…"
    },
    "hidden_in_chat": false
  },
  {
    "start_timestamp": "2026-11-03T10:31:12.221823Z",
    "stop_timestamp": "2026-11-03T10:31:30.331405Z",
    "flags": null,
    "type": "thinking",
    "thinking": "",
    "summaries": [
      {
        "summary": "Defining the RPC envelope and table of identity RPCs."
      },
      {
        "summary": "Setting out the column layout for the identity RPCs."
      },
      {
        "summary": "Listing the RPC inputs and outputs for employee management."
      },
      {
        "summary": "Defining role assignment and terminate RPCs."
      }
    ],
    "cut_off": false,
    "truncated": false,
    "hidden": false,
    "thinking_hidden": true,
    "alternative_display_type": null,
    "signature": null
  },
  {
    "start_timestamp": "2026-11-03T10:31:30.331516Z",
    "stop_timestamp": "2026-11-03T10:31:53.875746Z",
    "flags": null,
    "type": "tool_use",
    "id": "toolu_01YVgJSHgF1RDgfCSMrwkWVG",
    "name": "Claude Docs:update",
    "input": {
      "container": {
        "id": "7100045d-5c9d-44ce-bb65-c27f892b5438",
        "kind": "project"
      },
      "engine": "prose",
      "payload": "{\"ops\":[{\"op\":\"replace\",\"target\":{\"kind\":\"blocks\",\"ids\":[\"mysjbetn44p.334\"]},\"with\":{\"as\":\"markdown\",\"from\":{\"kind\":\"inline\",\"content\":\"## ৮. RPC Specification: Identity ও Access


### `core.sensitive_operations` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `rpc_name` | text | NN | UK | |
| `requires_session_check` | boolean | NN | default true | `session_id` Claim ও `auth.sessions` মেলানো |
| `requires_aal2` | boolean | NN | default false | MFA-যাচাইকৃত Token লাগবে |
| `max_token_age_seconds` | int | | | Token এর চেয়ে পুরোনো হলে প্রত্যাখ্যান |
| `status` | text | NN | CHECK `active`/`inactive` | |

প্রাথমিক তালিকা (**Proposed**; চূড়ান্ত **Pending #২৮**): `rpc_chairman_override` (aal2), `rpc_assign_role` (aal2), `rpc_set_permission_override`, `rpc_terminate_employee`, `rpc_create_approval_rule_version`, `rpc_post`, `rpc_approve`, পাশাপাশি ভাগ ২-৩-এর Payment ও Salary RPC।


### `core.session_events` [A]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `employee_id` | uuid | NN | FK→employees | |
| `auth_session_id` | uuid | | | |
| `event_type` | text | NN | CHECK `login`/`logout`/`forced_signout`/`session_check_failed`/`mfa_failed`/`token_refresh_denied` | |
| `device_id` | text | | | |
| `ip` | inet | | | |
| `user_agent` | text | | | |
| `occurred_at` | timestamptz | NN | default `now()` | |

উৎস: Edge Function ও নিজস্ব RPC। Supabase Auth-এর নিজের লগ আলাদা, এই টেবিলটি ERP-এর ভেতরের রেকর্ড।


### `core.transaction_links` [A]
আংশিক Reversal বোঝাতে আলাদা Link-টেবিল। এর ফলে `transaction_registry.replaced_by` কলাম **বাদ** (একই সত্য দুই জায়গায় নয়)।

| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `from_txn_id` | uuid | NN | FK→transaction_registry | |
| `to_txn_id` | uuid | NN | FK→transaction_registry | CHECK `from_txn_id <> to_txn_id` |
| `link_type` | text | NN | CHECK `reversal`/`replacement`/`restores`/`return`/`adjustment` | |
| `reason` | text | NN | | |

সীমা: UK (`from_txn_id`, `to_txn_id`, `link_type`)।


### `core.transaction_registry` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `txn_type_id` | uuid | NN | FK→transaction_types | |
| `wing_id` | uuid | NN | FK→wings | Scope-এর ভিত্তি |
| `department_id` | uuid | | FK→departments | |
| `draft_ref` | text | NN | UK | সিস্টেম-জেনারেটেড অস্থায়ী রেফারেন্স |
| `txn_no` | text | | UK যেখানে NN | আনুষ্ঠানিক নম্বর, বসে শুধু Post-এর সময় |
| `txn_date` | date | NN | | ব্যবসায়িক তারিখ |
| `version` | int | NN | default 1 | Submit-সংখ্যা |
| `approval_status` | text | NN | CHECK `draft`/`submitted`/`pending`/`approved`/`rejected`/`returned`/`cancelled`, default `draft` | `submitted` = কোনো Approver Action আসেনি; প্রথম Action-এ `pending` |
| `posting_status` | text | NN | CHECK `unposted`/`posted`/`voided`, default `unposted` | |
| `amount` | numeric(18,2) | | | Approval Band-এর জন্য |
| `submitted_by`, `submitted_at` | uuid, timestamptz | | FK→employees | |
| `approved_at` | timestamptz | | | |
| `posted_by`, `posted_at` | uuid, timestamptz | | FK→employees | |
| `source_table`, `source_id` | text, uuid | | | মডিউল Header-এর পয়েন্টার |
| `client_uuid` | uuid | | UK (`created_by`, `client_uuid`) যেখানে NN | Offline Draft |
| `reversal_of` | uuid | | FK→self, UK যেখানে NN | যে লেনদেনকে বাতিল করছে |
| `replaced_by` | uuid | | FK→self | |
| `deleted_at`, `deleted_by`, `delete_reason` | timestamptz, uuid, text | | | Draft/Returned-এর লজিকাল Delete |

CHECK: `posting_status <> 'unposted'` হলে `approval_status = 'approved'`; `posted`/`voided` হলে `txn_no` ও `posted_at` NN; `deleted_at` NN হলে `posting_status = 'unposted'` ও `approval_status` `draft`/`returned`। State Machine Trigger শুধু বৈধ পরিবর্তন (যেমন `posted → voided`) পাস করে। Edit করা যায় শুধু `draft` ও `returned` অবস্থায়।


### `core.transaction_reversals` [A]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `original_txn_id` | uuid | NN | UK, FK→transaction_registry | একটি লেনদেনের একটিই Reversal (**Final**) |
| `reversing_txn_id` | uuid | NN | UK, FK→transaction_registry | বিপরীত লেনদেন |
| `correction_id` | uuid | NN | FK→corrections | |
| `reason` | text | NN | | |

Trigger: মূল লেনদেন `posted` না হলে Insert ব্যর্থ; Insert-এর সাথে মূল লেনদেন `voided` হয়; Reversal নিজেকে আবার Reverse করা যায় না।


### `core.transaction_types` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `code` | text | NN | UK | যেমন `PURCHASE_INVOICE`, `GRN` |
| `module` | text | NN | | |
| `name` | text | NN | | |
| `requires_approval` | boolean | NN | default true | `false` হলে Submit-এ সরাসরি `approved` |
| `separate_post_step` | boolean | NN | default true | Approved-এর পর আলাদা Post ধাপ (**Pending #২১**) |
| `validator_function` | text | | | Submit-এর আগে মডিউলের যাচাই (ভাগ ২-৩-এ ভরবে) |
| `posting_function` | text | | | `post_transaction` যাকে ডাকে |
| `reverse_function` | text | | | Reversal-এ যাকে ডাকে |
| `numbering_series_key` | text | NN | | |
| `allow_backdate_days` | int | NN | default 0, CHECK ≥ 0 | (**Pending #২২**) |
| `status` | text | NN | CHECK `active`/`inactive` | |

পরিবর্তন v0.2.1 থেকে: “গুরুত্বপূর্ণ ক্ষেত্র” তালিকা (`material_fields`) বাদ। Pending বা Approved অবস্থায় কোনো Edit নেই, তাই যেকোনো সংশোধন মানে Return/নতুন Version; আলাদা তালিকার দরকার নেই।


### `core.transaction_versions` [A]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `txn_id` | uuid | NN | FK→transaction_registry | |
| `version` | int | NN | UK (`txn_id`, `version`) | |
| `payload_hash` | text | NN | | Header + Line-এর Canonical Hash |
| `snapshot` | jsonb | NN | | Submit-এর মুহূর্তের পূর্ণ কপি |
| `change_reason` | text | | | Return-এর পর পুনঃজমায় NN |


### `core.user_permission_overrides` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `employee_id` | uuid | NN | FK→employees | |
| `permission_id` | uuid | NN | FK→permissions | |
| `effect` | text | NN | CHECK `allow`/`deny` | |
| `scope_type` | text | NN | CHECK ওপরের তালিকা + `record` | |
| `scope_id` | uuid | | | |
| `scope_table` | text | | | `record` হলে NN (কোন টেবিলের সারি) |
| `effective_from` | timestamptz | NN | default `now()` | |
| `effective_to` | timestamptz | | | `allow`-এ NN বাধ্যতামূলক (মেয়াদহীন Allow নিষিদ্ধ) |
| `reason` | text | NN | | |
| `approval_request_id` | uuid | | FK→approval_requests | সংবেদনশীল Permission দিতে NN |
| `status` | text | NN | CHECK `active`/`revoked` | |
| `granted_by` | uuid | NN | FK→employees | |


### `core.user_roles` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `employee_id` | uuid | NN | FK→employees | একজনের একাধিক Role থাকতে পারে (**Final**) |
| `role_id` | uuid | NN | FK→roles | |
| `scope_type` | text | NN | CHECK `organization`/`wing`/`department`/`warehouse`/`employee` | |
| `scope_id` | uuid | | | `organization` হলে ফাঁকা, নইলে NN: `CHECK ((scope_type='organization') = (scope_id IS NULL))` |
| `effective_from` | date | NN | default আজ | |
| `effective_to` | date | | CHECK ≥ `effective_from` | |
| `status` | text | NN | CHECK `active`/`revoked` | |
| `reason` | text | NN | | |
| `granted_by` | uuid | NN | FK→employees | |
| `revoked_at`, `revoked_by` | timestamptz, uuid | | | |

সীমা: UK (`employee_id`, `role_id`, `scope_type`, `scope_id`, `effective_from`)।


### `core.wings` [S]
| কলাম | ধরন | Null | Key / Check | নোট |
| --- | --- | --- | --- | --- |
| `organization_id` | uuid | NN | FK→organizations | |
| `code` | text | NN | UK | যেমন `MFG`; একবার দিলে বদলায় না |
| `name` | text | NN | | |
| `status` | text | NN | CHECK `active`/`inactive` | |
