# Appendix H — সংশোধিত Test Registry T01–T319

> **পদ্ধতি ও সীমা:** T01–T120: প্রতিটি Test-এর মূল পাঠ থেকে Area, RPC-নাম, DB-সীমাবদ্ধতা **কীওয়ার্ড-মিলিয়ে স্বয়ংক্রিয়ভাবে** নেওয়া — পর্যালোচনা-সাপেক্ষ (ভুল-মিল সম্ভব)। T121–T215: মূল Test-পাঠ এই সেশনে পুনরায় পড়া হয়নি; **সিরিজ-স্তরে** মিলানো। T216–T290: সংশ্লিষ্ট Spec-ডকুমেন্টের শিরোনাম অনুযায়ী। **Supersession-ইতিহাস অক্ষত:** T121, T122, T123 (→T141–T143), T124 (→T147), T133 (→T160) প্রত্যাহৃত; ID মোছা হয়নি। “Milestone” = কোন পর্যায়ের আগে পাস দরকার (Foundation / First Vertical Slice / Manufacturing / Later Wing / Production Gate)। Test পাস মানে Log সহ প্রমাণ।

| ID | স্ট্যাটাস | Requirement-এলাকা | RPC/ফাংশন | DB-সীমাবদ্ধতা | Milestone | উৎস |
| --- | --- | --- | --- | --- | --- | --- |
| T01 | সক্রিয় (লিখিত) | Maker-Checker/অনুমোদন | rpc_approve | Trigger | First Vertical Slice | v0.2.2 |
| T02 | সক্রিয় (লিখিত) | Group/Organization-জীবনচক্র | rpc_*_organization, rpc_group_override | — | Production Gate | v0.2.2 |
| T03 | সক্রিয় (লিখিত) | নিরাপত্তা-ঘটনা/Permission | fn_has_permission | — | Foundation | v0.2.2 |
| T04 | সক্রিয় (লিখিত) | Scope | fn_in_scope | — | Foundation | v0.2.2 |
| T05 | সক্রিয় (লিখিত) | Group/Organization-জীবনচক্র | rpc_*_organization, rpc_group_override | — | Production Gate | v0.2.2 |
| T06 | সক্রিয় (লিখিত) | Delegation | rpc_create_delegation | — | Later Wing | v0.2.2 |
| T07 | সক্রিয় (লিখিত) | কোম্পানি-বিচ্ছিন্নতা/RLS | (RLS/Composite FK) | RLS | Foundation | v0.2.2 |
| T08 | সক্রিয় (লিখিত) | Group/Organization-জীবনচক্র | rpc_*_organization, rpc_group_override | — | Production Gate | v0.2.2 |
| T09 | সক্রিয় (লিখিত) | নিরাপত্তা-ঘটনা/Permission | fn_has_permission | — | Foundation | v0.2.2 |
| T10 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | Trigger | First Vertical Slice | v0.2.2 |
| T11 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.2 |
| T12 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.2 |
| T13 | সক্রিয় (লিখিত) | Concurrency/Lock | (সব Class-B RPC) | — | First Vertical Slice | v0.2.2 |
| T14 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.2 |
| T15 | সক্রিয় (লিখিত) | Concurrency/Lock | (সব Class-B RPC) | — | First Vertical Slice | v0.2.2 |
| T16 | সক্রিয় (লিখিত) | Concurrency/Lock | (সব Class-B RPC) | — | First Vertical Slice | v0.2.2 |
| T17 | সক্রিয় (লিখিত) | Concurrency/Lock | (সব Class-B RPC) | — | First Vertical Slice | v0.2.2 |
| T18 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.2 |
| T19 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.2 |
| T20 | সক্রিয় (লিখিত) | Maker-Checker/অনুমোদন | rpc_approve | — | First Vertical Slice | v0.2.2 |
| T21 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.2 |
| T22 | সক্রিয় (লিখিত) | Group/Organization-জীবনচক্র | rpc_*_organization, rpc_group_override | — | Production Gate | v0.2.2 |
| T23 | সক্রিয় (লিখিত) | Delegation | rpc_create_delegation | — | Later Wing | v0.2.2 |
| T24 | সক্রিয় (লিখিত) | Auth/Session/MFA | rpc_get_my_permissions | — | Foundation | v0.2.2 |
| T25 | সক্রিয় (লিখিত) | Concurrency/Lock | (সব Class-B RPC) | Unique | First Vertical Slice | v0.2.2 |
| T26 | সক্রিয় (লিখিত) | Numbering/Sequence | fn_assign_txn_no | — | First Vertical Slice | v0.2.2 |
| T27 | সক্রিয় (লিখিত) | Maker-Checker/অনুমোদন | rpc_approve | — | First Vertical Slice | v0.2.2 |
| T28 | সক্রিয় (লিখিত) | Correction/Reversal | rpc_request_correction, fn_execute_correction | — | First Vertical Slice | v0.2.2 |
| T29 | সক্রিয় (লিখিত) | Correction/Reversal | rpc_request_correction, fn_execute_correction | — | First Vertical Slice | v0.2.2 |
| T30 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit, fn_write_audit | — | Foundation | v0.2.2 |
| T31 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit, fn_write_audit | — | Foundation | v0.2.2 |
| T32 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit | — | Foundation | v0.2.2 |
| T33 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit, fn_write_audit | — | Foundation | v0.2.2 |
| T34 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit, fn_write_audit | — | Foundation | v0.2.2 |
| T35 | সক্রিয় (লিখিত) | নিরাপত্তা-ঘটনা/Permission | fn_has_permission | — | Foundation | v0.2.2 |
| T36 | সক্রিয় (লিখিত) | কোম্পানি-বিচ্ছিন্নতা/RLS | (RLS/Composite FK) | RLS | Foundation | v0.2.2 |
| T37 | সক্রিয় (লিখিত) | কোম্পানি-বিচ্ছিন্নতা/RLS | (RLS/Composite FK) | RLS | Foundation | v0.2.2 |
| T38 | সক্রিয় (লিখিত) | কোম্পানি-বিচ্ছিন্নতা/RLS | (RLS/Composite FK) | — | Foundation | v0.2.2 |
| T39 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.2 |
| T40 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.2 |
| T41 | সক্রিয় (লিখিত) | Auth/Session/MFA | rpc_get_my_permissions | — | Foundation | v0.2.2 |
| T42 | সক্রিয় (লিখিত) | Concurrency/Lock | (সব Class-B RPC) | — | First Vertical Slice | v0.2.2 |
| T43 | সক্রিয় (লিখিত) | কোম্পানি-বিচ্ছিন্নতা/RLS | (RLS/Composite FK) | RLS | Foundation | v0.2.2 |
| T44 | সক্রিয় (লিখিত) | Maker-Checker/অনুমোদন | rpc_approve | — | First Vertical Slice | v0.2.2 |
| T45 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit, fn_write_audit | — | Foundation | v0.2.2 |
| T46 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_declare_break_glass | — | Foundation | v0.2.2 |
| T47 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit, fn_write_audit | — | Foundation | v0.2.2 |
| T48 | সক্রিয় (লিখিত) | নিরাপত্তা-ঘটনা/Permission | fn_has_permission | — | Foundation | v0.2.2 |
| T49 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit, fn_write_audit | — | Foundation | v0.2.2 |
| T50 | সক্রিয় (লিখিত) | Correction/Reversal | rpc_post | — | First Vertical Slice | v0.2.2 |
| T51 | সক্রিয় (লিখিত) | Numbering/Sequence | fn_assign_txn_no | Unique | First Vertical Slice | v0.2.2 |
| T52 | সক্রিয় (লিখিত) | Maker-Checker/অনুমোদন | rpc_approve | — | First Vertical Slice | v0.2.2 |
| T53 | সক্রিয় (লিখিত) | Correction/Reversal | rpc_request_correction, fn_execute_correction | — | First Vertical Slice | v0.2.2 |
| T54 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit, fn_write_audit | — | Foundation | v0.2.2 |
| T55 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit, fn_write_audit | — | Foundation | v0.2.2 |
| T56 | সক্রিয় (লিখিত) | Correction/Reversal | rpc_request_correction, fn_execute_correction | — | First Vertical Slice | v0.2.2 |
| T57 | সক্রিয় (লিখিত) | Idempotency | (সব Class-B RPC) | — | First Vertical Slice | v0.2.2 |
| T58 | সক্রিয় (লিখিত) | Idempotency | (সব Class-B RPC) | — | First Vertical Slice | v0.2.2 |
| T59 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.2 |
| T60 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.2 |
| T61 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.2 |
| T62 | সক্রিয় (লিখিত) | Correction/Reversal | rpc_request_correction, fn_execute_correction | — | First Vertical Slice | v0.2.2 |
| T63 | সক্রিয় (লিখিত) | কোম্পানি-বিচ্ছিন্নতা/RLS | (RLS/Composite FK) | — | Foundation | v0.2.2 |
| T64 | সক্রিয় (লিখিত) | নিরাপত্তা-ঘটনা/Permission | fn_has_permission | — | Foundation | v0.2.2 |
| T65 | সক্রিয় (লিখিত) | Scope | fn_in_scope | — | Foundation | v0.2.2 |
| T66 | সক্রিয় (লিখিত) | State-যন্ত্র | (State-Trigger) | — | First Vertical Slice | v0.2.2 |
| T67 | সক্রিয় (লিখিত) | Maker-Checker/অনুমোদন | rpc_approve | — | First Vertical Slice | v0.2.3 |
| T68 | সক্রিয় (লিখিত) | Delegation | rpc_create_delegation | — | Later Wing | v0.2.3 |
| T69 | সক্রিয় (লিখিত) | Concurrency/Lock | (সব Class-B RPC) | — | First Vertical Slice | v0.2.3 |
| T70 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.3 |
| T71 | সক্রিয় (লিখিত) | Maker-Checker/অনুমোদন | rpc_approve | — | First Vertical Slice | v0.2.3 |
| T72 | সক্রিয় (লিখিত) | Scope | fn_in_scope | — | Foundation | v0.2.3 |
| T73 | সক্রিয় (লিখিত) | Concurrency/Lock | (সব Class-B RPC) | — | First Vertical Slice | v0.2.3 |
| T74 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit, fn_write_audit | — | Foundation | v0.2.3 |
| T75 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit, fn_write_audit | — | Foundation | v0.2.3 |
| T76 | সক্রিয় (লিখিত) | Idempotency | (সব Class-B RPC) | — | First Vertical Slice | v0.2.3 |
| T77 | সক্রিয় (লিখিত) | Group/Organization-জীবনচক্র | rpc_*_organization, rpc_group_override | — | Production Gate | v0.2.3 |
| T78 | সক্রিয় (লিখিত) | Correction/Reversal | rpc_request_correction, fn_execute_correction | — | First Vertical Slice | v0.2.3 |
| T79 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | Trigger | First Vertical Slice | v0.2.3 |
| T80 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.3 |
| T81 | সক্রিয় (লিখিত) | Concurrency/Lock | (সব Class-B RPC) | — | First Vertical Slice | v0.2.4 |
| T82 | সক্রিয় (লিখিত) | Concurrency/Lock | (সব Class-B RPC) | — | First Vertical Slice | v0.2.4 |
| T83 | সক্রিয় (লিখিত) | Maker-Checker/অনুমোদন | rpc_approve | — | First Vertical Slice | v0.2.4 |
| T84 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.4 |
| T85 | সক্রিয় (লিখিত) | কোম্পানি-বিচ্ছিন্নতা/RLS | (RLS/Composite FK) | Trigger, FK, Unique | Foundation | v0.2.4 |
| T86 | সক্রিয় (লিখিত) | Maker-Checker/অনুমোদন | rpc_approve | — | First Vertical Slice | v0.2.4 |
| T87 | সক্রিয় (লিখিত) | Concurrency/Lock | (সব Class-B RPC) | — | First Vertical Slice | v0.2.4 |
| T88 | সক্রিয় (লিখিত) | Idempotency | (সব Class-B RPC) | — | First Vertical Slice | v0.2.4 |
| T89 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.4 |
| T90 | সক্রিয় (লিখিত) | Correction/Reversal | rpc_create_replacement_draft | — | First Vertical Slice | v0.2.5 |
| T91 | সক্রিয় (লিখিত) | Period | rpc_post, (Period-ফাংশন) | — | First Vertical Slice | v0.2.5 |
| T92 | সক্রিয় (লিখিত) | Correction/Reversal | rpc_request_correction, fn_execute_correction | — | First Vertical Slice | v0.2.5 |
| T93 | সক্রিয় (লিখিত) | Correction/Reversal | rpc_request_correction, fn_execute_correction | — | First Vertical Slice | v0.2.5 |
| T94 | সক্রিয় (লিখিত) | কোম্পানি-বিচ্ছিন্নতা/RLS | (RLS/Composite FK) | — | Foundation | v0.2.5 |
| T95 | সক্রিয় (লিখিত) | কোম্পানি-বিচ্ছিন্নতা/RLS | (RLS/Composite FK) | FK | Foundation | v0.2.5 |
| T96 | সক্রিয় (লিখিত) | Group/Organization-জীবনচক্র | rpc_*_organization, rpc_group_override | — | Production Gate | v0.2.5 |
| T97 | সক্রিয় (লিখিত) | Concurrency/Lock | (সব Class-B RPC) | — | First Vertical Slice | v0.2.5 |
| T98 | সক্রিয় (লিখিত) | Group/Organization-জীবনচক্র | rpc_*_organization, rpc_group_override | FK | Production Gate | v0.2.5 |
| T99 | সক্রিয় (লিখিত) | Numbering/Sequence | fn_assign_txn_no | — | First Vertical Slice | v0.2.5 |
| T100 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit, fn_write_audit | — | Foundation | v0.2.5 |
| T101 | সক্রিয় (লিখিত) | Group/Organization-জীবনচক্র | rpc_create_organization | — | Production Gate | v0.2.5 |
| T102 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.5 |
| T103 | সক্রিয় (লিখিত) | Group/Organization-জীবনচক্র | rpc_approve | — | Production Gate | v0.2.6 |
| T104 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | Trigger | First Vertical Slice | v0.2.6 |
| T105 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | FK | First Vertical Slice | v0.2.6 |
| T106 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | FK | First Vertical Slice | v0.2.6 |
| T107 | সক্রিয় (লিখিত) | Scope | fn_in_scope | — | Foundation | v0.2.6 |
| T108 | সক্রিয় (লিখিত) | Maker-Checker/অনুমোদন | rpc_approve | — | First Vertical Slice | v0.2.6 |
| T109 | সক্রিয় (লিখিত) | Correction/Reversal | rpc_request_correction, fn_execute_correction | — | First Vertical Slice | v0.2.6 |
| T110 | সক্রিয় (লিখিত) | Group/Organization-জীবনচক্র | rpc_*_organization, rpc_group_override | — | Production Gate | v0.2.6 |
| T111 | সক্রিয় (লিখিত) | Delegation | rpc_create_delegation | — | Later Wing | v0.2.6 |
| T112 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit, fn_write_audit | — | Foundation | v0.2.6 |
| T113 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.6 |
| T114 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit, fn_write_audit | — | Foundation | v0.2.6 |
| T115 | সক্রিয় (লিখিত) | Auth/Session/MFA | rpc_get_my_permissions | — | Foundation | v0.2.6 |
| T116 | সক্রিয় (লিখিত) | Audit/Chain/Seal | rpc_verify_audit, fn_write_audit | Trigger, CHECK, FK | Foundation | v0.2.6 |
| T117 | সক্রিয় (লিখিত) | Group/Organization-জীবনচক্র | rpc_*_organization, rpc_group_override | — | Production Gate | v0.2.6 |
| T118 | সক্রিয় (লিখিত) | Correction/Reversal | rpc_request_correction, fn_execute_correction | — | First Vertical Slice | v0.2.6 |
| T119 | সক্রিয় (লিখিত) | কোম্পানি-বিচ্ছিন্নতা/RLS | (RLS/Composite FK) | — | Foundation | v0.2.6 |
| T120 | সক্রিয় (লিখিত) | Core-অন্যান্য | — | — | First Vertical Slice | v0.2.6 |
| T121 | **প্রত্যাহৃত** (→ T141) | Suspension/Company Status Lock | (পুরোনো প্রত্যাশা) | — | — | v0.2.7 |
| T122 | **প্রত্যাহৃত** (→ T142) | Suspension/Company Status Lock | (পুরোনো প্রত্যাশা) | — | — | v0.2.7 |
| T123 | **প্রত্যাহৃত** (→ T143) | Suspension/Company Status Lock | (পুরোনো প্রত্যাশা) | — | — | v0.2.7 |
| T124 | **প্রত্যাহৃত** (→ T147) | Suspension/Company Status Lock | (পুরোনো প্রত্যাশা) | — | — | v0.2.7 |
| T125 | সক্রিয় | Company Status Lock / Actor-Ownership / Group-Mirror / Period Lock | rpc_suspend_organization, rpc_approve (Group-পথ), rpc_post | Composite FK, Trigger | Production Gate | v0.2.7 |
| T126 | সক্রিয় | Company Status Lock / Actor-Ownership / Group-Mirror / Period Lock | rpc_suspend_organization, rpc_approve (Group-পথ), rpc_post | Composite FK, Trigger | Production Gate | v0.2.7 |
| T127 | সক্রিয় | Company Status Lock / Actor-Ownership / Group-Mirror / Period Lock | rpc_suspend_organization, rpc_approve (Group-পথ), rpc_post | Composite FK, Trigger | Production Gate | v0.2.7 |
| T128 | সক্রিয় | Company Status Lock / Actor-Ownership / Group-Mirror / Period Lock | rpc_suspend_organization, rpc_approve (Group-পথ), rpc_post | Composite FK, Trigger | Production Gate | v0.2.7 |
| T129 | সক্রিয় | Company Status Lock / Actor-Ownership / Group-Mirror / Period Lock | rpc_suspend_organization, rpc_approve (Group-পথ), rpc_post | Composite FK, Trigger | Production Gate | v0.2.7 |
| T130 | সক্রিয় | Company Status Lock / Actor-Ownership / Group-Mirror / Period Lock | rpc_suspend_organization, rpc_approve (Group-পথ), rpc_post | Composite FK, Trigger | Production Gate | v0.2.7 |
| T131 | সক্রিয় | Company Status Lock / Actor-Ownership / Group-Mirror / Period Lock | rpc_suspend_organization, rpc_approve (Group-পথ), rpc_post | Composite FK, Trigger | Production Gate | v0.2.7 |
| T132 | সক্রিয় | Company Status Lock / Actor-Ownership / Group-Mirror / Period Lock | rpc_suspend_organization, rpc_approve (Group-পথ), rpc_post | Composite FK, Trigger | Production Gate | v0.2.7 |
| T133 | **প্রত্যাহৃত** (→ T160) | Suspension/Company Status Lock | (পুরোনো প্রত্যাশা) | — | — | v0.2.7 |
| T134 | সক্রিয় | Company Status Lock / Actor-Ownership / Group-Mirror / Period Lock | rpc_suspend_organization, rpc_approve (Group-পথ), rpc_post | Composite FK, Trigger | Production Gate | v0.2.7 |
| T135 | সক্রিয়; T১৩৫–T১৪০-এর অংশ সংশোধিত (L4p) | Company Status Lock / Actor-Ownership / Group-Mirror / Period Lock | rpc_suspend_organization, rpc_approve (Group-পথ), rpc_post | Composite FK, Trigger | Production Gate | v0.2.7 |
| T136 | সক্রিয়; T১৩৫–T১৪০-এর অংশ সংশোধিত (L4p) | Company Status Lock / Actor-Ownership / Group-Mirror / Period Lock | rpc_suspend_organization, rpc_approve (Group-পথ), rpc_post | Composite FK, Trigger | Production Gate | v0.2.7 |
| T137 | সক্রিয়; T১৩৫–T১৪০-এর অংশ সংশোধিত (L4p) | Company Status Lock / Actor-Ownership / Group-Mirror / Period Lock | rpc_suspend_organization, rpc_approve (Group-পথ), rpc_post | Composite FK, Trigger | Production Gate | v0.2.7 |
| T138 | সক্রিয়; T১৩৫–T১৪০-এর অংশ সংশোধিত (L4p) | Company Status Lock / Actor-Ownership / Group-Mirror / Period Lock | rpc_suspend_organization, rpc_approve (Group-পথ), rpc_post | Composite FK, Trigger | Production Gate | v0.2.7 |
| T139 | সক্রিয়; T১৩৫–T১৪০-এর অংশ সংশোধিত (L4p) | Company Status Lock / Actor-Ownership / Group-Mirror / Period Lock | rpc_suspend_organization, rpc_approve (Group-পথ), rpc_post | Composite FK, Trigger | Production Gate | v0.2.7 |
| T140 | সক্রিয়; T১৩৫–T১৪০-এর অংশ সংশোধিত (L4p) | Company Status Lock / Actor-Ownership / Group-Mirror / Period Lock | rpc_suspend_organization, rpc_approve (Group-পথ), rpc_post | Composite FK, Trigger | Production Gate | v0.2.7 |
| T141 | সক্রিয় (Rev ২) | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T142 | সক্রিয় (Rev ২) | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T143 | সক্রিয় (Rev ২) | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T144 | সক্রিয় (Rev ২) | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T145 | সক্রিয় (Rev ২) | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T146 | সক্রিয় (Rev ২) | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T147 | সক্রিয় (Rev ২) | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T148 | সক্রিয় (Rev ২) | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T149 | সক্রিয় | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T150 | সক্রিয় | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T151 | সক্রিয় | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T152 | সক্রিয় | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T153 | সক্রিয় (সংশোধিত) | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T154 | সক্রিয় (সংশোধিত) | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T155 | সক্রিয় (সংশোধিত) | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T156 | সক্রিয় | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T157 | সক্রিয় | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T158 | সক্রিয় | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T159 | সক্রিয় | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T160 | সক্রিয় (T133-এর প্রতিস্থাপক) | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T161 | সক্রিয় | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T162 | সক্রিয় | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T163 | সক্রিয় | Suspension-Linearization / status_epoch / Period Freeze (L4p) / event_pairs | rpc_suspend_organization, svc_suspension_worker, rpc_post | CHECK, Unique, Trigger | Production Gate | v0.2.8 |
| T164 | সক্রিয় (Gate-সর্বজনীনতা) | Company Write Gate সর্বজনীনতা (Class-B/S) | svc_*, rpc_* (সব) | Privilege (service_role) | Production Gate | v0.2.9 |
| T165 | সক্রিয় (Gate-সর্বজনীনতা) | Company Write Gate সর্বজনীনতা (Class-B/S) | svc_*, rpc_* (সব) | Privilege (service_role) | Production Gate | v0.2.9 |
| T166 | সক্রিয় (Gate-সর্বজনীনতা) | Company Write Gate সর্বজনীনতা (Class-B/S) | svc_*, rpc_* (সব) | Privilege (service_role) | Production Gate | v0.2.9 |
| T167 | সক্রিয় (Gate-সর্বজনীনতা) | Company Write Gate সর্বজনীনতা (Class-B/S) | svc_*, rpc_* (সব) | Privilege (service_role) | Production Gate | v0.2.9 |
| T168 | সক্রিয় (Gate-সর্বজনীনতা) | Company Write Gate সর্বজনীনতা (Class-B/S) | svc_*, rpc_* (সব) | Privilege (service_role) | Production Gate | v0.2.9 |
| T169 | সক্রিয় (Gate-সর্বজনীনতা) | Company Write Gate সর্বজনীনতা (Class-B/S) | svc_*, rpc_* (সব) | Privilege (service_role) | Production Gate | v0.2.9 |
| T170 | সক্রিয় | Close বনাম Cross-period Correction (Blocker-Transition) | rpc_close_period, fn_execute_correction, rpc_create_replacement_draft | FK, Lock | Production Gate | v0.2.9 |
| T171 | সক্রিয় | Close বনাম Cross-period Correction (Blocker-Transition) | rpc_close_period, fn_execute_correction, rpc_create_replacement_draft | FK, Lock | Production Gate | v0.2.9 |
| T172 | সক্রিয় | Close বনাম Cross-period Correction (Blocker-Transition) | rpc_close_period, fn_execute_correction, rpc_create_replacement_draft | FK, Lock | Production Gate | v0.2.9 |
| T173 | সক্রিয় | Close বনাম Cross-period Correction (Blocker-Transition) | rpc_close_period, fn_execute_correction, rpc_create_replacement_draft | FK, Lock | Production Gate | v0.2.9 |
| T174 | সক্রিয় | Close বনাম Cross-period Correction (Blocker-Transition) | rpc_close_period, fn_execute_correction, rpc_create_replacement_draft | FK, Lock | Production Gate | v0.2.9 |
| T175 | সক্রিয় | Audit Pair-Integrity (event_pairs) | fn_write_group_event_pair | Trigger, Unique | Production Gate | v0.2.9 |
| T176 | সক্রিয় | Audit Pair-Integrity (event_pairs) | fn_write_group_event_pair | Trigger, Unique | Production Gate | v0.2.9 |
| T177 | সক্রিয় | Audit Pair-Integrity (event_pairs) | fn_write_group_event_pair | Trigger, Unique | Production Gate | v0.2.9 |
| T178 | সক্রিয় | Audit Pair-Integrity (event_pairs) | fn_write_group_event_pair | Trigger, Unique | Production Gate | v0.2.9 |
| T179 | সক্রিয় | Audit Pair-Integrity (event_pairs) | fn_write_group_event_pair | Trigger, Unique | Production Gate | v0.2.9 |
| T180 | সক্রিয় | Audit Pair-Integrity (event_pairs) | fn_write_group_event_pair | Trigger, Unique | Production Gate | v0.2.9 |
| T181 | সক্রিয় | Audit Pair-Integrity (event_pairs) | fn_write_group_event_pair | Trigger, Unique | Production Gate | v0.2.9 |
| T182 | সক্রিয় (মহড়া) | DR/BC (Restore, Failover, Offline) | Restore-Runbook (RPC নয়) | — | Production Gate | v0.2.9 |
| T183 | সক্রিয় (মহড়া) | DR/BC (Restore, Failover, Offline) | Restore-Runbook (RPC নয়) | — | Production Gate | v0.2.9 |
| T184 | সক্রিয় (মহড়া) | DR/BC (Restore, Failover, Offline) | Restore-Runbook (RPC নয়) | — | Production Gate | v0.2.9 |
| T185 | সক্রিয় (মহড়া) | DR/BC (Restore, Failover, Offline) | Restore-Runbook (RPC নয়) | — | Production Gate | v0.2.9 |
| T186 | সক্রিয় (মহড়া) | DR/BC (Restore, Failover, Offline) | Restore-Runbook (RPC নয়) | — | Production Gate | v0.2.9 |
| T187 | সক্রিয় (মহড়া) | DR/BC (Restore, Failover, Offline) | Restore-Runbook (RPC নয়) | — | Production Gate | v0.2.9 |
| T188 | সক্রিয় (মহড়া) | DR/BC (Restore, Failover, Offline) | Restore-Runbook (RPC নয়) | — | Production Gate | v0.2.9 |
| T189 | সক্রিয় (মহড়া) | DR/BC (Restore, Failover, Offline) | Restore-Runbook (RPC নয়) | — | Production Gate | v0.2.9 |
| T190 | সক্রিয় (মহড়া) | DR/BC (Restore, Failover, Offline) | Restore-Runbook (RPC নয়) | — | Production Gate | v0.2.9 |
| T191 | সক্রিয় (মহড়া) | DR/BC (Restore, Failover, Offline) | Restore-Runbook (RPC নয়) | — | Production Gate | v0.2.9 |
| T192 | সক্রিয় (মহড়া) | DR/BC (Restore, Failover, Offline) | Restore-Runbook (RPC নয়) | — | Production Gate | v0.2.9 |
| T193 | সক্রিয় (মহড়া) | DR/BC (Restore, Failover, Offline) | Restore-Runbook (RPC নয়) | — | Production Gate | v0.2.9 |
| T194 | সক্রিয় (মহড়া) | DR/BC (Restore, Failover, Offline) | Restore-Runbook (RPC নয়) | — | Production Gate | v0.2.9 |
| T195 | সক্রিয় (মহড়া) | DR/BC (Restore, Failover, Offline) | Restore-Runbook (RPC নয়) | — | Production Gate | v0.2.9 |
| T196 | সক্রিয় (মহড়া) | ইতিহাস-সংরক্ষণ (Retention, Archive) | svc_archive (পরিকল্পিত) | — | Production Gate | v0.2.9 |
| T197 | সক্রিয় (মহড়া) | ইতিহাস-সংরক্ষণ (Retention, Archive) | svc_archive (পরিকল্পিত) | — | Production Gate | v0.2.9 |
| T198 | সক্রিয় (মহড়া) | ইতিহাস-সংরক্ষণ (Retention, Archive) | svc_archive (পরিকল্পিত) | — | Production Gate | v0.2.9 |
| T199 | সক্রিয় (মহড়া) | ইতিহাস-সংরক্ষণ (Retention, Archive) | svc_archive (পরিকল্পিত) | — | Production Gate | v0.2.9 |
| T200 | সক্রিয় (মহড়া) | ইতিহাস-সংরক্ষণ (Retention, Archive) | svc_archive (পরিকল্পিত) | — | Production Gate | v0.2.9 |
| T201 | সক্রিয় (মহড়া) | ইতিহাস-সংরক্ষণ (Retention, Archive) | svc_archive (পরিকল্পিত) | — | Production Gate | v0.2.9 |
| T202 | সক্রিয় (মহড়া) | ইতিহাস-সংরক্ষণ (Retention, Archive) | svc_archive (পরিকল্পিত) | — | Production Gate | v0.2.9 |
| T203 | সক্রিয় (মহড়া) | ইতিহাস-সংরক্ষণ (Retention, Archive) | svc_archive (পরিকল্পিত) | — | Production Gate | v0.2.9 |
| T204 | **সংশোধন-প্রয়োজন** (ছয়-অবস্থা; T216–T240-এর সাথে একীকরণ বাকি) | Handover (Discovery) | rpc_handover_* | — | Manufacturing | v0.2.9 |
| T205 | **সংশোধন-প্রয়োজন** (ছয়-অবস্থা; T216–T240-এর সাথে একীকরণ বাকি) | Handover (Discovery) | rpc_handover_* | — | Manufacturing | v0.2.9 |
| T206 | **সংশোধন-প্রয়োজন** (ছয়-অবস্থা; T216–T240-এর সাথে একীকরণ বাকি) | Handover (Discovery) | rpc_handover_* | — | Manufacturing | v0.2.9 |
| T207 | **সংশোধন-প্রয়োজন** (ছয়-অবস্থা; T216–T240-এর সাথে একীকরণ বাকি) | Handover (Discovery) | rpc_handover_* | — | Manufacturing | v0.2.9 |
| T208 | **সংশোধন-প্রয়োজন** (ছয়-অবস্থা; T216–T240-এর সাথে একীকরণ বাকি) | Handover (Discovery) | rpc_handover_* | — | Manufacturing | v0.2.9 |
| T209 | **সংশোধন-প্রয়োজন** (ছয়-অবস্থা; T216–T240-এর সাথে একীকরণ বাকি) | Handover (Discovery) | rpc_handover_* | — | Manufacturing | v0.2.9 |
| T210 | **সংশোধন-প্রয়োজন** (ছয়-অবস্থা; T216–T240-এর সাথে একীকরণ বাকি) | Handover (Discovery) | rpc_handover_* | — | Manufacturing | v0.2.9 |
| T211 | **সংশোধন-প্রয়োজন** (ছয়-অবস্থা; T216–T240-এর সাথে একীকরণ বাকি) | Handover (Discovery) | rpc_handover_* | — | Manufacturing | v0.2.9 |
| T212 | **সংশোধন-প্রয়োজন** (ছয়-অবস্থা; T216–T240-এর সাথে একীকরণ বাকি) | Handover (Discovery) | rpc_handover_* | — | Manufacturing | v0.2.9 |
| T213 | **সংশোধন-প্রয়োজন** (ছয়-অবস্থা; T216–T240-এর সাথে একীকরণ বাকি) | Handover (Discovery) | rpc_handover_* | — | Manufacturing | v0.2.9 |
| T214 | **সংশোধন-প্রয়োজন** (ছয়-অবস্থা; T216–T240-এর সাথে একীকরণ বাকি) | Handover (Discovery) | rpc_handover_* | — | Manufacturing | v0.2.9 |
| T215 | **সংশোধন-প্রয়োজন** (ছয়-অবস্থা; T216–T240-এর সাথে একীকরণ বাকি) | Handover (Discovery) | rpc_handover_* | — | Manufacturing | v0.2.9 |
| T216 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T217 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T218 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T219 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T220 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T221 | সক্রিয় | Live Authorization/Revocation | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Foundation | Succession |
| T222 | সক্রিয় | Live Authorization/Revocation | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Foundation | Succession |
| T223 | সক্রিয় | Live Authorization/Revocation | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Foundation | Succession |
| T224 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T225 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T226 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T227 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T228 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T229 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T230 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T231 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T232 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T233 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T234 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T235 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T236 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T237 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T238 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T239 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T240 | সক্রিয় | Staff Succession | rpc_handover_*, rpc_terminate_employee, rpc_declare_break_glass | Exclusion, Trigger | Manufacturing | Succession |
| T241 | সক্রিয় | Universal QR | api.v1_qr_* | — | First Vertical Slice | QR/Action Spec |
| T242 | সক্রিয় | Universal QR | api.v1_qr_* | — | First Vertical Slice | QR/Action Spec |
| T243 | সক্রিয় | Universal QR | api.v1_qr_* | — | First Vertical Slice | QR/Action Spec |
| T244 | সক্রিয় | Universal QR | api.v1_qr_* | — | Later Wing | QR/Action Spec |
| T245 | সক্রিয় | Universal QR | api.v1_qr_* | — | First Vertical Slice | QR/Action Spec |
| T246 | সক্রিয় | Universal QR | api.v1_qr_* | — | First Vertical Slice | QR/Action Spec |
| T247 | সক্রিয় | Universal QR | api.v1_qr_* | — | First Vertical Slice | QR/Action Spec |
| T248 | সক্রিয় | Universal QR | api.v1_qr_* | — | First Vertical Slice | QR/Action Spec |
| T249 | সক্রিয় | Universal QR | api.v1_qr_* | — | Later Wing | QR/Action Spec |
| T250 | সক্রিয় | Universal QR | api.v1_qr_* | — | Later Wing | QR/Action Spec |
| T251 | সক্রিয় | Universal QR | api.v1_qr_* | — | Later Wing | QR/Action Spec |
| T252 | সক্রিয় | Universal QR | api.v1_qr_* | — | Later Wing | QR/Action Spec |
| T253 | সক্রিয় | Universal QR | api.v1_qr_* | — | Later Wing | QR/Action Spec |
| T254 | সক্রিয় | Universal QR | api.v1_qr_* | — | Later Wing | QR/Action Spec |
| T255 | সক্রিয় | Universal QR | api.v1_qr_* | — | Later Wing | QR/Action Spec |
| T256 | সক্রিয় | Universal QR | api.v1_qr_* | — | First Vertical Slice | QR/Action Spec |
| T257 | সক্রিয় | উপস্থিতি-Kiosk | api.v1_record_attendance_scan | — | Later Wing | QR/Action Spec |
| T258 | সক্রিয় | উপস্থিতি-Kiosk | api.v1_record_attendance_scan | — | Later Wing | QR/Action Spec |
| T259 | সক্রিয় | উপস্থিতি-Kiosk | api.v1_record_attendance_scan | — | Later Wing | QR/Action Spec |
| T260 | সক্রিয় | উপস্থিতি-Kiosk | api.v1_record_attendance_scan | — | Later Wing | QR/Action Spec |
| T261 | সক্রিয় | উপস্থিতি-Kiosk | api.v1_record_attendance_scan | — | Later Wing | QR/Action Spec |
| T262 | সক্রিয় | উপস্থিতি-Kiosk | api.v1_record_attendance_scan | — | Later Wing | QR/Action Spec |
| T263 | সক্রিয় | উপস্থিতি-Kiosk | api.v1_record_attendance_scan | — | Later Wing | QR/Action Spec |
| T264 | সক্রিয় | উপস্থিতি-Kiosk | api.v1_record_attendance_scan | — | Later Wing | QR/Action Spec |
| T265 | সক্রিয় | Action Menu (⋮) | api.v1_get_available_actions | — | First Vertical Slice | QR/Action Spec |
| T266 | সক্রিয় | Action Menu (⋮) | api.v1_get_available_actions | — | First Vertical Slice | QR/Action Spec |
| T267 | সক্রিয় | Action Menu (⋮) | api.v1_get_available_actions | — | First Vertical Slice | QR/Action Spec |
| T268 | সক্রিয় | Action Menu (⋮) | api.v1_get_available_actions | — | First Vertical Slice | QR/Action Spec |
| T269 | সক্রিয় | Action Menu (⋮) | api.v1_get_available_actions | — | First Vertical Slice | QR/Action Spec |
| T270 | সক্রিয় | Action Menu (⋮) | api.v1_get_available_actions | — | First Vertical Slice | QR/Action Spec |
| T271 | সক্রিয় | Action Menu (⋮) | api.v1_get_available_actions | — | First Vertical Slice | QR/Action Spec |
| T272 | সক্রিয় | Action Menu (⋮) | api.v1_get_available_actions | — | Later Wing | QR/Action Spec |
| T273 | সক্রিয় | Visual Sharing/Export | api.v1_create_export_snapshot | — | First Vertical Slice | QR/Action Spec |
| T274 | সক্রিয় | Visual Sharing/Export | api.v1_create_export_snapshot | — | First Vertical Slice | QR/Action Spec |
| T275 | সক্রিয় | Visual Sharing/Export | api.v1_create_export_snapshot | — | Later Wing | QR/Action Spec |
| T276 | সক্রিয় | Visual Sharing/Export | api.v1_create_export_snapshot | — | Later Wing | QR/Action Spec |
| T277 | সক্রিয় | Visual Sharing/Export | api.v1_create_export_snapshot | — | First Vertical Slice | QR/Action Spec |
| T278 | সক্রিয় | Visual Sharing/Export | api.v1_create_export_snapshot | — | First Vertical Slice | QR/Action Spec |
| T279 | সক্রিয় | Visual Sharing/Export | api.v1_create_export_snapshot | — | First Vertical Slice | QR/Action Spec |
| T280 | সক্রিয় | Visual Sharing/Export | api.v1_create_export_snapshot | — | Later Wing | QR/Action Spec |
| T281 | সক্রিয় | Visual Sharing/Export | api.v1_create_export_snapshot | — | Later Wing | QR/Action Spec |
| T282 | সক্রিয় | Visual Sharing/Export | api.v1_create_export_snapshot | — | Later Wing | QR/Action Spec |
| T283 | সক্রিয় | Visual Sharing/Export | api.v1_create_export_snapshot | — | Later Wing | QR/Action Spec |
| T284 | সক্রিয় | Visual Sharing/Export | api.v1_create_export_snapshot | — | Later Wing | QR/Action Spec |
| T285 | সক্রিয় | Visual Sharing/Export | api.v1_create_export_snapshot | — | Later Wing | QR/Action Spec |
| T286 | সক্রিয় | Contact | api.v1_get_contact_channels | — | Later Wing | QR/Action Spec |
| T287 | সক্রিয় | Contact | api.v1_get_contact_channels | — | Later Wing | QR/Action Spec |
| T288 | সক্রিয় | Contact | api.v1_get_contact_channels | — | Later Wing | QR/Action Spec |
| T289 | সক্রিয় | Contact | api.v1_get_contact_channels | — | Later Wing | QR/Action Spec |
| T290 | সক্রিয় | Contact | api.v1_get_contact_channels | — | Later Wing | QR/Action Spec |
| T291 | সক্রিয় (নতুন; Readiness Report §৯.২) | লেনদেনের ভারসাম্য (Σডেবিট = Σক্রেডিট) | finance.ledger_entries, rpc_post | Deferred Check | First Vertical Slice | Final Audit |
| T292 | সক্রিয় (নতুন; Readiness Report §৯.২) | Reversal ঠিক বিপরীত; মূল সারি অপরিবর্তিত | fn_execute_correction | Append-only | First Vertical Slice | Final Audit |
| T293 | সক্রিয় (নতুন; Readiness Report §৯.২) | Balance-পুনর্গণনা মিল | svc/Job, finance.account_balances | — | First Vertical Slice | Final Audit |
| T294 | সক্রিয় (নতুন; Readiness Report §৯.২) | রিপোর্ট-যথার্থতা (Cash Book/Trial Balance) | rpc_get_cash_book, rpc_get_trial_balance | — | First Vertical Slice | Final Audit |
| T295 | সক্রিয় (নতুন; Readiness Report §৯.২) | Posting-এর একক পথ (সরাসরি Ledger-Insert প্রত্যাখ্যাত) | rpc_post | Privilege/RLS | First Vertical Slice | Final Audit |
| T296 | সক্রিয় (নতুন; Readiness Report §৯.২) | Exactly-once (পুনরাবৃত্তি ও সমান্তরাল Post) | rpc_post | Unique (txn_id, entry_no) | First Vertical Slice | Final Audit |
| T297 | সক্রিয় (নতুন; Readiness Report §৯.২) | Period-নিয়ম (বন্ধ/অবৈধ তারিখ) | rpc_post | FK, CHECK | First Vertical Slice | Final Audit |
| T298 | সক্রিয় (নতুন; Readiness Report §৯.২) | E2E প্রবাহ Login→Report | সব Slice-RPC | — | First Vertical Slice | Final Audit |
| T299 | সক্রিয় (নতুন; Readiness Report §৯.২) | MD-only Factory P&L | rpc (fin.report.factory_pl) | RLS | Production Gate | Final Audit |
| T300 | সক্রিয় (নতুন, OD/Audit; Executed (Python, স্থানীয়)) | OD-01: Reviewer-অনির্ধারিত বা Approval-রেকর্ড-হীন হলে Production Release BLOCKED | scripts/check_release_gate.py | Release Gate | Production Gate | Owner Decision/Audit |
| T301 | সক্রিয় (নতুন, OD/Audit; Executed (Python, স্থানীয়)) | OD-01: Developer নিজে Reviewer হতে পারে না | check_release_gate.py | Release Gate | Production Gate | Owner Decision/Audit |
| T302 | সক্রিয় (নতুন, OD/Audit; Executed (Python, স্থানীয়)) | OD-01: Evidence/Commit/Tag-অমিল ও Owner-অনুমোদনহীন Emergency প্রত্যাখ্যাত | check_release_gate.py | Release Gate | Production Gate | Owner Decision/Audit |
| T303 | সক্রিয় (নতুন, OD/Audit; SQL লেখা) | OD-02: এক ব্যক্তি = দুই কোম্পানিতে আলাদা Employee/Account/Auth-পরিচয়; অমিল প্রত্যাখ্যাত | core.employee_accounts | Composite FK, Unique | Foundation | Owner Decision/Audit |
| T304 | সক্রিয় (নতুন, OD/Audit; স্পেক; কোড নেই (Spike S3-সংলগ্ন)) | OD-02: কোম্পানি A-র Login দিয়ে B-র ডেটা পড়া/বদলানো অসম্ভব (RLS+RPC, বাস্তব Login) | api.v1_* | RLS | Foundation | Owner Decision/Audit |
| T305 | সক্রিয় (নতুন, OD/Audit; SQL লেখা (অবস্থা-স্তরে আংশিক)) | OD-02: A-র Account Suspend/Terminate হলে B-র Account অক্ষত | core.employee_accounts | — | Foundation | Owner Decision/Audit |
| T306 | সক্রিয় (নতুন, OD/Audit; SQL লেখা) | OD-02: কোম্পানি-মধ্যবর্তী Role-Grant অসম্ভব | core.user_roles | Composite FK | Foundation | Owner Decision/Audit |
| T307 | সক্রিয় (নতুন, OD/Audit; SQL লেখা) | OD-03: কোম্পানি-মধ্যবর্তী Ledger Posting Database-এ প্রত্যাখ্যাত | finance.ledger_entries | Composite FK | First Vertical Slice | Owner Decision/Audit |
| T308 | সক্রিয় (নতুন, OD/Audit; স্পেক; Inventory-সারণি নেই) | OD-03: কোম্পানি-মধ্যবর্তী Stock Transfer প্রত্যাখ্যাত | Inventory RPC | Composite FK | Manufacturing | Owner Decision/Audit |
| T309 | সক্রিয় (নতুন, OD/Audit; স্পেক; `parties` Migration-এ নেই) | OD-03: কোম্পানি-মধ্যবর্তী Payment/Collection Adjustment প্রত্যাখ্যাত (অন্য কোম্পানির Party) | Party/Collection RPC | Composite FK | Later Wing | Owner Decision/Audit |
| T310 | সক্রিয় (নতুন, OD/Audit; স্পেক; কোড নেই) | OD-03: সরাসরি REST/RPC-এ ভিনকোম্পানির ID পাঠালে `E_SCOPE` (UI-নিরপেক্ষ) | api.v1_* (সব) | RLS, FK | First Vertical Slice | Owner Decision/Audit |
| T311 | সক্রিয় (নতুন, OD/Audit; SQL লেখা) | OD-04: Role-Registry ঠিক ১৭টি অনুমোদিত নাম | core.roles | — | Foundation | Owner Decision/Audit |
| T312 | সক্রিয় (নতুন, OD/Audit; SQL লেখা) | OD-04: TECH_ADMIN-এর Business-ডেটা-Permission নেই | core.role_permissions | — | Foundation | Owner Decision/Audit |
| T313 | সক্রিয় (নতুন, OD/Audit; SQL লেখা) | OD-04: Factory P&L Permission শুধু MD-র | core.role_permissions | — | Foundation | Owner Decision/Audit |
| T314 | সক্রিয় (নতুন, OD/Audit; SQL লেখা) | OD-04: Wing-স্থানধারক ও Break-glass Permission `active` নয় | core.permissions | CHECK | Foundation | Owner Decision/Audit |
| T315 | সক্রিয় (নতুন, OD/Audit; স্পেক; কোড নেই) | OD-04: UI-বাইপাস: Permission-ছাড়া সরাসরি RPC → `E_PERM` | api.v1_* (সব) | — | First Vertical Slice | Owner Decision/Audit |
| T316 | সক্রিয় (নতুন, OD/Audit; SQL লেখা) | Audit: ৩-সারির Chain যাচাই পাস | core.fn_verify_audit_chain | — | Foundation | Owner Decision/Audit |
| T317 | সক্রিয় (নতুন, OD/Audit; SQL লেখা) | Audit: UPDATE প্রত্যাখ্যাত | core.audit_logs | Trigger | Foundation | Owner Decision/Audit |
| T318 | সক্রিয় (নতুন, OD/Audit; SQL লেখা) | Audit: DELETE প্রত্যাখ্যাত | core.audit_logs | Trigger | Foundation | Owner Decision/Audit |
| T319 | সক্রিয় (নতুন, OD/Audit; SQL লেখা) | Audit: ছদ্ম-বদল Verifier ধরে | core.fn_verify_audit_chain | — | Foundation | Owner Decision/Audit |

## গণনা (২০২৬-১১-০৪; স্ক্রিপ্টে পুনর্গণিত)

| বিভাগ | সংখ্যা |
| --- | --- |
| মোট লিখিত Test (T০১–T৩১৯) | **319** |
| সক্রিয় (Active) | **302** |
| সংশোধন-প্রয়োজন (T২০৪–T২১৫) | **12** |
| প্রত্যাহৃত/Superseded (T১২১, T১২২, T১২৩, T১২৪, T১৩৩) | **5** |
| নতুন: T২৯১–T২৯৯ (Audit-রিপোর্ট) | ৯ |
| নতুন: T৩০০–T৩১৯ (OD-০১–০৪, Audit-Chain) | ২০ |
| মূল T০১–T২৯০ | ২৯০ (সক্রিয় ২৭৩, সংশোধন-প্রয়োজন ১২, প্রত্যাহৃত ৫) |
| **Executable কোড লেখা** | T২৯১, T২৯৫, T৩০০–T৩০২, T৩০৩, T৩০৫ (আংশিক), T৩০৬, T৩০৭, T৩১১–T৩১৪, T৩১৬–T৩১৯ = **১৭** |
| **বাস্তবে চালানো** | **৩** (T৩০০–T৩০২: Release-Gate Python-Script, স্থানীয়; ১২টি Unit-Case সব পাস; Log: `docs/EVIDENCE/release_gate_tests_*.log`) |
| PostgreSQL/Supabase-এ চালানো | **০** (এই পরিবেশে PostgreSQL/Supabase-প্রবেশ নেই) |
| Milestone-ভাগ | First Vertical Slice: 97, Foundation: 54, Later Wing: 35, Manufacturing: 35, Production Gate: 93, —: 5 |