# Appendix F — Role × Permission × Scope × Action ম্যাট্রিক্স (Proposed)

> **অবস্থা: ১৭টি Role ও এই প্রাথমিক Matrix OWNER APPROVED (OD-০৪, ২০২৬-১১-০৪)।** Role Name ও Role ID (`role_code`) স্থিতিশীল। Matrix = প্রাথমিক Authoritative Reference। Role-নিয়ন্ত্রণ Backend RPC, RLS ও Live Authorization-এ; শুধু Android UI-তে নয়। **অনুমোদিত নয়:** EMERGENCY_ADMIN/Break-glass-এর অসম্পূর্ণ নীতি; Wing-স্থানধারক Permission (Mfg/Procurement/Sales/Inventory) সংশ্লিষ্ট Wing-এর Design ও Test ছাড়া **চালু (`active`) করা যাবে না** (Seed-এ `registered`)। প্রথম Slice-এ শুধু ২০টি প্রয়োজনীয় Permission `active`; বাকি ৩৮টি Registry-তে। **Implementation:** Seed Migration লেখা হয়েছে, চালানো হয়নি। Scope-কোড: **G** Group, **O** কোম্পানি, **W** Wing, **D** বিভাগ, **L** Location/Container, **A** নির্ধারিত (Assigned), **S** নিজে।

## অলঙ্ঘনীয় নিয়ম (Owner-confirmed বা বিদ্যমান সিদ্ধান্ত)

1. **Maker ≠ Approver** ও **No-Self-Approval**; Poster আলাদা ধাপ (Proposed #২১)।
2. **Factory P&L শুধু কোম্পানির MD** (#১৩); Chairman, Finance, Wing-প্রধান, Tech Admin — কারও নয়; হস্তান্তর/Delegation যোগ্য নয়।
3. **কোম্পানি-বিচ্ছিন্নতা:** কোনো Role অন্য কোম্পানি দেখে না; Chairman Group-স্তরের নির্ধারিত অধিকারে (Group-পথ)।
4. **Live Authorization:** Role/Scope Token-এ নয়; প্রতিটি RPC ও RLS Live-যাচাই।
5. **Tech Admin ও Chairman-এর Posting-অধিকার নেই** (প্রস্তাব); Tech Admin Business-ডেটা পড়ে না।
6. **Auditor** শুধু পাঠ ও যাচাই।
7. সংবেদনশীল (S) Permission-এ `aal2`, কারণ ও Audit।

## Permission-ক্যাটালগ

| Permission | Domain | ধরন | নোট |
| --- | --- | --- | --- |
| `iam.user.create` | IAM | সংবেদনশীল | Account তৈরি; Maker-Checker |
| `iam.role.assign` | IAM | সংবেদনশীল | Role-প্রদান; Maker-Checker; aal2 |
| `iam.override.set` | IAM | সংবেদনশীল | Permission-Override; aal2; কারণ |
| `approval.rule.manage` | Approval | সংবেদনশীল | Rule-Version প্রকাশ; aal2 |
| `approval.view` | Approval | সাধারণ | নিজের Scope |
| `approval.approve` | Approval | সাধারণ | Approver-Snapshot-সদস্য; Maker≠Approver |
| `approval.override` | Approval | সংবেদনশীল | aal2; কারণ; MD-কে বিজ্ঞপ্তি |
| `approval.delegate` | Approval | সংবেদনশীল | Group-Authority নয় |
| `approval.reassign` | Approval | সংবেদনশীল | Maker-Checker; Approve নয় |
| `txn.create` | Txn | সাধারণ | Draft; Maker |
| `txn.submit` | Txn | সাধারণ | Maker |
| `txn.view` | Txn | সাধারণ | Scope |
| `txn.post` | Txn | সাধারণ | আলাদা Post-ধাপ (#২১); Poster |
| `txn.correct.request` | Txn | সাধারণ | Posted-লেনদেনে |
| `correction.approve` | Txn | সংবেদনশীল | Reversal-অনুমোদন; Replacement আলাদা approval.approve (F৪) |
| `fin.cash.view` | Finance | সাধারণ | Cashbox/Ledger দেখা |
| `fin.report.view` | Finance | সাধারণ | সাধারণ রিপোর্ট |
| `fin.report.factory_pl` | Finance | সংবেদনশীল | **শুধু MD (#১৩); অ-হস্তান্তরযোগ্য** |
| `fin.period.close` | Finance | সংবেদনশীল | aal2; Close-Blocker-যাচাই |
| `fin.period.reopen` | Finance | সংবেদনশীল | aal2; #৬১ Pending |
| `inv.view` | Inventory | সাধারণ |  |
| `inv.receive` | Inventory | সাধারণ | GRN/Receipt-Draft |
| `inv.issue` | Inventory | সাধারণ | Issue-Draft |
| `inv.count` | Inventory | সাধারণ | গণনা-Draft |
| `inv.adjust` | Inventory | সংবেদনশীল | স্বয়ংক্রিয় নয়; Variance-পথে |
| `mfg.bom.manage` | Mfg | সংবেদনশীল | Wing-ডিজাইন বাকি |
| `mfg.order.manage` | Mfg | সাধারণ | Wing-ডিজাইন বাকি |
| `mfg.qc.record` | Mfg | সাধারণ | Wing-ডিজাইন বাকি |
| `proc.po.manage` | Procurement | সাধারণ | Wing-ডিজাইন বাকি |
| `sales.order.manage` | Sales | সাধারণ | Wing-ডিজাইন বাকি |
| `sales.collection.create` | Sales | সাধারণ | Collection-Draft |
| `party.view` | Party | সাধারণ | Dealer/Retailer/Supplier |
| `party.edit` | Party | সাধারণ | Audit-ভুক্ত |
| `hr.employee.view` | HR | সাধারণ | ব্যক্তিগত-তথ্য সীমিত |
| `hr.employee.edit` | HR | সাধারণ |  |
| `hr.employee.terminate` | HR | সংবেদনশীল | Termination; তাৎক্ষণিক Access-কর্তন একক Authority; পরে অনুমোদন |
| `hr.assignment.manage` | HR | সংবেদনশীল | Assignment/Handover-শুরু |
| `hr.handover.approve` | HR | সংবেদনশীল | Approver ∉ {পুরোনো, নতুন, জড়িত Supervisor} |
| `hr.attendance.view` | HR | সাধারণ |  |
| `hr.attendance.manual` | HR | সংবেদনশীল | কারণ + Maker-Checker; নিজের নয় |
| `custody.accept` | HR | সাধারণ | Handover-গ্রহণ (উত্তরসূরি) |
| `variance.investigate` | Audit | সংবেদনশীল | স্বাধীন তদন্তকারী |
| `variance.resolve.approve` | Audit | সংবেদনশীল | Liability Gate-সহ |
| `audit.view` | Audit | সাধারণ |  |
| `audit.verify` | Audit | সাধারণ |  |
| `qr.view` | QR | সাধারণ |  |
| `qr.issue` | QR | সংবেদনশীল | ID Card ইস্যু HR-অনুমোদিত |
| `qr.revoke` | QR | সংবেদনশীল |  |
| `qr.print` | QR | সাধারণ |  |
| `export.share` | Export | সাধারণ | Export-নীতি ও Mask-প্রোফাইল |
| `export.pdf` | Export | সাধারণ |  |
| `export.print` | Export | সাধারণ |  |
| `contact.view` | Contact | সাধারণ | Visibility-শ্রেণি |
| `contact.edit` | Contact | সাধারণ | Audit |
| `history.view` | Core | সাধারণ |  |
| `break_glass.declare` | Emergency | সংবেদনশীল | দ্বৈত-নিয়ন্ত্রণ; সময়-বদ্ধ; (#১৬; O২৫) |
| `sys.deploy` | System | সংবেদনশীল | Business-ডেটা-প্রবেশ নেই; Deploy-পর্যালোচনা (#৪৬) |
| `sys.settings.manage` | System | সংবেদনশীল | Audit-ভুক্ত |

## Role-ভিত্তিক Permission ও Scope

### CHAIRMAN — Owner-confirmed (Group)
Group-স্তরে; কোম্পানির Factory P&L নয়

| Permission | Scope/শর্ত |
| --- | --- |
| `iam.user.create` | G |
| `iam.role.assign` | G |
| `approval.rule.manage` | G |
| `approval.view` | G |
| `approval.approve` | G (group_step) |
| `approval.override` | G (group_override) |
| `approval.delegate` | G (অ-হস্তান্তরযোগ্য) |
| `hr.employee.terminate` | G |
| `audit.view` | G |
| `audit.verify` | G |
| `fin.report.view` | G |
| `txn.view` | G |
| `party.view` | G |
| `history.view` | G |

### MD — Owner-confirmed (প্রতি কোম্পানি)
কোম্পানি-স্তর; একমাত্র Factory P&L-দর্শক

| Permission | Scope/শর্ত |
| --- | --- |
| `iam.user.create` | O |
| `iam.role.assign` | O |
| `approval.rule.manage` | O |
| `approval.view` | O |
| `approval.approve` | O |
| `approval.override` | O |
| `approval.delegate` | O |
| `approval.reassign` | O |
| `correction.approve` | O |
| `hr.employee.view` | O |
| `hr.employee.terminate` | O |
| `hr.assignment.manage` | O |
| `hr.handover.approve` | O |
| `fin.report.view` | O |
| `fin.report.factory_pl` | O (একমাত্র) |
| `fin.period.close` | O |
| `fin.period.reopen` | O (#৬১) |
| `txn.view` | O |
| `inv.view` | O |
| `party.view` | O |
| `audit.view` | O |
| `break_glass.declare` | O (দ্বৈত) |
| `variance.resolve.approve` | O |
| `qr.view` | O |
| `export.share` | O |
| `export.pdf` | O |
| `contact.view` | O |
| `history.view` | O |

### WING_HEAD — Proposed
Wing/বিভাগ-প্রধান (যেমন Factory Manager)

| Permission | Scope/শর্ত |
| --- | --- |
| `txn.create` | W |
| `txn.submit` | W |
| `txn.view` | W |
| `approval.view` | W |
| `approval.approve` | W (Rule-ভিত্তিক) |
| `inv.view` | W |
| `inv.adjust` | — |
| `mfg.order.manage` | W |
| `hr.employee.view` | W (সীমিত) |
| `hr.attendance.view` | W |
| `party.view` | W |
| `qr.view` | W |
| `export.share` | W |
| `export.pdf` | W |
| `contact.view` | W |
| `history.view` | W |

### FIN_MANAGER — Proposed
Finance-প্রধান

| Permission | Scope/শর্ত |
| --- | --- |
| `txn.view` | O |
| `approval.view` | O |
| `approval.approve` | O (Rule-ভিত্তিক) |
| `txn.post` | O |
| `correction.approve` | O (Rule-ভিত্তিক) |
| `fin.cash.view` | O |
| `fin.report.view` | O (Factory P&L বাদে) |
| `fin.period.close` | O (প্রস্তাব: MD-এর সাথে) |
| `party.view` | O |
| `variance.investigate` | O (স্বাধীন হলে) |
| `qr.view` | O |
| `export.share` | O |
| `export.pdf` | O |
| `export.print` | O |
| `contact.view` | O |
| `history.view` | O |

### ACCOUNTANT — Proposed (Poster)
Posting-ধাপ

| Permission | Scope/শর্ত |
| --- | --- |
| `txn.create` | O/W |
| `txn.submit` | O/W |
| `txn.post` | O/W |
| `txn.view` | O/W |
| `fin.cash.view` | O/W |
| `party.view` | O |
| `qr.view` | O/W |
| `export.pdf` | O/W |
| `export.print` | O/W |
| `history.view` | O/W |

### CASHIER — Proposed
নগদ-হেফাজতকারী (Container-বদ্ধ)

| Permission | Scope/শর্ত |
| --- | --- |
| `txn.create` | L (নিজের Cashbox) |
| `txn.submit` | L |
| `txn.view` | L |
| `fin.cash.view` | L |
| `custody.accept` | L |
| `qr.view` | L |
| `export.print` | L (Receipt) |
| `history.view` | L |

### HR_OFFICER — Proposed


| Permission | Scope/শর্ত |
| --- | --- |
| `hr.employee.view` | O |
| `hr.employee.edit` | O |
| `hr.assignment.manage` | O (Maker) |
| `hr.attendance.view` | O |
| `hr.attendance.manual` | O (Maker) |
| `qr.issue` | O (ID Card) |
| `qr.revoke` | O |
| `qr.print` | O |
| `contact.view` | O (কর্মী) |
| `contact.edit` | O (কর্মী) |
| `iam.user.create` | O (Maker) |
| `history.view` | O |

### STOREKEEPER — Proposed
Warehouse/Location-বদ্ধ

| Permission | Scope/শর্ত |
| --- | --- |
| `inv.view` | L |
| `inv.receive` | L |
| `inv.issue` | L |
| `inv.count` | L |
| `custody.accept` | L |
| `qr.view` | L |
| `qr.print` | L (Label) |
| `history.view` | L |

### PROD_SUPERVISOR — Proposed
Factory (Wing-ডিজাইন বাকি)

| Permission | Scope/শর্ত |
| --- | --- |
| `mfg.order.manage` | W |
| `inv.view` | W |
| `inv.issue` | W (Draft) |
| `hr.attendance.view` | W (নিজের দল) |
| `qr.view` | W |
| `history.view` | W |

### QC_OFFICER — Proposed


| Permission | Scope/শর্ত |
| --- | --- |
| `mfg.qc.record` | W |
| `inv.view` | W |
| `qr.view` | W |
| `history.view` | W |

### PURCHASE_OFFICER — Proposed


| Permission | Scope/শর্ত |
| --- | --- |
| `proc.po.manage` | W/O |
| `inv.receive` | W (Draft) |
| `party.view` | O (Supplier) |
| `party.edit` | O (Supplier) |
| `contact.view` | O (Supplier) |
| `contact.edit` | O (Supplier) |
| `txn.create` | W |
| `txn.submit` | W |
| `history.view` | W/O |

### SALES_MANAGER — Proposed


| Permission | Scope/শর্ত |
| --- | --- |
| `sales.order.manage` | W/O |
| `party.view` | O (Dealer/Retailer) |
| `party.edit` | O |
| `txn.view` | W |
| `approval.approve` | W (Rule-ভিত্তিক) |
| `contact.view` | O |
| `contact.edit` | O |
| `qr.view` | W |
| `export.share` | W |
| `export.pdf` | W |
| `history.view` | W |

### FIELD_SALES — Proposed (Dealer-সংশ্লিষ্ট)
নির্ধারিত Dealer/Retailer (A)

| Permission | Scope/শর্ত |
| --- | --- |
| `party.view` | A |
| `contact.view` | A |
| `sales.order.manage` | A (Draft) |
| `sales.collection.create` | A (Draft) |
| `qr.view` | A |
| `export.share` | A (Mask-প্রোফাইল) |
| `history.view` | A |

### AUDITOR — Proposed
শুধু পাঠ; Posting/Approve নয়

| Permission | Scope/শর্ত |
| --- | --- |
| `audit.view` | O/G (নির্ধারিত) |
| `audit.verify` | O/G |
| `txn.view` | O |
| `variance.investigate` | O (স্বাধীন) |
| `qr.view` | O |
| `history.view` | O |

### EMPLOYEE_SELF — Proposed


| Permission | Scope/শর্ত |
| --- | --- |
| `hr.employee.view` | S |
| `hr.attendance.view` | S |
| `qr.view` | S (নিজের ID) |
| `contact.edit` | S (সীমিত) |
| `history.view` | S |

### EMERGENCY_ADMIN — Proposed (#১৬ Pending)
সিল-করা; শুধু Break-glass

| Permission | Scope/শর্ত |
| --- | --- |
| `break_glass.declare` | O (দ্বৈত-নিয়ন্ত্রণ, সময়-বদ্ধ) |

### TECH_ADMIN — Proposed
Business-ডেটা-প্রবেশ নেই

| Permission | Scope/শর্ত |
| --- | --- |
| `sys.deploy` | — |
| `sys.settings.manage` | G/O (Business-বহির্ভূত) |

## Maker-Checker ও SoD-সংঘাত-তালিকা (Promotion/Assignment-যাচাই)

| সংঘাত | নিষিদ্ধ |
| --- | --- |
| `txn.create/submit` + `approval.approve` (একই লেনদেনে) | হ্যাঁ |
| `txn.post` + `txn.create` (একই লেনদেনে) | প্রস্তাব: নিষিদ্ধ |
| `hr.assignment.manage` (Maker) + `hr.handover.approve` (একই Case) | নিষিদ্ধ |
| `variance.investigate` + পুরোনো/নতুন ধারক বা Supervisor | নিষিদ্ধ |
| `iam.role.assign` নিজেকে | নিষিদ্ধ |
| `qr.issue` + `hr.attendance.manual` (নিজের) | নিষিদ্ধ |