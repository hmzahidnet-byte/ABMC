# Appendix C — RPC/Function নাম-তালিকা (লিখিত নকশার Transcript থেকে; Contract নয়)

> **সতর্কতা:** এটি শুধু নাম-তালিকা; কোনোটি বাস্তবে নেই। প্রথম Slice-এর ১৪টির Contract Baseline §৬.৩-এ। নতুন Succession/QR/Action RPC (`rpc_*handover*`, `api.v1_qr_*`, `api.v1_get_available_actions` ইত্যাদি) নতুন Spec-ডকুমেন্টে।

| নাম | কোথায় উল্লিখিত | নোট |
| --- | --- | --- |
| `fn_assign_txn_no` | v0.2.1–v0.2.2 | ভেতরের; নম্বর-বরাদ্দ |
| `fn_begin_call` | v0.2.1–v0.2.2 | ভেতরের; RPC-Prologue |
| `fn_execute_correction` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | ভেতরের; Reversal-সম্পাদন |
| `fn_has_permission` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | ভেতরের; Permission-যাচাই |
| `fn_in_scope` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | ভেতরের; Scope-যাচাই |
| `fn_registry_create_draft` | v0.2.1–v0.2.2 | ভেতরের; Registry-সহ Draft |
| `fn_write_audit` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | ভেতরের; Audit-লেখা (API-এ EXECUTE নেই) |
| `rpc_activate_organization` | v0.2.3–v0.2.6 | কোম্পানি সক্রিয়করণ |
| `rpc_activate_self` | v0.2.3–v0.2.6 | প্রথম MD-র নিজ-সক্রিয়করণ |
| `rpc_approve` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | অনুমোদন/প্রত্যাখ্যান; Auto-post-সহ (Slice ০) |
| `rpc_assign_role` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | Role-প্রদান |
| `rpc_cancel_provisioning` | v0.2.3–v0.2.6 | Provisioning বাতিল |
| `rpc_chairman_override` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | পুরোনো নাম; v0.2.6-এ rpc_group_override-এ প্রতিস্থাপিত |
| `rpc_close_correction_without_replacement` | v0.2.3–v0.2.6 | Correction বর্জন |
| `rpc_confirm_external_checkpoint` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | External Checkpoint-নিশ্চিতকরণ |
| `rpc_create_approval_rule_version` | v0.2.1–v0.2.2 | Approval Rule-Version |
| `rpc_create_delegation` | v0.2.3–v0.2.6 | Delegation |
| `rpc_create_draft` | v0.2.1–v0.2.2 | Draft তৈরি (Slice ০) |
| `rpc_create_organization` | v0.2.3–v0.2.6 | কোম্পানি-তৈরি (Provisioning) |
| `rpc_create_replacement_draft` | v0.2.3–v0.2.6 | Replacement Draft (Option B) |
| `rpc_declare_break_glass` | v0.2.1–v0.2.2 | Emergency Break-glass (দ্বৈত-নিয়ন্ত্রণ) |
| `rpc_get_my_permissions` | v0.2.1–v0.2.2 | Live Permission-তালিকা (UI-ইঙ্গিত) |
| `rpc_group_override` | v0.2.3–v0.2.6 | Group-পথ Override |
| `rpc_link_document` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | নথি-সংযুক্তি |
| `rpc_name` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | Placeholder (Idempotency-স্কোপের স্থির নাম-ধারণা), প্রকৃত RPC নয় |
| `rpc_post` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | আলাদা Post-ধাপ (Slice ০) |
| `rpc_reassign_approver` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | Approver-পুনর্বণ্টন (Maker-Checker) |
| `rpc_register_document` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | নথি-নিবন্ধন |
| `rpc_replace_first_md_invitation` | v0.2.3–v0.2.6 | প্রথম MD-র আমন্ত্রণ-প্রতিস্থাপন |
| `rpc_request_correction` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | Correction-অনুরোধ (Slice ০) |
| `rpc_set_permission_override` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | Permission-Override (সংবেদনশীল) |
| `rpc_submit` | v0.2.1–v0.2.2 | Submit; txn_date Freeze; Rule-Version বাঁধা (Slice ০) |
| `rpc_suspend_organization` | v0.2.3–v0.2.6 | Suspend (দুই-ধাপ; ধাপ ১ RPC, ধাপ ২ Worker) |
| `rpc_terminate_employee` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | কর্মী-সমাপ্তি; Succession-ক্রম (L1b→L1s→L1k) প্রযোজ্য |
| `rpc_unsuspend_organization` | v0.2.3–v0.2.6 | Suspend-প্রত্যাহার |
| `rpc_verify_audit` | v0.2.1–v0.2.2, v0.2.3–v0.2.6 | Audit-যাচাই |