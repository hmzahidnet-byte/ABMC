# Release approvals (OD-01)
One file per release: `release/approvals/<version>.json`, e.g. `0.1.0.json`.

```json
{
  "version": "0.1.0",
  "git_commit": "<40-hex commit sha>",
  "git_tag": "v0.1.0",
  "author": "<developer identifier>",
  "reviewer": "<identifier listed in release/REVIEWER.json>",
  "reviewer_decision": "approved",
  "approved_at": "2026-11-04T10:00:00Z",
  "evidence_files": ["release/evidence/0.1.0/review-notes.md", "release/evidence/0.1.0/test-log.txt"],
  "emergency": false,
  "owner_approval_ref": null
}
```
Rules enforced by `scripts/check_release_gate.py` (exit code 1 = BLOCKED):
1. `release/REVIEWER.json` must list at least one reviewer.
2. The reviewer must be on that list and must **not** be the author (nor any listed commit author).
3. `reviewer_decision` must be `approved`; the commit must be 40-hex and match the repository HEAD (when run inside Git).
4. The tag must be `v<version>`; every evidence file must exist and be non-empty.
5. `emergency: true` requires `owner_approval_ref`, and `owner_emergency_exceptions_enabled` must be true in `REVIEWER.json` (owner switch; off by default).
