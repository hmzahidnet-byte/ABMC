Dev/Staging seed data lives here (never Production). Reference data (roles, permissions) is already in migration `…000400`.
