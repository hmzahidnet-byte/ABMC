-- Live-authorization and company-isolation tests with REAL runtime behaviour: SET ROLE authenticated + a JWT-claims GUC, RLS evaluated by PostgreSQL.
-- The ONLY test-time substitution: core.fn_session_alive() is replaced by "true" INSIDE this rolled-back transaction after T-AUTH-1 has
-- proved the real function rejects an unknown session. The original function is restored by the rollback.
-- STATUS: WRITTEN; first execution happens in the Staging workflow.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;

do $$
declare
  grp uuid; ca uuid; cb uuid; wa uuid; wb uuid; ea uuid; ea2 uuid; eb uuid;
  ua uuid := gen_random_uuid(); ua2 uuid := gen_random_uuid(); ub uuid := gen_random_uuid();
  j jsonb; n_a int; n_b_seen int; n_acc_b int; n_none int; n_b int; d_ins boolean; d_upd boolean; d_del boolean;
  has_create boolean; has_approve boolean; has_term boolean; has_pnl boolean; has_bg boolean; roles_a jsonb;
begin
  insert into core.organizations (kind, code, name, status) values ('group', 'GRP-L', 'G', 'active') returning id into grp;
  insert into core.organizations (kind, parent_organization_id, code, name, status) values ('company', grp, 'CA-L', 'A', 'active') returning id into ca;
  insert into core.organizations (kind, parent_organization_id, code, name, status) values ('company', grp, 'CB-L', 'B', 'active') returning id into cb;
  insert into core.wings (organization_id, code, name) values (ca, 'W', 'WA') returning id into wa;
  insert into core.wings (organization_id, code, name) values (cb, 'W', 'WB') returning id into wb;
  insert into core.employees (organization_id, employee_no, full_name, primary_wing_id) values (ca, 'E1', 'A1', wa) returning id into ea;
  insert into core.employees (organization_id, employee_no, full_name, primary_wing_id) values (ca, 'E2', 'A2', wa) returning id into ea2;
  insert into core.employees (organization_id, employee_no, full_name, primary_wing_id) values (cb, 'E1', 'B1', wb) returning id into eb;
  insert into core.employee_accounts (employee_id, organization_id, auth_user_id, login_handle) values (ea, ca, ua, 'a1');
  insert into core.employee_accounts (employee_id, organization_id, auth_user_id, login_handle) values (ea2, ca, ua2, 'a2');
  insert into core.employee_accounts (employee_id, organization_id, auth_user_id, login_handle) values (eb, cb, ub, 'b1');
  insert into core.user_roles (organization_id, employee_id, role_code) values (ca, ea, 'CASHIER');
  insert into core.user_roles (organization_id, employee_id, role_code) values (cb, eb, 'MD');
  insert into core.user_roles (organization_id, employee_id, role_code, effective_from, effective_to)
    values (ca, ea2, 'FIN_MANAGER', now() - interval '2 days', now() - interval '1 day');
  insert into finance.accounts (organization_id, code, name_bn, account_type) values (ca, '1', 'A-cash', 'asset');
  insert into finance.accounts (organization_id, code, name_bn, account_type) values (cb, '1', 'B-cash', 'asset');
  -- TEST-ONLY grants (rolled back): production gives authenticated NO table access, so selects fail closed. Here they are granted
  -- only to prove that, if access were ever granted, the RLS policies themselves isolate companies correctly.
  grant select on core.employees, finance.accounts, core.user_roles to authenticated;
  grant execute on function core.fn_current_org_id(), core.fn_current_employee_id() to authenticated;

  -- T-AUTH-1: REAL core.fn_session_alive(): a valid user id with a session id that is not in auth.sessions must be rejected
  begin
    perform set_config('request.jwt.claims', json_build_object('sub', ua, 'session_id', gen_random_uuid())::text, true);
    j := core.fn_get_my_permissions();
    insert into _r values ('T-AUTH-1', (j ->> 'error') = 'E_AUTH', 'unknown session_id => E_AUTH (real session check; also proves erp_owner can read auth.sessions)');
  exception when others then
    insert into _r values ('T-AUTH-1', false, 'session check could not run: ' || sqlerrm);
  end;

  -- from here on the session check is substituted (rolled back at the end)
  execute 'create or replace function core.fn_session_alive() returns boolean language sql stable as $f$ select true $f$';

  -- user A (company A, role CASHIER)
  perform set_config('request.jwt.claims', json_build_object('sub', ua)::text, true);
  set local role authenticated;
  select count(*) into n_a from core.employees;
  select count(*) into n_b_seen from core.employees where organization_id = cb;
  select count(*) into n_acc_b from finance.accounts where organization_id = cb;
  begin insert into core.employees (organization_id, employee_no, full_name, primary_wing_id) values (ca, 'EX', 'x', wa); d_ins := false;
  exception when insufficient_privilege then d_ins := true; end;
  begin update core.employees set full_name = 'x'; d_upd := false;
  exception when insufficient_privilege then d_upd := true; end;
  begin delete from core.employees; d_del := false;
  exception when insufficient_privilege then d_del := true; end;
  j := api.v1_get_my_permissions();
  reset role; set local role erp_owner;
  has_create  := exists (select 1 from jsonb_array_elements(j -> 'permissions') e where e ->> 'code' = 'txn.create');
  has_approve := exists (select 1 from jsonb_array_elements(j -> 'permissions') e where e ->> 'code' = 'approval.approve');
  has_term    := exists (select 1 from jsonb_array_elements(j -> 'permissions') e where e ->> 'code' = 'hr.employee.terminate');
  has_pnl     := exists (select 1 from jsonb_array_elements(j -> 'permissions') e where e ->> 'code' = 'fin.report.factory_pl');
  insert into _r values ('T-ISO-1', n_a = 2, 'company A user sees exactly the 2 company-A employees through RLS (saw ' || n_a || ')');
  insert into _r values ('T-ISO-2', n_b_seen = 0, 'company A user sees NO company-B employee');
  insert into _r values ('T-ISO-3', n_acc_b = 0, 'company A user sees NO company-B ledger account');
  insert into _r values ('T-ISO-4', d_ins, 'authenticated cannot INSERT into core.employees (no write privilege)');
  insert into _r values ('T-ISO-5', d_upd, 'authenticated cannot UPDATE core.employees');
  insert into _r values ('T-ISO-6', d_del, 'authenticated cannot DELETE from core.employees');
  insert into _r values ('T-PERM-3', has_create and not has_approve and not has_term and not has_pnl, 'CASHIER gets txn.create but NOT approval.approve, hr.employee.terminate or fin.report.factory_pl');
  insert into _r values ('T-PERM-9', (j ->> 'organization_id') = ca::text, 'the session company is fixed to the account''s own company');

  -- forged client claims must have no effect
  perform set_config('request.jwt.claims', json_build_object('sub', ua, 'role_codes', json_build_array('MD'), 'app_metadata', json_build_object('role', 'MD', 'organization_id', cb))::text, true);
  j := core.fn_get_my_permissions();
  roles_a := j -> 'roles';
  insert into _r values ('T-AUTH-2', roles_a = '["CASHIER"]'::jsonb and (j ->> 'organization_id') = ca::text, 'forged role/company claims in the token are ignored; roles come from the database only');

  -- no identity at all
  perform set_config('request.jwt.claims', '{}', true);
  set local role authenticated;
  select count(*) into n_none from core.employees;
  reset role; set local role erp_owner;
  insert into _r values ('T-ISO-7', n_none = 0, 'authenticated without any identity sees 0 employees');

  -- user B (company B, role MD)
  perform set_config('request.jwt.claims', json_build_object('sub', ub)::text, true);
  set local role authenticated;
  select count(*) into n_b from core.employees;
  j := api.v1_get_my_permissions();
  reset role; set local role erp_owner;
  has_approve := exists (select 1 from jsonb_array_elements(j -> 'permissions') e where e ->> 'code' = 'approval.approve');
  has_pnl     := exists (select 1 from jsonb_array_elements(j -> 'permissions') e where e ->> 'code' = 'fin.report.factory_pl');
  has_bg      := exists (select 1 from jsonb_array_elements(j -> 'permissions') e where e ->> 'code' = 'break_glass.declare');
  insert into _r values ('T-ISO-8', n_b = 1, 'company B user sees exactly its own 1 employee');
  insert into _r values ('T-PERM-4', has_approve and not has_pnl and not has_bg, 'MD gets approval.approve; fin.report.factory_pl and break_glass.declare stay inactive (OD-04: not enforceable yet)');

  -- expired grant (user A2)
  perform set_config('request.jwt.claims', json_build_object('sub', ua2)::text, true);
  j := core.fn_get_my_permissions();
  insert into _r values ('T-PERM-5', jsonb_array_length(coalesce(j -> 'roles', '[]'::jsonb)) = 0 and jsonb_array_length(coalesce(j -> 'permissions', '[]'::jsonb)) = 0, 'an expired role grant yields no roles and no permissions');

  -- disabled account (A2)
  update core.employee_accounts set account_status = 'disabled' where employee_id = ea2;
  j := core.fn_get_my_permissions();
  insert into _r values ('T-PERM-7', (j ->> 'error') = 'E_AUTH', 'a disabled login account is rejected at once');

  -- terminated employee (A1)
  update core.employees set employment_status = 'terminated', separated_on = current_date where id = ea;
  perform set_config('request.jwt.claims', json_build_object('sub', ua)::text, true);
  j := core.fn_get_my_permissions();
  insert into _r values ('T-PERM-6', (j ->> 'error') = 'E_AUTH', 'a terminated employee loses access at once even with a valid login');

  -- suspended company (B)
  update core.organizations set status = 'suspended' where id = cb;
  perform set_config('request.jwt.claims', json_build_object('sub', ub)::text, true);
  j := core.fn_get_my_permissions();
  insert into _r values ('T-PERM-8', (j ->> 'error') = 'E_AUTH', 'a suspended company''s users are rejected');
end $$;

select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;
