-- Privilege-model tests (catalog level, category "privilege"). All are NEGATIVE tests: they prove what API roles can NOT do.
-- Targets the real Supabase role model: anon, authenticated, service_role (+ authenticator), our NOLOGIN owner erp_owner, any custom role.
-- Runs in a rolled-back transaction. STATUS: WRITTEN; first execution happens in the Staging workflow.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;

insert into _r values ('T-PRIV-1',
  not exists (
    select 1
      from pg_class c
      join pg_namespace n on n.oid = c.relnamespace
      cross join unnest(array['anon', 'authenticated', 'service_role']) as r(role_name)
      cross join unnest(array['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'TRUNCATE', 'REFERENCES', 'TRIGGER']) as p(priv)
     where n.nspname in ('core', 'finance', 'hr', 'svc', 'api')
       and c.relkind in ('r', 'p', 'v', 'm', 'f')
       and has_table_privilege(r.role_name, c.oid, p.priv)),
  'anon, authenticated and service_role hold NO privilege on any table or view in our schemas');

insert into _r values ('T-PRIV-2',
  not exists (
    select 1
      from pg_class c
      join pg_namespace n on n.oid = c.relnamespace
      cross join unnest(array['anon', 'authenticated', 'service_role']) as r(role_name)
      cross join unnest(array['USAGE', 'SELECT', 'UPDATE']) as p(priv)
     where n.nspname in ('core', 'finance', 'hr', 'svc', 'api')
       and c.relkind = 'S'
       and has_sequence_privilege(r.role_name, c.oid, p.priv)),
  'API roles hold no privilege on any sequence');

insert into _r values ('T-PRIV-3',
  not has_schema_privilege('anon', 'core', 'USAGE') and not has_schema_privilege('anon', 'finance', 'USAGE')
  and not has_schema_privilege('anon', 'hr', 'USAGE') and not has_schema_privilege('anon', 'svc', 'USAGE')
  and not has_schema_privilege('anon', 'api', 'USAGE')
  and has_schema_privilege('authenticated', 'api', 'USAGE') and has_schema_privilege('authenticated', 'core', 'USAGE')
  and not has_schema_privilege('authenticated', 'finance', 'USAGE') and not has_schema_privilege('authenticated', 'hr', 'USAGE')
  and not has_schema_privilege('authenticated', 'svc', 'USAGE')
  and not has_schema_privilege('service_role', 'core', 'USAGE') and not has_schema_privilege('service_role', 'finance', 'USAGE')
  and not has_schema_privilege('service_role', 'hr', 'USAGE') and not has_schema_privilege('service_role', 'api', 'USAGE')
  and has_schema_privilege('service_role', 'svc', 'USAGE'),
  'schema USAGE: anon none; authenticated only api+core; service_role only svc');

insert into _r values ('T-PRIV-4',
  not exists (
    select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname in ('core', 'finance', 'hr', 'svc', 'api')
       and (p.proacl is null
            or exists (select 1 from aclexplode(p.proacl) a where a.grantee = 0 and a.privilege_type = 'EXECUTE'))),
  'no function in our schemas is executable by PUBLIC (default EXECUTE was revoked)');

insert into _r values ('T-PRIV-5',
  (select coalesce(array_agg(n.nspname || '.' || p.proname order by n.nspname || '.' || p.proname), array[]::text[])
     from pg_proc p join pg_namespace n on n.oid = p.pronamespace
    where n.nspname in ('core', 'finance', 'hr', 'svc', 'api') and has_function_privilege('authenticated', p.oid, 'EXECUTE'))
    = array['api.v1_get_my_permissions', 'core.fn_get_my_permissions']
  and not exists (
    select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname in ('core', 'finance', 'hr', 'svc', 'api')
       and (has_function_privilege('anon', p.oid, 'EXECUTE') or has_function_privilege('service_role', p.oid, 'EXECUTE'))),
  'authenticated may execute exactly the two permission functions; anon and service_role execute none');

insert into _r values ('T-PRIV-6',
  exists (select 1 from pg_roles where rolname = 'erp_owner'
           and not rolsuper and not rolcanlogin and not rolbypassrls and not rolcreaterole and not rolcreatedb),
  'erp_owner is NOLOGIN, not superuser, not BYPASSRLS, cannot create roles or databases');

insert into _r values ('T-PRIV-7',
  not exists (
    select 1 from pg_auth_members m
      join pg_roles g on g.oid = m.roleid
      join pg_roles u on u.oid = m.member
     where g.rolname = 'erp_owner' and u.rolname in ('anon', 'authenticated', 'service_role', 'authenticator')),
  'no API role (anon, authenticated, service_role, authenticator) is a member of erp_owner');

insert into _r values ('T-PRIV-8',
  not exists (
    with acls as (
      select coalesce(r.rolname, 'PUBLIC') as grantee
        from pg_class c join pg_namespace n on n.oid = c.relnamespace
        cross join lateral aclexplode(coalesce(c.relacl, acldefault('r', c.relowner))) a
        left join pg_roles r on r.oid = a.grantee
       where n.nspname in ('core', 'finance', 'hr', 'svc', 'api') and c.relkind in ('r', 'p', 'v', 'm')
      union all
      select coalesce(r.rolname, 'PUBLIC')
        from pg_namespace n
        cross join lateral aclexplode(coalesce(n.nspacl, acldefault('n', n.nspowner))) a
        left join pg_roles r on r.oid = a.grantee
       where n.nspname in ('core', 'finance', 'hr', 'svc', 'api')
      union all
      select coalesce(r.rolname, 'PUBLIC')
        from pg_proc p join pg_namespace n on n.oid = p.pronamespace
        cross join lateral aclexplode(coalesce(p.proacl, acldefault('f', p.proowner))) a
        left join pg_roles r on r.oid = a.grantee
       where n.nspname in ('core', 'finance', 'hr', 'svc', 'api'))
    select 1 from acls where grantee not in ('erp_owner', 'authenticated', 'service_role')),
  'no unexpected grantee (PUBLIC, anon, custom or system role) holds any privilege in our schemas');

select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;
