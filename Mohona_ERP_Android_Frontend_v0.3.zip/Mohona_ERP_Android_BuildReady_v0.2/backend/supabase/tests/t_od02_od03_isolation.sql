-- Tests: T303, T306 (OD-02 separate company accounts / no cross-company role grant),
--        T307 (OD-03 cross-company ledger posting rejected at DB), T305 (partial: independence of two accounts' states).
-- Run inside a transaction that is rolled back. Prints RESULT|<id>|PASS/FAIL|<note>. STATUS: WRITTEN, NOT EXECUTED.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text) returns boolean language plpgsql as $$
begin execute p_sql; return false; exception when others then return true; end $$;

do $$
declare grp uuid; ca uuid; cb uuid; wa uuid; wb uuid; ea uuid; eb uuid; ua uuid := gen_random_uuid(); ub uuid := gen_random_uuid();
        aa uuid; ab uuid; ta uuid; pa uuid; fy uuid; ty uuid;
begin
  insert into core.organizations (kind, code, name, status) values ('group','GRP','Group','active') returning id into grp;
  insert into core.organizations (kind, parent_organization_id, code, name, status) values ('company', grp, 'CA','Company A','active') returning id into ca;
  insert into core.organizations (kind, parent_organization_id, code, name, status) values ('company', grp, 'CB','Company B','active') returning id into cb;
  insert into core.wings (organization_id, code, name) values (ca,'MFG','A-Mfg') returning id into wa;
  insert into core.wings (organization_id, code, name) values (cb,'MFG','B-Mfg') returning id into wb;
  -- The SAME human works in both companies: two separate employee rows, two separate accounts, two separate auth identities.
  insert into core.employees (organization_id, employee_no, full_name, primary_wing_id) values (ca,'E1','Rahim',wa) returning id into ea;
  insert into core.employees (organization_id, employee_no, full_name, primary_wing_id) values (cb,'E1','Rahim',wb) returning id into eb;
  insert into core.employee_accounts (employee_id, organization_id, auth_user_id, login_handle) values (ea, ca, ua, 'rahim');
  insert into core.employee_accounts (employee_id, organization_id, auth_user_id, login_handle) values (eb, cb, ub, 'rahim');

  insert into _r values ('T303', (select count(*) = 2 and count(distinct auth_user_id) = 2 and count(distinct organization_id) = 2 from core.employee_accounts), 'two accounts, two auth identities, two companies');
  insert into _r values ('T303', pg_temp.expect_fail(format($f$insert into core.employee_accounts (employee_id, organization_id, auth_user_id, login_handle) values (%L,%L,%L,'x')$f$, ea, ca, gen_random_uuid()))
                                 , 'second account for the same employee is rejected');
  insert into _r values ('T303', pg_temp.expect_fail(format($f$insert into core.employee_accounts (employee_id, organization_id, auth_user_id, login_handle) values (%L,%L,%L,'y')$f$, ea, cb, gen_random_uuid()))
                                 , 'account whose company differs from the employee''s company is rejected (composite FK)');
  insert into _r values ('T303', pg_temp.expect_fail(format($f$insert into core.employee_accounts (employee_id, organization_id, auth_user_id, login_handle) values (%L,%L,%L,'z')$f$, gen_random_uuid(), ca, ua))
                                 , 'reusing one auth identity for a second account is rejected');

  -- T306: a role grant can never point an employee of company A into company B.
  insert into _r values ('T306', pg_temp.expect_fail(format($f$insert into core.user_roles (organization_id, employee_id, role_code) values (%L,%L,'CASHIER')$f$, cb, ea))
                                 , 'cross-company role grant rejected (composite FK)');
  insert into core.user_roles (organization_id, employee_id, role_code) values (ca, ea, 'CASHIER');

  -- T305 (state independence): terminating/disabling A's account does not touch B's account.
  update core.employee_accounts set account_status = 'disabled' where employee_id = ea;
  update core.employees set employment_status = 'terminated', separated_on = current_date where id = ea;
  insert into _r values ('T305', (select account_status = 'active' from core.employee_accounts where employee_id = eb)
                                 and (select employment_status = 'active' from core.employees where id = eb), 'company B account unaffected by company A termination');

  -- T307 / OD-03: build company A's books, then try to touch them with company B ids.
  insert into core.transaction_types (code, name_bn) values ('cash_voucher','নগদ ভাউচার') returning id into ty;
  insert into finance.accounts (organization_id, code, name_bn, account_type, is_cash) values (ca,'1001','নগদ','asset',true) returning id into aa;
  insert into finance.accounts (organization_id, code, name_bn, account_type) values (cb,'1001','নগদ','asset') returning id into ab;
  insert into core.fiscal_years (organization_id, name, start_date, end_date) values (ca,'FY','2026-07-01','2027-06-30') returning id into fy;
  insert into core.accounting_periods (organization_id, fiscal_year_id, period_no, start_date, end_date) values (ca, fy, 1, '2026-07-01','2026-07-31') returning id into pa;
  insert into core.transaction_registry (organization_id, wing_id, transaction_type_id, txn_date, post_mode, posting_required, created_by)
    values (ca, wa, ty, '2026-07-05','manual', true, ea) returning id into ta;
  perform set_config('mohona.in_posting','on', true);
  insert into _r values ('T307', pg_temp.expect_fail(format($f$insert into finance.ledger_entries (organization_id, txn_id, entry_no, account_id, debit, posting_date, period_id, actor_employee_id) values (%L,%L,1,%L,10,'2026-07-05',%L,%L)$f$, ca, ta, ab, pa, ea))
                                 , 'ledger entry in company A using company B account is rejected');
  insert into _r values ('T307', pg_temp.expect_fail(format($f$insert into finance.ledger_entries (organization_id, txn_id, entry_no, account_id, debit, posting_date, period_id, actor_employee_id) values (%L,%L,1,%L,10,'2026-07-05',%L,%L)$f$, cb, ta, ab, pa, eb))
                                 , 'ledger entry in company B pointing at company A transaction is rejected');
  perform set_config('mohona.in_posting','off', true);
end $$;

select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;
