-- Tests: T291 (balanced entries commit; unbalanced rejected), T295 (posting-path guard), audit append-only + chain verification.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text) returns boolean language plpgsql as $$
begin execute p_sql; return false; exception when others then return true; end $$;
do $$
declare grp uuid; ca uuid; wa uuid; ea uuid; ty uuid; a1 uuid; a2 uuid; fy uuid; pa uuid; t1 uuid; t2 uuid; s1 bigint; s2 bigint; s3 bigint;
begin
  insert into core.organizations (kind, code, name, status) values ('group','GRP','G','active') returning id into grp;
  insert into core.organizations (kind, parent_organization_id, code, name, status) values ('company', grp,'CA','A','active') returning id into ca;
  insert into core.wings (organization_id, code, name) values (ca,'MFG','M') returning id into wa;
  insert into core.employees (organization_id, employee_no, full_name, primary_wing_id) values (ca,'E1','X',wa) returning id into ea;
  insert into core.transaction_types (code, name_bn) values ('cash_voucher','v') returning id into ty;
  insert into finance.accounts (organization_id, code, name_bn, account_type, is_cash) values (ca,'1','cash','asset',true) returning id into a1;
  insert into finance.accounts (organization_id, code, name_bn, account_type) values (ca,'5','exp','expense') returning id into a2;
  insert into core.fiscal_years (organization_id, name, start_date, end_date) values (ca,'FY','2026-07-01','2027-06-30') returning id into fy;
  insert into core.accounting_periods (organization_id, fiscal_year_id, period_no, start_date, end_date) values (ca, fy, 1,'2026-07-01','2026-07-31') returning id into pa;
  insert into core.transaction_registry (organization_id, wing_id, transaction_type_id, txn_date, post_mode, posting_required, created_by) values (ca,wa,ty,'2026-07-05','manual',true,ea) returning id into t1;
  insert into core.transaction_registry (organization_id, wing_id, transaction_type_id, txn_date, post_mode, posting_required, created_by) values (ca,wa,ty,'2026-07-06','manual',true,ea) returning id into t2;

  -- T295: no posting context -> rejected
  insert into _r values ('T295', pg_temp.expect_fail(format($f$insert into finance.ledger_entries (organization_id, txn_id, entry_no, account_id, debit, posting_date, period_id, actor_employee_id) values (%L,%L,1,%L,100,'2026-07-05',%L,%L)$f$, ca,t1,a2,pa,ea)), 'direct ledger insert outside posting function rejected');

  perform set_config('mohona.in_posting','on', true);
  -- T291 balanced: both rows then commit-check (forced immediate here)
  insert into finance.ledger_entries (organization_id, txn_id, entry_no, account_id, debit, posting_date, period_id, actor_employee_id) values (ca,t1,1,a2,100,'2026-07-05',pa,ea);
  insert into finance.ledger_entries (organization_id, txn_id, entry_no, account_id, credit, posting_date, period_id, actor_employee_id) values (ca,t1,2,a1,100,'2026-07-05',pa,ea);
  set constraints all immediate;
  insert into _r values ('T291', true, 'balanced transaction accepted');
  set constraints all deferred;
  -- unbalanced: single leg
  insert into finance.ledger_entries (organization_id, txn_id, entry_no, account_id, debit, posting_date, period_id, actor_employee_id) values (ca,t2,1,a2,50,'2026-07-06',pa,ea);
  insert into _r values ('T291', pg_temp.expect_fail('set constraints all immediate'), 'unbalanced transaction rejected at constraint check');
  perform set_config('mohona.in_posting','off', true);
end $$;
-- fresh savepoint-free path: remaining checks use their own org
do $$
declare grp uuid; ca uuid; ok1 boolean; bad bigint;
begin
  insert into core.organizations (kind, code, name, status) values ('group','GRP2','G2','active') returning id into grp;
  insert into core.organizations (kind, parent_organization_id, code, name, status) values ('company', grp,'AU','Audit Co','active') returning id into ca;
  perform core.fn_write_audit(ca, null, 'test.one'); perform core.fn_write_audit(ca, null, 'test.two', 'x', null, 'success', '{"k":1}'::jsonb);
  perform core.fn_write_audit(ca, null, 'test.three');
  insert into _r values ('T-AUD-1', core.fn_verify_audit_chain(ca) is null, 'chain of 3 rows verifies');
  insert into _r values ('T-AUD-2', pg_temp.expect_fail(format($f$update core.audit_logs set action='tampered' where organization_id=%L and seq=2$f$, ca)), 'UPDATE on audit_logs rejected');
  insert into _r values ('T-AUD-3', pg_temp.expect_fail(format($f$delete from core.audit_logs where organization_id=%L$f$, ca)), 'DELETE on audit_logs rejected');
  -- tamper by disabling the trigger as owner, then the verifier must flag the row
  alter table core.audit_logs disable trigger trg_audit_logs_no_update;
  update core.audit_logs set action = 'tampered' where organization_id = ca and seq = 2;
  alter table core.audit_logs enable trigger trg_audit_logs_no_update;
  bad := core.fn_verify_audit_chain(ca);
  insert into _r values ('T-AUD-4', bad = 2, 'tampering is detected at seq 2 (got ' || coalesce(bad::text,'null') || ')');
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;
