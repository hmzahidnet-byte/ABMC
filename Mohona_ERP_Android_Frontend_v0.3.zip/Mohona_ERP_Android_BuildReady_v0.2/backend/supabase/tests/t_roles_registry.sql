-- Tests: T311 (exactly the 17 approved roles), T312 (TECH_ADMIN has no business permissions),
--        T313 (Factory P&L permission only for MD), T314 (placeholder Wing permissions are not active).
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
insert into _r values ('T311', (select count(*) = 17 from core.roles) and (select array_agg(role_code order by role_code) = array['ACCOUNTANT','AUDITOR','CASHIER','CHAIRMAN','EMERGENCY_ADMIN','EMPLOYEE_SELF','FIELD_SALES','FIN_MANAGER','HR_OFFICER','MD','PROD_SUPERVISOR','PURCHASE_OFFICER','QC_OFFICER','SALES_MANAGER','STOREKEEPER','TECH_ADMIN','WING_HEAD'] from core.roles), 'role registry equals the 17 approved names');
insert into _r values ('T312', not exists (select 1 from core.role_permissions rp join core.permissions p on p.code = rp.permission_code
                                           where rp.role_code = 'TECH_ADMIN' and p.domain not in ('System')), 'TECH_ADMIN holds only System permissions (no business data)');
insert into _r values ('T313', (select array_agg(role_code) = array['MD'] from core.role_permissions where permission_code = 'fin.report.factory_pl'), 'only MD holds fin.report.factory_pl');
insert into _r values ('T314', not exists (select 1 from core.permissions where domain in ('Mfg','Procurement','Sales','Inventory') and status = 'active'), 'future-Wing placeholder permissions are not active');
insert into _r values ('T314', not exists (select 1 from core.permissions where code = 'break_glass.declare' and status = 'active'), 'break-glass stays inactive until its policy is approved');
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;
