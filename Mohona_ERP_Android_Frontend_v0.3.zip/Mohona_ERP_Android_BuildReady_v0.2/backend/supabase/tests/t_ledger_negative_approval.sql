-- Negative tests for the ledger (append-only, one-sided lines, company-bound periods) and for maker-checker at the DATABASE level.
-- Rolled-back transaction. STATUS: WRITTEN; first execution happens in the Staging workflow.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text) returns boolean language plpgsql as $$
begin execute p_sql; return false; exception when others then return true; end $$;

do $$
declare
  grp uuid; ca uuid; cb uuid; wa uuid; wb uuid; ea uuid; ea2 uuid; eb uuid; ty uuid; a1 uuid; a2 uuid;
  fya uuid; fyb uuid; pa uuid; pb uuid; t1 uuid; rule uuid; ver uuid; req uuid; stp uuid;
begin
  insert into core.organizations (kind, code, name, status) values ('group', 'GRP-N', 'G', 'active') returning id into grp;
  insert into core.organizations (kind, parent_organization_id, code, name, status) values ('company', grp, 'CA-N', 'A', 'active') returning id into ca;
  insert into core.organizations (kind, parent_organization_id, code, name, status) values ('company', grp, 'CB-N', 'B', 'active') returning id into cb;
  insert into core.wings (organization_id, code, name) values (ca, 'W', 'WA') returning id into wa;
  insert into core.wings (organization_id, code, name) values (cb, 'W', 'WB') returning id into wb;
  insert into core.employees (organization_id, employee_no, full_name, primary_wing_id) values (ca, 'E1', 'Maker', wa) returning id into ea;
  insert into core.employees (organization_id, employee_no, full_name, primary_wing_id) values (ca, 'E2', 'Checker', wa) returning id into ea2;
  insert into core.employees (organization_id, employee_no, full_name, primary_wing_id) values (cb, 'E1', 'Other', wb) returning id into eb;
  insert into core.transaction_types (code, name_bn) values ('cash_voucher', 'v') returning id into ty;
  insert into finance.accounts (organization_id, code, name_bn, account_type, is_cash) values (ca, '1', 'cash', 'asset', true) returning id into a1;
  insert into finance.accounts (organization_id, code, name_bn, account_type) values (ca, '5', 'exp', 'expense') returning id into a2;
  insert into core.fiscal_years (organization_id, name, start_date, end_date) values (ca, 'FY', '2026-07-01', '2027-06-30') returning id into fya;
  insert into core.fiscal_years (organization_id, name, start_date, end_date) values (cb, 'FY', '2026-07-01', '2027-06-30') returning id into fyb;
  insert into core.accounting_periods (organization_id, fiscal_year_id, period_no, start_date, end_date) values (ca, fya, 1, '2026-07-01', '2026-07-31') returning id into pa;
  insert into core.accounting_periods (organization_id, fiscal_year_id, period_no, start_date, end_date) values (cb, fyb, 1, '2026-07-01', '2026-07-31') returning id into pb;
  insert into core.transaction_registry (organization_id, wing_id, transaction_type_id, txn_date, post_mode, posting_required, created_by)
    values (ca, wa, ty, '2026-07-05', 'manual', true, ea) returning id into t1;

  perform set_config('mohona.in_posting', 'on', true);
  insert into finance.ledger_entries (organization_id, txn_id, entry_no, account_id, debit, posting_date, period_id, actor_employee_id) values (ca, t1, 1, a2, 100, '2026-07-05', pa, ea);
  insert into finance.ledger_entries (organization_id, txn_id, entry_no, account_id, credit, posting_date, period_id, actor_employee_id) values (ca, t1, 2, a1, 100, '2026-07-05', pa, ea);
  set constraints all immediate;
  set constraints all deferred;

  insert into _r values ('T-LDG-1', pg_temp.expect_fail(format($f$update finance.ledger_entries set debit = 1 where txn_id = %L$f$, t1)), 'a posted ledger row cannot be UPDATED');
  insert into _r values ('T-LDG-2', pg_temp.expect_fail(format($f$delete from finance.ledger_entries where txn_id = %L$f$, t1)), 'a posted ledger row cannot be DELETED');
  insert into _r values ('T-LDG-3', pg_temp.expect_fail(format($f$insert into finance.ledger_entries (organization_id, txn_id, entry_no, account_id, debit, credit, posting_date, period_id, actor_employee_id) values (%L,%L,9,%L,5,5,'2026-07-05',%L,%L)$f$, ca, t1, a2, pa, ea)), 'a line with both debit and credit is rejected');
  insert into _r values ('T-LDG-4',
    pg_temp.expect_fail(format($f$insert into finance.ledger_entries (organization_id, txn_id, entry_no, account_id, debit, posting_date, period_id, actor_employee_id) values (%L,%L,10,%L,0,'2026-07-05',%L,%L)$f$, ca, t1, a2, pa, ea))
    and pg_temp.expect_fail(format($f$insert into finance.ledger_entries (organization_id, txn_id, entry_no, account_id, debit, posting_date, period_id, actor_employee_id) values (%L,%L,11,%L,-5,'2026-07-05',%L,%L)$f$, ca, t1, a2, pa, ea)),
    'zero-amount and negative-amount lines are rejected');
  insert into _r values ('T-LDG-5', pg_temp.expect_fail(format($f$insert into finance.ledger_entries (organization_id, txn_id, entry_no, account_id, debit, posting_date, period_id, actor_employee_id) values (%L,%L,12,%L,1,'2026-07-05',%L,%L)$f$, ca, t1, a2, pb, ea)), 'a line cannot use another company''s accounting period');
  insert into _r values ('T-LDG-6', pg_temp.expect_fail('truncate finance.ledger_entries'), 'the ledger cannot be TRUNCATED');

  -- maker-checker at database level
  insert into core.approval_rules (organization_id, transaction_type_id, name) values (ca, ty, 'r') returning id into rule;
  insert into core.approval_rule_versions (organization_id, rule_id, version_no, change_reason) values (ca, rule, 1, 'test') returning id into ver;
  insert into core.approval_rule_steps (organization_id, rule_version_id, step_no, approver_role_code) values (ca, ver, 1, 'FIN_MANAGER');
  insert into core.approval_requests (organization_id, txn_id, rule_version_id, submitted_by) values (ca, t1, ver, ea) returning id into req;
  insert into core.approval_request_steps (organization_id, request_id, step_no, mode, required_count, approver_role_code) values (ca, req, 1, 'any_one', 1, 'FIN_MANAGER') returning id into stp;

  insert into _r values ('T-APR-1', pg_temp.expect_fail(format($f$insert into core.approval_actions (organization_id, request_step_id, actor_employee_id, actor_organization_id, decision) values (%L,%L,%L,%L,'approve')$f$, ca, stp, ea, ca)), 'the maker cannot approve their own transaction (database trigger)');
  insert into _r values ('T-APR-3', pg_temp.expect_fail(format($f$insert into core.approval_actions (organization_id, request_step_id, actor_employee_id, actor_organization_id, decision) values (%L,%L,%L,%L,'approve')$f$, ca, stp, eb, cb)), 'an actor from another company cannot approve through the company path');
  begin
    insert into core.approval_actions (organization_id, request_step_id, actor_employee_id, actor_organization_id, decision) values (ca, stp, ea2, ca, 'approve');
    insert into _r values ('T-APR-2', true, 'an independent checker of the same company can approve');
  exception when others then
    insert into _r values ('T-APR-2', false, 'independent approval failed: ' || sqlerrm);
  end;
  insert into _r values ('T-APR-4', pg_temp.expect_fail(format($f$update core.approval_actions set decision = 'reject' where request_step_id = %L$f$, stp)) and pg_temp.expect_fail(format($f$delete from core.approval_actions where request_step_id = %L$f$, stp)), 'a recorded approval can be neither changed nor deleted');
end $$;

select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;
