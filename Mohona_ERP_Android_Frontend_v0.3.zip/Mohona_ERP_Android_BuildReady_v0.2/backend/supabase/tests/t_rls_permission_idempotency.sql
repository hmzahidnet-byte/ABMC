-- Tests: T-RLS-1..3 (API roles have no direct table access; RLS enabled everywhere),
--        T-PERM-1..2 (no identity => no permission), T-IDEM-1..2 (idempotency key uniqueness).
-- Everything runs inside a transaction that is rolled back. STATUS: WRITTEN, NOT EXECUTED (until the Staging workflow runs it).
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text) returns boolean language plpgsql as $$
begin execute p_sql; return false; exception when others then return true; end $$;

insert into _r values ('T-RLS-1',
  not has_table_privilege('anon', 'core.employees', 'select') and not has_table_privilege('authenticated', 'core.employees', 'select'),
  'anon and authenticated have no direct SELECT on core.employees');
insert into _r values ('T-RLS-2',
  not has_table_privilege('service_role', 'finance.ledger_entries', 'insert') and not has_table_privilege('service_role', 'core.organizations', 'select'),
  'service_role has no direct DML/SELECT on business tables');
insert into _r values ('T-RLS-3',
  not exists (
    select 1 from pg_class c
      join pg_namespace n on n.oid = c.relnamespace
      join pg_attribute a on a.attrelid = c.oid and a.attname = 'organization_id' and not a.attisdropped
     where n.nspname in ('core', 'finance', 'hr') and c.relkind = 'r' and not c.relrowsecurity),
  'row level security is enabled on every table that has organization_id');

insert into _r values ('T-PERM-1', (core.fn_get_my_permissions() ->> 'error') = 'E_AUTH', 'no identity => E_AUTH');
insert into _r values ('T-PERM-2', core.fn_has_permission('txn.post') = false, 'no identity => no permission');

do $$
declare grp uuid; ca uuid; wa uuid; ea uuid;
begin
  insert into core.organizations (kind, code, name, status) values ('group', 'IDG', 'G', 'active') returning id into grp;
  insert into core.organizations (kind, parent_organization_id, code, name, status) values ('company', grp, 'IDC', 'C', 'active') returning id into ca;
  insert into core.wings (organization_id, code, name) values (ca, 'W', 'W') returning id into wa;
  insert into core.employees (organization_id, employee_no, full_name, primary_wing_id) values (ca, 'E1', 'X', wa) returning id into ea;
  insert into core.idempotency_records (organization_id, actor_employee_id, rpc_name, idempotency_key, payload_hash)
    values (ca, ea, 'rpc_probe', 'k1', '\x01');
  insert into _r values ('T-IDEM-1', pg_temp.expect_fail(format($f$insert into core.idempotency_records (organization_id, actor_employee_id, rpc_name, idempotency_key, payload_hash) values (%L,%L,'rpc_probe','k1','\x01')$f$, ca, ea)),
    'the same idempotency key cannot be recorded twice');
  insert into _r values ('T-IDEM-2', pg_temp.expect_fail(format($f$insert into core.idempotency_records (organization_id, actor_employee_id, rpc_name, idempotency_key, payload_hash) values (%L,%L,'rpc_probe','k1','\x02')$f$, ca, ea)),
    'the same key with a DIFFERENT payload hash is also rejected (conflict must be detected, not stored)');
end $$;

select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;
