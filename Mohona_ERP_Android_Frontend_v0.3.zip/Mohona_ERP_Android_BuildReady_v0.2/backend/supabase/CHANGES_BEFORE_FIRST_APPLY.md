# Changes to migration files before their first apply
Rule: a migration may be corrected in place ONLY while it has never been applied anywhere. After the first successful apply it is immutable
(the Staging workflow enforces this by SHA-256) and every change is a NEW forward migration. The original is preserved here.

## 2026-11-05 — 20261104000900_authz_rls_api.sql
- **Defect found while designing the P0 negative tests:** `core.fn_get_my_permissions()` was written as `coalesce(jsonb_build_object(...), jsonb_build_object('error','E_AUTH'))`.
  `jsonb_build_object()` never returns NULL, so the error branch was unreachable: with no valid identity the function returned an object with null ids instead of `{"error":"E_AUTH"}`.
  The Android app (`fetchAuthorization`) and Spike S3 both expect `E_AUTH`.
- **Fix:** an explicit `CASE WHEN core.fn_current_employee_id() IS NULL THEN {"error":"E_AUTH"} ELSE ... END`. Nothing else in the file changed.
- Original file (unchanged copy): `original_unapplied/20261104000900_authz_rls_api.ORIGINAL.sql`
- SHA-256 original: `f879fc4d56581aaa8b4376867918cbeaf56b06402e659d01a433ee3b5d756c2a`
- SHA-256 corrected: `695c4b54ca59deedd9e491a5ccd2d216dbc7c4c22ffbaadaba69b4ecb3daf16d`
- Executed anywhere? **No.** Verified? **No** — covered by tests T-PERM-1, T-PERM-6..8 and T-AUTH-1 once the Staging workflow runs them.
