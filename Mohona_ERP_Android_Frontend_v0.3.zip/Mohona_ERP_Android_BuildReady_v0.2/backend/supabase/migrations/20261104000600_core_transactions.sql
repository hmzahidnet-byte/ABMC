-- 20261104000600_core_transactions.sql
-- Transaction registry, versions, idempotency, numbering, corrections, archived drafts. Baseline §5.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create table core.transaction_types (
  id                uuid primary key default gen_random_uuid(),
  code              text not null unique,
  name_bn           text not null,
  requires_posting  boolean not null default true,
  post_mode         text not null default 'manual' check (post_mode in ('manual','auto')),  -- #21 default is a PROPOSAL (configurable)
  posting_function  text,
  reverse_function  text,
  status            text not null default 'active' check (status in ('active','inactive'))
);

create table core.transaction_registry (
  id                  uuid primary key default gen_random_uuid(),
  organization_id     uuid not null references core.organizations(id),
  wing_id             uuid not null,
  transaction_type_id uuid not null references core.transaction_types(id),
  status              text not null default 'draft'
                      check (status in ('draft','submitted','pending','approved','posted','rejected','returned','cancelled')),
  txn_no              text,
  txn_date            date not null,
  post_mode           text not null check (post_mode in ('manual','auto')),     -- copied at creation, immutable
  posting_required    boolean not null,                                          -- copied at creation, immutable
  current_version_no  integer not null default 1,
  created_by          uuid not null,
  created_at          timestamptz not null default now(),
  submitted_by        uuid,
  submitted_at        timestamptz,
  posted_at           timestamptz,
  unique (id, organization_id),
  unique (organization_id, txn_no),
  foreign key (wing_id, organization_id) references core.wings (id, organization_id),
  foreign key (created_by, organization_id) references core.employees (id, organization_id),
  constraint txn_posted_has_number check (status <> 'posted' or txn_no is not null)
);
create index transaction_registry_status on core.transaction_registry (organization_id, status);

create function core.fn_registry_guard() returns trigger language plpgsql as $$
begin
  if new.post_mode is distinct from old.post_mode or new.posting_required is distinct from old.posting_required
     or new.organization_id is distinct from old.organization_id or new.transaction_type_id is distinct from old.transaction_type_id then
    raise exception 'E_IMMUTABLE: post_mode/posting_required/type/organization are fixed at creation' using errcode = 'P0001';
  end if;
  if old.status = 'posted' and new.status <> 'posted' then
    raise exception 'E_STATE: a posted transaction cannot leave posted (corrections are new transactions)' using errcode = 'P0001';
  end if;
  if old.txn_date is distinct from new.txn_date and old.status not in ('draft','returned') then
    raise exception 'E_STATE: txn_date is frozen after submit' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_registry_guard before update on core.transaction_registry
  for each row execute function core.fn_registry_guard();
create trigger trg_registry_no_delete before delete on core.transaction_registry
  for each row execute function core.fn_deny_mutation();

create table core.transaction_versions (
  txn_id          uuid not null,
  organization_id uuid not null,
  version_no      integer not null,
  payload         jsonb not null,
  created_by      uuid not null,
  created_at      timestamptz not null default now(),
  primary key (txn_id, version_no),
  foreign key (txn_id, organization_id) references core.transaction_registry (id, organization_id)
);
create trigger trg_txn_versions_immutable before update or delete on core.transaction_versions
  for each row execute function core.fn_deny_mutation();

create table core.deleted_drafts_archive (
  id              uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  txn_id          uuid not null,
  snapshot        jsonb not null,
  deleted_by      uuid not null,
  deleted_at      timestamptz not null default now()
);

create table core.idempotency_records (
  organization_id uuid not null references core.organizations(id),
  actor_employee_id uuid not null,
  rpc_name        text not null,
  idempotency_key text not null,
  payload_hash    bytea not null,
  status          text not null default 'in_progress' check (status in ('in_progress','done')),
  response        jsonb,
  created_at      timestamptz not null default now(),
  primary key (organization_id, actor_employee_id, rpc_name, idempotency_key)
);

create table core.document_sequences (
  organization_id uuid not null references core.organizations(id),
  seq_key         text not null,
  mode            text not null default 'unique_only' check (mode in ('unique_only','gapless')),  -- #15 default is a PROPOSAL
  next_value      bigint not null default 1 check (next_value >= 1),
  primary key (organization_id, seq_key)
);

-- Lock level L9: last in the hierarchy. Caller must already hold L1o..L8.
create function core.fn_next_number(p_org uuid, p_key text) returns bigint
language plpgsql security definer set search_path = pg_catalog, public as $$
declare v bigint;
begin
  insert into core.document_sequences (organization_id, seq_key) values (p_org, p_key) on conflict do nothing;
  update core.document_sequences set next_value = next_value + 1
   where organization_id = p_org and seq_key = p_key returning next_value - 1 into v;
  return v;
end $$;

-- Corrections (Reversal + Replacement, Option B = F4)
create table core.corrections (
  id                  uuid primary key default gen_random_uuid(),
  organization_id     uuid not null,
  original_txn_id     uuid not null,
  reversal_txn_id     uuid,
  replacement_txn_id  uuid,
  reversal_period_id  uuid,
  status              text not null default 'open' check (status in ('open','approved','reversed','completed','abandoned')),
  reason              text not null,
  attempt_no          integer not null default 1,
  requested_by        uuid not null,
  requested_at        timestamptz not null default now(),
  unique (id, organization_id),
  foreign key (original_txn_id, organization_id) references core.transaction_registry (id, organization_id),
  foreign key (reversal_txn_id, organization_id) references core.transaction_registry (id, organization_id),
  foreign key (replacement_txn_id, organization_id) references core.transaction_registry (id, organization_id)
);
create unique index corrections_one_open_per_txn on core.corrections (original_txn_id) where status in ('open','approved','reversed');

create table core.transaction_links (
  id              uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  from_txn_id     uuid not null,
  to_txn_id       uuid not null,
  link_kind       text not null check (link_kind in ('reversal_of','replacement_of','source')),
  created_at      timestamptz not null default now(),
  foreign key (from_txn_id, organization_id) references core.transaction_registry (id, organization_id),
  foreign key (to_txn_id, organization_id)   references core.transaction_registry (id, organization_id)
);
create trigger trg_txn_links_immutable before update or delete on core.transaction_links
  for each row execute function core.fn_deny_mutation();

reset role;
