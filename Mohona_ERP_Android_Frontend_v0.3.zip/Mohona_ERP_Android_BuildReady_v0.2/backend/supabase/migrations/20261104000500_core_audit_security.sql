-- 20261104000500_core_audit_security.sql
-- Append-only, hash-chained audit per company; security events. Baseline §7.1.
-- DEVIATION (declared): audit_logs is NOT partitioned yet; partition strategy waits for Spike S6 (CR if S6 changes it).
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create function core.fn_deny_mutation() returns trigger language plpgsql as $$
begin
  raise exception 'E_APPEND_ONLY: % on %.% is not allowed', tg_op, tg_table_schema, tg_table_name using errcode = 'P0001';
end $$;

create table core.audit_chain_heads (
  organization_id uuid primary key references core.organizations(id),
  last_seq        bigint not null default 0,
  last_hash       bytea  not null default '\x00'::bytea
);

create table core.audit_logs (
  organization_id       uuid   not null references core.organizations(id),
  seq                   bigint not null,
  occurred_at           timestamptz not null,
  actor_employee_id     uuid,
  actor_organization_id uuid,
  actor_kind            text   not null default 'company_staff' check (actor_kind in ('company_staff','group_staff','system')),
  action                text   not null,
  entity_type           text,
  entity_id             uuid,
  outcome               text   not null default 'success',
  detail                jsonb  not null default '{}'::jsonb,
  request_id            text,
  prev_hash             bytea  not null,
  row_hash              bytea  not null,
  primary key (organization_id, seq)
);
create trigger trg_audit_logs_no_update before update or delete on core.audit_logs
  for each row execute function core.fn_deny_mutation();
create trigger trg_audit_logs_no_truncate before truncate on core.audit_logs
  for each statement execute function core.fn_deny_mutation();

create function core.fn_audit_digest(p_prev bytea, p_org uuid, p_seq bigint, p_ts timestamptz, p_actor uuid,
                                     p_action text, p_etype text, p_eid uuid, p_outcome text, p_detail jsonb)
returns bytea language sql immutable set search_path = pg_catalog, public, extensions as $$
  select digest(
    p_prev || convert_to(concat_ws('|', p_org::text, p_seq::text,
      to_char(p_ts at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US'),
      coalesce(p_actor::text,''), p_action, coalesce(p_etype,''), coalesce(p_eid::text,''), p_outcome, p_detail::text), 'UTF8'),
    'sha256')
$$;

-- The ONLY writer. Serialises per company through the chain-head row (lock level L10: always last).
create function core.fn_write_audit(p_org uuid, p_actor uuid, p_action text, p_entity_type text default null,
                                    p_entity_id uuid default null, p_outcome text default 'success',
                                    p_detail jsonb default '{}'::jsonb, p_request_id text default null)
returns bigint language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare
  v_head core.audit_chain_heads%rowtype; v_seq bigint; v_ts timestamptz := clock_timestamp(); v_hash bytea;
begin
  insert into core.audit_chain_heads (organization_id) values (p_org) on conflict do nothing;
  select * into v_head from core.audit_chain_heads where organization_id = p_org for update;
  v_seq  := v_head.last_seq + 1;
  v_hash := core.fn_audit_digest(v_head.last_hash, p_org, v_seq, v_ts, p_actor, p_action, p_entity_type, p_entity_id, p_outcome, p_detail);
  insert into core.audit_logs (organization_id, seq, occurred_at, actor_employee_id, actor_organization_id, action,
                               entity_type, entity_id, outcome, detail, request_id, prev_hash, row_hash)
  values (p_org, v_seq, v_ts, p_actor, case when p_actor is null then null else p_org end, p_action,
          p_entity_type, p_entity_id, p_outcome, p_detail, p_request_id, v_head.last_hash, v_hash);
  update core.audit_chain_heads set last_seq = v_seq, last_hash = v_hash where organization_id = p_org;
  return v_seq;
end $$;

-- Verifier: returns the first broken sequence number, or NULL when the whole chain is intact.
create function core.fn_verify_audit_chain(p_org uuid) returns bigint
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare r core.audit_logs%rowtype; v_prev bytea := '\x00'::bytea; v_expect bytea; v_n bigint := 0;
begin
  for r in select * from core.audit_logs where organization_id = p_org order by seq loop
    v_n := v_n + 1;
    if r.seq <> v_n or r.prev_hash <> v_prev then return r.seq; end if;
    v_expect := core.fn_audit_digest(v_prev, r.organization_id, r.seq, r.occurred_at, r.actor_employee_id,
                                     r.action, r.entity_type, r.entity_id, r.outcome, r.detail);
    if v_expect <> r.row_hash then return r.seq; end if;
    v_prev := r.row_hash;
  end loop;
  if exists (select 1 from core.audit_chain_heads h where h.organization_id = p_org and (h.last_seq <> v_n or h.last_hash <> v_prev)) then
    return v_n + 1;
  end if;
  return null;
end $$;

create table core.security_events (
  id                     bigint generated always as identity primary key,
  organization_id        uuid references core.organizations(id),   -- the ACTOR's company (v0.2.7 rule)
  target_organization_id uuid,
  occurred_at            timestamptz not null default now(),
  actor_employee_id      uuid,
  event_kind             text not null,
  outcome                text not null,
  detail                 jsonb not null default '{}'::jsonb
);
create trigger trg_security_events_no_update before update or delete on core.security_events
  for each row execute function core.fn_deny_mutation();

reset role;
