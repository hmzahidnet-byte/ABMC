-- 20261104000700_core_approvals.sql
-- Approval rules (versioned), requests, steps, actions. Maker-Checker / no-self-approval enforced in the DATABASE too (T01).
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create table core.approval_rules (
  id                  uuid primary key default gen_random_uuid(),
  organization_id     uuid not null references core.organizations(id),
  transaction_type_id uuid not null references core.transaction_types(id),
  wing_id             uuid,
  name                text not null,
  status              text not null default 'active' check (status in ('active','inactive')),
  current_version_id  uuid,
  unique (id, organization_id),
  foreign key (wing_id, organization_id) references core.wings (id, organization_id)
);
create unique index approval_rules_one_active on core.approval_rules (organization_id, transaction_type_id, coalesce(wing_id, '00000000-0000-0000-0000-000000000000'::uuid)) where status = 'active';

create table core.approval_rule_versions (
  id              uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  rule_id         uuid not null,
  version_no      integer not null,
  status          text not null default 'draft' check (status in ('draft','active','retired')),
  effective_from  timestamptz not null default now(),
  effective_to    timestamptz,
  change_reason   text not null,
  unique (id, organization_id),
  unique (rule_id, version_no),
  foreign key (rule_id, organization_id) references core.approval_rules (id, organization_id)
);
create unique index approval_rule_versions_one_active on core.approval_rule_versions (rule_id) where status = 'active';
alter table core.approval_rules add constraint approval_rules_current_version
  foreign key (current_version_id, organization_id) references core.approval_rule_versions (id, organization_id) deferrable initially deferred;

create table core.approval_rule_steps (
  id               uuid primary key default gen_random_uuid(),
  organization_id  uuid not null,
  rule_version_id  uuid not null,
  step_no          integer not null check (step_no >= 1),
  mode             text not null default 'any_one' check (mode in ('any_one','all','n_of_m')),
  required_count   integer not null default 1 check (required_count >= 1),
  approver_role_code text not null references core.roles(role_code),
  unique (rule_version_id, step_no),
  foreign key (rule_version_id, organization_id) references core.approval_rule_versions (id, organization_id)
);

create table core.approval_requests (
  id              uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  txn_id          uuid not null,
  rule_version_id uuid not null,                       -- bound at submit (#11)
  status          text not null default 'pending' check (status in ('pending','approved','rejected','returned','cancelled')),
  submitted_by    uuid not null,
  submitted_at    timestamptz not null default now(),
  unique (id, organization_id),
  foreign key (txn_id, organization_id) references core.transaction_registry (id, organization_id),
  foreign key (rule_version_id, organization_id) references core.approval_rule_versions (id, organization_id),
  foreign key (submitted_by, organization_id) references core.employees (id, organization_id)
);
create unique index approval_requests_one_pending on core.approval_requests (txn_id) where status = 'pending';

create table core.approval_request_steps (
  id                uuid primary key default gen_random_uuid(),
  organization_id   uuid not null,
  request_id        uuid not null,
  step_no           integer not null,
  mode              text not null,
  required_count    integer not null,
  approver_role_code text not null references core.roles(role_code),
  status            text not null default 'waiting' check (status in ('waiting','active','approved','rejected','skipped')),
  eligible_snapshot uuid[] not null default '{}',      -- #35: eligible approvers at activation time
  unique (id, organization_id),
  unique (request_id, step_no),
  foreign key (request_id, organization_id) references core.approval_requests (id, organization_id)
);

create table core.approval_actions (
  id                    uuid primary key default gen_random_uuid(),
  organization_id       uuid not null,
  request_step_id       uuid not null,
  actor_employee_id     uuid not null,
  actor_organization_id uuid not null,
  actor_kind            text not null default 'company_staff' check (actor_kind in ('company_staff','group_staff')),
  authority_path        text not null default 'company_step' check (authority_path in ('company_step','group_step','group_override')),
  decision              text not null check (decision in ('approve','reject','return')),
  reason                text,
  acted_at              timestamptz not null default now(),
  foreign key (request_step_id, organization_id) references core.approval_request_steps (id, organization_id),
  foreign key (actor_employee_id, actor_organization_id) references core.employees (id, organization_id),
  -- First Slice supports company_step only: the actor must belong to the same company (OD-02/OD-03).
  constraint approval_actions_company_path check (authority_path <> 'company_step' or actor_organization_id = organization_id),
  unique (request_step_id, actor_employee_id)
);
create trigger trg_approval_actions_immutable before update or delete on core.approval_actions
  for each row execute function core.fn_deny_mutation();

-- No-self-approval at DB level (T01): the actor may not be the creator or submitter of the transaction.
create function core.fn_approval_no_self() returns trigger language plpgsql as $$
declare v_creator uuid; v_submitter uuid;
begin
  select t.created_by, r.submitted_by into v_creator, v_submitter
    from core.approval_request_steps s
    join core.approval_requests r on r.id = s.request_id and r.organization_id = s.organization_id
    join core.transaction_registry t on t.id = r.txn_id and t.organization_id = r.organization_id
   where s.id = new.request_step_id and s.organization_id = new.organization_id;
  if new.actor_employee_id in (v_creator, v_submitter) then
    raise exception 'E_SELF_APPROVAL' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_approval_actions_no_self before insert on core.approval_actions
  for each row execute function core.fn_approval_no_self();

reset role;
