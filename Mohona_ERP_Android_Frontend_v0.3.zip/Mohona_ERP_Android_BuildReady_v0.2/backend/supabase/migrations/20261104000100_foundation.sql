-- 20261104000100_foundation.sql
-- Roles, schemas, privilege baseline. Appendix E / Baseline §4.1 (R-S1, R-S2). OD-01..OD-04 context.
-- STATUS: WRITTEN, NOT EXECUTED (no PostgreSQL/Supabase access when authored). First execution = Spike S2 / BF-1.
-- ASSUMPTIONS TO VERIFY ON SUPABASE (Spike S2): migration role may CREATE ROLE, GRANT erp_owner TO itself, SET ROLE erp_owner.

create extension if not exists pgcrypto;

do $$
begin
  if not exists (select 1 from pg_roles where rolname = 'erp_owner') then
    create role erp_owner nologin nobypassrls;
  end if;
end $$;

grant erp_owner to current_user;

create schema if not exists core    authorization erp_owner;
create schema if not exists finance authorization erp_owner;
create schema if not exists hr      authorization erp_owner;
create schema if not exists api     authorization erp_owner;
create schema if not exists svc     authorization erp_owner;

-- No implicit access for anyone but the owner (R-S2).
revoke all on schema core, finance, hr, svc from public;
revoke all on schema api from public;

-- Functions are executable by PUBLIC by default; remove that for everything erp_owner creates.
alter default privileges for role erp_owner revoke execute on functions from public;
alter default privileges for role erp_owner in schema core, finance, hr, api, svc
  revoke all on tables    from public;
alter default privileges for role erp_owner in schema core, finance, hr, api, svc
  revoke all on sequences from public;

-- Only the API schema is reachable by logged-in app users. anon gets nothing.
do $$
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    grant usage on schema api  to authenticated;
    grant usage on schema core to authenticated;   -- needed so SECURITY INVOKER api wrappers can call core.fn_* (EXECUTE is granted per function)
  end if;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    grant usage on schema svc to service_role;     -- svc_* worker functions only (Class-S allowlist)
  end if;
end $$;

do $$ begin if exists (select 1 from pg_namespace where nspname='extensions') then grant usage on schema extensions to erp_owner; end if; end $$;
