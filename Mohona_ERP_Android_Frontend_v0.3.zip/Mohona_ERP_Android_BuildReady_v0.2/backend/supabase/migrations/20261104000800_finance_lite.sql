-- 20261104000800_finance_lite.sql
-- Fiscal years/periods and the Slice-0 Finance-lite (accounts, cash vouchers, ledger, balances). Appendix E §G8.
-- OD-03: cross-company posting is impossible at the DATABASE boundary: every FK below is composite (id, organization_id).
-- STATUS: WRITTEN, NOT EXECUTED. Single currency BDT (assumption; multi-currency out of scope).
set role erp_owner;

create table core.fiscal_years (
  id              uuid primary key default gen_random_uuid(),
  organization_id uuid not null references core.organizations(id),
  name            text not null,
  start_date      date not null,
  end_date        date not null,
  status          text not null default 'open' check (status in ('open','closing','closed')),
  unique (id, organization_id),
  unique (organization_id, name),
  check (end_date > start_date)
);

create table core.accounting_periods (
  id              uuid primary key default gen_random_uuid(),
  organization_id uuid not null,
  fiscal_year_id  uuid not null,
  period_no       integer not null check (period_no >= 1),
  start_date      date not null,
  end_date        date not null,
  status          text not null default 'open' check (status in ('open','closed')),
  closed_at       timestamptz,
  unique (id, organization_id),
  unique (fiscal_year_id, period_no),
  check (end_date >= start_date),
  foreign key (fiscal_year_id, organization_id) references core.fiscal_years (id, organization_id)
);

-- Overlap guard without relying on the btree_gist extension (availability is a Spike S1 question).
create function core.fn_period_no_overlap() returns trigger language plpgsql as $$
begin
  if exists (select 1 from core.accounting_periods p
              where p.organization_id = new.organization_id and p.id <> new.id
                and daterange(p.start_date, p.end_date, '[]') && daterange(new.start_date, new.end_date, '[]')) then
    raise exception 'E_PERIOD_ORDER: overlapping accounting period' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_period_no_overlap before insert or update on core.accounting_periods
  for each row execute function core.fn_period_no_overlap();

create table finance.accounts (
  id              uuid primary key default gen_random_uuid(),
  organization_id uuid not null references core.organizations(id),
  code            text not null,
  name_bn         text not null,
  account_type    text not null check (account_type in ('asset','liability','equity','income','expense')),
  parent_account_id uuid,
  is_cash         boolean not null default false,
  is_postable     boolean not null default true,
  wing_id         uuid,
  status          text not null default 'active' check (status in ('active','inactive')),
  unique (id, organization_id),
  unique (organization_id, code),
  foreign key (parent_account_id, organization_id) references finance.accounts (id, organization_id),
  foreign key (wing_id, organization_id) references core.wings (id, organization_id)
);

create table finance.cash_vouchers (
  txn_id             uuid primary key,
  organization_id    uuid not null,
  wing_id            uuid not null,
  voucher_kind       text not null check (voucher_kind in ('payment','receipt')),
  cash_account_id    uuid not null,
  counter_account_id uuid not null,
  amount             numeric(18,2) not null check (amount > 0),
  narration          text,
  foreign key (txn_id, organization_id) references core.transaction_registry (id, organization_id),
  foreign key (wing_id, organization_id) references core.wings (id, organization_id),
  foreign key (cash_account_id, organization_id) references finance.accounts (id, organization_id),
  foreign key (counter_account_id, organization_id) references finance.accounts (id, organization_id),
  check (cash_account_id <> counter_account_id)
);

create table finance.ledger_entries (
  id                   bigint generated always as identity primary key,
  organization_id      uuid not null,
  txn_id               uuid not null,
  entry_no             integer not null,
  account_id           uuid not null,
  debit                numeric(18,2) not null default 0 check (debit >= 0),
  credit               numeric(18,2) not null default 0 check (credit >= 0),
  posting_date         date not null,
  period_id            uuid not null,
  posted_at            timestamptz not null default now(),
  actor_employee_id    uuid not null,                         -- original actor, immutable
  reversal_of_entry_id bigint references finance.ledger_entries(id),
  unique (txn_id, entry_no),
  constraint ledger_one_side check ((debit > 0)::int + (credit > 0)::int = 1),
  foreign key (txn_id, organization_id)     references core.transaction_registry (id, organization_id),
  foreign key (account_id, organization_id) references finance.accounts (id, organization_id),
  foreign key (period_id, organization_id)  references core.accounting_periods (id, organization_id),
  foreign key (actor_employee_id, organization_id) references core.employees (id, organization_id)
);
create index ledger_entries_account on finance.ledger_entries (organization_id, account_id, id);

create trigger trg_ledger_append_only before update or delete on finance.ledger_entries
  for each row execute function core.fn_deny_mutation();
create trigger trg_ledger_no_truncate before truncate on finance.ledger_entries
  for each statement execute function core.fn_deny_mutation();

-- Single posting path (T295): inserts are only accepted inside a posting function that announces itself.
create function finance.fn_guard_posting() returns trigger language plpgsql as $$
begin
  if coalesce(current_setting('mohona.in_posting', true), '') <> 'on' then
    raise exception 'E_POSTING_PATH: ledger rows may only be written by the posting function' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_ledger_guard before insert on finance.ledger_entries
  for each row execute function finance.fn_guard_posting();

-- Double-entry balance per transaction, checked at COMMIT (T291).
create function finance.fn_check_txn_balanced() returns trigger language plpgsql as $$
declare v numeric(18,2);
begin
  select coalesce(sum(debit),0) - coalesce(sum(credit),0) into v
    from finance.ledger_entries where txn_id = new.txn_id and organization_id = new.organization_id;
  if v <> 0 then raise exception 'E_UNBALANCED: transaction % differs by %', new.txn_id, v using errcode = 'P0001'; end if;
  return null;
end $$;
create constraint trigger trg_ledger_balanced after insert on finance.ledger_entries
  deferrable initially deferred for each row execute function finance.fn_check_txn_balanced();

create table finance.account_balances (
  organization_id uuid not null,
  account_id      uuid not null,
  balance         numeric(18,2) not null default 0,
  last_entry_id   bigint,
  version         integer not null default 0,
  primary key (organization_id, account_id),
  foreign key (account_id, organization_id) references finance.accounts (id, organization_id)
);

reset role;
