-- 20261104000300_core_rbac.sql
-- Permission catalog, the 17 OWNER-APPROVED roles (OD-04), role->permission scope rules, per-employee role grants.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create table core.permissions (
  code        text primary key,
  domain      text not null,
  sensitivity text not null check (sensitivity in ('normal','sensitive')),
  note        text,
  status      text not null default 'registered' check (status in ('active','registered','retired')),
  -- 'registered' = exists in the registry but NOT enforceable yet (future-Wing placeholders, OD-04 rule).
  check (status <> 'active' or domain not in ('Mfg','Procurement','Sales','Inventory'))
);

-- Role ID = role_code and is STABLE (OD-04).
create table core.roles (
  role_code        text primary key,
  description      text,
  owner_confirmed  boolean not null default false,   -- only CHAIRMAN and MD were confirmed before OD-04
  approval_ref     text not null,
  status           text not null default 'approved' check (status in ('approved','retired')),
  check (role_code = upper(role_code))
);

create table core.role_permissions (
  role_code       text not null references core.roles(role_code),
  permission_code text not null references core.permissions(code),
  scope_rule      text not null,        -- G | O | W | D | L | A | S | O/W | W/O | O/G | G/O | NONE
  scope_note      text,
  effective_from  timestamptz not null default now(),
  effective_to    timestamptz,
  primary key (role_code, permission_code),
  check (effective_to is null or effective_to >= effective_from)
);

-- Company-scoped grants. The composite FK makes a cross-company grant impossible (OD-02, T306).
create table core.user_roles (
  id               uuid primary key default gen_random_uuid(),
  organization_id  uuid not null,
  employee_id      uuid not null,
  role_code        text not null references core.roles(role_code),
  scope_type       text not null default 'organization'
                   check (scope_type in ('group','organization','wing','department','location','self')),
  scope_id         uuid,
  effective_from   timestamptz not null default now(),   -- timestamptz: mid-day revocation must take effect at once
  effective_to     timestamptz,
  granted_by       uuid,
  grant_approval_id uuid,
  constraint user_roles_span check (effective_to is null or effective_to >= effective_from),
  constraint user_roles_scope check (scope_type in ('organization','self') or scope_id is not null),
  foreign key (employee_id, organization_id) references core.employees (id, organization_id)
);
create index user_roles_lookup on core.user_roles (organization_id, employee_id);

reset role;
