-- 20261104000200_core_org_identity.sql
-- Organization, structure, employees, per-company login accounts (OD-02), assignments.
-- Appendix E §core.organizations … employee_positions. STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create table core.organizations (
  id                     uuid primary key default gen_random_uuid(),
  kind                   text not null check (kind in ('group','company')),
  parent_organization_id uuid references core.organizations(id),
  code                   text not null unique,
  name                   text not null,
  legal_name             text,
  status                 text not null default 'provisioning'
                         check (status in ('provisioning','active','suspending','suspended','cancelled')),
  status_epoch           integer not null default 0,
  created_at             timestamptz not null default now(),
  constraint organizations_kind_parent check (
    (kind = 'group'   and parent_organization_id is null) or
    (kind = 'company' and parent_organization_id is not null))
);
create unique index organizations_single_group on core.organizations ((true)) where kind = 'group';

create function core.fn_organizations_immutable() returns trigger language plpgsql as $$
begin
  if new.kind is distinct from old.kind
     or new.parent_organization_id is distinct from old.parent_organization_id
     or new.code is distinct from old.code then
    raise exception 'E_IMMUTABLE: organization kind/parent/code cannot change' using errcode = 'P0001';
  end if;
  if new.status is distinct from old.status then
    new.status_epoch := old.status_epoch + 1;
  end if;
  return new;
end $$;
create trigger trg_organizations_immutable before update on core.organizations
  for each row execute function core.fn_organizations_immutable();

create table core.wings (
  id              uuid primary key default gen_random_uuid(),
  organization_id uuid not null references core.organizations(id),
  code            text not null,
  name            text not null,
  status          text not null default 'active' check (status in ('active','inactive')),
  unique (id, organization_id),
  unique (organization_id, code)
);

create table core.departments (
  id                   uuid primary key default gen_random_uuid(),
  organization_id      uuid not null,
  wing_id              uuid not null,
  parent_department_id uuid,
  code                 text not null,
  name                 text not null,
  status               text not null default 'active' check (status in ('active','inactive')),
  unique (id, organization_id),
  unique (wing_id, code),
  foreign key (wing_id, organization_id) references core.wings (id, organization_id),
  foreign key (parent_department_id, organization_id) references core.departments (id, organization_id)
);

create table core.positions (
  id                     uuid primary key default gen_random_uuid(),
  organization_id        uuid not null,
  department_id          uuid not null,
  code                   text not null,
  title                  text not null,
  level                  integer not null default 0 check (level >= 0),
  allows_multiple_holders boolean not null default false,
  status                 text not null default 'active' check (status in ('active','inactive')),
  unique (id, organization_id),
  unique (department_id, code),
  foreign key (department_id, organization_id) references core.departments (id, organization_id)
);

create table core.employees (
  id                      uuid primary key default gen_random_uuid(),
  organization_id         uuid not null references core.organizations(id),
  employee_no             text not null,
  full_name               text not null,
  full_name_bn            text,
  phone                   text,
  email                   text,
  joined_on               date not null default current_date,
  primary_wing_id         uuid not null,
  employment_status       text not null default 'active'
                          check (employment_status in ('active','suspended','resigned','terminated')),
  separated_on            date,
  separated_effective_at  timestamptz,
  is_first_md             boolean not null default false,
  authz_epoch             integer not null default 0,
  created_at              timestamptz not null default now(),
  unique (id, organization_id),
  unique (organization_id, employee_no),
  foreign key (primary_wing_id, organization_id) references core.wings (id, organization_id),
  constraint employees_separation check (
    employment_status not in ('resigned','terminated') or separated_on is not null)
);
-- No DELETE privilege is ever granted on employees (Appendix A rule).

-- OD-02: one separate login account PER COMPANY. A person working in two companies has two employee rows
-- and two accounts with two different auth identities. No cross-company person link is stored (F3: nothing shared).
create table core.employee_accounts (
  employee_id     uuid primary key,
  organization_id uuid not null,
  auth_user_id    uuid not null unique,      -- Supabase auth.users.id; FK deliberately omitted (cross-owner privilege unverified, Spike S3)
  login_handle    text not null,             -- company-scoped sign-in name; mapped to a synthetic auth identifier by the client
  account_status  text not null default 'active' check (account_status in ('active','disabled','locked')),
  mfa_required    boolean not null default true,
  created_at      timestamptz not null default now(),
  unique (organization_id, login_handle),
  foreign key (employee_id, organization_id) references core.employees (id, organization_id)
);

create table core.employee_positions (
  id                     uuid primary key default gen_random_uuid(),
  organization_id        uuid not null,
  employee_id            uuid not null,
  position_id            uuid not null,
  effective_at           timestamptz not null,          -- business time (reports/attribution)
  activated_at           timestamptz,                   -- system time: the ONLY authority-determining clock (Succession §2.5)
  effective_to           timestamptz,
  status                 text not null default 'active' check (status in ('active','suspended','ended')),
  assignment_kind        text not null default 'regular' check (assignment_kind in ('regular','interim','emergency')),
  responsibility_classes text[] not null default '{}',
  constraint employee_positions_span check (effective_to is null or effective_to >= effective_at),
  foreign key (employee_id, organization_id) references core.employees (id, organization_id),
  foreign key (position_id, organization_id) references core.positions (id, organization_id)
);
create index employee_positions_employee on core.employee_positions (organization_id, employee_id);

reset role;
