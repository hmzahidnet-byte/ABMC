-- 20261104000900_authz_rls_api.sql
-- Live Authorization (never from JWT claims), RLS on every company-owned table, first API function.
-- OD-02: an account belongs to exactly ONE company, so the session context IS that company; no company switching.
-- OD-04: permissions are enforced HERE and in RPCs — never only in the Android UI.
-- ASSUMPTIONS TO VERIFY (Spike S3): auth.uid(), auth.jwt() and auth.sessions are readable by erp_owner SECURITY DEFINER functions.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- The JWT carries identity (sub), aal and session_id only. The session must still exist in auth.sessions (revocation).
create function core.fn_session_alive() returns boolean
language sql stable security definer set search_path = pg_catalog, auth as $$
  select exists (select 1 from auth.sessions s where s.id = nullif(auth.jwt() ->> 'session_id', '')::uuid)
$$;

create function core.fn_current_employee_id() returns uuid
language sql stable security definer set search_path = pg_catalog, public as $$
  select a.employee_id
    from core.employee_accounts a
    join core.employees e     on e.id = a.employee_id and e.organization_id = a.organization_id
    join core.organizations o on o.id = a.organization_id
   where a.auth_user_id = auth.uid()
     and a.account_status = 'active'
     and e.employment_status = 'active'
     and o.status = 'active'
     and core.fn_session_alive()
$$;

create function core.fn_current_org_id() returns uuid
language sql stable security definer set search_path = pg_catalog, public as $$
  select e.organization_id from core.employees e where e.id = core.fn_current_employee_id()
$$;

-- Live permission check. Placeholder/registered permissions never pass (OD-04).
create function core.fn_has_permission(p_code text) returns boolean
language sql stable security definer set search_path = pg_catalog, public as $$
  select exists (
    select 1
      from core.user_roles ur
      join core.role_permissions rp on rp.role_code = ur.role_code
      join core.permissions p       on p.code = rp.permission_code
     where ur.employee_id = core.fn_current_employee_id()
       and ur.organization_id = core.fn_current_org_id()
       and now() >= ur.effective_from and now() < coalesce(ur.effective_to, 'infinity'::timestamptz)
       and now() >= rp.effective_from and now() < coalesce(rp.effective_to, 'infinity'::timestamptz)
       and p.status = 'active'
       and rp.scope_rule <> 'NONE'
       and rp.permission_code = p_code)
$$;

create function core.fn_get_my_permissions() returns jsonb
language sql stable security definer set search_path = pg_catalog, public as $$
  select coalesce(jsonb_build_object(
    'employee_id',     core.fn_current_employee_id(),
    'organization_id', core.fn_current_org_id(),
    'roles', (select coalesce(jsonb_agg(distinct ur.role_code), '[]'::jsonb) from core.user_roles ur
               where ur.employee_id = core.fn_current_employee_id() and ur.organization_id = core.fn_current_org_id()
                 and now() >= ur.effective_from and now() < coalesce(ur.effective_to, 'infinity'::timestamptz)),
    'permissions', (select coalesce(jsonb_agg(distinct jsonb_build_object('code', rp.permission_code, 'scope', rp.scope_rule)), '[]'::jsonb)
                      from core.user_roles ur
                      join core.role_permissions rp on rp.role_code = ur.role_code
                      join core.permissions p on p.code = rp.permission_code and p.status = 'active'
                     where ur.employee_id = core.fn_current_employee_id() and ur.organization_id = core.fn_current_org_id()
                       and now() >= ur.effective_from and now() < coalesce(ur.effective_to, 'infinity'::timestamptz)
                       and now() >= rp.effective_from and now() < coalesce(rp.effective_to, 'infinity'::timestamptz)
                       and rp.scope_rule <> 'NONE')
  ), jsonb_build_object('error', 'E_AUTH'))
$$;

-- RLS: defence in depth on every company-owned table. App users have NO table privileges at all (reads/writes go through api RPCs).
do $$
declare r record;
begin
  for r in
    select c.table_schema, c.table_name
      from information_schema.columns c
      join information_schema.tables t on t.table_schema = c.table_schema and t.table_name = c.table_name and t.table_type = 'BASE TABLE'
     where c.column_name = 'organization_id' and c.table_schema in ('core','finance','hr')
  loop
    execute format('alter table %I.%I enable row level security', r.table_schema, r.table_name);
    execute format('drop policy if exists company_isolation_select on %I.%I', r.table_schema, r.table_name);
    execute format('create policy company_isolation_select on %I.%I for select to authenticated using (organization_id = core.fn_current_org_id())', r.table_schema, r.table_name);
  end loop;
end $$;
alter table core.organizations enable row level security;
create policy own_company_select on core.organizations for select to authenticated using (id = core.fn_current_org_id());

-- First API function (SECURITY INVOKER wrapper; the caller needs EXECUTE only on exactly these functions).
create function api.v1_get_my_permissions() returns jsonb
language sql stable security invoker set search_path = pg_catalog as $$ select core.fn_get_my_permissions() $$;

do $$
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    grant execute on function core.fn_get_my_permissions() to authenticated;
    grant execute on function api.v1_get_my_permissions() to authenticated;
  end if;
end $$;

reset role;
