-- Spike S1: PostgreSQL version and extensions. Run in the Supabase SQL editor (Staging project ONLY).
-- Evidence to keep: the full result grid (screenshot or copy), date, plan, region.
select version();
show server_version;
select name, default_version, installed_version from pg_available_extensions
 where name in ('pgcrypto','btree_gist','pg_cron','pgtap','pg_stat_statements') order by name;
-- PASS: version recorded (target PG17; record the real value); pgcrypto available.
-- btree_gist / pg_cron / pgtap availability decide: Exclusion constraints, scheduled workers (S10), SQL-test framework.
