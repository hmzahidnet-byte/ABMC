#!/usr/bin/env python3
"""Spike S3 — Auth: login, live-permission RPC, MFA claim, and revocation timing. Run against a STAGING Supabase project only.
Needs migrations 20261104000100..900 applied and ONE test company/employee/account seeded (see docs/EVIDENCE/README.md).
Environment: SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_KEY, TEST_EMAIL, TEST_PASSWORD, TEST_AUTH_USER_ID (the auth.users id mapped in core.employee_accounts).
Uses only the Python standard library. Prints a JSON evidence record; it never prints keys. STATUS: WRITTEN, NOT EXECUTED."""
import json, os, sys, time, base64, urllib.request, urllib.error

def env(k):
    v = os.environ.get(k)
    if not v: sys.exit(f"missing environment variable {k}")
    return v

URL = env("SUPABASE_URL").rstrip("/"); ANON = env("SUPABASE_ANON_KEY"); EMAIL = env("TEST_EMAIL"); PASSWORD = env("TEST_PASSWORD")

def call(method, path, body=None, token=None, key=None, headers=None):
    h = {"apikey": key or ANON, "Content-Type": "application/json"}
    if token: h["Authorization"] = f"Bearer {token}"
    if headers: h.update(headers)
    req = urllib.request.Request(URL + path, method=method, headers=h, data=(json.dumps(body).encode() if body is not None else None))
    t0 = time.monotonic()
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            raw = r.read().decode() or "null"; code = r.status
    except urllib.error.HTTPError as e:
        raw = e.read().decode() or "null"; code = e.code
    try: data = json.loads(raw)
    except Exception: data = raw
    return code, data, round((time.monotonic() - t0) * 1000)

def jwt_claims(tok):
    p = tok.split(".")[1]; p += "=" * (-len(p) % 4)
    return json.loads(base64.urlsafe_b64decode(p))

def rpc(token):  # api schema is the only exposed schema
    return call("POST", "/rest/v1/rpc/v1_get_my_permissions", {}, token=token, headers={"Content-Profile": "api", "Accept-Profile": "api"})

ev = {"spike": "S3", "started": time.strftime("%FT%TZ", time.gmtime())}
code, tok, ms = call("POST", "/auth/v1/token?grant_type=password", {"email": EMAIL, "password": PASSWORD})
ev["login"] = {"http": code, "ms": ms}
if code != 200: print(json.dumps(ev)); sys.exit("login failed")
access = tok["access_token"]; claims = jwt_claims(access)
ev["claims"] = {"has_session_id": "session_id" in claims, "aal": claims.get("aal"), "exp_in_s": claims["exp"] - int(time.time()), "custom_authz_claims_present": any(k in claims for k in ("role_codes", "permissions", "org_id"))}
code, data, ms = rpc(access)
ev["rpc_before_revoke"] = {"http": code, "ms": ms, "has_permissions": isinstance(data, dict) and bool(data.get("permissions")), "sample": data if isinstance(data, dict) and "error" in data else "ok"}
code, _, ms = call("POST", "/auth/v1/logout?scope=global", None, token=access)
ev["global_signout"] = {"http": code, "ms": ms}
t0 = time.monotonic(); denied_after_ms = None
for _ in range(50):
    code, data, ms = rpc(access)
    if isinstance(data, dict) and data.get("error") == "E_AUTH":
        denied_after_ms = round((time.monotonic() - t0) * 1000); break
    time.sleep(0.2)
ev["rpc_after_signout"] = {"jwt_still_unexpired": claims["exp"] > time.time(), "denied_after_ms": denied_after_ms}
ev["PASS_CRITERIA"] = {"revocation_denies_within_1s": denied_after_ms is not None and denied_after_ms <= 1000,
                       "no_authz_in_jwt": not ev["claims"]["custom_authz_claims_present"], "session_id_present": ev["claims"]["has_session_id"]}
print(json.dumps(ev, indent=2, ensure_ascii=False))
