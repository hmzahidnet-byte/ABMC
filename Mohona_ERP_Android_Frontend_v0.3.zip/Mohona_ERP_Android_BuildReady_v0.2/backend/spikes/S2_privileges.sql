-- Spike S2: privilege model. Run AFTER migration 20261104000100 and 20261104000200 on Staging.
-- It tries forbidden actions as anon / authenticated / service_role and records whether each was DENIED.
-- PASS = every probe says denied=true. Keep the output as evidence. Any 'false' = a hole (stop and report).
create temp table if not exists spike_s2 (probe text, role_name text, denied boolean, detail text);
create or replace function pg_temp.probe(p_role text, p_sql text, p_label text) returns void language plpgsql as $$
declare v_denied boolean := false; v_detail text := 'executed without error';
begin
  begin
    execute format('set local role %I', p_role);
    execute p_sql;
  exception when others then v_denied := true; v_detail := sqlerrm;
  end;
  reset role;
  insert into spike_s2 values (p_label, p_role, v_denied, v_detail);
end $$;
do $$
declare r text;
begin
  foreach r in array array['anon','authenticated','service_role'] loop
    perform pg_temp.probe(r, 'select * from core.organizations limit 1', 'select core.organizations');
    perform pg_temp.probe(r, 'select * from core.employee_accounts limit 1', 'select core.employee_accounts');
    perform pg_temp.probe(r, $$insert into core.organizations (kind, code, name) values ('group','SPIKE','x')$$, 'insert core.organizations');
    perform pg_temp.probe(r, 'select * from core.role_permissions limit 1', 'select core.role_permissions');
    perform pg_temp.probe(r, 'select * from finance.ledger_entries limit 1', 'select finance.ledger_entries');
    perform pg_temp.probe(r, 'select core.fn_write_audit(gen_random_uuid(), null, ''spike'')', 'execute core.fn_write_audit');
  end loop;
end $$;
select * from spike_s2 order by role_name, probe;
select count(*) filter (where not denied) as holes from spike_s2;   -- PASS requires holes = 0
-- ALSO CHECK BY HAND and record: (a) can the migration role really CREATE ROLE erp_owner and SET ROLE erp_owner?
--   (b) is only the api schema exposed in Settings > API > Exposed schemas? (c) does service_role still have table privileges anywhere?
