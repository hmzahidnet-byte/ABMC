#!/usr/bin/env python3
"""Source of truth for the Mohona ERP DEMO dataset (fictional). Produces app/src/main/assets/demo/demo_data.json and verifies the graph.
Every number a screen shows is derived here (moving weighted average, reconciliation, dues); the Kotlin Costing use-case recomputes the same
numbers at runtime and the JVM unit tests compare both. Nothing here is approved business policy: rounding and cost allocation rules are DEMO choices."""
import json, os, sys
from decimal import Decimal as D, ROUND_HALF_UP
from collections import defaultdict, OrderedDict

BN = '০১২৩৪৫৬৭৮৯'
def bn(s): return ''.join(BN[int(c)] if c.isdigit() else c for c in str(s))
def q(x, p): return x.quantize(D(1).scaleb(-p), rounding=ROUND_HALF_UP)
def grp(n):
    s = str(abs(int(n)))
    if len(s) <= 3: return s
    last, rest, parts = s[-3:], s[:-3], []
    while len(rest) > 2: parts.insert(0, rest[-2:]); rest = rest[:-2]
    if rest: parts.insert(0, rest)
    return ','.join(parts) + ',' + last
def money(x):
    x = q(D(x), 2); ip = int(x); frac = x - ip
    s = grp(ip) + ('' if frac == 0 else ('.%02d' % int((frac * 100).to_integral_value())))
    return bn('৳ ' + ('-' if x < 0 else '') + s)
def qty(x, unit=''):
    x = D(x).normalize(); t = format(x, 'f')
    if '.' in t: t = t.rstrip('0').rstrip('.')
    return bn(t) + (' ' + unit if unit else '')
def unitcost(x): return bn(format(q(D(x), 4), 'f').rstrip('0').rstrip('.') if '.' in format(q(D(x), 4), 'f') else format(q(D(x), 4), 'f'))

# ------------------------------------------------------------------ companies, users
COMPANIES = [{'id': 'C1', 'name': 'নমুনা টি-মিক্স প্রোডাক্টস লিমিটেড'}, {'id': 'C2', 'name': 'নমুনা ফুড ইন্ডাস্ট্রিজ লিমিটেড'}]
DEMO_DATE = '2026-10-28'
ME = 'EMP-100'

R = OrderedDict()                  # (type,id) -> record
REL = defaultdict(list)            # (type,id) -> [(type,id)]  (auto-reversed)
def key(t, i): return (t, i)
def add(t, i, title, **kw):
    rec = {'type': t, 'id': i, 'title': title, 'reference': kw.pop('reference', i), 'status': kw.pop('status', 'ACTIVE'), 'company': kw.pop('company', 'C1'),
           'date': kw.pop('date', ''), 'subtitle': kw.pop('subtitle', ''), 'createdBy': kw.pop('createdBy', None), 'imageTone': kw.pop('imageTone', 0),
           'qrToken': kw.pop('qrToken', None), 'kpis': kw.pop('kpis', []), 'info': kw.pop('info', []), 'sensitive': kw.pop('sensitive', []), 'lines': kw.pop('lines', []),
           'totals': kw.pop('totals', []), 'history': kw.pop('history', []), 'approval': kw.pop('approval', []), 'originalOf': kw.pop('originalOf', None),
           'reversalOf': kw.pop('reversalOf', None), 'replacementOf': kw.pop('replacementOf', None), 'note': kw.pop('note', ''), 'extra': kw.pop('extra', {})}
    assert not kw, kw
    assert key(t, i) not in R, (t, i)
    R[key(t, i)] = rec
    return rec
def rel(a, b):
    if b not in REL[a]: REL[a].append(b)
    if a not in REL[b]: REL[b].append(a)
def ev(when, title, detail='', actor=''): return [when, title, detail, actor]
def info(*pairs): return [list(p) for p in pairs]
def kpi(l, v, n=''): return [l, v, n]

# ------------------------------------------------------------------ employees (C1)
EMP = [
 ('EMP-100', 'নমুনা ব্যবহারকারী (আপনি)', 'ফ্যাক্টরি ব্যবস্থাপনা (প্রিভিউ-পরিচয়)', 'ব্যবস্থাপনা', ['প্রিভিউ-ব্যবহারকারী'], '২০২৪-০১-০১', 'সক্রিয়', 'সাধারণ শিফট ০৯:০০–১৭:০০', True, 28000, 5000),
 ('EMP-101', 'নমুনা: রহিম উদ্দিন', 'উৎপাদন সুপারভাইজার', 'উৎপাদন', ['উৎপাদন সুপারভাইজার', 'অস্থায়ী: শিফট ইনচার্জ'], '২০২৩-০৩-১২', 'সক্রিয়', 'সকাল শিফট ০৮:০০–১৬:০০', True, 32000, 4000),
 ('EMP-102', 'নমুনা: করিম আহমেদ', 'কিউসি কর্মকর্তা', 'কিউসি', ['কিউসি কর্মকর্তা'], '২০২৪-০৬-০১', 'সক্রিয়', 'সকাল শিফট ০৮:০০–১৬:০০', True, 30000, 3500),
 ('EMP-103', 'নমুনা: সালমা খাতুন', 'স্টোরকিপার', 'গুদাম', ['স্টোরকিপার'], '২০২২-১১-১৫', 'সক্রিয়', 'সকাল শিফট ০৮:০০–১৬:০০', False, 26000, 3000),
 ('EMP-104', 'নমুনা: জামাল হোসেন', 'অপারেটর (ফিলিং)', 'উৎপাদন', ['অপারেটর'], '২০২৫-০২-০১', 'সক্রিয়', 'সকাল শিফট ০৮:০০–১৬:০০', False, 18000, 2000),
 ('EMP-105', 'নমুনা: নাজমা আক্তার', 'এইচআর কর্মকর্তা', 'এইচআর', ['এইচআর কর্মকর্তা'], '২০২৩-০৮-০১', 'সক্রিয়', 'সাধারণ শিফট ০৯:০০–১৭:০০', True, 34000, 4500),
 ('EMP-106', 'নমুনা: ফারুক আলম', 'হিসাবরক্ষক', 'হিসাব', ['হিসাবরক্ষক'], '২০২৩-০৫-২০', 'ছুটিতে', 'সাধারণ শিফট ০৯:০০–১৭:০০', True, 33000, 4000),
]
for i, (eid, name, pos, dept, positions, joined, st, shift, login, basic, allow) in enumerate(EMP):
    status = 'ACTIVE' if st == 'সক্রিয়' else 'ON_LEAVE'
    add('EMPLOYEE', eid, name, reference=eid, status=status, subtitle=pos + ' • ' + dept, imageTone=i, qrToken='QR-EMP-%d' % (7310 + i),
        kpis=[kpi('বিভাগ', dept), kpi('পদ', pos), kpi('যোগদান', joined)],
        info=info(('কর্মী-আইডি', eid), ('বিভাগ', dept), ('পদ-দায়িত্ব', ' | '.join(positions)), ('কর্মসংস্থান-অবস্থা', st), ('যোগদানের তারিখ', joined), ('শিফট', shift),
                  ('অ্যাপ-লগইন', 'আছে (কর্মী-প্রোফাইল ও লগইন-অ্যাকাউন্ট আলাদা)' if login else 'নেই (এই কর্মীর অ্যাপ-লগইন নেই)')),
        sensitive=info(('মূল বেতন', money(basic)), ('ভাতা', money(allow)), ('মোট', money(basic + allow))),
        history=[ev(joined, 'যোগদান', pos, 'এইচআর'), ev('২০২৫-০৪-০১', 'দায়িত্ব-নিশ্চিতকরণ', 'ডেমো-ঘটনা', 'এইচআর')] + ([ev('২০২৬-০৭-০১', 'পদোন্নতি (ডেমো)', 'সুপারভাইজার', 'এইচআর')] if eid == 'EMP-101' else []),
        extra={'basic': int(basic), 'allow': int(allow)})
EMP_PROFILE = {e[0]: e for e in EMP}

# ------------------------------------------------------------------ suppliers, materials, products, warehouses, machines
SUP = [('SUP-001', 'নমুনা: আদর্শ ট্রেডার্স', 'চিনি, এনডিসি সরবরাহ', '০১৭XXXXXXXX'), ('SUP-002', 'নমুনা: প্যাক-টেক ফয়েল সরবরাহ', 'ফয়েল ও প্যাকেজিং', '০১৮XXXXXXXX'), ('SUP-003', 'নমুনা: সুমন এন্টারপ্রাইজ', 'চা-পাউডার', '০১৯XXXXXXXX')]
for i, (sid, name, what, ph) in enumerate(SUP):
    add('SUPPLIER', sid, name, subtitle=what, imageTone=i, info=info(('সরবরাহকারী-আইডি', sid), ('সরবরাহের ধরন', what), ('যোগাযোগ (ডেমো)', ph), ('কোম্পানি', COMPANIES[0]['name'])),
        history=[ev('২০২৬-০৯-১৫', 'সরবরাহকারী নিবন্ধিত', 'ডেমো-ঘটনা', 'ক্রয় কর্মকর্তা')])
MATS = [('MAT-001', 'চিনি', 'কেজি'), ('MAT-002', 'এনডিসি (নন-ডেইরি ক্রিমার)', 'কেজি'), ('MAT-003', 'চা-পাউডার', 'কেজি'), ('MAT-004', 'ফয়েল (প্যাকেজিং)', 'কেজি')]
MAT_NAME = {m[0]: m[1] for m in MATS}; MAT_UNIT = {m[0]: m[2] for m in MATS}
for i, (mid, name, unit) in enumerate(MATS):
    add('RAW_MATERIAL', mid, name, subtitle='কাঁচামাল' if mid != 'MAT-004' else 'প্যাকেজিং (খরচ-নিয়ন্ত্রিত উপাদান)', imageTone=i, info=info(('কোড', mid), ('একক', unit), ('ধরন', 'ফয়েল/প্যাকেজিং' if mid == 'MAT-004' else 'কাঁচামাল'), ('মূল্যায়ন-পদ্ধতি', 'চলমান ভারযুক্ত গড় (Moving Weighted Average)'), ('ন্যূনতম মজুত-সতর্কতা', 'প্রযোজ্য নীতি অনুমোদিত নয় (Pending)')))
add('WAREHOUSE', 'WH-RM', 'কাঁচামাল গুদাম', subtitle='কাঁচামাল ও ফয়েল', info=info(('গুদাম-কোড', 'WH-RM'), ('ধরন', 'কাঁচামাল')), imageTone=1)
add('WAREHOUSE', 'WH-FG', 'তৈরি পণ্য গুদাম', subtitle='Poly-ভিত্তিক তৈরি পণ্য', info=info(('গুদাম-কোড', 'WH-FG'), ('ধরন', 'তৈরি পণ্য (শুধু QC-গৃহীত মজুত উপলব্ধ)')), imageTone=2)

PRODUCTS = [('PRD-001', 'ইনস্ট্যান্ট চা-মিক্স (ক্লাসিক)', 'চা-মিক্স'), ('PRD-002', 'ইনস্ট্যান্ট চা-মিক্স (এলাচি)', 'চা-মিক্স'), ('PRD-003', 'ইনস্ট্যান্ট চা-মিক্স (আদা)', 'চা-মিক্স'),
            ('PRD-004', 'মিল্ক টি মিক্স', 'চা-মিক্স'), ('PRD-005', 'লেবু-চা মিক্স', 'চা-মিক্স'), ('PRD-006', 'ইনস্ট্যান্ট কফি-মিক্স', 'কফি-মিক্স')]
# machines
MACH = [('MC-001', 'মিক্সিং মেশিন (M-01)', 'মিক্সিং'), ('MC-002', 'ফিলিং ও সিলিং মেশিন (F-02)', 'প্যাকিং'), ('MC-003', 'ফয়েল প্যাকিং লাইন (P-03)', 'প্যাকিং')]

# ------------------------------------------------------------------ purchases (stock-affecting facts)
PURCH = [  # po, supplier, mat, qty, price, date, status, grn
 ('PO-001', 'SUP-001', 'MAT-001', D('2000'), D('118.50'), '2026-10-02', 'POSTED', 'GRN-001'),
 ('PO-002', 'SUP-001', 'MAT-002', D('800'), D('310'), '2026-10-04', 'POSTED', 'GRN-002'),
 ('PO-003', 'SUP-003', 'MAT-003', D('500'), D('640'), '2026-10-06', 'POSTED', 'GRN-003'),
 ('PO-004', 'SUP-002', 'MAT-004', D('120'), D('780'), '2026-10-08', 'POSTED', 'GRN-004'),
 ('PO-005', 'SUP-001', 'MAT-001', D('1500'), D('124.00'), '2026-10-20', 'POSTED', 'GRN-005'),
]
PURCH_OPEN = [('PO-006', 'SUP-001', 'MAT-002', D('600'), D('325'), '2026-10-27', 'SUBMITTED', 'EMP-103'), ('PO-007', 'SUP-003', 'MAT-003', D('300'), D('655'), '2026-10-28', 'DRAFT', ME)]

# batches: id, product, bom, bomver, date, planned, produced, accepted, qc status, status
BOMS = {'BOM-001': ('PRD-001', {1: {'MAT-001': D('300'), 'MAT-002': D('200'), 'MAT-003': D('80'), 'MAT-004': D('6')}, 2: {'MAT-001': D('295'), 'MAT-002': D('205'), 'MAT-003': D('80'), 'MAT-004': D('6')}}, 1000),
        'BOM-002': ('PRD-002', {1: {'MAT-001': D('245'), 'MAT-002': D('165'), 'MAT-003': D('75'), 'MAT-004': D('5')}}, 800)}
BAT = {
 'B-001': dict(prod='PRD-001', bom='BOM-001', ver=1, date='2026-10-10', planned=1000, produced=985, accepted=960, rejected=25, qc='ACCEPTED', status='COMPLETED', issue_date='2026-10-10', ret_date='2026-10-12',
               issued={'MAT-001': D('305'), 'MAT-002': D('205'), 'MAT-003': D('82'), 'MAT-004': D('6.5')}, consumed={'MAT-001': D('298'), 'MAT-002': D('202'), 'MAT-003': D('80.5'), 'MAT-004': D('6.0')},
               returned={'MAT-001': D('5'), 'MAT-002': D('2'), 'MAT-003': D('1'), 'MAT-004': D('0.2')}, waste={'MAT-001': D('2'), 'MAT-002': D('1'), 'MAT-003': D('0.5'), 'MAT-004': D('0.3')}),
 'B-002': dict(prod='PRD-001', bom='BOM-001', ver=2, date='2026-10-24', planned=1000, produced=990, accepted=985, rejected=5, qc='ACCEPTED', status='COMPLETED', issue_date='2026-10-24', ret_date='2026-10-26',
               issued={'MAT-001': D('300'), 'MAT-002': D('210'), 'MAT-003': D('82'), 'MAT-004': D('6.5')}, consumed={'MAT-001': D('294'), 'MAT-002': D('207'), 'MAT-003': D('80.0'), 'MAT-004': D('6.1')},
               returned={'MAT-001': D('4'), 'MAT-002': D('2'), 'MAT-003': D('1.5'), 'MAT-004': D('0.2')}, waste={'MAT-001': D('2'), 'MAT-002': D('1'), 'MAT-003': D('0.5'), 'MAT-004': D('0.2')}),
 'B-003': dict(prod='PRD-002', bom='BOM-002', ver=1, date='2026-10-26', planned=800, produced=780, accepted=0, rejected=0, qc='HOLD', status='QC_HOLD', issue_date='2026-10-26', ret_date='2026-10-28',
               issued={'MAT-001': D('250'), 'MAT-002': D('170'), 'MAT-003': D('76'), 'MAT-004': D('5.2')}, consumed={'MAT-001': D('247'), 'MAT-002': D('168'), 'MAT-003': D('74.5'), 'MAT-004': D('5.0')},
               returned={'MAT-001': D('2'), 'MAT-002': D('1'), 'MAT-003': D('1'), 'MAT-004': D('0.1')}, waste={'MAT-001': D('1'), 'MAT-002': D('1'), 'MAT-003': D('0.5'), 'MAT-004': D('0.1')}),
 'B-004': dict(prod='PRD-001', bom='BOM-001', ver=2, date='2026-10-28', planned=1000, produced=0, accepted=0, rejected=0, qc='NONE', status='IN_PROGRESS', issue_date='2026-10-28', ret_date=None,
               issued={'MAT-001': D('300'), 'MAT-002': D('210'), 'MAT-003': D('82'), 'MAT-004': D('6.5')}, consumed={'MAT-001': D('120'), 'MAT-002': D('85'), 'MAT-003': D('33'), 'MAT-004': D('2.5')},
               returned={}, waste={}),
}
for b, d in BAT.items():                                         # reconciliation (issued = consumed + returned + waste) for finished batches
    if d['status'] != 'IN_PROGRESS':
        for m in d['issued']: assert d['issued'][m] == d['consumed'][m] + d['returned'].get(m, D(0)) + d['waste'].get(m, D(0)), (b, m)

# ------------------------------------------------------------------ costing (moving weighted average) — DEMO rounding: value 2dp, unit cost 4dp, HALF_UP
EVENTS = []                                                       # (material, date, seq, kind, qty, price|None, batch|None)
seq = 0
def event(m, date, kind, qty_, price=None, batch=None):
    global seq; seq += 1; EVENTS.append((m, date, seq, kind, qty_, price, batch))
for po, sup, m, qq, pr, dt, st, grn in PURCH: event(m, dt, 'RECEIPT', qq, pr)
for b, d in BAT.items():
    for m, qq in d['issued'].items(): event(m, d['issue_date'], 'ISSUE', qq, None, b)
    if d['ret_date']:
        for m, qq in d['returned'].items(): event(m, d['ret_date'], 'RETURN', qq, None, b)
ORDER = {'RECEIPT': 0, 'ISSUE': 1, 'RETURN': 2}
EVENTS.sort(key=lambda e: (e[1], e[2]))                           # date, then declaration order
pos = defaultdict(lambda: {'qty': D(0), 'value': D(0), 'avg': D(0)})
issue_unit = {}; mv = []                                          # movements with costs
for (m, dt, sq, kind, qq, pr, b) in EVENTS:
    p = pos[m]
    if kind == 'RECEIPT':
        val = q(qq * pr, 2); p['value'] += val; p['qty'] += qq; p['avg'] = q(p['value'] / p['qty'], 4); mv.append((m, dt, kind, qq, pr, val, b))
    elif kind == 'ISSUE':
        unit = p['avg']; cost = q(qq * unit, 2); assert p['qty'] >= qq, ('negative stock', m, dt)
        p['value'] -= cost; p['qty'] -= qq; issue_unit[(b, m)] = unit; mv.append((m, dt, kind, qq, unit, cost, b))
        if p['qty'] > 0: p['avg'] = q(p['value'] / p['qty'], 4)
    else:
        unit = issue_unit[(b, m)]; val = q(qq * unit, 2); p['value'] += val; p['qty'] += qq; p['avg'] = q(p['value'] / p['qty'], 4); mv.append((m, dt, kind, qq, unit, val, b))
BATCH_COST = {}
for b, d in BAT.items():
    cons = {m: q(d['consumed'][m] * issue_unit[(b, m)], 2) for m in d['consumed']}
    waste = {m: q(d['waste'].get(m, D(0)) * issue_unit[(b, m)], 2) for m in d['issued']}
    total = sum(cons.values(), D(0)); wtotal = sum(waste.values(), D(0))
    acc = D(d['accepted']); cpp = q(total / acc, 2) if acc > 0 else None
    BATCH_COST[b] = dict(cons=cons, waste=waste, total=total, wtotal=wtotal, accepted=acc, cpp=cpp)
EXPECTED = {'wac_final': {m: {'qty': str(pos[m]['qty']), 'value': str(pos[m]['value']), 'avg': str(pos[m]['avg'])} for m in pos},
            'issue_unit': {'%s/%s' % k: str(v) for k, v in issue_unit.items()},
            'batch_material_cost': {b: str(c['total']) for b, c in BATCH_COST.items()},
            'material_cost_per_poly': {b: (str(c['cpp']) if c['cpp'] is not None else None) for b, c in BATCH_COST.items()}}

# supplier dues (payments below)
PAYMENTS = [('PV-001', 'SUP-001', 'PO-001', D('150000'), '2026-10-05', 'POSTED', 'EMP-106'), ('PV-002', 'SUP-002', 'PO-004', D('93600'), '2026-10-09', 'POSTED', 'EMP-106'),
            ('PV-003', 'SUP-003', 'PO-003', D('50000'), '2026-10-12', 'REVERSED', 'EMP-106'), ('PV-003R', 'SUP-003', 'PO-003', D('50000'), '2026-10-14', 'POSTED', 'EMP-106'),
            ('PV-004', 'SUP-003', 'PO-003', D('80000'), '2026-10-14', 'POSTED', 'EMP-106')]
PO_TOTAL = {po: q(qq * pr, 2) for po, s, m, qq, pr, dt, st, g in PURCH}
paid = defaultdict(D)
for pv, sup, po, amt, dt, st, cb in PAYMENTS:
    if pv == 'PV-003': paid[po] += amt
    elif pv == 'PV-003R': paid[po] -= amt
    else: paid[po] += amt
PO_PAID = dict(paid)
SUP_DUE = defaultdict(D)
for po, s, m, qq, pr, dt, st, g in PURCH: SUP_DUE[s] += PO_TOTAL[po] - PO_PAID.get(po, D(0))
EXPECTED['supplier_due'] = {s: str(v) for s, v in SUP_DUE.items()}

# ------------------------------------------------------------------ build records
def dt_bn(iso): return bn(iso)
for pid, name, cat in PRODUCTS:
    i = int(pid[-1])
    batches = [b for b, d in BAT.items() if d['prod'] == pid]
    prod_total = sum(BAT[b]['produced'] for b in batches); acc_total = sum(BAT[b]['accepted'] for b in batches)
    boms = [bid for bid, v in BOMS.items() if v[0] == pid]
    add('PRODUCT', pid, name, subtitle=cat + ' • একক: Poly', imageTone=i, qrToken='QR-PRD-%d' % (4200 + i),
        kpis=[kpi('উৎপাদন (অক্টোবর)', qty(prod_total, 'Poly'), 'উৎপাদিত'), kpi('ব্যাচ', bn(len(batches)) + 'টি'), kpi('তৈরি পণ্য মজুত', qty(acc_total, 'Poly'), 'QC-গৃহীত')],
        info=info(('পণ্য-কোড', pid), ('ক্যাটাগরি', cat), ('প্রাথমিক একক', 'Poly (PCS নয়)'), ('Poly-রূপান্তর', 'অনুমোদনের অপেক্ষায় (Pending) — কোনো মান ধরে নেওয়া হয়নি; পণ্যভিত্তিক লিখিত অনুমোদন ছাড়া পূর্ণ খরচ-গণনা চালু নয়'),
                  ('অনুমোদিত BOM', ', '.join(boms) if boms else 'এখনো নেই'), ('পণ্য-ছবি', 'আপলোড হয়নি (প্লেসহোল্ডার)')),
        history=[ev('২০২৬-০৯-২০', 'পণ্য নিবন্ধিত', '', 'উইং-প্রধান (ডেমো)')])
add('PRODUCT', 'PRD-C2-001', 'নমুনা: অন্য কোম্পানির পণ্য', company='C2', qrToken='QR-PRD-C2-001', subtitle='কোম্পানি-খ • আলাদা কোম্পানি', imageTone=3, info=info(('পণ্য-কোড', 'PRD-C2-001'), ('কোম্পানি', COMPANIES[1]['name'])))
add('SUPPLIER', 'SUP-C2-001', 'নমুনা: অন্য কোম্পানির সরবরাহকারী', company='C2', subtitle='কোম্পানি-খ', info=info(('কোম্পানি', COMPANIES[1]['name'])))
add('PURCHASE_ORDER', 'PO-C2-001', 'ক্রয় আদেশ PO-C2-001', company='C2', status='APPROVED', date='2026-10-15', subtitle='কোম্পানি-খ', info=info(('কোম্পানি', COMPANIES[1]['name'])))
rel(key('PURCHASE_ORDER', 'PO-C2-001'), key('SUPPLIER', 'SUP-C2-001'))

# BOMs
for bid, (pid, vers, size) in BOMS.items():
    for ver, lines in vers.items():
        latest = ver == max(vers)
        rid = '%s-V%d' % (bid, ver)
        add('BOM', rid, '%s — সংস্করণ %s' % (R[key('PRODUCT', pid)]['title'], bn(ver)), reference=rid, status='APPROVED' if latest else 'SUPERSEDED', date='2026-10-0%d' % (1 if ver == 1 else 9) if ver == 1 else '2026-10-18',
            subtitle='ব্যাচ-আকার ' + qty(size, 'Poly'), createdBy='EMP-101',
            kpis=[kpi('লক্ষ্য ব্যাচ', qty(size, 'Poly')), kpi('উপাদান', bn(len(lines)) + 'টি'), kpi('অবস্থা', 'বর্তমান' if latest else 'পুরোনো সংস্করণ (অপরিবর্তনীয়)')],
            info=info(('পণ্য', R[key('PRODUCT', pid)]['title']), ('সংস্করণ', bn(ver)), ('অনুমোদিত সংস্করণ অপরিবর্তনীয়', 'হ্যাঁ; পরিবর্তন = নতুন সংস্করণ'), ('প্রত্যাশিত ফলন', qty(size, 'Poly') + ' (লক্ষ্য)'), ('আদর্শ অপচয়', 'নীতি অনুমোদিত নয় (Pending)')),
            lines=[{'name': MAT_NAME[m], 'qty': qty(lines[m]), 'unit': MAT_UNIT[m], 'price': '', 'amount': '', 'ref': 'MAT/' + m} for m in lines],
            history=[ev('২০২৬-১০-০১' if ver == 1 else '২০২৬-১০-১৮', 'অনুমোদিত', 'সংস্করণ ' + bn(ver), 'উইং-প্রধান (ডেমো)')])
        rel(key('BOM', rid), key('PRODUCT', pid))
        for m in lines: rel(key('BOM', rid), key('RAW_MATERIAL', m))
for pid, name, cat in PRODUCTS: pass

# suppliers/materials/purchases/GRNs
for po, sup, m, qq, pr, dt, st, grn in PURCH:
    total = PO_TOTAL[po]; paid_amt = PO_PAID.get(po, D(0)); due = total - paid_amt
    add('PURCHASE_ORDER', po, 'ক্রয় আদেশ ' + po, reference=po, status='POSTED', date=dt, subtitle=R[key('SUPPLIER', sup)]['title'] + ' • ' + MAT_NAME[m], createdBy='EMP-103', imageTone=0,
        kpis=[kpi('মোট', money(total)), kpi('পরিশোধিত', money(paid_amt)), kpi('বকেয়া', money(due))],
        info=info(('লেনদেন-আইডি', po), ('ধরন', 'ক্রয় আদেশ'), ('সরবরাহকারী', R[key('SUPPLIER', sup)]['title']), ('তারিখ', bn(dt)), ('প্রস্তুতকারী', EMP_PROFILE['EMP-103'][1]), ('কোম্পানি', COMPANIES[0]['name'])),
        lines=[{'name': MAT_NAME[m], 'qty': qty(qq), 'unit': MAT_UNIT[m], 'price': money(pr), 'amount': money(total), 'ref': 'MAT/' + m}],
        totals=[['মোট মূল্য', money(total)], ['পরিশোধিত', money(paid_amt)], ['বকেয়া', money(due)]],
        history=[ev(bn(dt), 'পণ্য গ্রহণ সম্পন্ন', grn, 'স্টোরকিপার')],
        approval=[ev(bn(dt), 'জমা দেওয়া', '', EMP_PROFILE['EMP-103'][1]), ev(bn(dt), 'অনুমোদিত', 'নমুনা অনুমোদনকারী: উইং-প্রধান (ডেমো)', 'উইং-প্রধান')])
    add('GRN', grn, 'পণ্য গ্রহণ ' + grn, status='POSTED', date=dt, subtitle=MAT_NAME[m] + ' • ' + qty(qq, MAT_UNIT[m]), createdBy='EMP-103',
        kpis=[kpi('গৃহীত', qty(qq, MAT_UNIT[m])), kpi('একক-দাম', money(pr)), kpi('মূল্য', money(total))],
        info=info(('GRN-আইডি', grn), ('ক্রয় আদেশ', po), ('লট-নম্বর', 'LOT-' + grn[-3:]), ('মেয়াদ', 'প্রযোজ্য মেয়াদ-তথ্য নেই (ডেমো)'), ('অতিরিক্ত যোগ্য খরচ', 'নেই (ডেমো)'), ('হিসাব-নীতি', 'GRNI/ক্রয়-হিসাব-নীতি অনুমোদিত নয় (Pending) — কোনো হিসাব-লিপি দাবি করা হয়নি')),
        lines=[{'name': MAT_NAME[m], 'qty': qty(qq), 'unit': MAT_UNIT[m], 'price': money(pr), 'amount': money(total), 'ref': 'MAT/' + m}],
        totals=[['মোট মূল্য', money(total)]], history=[ev(bn(dt), 'গৃহীত ও গুদামজাত', 'WH-RM', 'স্টোরকিপার')])
    rel(key('PURCHASE_ORDER', po), key('SUPPLIER', sup)); rel(key('PURCHASE_ORDER', po), key('GRN', grn)); rel(key('GRN', grn), key('RAW_MATERIAL', m)); rel(key('PURCHASE_ORDER', po), key('RAW_MATERIAL', m)); rel(key('GRN', grn), key('SUPPLIER', sup))
for po, sup, m, qq, pr, dt, st, who in PURCH_OPEN:
    total = q(qq * pr, 2)
    add('PURCHASE_ORDER', po, 'ক্রয় আদেশ ' + po, status=st, date=dt, subtitle=R[key('SUPPLIER', sup)]['title'] + ' • ' + MAT_NAME[m], createdBy=who,
        kpis=[kpi('মোট', money(total)), kpi('অবস্থা', 'অনুমোদনের অপেক্ষায়' if st == 'SUBMITTED' else 'খসড়া')],
        info=info(('লেনদেন-আইডি', po), ('ধরন', 'ক্রয় আদেশ'), ('সরবরাহকারী', R[key('SUPPLIER', sup)]['title']), ('তারিখ', bn(dt)), ('প্রস্তুতকারী', EMP_PROFILE[who][1]), ('কোম্পানি', COMPANIES[0]['name'])),
        lines=[{'name': MAT_NAME[m], 'qty': qty(qq), 'unit': MAT_UNIT[m], 'price': money(pr), 'amount': money(total), 'ref': 'MAT/' + m}], totals=[['মোট মূল্য', money(total)]],
        history=[ev(bn(dt), 'তৈরি', '', EMP_PROFILE[who][1])] + ([ev(bn(dt), 'জমা দেওয়া', 'অনুমোদনের জন্য', EMP_PROFILE[who][1])] if st == 'SUBMITTED' else []),
        approval=[ev(bn(dt), 'জমা দেওয়া', '', EMP_PROFILE[who][1]), ev('অপেক্ষমাণ', 'অনুমোদন', 'প্রস্তুতকারী নিজে অনুমোদন করতে পারেন না (Maker-Checker)', 'অনুমোদনকারী')] if st == 'SUBMITTED' else [],
        note='সরবরাহ এখনো গৃহীত হয়নি; স্টকে যুক্ত হয়নি।')
    rel(key('PURCHASE_ORDER', po), key('SUPPLIER', sup)); rel(key('PURCHASE_ORDER', po), key('RAW_MATERIAL', m))

# payments & supplier ledger
sl_i = 0; bal = defaultdict(D)
sl_entries = []
for po, sup, m, qq, pr, dt, st, grn in PURCH: sl_entries.append((dt, sup, 'GRN', grn, PO_TOTAL[po], 'ক্রয় বকেয়া (' + grn + ')'))
for pv, sup, po, amt, dt, st, cb in PAYMENTS:
    sl_entries.append((dt, sup, 'PV', pv, -amt if pv != 'PV-003R' else amt, ('পরিশোধ ' if pv != 'PV-003R' else 'বাতিল-সমন্বয় (Reversal) ') + pv))
sl_entries.sort(key=lambda e: (e[1], e[0]))
SL_IDS = {}
for dt, sup, kind, src, delta, text in sl_entries:
    sl_i += 1; bal[sup] += delta; sid = 'SL-%03d' % sl_i; SL_IDS[(sup, kind, src)] = sid
    add('SUPPLIER_LEDGER', sid, 'খতিয়ান-লিপি ' + sid, status='POSTED', date=dt, subtitle=text, kpis=[kpi('পরিবর্তন', ('+' if delta > 0 else '') + money(delta)), kpi('অবশিষ্ট বকেয়া', money(bal[sup]))],
        info=info(('লিপি-আইডি', sid), ('সরবরাহকারী', R[key('SUPPLIER', sup)]['title']), ('উৎস', src), ('নোট', 'সরবরাহকারী-খতিয়ান (ডেমো); GRNI/সাধারণ-হিসাব-লিপি নীতি অনুমোদিত নয়')))
    rel(key('SUPPLIER_LEDGER', sid), key('SUPPLIER', sup))
    rel(key('SUPPLIER_LEDGER', sid), key('GRN' if kind == 'GRN' else 'PAYMENT_VOUCHER', src))
for pv, sup, po, amt, dt, st, cb in PAYMENTS:
    corr = {}
    if pv == 'PV-003': corr = dict(note='এই পোস্টকৃত ভাউচার ভুল পরিমাণের কারণে বাতিল-সমন্বয় (Reversal) করা হয়েছে; সরাসরি সম্পাদনা বা মুছে ফেলা যায় না।')
    if pv == 'PV-003R': corr = dict(reversalOf='PAYMENT_VOUCHER/PV-003', note='এটি PV-003-এর Reversal।')
    if pv == 'PV-004': corr = dict(replacementOf='PAYMENT_VOUCHER/PV-003', note='এটি PV-003-এর Replacement; আলাদা অনুমোদন লেগেছে।')
    add('PAYMENT_VOUCHER', pv, 'পরিশোধ ভাউচার ' + pv, status=st, date=dt, subtitle=R[key('SUPPLIER', sup)]['title'] + ' • ' + po, createdBy=cb,
        kpis=[kpi('পরিমাণ', money(amt)), kpi('ক্রয় আদেশ', po)],
        info=info(('ভাউচার-আইডি', pv), ('ধরন', 'সরবরাহকারী-পরিশোধ'), ('সরবরাহকারী', R[key('SUPPLIER', sup)]['title']), ('ক্রয় আদেশ', po), ('প্রস্তুতকারী', EMP_PROFILE[cb][1])),
        lines=[{'name': 'আংশিক/পূর্ণ পরিশোধ — ' + po, 'qty': '', 'unit': '', 'price': '', 'amount': money(amt), 'ref': 'PO/' + po}], totals=[['মোট', money(amt)]],
        history=[ev(bn(dt), 'পোস্টকৃত' if st != 'DRAFT' else 'তৈরি', '', 'হিসাবরক্ষক')],
        approval=[ev(bn(dt), 'জমা দেওয়া', '', EMP_PROFILE[cb][1]), ev(bn(dt), 'অনুমোদিত', 'নমুনা: অর্থ ব্যবস্থাপক', 'অর্থ ব্যবস্থাপক')], **corr)
    rel(key('PAYMENT_VOUCHER', pv), key('SUPPLIER', sup)); rel(key('PAYMENT_VOUCHER', pv), key('PURCHASE_ORDER', po))
rel(key('PAYMENT_VOUCHER', 'PV-003R'), key('PAYMENT_VOUCHER', 'PV-003')); rel(key('PAYMENT_VOUCHER', 'PV-004'), key('PAYMENT_VOUCHER', 'PV-003'))
for sup, due in SUP_DUE.items():
    sp = R[key('SUPPLIER', sup)]; sp['kpis'] = [kpi('মোট বকেয়া', money(due)), kpi('পরিশোধ বনাম ক্রয়', 'বকেয়া ও ইনভেন্টরি-মূল্য আলাদা হিসাব')]
for po, sup, m, qq, pr, dt, st, grn in PURCH: pass

# stock movements, issues, consumption, batches, QC, FG, costs
smi = 0; SM_BY = {}
for (m, dt, kind, qq, pr_or_unit, val, b) in mv:
    smi += 1; sid = 'SM-%03d' % smi
    if kind == 'RECEIPT':
        src = [p for p in PURCH if p[2] == m and p[5] == dt and p[3] == qq][0]; srcref = ('GRN', src[7]); title = 'স্টক-জমা (পণ্য গ্রহণ)'; direction = '+'
    elif kind == 'ISSUE':
        srcref = ('MATERIAL_ISSUE', 'ISS-' + b[-3:]); title = 'স্টক-ইস্যু (WIP-তে)'; direction = '−'
    else:
        srcref = ('MATERIAL_ISSUE', 'ISS-' + b[-3:]); title = 'স্টক-ফেরত (ইস্যু-খরচে)'; direction = '+'
    SM_BY[(m, dt, kind, b, qq)] = sid
    add('STOCK_MOVEMENT', sid, '%s — %s' % (title, MAT_NAME[m]), status='POSTED', date=dt, subtitle=direction + qty(qq, MAT_UNIT[m]) + ' • ' + ('একক ' + money(pr_or_unit)), 
        kpis=[kpi('পরিমাণ', direction + qty(qq, MAT_UNIT[m])), kpi('একক-খরচ', money(pr_or_unit)), kpi('মূল্য', money(val))],
        info=info(('চলাচল-আইডি', sid), ('উপাদান', MAT_NAME[m]), ('গুদাম', 'WH-RM'), ('উৎস-নথি', srcref[1]), ('মূল্যায়ন', 'চলমান ভারযুক্ত গড় (ডেমো-গণনা; রাউন্ডিং-নীতি অনুমোদিত নয়)')), history=[ev(bn(dt), 'পোস্টকৃত', '', 'সিস্টেম (ডেমো)')])
    rel(key('STOCK_MOVEMENT', sid), key('RAW_MATERIAL', m)); rel(key('STOCK_MOVEMENT', sid), key('WAREHOUSE', 'WH-RM')); rel(key('STOCK_MOVEMENT', sid), key(*srcref) if False else key(srcref[0], srcref[1]))
    if b: rel(key('STOCK_MOVEMENT', sid), key('BATCH', b))

for b, d in BAT.items():
    pid = d['prod']; bomid = '%s-V%d' % (d['bom'], d['ver']); bc = BATCH_COST[b]
    st = d['status']
    kp = [kpi('পরিকল্পিত', qty(d['planned'], 'Poly')), kpi('উৎপাদিত', qty(d['produced'], 'Poly') if d['produced'] else 'চলমান'), kpi('QC-গৃহীত', qty(d['accepted'], 'Poly') if d['qc'] == 'ACCEPTED' else ('QC হোল্ড' if d['qc'] == 'HOLD' else '—'))]
    add('BATCH', b, 'ব্যাচ %s — %s' % (b, R[key('PRODUCT', pid)]['title']), status=st, date=d['date'], subtitle='BOM সংস্করণ ' + bomid, createdBy='EMP-101', qrToken='QR-BAT-%s' % b[-3:],
        kpis=kp, info=info(('ব্যাচ-নম্বর', b), ('পণ্য', R[key('PRODUCT', pid)]['title']), ('ব্যবহৃত BOM-সংস্করণ', bomid + ' (অপরিবর্তনীয়)'), ('তারিখ', bn(d['date'])), ('একক', 'Poly')),
        history=[ev(bn(d['date']), 'ব্যাচ তৈরি', '', 'উৎপাদন সুপারভাইজার'), ev(bn(d['issue_date']), 'মালামাল ইস্যু', 'ISS-' + b[-3:], 'স্টোরকিপার')] + ([ev(bn(d['date']), 'উৎপাদন সম্পন্ন', qty(d['produced'], 'Poly'), 'উৎপাদন সুপারভাইজার')] if d['produced'] else []),
        note='ব্যাচ-ধাপ: BOM → পরিকল্পিত উপাদান → ইস্যু → প্রকৃত ব্যবহার → অপচয় → QC → তৈরি পণ্য → খরচ' )
    rel(key('BATCH', b), key('PRODUCT', pid)); rel(key('BATCH', b), key('BOM', bomid))
    # issue
    iss = 'ISS-' + b[-3:]
    plan = BOMS[d['bom']][1][d['ver']]
    lines = []
    for m in d['issued']:
        lines.append({'name': MAT_NAME[m], 'qty': 'পরিকল্পিত ' + qty(plan[m]) + ' | ইস্যু ' + qty(d['issued'][m]), 'unit': MAT_UNIT[m], 'price': money(issue_unit[(b, m)]), 'amount': money(q(d['issued'][m] * issue_unit[(b, m)], 2)), 'ref': 'MAT/' + m})
    add('MATERIAL_ISSUE', iss, 'মালামাল ইস্যু ' + iss, status='POSTED', date=d['issue_date'], subtitle='ব্যাচ ' + b, createdBy='EMP-103',
        kpis=[kpi('উপাদান', bn(len(lines)) + 'টি'), kpi('ইস্যু-মূল্য', money(sum((q(d['issued'][m] * issue_unit[(b, m)], 2) for m in d['issued']), D(0))))],
        info=info(('ইস্যু-আইডি', iss), ('ব্যাচ', b), ('গুদাম → উৎপাদন (WIP)', 'WH-RM → WIP'), ('ইস্যু-খরচ', 'ইস্যুর মুহূর্তের চলমান-গড় (ঐতিহাসিক খরচ সংরক্ষিত)'), ('রিজার্ভেশন', 'রিজার্ভ ও বাস্তব-ইস্যু আলাদা (রিজার্ভেশন-নীতি Pending)')),
        lines=lines, history=[ev(bn(d['issue_date']), 'ইস্যু সম্পন্ন', '', 'স্টোরকিপার')],
        approval=[ev(bn(d['issue_date']), 'জমা', '', 'স্টোরকিপার'), ev(bn(d['issue_date']), 'অনুমোদিত', 'নমুনা: উৎপাদন সুপারভাইজার/উইং-প্রধান', 'উইং-প্রধান')])
    rel(key('MATERIAL_ISSUE', iss), key('BATCH', b))
    for m in d['issued']: rel(key('MATERIAL_ISSUE', iss), key('RAW_MATERIAL', m))
    # consumption
    con = 'CON-' + b[-3:]; clines = []
    for m in d['issued']:
        cons_c = q(d['consumed'][m] * issue_unit[(b, m)], 2)
        rem = d['issued'][m] - d['consumed'][m] - d['returned'].get(m, D(0)) - d['waste'].get(m, D(0))
        clines.append({'name': MAT_NAME[m], 'qty': 'ইস্যু %s | ব্যবহৃত %s | ফেরত %s | অপচয় %s | অবশিষ্ট %s' % (qty(d['issued'][m]), qty(d['consumed'][m]), qty(d['returned'].get(m, 0)), qty(d['waste'].get(m, 0)), qty(rem)), 'unit': MAT_UNIT[m], 'price': money(issue_unit[(b, m)]), 'amount': money(cons_c), 'ref': 'MAT/' + m})
    add('CONSUMPTION', con, 'প্রকৃত ব্যবহার ' + con, status='COMPLETED' if st != 'IN_PROGRESS' else 'IN_PROGRESS', date=d['date'], subtitle='ব্যাচ ' + b,
        kpis=[kpi('ব্যবহৃত-খরচ', money(bc['total'])), kpi('অপচয়-খরচ', money(bc['wtotal']), 'আলাদা দেখানো')],
        info=info(('ব্যবহার-আইডি', con), ('ব্যাচ', b), ('সমীকরণ', 'ইস্যু = ব্যবহৃত + ফেরত + ক্ষতি + অন্যান্য অনুমোদিত'), ('ফয়েল-ব্যবহার', 'অন্তর্ভুক্ত (আলাদা উপাদান)'), ('অপচয়-হিসাব-নীতি', 'অস্বাভাবিক অপচয়ের নীতি Pending; এখানে আলাদা দেখানো, ব্যাচ-খরচে ভাগ করা হয়নি')) if st != 'IN_PROGRESS' else info(('ব্যবহার-আইডি', con), ('ব্যাচ', b), ('অবস্থা', 'চলমান: আংশিক ব্যবহার রেকর্ড; অবশিষ্ট হিসাব সমাপ্তির আগে চূড়ান্ত নয়')),
        lines=clines, history=[ev(bn(d['date']), 'ব্যবহার রেকর্ড', '', 'উৎপাদন সুপারভাইজার')])
    rel(key('CONSUMPTION', con), key('BATCH', b)); rel(key('CONSUMPTION', con), key('MATERIAL_ISSUE', iss))
    # batch cost
    if st != 'IN_PROGRESS':
        bcid = 'BC-' + b[-3:]
        cpp = bc['cpp']
        add('BATCH_COST', bcid, 'ব্যাচ-খরচ ' + bcid, status='COMPLETED' if cpp is not None else 'HOLD', date=d['date'], subtitle='শুধু উপাদান-খরচ (আংশিক)',
            kpis=[kpi('উপাদান-খরচ (প্রকৃত ব্যবহৃত)', money(bc['total'])), kpi('গৃহীত Poly', qty(bc['accepted'], 'Poly')), kpi('উপাদান-খরচ প্রতি Poly', money(cpp) if cpp is not None else 'গণনাযোগ্য নয়', 'আংশিক: শ্রম, বিদ্যুৎ, মেশিন, ওভারহেড অন্তর্ভুক্ত নয়')],
            info=info(('ব্যাচ', b), ('সূত্র', 'গৃহীত Poly-এর ওপর প্রকৃত ব্যবহৃত উপাদান-খরচ ÷ গৃহীত Poly'), ('গুরুত্বপূর্ণ', 'এটি পূর্ণ উৎপাদন-খরচ বা প্রকৃত লাভ নয়; পূর্ণ খরচের জন্য অনুমোদিত বণ্টন-নীতি লাগবে'), ('অপচয়-খরচ (আলাদা)', money(bc['wtotal'])), ('ডেমো-রাউন্ডিং', 'মূল্য ২ দশমিক, একক-খরচ ৪ দশমিক — অনুমোদিত নীতি নয়'), ('গৃহীত আউটপুট নেই', 'খরচ WIP/হোল্ডে ধরে রাখার নিয়ম প্রযোজ্য; শূন্য দিয়ে ভাগ করা হয় না') if cpp is None else ('অবস্থা', 'চূড়ান্ত (ডেমো)')),
            lines=[{'name': MAT_NAME[m], 'qty': qty(d['consumed'][m]), 'unit': MAT_UNIT[m], 'price': money(issue_unit[(b, m)]), 'amount': money(bc['cons'][m]), 'ref': 'MAT/' + m} for m in d['consumed']],
            totals=[['উপাদান-খরচ মোট', money(bc['total'])]] + ([['উপাদান-খরচ প্রতি Poly', money(cpp)]] if cpp is not None else []), history=[ev(bn(d['date']), 'গণনা (ডেমো)', '', 'সিস্টেম')])
        rel(key('BATCH_COST', bcid), key('BATCH', b)); rel(key('BATCH_COST', bcid), key('CONSUMPTION', con))
    # QC and FG
    if d['qc'] in ('ACCEPTED', 'HOLD'):
        qcid = 'QC-' + b[-3:]
        add('QC_RECORD', qcid, 'কিউসি পরীক্ষা ' + qcid, status='ACCEPTED' if d['qc'] == 'ACCEPTED' else 'HOLD', date=d['date'], subtitle='ব্যাচ ' + b, createdBy='EMP-102',
            kpis=[kpi('উৎপাদিত', qty(d['produced'], 'Poly')), kpi('গৃহীত', qty(d['accepted'], 'Poly')), kpi('প্রত্যাখ্যাত', qty(d['rejected'], 'Poly'))] if d['qc'] == 'ACCEPTED' else [kpi('উৎপাদিত', qty(d['produced'], 'Poly')), kpi('QC-হোল্ড', qty(d['produced'], 'Poly'), 'বিক্রয়যোগ্য নয়')],
            info=info(('পরীক্ষা-আইডি', qcid), ('ব্যাচ', b), ('পরিদর্শক', EMP_PROFILE['EMP-102'][1]), ('ফল', 'গৃহীত' if d['qc'] == 'ACCEPTED' else 'হোল্ড (পুনঃপরীক্ষা অপেক্ষমাণ)'), ('নিয়ম', 'QC-হোল্ড বা অমুক্ত মজুত “উপলব্ধ তৈরি পণ্য” নয়')),
            history=[ev(bn(d['date']), 'নমুনা-পরীক্ষা', '', 'কিউসি কর্মকর্তা')] + ([ev(bn(d['date']), 'রিলিজ', qty(d['accepted'], 'Poly'), 'কিউসি কর্মকর্তা')] if d['qc'] == 'ACCEPTED' else [ev(bn(d['date']), 'হোল্ড', 'পুনঃপরীক্ষা অপেক্ষমাণ', 'কিউসি কর্মকর্তা')]))
        rel(key('QC_RECORD', qcid), key('BATCH', b))
    if d['qc'] == 'ACCEPTED':
        fg = 'FGR-' + b[-3:]
        add('FG_RECEIPT', fg, 'তৈরি পণ্য গ্রহণ ' + fg, status='POSTED', date=d['date'], subtitle='ব্যাচ ' + b + ' • ' + qty(d['accepted'], 'Poly'), createdBy='EMP-103',
            kpis=[kpi('গৃহীত Poly', qty(d['accepted'], 'Poly'))], info=info(('গ্রহণ-আইডি', fg), ('ব্যাচ', b), ('গুদাম', 'WH-FG'), ('শর্ত', 'শুধু QC-গৃহীত পরিমাণ গ্রহণযোগ্য')), history=[ev(bn(d['date']), 'গুদামে গৃহীত', '', 'স্টোরকিপার')])
        rel(key('FG_RECEIPT', fg), key('BATCH', b)); rel(key('FG_RECEIPT', fg), key('QC_RECORD', 'QC-' + b[-3:])); rel(key('FG_RECEIPT', fg), key('WAREHOUSE', 'WH-FG')); rel(key('FG_RECEIPT', fg), key('PRODUCT', pid))

# raw material dashboards (derived stock) and warehouses
for m in pos:
    p = pos[m]
    R[key('RAW_MATERIAL', m)]['kpis'] = [kpi('বর্তমান মজুত', qty(p['qty'], MAT_UNIT[m])), kpi('মজুত-মূল্য', money(p['value'])), kpi('চলমান গড় একক-খরচ', money(p['avg']), 'ডেমো-গণনা')]
    R[key('RAW_MATERIAL', m)]['info'] += info(('আপডেটকৃত মজুত', 'ডেমো-গণনা; যাচাইকৃত ডাটাবেস-যুক্তি ছাড়া চূড়ান্ত নয়'))
    rel(key('RAW_MATERIAL', m), key('WAREHOUSE', 'WH-RM'))
rm_value = sum((pos[m]['value'] for m in pos), D(0))
R[key('WAREHOUSE', 'WH-RM')]['kpis'] = [kpi('মোট মজুত-মূল্য', money(rm_value)), kpi('উপাদান', bn(len(pos)) + 'টি')]
fg_acc = sum(d['accepted'] for d in BAT.values())
R[key('WAREHOUSE', 'WH-FG')]['kpis'] = [kpi('উপলব্ধ (QC-গৃহীত)', qty(fg_acc, 'Poly')), kpi('QC-হোল্ড (অনুপলব্ধ)', qty(sum(d['produced'] for d in BAT.values() if d['qc'] == 'HOLD'), 'Poly'))]
for pid, name, cat in PRODUCTS: rel(key('WAREHOUSE', 'WH-FG'), key('PRODUCT', pid)) if any(BAT[b]['prod'] == pid and BAT[b]['accepted'] for b in BAT) else None

# ------------------------------------------------------------------ attendance & payroll for 3 employees
ATT = {'EMP-101': ['P', 'P', 'L', 'P', 'P'], 'EMP-102': ['P', 'P', 'P', 'A', 'P'], 'EMP-103': ['P', 'L', 'P', 'P', 'P']}
TIMES = {'P': ('০৭:৫৫', '১৬:০৫'), 'L': ('০৮:২২', '১৬:১০')}
for eid, days in ATT.items():
    mid = 'ATM-%s-202610' % eid[-3:]; present = days.count('P'); late = days.count('L'); absent = days.count('A')
    add('ATTENDANCE_MONTH', mid, 'উপস্থিতি — অক্টোবর ২০২৬ (প্রথম ৫ দিন, ডেমো)', subtitle=EMP_PROFILE[eid][1], date='2026-10-01',
        kpis=[kpi('উপস্থিত', bn(present) + ' দিন'), kpi('দেরিতে', bn(late) + ' দিন'), kpi('অনুপস্থিত', bn(absent) + ' দিন')],
        info=info(('কর্মী', EMP_PROFILE[eid][1]), ('পরিসর', 'অক্টোবর ২০২৬-এর প্রথম ৫ দিন (ডেমো-পরিসর)'), ('পদ্ধতি', 'ফ্যাক্টরির নির্ধারিত QR-ডিভাইস + PIN; ব্যাকআপ: অনুমোদিত HR-ম্যানুয়াল'), ('যাচাই', 'ডেমো — আসল যাচাইকৃত উপস্থিতি নয়')))
    rel(key('ATTENDANCE_MONTH', mid), key('EMPLOYEE', eid))
    for k, c in enumerate(days, 1):
        did = 'ATD-%s-2026100%d' % (eid[-3:], k); iso = '2026-10-0%d' % k
        add('ATTENDANCE_DAY', did, 'উপস্থিতি — ' + bn(iso), status={'P': 'PRESENT', 'L': 'LATE', 'A': 'ABSENT'}[c], date=iso, subtitle=EMP_PROFILE[eid][1],
            kpis=[kpi('অবস্থা', {'P': 'উপস্থিত', 'L': 'দেরিতে', 'A': 'অনুপস্থিত'}[c])] + ([kpi('প্রবেশ', TIMES[c][0]), kpi('প্রস্থান', TIMES[c][1])] if c != 'A' else []),
            info=info(('কর্মী', EMP_PROFILE[eid][1]), ('তারিখ', bn(iso)), ('শিফট', EMP_PROFILE[eid][7])) + ([('নোট', 'এই দিনে কোনো উপস্থিতি-ইভেন্ট নেই')] if c == 'A' else []))
        rel(key('ATTENDANCE_DAY', did), key('ATTENDANCE_MONTH', mid)); rel(key('ATTENDANCE_DAY', did), key('EMPLOYEE', eid))
        if c != 'A':
            for kind, tm in (('IN', TIMES[c][0]), ('OUT', TIMES[c][1])):
                aid = 'ATE-%s-2026100%d-%s' % (eid[-3:], k, kind)
                add('ATTENDANCE_EVENT', aid, ('প্রবেশ' if kind == 'IN' else 'প্রস্থান') + ' ' + tm, status='ACTIVE', date=iso, subtitle=EMP_PROFILE[eid][1],
                    info=info(('ইভেন্ট', 'প্রবেশ' if kind == 'IN' else 'প্রস্থান'), ('সময়', tm), ('পদ্ধতি', 'কারখানার প্রবেশদ্বারের নির্ধারিত QR-ডিভাইস + PIN (ডেমো)'), ('ডিভাইস', 'GATE-01 (ডেমো)'), ('যাচাই', 'ডেমো-ইভেন্ট; আসল যাচাইকৃত নয়')))
                rel(key('ATTENDANCE_EVENT', aid), key('ATTENDANCE_DAY', did)); rel(key('ATTENDANCE_EVENT', aid), key('EMPLOYEE', eid))
    pm = 'PRM-%s-202610' % eid[-3:]; psl = 'PSL-%s-202610' % eid[-3:]
    basic, allow = EMP_PROFILE[eid][9], EMP_PROFILE[eid][10]; ded = absent * (basic // 26); net = basic + allow - ded
    lines = [{'name': 'মূল বেতন', 'qty': '', 'unit': '', 'price': '', 'amount': money(basic), 'ref': ''}, {'name': 'ভাতা', 'qty': '', 'unit': '', 'price': '', 'amount': money(allow), 'ref': ''}, {'name': 'অনুপস্থিতি-কর্তন (ডেমো-সূত্র: মূল বেতন ÷ ২৬ × অনুপস্থিত দিন)', 'qty': bn(absent) + ' দিন', 'unit': '', 'price': '', 'amount': '-' + money(ded) if ded else money(0), 'ref': ''}]
    add('PAYROLL_MONTH', pm, 'বেতন — অক্টোবর ২০২৬ (ডেমো)', status='DRAFT', date='2026-10-31', subtitle=EMP_PROFILE[eid][1], createdBy='EMP-105',
        kpis=[kpi('নিট (ডেমো)', money(net))], info=info(('কর্মী', EMP_PROFILE[eid][1]), ('মাস', 'অক্টোবর ২০২৬'), ('অবস্থা', 'খসড়া — অনুমোদন-পূর্ব'), ('নীতি', 'পেরোল-অনুমতি ও কর্তন-নীতি অনুমোদিত নয় (Pending); স্বয়ংক্রিয় কর্তন নিষিদ্ধ নীতির সাথে এই ডেমো-সূত্র শুধু দৃশ্য-উদাহরণ')),
        lines=lines, totals=[['নিট', money(net)]], history=[ev('২০২৬-১০-৩১', 'খসড়া তৈরি', '', 'এইচআর কর্মকর্তা')])
    add('PAYSLIP', psl, 'পে-স্লিপ — অক্টোবর ২০২৬ (ডেমো)', status='DRAFT', date='2026-10-31', subtitle=EMP_PROFILE[eid][1], createdBy='EMP-105',
        kpis=[kpi('নিট (ডেমো)', money(net))], info=info(('কর্মী', EMP_PROFILE[eid][1]), ('বেতন-রেকর্ড', pm)), lines=lines, totals=[['নিট', money(net)]], history=[ev('২০২৬-১০-৩১', 'খসড়া', 'অনুমোদনের আগে চূড়ান্ত নয়', 'এইচআর কর্মকর্তা')])
    rel(key('PAYROLL_MONTH', pm), key('EMPLOYEE', eid)); rel(key('PAYSLIP', psl), key('PAYROLL_MONTH', pm)); rel(key('PAYSLIP', psl), key('EMPLOYEE', eid))

# ------------------------------------------------------------------ machines, maintenance, expenses
for i, (mid, name, kind) in enumerate(MACH):
    add('MACHINE', mid, name, subtitle=kind, imageTone=i, status='ACTIVE' if mid != 'MC-002' else 'ACTIVE', info=info(('মেশিন-কোড', mid), ('ধরন', kind), ('অবস্থান', 'উৎপাদন ফ্লোর (ডেমো)')), history=[ev('২০২৫-০১-১০', 'স্থাপিত', '', 'ফ্যাক্টরি')])
add('SPARE_PART', 'SPR-001', 'ড্রাইভ বেল্ট (F-02)', subtitle='স্পেয়ার পার্টস', info=info(('পার্ট-কোড', 'SPR-001'), ('মজুত (ডেমো)', '৪ পিস'), ('একক-দাম', money(1250))), imageTone=1)
add('SPARE_PART', 'SPR-002', 'সিলিং ব্লেড', subtitle='স্পেয়ার পার্টস', info=info(('পার্ট-কোড', 'SPR-002'), ('মজুত (ডেমো)', '৯ পিস'), ('একক-দাম', money(430))), imageTone=2)
add('BREAKDOWN', 'BRK-001', 'ব্রেকডাউন — ফিলিং মেশিন (F-02)', status='COMPLETED', date='2026-10-22', subtitle='ড্রাইভ বেল্ট ছিঁড়ে যায়', kpis=[kpi('ডাউনটাইম', '৩ ঘণ্টা ২০ মিনিট (ডেমো)')], info=info(('ব্রেকডাউন-আইডি', 'BRK-001'), ('মেশিন', 'MC-002'), ('কারণ', 'বেল্ট ক্ষয়')), history=[ev('২০২৬-১০-২২', 'ব্রেকডাউন নথিভুক্ত', '', 'উৎপাদন সুপারভাইজার')])
add('MAINTENANCE', 'MNT-001', 'সংশোধনমূলক রক্ষণাবেক্ষণ — F-02', status='COMPLETED', date='2026-10-22', subtitle='ব্রেকডাউন BRK-001-এর পর', createdBy='EMP-101', kpis=[kpi('ব্যয়', money(2500))], info=info(('রক্ষণাবেক্ষণ-আইডি', 'MNT-001'), ('ধরন', 'সংশোধনমূলক'), ('ব্যবহৃত পার্ট', 'ড্রাইভ বেল্ট × ২')), history=[ev('২০২৬-১০-২২', 'সম্পন্ন', '', 'রক্ষণাবেক্ষণ দল')])
add('MAINTENANCE', 'MNT-002', 'প্রতিরোধমূলক রক্ষণাবেক্ষণ — M-01', status='PENDING', date='2026-11-02', subtitle='নির্ধারিত', createdBy='EMP-101', info=info(('রক্ষণাবেক্ষণ-আইডি', 'MNT-002'), ('ধরন', 'প্রতিরোধমূলক'), ('নির্ধারিত তারিখ', bn('2026-11-02'))))
add('EXPENSE', 'EXP-001', 'রক্ষণাবেক্ষণ-ব্যয় EXP-001', status='POSTED', date='2026-10-22', subtitle='স্পেয়ার পার্টস — F-02', createdBy='EMP-106', kpis=[kpi('পরিমাণ', money(2500))],
    info=info(('ব্যয়-আইডি', 'EXP-001'), ('বিভাগ', 'রক্ষণাবেক্ষণ'), ('কস্ট-সেন্টার', 'ফিলিং ও সিলিং (ডেমো)')), lines=[{'name': 'ড্রাইভ বেল্ট', 'qty': '২', 'unit': 'পিস', 'price': money(1250), 'amount': money(2500), 'ref': 'SPR/SPR-001'}], totals=[['মোট', money(2500)]],
    approval=[ev('২০২৬-১০-২২', 'জমা', '', 'হিসাবরক্ষক'), ev('২০২৬-১০-২২', 'অনুমোদিত', 'নমুনা: অর্থ ব্যবস্থাপক', 'অর্থ ব্যবস্থাপক')], history=[ev('২০২৬-১০-২২', 'পোস্টকৃত', '', 'হিসাবরক্ষক')])
add('EXPENSE', 'EXP-002', 'বিদ্যুৎ-ব্যয় (আংশিক) EXP-002', status='SUBMITTED', date='2026-10-27', subtitle='ইউটিলিটি', createdBy='EMP-106', kpis=[kpi('পরিমাণ', money(48500))],
    info=info(('ব্যয়-আইডি', 'EXP-002'), ('বিভাগ', 'ইউটিলিটি'), ('নোট', 'ব্যাচে বণ্টনের নীতি Pending')), lines=[{'name': 'বিদ্যুৎ-বিল (আংশিক)', 'qty': '', 'unit': '', 'price': '', 'amount': money(48500), 'ref': ''}], totals=[['মোট', money(48500)]],
    approval=[ev('২০২৬-১০-২৭', 'জমা', '', 'হিসাবরক্ষক'), ev('অপেক্ষমাণ', 'অনুমোদন', '', 'অনুমোদনকারী')], history=[ev('২০২৬-১০-২৭', 'জমা দেওয়া', '', 'হিসাবরক্ষক')])
add('FACTORY_PNL', 'PNL-202610', 'ফ্যাক্টরি লাভ-ক্ষতি — অক্টোবর ২০২৬', status='PENDING', date='2026-10-31', subtitle='শুধু এমডি', sensitive=[['অবস্থা', 'পূর্ণ খরচ-বণ্টন ও বিক্রয়-তথ্যের নীতি অনুমোদিত নয়; কোনো সংখ্যা তৈরি করা হয়নি']],
    info=info(('দর্শক', 'শুধু সংশ্লিষ্ট কোম্পানির এমডি'), ('নোট', 'অবিক্রীত তৈরি পণ্য আয় নয়; প্রক্ষেপিত লাভ প্রকৃত লাভ নয়')))
rel(key('MACHINE', 'MC-002'), key('MAINTENANCE', 'MNT-001')); rel(key('MAINTENANCE', 'MNT-001'), key('BREAKDOWN', 'BRK-001')); rel(key('BREAKDOWN', 'BRK-001'), key('MACHINE', 'MC-002'))
rel(key('BREAKDOWN', 'BRK-001'), key('SPARE_PART', 'SPR-001')); rel(key('MAINTENANCE', 'MNT-001'), key('SPARE_PART', 'SPR-001')); rel(key('SPARE_PART', 'SPR-001'), key('EXPENSE', 'EXP-001')); rel(key('MAINTENANCE', 'MNT-001'), key('EXPENSE', 'EXP-001'))
rel(key('MACHINE', 'MC-001'), key('MAINTENANCE', 'MNT-002'))
for e in EMP:                                               # employee -> responsible links
    pass
rel(key('BATCH', 'B-001'), key('EMPLOYEE', 'EMP-101')); rel(key('BATCH', 'B-002'), key('EMPLOYEE', 'EMP-101')); rel(key('QC_RECORD', 'QC-001'), key('EMPLOYEE', 'EMP-102'))

# ------------------------------------------------------------------ attach related groups
TYPE_TITLE = {}
def tt(t): return t
for a, bs in REL.items():
    pass
rec_related = defaultdict(lambda: OrderedDict())
for a, bs in REL.items():
    for b in bs:
        rec_related[a].setdefault(b[0], []).append(b)
for k, r in R.items():
    r['related'] = [{'type': t, 'refs': ['%s/%s' % (x[0], x[1]) for x in sorted(set(refs), key=lambda z: z[1])]} for t, refs in rec_related.get(k, {}).items()]
# product ↔ batch/FG/QC/cost shortcut links
for b, d in BAT.items():
    kk = key('PRODUCT', d['prod'])
    exist = {g['type'] for g in R[kk]['related']}

# notifications (each opens a record)
NOTIFS = [
 {'id': 'N-001', 'title': 'অনুমোদনের অপেক্ষায়: ক্রয় আদেশ PO-006', 'detail': 'এনডিসি ৬০০ কেজি', 'ref': 'PURCHASE_ORDER/PO-006', 'when': 'আজ'},
 {'id': 'N-002', 'title': 'কিউসি হোল্ড: ব্যাচ B-003', 'detail': '৭৮০ Poly বিক্রয়যোগ্য নয়', 'ref': 'QC_RECORD/QC-003', 'when': 'আজ'},
 {'id': 'N-003', 'title': 'অনুমোদনের অপেক্ষায়: বিদ্যুৎ-ব্যয় EXP-002', 'detail': '৳ ৪৮,৫০০', 'ref': 'EXPENSE/EXP-002', 'when': 'গতকাল'},
 {'id': 'N-004', 'title': 'রক্ষণাবেক্ষণ নির্ধারিত: মিক্সিং মেশিন', 'detail': '০২ নভেম্বর', 'ref': 'MAINTENANCE/MNT-002', 'when': '২ দিন আগে'},
 {'id': 'N-005', 'title': 'আপনার খসড়া: ক্রয় আদেশ PO-007', 'detail': 'জমা দেওয়া হয়নি', 'ref': 'PURCHASE_ORDER/PO-007', 'when': 'আজ'},
]
# QR tokens
QR = {r['qrToken']: '%s/%s' % (r['type'], r['id']) for r in R.values() if r['qrToken']}
# facts for runtime dashboards / costing
FACTS = {'events': [{'material': m, 'date': dt, 'seq': sq, 'kind': kind, 'qty': str(qq), 'price': (str(pr) if pr is not None else None), 'batch': b} for (m, dt, sq, kind, qq, pr, b) in sorted(EVENTS, key=lambda e: (e[1], e[2]))],
         'batches': [{'id': b, 'product': d['prod'], 'date': d['date'], 'planned': d['planned'], 'produced': d['produced'], 'accepted': d['accepted'], 'status': d['status'], 'qc': d['qc'],
                      'consumed': {m: str(v) for m, v in d['consumed'].items()}, 'waste': {m: str(v) for m, v in d['waste'].items()}} for b, d in BAT.items()],
         'supplierDues': {s: str(v) for s, v in SUP_DUE.items()}, 'materials': {m: {'name': MAT_NAME[m], 'unit': MAT_UNIT[m]} for m in MAT_NAME}}

OUT = {'version': 1, 'demoDate': DEMO_DATE, 'meId': ME, 'companies': COMPANIES, 'records': [r for r in R.values()], 'notifications': NOTIFS, 'qr': QR, 'facts': FACTS, 'expected': EXPECTED}

# ------------------------------------------------------------------ integrity checks
def verify():
    errs = []
    keys = {'%s/%s' % k for k in R}
    for r in R.values():
        for g in r['related']:
            for x in g['refs']:
                if x not in keys: errs.append('dangling related %s -> %s' % (r['id'], x))
        for l in r['lines']:
            if l['ref'] and l['ref'].split('/')[0] in ('MAT', 'PO', 'SPR', 'BAT'):
                pass
        for f in ('originalOf', 'reversalOf', 'replacementOf'):
            if r[f] and r[f] not in keys: errs.append('dangling %s %s' % (f, r[f]))
        if r['createdBy'] and ('EMPLOYEE/%s' % r['createdBy']) not in keys: errs.append('unknown createdBy %s on %s' % (r['createdBy'], r['id']))
        if r['company'] not in {c['id'] for c in COMPANIES}: errs.append('bad company ' + r['id'])
    for n in NOTIFS:
        if n['ref'] not in keys: errs.append('notification target ' + n['ref'])
    for t, rf in QR.items():
        if rf not in keys: errs.append('qr target ' + rf)
    # symmetric relations
    for r in R.values():
        me = '%s/%s' % (r['type'], r['id'])
        for g in r['related']:
            for x in g['refs']:
                other = R[tuple(x.split('/', 1))]
                if not any(me in gg['refs'] for gg in other['related']): errs.append('asymmetric %s -> %s' % (me, x))
    # cross-company isolation: no C1<->C2 links
    for r in R.values():
        for g in r['related']:
            for x in g['refs']:
                if R[tuple(x.split('/', 1))]['company'] != r['company']: errs.append('cross-company link %s -> %s' % (r['id'], x))
    # accounting sanity
    for b, c in BATCH_COST.items():
        if c['cpp'] is not None: assert abs(q(c['cpp'] * c['accepted'], 0) - q(c['total'], 0)) <= c['accepted'], b
    for m, p in pos.items(): assert p['qty'] >= 0 and p['value'] >= 0
    # no stock goes negative; supplier ledger balances match dues
    for s in SUP_DUE: assert bal[s] == SUP_DUE[s], (s, bal[s], SUP_DUE[s])
    return errs

if __name__ == '__main__':
    errs = verify()
    if errs: print('\n'.join(errs)); sys.exit(1)
    here = os.path.dirname(os.path.abspath(__file__)); out = os.path.join(here, '..', 'app', 'src', 'main', 'assets', 'demo'); os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, 'demo_data.json'), 'w', encoding='utf-8') as f: json.dump(OUT, f, ensure_ascii=False, indent=1)
    types = defaultdict(int)
    for r in R.values(): types[r['type']] += 1
    print('records', len(R), dict(types)); print('expected wac_final', EXPECTED['wac_final']); print('cost per poly', EXPECTED['material_cost_per_poly']); print('supplier due', EXPECTED['supplier_due'])
    print('related edges', sum(len(v) for v in REL.values()) // 2, 'qr tokens', len(QR))
