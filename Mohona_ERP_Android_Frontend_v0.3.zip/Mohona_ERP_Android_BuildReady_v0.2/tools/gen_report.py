#!/usr/bin/env python3
"""Generates FRONTEND_REPORT_BN.md from the real source tree and demo data, so every number in the report is measured, not typed."""
import glob, json, os, re, sys, zipfile, tempfile, collections, hashlib
ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
J = os.path.join(ROOT, 'app/src/main/java/com/mohona/erp')
BN = '০১২৩৪৫৬৭৮৯'
def bn(x): return ''.join(BN[int(c)] if c.isdigit() else c for c in str(x))
d = json.load(open(os.path.join(ROOT, 'app/src/main/assets/demo/demo_data.json'), encoding='utf-8'))
R = {r['type'] + '/' + r['id']: r for r in d['records']}
files = sorted(glob.glob(J + '/**/*.kt', recursive=True))
src = {f: open(f, encoding='utf-8').read() for f in files}
rel = lambda f: os.path.relpath(f, ROOT)

# ---- 1. changes versus the delivered v0.2 ZIP (app sources only)
old = {}
zp = os.path.join(ROOT, '..', 'Mohona_ERP_Android_BuildReady_v0.2.zip')
if os.path.exists(zp):
    z = zipfile.ZipFile(zp)
    for n in z.namelist():
        if n.startswith('Mohona_ERP_Android_BuildReady_v0.2/app/') and not n.endswith('/'):
            old[n.split('Mohona_ERP_Android_BuildReady_v0.2/', 1)[1]] = hashlib.sha256(z.read(n)).hexdigest()
new = {}
for f in glob.glob(ROOT + '/app/**/*', recursive=True):
    if os.path.isfile(f): new[rel(f)] = hashlib.sha256(open(f, 'rb').read()).hexdigest()
added = sorted(set(new) - set(old)); removed = sorted(set(old) - set(new)); modified = sorted(k for k in new if k in old and new[k] != old[k])

# ---- 2. screens / components
screens = []
for f, s in src.items():
    for m in re.finditer(r'@Composable\s+fun (\w+Screen)\(', s): screens.append((m.group(1), rel(f).split('com/mohona/erp/')[-1]))
comps = []
for f, s in src.items():
    if '/ui/components/' in f:
        for m in re.finditer(r'@Composable\s+(?:internal )?fun (\w+)\(', s):
            comps.append(m.group(1))
nav = src[J + '/ui/navigation/AppNavigation.kt']
routes = re.findall(r'const val (\w+) = "([^"]+)"', nav)
tests = glob.glob(ROOT + '/app/src/test/**/*.kt', recursive=True)
n_tests = sum(open(t, encoding='utf-8').read().count('@Test') for t in tests)

# ---- 3. entity / transaction coverage from the data
types = collections.OrderedDict()
for r in d['records']: types.setdefault(r['type'], []).append(r)
kinds = dict(re.findall(r'^\s+([A-Z_]+)\("(?:[a-z]+)", "[^"]+", "[^"]+", RecordKind\.(\w+)', open(J + '/domain/RecordModel.kt', encoding='utf-8').read(), re.M))
def pct(lst, f): return '%d/%d' % (sum(1 for x in lst if f(x)), len(lst))
ent_rows = []
for t, lst in types.items():
    ent_rows.append('| %s | %s | %d | %s | %s | %s | %s |' % (t, kinds.get(t, '?'), len(lst), pct(lst, lambda r: bool(r['related'])), pct(lst, lambda r: bool(r['history'])), pct(lst, lambda r: bool(r['kpis'])), pct(lst, lambda r: bool(r['qrToken']))))
tx_rows = []
for t, lst in types.items():
    if kinds.get(t) == 'TRANSACTION':
        tx_rows.append('| %s | %d | %s | %s | %s | %s | %s |' % (t, len(lst), pct(lst, lambda r: bool(r['lines'])), pct(lst, lambda r: bool(r['totals'])), pct(lst, lambda r: bool(r['approval'])), pct(lst, lambda r: bool(r['history'])), pct(lst, lambda r: bool(r['related']))))

# ---- 4. role matrix: mirror of domain/Access.kt (UI hints from Appendix F)
OPS = {"MD", "WING_HEAD", "STOREKEEPER", "PROD_SUPERVISOR", "QC_OFFICER", "PURCHASE_OFFICER", "CHAIRMAN", "AUDITOR"}
PARTY = {"CHAIRMAN", "MD", "WING_HEAD", "FIN_MANAGER", "ACCOUNTANT", "PURCHASE_OFFICER", "AUDITOR"}
FIN = {"CHAIRMAN", "MD", "WING_HEAD", "FIN_MANAGER", "ACCOUNTANT", "CASHIER", "AUDITOR"}
HR = {"MD", "WING_HEAD", "HR_OFFICER"}; ATT = {"WING_HEAD", "HR_OFFICER", "PROD_SUPERVISOR"}
def roles_for(t):
    if t in ('EMPLOYEE', 'PAYROLL_MONTH', 'PAYSLIP'): return HR
    if t in ('ATTENDANCE_MONTH', 'ATTENDANCE_DAY', 'ATTENDANCE_EVENT'): return ATT
    if t in ('SUPPLIER', 'PURCHASE_ORDER'): return PARTY | OPS
    if t in ('PAYMENT_VOUCHER', 'SUPPLIER_LEDGER', 'EXPENSE'): return FIN
    if t == 'FACTORY_PNL': return {'MD'}
    return OPS | FIN
ROLES = ['CHAIRMAN', 'MD', 'WING_HEAD', 'FIN_MANAGER', 'ACCOUNTANT', 'CASHIER', 'HR_OFFICER', 'STOREKEEPER', 'PROD_SUPERVISOR', 'QC_OFFICER', 'PURCHASE_OFFICER', 'SALES_MANAGER', 'FIELD_SALES', 'AUDITOR', 'EMPLOYEE_SELF', 'EMERGENCY_ADMIN', 'TECH_ADMIN']
ALLT = list(types)
MODS = re.findall(r'ModuleSpec\("(\w+)", "[^"]+", "[^"]*", "\w+", listOf\(([^)]*)\)', open(J + '/domain/WingRegistry.kt', encoding='utf-8').read())
MODS = [(m, [x.strip().replace('RecordType.', '') for x in ts.split(',')]) for m, ts in MODS]
self_types = {'EMPLOYEE', 'ATTENDANCE_MONTH', 'PAYROLL_MONTH', 'PAYSLIP'}
role_rows = []
for r in ROLES:
    open_t = [t for t in ALLT if r in roles_for(t)]
    selfv = r == 'EMPLOYEE_SELF'
    mods = [m for m, ts in MODS if any((r in roles_for(t)) or (selfv and t in self_types) for t in ts)]
    role_rows.append('| %s | %s | %d/%d | %d/%d | %s | %s | %s |' % (r, 'হ্যাঁ' if mods else 'না', len(mods), len(MODS), len(open_t) + (4 if selfv else 0), len(ALLT), 'হ্যাঁ' if r in {"CHAIRMAN", "MD", "WING_HEAD", "FIN_MANAGER"} else 'না', 'হ্যাঁ' if r == 'MD' else 'না', 'হ্যাঁ' if (r in HR or selfv) else 'না'))

# ---- 5. demo relationships
edges = sum(len(g['refs']) for r in d['records'] for g in r['related']) // 2
types_count = ', '.join('%s %d' % (t, len(l)) for t, l in types.items())

out = []
w = out.append
w('# মোহনা ERP — Frontend v0.3 প্রতিবেদন (সংখ্যাগুলো সোর্স ও ডেমো-ডেটা থেকে স্ক্রিপ্টে মাপা)')
w('')
w('> **Build ফল: UNVERIFIED।** এই পরিবেশে Android SDK/Gradle/Kotlin-কম্পাইলার নেই; Kotlin কোড কখনো কম্পাইল বা চালানো হয়নি। নিচে “পরীক্ষিত” মানে শুধু Python-এ চালানো যাচাই (ডেমো-ডেটা, গাণিতিক হিসাব, মিরর-পরীক্ষা)। JVM Unit Test **লেখা আছে, চালানো হয়নি**। কোনো APK দেওয়া হয়নি।')
w('')
w('## ১. সোর্স-পরিবর্তনের সারসংক্ষেপ (v0.2 ZIP-এর তুলনায়, শুধু `app/`)')
w('- **Kotlin মূল ফাইল:** %d টি, %s লাইন; **JVM Test ফাইল:** %d টি (%d টি `@Test`); **ডেমো-ডেটা:** `assets/demo/demo_data.json` (%d রেকর্ড)।' % (len(files), bn(sum(s.count('\n') for s in src.values())), len(tests), n_tests, len(R)))
w('- নতুন %d, পরিবর্তিত %d, অপসারিত %d (অপসারিতগুলো নতুন কাঠামোয় প্রতিস্থাপিত)।' % (len(added), len(modified), len(removed)))
w('- **অপসারিত (সচেতনভাবে):** পুরোনো গ্লোবাল Dashboard (KPI/চার্ট — নতুন Home-নিয়মের বিরোধী), `ModuleScreens` (প্রতি-Feature নমুনা-তালিকা), পুরোনো `registry/*`, `SampleData` — সব এখন একটি সাধারণ Record-ইঞ্জিন ও ডেমো-Repository দিয়ে প্রতিস্থাপিত। Login, Theme, Charts, ⋮ মেনু, Session (প্রমাণীকরণ/অনুমতি আলাদা), QR-ইন্টারফেস, রোল-মডেল **সংরক্ষিত**।')
w('')
w('## ২. স্ক্রিন-তালিকা (%d)' % len(screens))
w('| স্ক্রিন (Composable) | ফাইল |'); w('| --- | --- |')
for n, f in sorted(set(screens)): w('| `%s` | `%s` |' % (n, f))
w('')
w('## ৩. Navigation-মানচিত্র')
w('| Route | প্যাটার্ন |'); w('| --- | --- |')
for n, p in routes: w('| `%s` | `%s` |' % (n, p))
w('')
w('স্তর: ১ গ্লোবাল Home (`home`) → ২ Wing (`wing/{id}`) → ৩ Module (`module/{wing}/{module}`) → ৪ তালিকা (`list/{type}`) → ৫–৭ **একটিই** Record Dashboard (`record/{type}/{id}`), যেখান থেকে সংযুক্ত রেকর্ড আবার একই পর্দায় খোলে। বাইরের প্রবেশপথ: অনুসন্ধান, বিজ্ঞপ্তি, QR (`qr/{token}`), রিপোর্ট-সারি, অনুমোদন-কেন্দ্র — সবাই একই Route ব্যবহার করে। কোম্পানি-প্রসঙ্গ Session-এ থাকে।')
w('')
w('## ৪. পুনর্ব্যবহারযোগ্য Component (%d)' % len(set(comps)))
w(', '.join('`%s`' % c for c in sorted(set(comps))))
w('')
w('## ৫. Entity Dashboard Coverage (ডেমো-ডেটায় মাপা; সবাই একই Record-ইঞ্জিনে)')
w('| ধরন | শ্রেণি | রেকর্ড | সংযুক্ত রেকর্ড আছে | ইতিহাস আছে | KPI আছে | QR আছে |'); w('| --- | --- | --- | --- | --- | --- | --- |')
out += ent_rows
w('')
w('## ৬. Transaction Detail Coverage')
w('| ধরন | রেকর্ড | আইটেম-লাইন | মোট | অনুমোদন-টাইমলাইন | ইতিহাস | সংযুক্ত |'); w('| --- | --- | --- | --- | --- | --- | --- |')
out += tx_rows
w('')
w('যেসব ক্ষেত্র একটি লেনদেনে প্রযোজ্য নয় (যেমন বেতন-খসড়ায় ইনভেন্টরি-চলাচল) সেগুলো বানানো হয়নি; “অনুমোদন-টাইমলাইন” খালি থাকলে পর্দায় সৎ “কোনো ধাপ নেই” দেখায়।')
w('')
w('## ৭. Role-ভিত্তিক UI Coverage (UI-ইঙ্গিত; Appendix F-এর সিড থেকে; আসল নিয়ন্ত্রণ সার্ভারে)')
w('| Role | উইং খোলে | মডিউল | খুলতে পারা রেকর্ড-ধরন | অনুমোদন-ইঙ্গিত | ফ্যাক্টরি P&L | সংবেদনশীল তথ্য |'); w('| --- | --- | --- | --- | --- | --- | --- |')
out += role_rows
w('')
w('টীকা: `hr.payroll.view` অনুমোদিত ম্যাট্রিক্সে নেই, তাই বেতন-তথ্যের দৃশ্যমানতা **Pending-ইঙ্গিত**; `hr.attendance.view` ম্যাট্রিক্সে শুধু WING_HEAD, HR_OFFICER, PROD_SUPERVISOR (ও নিজ-কর্মী); **MD তালিকায় নেই**, তাই MD-কে উপস্থিতি-রেকর্ড খুলতে দেওয়া হয়নি — এটি ম্যাট্রিক্সের সম্ভাব্য বাদ পড়া; আপনার নিশ্চিতকরণ ছাড়া আমি অনুমতি যোগ করিনি।')
w('')
w('## ৮. ডেমো-ডেটা সম্পর্ক')
w('- মোট %d রেকর্ড, %d সংযোগ (দ্বিমুখী; অ-প্রতিসম বা ঝুলন্ত সংযোগ ০; কোম্পানি-মধ্যবর্তী সংযোগ ০)।' % (len(R), edges))
w('- ধরন-ভিত্তিক: ' + types_count)
w('- সব হিসাব `tools/gen_demo.py` থেকে (Moving Weighted Average, ইস্যু-খরচ, ব্যাচ-খরচ, সরবরাহকারী-বকেয়া); Kotlin `Costing` রানটাইমে একই গণনা করে এবং JVM Test দুটি ফল মেলায়।')
w('- রাউন্ডিং (মূল্য ২ দশমিক, একক-খরচ ৪ দশমিক) **ডেমো-পছন্দ, অনুমোদিত নীতি নয়**।')
w('- ডেমো-গণনা-ফল: ' + json.dumps(d['expected']['material_cost_per_poly'], ensure_ascii=False) + ' (টাকা প্রতি Poly, শুধু উপাদান-খরচ, আংশিক); সরবরাহকারী-বকেয়া ' + json.dumps(d['expected']['supplier_due'], ensure_ascii=False))
w('')
w('## ৯. সাতটি Journey: অবস্থা')
w('| Journey | সংযোগ ডেটায় আছে | Python-মিরর পরীক্ষা | JVM Test | ডিভাইসে চালানো |'); w('| --- | --- | --- | --- | --- |')
for j in ['A ক্রয় → উৎপাদন → খরচ/Poly', 'B কর্মী → উপস্থিতি → মাস → দিন → ইভেন্ট; বেতন → পে-স্লিপ', 'C লেনদেন → পক্ষ → খতিয়ান → ভাউচার → অনুমোদন-ইতিহাস → মূল লেনদেন', 'D মেশিন → রক্ষণাবেক্ষণ → ব্রেকডাউন → পার্ট → ব্যয়', 'E গুদাম → উপাদান-স্টক → চলাচল → উৎস-নথি → ব্যাচ', 'F QR → প্রিভিউ → অনুমোদিত বিবরণ → ইতিহাস', 'G ব্যবস্থাপনা → ড্যাশবোর্ড → অপেক্ষমাণ অনুমোদন → লেনদেন → কাজ (সিমুলেটেড) → ইতিহাস']:
    w('| %s | হ্যাঁ | পাস | লেখা, **চালানো হয়নি** | **UNVERIFIED** |' % j)
w('')
w('## ১০. বাস্তবায়ন-অবস্থা')
w('**Implemented (কোড লেখা; কম্পাইল-যাচাই নেই):** গ্লোবাল Home (শুধু অনুমোদিত উইং-কার্ড, কোম্পানি-নির্বাচক, অনুসন্ধান/বিজ্ঞপ্তি/প্রোফাইল); Manufacturing Wing Dashboard (তারিখ-ফিল্টার + Universal Calendar, পণ্য-ছবি-KPI প্রথম ৬টি + “সব পণ্য দেখুন”, সারাংশ-টাইল, ডেমো-ডেটা-চালিত চার্ট, সতর্কতা/অনুমোদন, মডিউল-গ্রিড); মডিউল-ড্যাশবোর্ড; সাধারণ তালিকা (অনুসন্ধান, স্ট্যাটাস-ফিল্টার, তারিখ-ফিল্টার); **সার্বজনীন Record Dashboard** (সব ধরন); **Transaction Detail** (লাইন, মোট, অনুমোদন, ইতিহাস, সংশোধন-সূত্র); প্রসঙ্গ-ভিত্তিক ⋮ মেনু (অবস্থা+ভূমিকা+কোম্পানি-নির্ভর); সিমুলেটেড অনুমোদন/ফেরত/প্রত্যাখ্যান/জমা/বাতিল (Maker-Checker সহ); অনুমোদন-কেন্দ্র; অনুসন্ধান; বিজ্ঞপ্তি (রেকর্ড-লিংক); QR-প্রিভিউ (অনুমতি-যাচাইসহ); রিপোর্ট-কেন্দ্র (১৩টি ডেমো-রিপোর্ট, সারি-ক্লিক); চেয়ারম্যান-মডিউল (Pending-ভিত্তিক); Role-ভিত্তিক দৃশ্যমানতা; Moving Weighted Average (ডেমো) ও Material Cost per Poly (আংশিক, লেবেলসহ); অনুপস্থিত/অবৈধ রেকর্ড, কোম্পানি-ভুল ও অনুমতি-নেই অবস্থা।')
w('')
w('**Partial:** Payslip-এর “কর্তন-বিবরণ” আলাদা পর্দা নয় (পে-স্লিপের লাইনে); BOM-সম্পাদনা ও নতুন-রেকর্ড ফর্ম নেই (সম্পাদনা-বোতাম নিষ্ক্রিয়); Product Poly-রূপান্তর Pending (কোনো মান ধরে নেওয়া হয়নি); পণ্য-ছবি শুধু প্লেসহোল্ডার; Calendar-এর কার্যক্রম-চিহ্ন এখন উৎপাদন/রেকর্ড-তারিখ-ভিত্তিক; Dealer/Retailer/Invoice নেই; Offline/Loading অবস্থা-Component আছে, কিন্তু ডেমো-ডেটা তাৎক্ষণিক বলে Loading বাস্তবে দেখা যায় না।')
w('')
w('**Not implemented:** Dealer, Retailer, Sales Invoice, Collection (নিশ্চিত Sales-উইং নেই); ক্রয়-ইনভয়েস ও ক্রয়-ফেরত; Production Plan; অপচয়-বিশ্লেষণ; ফিজিক্যাল স্টক যাচাই; Market-return repackaging; স্টক-স্থানান্তর/সমন্বয়; ছুটি, শিফট-রোস্টার, অগ্রিম/ঋণ, পদোন্নতি/বদলি ফর্ম; স্পেয়ার পার্টস ক্রয়; কস্ট-সেন্টার; PDF/PNG/WhatsApp/Email/A4/POS রপ্তানি ও প্রিন্ট (সব নিষ্ক্রিয়/“পরিকল্পিত”); ক্যামেরা-QR-স্ক্যানার; আসল QR-তৈরি; Supabase-সংযোগ (Preview-মোডে ব্যবসায়িক পর্দা শুধু ডেমো); Hilt (Build প্রমাণের আগে স্থগিত); Compose UI-Test।')
w('')
w('## ১১. জানা সমস্যা ও ঝুঁকি')
for x in ['**Kotlin কখনো কম্পাইল হয়নি।** নতুন/পরিবর্তিত Kotlin ফাইলে মোট %d লাইন (মাপা); কম্পাইল-ত্রুটি থাকার সম্ভাবনা বাস্তব। প্রথম GitHub Actions রানে ত্রুটি এলে লগ পাঠান।' % sum(open(os.path.join(ROOT, k), encoding='utf-8').read().count('\n') for k in added + modified if k.endswith('.kt')),
          'JVM Test ও APK-নির্মাণ একই Workflow-এ; Test ব্যর্থ হলে APK ব্লক হয় না (`continue-on-error`), কিন্তু রিপোর্ট Artifact-এ থাকে।',
          '`Icons.Filled.KeyboardArrowLeft` ইত্যাদি কিছু Icon Deprecation-সতর্কতা দিতে পারে (ত্রুটি নয়)।',
          'JSON-ডেমো-ডেটা ~৩৩০ KB; পুরোটা শুরুতে একবার পার্স হয় (সামান্য বিলম্ব সম্ভব)।',
          'ডেমো-সিমুলেশন Session-ভিত্তিক; অ্যাপ বন্ধ করলে মুছে যায়, লগআউটে রিসেট।',
          'Preview-মোডে ভূমিকা বদলালে শুধু দৃশ্য বদলায় (UI-ইঙ্গিত) — এটি নিরাপত্তা নয়।',
          'আসল ব্যাকএন্ডের কোনো Migration/RPC এই কাজে ব্যবহৃত বা চালানো হয়নি।']: w('- ' + x)
w('')
w('## ১২. স্বয়ংক্রিয় পরীক্ষার ফল (সৎ বিভাজন)')
w('| পরীক্ষা | অবস্থা |'); w('| --- | --- |')
w('| ডেমো-ডেটা জেনারেটর `tools/gen_demo.py`: সংযোগ-অখণ্ডতা, ক্রমিক-ঋণাত্মক-স্টক নেই, সরবরাহকারী-খতিয়ান = বকেয়া, স্থিতিশীল (দুইবার চালিয়ে একই হ্যাশ) | **চালানো, পাস** |')
w('| Python-মিরর: JVM Test-এর সব প্রত্যাশা আসল JSON-এ (সংযোগ, Journey-লিংক, FG ১,৯৪৫/০, QC-হোল্ড, BOM-সংস্করণ, Poly Pending, VAT/CCTV অনুপস্থিতি, সংশোধন-সূত্র) | **চালানো, পাস** |')
w('| স্ট্যাটিক: বন্ধনী-ভারসাম্য, প্রকল্প-Import, ডুপ্লিকেট নাম, Identifier/Import-সমাধান | **চালানো, পাস** (কম্পাইল নয়) |')
w('| JVM Unit Test (`DemoGraphTest`, `RoutesTest`): %d টি | **লেখা, চালানো হয়নি (UNVERIFIED)** |' % n_tests)
w('| Compose UI/Instrumented Test | **লেখা হয়নি** |')
w('| Android Build / APK / ফোনে চালানো | **UNVERIFIED** |')
w('')
w('## ১৩. Android Build নির্দেশনা')
w('GitHub: Repository-র বিদ্যমান Workflow “Android Debug APK” চালান (Actions → Run workflow); APK Artifact `mohona-erp-debug-apk`; Test-রিপোর্ট Artifact `unit-test-reports`। Android Studio: Open → Sync → Build → Build APK(s)। কমান্ড: `./gradlew assembleDebug testDebugUnitTest` (Wrapper-jar না থাকলে README_BN-এর বিকল্প)।')
w('')
w('## ১৪. ভবিষ্যৎ Supabase-সংযোগ-মানচিত্র (পরিকল্পনা; এখন কিছুই সংযুক্ত নয়)')
w('| রেকর্ড-ধরন | ভবিষ্যৎ উৎস (প্রস্তাবিত) | মন্তব্য |'); w('| --- | --- | --- |')
for t, h, note in [('PRODUCT / RAW_MATERIAL / SUPPLIER', '`mfg.products`, `inv.items`, `core.parties` + Storage (ছবি)', 'প্রতিটি `organization_id` + Composite FK; ছবি Private Bucket + Signed URL'), ('PURCHASE_ORDER / GRN / MATERIAL_ISSUE / CONSUMPTION', 'First-Slice S3–S9 RPC', 'Maker-Checker সার্ভারে; Idempotency-Key'), ('STOCK_MOVEMENT / WAREHOUSE', '`inv.stock_movements` (Append-only)', 'MWAC সার্ভারে; ঋণাত্মক-স্টক-নীতি Pending'), ('BATCH / BOM / QC / FG', 'S6–S12', 'অপরিবর্তনীয় BOM-সংস্করণ; QC-মুক্ত না হলে মজুত উপলব্ধ নয়'), ('BATCH_COST', 'S13', 'শুধু উপাদান-খরচ; পূর্ণ খরচ নীতি-সাপেক্ষ'), ('PAYMENT_VOUCHER / EXPENSE / SUPPLIER_LEDGER', 'Finance Ledger', 'Reversal+Replacement; GRNI-নীতি Pending'), ('EMPLOYEE / ATTENDANCE / PAYROLL', 'HR-মডিউল', 'কর্মী-প্রোফাইল ও লগইন আলাদা; পেরোল-অনুমতি নীতি Pending'), ('MACHINE / MAINTENANCE', 'Maintenance-মডিউল', '—'), ('QR', '`api.v1_qr_resolve`', 'টোকেন ≠ আইডি; সার্ভার অনুমতি-যাচাই'), ('Auth/Session', 'বিদ্যমান `AuthRepository` (OD-02)', 'অপরিবর্তিত')]: w('| %s | %s | %s |' % (t, h, note))
w('')
w('## ১৫. সঠিক ফাইল-তালিকা (v0.2 ZIP-এর তুলনায়)')
w('**নতুন (%d):**' % len(added)); [w('- `%s`' % a) for a in added]
w('**পরিবর্তিত (%d):**' % len(modified)); [w('- `%s`' % a) for a in modified]
w('**অপসারিত (%d):**' % len(removed)); [w('- `%s`' % a) for a in removed]
w('')
w('অ্যাপের বাইরে: `tools/gen_demo.py`, `tools/gen_report.py`, `.github/workflows/android-build.yml` (Test-ধাপ যোগ), `README_BN.md`, `BUILD_VERIFICATION_REPORT.md`; `backend/` **অপরিবর্তিত**।')
w('')
w('## ১৬. GitHub Actions সামঞ্জস্য')
w('Java 17, AGP 8.5.2, Kotlin 2.0.20, Compose BOM 2024.09.00 (অপরিবর্তিত)। নতুন নির্ভরতা শুধু `testImplementation` (JUnit 4.13.2, org.json 20231013) — APK-এর আকার বা Runtime-এ প্রভাব নেই। ডেমো-ডেটা `assets/`-এ। কোনো গোপন কী/পাসওয়ার্ড রাখা হয়নি।')
open(os.path.join(ROOT, 'FRONTEND_REPORT_BN.md'), 'w', encoding='utf-8').write('\n'.join(out) + '\n')
print('report written; added', len(added), 'modified', len(modified), 'removed', len(removed), 'screens', len(set(screens)), 'components', len(set(comps)), 'tests', n_tests)
