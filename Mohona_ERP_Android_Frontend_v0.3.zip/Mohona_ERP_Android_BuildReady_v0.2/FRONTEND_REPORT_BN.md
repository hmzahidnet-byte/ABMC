# মোহনা ERP — Frontend v0.3 প্রতিবেদন (সংখ্যাগুলো সোর্স ও ডেমো-ডেটা থেকে স্ক্রিপ্টে মাপা)

> **Build ফল: UNVERIFIED।** এই পরিবেশে Android SDK/Gradle/Kotlin-কম্পাইলার নেই; Kotlin কোড কখনো কম্পাইল বা চালানো হয়নি। নিচে “পরীক্ষিত” মানে শুধু Python-এ চালানো যাচাই (ডেমো-ডেটা, গাণিতিক হিসাব, মিরর-পরীক্ষা)। JVM Unit Test **লেখা আছে, চালানো হয়নি**। কোনো APK দেওয়া হয়নি।

## ১. সোর্স-পরিবর্তনের সারসংক্ষেপ (v0.2 ZIP-এর তুলনায়, শুধু `app/`)
- **Kotlin মূল ফাইল:** 33 টি, ৪৭৯০ লাইন; **JVM Test ফাইল:** 2 টি (22 টি `@Test`); **ডেমো-ডেটা:** `assets/demo/demo_data.json` (171 রেকর্ড)।
- নতুন 21, পরিবর্তিত 7, অপসারিত 8 (অপসারিতগুলো নতুন কাঠামোয় প্রতিস্থাপিত)।
- **অপসারিত (সচেতনভাবে):** পুরোনো গ্লোবাল Dashboard (KPI/চার্ট — নতুন Home-নিয়মের বিরোধী), `ModuleScreens` (প্রতি-Feature নমুনা-তালিকা), পুরোনো `registry/*`, `SampleData` — সব এখন একটি সাধারণ Record-ইঞ্জিন ও ডেমো-Repository দিয়ে প্রতিস্থাপিত। Login, Theme, Charts, ⋮ মেনু, Session (প্রমাণীকরণ/অনুমতি আলাদা), QR-ইন্টারফেস, রোল-মডেল **সংরক্ষিত**।

## ২. স্ক্রিন-তালিকা (15)
| স্ক্রিন (Composable) | ফাইল |
| --- | --- |
| `ApprovalCenterScreen` | `ui/screens/SearchAndApprovalScreens.kt` |
| `ChairmanScreen` | `ui/screens/NotificationAndChairmanScreens.kt` |
| `GlobalHomeScreen` | `ui/screens/GlobalHomeScreen.kt` |
| `LoginScreen` | `ui/screens/LoginScreen.kt` |
| `ModuleDashboardScreen` | `ui/screens/ModuleDashboardScreen.kt` |
| `NotificationCenterScreen` | `ui/screens/NotificationAndChairmanScreens.kt` |
| `ProfileScreen` | `ui/screens/ProfileScreen.kt` |
| `QrPreviewScreen` | `ui/screens/QrScreens.kt` |
| `RecordDashboardScreen` | `ui/screens/RecordDashboardScreen.kt` |
| `RecordListScreen` | `ui/screens/RecordListScreen.kt` |
| `ReportCenterScreen` | `ui/screens/ReportScreens.kt` |
| `ReportPreviewScreen` | `ui/screens/ReportScreens.kt` |
| `ScannerScreen` | `ui/screens/QrScreens.kt` |
| `SearchScreen` | `ui/screens/SearchAndApprovalScreens.kt` |
| `WingDashboardScreen` | `ui/screens/WingDashboardScreen.kt` |

## ৩. Navigation-মানচিত্র
| Route | প্যাটার্ন |
| --- | --- |
| `LOGIN` | `login` |
| `HOME` | `home` |
| `SEARCH` | `search` |
| `SCAN` | `scan` |
| `REPORTS` | `reports` |
| `PROFILE` | `profile` |
| `NOTIFICATIONS` | `notifications` |
| `APPROVALS` | `approvals` |
| `CHAIRMAN` | `chairman` |
| `WING_PATTERN` | `wing/{wingId}` |
| `MODULE_PATTERN` | `module/{wingId}/{moduleId}` |
| `LIST_PATTERN` | `list/{typeCode}` |
| `RECORD_PATTERN` | `record/{typeCode}/{id}` |
| `REPORT_PATTERN` | `report/{reportId}` |
| `QR_PATTERN` | `qr/{token}` |

স্তর: ১ গ্লোবাল Home (`home`) → ২ Wing (`wing/{id}`) → ৩ Module (`module/{wing}/{module}`) → ৪ তালিকা (`list/{type}`) → ৫–৭ **একটিই** Record Dashboard (`record/{type}/{id}`), যেখান থেকে সংযুক্ত রেকর্ড আবার একই পর্দায় খোলে। বাইরের প্রবেশপথ: অনুসন্ধান, বিজ্ঞপ্তি, QR (`qr/{token}`), রিপোর্ট-সারি, অনুমোদন-কেন্দ্র — সবাই একই Route ব্যবহার করে। কোম্পানি-প্রসঙ্গ Session-এ থাকে।

## ৪. পুনর্ব্যবহারযোগ্য Component (48)
`AppCard`, `BarChart`, `ChartCard`, `ColumnSpacer`, `Dialogs`, `DonutChart`, `DueCollectionOverview`, `EllipsisText`, `EmptyState`, `ErrorState`, `FilterChips`, `GrayBackground`, `Hairline`, `ImageHolder`, `InfoRows`, `KeyValueRow`, `KpiCard`, `KpiRow`, `LineChart`, `LineItemsSection`, `LoadingState`, `MohonaLogo`, `PermissionDeniedState`, `PreviewBadge`, `PreviewBanner`, `PrimaryActionRow`, `ProductSalesChart`, `ProductionComparisonChart`, `QrDemoImage`, `RatioBar`, `RecordCard`, `RecordMenu`, `RelatedGroupsSection`, `RelatedTile`, `SalesTrendChart`, `ScreenHeader`, `SearchField`, `SectionCard`, `SectionTitle`, `StatusBadge`, `StatusPill`, `StockSummaryChart`, `SummaryCard`, `TimelineView`, `UniversalActionMenu`, `UniversalCalendar`, `rememberActionController`, `rememberRecordActions`

## ৫. Entity Dashboard Coverage (ডেমো-ডেটায় মাপা; সবাই একই Record-ইঞ্জিনে)
| ধরন | শ্রেণি | রেকর্ড | সংযুক্ত রেকর্ড আছে | ইতিহাস আছে | KPI আছে | QR আছে |
| --- | --- | --- | --- | --- | --- | --- |
| EMPLOYEE | ENTITY | 7 | 3/7 | 7/7 | 7/7 | 7/7 |
| SUPPLIER | ENTITY | 4 | 4/4 | 3/4 | 3/4 | 0/4 |
| RAW_MATERIAL | ENTITY | 4 | 4/4 | 0/4 | 4/4 | 0/4 |
| WAREHOUSE | ENTITY | 2 | 2/2 | 0/2 | 2/2 | 0/2 |
| PRODUCT | ENTITY | 7 | 2/7 | 6/7 | 6/7 | 7/7 |
| PURCHASE_ORDER | TRANSACTION | 8 | 8/8 | 7/8 | 7/8 | 0/8 |
| BOM | ENTITY | 3 | 3/3 | 3/3 | 3/3 | 0/3 |
| GRN | TRANSACTION | 5 | 5/5 | 5/5 | 5/5 | 0/5 |
| SUPPLIER_LEDGER | EVENT | 10 | 10/10 | 0/10 | 10/10 | 0/10 |
| PAYMENT_VOUCHER | TRANSACTION | 5 | 5/5 | 5/5 | 5/5 | 0/5 |
| STOCK_MOVEMENT | EVENT | 33 | 33/33 | 33/33 | 33/33 | 0/33 |
| BATCH | TRANSACTION | 4 | 4/4 | 4/4 | 4/4 | 4/4 |
| MATERIAL_ISSUE | TRANSACTION | 4 | 4/4 | 4/4 | 4/4 | 0/4 |
| CONSUMPTION | TRANSACTION | 4 | 4/4 | 4/4 | 4/4 | 0/4 |
| BATCH_COST | EVENT | 3 | 3/3 | 3/3 | 3/3 | 0/3 |
| QC_RECORD | TRANSACTION | 3 | 3/3 | 3/3 | 3/3 | 0/3 |
| FG_RECEIPT | TRANSACTION | 2 | 2/2 | 2/2 | 2/2 | 0/2 |
| ATTENDANCE_MONTH | ENTITY | 3 | 3/3 | 0/3 | 3/3 | 0/3 |
| ATTENDANCE_DAY | EVENT | 15 | 15/15 | 0/15 | 15/15 | 0/15 |
| ATTENDANCE_EVENT | EVENT | 28 | 28/28 | 0/28 | 0/28 | 0/28 |
| PAYROLL_MONTH | TRANSACTION | 3 | 3/3 | 3/3 | 3/3 | 0/3 |
| PAYSLIP | TRANSACTION | 3 | 3/3 | 3/3 | 3/3 | 0/3 |
| MACHINE | ENTITY | 3 | 2/3 | 3/3 | 0/3 | 0/3 |
| SPARE_PART | ENTITY | 2 | 1/2 | 0/2 | 0/2 | 0/2 |
| BREAKDOWN | EVENT | 1 | 1/1 | 1/1 | 1/1 | 0/1 |
| MAINTENANCE | TRANSACTION | 2 | 2/2 | 1/2 | 1/2 | 0/2 |
| EXPENSE | TRANSACTION | 2 | 1/2 | 2/2 | 2/2 | 0/2 |
| FACTORY_PNL | ENTITY | 1 | 0/1 | 0/1 | 0/1 | 0/1 |

## ৬. Transaction Detail Coverage
| ধরন | রেকর্ড | আইটেম-লাইন | মোট | অনুমোদন-টাইমলাইন | ইতিহাস | সংযুক্ত |
| --- | --- | --- | --- | --- | --- | --- |
| PURCHASE_ORDER | 8 | 7/8 | 7/8 | 6/8 | 7/8 | 8/8 |
| GRN | 5 | 5/5 | 5/5 | 0/5 | 5/5 | 5/5 |
| PAYMENT_VOUCHER | 5 | 5/5 | 5/5 | 5/5 | 5/5 | 5/5 |
| BATCH | 4 | 0/4 | 0/4 | 0/4 | 4/4 | 4/4 |
| MATERIAL_ISSUE | 4 | 4/4 | 0/4 | 4/4 | 4/4 | 4/4 |
| CONSUMPTION | 4 | 4/4 | 0/4 | 0/4 | 4/4 | 4/4 |
| QC_RECORD | 3 | 0/3 | 0/3 | 0/3 | 3/3 | 3/3 |
| FG_RECEIPT | 2 | 0/2 | 0/2 | 0/2 | 2/2 | 2/2 |
| PAYROLL_MONTH | 3 | 3/3 | 3/3 | 0/3 | 3/3 | 3/3 |
| PAYSLIP | 3 | 3/3 | 3/3 | 0/3 | 3/3 | 3/3 |
| MAINTENANCE | 2 | 0/2 | 0/2 | 0/2 | 1/2 | 2/2 |
| EXPENSE | 2 | 2/2 | 2/2 | 2/2 | 2/2 | 1/2 |

যেসব ক্ষেত্র একটি লেনদেনে প্রযোজ্য নয় (যেমন বেতন-খসড়ায় ইনভেন্টরি-চলাচল) সেগুলো বানানো হয়নি; “অনুমোদন-টাইমলাইন” খালি থাকলে পর্দায় সৎ “কোনো ধাপ নেই” দেখায়।

## ৭. Role-ভিত্তিক UI Coverage (UI-ইঙ্গিত; Appendix F-এর সিড থেকে; আসল নিয়ন্ত্রণ সার্ভারে)
| Role | উইং খোলে | মডিউল | খুলতে পারা রেকর্ড-ধরন | অনুমোদন-ইঙ্গিত | ফ্যাক্টরি P&L | সংবেদনশীল তথ্য |
| --- | --- | --- | --- | --- | --- | --- |
| CHAIRMAN | হ্যাঁ | 9/10 | 21/28 | হ্যাঁ | না | না |
| MD | হ্যাঁ | 10/10 | 25/28 | হ্যাঁ | হ্যাঁ | হ্যাঁ |
| WING_HEAD | হ্যাঁ | 10/10 | 27/28 | হ্যাঁ | না | হ্যাঁ |
| FIN_MANAGER | হ্যাঁ | 9/10 | 21/28 | হ্যাঁ | না | না |
| ACCOUNTANT | হ্যাঁ | 9/10 | 21/28 | না | না | না |
| CASHIER | হ্যাঁ | 9/10 | 19/28 | না | না | না |
| HR_OFFICER | হ্যাঁ | 1/10 | 6/28 | না | না | হ্যাঁ |
| STOREKEEPER | হ্যাঁ | 8/10 | 18/28 | না | না | না |
| PROD_SUPERVISOR | হ্যাঁ | 9/10 | 21/28 | না | না | না |
| QC_OFFICER | হ্যাঁ | 8/10 | 18/28 | না | না | না |
| PURCHASE_OFFICER | হ্যাঁ | 8/10 | 18/28 | না | না | না |
| SALES_MANAGER | না | 0/10 | 0/28 | না | না | না |
| FIELD_SALES | না | 0/10 | 0/28 | না | না | না |
| AUDITOR | হ্যাঁ | 9/10 | 21/28 | না | না | না |
| EMPLOYEE_SELF | হ্যাঁ | 1/10 | 4/28 | না | না | হ্যাঁ |
| EMERGENCY_ADMIN | না | 0/10 | 0/28 | না | না | না |
| TECH_ADMIN | না | 0/10 | 0/28 | না | না | না |

টীকা: `hr.payroll.view` অনুমোদিত ম্যাট্রিক্সে নেই, তাই বেতন-তথ্যের দৃশ্যমানতা **Pending-ইঙ্গিত**; `hr.attendance.view` ম্যাট্রিক্সে শুধু WING_HEAD, HR_OFFICER, PROD_SUPERVISOR (ও নিজ-কর্মী); **MD তালিকায় নেই**, তাই MD-কে উপস্থিতি-রেকর্ড খুলতে দেওয়া হয়নি — এটি ম্যাট্রিক্সের সম্ভাব্য বাদ পড়া; আপনার নিশ্চিতকরণ ছাড়া আমি অনুমতি যোগ করিনি।

## ৮. ডেমো-ডেটা সম্পর্ক
- মোট 171 রেকর্ড, 371 সংযোগ (দ্বিমুখী; অ-প্রতিসম বা ঝুলন্ত সংযোগ ০; কোম্পানি-মধ্যবর্তী সংযোগ ০)।
- ধরন-ভিত্তিক: EMPLOYEE 7, SUPPLIER 4, RAW_MATERIAL 4, WAREHOUSE 2, PRODUCT 7, PURCHASE_ORDER 8, BOM 3, GRN 5, SUPPLIER_LEDGER 10, PAYMENT_VOUCHER 5, STOCK_MOVEMENT 33, BATCH 4, MATERIAL_ISSUE 4, CONSUMPTION 4, BATCH_COST 3, QC_RECORD 3, FG_RECEIPT 2, ATTENDANCE_MONTH 3, ATTENDANCE_DAY 15, ATTENDANCE_EVENT 28, PAYROLL_MONTH 3, PAYSLIP 3, MACHINE 3, SPARE_PART 2, BREAKDOWN 1, MAINTENANCE 2, EXPENSE 2, FACTORY_PNL 1
- সব হিসাব `tools/gen_demo.py` থেকে (Moving Weighted Average, ইস্যু-খরচ, ব্যাচ-খরচ, সরবরাহকারী-বকেয়া); Kotlin `Costing` রানটাইমে একই গণনা করে এবং JVM Test দুটি ফল মেলায়।
- রাউন্ডিং (মূল্য ২ দশমিক, একক-খরচ ৪ দশমিক) **ডেমো-পছন্দ, অনুমোদিত নীতি নয়**।
- ডেমো-গণনা-ফল: {"B-001": "160.56", "B-002": "158.10", "B-003": null, "B-004": null} (টাকা প্রতি Poly, শুধু উপাদান-খরচ, আংশিক); সরবরাহকারী-বকেয়া {"SUP-001": "521000.00", "SUP-003": "240000.00", "SUP-002": "0.00"}

## ৯. সাতটি Journey: অবস্থা
| Journey | সংযোগ ডেটায় আছে | Python-মিরর পরীক্ষা | JVM Test | ডিভাইসে চালানো |
| --- | --- | --- | --- | --- |
| A ক্রয় → উৎপাদন → খরচ/Poly | হ্যাঁ | পাস | লেখা, **চালানো হয়নি** | **UNVERIFIED** |
| B কর্মী → উপস্থিতি → মাস → দিন → ইভেন্ট; বেতন → পে-স্লিপ | হ্যাঁ | পাস | লেখা, **চালানো হয়নি** | **UNVERIFIED** |
| C লেনদেন → পক্ষ → খতিয়ান → ভাউচার → অনুমোদন-ইতিহাস → মূল লেনদেন | হ্যাঁ | পাস | লেখা, **চালানো হয়নি** | **UNVERIFIED** |
| D মেশিন → রক্ষণাবেক্ষণ → ব্রেকডাউন → পার্ট → ব্যয় | হ্যাঁ | পাস | লেখা, **চালানো হয়নি** | **UNVERIFIED** |
| E গুদাম → উপাদান-স্টক → চলাচল → উৎস-নথি → ব্যাচ | হ্যাঁ | পাস | লেখা, **চালানো হয়নি** | **UNVERIFIED** |
| F QR → প্রিভিউ → অনুমোদিত বিবরণ → ইতিহাস | হ্যাঁ | পাস | লেখা, **চালানো হয়নি** | **UNVERIFIED** |
| G ব্যবস্থাপনা → ড্যাশবোর্ড → অপেক্ষমাণ অনুমোদন → লেনদেন → কাজ (সিমুলেটেড) → ইতিহাস | হ্যাঁ | পাস | লেখা, **চালানো হয়নি** | **UNVERIFIED** |

## ১০. বাস্তবায়ন-অবস্থা
**Implemented (কোড লেখা; কম্পাইল-যাচাই নেই):** গ্লোবাল Home (শুধু অনুমোদিত উইং-কার্ড, কোম্পানি-নির্বাচক, অনুসন্ধান/বিজ্ঞপ্তি/প্রোফাইল); Manufacturing Wing Dashboard (তারিখ-ফিল্টার + Universal Calendar, পণ্য-ছবি-KPI প্রথম ৬টি + “সব পণ্য দেখুন”, সারাংশ-টাইল, ডেমো-ডেটা-চালিত চার্ট, সতর্কতা/অনুমোদন, মডিউল-গ্রিড); মডিউল-ড্যাশবোর্ড; সাধারণ তালিকা (অনুসন্ধান, স্ট্যাটাস-ফিল্টার, তারিখ-ফিল্টার); **সার্বজনীন Record Dashboard** (সব ধরন); **Transaction Detail** (লাইন, মোট, অনুমোদন, ইতিহাস, সংশোধন-সূত্র); প্রসঙ্গ-ভিত্তিক ⋮ মেনু (অবস্থা+ভূমিকা+কোম্পানি-নির্ভর); সিমুলেটেড অনুমোদন/ফেরত/প্রত্যাখ্যান/জমা/বাতিল (Maker-Checker সহ); অনুমোদন-কেন্দ্র; অনুসন্ধান; বিজ্ঞপ্তি (রেকর্ড-লিংক); QR-প্রিভিউ (অনুমতি-যাচাইসহ); রিপোর্ট-কেন্দ্র (১৩টি ডেমো-রিপোর্ট, সারি-ক্লিক); চেয়ারম্যান-মডিউল (Pending-ভিত্তিক); Role-ভিত্তিক দৃশ্যমানতা; Moving Weighted Average (ডেমো) ও Material Cost per Poly (আংশিক, লেবেলসহ); অনুপস্থিত/অবৈধ রেকর্ড, কোম্পানি-ভুল ও অনুমতি-নেই অবস্থা।

**Partial:** Payslip-এর “কর্তন-বিবরণ” আলাদা পর্দা নয় (পে-স্লিপের লাইনে); BOM-সম্পাদনা ও নতুন-রেকর্ড ফর্ম নেই (সম্পাদনা-বোতাম নিষ্ক্রিয়); Product Poly-রূপান্তর Pending (কোনো মান ধরে নেওয়া হয়নি); পণ্য-ছবি শুধু প্লেসহোল্ডার; Calendar-এর কার্যক্রম-চিহ্ন এখন উৎপাদন/রেকর্ড-তারিখ-ভিত্তিক; Dealer/Retailer/Invoice নেই; Offline/Loading অবস্থা-Component আছে, কিন্তু ডেমো-ডেটা তাৎক্ষণিক বলে Loading বাস্তবে দেখা যায় না।

**Not implemented:** Dealer, Retailer, Sales Invoice, Collection (নিশ্চিত Sales-উইং নেই); ক্রয়-ইনভয়েস ও ক্রয়-ফেরত; Production Plan; অপচয়-বিশ্লেষণ; ফিজিক্যাল স্টক যাচাই; Market-return repackaging; স্টক-স্থানান্তর/সমন্বয়; ছুটি, শিফট-রোস্টার, অগ্রিম/ঋণ, পদোন্নতি/বদলি ফর্ম; স্পেয়ার পার্টস ক্রয়; কস্ট-সেন্টার; PDF/PNG/WhatsApp/Email/A4/POS রপ্তানি ও প্রিন্ট (সব নিষ্ক্রিয়/“পরিকল্পিত”); ক্যামেরা-QR-স্ক্যানার; আসল QR-তৈরি; Supabase-সংযোগ (Preview-মোডে ব্যবসায়িক পর্দা শুধু ডেমো); Hilt (Build প্রমাণের আগে স্থগিত); Compose UI-Test।

## ১১. জানা সমস্যা ও ঝুঁকি
- **Kotlin কখনো কম্পাইল হয়নি।** নতুন/পরিবর্তিত Kotlin ফাইলে মোট 3883 লাইন (মাপা); কম্পাইল-ত্রুটি থাকার সম্ভাবনা বাস্তব। প্রথম GitHub Actions রানে ত্রুটি এলে লগ পাঠান।
- JVM Test ও APK-নির্মাণ একই Workflow-এ; Test ব্যর্থ হলে APK ব্লক হয় না (`continue-on-error`), কিন্তু রিপোর্ট Artifact-এ থাকে।
- `Icons.Filled.KeyboardArrowLeft` ইত্যাদি কিছু Icon Deprecation-সতর্কতা দিতে পারে (ত্রুটি নয়)।
- JSON-ডেমো-ডেটা ~৩৩০ KB; পুরোটা শুরুতে একবার পার্স হয় (সামান্য বিলম্ব সম্ভব)।
- ডেমো-সিমুলেশন Session-ভিত্তিক; অ্যাপ বন্ধ করলে মুছে যায়, লগআউটে রিসেট।
- Preview-মোডে ভূমিকা বদলালে শুধু দৃশ্য বদলায় (UI-ইঙ্গিত) — এটি নিরাপত্তা নয়।
- আসল ব্যাকএন্ডের কোনো Migration/RPC এই কাজে ব্যবহৃত বা চালানো হয়নি।

## ১২. স্বয়ংক্রিয় পরীক্ষার ফল (সৎ বিভাজন)
| পরীক্ষা | অবস্থা |
| --- | --- |
| ডেমো-ডেটা জেনারেটর `tools/gen_demo.py`: সংযোগ-অখণ্ডতা, ক্রমিক-ঋণাত্মক-স্টক নেই, সরবরাহকারী-খতিয়ান = বকেয়া, স্থিতিশীল (দুইবার চালিয়ে একই হ্যাশ) | **চালানো, পাস** |
| Python-মিরর: JVM Test-এর সব প্রত্যাশা আসল JSON-এ (সংযোগ, Journey-লিংক, FG ১,৯৪৫/০, QC-হোল্ড, BOM-সংস্করণ, Poly Pending, VAT/CCTV অনুপস্থিতি, সংশোধন-সূত্র) | **চালানো, পাস** |
| স্ট্যাটিক: বন্ধনী-ভারসাম্য, প্রকল্প-Import, ডুপ্লিকেট নাম, Identifier/Import-সমাধান | **চালানো, পাস** (কম্পাইল নয়) |
| JVM Unit Test (`DemoGraphTest`, `RoutesTest`): 22 টি | **লেখা, চালানো হয়নি (UNVERIFIED)** |
| Compose UI/Instrumented Test | **লেখা হয়নি** |
| Android Build / APK / ফোনে চালানো | **UNVERIFIED** |

## ১৩. Android Build নির্দেশনা
GitHub: Repository-র বিদ্যমান Workflow “Android Debug APK” চালান (Actions → Run workflow); APK Artifact `mohona-erp-debug-apk`; Test-রিপোর্ট Artifact `unit-test-reports`। Android Studio: Open → Sync → Build → Build APK(s)। কমান্ড: `./gradlew assembleDebug testDebugUnitTest` (Wrapper-jar না থাকলে README_BN-এর বিকল্প)।

## ১৪. ভবিষ্যৎ Supabase-সংযোগ-মানচিত্র (পরিকল্পনা; এখন কিছুই সংযুক্ত নয়)
| রেকর্ড-ধরন | ভবিষ্যৎ উৎস (প্রস্তাবিত) | মন্তব্য |
| --- | --- | --- |
| PRODUCT / RAW_MATERIAL / SUPPLIER | `mfg.products`, `inv.items`, `core.parties` + Storage (ছবি) | প্রতিটি `organization_id` + Composite FK; ছবি Private Bucket + Signed URL |
| PURCHASE_ORDER / GRN / MATERIAL_ISSUE / CONSUMPTION | First-Slice S3–S9 RPC | Maker-Checker সার্ভারে; Idempotency-Key |
| STOCK_MOVEMENT / WAREHOUSE | `inv.stock_movements` (Append-only) | MWAC সার্ভারে; ঋণাত্মক-স্টক-নীতি Pending |
| BATCH / BOM / QC / FG | S6–S12 | অপরিবর্তনীয় BOM-সংস্করণ; QC-মুক্ত না হলে মজুত উপলব্ধ নয় |
| BATCH_COST | S13 | শুধু উপাদান-খরচ; পূর্ণ খরচ নীতি-সাপেক্ষ |
| PAYMENT_VOUCHER / EXPENSE / SUPPLIER_LEDGER | Finance Ledger | Reversal+Replacement; GRNI-নীতি Pending |
| EMPLOYEE / ATTENDANCE / PAYROLL | HR-মডিউল | কর্মী-প্রোফাইল ও লগইন আলাদা; পেরোল-অনুমতি নীতি Pending |
| MACHINE / MAINTENANCE | Maintenance-মডিউল | — |
| QR | `api.v1_qr_resolve` | টোকেন ≠ আইডি; সার্ভার অনুমতি-যাচাই |
| Auth/Session | বিদ্যমান `AuthRepository` (OD-02) | অপরিবর্তিত |

## ১৫. সঠিক ফাইল-তালিকা (v0.2 ZIP-এর তুলনায়)
**নতুন (21):**
- `app/src/main/assets/demo/demo_data.json`
- `app/src/main/java/com/mohona/erp/data/demo/DemoRepository.kt`
- `app/src/main/java/com/mohona/erp/domain/Access.kt`
- `app/src/main/java/com/mohona/erp/domain/Costing.kt`
- `app/src/main/java/com/mohona/erp/domain/RecordModel.kt`
- `app/src/main/java/com/mohona/erp/domain/WingRegistry.kt`
- `app/src/main/java/com/mohona/erp/ui/components/BnDate.kt`
- `app/src/main/java/com/mohona/erp/ui/components/IconKeys.kt`
- `app/src/main/java/com/mohona/erp/ui/components/RecordComponents.kt`
- `app/src/main/java/com/mohona/erp/ui/components/UniversalCalendar.kt`
- `app/src/main/java/com/mohona/erp/ui/screens/GlobalHomeScreen.kt`
- `app/src/main/java/com/mohona/erp/ui/screens/ModuleDashboardScreen.kt`
- `app/src/main/java/com/mohona/erp/ui/screens/NotificationAndChairmanScreens.kt`
- `app/src/main/java/com/mohona/erp/ui/screens/ProfileScreen.kt`
- `app/src/main/java/com/mohona/erp/ui/screens/RecordDashboardScreen.kt`
- `app/src/main/java/com/mohona/erp/ui/screens/RecordListScreen.kt`
- `app/src/main/java/com/mohona/erp/ui/screens/ReportScreens.kt`
- `app/src/main/java/com/mohona/erp/ui/screens/SearchAndApprovalScreens.kt`
- `app/src/main/java/com/mohona/erp/ui/screens/WingDashboardScreen.kt`
- `app/src/test/java/com/mohona/erp/DemoGraphTest.kt`
- `app/src/test/java/com/mohona/erp/RoutesTest.kt`
**পরিবর্তিত (7):**
- `app/build.gradle.kts`
- `app/src/main/java/com/mohona/erp/MainActivity.kt`
- `app/src/main/java/com/mohona/erp/data/Roles.kt`
- `app/src/main/java/com/mohona/erp/data/SessionViewModel.kt`
- `app/src/main/java/com/mohona/erp/ui/components/Common.kt`
- `app/src/main/java/com/mohona/erp/ui/navigation/AppNavigation.kt`
- `app/src/main/java/com/mohona/erp/ui/screens/QrScreens.kt`
**অপসারিত (8):**
- `app/src/main/java/com/mohona/erp/data/SampleData.kt`
- `app/src/main/java/com/mohona/erp/registry/CoreModules.kt`
- `app/src/main/java/com/mohona/erp/registry/ManufacturingWing.kt`
- `app/src/main/java/com/mohona/erp/registry/Registry.kt`
- `app/src/main/java/com/mohona/erp/registry/ReportWidgets.kt`
- `app/src/main/java/com/mohona/erp/ui/screens/DashboardScreen.kt`
- `app/src/main/java/com/mohona/erp/ui/screens/ModuleScreens.kt`
- `app/src/main/java/com/mohona/erp/ui/screens/ReportsAndProfile.kt`

অ্যাপের বাইরে: `tools/gen_demo.py`, `tools/gen_report.py`, `.github/workflows/android-build.yml` (Test-ধাপ যোগ), `README_BN.md`, `BUILD_VERIFICATION_REPORT.md`; `backend/` **অপরিবর্তিত**।

## ১৬. GitHub Actions সামঞ্জস্য
Java 17, AGP 8.5.2, Kotlin 2.0.20, Compose BOM 2024.09.00 (অপরিবর্তিত)। নতুন নির্ভরতা শুধু `testImplementation` (JUnit 4.13.2, org.json 20231013) — APK-এর আকার বা Runtime-এ প্রভাব নেই। ডেমো-ডেটা `assets/`-এ। কোনো গোপন কী/পাসওয়ার্ড রাখা হয়নি।
