package com.abm.erp.ui.courier

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import kotlinx.coroutines.launch

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.abm.erp.core.GlassCard
import com.abm.erp.core.SubModuleGrid
import com.abm.erp.core.SubModuleItem
import com.abm.erp.core.BackToSubMenuLink
import com.abm.erp.data.MockRepository
import com.abm.erp.data.ShipmentStatus
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.ElectricCyan
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

/** v113-167 — Chairman-only: courier API base URL/key config, previously an
 * inline gate inside CourierScreen's "book" tab (correctly hidden from
 * non-Chairman already, but scattered rather than living in DMS's own
 * Chairman panel). Same dialog, same repository call, new home. */
@Composable
fun CourierApiConfigPanel() {
    val couriers by MockRepository.couriers.collectAsState()
    var configuringCourierId by remember { mutableStateOf<String?>(null) }
    // v113-250 — the real, previously-missing gap: there was no way to
    // add a new courier at all. Chairman-only, matching the permission
    // check inside addCourierPartner itself.
    var showAddCourier by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Courier API Config", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        Text(
            "Pathao / RedX / Steadfast — real credential দিলে real order তৈরি হবে (booking-এর সময়)। এখনো webhook সম্ভব না (এটা mobile app, public server না) — তাই delivery status update করতে হবে হাতে বা refresh করে।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(10.dp))
        Button(onClick = { showAddCourier = true }, modifier = Modifier.fillMaxWidth()) { Text("+ নতুন Courier যোগ করুন") }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(couriers, key = { it.id }) { c ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.name, color = TextPrimary)
                            Text(
                                if (c.hasApi) "Real API সংযুক্ত (${c.courierType})" else "Manual (no API)",
                                color = if (c.hasApi) SuccessGreen else TextSecondary, style = MaterialTheme.typography.labelSmall,
                            )
                        }
                        TextButton(onClick = { configuringCourierId = c.id }) { Text("API…") }
                    }
                }
            }
        }
    }

    configuringCourierId?.let { cid ->
        val courier = couriers.firstOrNull { it.id == cid }
        if (courier != null) {
            androidx.compose.ui.window.Dialog(onDismissRequest = { configuringCourierId = null }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                    var courierType by remember { mutableStateOf(courier.courierType) }
                    var typeMenuOpen by remember { mutableStateOf(false) }
                    var baseUrl by remember { mutableStateOf(courier.apiBaseUrl ?: "") }
                    var apiKey by remember { mutableStateOf(courier.apiKey ?: "") }
                    var apiSecretKey by remember { mutableStateOf(courier.apiSecretKey ?: "") }
                    var apiUsername by remember { mutableStateOf(courier.apiUsername ?: "") }
                    var apiPassword by remember { mutableStateOf(courier.apiPassword ?: "") }
                    var apiStoreId by remember { mutableStateOf(courier.apiStoreId ?: "") }
                    var cfgError by remember { mutableStateOf<String?>(null) }
                    // v113-249 — the person's own direct confirmation:
                    // they're a real merchant at Pathao/RedX/Steadfast and
                    // want the pasted key to actually call the real API.
                    // Each courier's real auth shape is genuinely
                    // different (confirmed directly against each one's
                    // own documentation before writing this) — so the
                    // fields shown change with the selected type, rather
                    // than one generic base-url/key pair pretending to
                    // cover all three.
                    Column(Modifier.padding(16.dp).heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                        Text("${courier.name} — API Config", fontWeight = FontWeight.Bold, color = TextPrimary)
                        cfgError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                        Spacer(Modifier.height(10.dp))
                        Box {
                            OutlinedButton(onClick = { typeMenuOpen = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("Courier Type: $courierType")
                            }
                            DropdownMenu(expanded = typeMenuOpen, onDismissRequest = { typeMenuOpen = false }) {
                                listOf("PATHAO", "REDX", "STEADFAST", "OTHER").forEach { t ->
                                    DropdownMenuItem(text = { Text(t) }, onClick = { courierType = t; typeMenuOpen = false })
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = baseUrl, onValueChange = { baseUrl = it },
                            label = { Text(if (courierType == "STEADFAST") "API Base URL (ফাঁকা রাখলে default ব্যবহার হবে)" else "API Base URL") },
                            singleLine = true, modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(8.dp))
                        when (courierType) {
                            "PATHAO" -> {
                                OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Client ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = apiSecretKey, onValueChange = { apiSecretKey = it }, label = { Text("Client Secret") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = apiUsername, onValueChange = { apiUsername = it }, label = { Text("Username (email)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = apiPassword, onValueChange = { apiPassword = it }, label = { Text("Password") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = apiStoreId, onValueChange = { apiStoreId = it }, label = { Text("Store ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "city_id/zone_id/area_id booking-এর সময় ম্যানুয়ালি দিতে হবে — এই app-এর নিজস্ব location আর Pathao-এর নিজস্ব code এখনো সংযুক্ত না।",
                                    style = MaterialTheme.typography.labelSmall, color = WarningAmber,
                                )
                            }
                            "REDX" -> {
                                OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Access Token") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = apiStoreId, onValueChange = { apiStoreId = it }, label = { Text("Pickup Store ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "delivery_area_id booking-এর সময় ম্যানুয়ালি দিতে হবে — এই app-এর নিজস্ব location আর RedX-এর নিজস্ব code এখনো সংযুক্ত না।",
                                    style = MaterialTheme.typography.labelSmall, color = WarningAmber,
                                )
                            }
                            "STEADFAST" -> {
                                OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Api-Key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = apiSecretKey, onValueChange = { apiSecretKey = it }, label = { Text("Secret-Key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(6.dp))
                                Text("ঠিকানা লিখলেই যথেষ্ট — কোনো area code লাগে না।", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                            }
                            else -> {
                                OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("API Key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(6.dp))
                                Text("এই courier type-এর জন্য real API call করা এখনো লেখা হয়নি — শুধু হাতে status আপডেট করা যাবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    cfgError = null
                                    val ok = MockRepository.setCourierApiConfig(
                                        cid, baseUrl, apiKey, onRejected = { r -> cfgError = r },
                                        courierType = courierType, apiSecretKey = apiSecretKey, apiUsername = apiUsername, apiPassword = apiPassword, apiStoreId = apiStoreId,
                                    )
                                    if (ok) configuringCourierId = null
                                },
                                modifier = Modifier.weight(1f),
                            ) { Text("সংরক্ষণ") }
                            OutlinedButton(
                                onClick = {
                                    cfgError = null
                                    val ok = MockRepository.setCourierApiConfig(cid, null, null, onRejected = { r -> cfgError = r })
                                    if (ok) configuringCourierId = null
                                },
                                modifier = Modifier.weight(1f),
                            ) { Text("মুছুন") }
                        }
                    }
                }
            }
        }
    }

    if (showAddCourier) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showAddCourier = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var newName by remember { mutableStateOf("") }
                var newType by remember { mutableStateOf("STEADFAST") }
                var newTypeMenuOpen by remember { mutableStateOf(false) }
                var addError by remember { mutableStateOf<String?>(null) }
                Column(Modifier.padding(16.dp)) {
                    Text("নতুন Courier", fontWeight = FontWeight.Bold, color = TextPrimary)
                    addError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("নাম (যেমন: Steadfast)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Box {
                        OutlinedButton(onClick = { newTypeMenuOpen = true }, modifier = Modifier.fillMaxWidth()) { Text("Type: $newType") }
                        DropdownMenu(expanded = newTypeMenuOpen, onDismissRequest = { newTypeMenuOpen = false }) {
                            listOf("PATHAO", "REDX", "STEADFAST", "OTHER").forEach { t ->
                                DropdownMenuItem(text = { Text(t) }, onClick = { newType = t; newTypeMenuOpen = false })
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            addError = null
                            val ok = MockRepository.addCourierPartner(newName, newType, onRejected = { r -> addError = r })
                            if (ok) { showAddCourier = false }
                        },
                        enabled = newName.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("যোগ করুন") }
                }
            }
        }
    }
}

class CourierViewModel : ViewModel() {
    val couriers = MockRepository.couriers
    val shipments = MockRepository.shipments
    fun bookShipment(
        courierId: String = "", dealerOrRetailer: String, invoiceId: String? = null, invoiceNo: String? = null,
        vehicleId: String? = null, deliveryAddress: String = "", weightKg: Double? = null, condition: String? = null,
        recipientPhone: String = "", codAmount: Double = 0.0,
        pathaoCityId: String? = null, pathaoZoneId: String? = null, pathaoAreaId: String? = null, redxDeliveryAreaId: String? = null,
        onResult: (success: Boolean, message: String?) -> Unit = { _, _ -> },
    ) = MockRepository.bookShipment(
        courierId, dealerOrRetailer, invoiceId, invoiceNo, vehicleId, deliveryAddress, weightKg, condition,
        recipientPhone, codAmount, pathaoCityId, pathaoZoneId, pathaoAreaId, redxDeliveryAreaId, onResult,
    )
    fun advanceShipmentStage(id: String, onRejected: (String) -> Unit = {}) = MockRepository.advanceShipmentStageManually(id, onRejected)
    fun setShipmentStatus(id: String, status: ShipmentStatus) = MockRepository.setShipmentStatus(id, status)

    // ---- Module 13: Vehicle Tracking ----
    val vehicles = MockRepository.vehicles
    val vehicleLocationPings = MockRepository.vehicleLocationPings
    fun createVehicle(registrationNo: String, vehicleType: String, driverName: String, driverPhone: String, onRejected: (String) -> Unit = {}) =
        MockRepository.createVehicle(registrationNo, vehicleType, driverName, driverPhone, onRejected)
    fun recordVehiclePing(vehicleId: String, lat: Double, lng: Double, speedKmh: Double) =
        MockRepository.recordVehiclePing(vehicleId, lat, lng, speedKmh)
    fun latestPingFor(vehicleId: String) = MockRepository.latestPingFor(vehicleId)
    fun canCreateVehicle() = com.abm.erp.data.PermissionManager.canCurrentUser("courier", com.abm.erp.data.PermissionAction.CREATE)
}

@Composable
fun CourierScreen(vm: CourierViewModel = viewModel()) {
    val couriers by vm.couriers.collectAsState()
    val shipments by vm.shipments.collectAsState()
    var dealerText by remember { mutableStateOf("") }
    var selectedCourier by remember { mutableStateOf<String?>(null) }
    // v113-249 — the person's own direct instruction to bring the manual
    // booking form up to the same real level as the auto-booking-from-
    // invoice flow: vehicle option, real address, weight, condition —
    // all previously missing here even though they'd already been built
    // for the invoice-creation path.
    val allVehicles by MockRepository.vehicles.collectAsState()
    var selectedVehicleForBooking by remember { mutableStateOf<String?>(null) }
    val allDealersForBooking by MockRepository.dealers.collectAsState()
    var deliveryAddressText by remember { mutableStateOf("") }
    var weightText by remember { mutableStateOf("") }
    var conditionText by remember { mutableStateOf("") }
    // v113-249 — real API call needs these; recipientPhone/codAmount for
    // all three courier types, the area-code fields only for Pathao/RedX
    // specifically (Steadfast needs none of them — plain address text is
    // enough).
    var recipientPhoneText by remember { mutableStateOf("") }
    var codAmountText by remember { mutableStateOf("") }
    var pathaoCityId by remember { mutableStateOf<String?>(null) }
    var pathaoCityName by remember { mutableStateOf<String?>(null) }
    var pathaoZoneId by remember { mutableStateOf<String?>(null) }
    var pathaoZoneName by remember { mutableStateOf<String?>(null) }
    var pathaoAreaId by remember { mutableStateOf<String?>(null) }
    var pathaoAreaName by remember { mutableStateOf<String?>(null) }
    var redxAreaId by remember { mutableStateOf<String?>(null) }
    var redxAreaName by remember { mutableStateOf<String?>(null) }
    var showLocationPicker by remember { mutableStateOf(false) }
    var bookingResultMsg by remember { mutableStateOf<String?>(null) }
    // v113-249 — the person's own direct, confirmed complaint: how a
    // courier booking connects to the invoice it's delivering was never
    // clear, because it never actually did — Shipment had no invoice
    // reference at all, only this same free-text name. Optional search-
    // and-pick, since not every shipment is invoice-related (some are
    // just a name-addressed parcel).
    val allInvoices by MockRepository.salesInvoices.collectAsState()
    var invoiceQuery by remember { mutableStateOf("") }
    var selectedInvoiceId by remember { mutableStateOf<String?>(null) }
    val selectedInvoice = remember(allInvoices, selectedInvoiceId) { allInvoices.firstOrNull { it.id == selectedInvoiceId } }
    var statusMenuFor by remember { mutableStateOf<String?>(null) }
    // v113-256 — connects a shipment marked FAILED/RETURNED_TO_SENDER to
    // the real invoice-linked Return flow that actually reverses the
    // due-balance/stock effect — holds the shipment id whose "⚠ Return
    // তৈরি করুন" button was tapped, until the confirm dialog resolves it.
    var failedShipmentForReturn by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf<Int?>(null) }
    val subItems = listOf(
        SubModuleItem("book", "Book Shipment", "🚚", 0xFF4E9CFF, 0xFF2E6FE0, Icons.Filled.LocalShipping),
        SubModuleItem("track", "Track Shipments", "📍", 0xFF3DDC97, 0xFF1FA972, Icons.Filled.LocationOn),
        SubModuleItem("vehicle", "Vehicle Tracking", "🚛", 0xFF8A6DFF, 0xFF5B3FE0, Icons.Filled.AirportShuttle),
    )

    val inTransitCount = shipments.count { it.status == com.abm.erp.data.ShipmentStatus.IN_TRANSIT }
    val outForDeliveryCount = shipments.count { it.status == com.abm.erp.data.ShipmentStatus.OUT_FOR_DELIVERY }
    val deliveredCount = shipments.count { it.status == com.abm.erp.data.ShipmentStatus.DELIVERED }

    Column(Modifier.fillMaxSize()) {
        com.abm.erp.core.ModuleWorkspaceHeader("Courier & Logistics", "🚛", 0xFF8A6DFF, 0xFF5B3FE0, iconVector = Icons.Filled.LocalShipping, miniDashboard = {
            com.abm.erp.core.ModuleStat("Couriers", "${couriers.size}", TextPrimary)
            com.abm.erp.core.ModuleStat("In Transit", "$inTransitCount", if (inTransitCount > 0) WarningAmber else SuccessGreen)
            com.abm.erp.core.ModuleStat("Out for Delivery", "$outForDeliveryCount", TextPrimary)
            com.abm.erp.core.ModuleStat("Delivered", "$deliveredCount", SuccessGreen)
        }, quickActions = {
            AssistChip(onClick = { tab = 0 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.LocalShipping, null, Modifier.size(16.dp)) }, label = { Text("Book") })
            AssistChip(onClick = { tab = 1 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.LocationOn, null, Modifier.size(16.dp)) }, label = { Text("Track") })
            AssistChip(onClick = { tab = 2 }, leadingIcon = { androidx.compose.material3.Icon(Icons.Filled.LocalShipping, null, Modifier.size(16.dp)) }, label = { Text("Vehicles") })
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("Shipment", "Courier", "DeliveryChallan"))
        })
        Column(Modifier.fillMaxSize().padding(16.dp)) {
        if (tab == null) {
            SubModuleGrid(subItems) { key -> tab = when (key) { "book" -> 0; "track" -> 1; else -> 2 } }
        } else if (tab == 2) {
            BackToSubMenuLink(onClick = { tab = null })
            VehicleTrackingTab(vm)
        } else {
            BackToSubMenuLink(onClick = { tab = null })
            LazyColumn(Modifier.fillMaxWidth().weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (tab == 0) {
        item {
            Text("Courier partners", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            couriers.forEach { c ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.name, color = TextPrimary)
                        // v113-137 — was "API connected", which was untrue: no courier API is integrated in this build. Says what is actually configured instead.
                        Text(if (c.hasApi) "API config saved (integration not active)" else "Manual (no API)", color = if (c.hasApi) WarningAmber else TextSecondary, style = MaterialTheme.typography.labelSmall)
                    }
                        // v113-167 — API config moved to DMS → Chairman → Courier API
                        // Config, consolidated with every other Chairman-only DMS action.
                }
            }
        }

        item {
            Spacer(Modifier.height(6.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Book a new shipment", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = dealerText, onValueChange = { dealerText = it }, label = { Text("Dealer / retailer name") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                if (selectedInvoice != null) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text("Invoice: ${selectedInvoice.invoiceNo}", style = MaterialTheme.typography.labelMedium, color = com.abm.erp.theme.SuccessGreen)
                        TextButton(onClick = { selectedInvoiceId = null; invoiceQuery = "" }) { Text("বাতিল") }
                    }
                } else {
                    OutlinedTextField(
                        value = invoiceQuery, onValueChange = { invoiceQuery = it },
                        label = { Text("Invoice নম্বর দিয়ে খুঁজুন (ঐচ্ছিক)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    )
                    if (invoiceQuery.isNotBlank()) {
                        val matches = remember(allInvoices, invoiceQuery) {
                            allInvoices.filter { !it.isDeleted && it.invoiceNo.contains(invoiceQuery, ignoreCase = true) }.take(5)
                        }
                        matches.forEach { inv ->
                            Text(
                                "${inv.invoiceNo} — ${inv.dealerName} (৳${"%,.0f".format(inv.total)})",
                                style = MaterialTheme.typography.labelSmall, color = TextPrimary,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                    .clickable {
                                        selectedInvoiceId = inv.id; dealerText = inv.dealerName; invoiceQuery = ""
                                        deliveryAddressText = allDealersForBooking.firstOrNull { it.id == inv.dealerId }?.address ?: ""
                                    },
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = deliveryAddressText, onValueChange = { deliveryAddressText = it },
                    label = { Text("ডেলিভারি ঠিকানা") }, modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = weightText, onValueChange = { weightText = it.filter { c -> c.isDigit() || c == '.' } },
                        label = { Text("ওজন (kg)") }, singleLine = true, modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = conditionText, onValueChange = { conditionText = it },
                        label = { Text("Condition") }, singleLine = true, modifier = Modifier.weight(1f),
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = recipientPhoneText, onValueChange = { recipientPhoneText = it },
                        label = { Text("গ্রাহকের ফোন") }, singleLine = true, modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = codAmountText, onValueChange = { codAmountText = it.filter { c -> c.isDigit() || c == '.' } },
                        label = { Text("COD Amount") }, singleLine = true, modifier = Modifier.weight(1f),
                    )
                }
                val currentCourierType = couriers.firstOrNull { it.id == selectedCourier }?.courierType
                if (currentCourierType == "PATHAO" || currentCourierType == "REDX") {
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { showLocationPicker = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            when (currentCourierType) {
                                "PATHAO" -> pathaoAreaName?.let { "Pathao: $pathaoCityName, $pathaoZoneName, $it" } ?: "📍 Pathao City/Zone/Area বাছুন"
                                else -> redxAreaName?.let { "RedX Area: $it" } ?: "📍 RedX Delivery Area বাছুন"
                            },
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Box {
                    OutlinedButton(onClick = { statusMenuFor = "courier-picker" }, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            couriers.firstOrNull { it.id == selectedCourier }?.name
                                ?: allVehicles.firstOrNull { it.id == selectedVehicleForBooking }?.let { "নিজস্ব গাড়ি — ${it.registrationNo}" }
                                ?: "Choose courier / নিজস্ব গাড়ি…",
                        )
                    }
                    DropdownMenu(expanded = statusMenuFor == "courier-picker", onDismissRequest = { statusMenuFor = null }) {
                        if (couriers.isNotEmpty()) {
                            Text("Courier", style = MaterialTheme.typography.labelSmall, color = TextSecondary, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
                            couriers.forEach { c ->
                                DropdownMenuItem(text = { Text(c.name) }, onClick = { selectedCourier = c.id; selectedVehicleForBooking = null; statusMenuFor = null })
                            }
                        }
                        if (allVehicles.isNotEmpty()) {
                            Text("নিজস্ব গাড়ি", style = MaterialTheme.typography.labelSmall, color = TextSecondary, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
                            allVehicles.filter { it.isActive }.forEach { v ->
                                DropdownMenuItem(text = { Text("${v.registrationNo} — ${v.driverName.ifBlank { "চালক নেই" }}") }, onClick = { selectedVehicleForBooking = v.id; selectedCourier = null; statusMenuFor = null })
                            }
                        }
                    }
                }
                bookingResultMsg?.let { Spacer(Modifier.height(6.dp)); Text(it, style = MaterialTheme.typography.labelSmall, color = if (it.startsWith("✔")) SuccessGreen else DangerRed) }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        if (dealerText.isBlank()) return@Button
                        if (selectedCourier == null && selectedVehicleForBooking == null) return@Button
                        bookingResultMsg = null
                        vm.bookShipment(
                            courierId = selectedCourier ?: "", dealerOrRetailer = dealerText,
                            invoiceId = selectedInvoiceId, invoiceNo = selectedInvoice?.invoiceNo,
                            vehicleId = selectedVehicleForBooking, deliveryAddress = deliveryAddressText,
                            weightKg = weightText.toDoubleOrNull(), condition = conditionText.trim().ifBlank { null },
                            recipientPhone = recipientPhoneText, codAmount = codAmountText.toDoubleOrNull() ?: 0.0,
                            pathaoCityId = pathaoCityId, pathaoZoneId = pathaoZoneId,
                            pathaoAreaId = pathaoAreaId, redxDeliveryAreaId = redxAreaId,
                            onResult = { success, message ->
                                bookingResultMsg = if (success) "✔ Shipment বুক হয়েছে" + (message?.let { " — $it" } ?: "")
                                    else "✖ Local-এ save হয়েছে, কিন্তু real API call ব্যর্থ: $message"
                            },
                        )
                        dealerText = ""; selectedInvoiceId = null; invoiceQuery = ""; selectedVehicleForBooking = null
                        deliveryAddressText = ""; weightText = ""; conditionText = ""
                        recipientPhoneText = ""; codAmountText = ""
                        pathaoCityId = null; pathaoCityName = null; pathaoZoneId = null; pathaoZoneName = null; pathaoAreaId = null; pathaoAreaName = null; redxAreaId = null; redxAreaName = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Book shipment") }
            }
        }
        } else {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text("Shipments", style = MaterialTheme.typography.titleMedium)
                val context = androidx.compose.ui.platform.LocalContext.current
                com.abm.erp.core.ModuleActionBar(
                    onExport = {
                        val header = "DealerOrRetailer,Status\n"
                        val rows = shipments.joinToString("\n") { s -> com.abm.erp.core.toCsvRow(s.dealerOrRetailer, s.status) }
                        val file = java.io.File(context.getExternalFilesDir(null), "shipments_${System.currentTimeMillis()}.csv")
                        file.writeText(header + rows)
                        android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                    },
                    onShare = {
                        val summary = "Shipments (${shipments.size})\n" + shipments.take(20).joinToString("\n") { "${it.dealerOrRetailer} — ${it.status}" }
                        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                        try { context.startActivity(android.content.Intent.createChooser(intent, "Shipments")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                    },
                )
            }
        }
        items(shipments, key = { it.id }) { s ->
            val courier = couriers.firstOrNull { it.id == s.courierId }
            val vehicles by vm.vehicles.collectAsState()
            val vehicle = vehicles.firstOrNull { it.id == s.vehicleId }
            // v113-249 — the person's own direct follow-up: a shipment can
            // now be on the company's own vehicle instead of a third-
            // party courier — this label needs to say which, correctly,
            // rather than showing a blank courierId (empty-string
            // sentinel) when it's actually a vehicle delivery.
            val carrierLabel = courier?.name ?: vehicle?.let { "নিজস্ব গাড়ি — ${it.registrationNo}" } ?: s.courierId
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(s.dealerOrRetailer, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Row {
                        Text(s.status.name.replace("_", " "), color = if (s.status == ShipmentStatus.DELIVERED) SuccessGreen else ElectricCyan, style = MaterialTheme.typography.labelSmall)
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Shipment", entityId = s.id, entityLabel = s.dealerOrRetailer,
                            shareText = "Shipment: ${s.dealerOrRetailer}\nCarrier: $carrierLabel\nStatus: ${s.status}${s.trackingId?.let { "\nTracking: $it" } ?: ""}",
                            csvHeader = "DealerOrRetailer,Carrier,TrackingId,Status",
                            csvRow = com.abm.erp.core.toCsvRow(s.dealerOrRetailer, carrierLabel, s.trackingId ?: "", s.status),
                        )
                    }
                }
                Text("$carrierLabel${s.trackingId?.let { " · Internal ref: $it" } ?: ""}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                // v113-249 — the reverse direction of the same fix: this
                // list is where courier staff actually look to know which
                // invoice a shipment is for — the connection means
                // nothing if it only exists at booking time and never
                // shows up again afterward.
                s.invoiceNo?.let { Text("📄 Invoice: $it", style = MaterialTheme.typography.labelSmall, color = SuccessGreen) }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (courier?.hasApi == true) {
                    val stageContext = androidx.compose.ui.platform.LocalContext.current
                    Button(onClick = { vm.advanceShipmentStage(s.id, onRejected = { e -> android.widget.Toast.makeText(stageContext, e, android.widget.Toast.LENGTH_LONG).show() }) }) { Text("▶ Advance stage (manual)") }
                    // v113-256 — a real-API courier's shipment previously
                    // had NO way to be marked FAILED/RETURNED_TO_SENDER at
                    // all — only the fixed auto-advance sequence, which
                    // never includes a failure state. A live courier can
                    // genuinely fail a delivery same as a manual one.
                    OutlinedButton(onClick = { vm.setShipmentStatus(s.id, ShipmentStatus.FAILED) }) { Text("Mark Failed") }
                } else {
                    Box {
                        OutlinedButton(onClick = { statusMenuFor = s.id }) { Text("Update status") }
                        DropdownMenu(expanded = statusMenuFor == s.id, onDismissRequest = { statusMenuFor = null }) {
                            ShipmentStatus.values().forEach { st ->
                                DropdownMenuItem(text = { Text(st.name.replace("_", " ")) }, onClick = { vm.setShipmentStatus(s.id, st); statusMenuFor = null })
                            }
                        }
                    }
                }
                // v113-256 — the person's own direct question: what
                // happens when courier never receives it, delivery
                // fails, or it's lost — balance-adjustment-wise? Every
                // status update path above (including the API-connected
                // one, which previously had no manual status picker at
                // all) can now mark FAILED/RETURNED_TO_SENDER, and this
                // button — always available regardless of hasApi —
                // connects that failure directly to the real, already-
                // built invoice-linked Return flow, which is what
                // actually reverses the due-balance/stock/ledger effect.
                if (s.invoiceId != null && (s.status == ShipmentStatus.FAILED || s.status == ShipmentStatus.RETURNED_TO_SENDER)) {
                    Button(
                        onClick = { failedShipmentForReturn = s.id },
                        colors = ButtonDefaults.buttonColors(containerColor = com.abm.erp.theme.WarningAmber),
                    ) { Text("⚠ Return তৈরি করুন", color = androidx.compose.ui.graphics.Color.White) }
                }
                }
            }
        }
        item {
            Text(
                "কোনো courier API এখনো যুক্ত করা হয়নি — tracking ref শুধু অভ্যন্তরীণ, courier-এর নিজের সাইটে কাজ করবে না। সব stage হাতে আপডেট করতে হয়। API যুক্ত করা হলে এখানেই live status আসবে।",
                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
            )
        }
        }
    }
    }
}
}
    // v113-255 — the real picker dialogs for this manual booking form,
    // same components DmsInvoiceWorkspace's own courier section now
    // uses — one real implementation, not two.
    if (showLocationPicker) {
        val activeCourier = couriers.firstOrNull { it.id == selectedCourier }
        if (activeCourier?.courierType == "PATHAO") {
            com.abm.erp.core.PathaoLocationPickerDialog(
                partner = activeCourier,
                onDismiss = { showLocationPicker = false },
                onSelected = { cId, cName, zId, zName, aId, aName ->
                    pathaoCityId = cId; pathaoCityName = cName; pathaoZoneId = zId; pathaoZoneName = zName; pathaoAreaId = aId; pathaoAreaName = aName
                },
            )
        } else if (activeCourier?.courierType == "REDX") {
            com.abm.erp.core.RedxAreaPickerDialog(
                partner = activeCourier,
                onDismiss = { showLocationPicker = false },
                onSelected = { aId, aName -> redxAreaId = aId; redxAreaName = aName },
            )
        }
    }
}

@Composable
private fun VehicleTrackingTab(vm: CourierViewModel) {
    val vehicles by vm.vehicles.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var pingFor by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        if (vm.canCreateVehicle()) {
            Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Add Vehicle") }
            Spacer(Modifier.height(10.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(vehicles, key = { it.id }) { v ->
                val latestPing by vm.latestPingFor(v.id).collectAsState(initial = null)
                // v113-249 — the person's own direct follow-up: Shipment
                // could already say "I'm on this vehicle," but this tab
                // never showed the reverse — which shipments a vehicle is
                // actually carrying right now. Doesn't depend on GPS at
                // all (the person's own confirmed constraint — no real
                // GPS hardware in the vehicles yet) — this is a separate,
                // simpler connection off Shipment.vehicleId directly.
                val shipments by vm.shipments.collectAsState()
                val activeShipments = remember(shipments, v.id) {
                    shipments.filter { it.vehicleId == v.id && it.status != ShipmentStatus.DELIVERED }
                }
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${v.registrationNo} (${v.vehicleType})", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("Driver: ${v.driverName.ifBlank { "—" }} · ${v.driverPhone}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            latestPing?.let { p ->
                                Text("সর্বশেষ অবস্থান: ${"%.4f".format(p.lat)}, ${"%.4f".format(p.lng)} · ${"%.0f".format(p.speedKmh)} km/h", style = MaterialTheme.typography.labelSmall, color = ElectricCyan)
                            } ?: Text("এখনো কোনো GPS ping পাওয়া যায়নি।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        TextButton(onClick = { pingFor = v.id }) { Text("📍 Log position") }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Vehicle", entityId = v.id, entityLabel = v.registrationNo,
                            shareText = "Vehicle: ${v.registrationNo} (${v.vehicleType})\nDriver: ${v.driverName} · ${v.driverPhone}",
                            csvHeader = "RegistrationNo,Type,Driver,Phone",
                            csvRow = com.abm.erp.core.toCsvRow(v.registrationNo, v.vehicleType, v.driverName, v.driverPhone),
                        )
                    }
                    if (activeShipments.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Divider()
                        Spacer(Modifier.height(6.dp))
                        Text("এই গাড়িতে এখন যা যাচ্ছে (${activeShipments.size})", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        activeShipments.forEach { s ->
                            Text(
                                "• ${s.dealerOrRetailer}${s.invoiceNo?.let { " · $it" } ?: ""} — ${s.status.name.replace("_", " ")}",
                                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                            )
                        }
                    }
                }
            }
            if (vehicles.isEmpty()) item { Text("এখনো কোনো vehicle registered নেই।", color = TextSecondary) }
        }
    }

    if (showAdd) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showAdd = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                var reg by remember { mutableStateOf("") }
                var type by remember { mutableStateOf("Truck") }
                var driver by remember { mutableStateOf("") }
                var phone by remember { mutableStateOf("") }
                Column(Modifier.padding(16.dp)) {
                    Text("Add Vehicle", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = reg, onValueChange = { reg = it }, label = { Text("Registration No.") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Truck", "Van", "Motorcycle").forEach { t -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) }) }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = driver, onValueChange = { driver = it }, label = { Text("Driver name") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Driver phone") }, modifier = Modifier.fillMaxWidth())
                    var vehicleError by remember { mutableStateOf<String?>(null) }
                    vehicleError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { if (vm.createVehicle(reg, type, driver, phone, onRejected = { e -> vehicleError = e }) != null) showAdd = false }, enabled = reg.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Register Vehicle") }
                }
            }
        }
    }

    pingFor?.let { vehicleId ->
        androidx.compose.ui.window.Dialog(onDismissRequest = { pingFor = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                // v113-255 — the person's own direct instruction: shift
                // this from manual entry to real GPS. Same exact proven
                // pattern as SalesChainScreen's own tagLocationNow() —
                // FusedLocationProviderClient.lastLocation, permission-
                // checked, permission-launcher fallback if not yet
                // granted — not a new mechanism invented for this one
                // dialog. Manual lat/lng fields kept, but now pre-filled
                // by a real GPS fix rather than typed from nothing, and
                // still editable for the rare case a real fix is
                // unavailable (indoors, no signal) and a known position
                // needs to be logged anyway.
                var latText by remember { mutableStateOf("") }
                var lngText by remember { mutableStateOf("") }
                var speedText by remember { mutableStateOf("") }
                var gpsError by remember { mutableStateOf<String?>(null) }
                val gpsContext = androidx.compose.ui.platform.LocalContext.current

                fun hasLocationPermission() = androidx.core.content.ContextCompat.checkSelfPermission(
                    gpsContext, android.Manifest.permission.ACCESS_FINE_LOCATION,
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED

                fun fetchRealGps() {
                    val client = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(gpsContext)
                    try {
                        @Suppress("MissingPermission")
                        client.lastLocation.addOnSuccessListener { loc ->
                            if (loc != null) {
                                latText = loc.latitude.toString(); lngText = loc.longitude.toString(); gpsError = null
                            } else gpsError = "সাম্প্রতিক GPS fix নেই — খোলা জায়গায় গিয়ে আবার চেষ্টা করুন।"
                        }.addOnFailureListener { gpsError = it.message ?: "অবস্থান আনা যায়নি।" }
                    } catch (e: SecurityException) {
                        gpsError = "Location অনুমতি লাগবে।"
                    }
                }
                val gpsPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                    androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
                ) { granted -> if (granted) fetchRealGps() else gpsError = "Location অনুমতি দেওয়া হয়নি।" }

                Column(Modifier.padding(16.dp)) {
                    Text("Log Vehicle Position", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { if (hasLocationPermission()) fetchRealGps() else gpsPermissionLauncher.launch(android.Manifest.permission.ACCESS_FINE_LOCATION) },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("📍 এখনকার real GPS অবস্থান নিন") }
                    gpsError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = latText, onValueChange = { latText = it }, label = { Text("Latitude") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = lngText, onValueChange = { lngText = it }, label = { Text("Longitude") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = speedText, onValueChange = { speedText = it }, label = { Text("Speed (km/h)") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val lat = latText.toDoubleOrNull() ?: return@Button
                            val lng = lngText.toDoubleOrNull() ?: return@Button
                            vm.recordVehiclePing(vehicleId, lat, lng, speedText.toDoubleOrNull() ?: 0.0)
                            pingFor = null
                        },
                        enabled = latText.toDoubleOrNull() != null && lngText.toDoubleOrNull() != null,
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Save Position") }
                }
            }
        }
    }

    // v113-256 — confirm dialog for the "⚠ Return তৈরি করুন" button: pulls
    // the shipment's own real linked invoice, offers its full line items
    // pre-selected (a courier failure/return-to-sender means none of it
    // was actually delivered — the default is "reverse all of it", not a
    // partial guess), then calls the same real createSalesReturn +
    // approveSalesReturn pair DealerReturnSheet already uses — one real
    // correction path, not a second one invented here.
    failedShipmentForReturn?.let { shipmentId ->
        val shipment = shipments.firstOrNull { it.id == shipmentId }
        val linkedInvoice = shipment?.invoiceId?.let { invId -> allInvoices.firstOrNull { it.id == invId } }
        if (shipment == null || linkedInvoice == null) {
            failedShipmentForReturn = null
        } else {
            var returnReason by remember(shipmentId) { mutableStateOf("Courier ${shipment.status.name.lowercase().replace("_", " ")} — কোনো পণ্য দেওয়া হয়নি") }
            var submitting by remember(shipmentId) { mutableStateOf(false) }
            var submitResult by remember(shipmentId) { mutableStateOf<String?>(null) }
            val returnScope = rememberCoroutineScope()
            androidx.compose.ui.window.Dialog(onDismissRequest = { failedShipmentForReturn = null }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp).heightIn(max = 480.dp).verticalScroll(rememberScrollState())) {
                        Text("Invoice ${linkedInvoice.invoiceNo} — সম্পূর্ণ Return", fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("${linkedInvoice.dealerName} — ৳${"%,.0f".format(linkedInvoice.total)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Spacer(Modifier.height(8.dp))
                        linkedInvoice.lineItems.forEach { line -> Text("• ${line.name} (${line.qty})", style = MaterialTheme.typography.bodySmall) }
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = returnReason, onValueChange = { returnReason = it }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
                        submitResult?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = if (it.startsWith("✔")) SuccessGreen else DangerRed) }
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = {
                                submitting = true
                                returnScope.launch {
                                    val r = MockRepository.createSalesReturn(
                                        invoiceId = linkedInvoice.id, partyType = com.abm.erp.data.PartyType.DEALER,
                                        partyId = linkedInvoice.dealerId, partyName = linkedInvoice.dealerName,
                                        lineItems = linkedInvoice.lineItems, reason = returnReason,
                                        onRejected = { reason -> submitResult = "✖ $reason"; submitting = false },
                                    )
                                    if (r != null) {
                                        MockRepository.approveSalesReturn(r.id, onRejected = { reason -> submitResult = "✖ Return তৈরি হয়েছে কিন্তু approve ব্যর্থ: $reason" })
                                        submitResult = "✔ Return ${r.returnNo} তৈরি ও approve হয়েছে — due/stock ঠিক হয়ে গেছে।"
                                    }
                                    submitting = false
                                }
                            },
                            enabled = !submitting, modifier = Modifier.fillMaxWidth(),
                        ) { Text(if (submitting) "..." else "সম্পূর্ণ Return জমা দিন") }
                        TextButton(onClick = { failedShipmentForReturn = null }, modifier = Modifier.fillMaxWidth()) { Text("বন্ধ করুন") }
                    }
                }
            }
        }
    }
}
