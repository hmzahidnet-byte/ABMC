package com.abm.erp.ui.dms

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.core.ModuleDrawerItem
import com.abm.erp.core.ModuleDrawerScaffold
import com.abm.erp.core.ModuleDrillRow
import com.abm.erp.core.rememberVisibleDealers
import com.abm.erp.data.MockRepository
import com.abm.erp.data.rejectCollection // v113-190: missing import — real CI compile error
import com.abm.erp.data.verifyCollection // v113-190: missing import — real CI compile error
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber
import kotlinx.coroutines.launch

/**
 * DMS — Dealer Management System. One of the six mother modules.
 *
 * Built to the person's hand-drawn DMS draft: a left drawer with the module's own
 * options, and everything about a dealer living *inside* here — nothing pulled out
 * into a cross-cutting screen, and no other mother module visible from in here.
 *
 * Where an option already exists as working code elsewhere, this hosts that exact
 * composable rather than writing a second copy. That is deliberate: duplicating the
 * dealer invoice UI would mean two places to fix every future bug, and the person's
 * standing rule is one home per feature.
 */
private val DMS_COLOR_START = 0xFF2563EB
private val DMS_COLOR_END = 0xFF1E3A8A

private val DMS_ITEMS_BASE = listOf(
    ModuleDrawerItem("dashboard", "DMS Dashboard", Icons.Filled.Home, "সারসংক্ষেপ"),
    ModuleDrawerItem("invoice", "Invoice", Icons.Filled.Description, "Direct Invoice + Auto Data"),
    ModuleDrawerItem("message", "Message / CRM", Icons.Filled.Forum, "Offer / Due / Custom SMS"),
    ModuleDrawerItem("list", "List", Icons.Filled.ListAlt, "Dealer Info & Full History"),
    ModuleDrawerItem("approve", "Approve", Icons.Filled.FactCheck, "Approvals & Permissions"),
    ModuleDrawerItem("alerts", "Alerts", Icons.Filled.Warning, "Stock Shortage · Due Over Limit"),
    ModuleDrawerItem("logistic", "Logistic", Icons.Filled.LocalShipping, "Courier Tracking & API"),
    ModuleDrawerItem("finance", "Finance", Icons.Filled.Payments, "Finance & Cash Management"),
    ModuleDrawerItem("complain", "Complain", Icons.Filled.ReportProblem, "Dealer Complaints"),
)

// v113-167 — same pattern as HR: one drawer item, always last, Chairman-only,
// hosting every Chairman-only-gated action for this module. Dealer/Retailer
// approve uses the broader GM/MD/AGM/Chairman tier (same as Invoice) so it
// stays in "approve" as-is — only setCourierApiConfig is genuinely
// Chairman-only-gated in DMS.
private val DMS_CHAIRMAN_ITEM = ModuleDrawerItem("chairman", "Chairman", Icons.Filled.Star, "Dealer Control · Product · Restore · Courier API")

@Composable
fun DmsHomeScreen(
    startKey: String? = null,
    onBackToHome: () -> Unit = {},
    onNavigate: (String) -> Unit = {},
) {
    // v113-249 — the person's own direct instruction from the diagnostic-
    // center discussion: entering a module should land directly on the
    // real work (the dealer list), not require an extra tap through a
    // summary screen first. Dashboard stays reachable — just not default.
    var selected by remember { mutableStateOf(startKey ?: "list") }
    val salesVm: com.abm.erp.ui.sales.SalesChainViewModel = viewModel()
    val dealersVm: com.abm.erp.ui.dealer.DealersScreenViewModel = viewModel()
    val dealers = rememberVisibleDealers()
    val isChairman = MockRepository.currentUser.role == com.abm.erp.data.UserRole.CHAIRMAN
    val items = if (isChairman) DMS_ITEMS_BASE + DMS_CHAIRMAN_ITEM else DMS_ITEMS_BASE
    // v113-211 — the person's own request: viewing a completed invoice
    // should fill the whole screen. DmsInvoiceWorkspace owns the actual
    // "am I viewing a finished document" state internally, so it reports
    // changes up through this callback rather than that state being
    // duplicated or lifted here.
    var fullScreenDocument by remember { mutableStateOf(false) }

    ModuleDrawerScaffold(
        moduleName = "DMS",
        moduleSubtitle = "Dealer Management System",
        colorStart = DMS_COLOR_START,
        colorEnd = DMS_COLOR_END,
        moduleIcon = Icons.Filled.Business,
        items = items,
        selectedKey = selected,
        onSelect = { selected = it },
        onBackToHome = onBackToHome,
        hideTopBar = fullScreenDocument && selected == "invoice",
    ) { key ->
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            when (key) {
                "dashboard" -> DmsDashboard(dealers)
                // v113-80 — the workspace contract's reference implementation: the whole
                // invoice operation in ONE screen (dealer QR/search/add + financial
                // context + product + offer/discount + return + summary + approve +
                // history). Old DealerInvoiceTab remains for legacy Sales suite until
                // the final strip-down.
                "invoice" -> DmsInvoiceWorkspace(onNavigate, onViewingDocumentChange = { fullScreenDocument = it })
                // v113-249 — ledger/stock/newdealer drawer items removed
                // (the person's own direct instruction, from the earlier
                // diagnostic-center discussion): each was just "pick a
                // dealer, then see ONE thing about them" — a real,
                // confirmed duplicate of what "list" → a dealer's own rich
                // detail already shows in full (Ledger + Graph + 90-Day
                // sub, the Stock extraTab, and the same detail's own
                // +Add-Dealer button). "list" is the single, complete home
                // for all three now; the underlying dealer_stock/{id} and
                // statement/DEALER/{id} routes are untouched for anything
                // else that might still reference them directly.
                "list" -> com.abm.erp.core.ModuleBrowseList(
                    config = com.abm.erp.core.rememberDealerBrowseConfig(
                        zones = remember(dealers) { dealers.map { it.zone }.filter { it.isNotBlank() }.distinct().sorted() },
                    ),
                    // v113-253 — audit catch, the most visible place this
                    // gap could show up: ModuleBrowseList itself doesn't
                    // filter isDeleted (confirmed directly against its
                    // own implementation — it only filters by search/
                    // facets, the caller owns what "records" it's given),
                    // and dealers here wasn't guaranteed clean on every
                    // visibleDealersFor role path. Without this, a soft-
                    // deleted dealer could appear in the primary Dealer
                    // List itself and be clicked into.
                    records = remember(dealers) { dealers.filter { !it.isDeleted } },
                    onBack = { selected = "dashboard" },
                    onNavigate = onNavigate,
                )
                "approve" -> DmsApprove(dealers, salesVm, onNavigate)
                "alerts" -> DmsAlertsTab(dealers, onNavigate)
                "logistic" -> com.abm.erp.ui.courier.CourierScreen()
                "newdealer" -> com.abm.erp.ui.dealer.AddDealerForm(dealersVm) { selected = "list" }
                // v113-81 — workspace contract: whole collection operation in one screen
                // (party QR/search + due context + entry + dual-control verify history).
                "finance" -> com.abm.erp.core.CollectionWorkspace(
                    partyType = com.abm.erp.data.PartyType.DEALER, partyLabel = "Dealer",
                    // v113-253 — a real audit catch, checking every drawer
                    // item's own logic directly: visibleDealersFor doesn't
                    // filter isDeleted on every one of its own branches
                    // (confirmed directly — only the profile-linked path
                    // does), and "message" right below already added its
                    // own defensive !isDeleted filter for exactly that
                    // reason — this one hadn't, meaning a soft-deleted
                    // (cancelled) dealer could still appear as a valid
                    // target to record a brand new collection against.
                    parties = remember(dealers) { dealers.filter { !it.isDeleted }.map { com.abm.erp.core.CollectionParty(it.id, it.name, it.zone, it.dueBalance) } },
                    onNavigate = onNavigate,
                )
                "message" -> com.abm.erp.core.PartyCampaignSection(
                    audienceLabel = "Dealer",
                    parties = remember(dealers) { dealers.filter { !it.isDeleted }.map { com.abm.erp.core.CampaignParty(it.id, it.name, it.phone, it.zone, it.dueBalance) } },
                )
                // v113-77 — hosted from GeoCrmScreen (made internal); CRM's own tab now
                // points here. One implementation, one home.
                "complain" -> com.abm.erp.ui.crm.CustomerComplaintsTab(dealers)
                "chairman" -> if (isChairman) DmsChairmanPanel(onNavigate) else DmsDashboard(dealers)
                else -> DmsDashboard(dealers)
            }
        }
    }
}

/**
 * v113-175 — person's specific request for DMS's Chairman panel: a clean
 * approval-only view, not a full browse. If someone wants to add a dealer,
 * that shows here for Chairman to approve — plus Dealer Cancellation and
 * Collection verification (anyone can log a collection; Chairman verifies
 * it). All three already exist as real repository functions
 * (approveDealer/rejectDealer, deleteDealer, verifyCollection/
 * rejectCollection) — this is their first home inside the new DMS module
 * (previously only reachable via the legacy DealersScreen).
 */
// v113-249 — the person's own direct, confirmed finding: DMS had two
// separate implementations of the same "approve pending things" idea —
// Chairman's own panel had a real, complete one (Dealer Add + Invoice +
// Collection, each with real action buttons), while the regular "Approve"
// drawer item (meant for any ASM+ role with real approve permission, per
// PermissionManager's own canApprove = role.ordinal >= ASM.ordinal) had
// only a passive count pointing elsewhere. Extracted the real, working
// content into one shared composable so both call sites show the exact
// same thing — not a second, parallel reimplementation. Dealer
// Cancellation (a more sensitive, destructive delete, not an approval)
// deliberately stays Chairman-panel-only, not pulled into this shared
// piece.
@Composable
private fun DealerApprovalsShared() {
    val dealers by MockRepository.dealers.collectAsState()
    val collections by MockRepository.partyCollections.collectAsState()
    val invoices by MockRepository.salesInvoices.collectAsState()
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    val pendingDealers = remember(dealers) { dealers.filter { !it.isDeleted && !it.isActive && it.status == "PENDING_APPROVAL" } }
    val pendingCollections = remember(collections) { collections.filter { it.status == "PENDING" } }
    val pendingInvoices = remember(invoices) { invoices.filter { !it.isDeleted && it.status == "PENDING" } }

    fun toast(msg: String) = android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()

    Column(Modifier.fillMaxWidth()) {
        Text("Dealer Add (${pendingDealers.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingDealers.isEmpty()) Text("কোনো pending dealer নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingDealers.forEach { d ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(d.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(d.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { scope.launch { MockRepository.approveDealer(d.id, onRejected = { r -> toast(r) }) } }) { Text("Approve") }
                    TextButton(onClick = { scope.launch { MockRepository.rejectDealer(d.id, "Rejected", onRejected = { r -> toast(r) }) } }) { Text("Reject", color = DangerRed) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Invoice Approvals (${pendingInvoices.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingInvoices.isEmpty()) Text("কোনো pending invoice নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingInvoices.take(30).forEach { inv ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${inv.invoiceNo} — ${inv.dealerName}", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("৳${"%,.0f".format(inv.total)} · ${inv.createdAt.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { MockRepository.approveSalesInvoice(inv.id, onRejected = { r -> toast(r) }) }) { Text("Approve") }
                    TextButton(onClick = { if (!MockRepository.rejectSalesInvoice(inv.id, "Rejected")) toast("Reject করা যায়নি।") }) { Text("Reject", color = DangerRed) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Dealer Collections (${pendingCollections.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        if (pendingCollections.isEmpty()) Text("কোনো pending collection নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        pendingCollections.forEach { c ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.partyName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("৳${"%,.0f".format(c.amount)} · ${c.method}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    TextButton(onClick = { scope.launch { MockRepository.verifyCollection(c.id, onRejected = { r -> toast(r) }) } }) { Text("Verify") }
                    TextButton(onClick = { scope.launch { MockRepository.rejectCollection(c.id, onRejected = { r -> toast(r) }) } }) { Text("Reject", color = DangerRed) }
                }
                if (c.proofUri != null) {
                    Spacer(Modifier.height(6.dp))
                    coil.compose.AsyncImage(
                        model = c.proofUri, contentDescription = "লেনদেনের প্রমাণ",
                        modifier = Modifier.height(110.dp).fillMaxWidth(),
                        contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                    )
                } else {
                    Spacer(Modifier.height(4.dp))
                    Text("⚠ কোনো প্রমাণের ছবি সংযুক্ত করা হয়নি।", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                }
            }
        }
    }
}

@Composable
private fun DmsApprovalsPanel() {
    val dealers by MockRepository.dealers.collectAsState()
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    val activeDealers = remember(dealers) { dealers.filter { !it.isDeleted && it.isActive } }

    fun toast(msg: String) = android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()

    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        DealerApprovalsShared()

        Spacer(Modifier.height(16.dp))
        Text("Dealer Cancellation", fontWeight = FontWeight.Bold, color = TextPrimary)
        Text("সক্রিয় dealer বাতিল করুন — soft delete, পুনরুদ্ধার Restore tab থেকে সম্ভব।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        var cancelQuery by remember { mutableStateOf("") }
        OutlinedTextField(value = cancelQuery, onValueChange = { cancelQuery = it }, placeholder = { Text("Dealer নাম খুঁজুন…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        activeDealers.filter { cancelQuery.isBlank() || it.name.contains(cancelQuery, true) }.take(20).forEach { d ->
            GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(d.name, color = TextPrimary, modifier = Modifier.weight(1f))
                    TextButton(onClick = { scope.launch { MockRepository.deleteDealer(d.id, onRejected = { r -> toast(r) }) } }) { Text("Cancel", color = DangerRed) }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun DmsChairmanPanel(onNavigate: (String) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        androidx.compose.material3.ScrollableTabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Approvals") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Dealer Control") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Sales Rules") })
            Tab(selected = tab == 3, onClick = { tab = 3 }, text = { Text("Restore") })
            Tab(selected = tab == 4, onClick = { tab = 4 }, text = { Text("Courier API") })
            // v113-249 — the person's own direct confirmation: these are
            // genuinely DMS-related (dealer-territory GPS anomalies and
            // security events), so they belong directly in DMS's own
            // Chairman panel rather than only being reachable indirectly
            // through other modules' quick-links (Dashboard, Boardroom).
            // Reused directly from DealersScreen.kt (now internal rather
            // than private) — not a second implementation of the same
            // review lists.
            Tab(selected = tab == 5, onClick = { tab = 5 }, text = { Text("Location Alerts") })
            Tab(selected = tab == 6, onClick = { tab = 6 }, text = { Text("Security Events") })
        }
        when (tab) {
            0 -> DmsApprovalsPanel()
            1 -> {
                // v113-172 — moved from the central Chairman module's "parties" item
                // (dealer half — retailer half is now RMS's own Chairman tab).
                // v113-201 — was passed onNavigate = {} because this composable had
                // no parameter to forward one through: confirmed by tracing DmsHomeScreen's
                // "chairman" route, which called DmsChairmanPanel() with zero arguments.
                // The only two things ModuleBrowseList's onNavigate actually drives (its
                // own onNavigate calls, traced directly in ModuleBrowseFlow.kt) are the
                // "Add" button (dealer's addRoute = "dms?key=newdealer") and the QR-scan
                // FAB — both were silently inert here. Now wired to the real one.
                val dealers = com.abm.erp.core.rememberVisibleDealers()
                // v113-253 — same audit catch as the regular "list" drawer
                // item: ModuleBrowseList doesn't filter isDeleted itself,
                // and rememberVisibleDealers() isn't guaranteed to have
                // filtered it on every role path either.
                com.abm.erp.core.ModuleBrowseList(
                    config = com.abm.erp.core.rememberDealerBrowseConfig(
                        zones = remember(dealers) { dealers.map { it.zone }.filter { it.isNotBlank() }.distinct().sorted() },
                    ),
                    records = remember(dealers) { dealers.filter { !it.isDeleted } },
                    onBack = {},
                    onNavigate = onNavigate,
                )
            }
            // v113-221 — was "Product Control" (ChairmanProductControl) —
            // removed as a duplicate: Product now lives only in the
            // central Chairman module's own "Product" item, matching the
            // person's own principle of not showing the same control from
            // two places. This slot now carries the DMS-relevant subset of
            // the old central "Business Rule Engine" instead (the
            // sales/credit rules — the HR-relevant subset went to HR's
            // own Chairman panel the same way) — "একেক জায়গায় একেকটা
            // rules হবে", the person's own words.
            2 -> DmsBusinessRulesSection()
            3 -> Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
                Text("Soft-deleted রেকর্ড দেখা ও restore — hard delete এই অ্যাপে নেই।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Spacer(Modifier.height(8.dp))
                com.abm.erp.ui.chairmanmodule.DmsInvoiceRestoreSection()
                Spacer(Modifier.height(8.dp))
                com.abm.erp.ui.chairmanmodule.DmsDealerRestoreSection()
                Spacer(Modifier.height(8.dp))
                com.abm.erp.ui.chairmanmodule.DmsProductRestoreSection()
            }
            4 -> com.abm.erp.ui.courier.CourierApiConfigPanel()
            5 -> com.abm.erp.ui.dealer.LocationAlertsTab()
            else -> com.abm.erp.ui.dealer.SecurityEventsTab()
        }
    }
}

private data class DmsRuleDef(val key: String, val label: String, val type: com.abm.erp.data.BusinessRuleType, val default: Double)

private val DMS_RULES = listOf(
    DmsRuleDef("WEEKLY_DUE_PCT", "Weekly 50% Due Rule (Tuesday checkpoint %)", com.abm.erp.data.BusinessRuleType.PERCENTAGE, 50.0),
    DmsRuleDef("MAX_DISCOUNT_PCT", "Maximum Discount %", com.abm.erp.data.BusinessRuleType.PERCENTAGE, 15.0),
    DmsRuleDef("INVOICE_LIMIT", "Invoice Limit (needs extra approval above this)", com.abm.erp.data.BusinessRuleType.AMOUNT, 500000.0),
    DmsRuleDef("DEALER_CREDIT_LIMIT_DEFAULT", "Dealer Credit Limit — default for new dealers", com.abm.erp.data.BusinessRuleType.AMOUNT, 0.0),
    DmsRuleDef("MIN_CREDIT_LIMIT", "Minimum Credit Limit (floor for any dealer)", com.abm.erp.data.BusinessRuleType.AMOUNT, 0.0),
)

@Composable
private fun DmsBusinessRulesSection() {
    val rules by MockRepository.businessRules.collectAsState()
    var editingKey by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Text("Sales & Credit Rules", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("পরিবর্তন সাথে সাথে সারা ERP-এ প্রতিফলিত হবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Spacer(Modifier.height(8.dp))
        DMS_RULES.forEach { def ->
            val current = rules.firstOrNull { it.key == def.key }
            val currentValue = current?.value ?: def.default
            Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp), tonalElevation = 2.dp) {
                Column(Modifier.padding(10.dp)) {
                    Text(def.label, style = MaterialTheme.typography.titleSmall)
                    Text("বর্তমান মান: $currentValue${if (def.type == com.abm.erp.data.BusinessRuleType.PERCENTAGE) "%" else ""}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    TextButton(onClick = { editingKey = def.key }) { Text("সম্পাদনা করুন") }
                }
            }
        }
    }
    editingKey?.let { key ->
        val def = DMS_RULES.first { it.key == key }
        val current = rules.firstOrNull { it.key == key }?.value ?: def.default
        var newValue by remember { mutableStateOf(current.toString()) }
        androidx.compose.ui.window.Dialog(onDismissRequest = { editingKey = null }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(def.label, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newValue, onValueChange = { newValue = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("নতুন মান") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val v = newValue.toDoubleOrNull()
                            if (v != null) { MockRepository.setBusinessRule(def.key, def.label, def.type, v); editingKey = null }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("সংরক্ষণ করুন") }
                }
            }
        }
    }
}

@Composable
private fun DmsDashboard(dealers: List<com.abm.erp.data.Dealer>) {
    // v113-253 — a real audit catch: dealers (as passed into this whole
    // screen) isn't reliably isDeleted-filtered on every role path
    // visibleDealersFor takes (confirmed directly — only the profile-
    // linked branch filters it), so a soft-deleted dealer could inflate
    // this Dashboard's own real business numbers — the dealer count, the
    // total due, and both of the newly-added graphs below, all of which
    // read from dealers directly. Filtered once, here, rather than
    // scattering the same guard across every individual stat.
    val activeDealers = remember(dealers) { dealers.filter { !it.isDeleted } }
    val invoices by MockRepository.salesInvoices.collectAsState()
    val approvals by MockRepository.approvals.collectAsState()
    val totalDue = remember(activeDealers) { activeDealers.sumOf { it.dueBalance } }
    val pendingInvoices = remember(invoices) { invoices.count { it.status == "PENDING" && !it.isDeleted } }
    val pendingApprovals = remember(approvals) {
        approvals.count { it.status == com.abm.erp.data.ApprovalStatus.PENDING && it.entityType == "SalesInvoice" }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("DMS Overview", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(4.dp))
        Text(
            "আপনার cascade scope অনুযায়ী — অন্য এলাকার dealer এখানে গোনা হয় না।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(12.dp))
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            DmsStatRow("Dealer", "${activeDealers.size}", TextPrimary)
            DmsStatRow("Total Due", "৳${"%,.0f".format(totalDue)}", if (totalDue > 0) WarningAmber else SuccessGreen)
            DmsStatRow("Pending Invoice", "$pendingInvoices", if (pendingInvoices > 0) WarningAmber else SuccessGreen)
            DmsStatRow("Pending Approval", "$pendingApprovals", if (pendingApprovals > 0) WarningAmber else SuccessGreen)
        }
        // v113-139 — person asked every mother-module dashboard to carry a KPI
        // graphic. Uses the SHARED DualSeriesBarChart and real invoice/collection
        // rows for the dealers in this user's own cascade scope — no sample data,
        // and no second charting implementation.
        val collections by MockRepository.partyCollections.collectAsState()
        val myDealerIds = remember(activeDealers) { activeDealers.map { it.id }.toSet() }
        val weekly = remember(invoices, collections, myDealerIds) {
            val today = java.time.LocalDate.now()
            val thisMonday = today.minusDays((today.dayOfWeek.value - 1).toLong())
            (4 downTo 0).map { w ->
                val start = thisMonday.minusWeeks(w.toLong())
                val end = start.plusDays(7)
                val sales = invoices.filter { !it.isDeleted && it.dealerId in myDealerIds && !it.createdAt.toLocalDate().isBefore(start) && it.createdAt.toLocalDate().isBefore(end) }
                    .sumOf { inv -> inv.lineItems.sumOf { it.lineTotal } }
                val col = collections.filter { it.status == "VERIFIED" && it.partyId in myDealerIds && !it.createdAt.toLocalDate().isBefore(start) && it.createdAt.toLocalDate().isBefore(end) }
                    .sumOf { it.amount }
                Triple("${start.dayOfMonth}/${start.monthValue}", sales, col)
            }
        }
        if (weekly.any { it.second > 0.0 || it.third > 0.0 }) {
            Spacer(Modifier.height(12.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Sales vs Collection — Last 5 Weeks", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                com.abm.erp.core.DualSeriesBarChart(weekly, "Sales", "Collection")
            }
        }

        // v113-251 — the person's own direct instruction: entering DMS
        // should show real graphical reports right on the Dashboard, not
        // just stat numbers and one chart. Reuses the exact bar-progress
        // visual already proven in TerritoryOverviewScreen's own Sales
        // Report tab and DealerSalesReportTab — same pattern, company-
        // wide scope here, not a new visual language invented for this
        // one screen.
        val myDealerIds30 = remember(activeDealers) { activeDealers.map { it.id }.toSet() }
        val last30Invoices = remember(invoices, myDealerIds30) {
            val cutoff = java.time.LocalDate.now().minusDays(29)
            invoices.filter { !it.isDeleted && it.dealerId in myDealerIds30 && !it.createdAt.toLocalDate().isBefore(cutoff) }
        }
        data class TopProduct(val name: String, val qty: Int, val value: Double)
        val topProducts = remember(last30Invoices) {
            last30Invoices.flatMap { it.lineItems }
                .groupBy { it.name }
                .map { (name, lines) -> TopProduct(name, lines.sumOf { it.qty }, lines.sumOf { it.lineTotal }) }
                .sortedByDescending { it.value }.take(6)
        }
        if (topProducts.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Top Products — Last 30 Days", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                val maxVal = topProducts.maxOf { it.value }
                topProducts.forEach { p ->
                    Column(Modifier.padding(vertical = 4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(p.name, fontSize = 11.sp, color = TextPrimary, maxLines = 1, modifier = Modifier.weight(1f))
                            Text("${p.qty} · ৳${"%,.0f".format(p.value)}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        }
                        Spacer(Modifier.height(3.dp))
                        Box(Modifier.fillMaxWidth().height(5.dp).background(com.abm.erp.theme.HairlineBorder, androidx.compose.foundation.shape.RoundedCornerShape(999.dp))) {
                            Box(
                                Modifier.fillMaxWidth((p.value / maxVal).toFloat().coerceIn(0f, 1f))
                                    .fillMaxHeight().background(com.abm.erp.theme.DarazOrange, androidx.compose.foundation.shape.RoundedCornerShape(999.dp)),
                            )
                        }
                    }
                }
            }
        }

        // Zone-wise due — where the risk actually concentrates, at a glance.
        val zoneDue = remember(activeDealers) {
            activeDealers.filter { it.zone.isNotBlank() }
                .groupBy { it.zone }
                .map { (zone, ds) -> zone to ds.sumOf { it.dueBalance } }
                .sortedByDescending { it.second }.take(6)
        }
        if (zoneDue.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Zone-wise Due", fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Spacer(Modifier.height(10.dp))
                val maxDue = zoneDue.maxOf { it.second }.coerceAtLeast(1.0)
                zoneDue.forEach { (zone, due) ->
                    Column(Modifier.padding(vertical = 4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(zone, fontSize = 11.sp, color = TextPrimary, maxLines = 1, modifier = Modifier.weight(1f))
                            Text("৳${"%,.0f".format(due)}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = if (due > 0) WarningAmber else SuccessGreen)
                        }
                        Spacer(Modifier.height(3.dp))
                        Box(Modifier.fillMaxWidth().height(5.dp).background(com.abm.erp.theme.HairlineBorder, androidx.compose.foundation.shape.RoundedCornerShape(999.dp))) {
                            Box(
                                Modifier.fillMaxWidth((due / maxDue).toFloat().coerceIn(0f, 1f))
                                    .fillMaxHeight().background(if (due > 0) WarningAmber else SuccessGreen, androidx.compose.foundation.shape.RoundedCornerShape(999.dp)),
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun DmsStatRow(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        Text(value, fontWeight = FontWeight.Bold, color = color)
    }
}

/** Shared "pick a dealer, then drill in" list — used by Ledger and Stock. */
@Composable
private fun DmsDealerPickerList(
    dealers: List<com.abm.erp.data.Dealer>,
    emptyText: String,
    subtitleFor: (com.abm.erp.data.Dealer) -> String,
    onPick: (com.abm.erp.data.Dealer) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(dealers, query) {
        if (query.isBlank()) dealers
        else dealers.filter { it.name.contains(query, true) || it.zone.contains(query, true) }
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            placeholder = { Text("নাম বা এলাকা দিয়ে খুঁজুন…") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(10.dp))
        if (filtered.isEmpty()) Text(emptyText, color = TextSecondary)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.id }) { d ->
                ModuleDrillRow(d.name, subtitleFor(d)) { onPick(d) }
            }
        }
    }
}

/**
 * Approve — invoice/discount approvals for dealers, inside DMS where they belong
 * (Decision 2). ApprovalRequest rows (discount/over-limit) are actioned here; the
 * invoice's own ✓ Approve lives inline in the Invoice Workspace's history list
 * (v113-80), so this section points there rather than hosting a second copy.
 */
@Composable
private fun DmsApprove(
    dealers: List<com.abm.erp.data.Dealer>,
    salesVm: com.abm.erp.ui.sales.SalesChainViewModel,
    onNavigate: (String) -> Unit,
) {
    // v113-249 — the person's own direct, confirmed finding: this drawer
    // item — reachable by any role with real approve permission
    // (PermissionManager's own canApprove = role.ordinal >= ASM.ordinal,
    // not Chairman-only) — used to show only a passive count with a note
    // pointing elsewhere, while Chairman's own separate panel had the
    // real, actionable version of the exact same thing. Now calls the
    // same shared component Chairman's panel calls — one real
    // implementation, not two.
    Column(Modifier.fillMaxSize().padding(bottom = 12.dp).verticalScroll(rememberScrollState())) {
        com.abm.erp.core.ModuleApprovalSection(
            title = "Discount / limit অনুমোদনের অপেক্ষায়",
            entityTypes = setOf("SalesInvoice"),
        )
        Spacer(Modifier.height(12.dp))
        DealerApprovalsShared()
    }
}

// v113-249 — the person's own direct request: a real, live alerts view
// inside DMS — stock shortage (against Product's own reorderThreshold,
// now finally settable via Chairman's Product dialog) and due-over-limit
// dealers, in one place. Deliberately a live, always-current computed
// list rather than a persisted notification log — this app has no
// background/scheduled job infrastructure to reliably trigger periodic
// notification-creation, so a live view can never go stale or miss an
// event the way a notification-log approach could.
@Composable
private fun DmsAlertsTab(dealers: List<com.abm.erp.data.Dealer>, onNavigate: (String) -> Unit) {
    val allStockLines by MockRepository.allDealerStockLines().collectAsState(initial = emptyList())
    val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
    val reorderByProductId = remember(products) { products.filter { it.reorderThreshold > 0 }.associate { it.id to it.reorderThreshold } }
    // v113-253 — audit catch: overLimitDealers below already correctly
    // filters !isDeleted, but this one didn't — meaning a soft-deleted
    // (cancelled) dealer's leftover stock lines could still surface a
    // "shortage" alert with their name resolving fine, noise nobody
    // needs to act on since that dealer isn't actively supplied anymore.
    val dealerNameById = remember(dealers) { dealers.filter { !it.isDeleted }.associate { it.id to it.name } }

    data class ShortageRow(val dealerName: String, val dealerId: String, val productName: String, val qty: Int, val threshold: Double)
    val shortages = remember(allStockLines, reorderByProductId, dealerNameById) {
        allStockLines.mapNotNull { line ->
            val threshold = reorderByProductId[line.productId] ?: return@mapNotNull null
            if (line.qty >= threshold) return@mapNotNull null
            val dealerName = dealerNameById[line.dealerId] ?: return@mapNotNull null
            ShortageRow(dealerName, line.dealerId, line.productName, line.qty, threshold)
        }.sortedBy { it.qty }
    }

    val overLimitDealers = remember(dealers) {
        dealers.filter { !it.isDeleted && it.creditLimit > 0 && it.dueBalance > it.creditLimit }
            .sortedByDescending { it.dueBalance - it.creditLimit }
    }

    Column(Modifier.fillMaxSize().padding(bottom = 12.dp).verticalScroll(rememberScrollState())) {
        Text("Stock Shortage (${shortages.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        Text(
            "Product-এর Reorder Threshold-এর নিচে নেমে যাওয়া dealer stock — Chairman-এর Product সেটিংসে threshold নির্ধারণ করুন।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        Spacer(Modifier.height(6.dp))
        if (shortages.isEmpty()) {
            Text("কোনো shortage নেই।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        } else {
            shortages.forEach { s ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { onNavigate("rich_dealer_detail/${s.dealerId}") }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(s.productName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(s.dealerName, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text("${s.qty} / ${s.threshold.toInt()}", color = DangerRed, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("Due Over Limit (${overLimitDealers.size})", fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(6.dp))
        if (overLimitDealers.isEmpty()) {
            Text("কোনো dealer limit ছাড়ায়নি।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
        } else {
            overLimitDealers.forEach { d ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { onNavigate("rich_dealer_detail/${d.id}") }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(d.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(d.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Due ৳${"%,.0f".format(d.dueBalance)}", color = DangerRed, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            Text("Limit ৳${"%,.0f".format(d.creditLimit)}", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}
