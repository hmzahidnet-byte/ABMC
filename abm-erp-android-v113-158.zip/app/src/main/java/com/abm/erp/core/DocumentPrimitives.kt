package com.abm.erp.core

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abm.erp.theme.HairlineBorder
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary

/**
 * Shared building blocks for on-screen printable documents (Invoice, Memo, and any
 * future receipt/voucher screen). Originally lived only inside InvoiceDocumentScreen —
 * pulled out here (v113-153) so MemoDocumentScreen can reuse the exact same look
 * instead of a second, drifting copy. One home per feature.
 */

@Composable fun DocLabel(t: String) =
    Text(t.uppercase(), fontSize = 8.sp, color = TextSecondary, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)

@Composable fun DocValue(t: String) =
    Text(t, fontSize = 13.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)

@Composable fun RowScope.Th(t: String, w: Float, align: TextAlign = TextAlign.Start) =
    Text(t, Modifier.weight(w), color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = align)

@Composable fun RowScope.Td(
    t: String, w: Float, align: TextAlign = TextAlign.Start, weight: FontWeight = FontWeight.Normal,
) = Text(t, Modifier.weight(w), color = TextPrimary, fontSize = 11.sp, textAlign = align, fontWeight = weight)

@Composable fun TotalRow(label: String, value: String, color: Color = TextPrimary) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 11.sp, color = TextSecondary)
        Text(value, fontSize = 12.sp, color = color, fontWeight = FontWeight.SemiBold)
    }
}

@Composable fun SignatureSlot(role: String, name: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        if (name.isNotBlank()) {
            Text(name, fontSize = 9.sp, color = TextPrimary, maxLines = 1)
        } else {
            Spacer(Modifier.height(12.dp))
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(HairlineBorder))
        Spacer(Modifier.height(3.dp))
        Text(role, fontSize = 8.sp, color = TextSecondary, textAlign = TextAlign.Center)
    }
}

/**
 * Amount in words, Bangladeshi convention (lakh / crore rather than million / billion).
 *
 * Presentation only — it never feeds a calculation, and the numeric total beside it stays
 * the authority. Deliberately kept simple and total-agnostic so it cannot alter a figure.
 */
fun amountInWords(amount: Double): String {
    val n = kotlin.math.floor(amount).toLong()
    if (n == 0L) return "Zero Taka Only"
    if (n < 0L) return "Minus ${amountInWords(-amount)}"

    val ones = listOf(
        "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
        "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen",
    )
    val tens = listOf("", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety")

    fun under100(v: Int): String = when {
        v == 0 -> ""
        v < 20 -> ones[v]
        else -> (tens[v / 10] + if (v % 10 != 0) " ${ones[v % 10]}" else "")
    }

    fun under1000(v: Int): String {
        val h = v / 100
        val r = v % 100
        val parts = mutableListOf<String>()
        if (h > 0) parts += "${ones[h]} Hundred"
        if (r > 0) parts += under100(r)
        return parts.joinToString(" ")
    }

    val crore = (n / 10_000_000).toInt()
    val lakh = ((n / 100_000) % 100).toInt()
    val thousand = ((n / 1_000) % 100).toInt()
    val rest = (n % 1_000).toInt()

    val parts = mutableListOf<String>()
    if (crore > 0) parts += "${under1000(crore)} Crore"
    if (lakh > 0) parts += "${under100(lakh)} Lakh"
    if (thousand > 0) parts += "${under100(thousand)} Thousand"
    if (rest > 0) parts += under1000(rest)

    return parts.joinToString(" ").trim() + " Taka Only"
}
