package com.abm.erp.ui.fms

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.abm.erp.core.ModuleDrawerItem
import com.abm.erp.core.ModuleDrawerScaffold
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * FMS — Factory Management System. Mother module #4.
 *
 * This is where the person's four-stock-world rule lands for the company side:
 * Dealer stock lives in DMS, Retailer stock in RMS, and the old company-wide
 * "Inventory" splits here into the **Factory pipeline** (raw material → production →
 * finished goods, i.e. ProductionScreen + PurchaseScreen) and the **Warehouse
 * pipeline** (InventoryScreen: levels, movement, adjustment, count, expiry). The
 * split is by drawer item, not by rewriting either screen — the underlying data was
 * already organised this way; the old UI just presented both under one "Inventory"
 * roof.
 *
 * Everything hosted; nothing duplicated. `startTab` indices below are verified
 * against each screen's own `when (tab)` dispatch, not guessed:
 *  - ProductionScreen: 0 materials · 1 batches · 2 factory-hrm · 3 bom · 4 porder ·
 *    5 qc · 6 ploss · 7 machine
 *  - InventoryScreen: 0 levels · 1 move · 2 add · 3 catbrand · 4 adjust · 5 transfer ·
 *    6 damage · 7 expiry · 8 count · 9 intel
 *  - ProductionWarehouseScreen: 0 plans · 1 transfers
 */
private val FMS_COLOR_START = 0xFFE85D4A
private val FMS_COLOR_END = 0xFFC03A2B

private val FMS_ITEMS = listOf(
    ModuleDrawerItem("dashboard", "Dashboard", Icons.Filled.Home, "সারসংক্ষেপ"),
    ModuleDrawerItem("rawmat", "Raw Material", Icons.Filled.Layers, "Stock, Purchase & Usage"),
    ModuleDrawerItem("production", "Product (Production)", Icons.Filled.Factory, "Planning, Manufacturing & Stock"),
    // v113-86 — same approved browse pattern as DMS/RMS/HR, product-shaped: the FMS
    // "record" is a product, so the flow shows SKU/category/stock instead of dues,
    // and the graph is per-warehouse quantity split (no fake money screens).
    ModuleDrawerItem("productlist", "Product List", Icons.Filled.ListAlt, "Product Info & Stock History"),
    ModuleDrawerItem("qc", "Quality Control", Icons.Filled.VerifiedUser, "QC Reject & Verify"),
    ModuleDrawerItem("send", "Send to Warehouse", Icons.Filled.LocalShipping, "Factory → Warehouse Transfer"),
    ModuleDrawerItem("warehouse", "Warehouse Stock", Icons.Filled.Inventory2, "Stock In/Out Management"),
    ModuleDrawerItem("damage", "Damage / Wastage", Icons.Filled.BrokenImage, "Damage, Wastage & Return"),
    ModuleDrawerItem("factoryhr", "HR (Factory)", Icons.Filled.Engineering, "Factory Worker HR & Payroll"),
    ModuleDrawerItem("purchase", "Purchase / GRN", Icons.Filled.ShoppingCart, "Supplier, PO & Goods Receive"),
    // v113-82 — fills the gap ApprovalRouting.kt flagged since v113-77: no module
    // hosted Expense until now. Utility/office/transport/maintenance are FMS-typical
    // operational costs, and Expense sits alongside Purchase/GRN as the other
    // money-out-of-FMS workflow.
    ModuleDrawerItem("expense", "Expense", Icons.Filled.Receipt, "Submit & Approve Expense"),
    ModuleDrawerItem("complain", "Complain Box", Icons.Filled.MarkunreadMailbox, "Factory Complaints"),
    ModuleDrawerItem("reports", "Reports & Analytics", Icons.Filled.InsertChart, "All Factory Reports"),
)

@Composable
fun FmsHomeScreen(
    startKey: String? = null,
    onBackToHome: () -> Unit = {},
    onNavigate: (String) -> Unit = {},
) {
    var selected by remember { mutableStateOf(startKey ?: "dashboard") }
    val backToDash: () -> Unit = { selected = "dashboard" }

    ModuleDrawerScaffold(
        moduleName = "FMS",
        moduleSubtitle = "Factory Management System",
        colorStart = FMS_COLOR_START,
        colorEnd = FMS_COLOR_END,
        moduleIcon = Icons.Filled.Factory,
        items = FMS_ITEMS,
        selectedKey = selected,
        onSelect = { selected = it },
        onBackToHome = onBackToHome,
    ) { key ->
        when (key) {
            "dashboard" -> FmsDashboard()
            "rawmat" -> com.abm.erp.ui.production.ProductionScreen(startTab = 0, onBack = backToDash, onNavigate = onNavigate)
            "production" -> com.abm.erp.ui.production.ProductionScreen(startTab = 4, onBack = backToDash, onNavigate = onNavigate)
            "qc" -> com.abm.erp.ui.production.ProductionScreen(startTab = 5, onBack = backToDash, onNavigate = onNavigate)
            "factoryhr" -> com.abm.erp.ui.production.ProductionScreen(startTab = 2, onBack = backToDash, onNavigate = onNavigate)
            "send" -> com.abm.erp.ui.production.ProductionWarehouseScreen(startTab = 1, onBack = backToDash, onNavigate = onNavigate)
            "productlist" -> {
                val products by com.abm.erp.data.InventoryRepository.products.collectAsState()
                val alive = remember(products) { products.filter { !it.isDeleted } }
                com.abm.erp.core.ModuleBrowseList(
                    config = com.abm.erp.core.rememberProductBrowseConfig(
                        categories = remember(alive) { alive.map { it.category }.filter { it.isNotBlank() }.distinct().sorted() },
                    ),
                    records = alive,
                    onBack = backToDash,
                    onNavigate = onNavigate,
                )
            }
            "warehouse" -> com.abm.erp.ui.inventory.InventoryScreen(startTab = 0, onBack = backToDash)
            "damage" -> com.abm.erp.ui.inventory.InventoryScreen(startTab = 6, onBack = backToDash)
            // GRN (tab 2 in PurchaseScreen's own dispatch) is the factory-side entry point;
            // suppliers/PO are one back-tap away. startTab non-null keeps the compact
            // TaskHeader instead of the old full workspace header (v113-71 behaviour).
            "purchase" -> com.abm.erp.ui.purchase.PurchaseScreen(startTab = 2, onBack = backToDash)
            "expense" -> com.abm.erp.core.ExpenseWorkspace()
            "complain" -> com.abm.erp.ui.complaint.ComplaintBoxScreen()
            "reports" -> FmsCombinedReport()
            else -> FmsDashboard()
        }
    }
}

@Composable
private fun FmsDashboard() {
    val plans by com.abm.erp.data.MockRepository.productionPlans.collectAsState()
    val stockLevels by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
    val pendingPlans = remember(plans) { plans.count { it.status == com.abm.erp.data.ProductionPlanStatus.DRAFT } }
    val totalOnHand = remember(stockLevels) { stockLevels.sumOf { it.quantityOnHand } }
    val negativeCount = remember(stockLevels) { stockLevels.count { it.quantityOnHand < 0 } }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("FMS Overview", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
        Spacer(Modifier.height(12.dp))
        com.abm.erp.core.GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Warehouse On-hand", color = TextSecondary)
                Text("%,.0f".format(totalOnHand), color = TextPrimary)
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Draft Production Plan", color = TextSecondary)
                Text("$pendingPlans", color = if (pendingPlans > 0) WarningAmber else SuccessGreen)
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Negative Stock Item", color = TextSecondary)
                Text("$negativeCount", color = if (negativeCount > 0) com.abm.erp.theme.DangerRed else SuccessGreen)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Factory pipeline (Raw Material → Production → QC) আর Warehouse pipeline (Stock In/Out) " +
                "— দুটোই বাম মেনুতে আলাদা, dealer/retailer stock থেকে সম্পূর্ণ বিচ্ছিন্ন।",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
    }
}

/**
 * v113-86 — the one-page combined factory report that "reports" promised since the
 * poster. Every figure reads a live flow; each of the four sections links the detailed
 * screen that already exists. Time window: this month (period label shown), because
 * that is what the poster's "Key Summary (This Month)" block shows.
 */
@Composable
private fun FmsCombinedReport() {
    val plans by com.abm.erp.data.MockRepository.productionPlans.collectAsState()
    val stockLevels by com.abm.erp.data.InventoryRepository.stockLevels.collectAsState()
    val damages by com.abm.erp.data.InventoryRepository.damageReports.collectAsState()
    val month = remember { java.time.YearMonth.now() }
    val monthPlans = remember(plans) { plans.filter { java.time.YearMonth.from(it.productionDate) == month } }
    val completed = monthPlans.filter { it.status == com.abm.erp.data.ProductionPlanStatus.COMPLETED || it.status == com.abm.erp.data.ProductionPlanStatus.PARTIALLY_COMPLETED }
    val monthDamage = remember(damages) { damages.filter { java.time.YearMonth.from(it.createdAt.toLocalDate()) == month } }
    val totalStock = stockLevels.sumOf { it.quantityOnHand }
    val lowCount = stockLevels.count { it.isLowStock }

    androidx.compose.foundation.layout.Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Factory Report — ${month.month.name.lowercase().replaceFirstChar { it.uppercase() }} ${month.year}",
            fontWeight = FontWeight.Bold, color = com.abm.erp.theme.TextPrimary)
        com.abm.erp.core.GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Production (this month)", fontWeight = FontWeight.SemiBold, color = com.abm.erp.theme.TextPrimary)
            Row(Modifier.fillMaxWidth()) {
                com.abm.erp.core.BrowseStatCell("Plans", "${monthPlans.size}", modifier = Modifier.weight(1f))
                com.abm.erp.core.BrowseStatCell("Completed", "${completed.size}", com.abm.erp.theme.SuccessGreen, Modifier.weight(1f))
                com.abm.erp.core.BrowseStatCell("Planned Qty", "%,.0f".format(monthPlans.sumOf { it.plannedQuantity }), modifier = Modifier.weight(1f))
            }
        }
        com.abm.erp.core.GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Warehouse Stock (now)", fontWeight = FontWeight.SemiBold, color = com.abm.erp.theme.TextPrimary)
            Row(Modifier.fillMaxWidth()) {
                com.abm.erp.core.BrowseStatCell("Total On Hand", "%,.0f".format(totalStock), modifier = Modifier.weight(1f))
                com.abm.erp.core.BrowseStatCell("Product-Warehouse rows", "${stockLevels.size}", modifier = Modifier.weight(1f))
                com.abm.erp.core.BrowseStatCell("Low Stock", "$lowCount", if (lowCount > 0) com.abm.erp.theme.WarningAmber else com.abm.erp.theme.SuccessGreen, Modifier.weight(1f))
            }
        }
        com.abm.erp.core.GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("Damage / Wastage (this month)", fontWeight = FontWeight.SemiBold, color = com.abm.erp.theme.TextPrimary)
            Row(Modifier.fillMaxWidth()) {
                com.abm.erp.core.BrowseStatCell("Reports", "${monthDamage.size}", modifier = Modifier.weight(1f))
                com.abm.erp.core.BrowseStatCell("Damaged Qty", "%,.0f".format(monthDamage.sumOf { it.qty }), if (monthDamage.isNotEmpty()) com.abm.erp.theme.DangerRed else com.abm.erp.theme.TextPrimary, Modifier.weight(1f))
                Spacer(Modifier.weight(1f))
            }
            if (monthDamage.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                monthDamage.take(5).forEach { d ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${d.productName} · ${d.reason}", style = MaterialTheme.typography.labelSmall, color = com.abm.erp.theme.TextSecondary, maxLines = 1, modifier = Modifier.weight(1f))
                        Text("%,.0f".format(d.qty), style = MaterialTheme.typography.labelSmall, color = com.abm.erp.theme.DangerRed)
                    }
                }
            }
        }
        Text(
            "বিস্তারিত রিপোর্ট নিজ নিজ সেকশনে: Raw Material / Production / QC ট্যাবে, Warehouse-এ stock report, Damage ট্যাবে damage list।",
            style = MaterialTheme.typography.labelSmall, color = com.abm.erp.theme.TextSecondary,
        )
        Spacer(Modifier.height(20.dp))
    }
}
