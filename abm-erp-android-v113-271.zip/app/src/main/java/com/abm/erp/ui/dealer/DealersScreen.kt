package com.abm.erp.ui.dealer

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.abm.erp.core.GlassCard
import com.abm.erp.data.FirebaseSync
import com.abm.erp.data.MockRepository
import com.abm.erp.data.createCollection
import com.abm.erp.data.createCollectionWithMultipleAllocations
import com.abm.erp.data.rejectCollection
import com.abm.erp.data.verifyCollection
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.abm.erp.data.PartyType
import com.abm.erp.data.PermissionAction
import com.abm.erp.data.PermissionManager
import com.abm.erp.theme.DangerRed
import com.abm.erp.theme.ElectricCyan
import com.abm.erp.theme.Sky
import com.abm.erp.theme.SuccessGreen
import com.abm.erp.theme.TextPrimary
import com.abm.erp.theme.TextSecondary
import com.abm.erp.theme.WarningAmber

/**
 * Module 7 — Dealer Management (DMS). ViewModel delegates every action to
 * MockRepository/FirebaseSync (repository pattern) and every write already
 * runs through PermissionManager + audit log at the repository layer — the
 * canX() checks here only control what the UI shows/hides.
 */
class DealersScreenViewModel : ViewModel() {
    val dealers = MockRepository.dealers
    val dealerOrders = FirebaseSync.dealerOrders
    val collections = MockRepository.partyCollections

    fun setDealerOrderStatus(id: String, status: String) = FirebaseSync.setDealerOrderStatus(id, status)
    suspend fun createDealer(name: String, zone: String, phone: String, address: String, onRejected: (String) -> Unit = {}) = MockRepository.createDealer(name, zone, phone, address, onRejected = onRejected)
    fun deleteDealer(id: String) = MockRepository.deleteDealer(id)
    suspend fun restoreDealer(id: String) = MockRepository.restoreDealer(id)

    fun ledgerFor(dealerId: String) = MockRepository.partyLedgerFor(PartyType.DEALER, dealerId)
    fun visitsFor(dealerId: String) = MockRepository.visitLogsFor(PartyType.DEALER, dealerId)
    fun createCollection(dealerId: String, dealerName: String, amount: Double, method: String) =
        MockRepository.createCollection(PartyType.DEALER, dealerId, dealerName, amount, method)?.also { linkToActiveVisit(it.id) }
    fun verifyCollection(id: String) = MockRepository.verifyCollection(id)
    fun rejectCollection(id: String) = MockRepository.rejectCollection(id)

    fun canCreateDealer() = PermissionManager.canCurrentUser("dealer", PermissionAction.CREATE)
    fun canDeleteDealer() = PermissionManager.canCurrentUser("dealer", PermissionAction.DELETE)
    fun canApproveCollection() = PermissionManager.canCurrentUser("bill", PermissionAction.APPROVE)
    suspend fun duplicateDealerAction(id: String, onRejected: (String) -> Unit = {}) = MockRepository.duplicateDealer(id, onRejected)
    fun deleteDealerAction(id: String, onRejected: (String) -> Unit = {}) = MockRepository.deleteDealer(id, onRejected)
    suspend fun restoreDealerAction(id: String) = MockRepository.restoreDealer(id)
    suspend fun duplicateRetailerAction(id: String, onRejected: (String) -> Unit = {}) = MockRepository.duplicateRetailer(id, onRejected)
    suspend fun archiveRetailerAction(id: String, onRejected: (String) -> Unit = {}) = MockRepository.deleteRetailer(id, onRejected)
    suspend fun restoreRetailerAction(id: String) = MockRepository.restoreRetailer(id)
    fun creditUtilization(d: com.abm.erp.data.Dealer) = MockRepository.creditUtilization(d)
    fun creditUtilization(r: com.abm.erp.data.Retailer) = MockRepository.creditUtilization(r)
    fun inactiveDealers() = MockRepository.inactiveDealers()

    // ---- Module 8: Retailer / Outlet ----
    val retailers = MockRepository.retailers
    val salesRoutes = MockRepository.salesRoutes
    suspend fun createRetailer(name: String, phone: String, address: String, dealerId: String?, outletCategory: String, outletType: String, ownerName: String = "", altPhone: String = "", district: String = "", upazila: String = "", classification: String = "B", lat: Double? = null, lng: Double? = null, gpsAccuracyMeters: Double? = null, photoUri: String? = null, onRejected: (String) -> Unit = {}) =
        MockRepository.createRetailer(name = name, phone = phone, address = address, dealerId = dealerId, outletCategory = outletCategory, outletType = outletType, ownerName = ownerName, altPhone = altPhone, district = district, upazila = upazila, classification = classification, lat = lat, lng = lng, gpsAccuracyMeters = gpsAccuracyMeters, photoUri = photoUri, onRejected = onRejected)
    suspend fun deleteRetailer(id: String) = MockRepository.deleteRetailer(id)
    fun retailerLedgerFor(retailerId: String) = MockRepository.partyLedgerFor(PartyType.RETAILER, retailerId)
    fun retailerVisitsFor(retailerId: String) = MockRepository.visitLogsFor(PartyType.RETAILER, retailerId)
    fun createRoute(name: String, employeeId: String) = MockRepository.createRoute(name, null, employeeId, emptyList())
    fun assignOutletToRoute(routeId: String, retailerId: String) = MockRepository.assignOutletToRoute(routeId, retailerId)
    fun createRetailerCollection(retailerId: String, retailerName: String, amount: Double, method: String) =
        MockRepository.createCollection(PartyType.RETAILER, retailerId, retailerName, amount, method)?.also { linkToActiveVisit(it.id) }

    // v113-243 — linkVisitToCollection already existed, fully real (ties
    // a collection to whatever active check-in visit is running, feeding
    // the same real fraud/suspicious-location detection linkVisitToOrder
    // already got wired into), zero callers. Shared by both Dealer and
    // Retailer collection creation, both real UI callers of this
    // ViewModel — a harmless no-op whenever there's no active visit.
    private fun linkToActiveVisit(collectionId: String) {
        viewModelScope.launch { MockRepository.linkVisitToCollection(collectionId) }
    }
}

@Composable
fun DealersScreen(startTab: Int? = null, onBack: () -> Unit = {}, onNavigate: (String) -> Unit = {}, vm: DealersScreenViewModel = viewModel()) {
    // Dealer & Retailer Security — same real hierarchy-based visibility scope as
    // Retailer's OutletsTab, so Dealers are territory-restricted rather than
    // company-wide-visible by default.
    //
    // Decision 4 (v113-73): this screen used to hold the ONLY correct copy of that
    // three-branch rule, written out inline. That copy is now the shared accessor in
    // MockRepository.visibleDealersFor(...) / rememberVisibleDealers(). Same logic,
    // one implementation — which is the whole point, since the two invoice screens
    // that forgot to copy it are exactly where the territory hole was.
    val dealers = com.abm.erp.core.rememberVisibleDealers()
    val allOrders by vm.dealerOrders.collectAsState()
    val pending = allOrders.filter { it.status == "Pending" }
    var tab by remember { mutableStateOf(startTab ?: 0) }
    var selectedDealerId by remember { mutableStateOf<String?>(null) }
    var selectedRetailerId by remember { mutableStateOf<String?>(null) }
    var showAddDealer by remember { mutableStateOf(false) }
    var showAddRetailer by remember { mutableStateOf(false) }

    // Universal Search deep-link: if the person tapped a Dealer/Retailer search result, jump straight to its detail panel and the right tab.
    LaunchedEffect(Unit) {
        com.abm.erp.data.PendingSearchNavigation.consume("Dealer")?.let { id -> tab = 0; selectedDealerId = id }
        com.abm.erp.data.PendingSearchNavigation.consume("Retailer")?.let { id -> tab = 2; selectedRetailerId = id }
    }

    // QR Code Identity System — scanning instantly opens the matching
    // Dealer/Retailer profile. QR content is only ever the unique
    // dealerCode/retailerCode (never sensitive data), so the scan result
    // itself is safe to look up directly.
    val qrScanContext = androidx.compose.ui.platform.LocalContext.current
    // Decision 4 (v113-73) — same dedupe as the dealer list above; identical rule,
    // one implementation.
    val allRetailersForScan = com.abm.erp.core.rememberVisibleRetailers()
    val qrScanLauncher = androidx.activity.compose.rememberLauncherForActivityResult(com.journeyapps.barcodescanner.ScanContract()) { result ->
        val scannedCode = result?.contents ?: return@rememberLauncherForActivityResult
        when (val resolved = com.abm.erp.data.CodeRegistry.resolve(scannedCode)) {
            is com.abm.erp.data.CodeRegistry.ResolveResult.Found -> {
                when (resolved.type) {
                    com.abm.erp.data.CodeRegistry.CodeType.DEALER -> {
                        // Territory-scope preserved: CodeRegistry validates the code is a REAL dealer, but navigation only happens if it's within THIS user's visible (territory-filtered) list.
                        val visible = dealers.firstOrNull { it.id == resolved.id }
                        if (visible != null) {
                            tab = 0; selectedDealerId = visible.id
                            MockRepository.logAudit("Dealer", visible.id, "QR_SCANNED", reason = "scanned by ${MockRepository.currentUser.name}")
                        } else {
                            android.widget.Toast.makeText(qrScanContext, "এই Dealer আপনার এলাকার বাইরে — অ্যাক্সেস নেই।", android.widget.Toast.LENGTH_LONG).show()
                        }
                    }
                    com.abm.erp.data.CodeRegistry.CodeType.RETAILER -> {
                        val visible = allRetailersForScan.firstOrNull { it.id == resolved.id }
                        if (visible != null) {
                            tab = 2; selectedRetailerId = visible.id
                            MockRepository.logAudit("Retailer", visible.id, "QR_SCANNED", reason = "scanned by ${MockRepository.currentUser.name}")
                        } else {
                            android.widget.Toast.makeText(qrScanContext, "এই Retailer আপনার এলাকার বাইরে — অ্যাক্সেস নেই।", android.widget.Toast.LENGTH_LONG).show()
                        }
                    }
                    com.abm.erp.data.CodeRegistry.CodeType.EMPLOYEE -> {
                        MockRepository.logAudit("EmployeeProfile", resolved.id, "QR_SCANNED", reason = "scanned by ${MockRepository.currentUser.name}")
                        android.widget.Toast.makeText(qrScanContext, "Employee পাওয়া গেছে: ${resolved.label} — HR module থেকে দেখুন।", android.widget.Toast.LENGTH_LONG).show()
                    }
                    com.abm.erp.data.CodeRegistry.CodeType.CARTON -> {
                        android.widget.Toast.makeText(qrScanContext, "Carton code শনাক্ত হয়েছে — বিস্তারিত Production/Warehouse module থেকে দেখুন।", android.widget.Toast.LENGTH_LONG).show()
                    }
                    com.abm.erp.data.CodeRegistry.CodeType.PRODUCTION_BATCH, com.abm.erp.data.CodeRegistry.CodeType.WAREHOUSE_TRANSFER -> {
                        android.widget.Toast.makeText(qrScanContext, "${resolved.label} — Production/Warehouse module থেকে বিস্তারিত দেখুন, অথবা Universal Scanner ব্যবহার করুন।", android.widget.Toast.LENGTH_LONG).show()
                    }
                    com.abm.erp.data.CodeRegistry.CodeType.INVOICE, com.abm.erp.data.CodeRegistry.CodeType.COLLECTION, com.abm.erp.data.CodeRegistry.CodeType.PRODUCT, com.abm.erp.data.CodeRegistry.CodeType.DELIVERY -> {
                        android.widget.Toast.makeText(qrScanContext, "${resolved.label} — বিস্তারিত দেখতে Universal Scanner ব্যবহার করুন।", android.widget.Toast.LENGTH_LONG).show()
                    }
                    com.abm.erp.data.CodeRegistry.CodeType.UNKNOWN -> {}
                }
            }
            is com.abm.erp.data.CodeRegistry.ResolveResult.Ambiguous -> {
                MockRepository.logAudit("CodeRegistry", scannedCode, "AMBIGUOUS_SCAN", newValue = resolved.matches.toString())
                android.widget.Toast.makeText(qrScanContext, "এই কোড একাধিক রেকর্ডের সাথে মিলছে — ডেটা সমস্যা, Chairman-কে জানান।", android.widget.Toast.LENGTH_LONG).show()
            }
            com.abm.erp.data.CodeRegistry.ResolveResult.NotFound -> android.widget.Toast.makeText(qrScanContext, "কোনো মিলে যাওয়া Dealer/Retailer/Employee পাওয়া যায়নি।", android.widget.Toast.LENGTH_LONG).show()
            com.abm.erp.data.CodeRegistry.ResolveResult.Invalid -> android.widget.Toast.makeText(qrScanContext, "অবৈধ কোড।", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    // Security — prevent screenshots of this confidential list while it's on screen.
    val secureView = androidx.compose.ui.platform.LocalView.current
    DisposableEffect(Unit) {
        val window = (secureView.context as? android.app.Activity)?.window
        window?.setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE, android.view.WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE) }
    }

    val retailersForMini by MockRepository.retailers.collectAsState()
    val collectionsForMini by MockRepository.partyCollections.collectAsState()
    val todayForMini = java.time.LocalDate.now()
    val totalDealerDue = dealers.sumOf { it.dueBalance }
    val todayCollected = collectionsForMini.filter { it.createdAt.toLocalDate() == todayForMini }.sumOf { it.amount }
    val overLimitCount = dealers.count { it.dueBalance > it.creditLimit && it.creditLimit > 0 }

    Column(Modifier.fillMaxSize()) {
        if (startTab == null) {
        com.abm.erp.core.ModuleWorkspaceHeader("Dealers & Stock", "🏢", 0xFFB45CFF, 0xFF7A2EE0, iconVector = Icons.Filled.Storefront, miniDashboard = {
            com.abm.erp.core.ModuleStat("Dealers", "${dealers.size}", TextPrimary)
            com.abm.erp.core.ModuleStat("Retailers", "${retailersForMini.size}", TextPrimary)
            com.abm.erp.core.ModuleStat("Total Due", "৳${"%,.0f".format(totalDealerDue)}", if (totalDealerDue > 0) WarningAmber else SuccessGreen)
            com.abm.erp.core.ModuleStat("Collected Today", "৳${"%,.0f".format(todayCollected)}", SuccessGreen)
            com.abm.erp.core.ModuleStat("Over Limit", "$overLimitCount", if (overLimitCount > 0) DangerRed else SuccessGreen)
        }, quickActions = {
            AssistChip(onClick = { qrScanLauncher.launch(com.journeyapps.barcodescanner.ScanOptions().setPrompt("Dealer/Retailer QR স্ক্যান করুন").setBeepEnabled(true).setOrientationLocked(true)) }, label = { Text("📷 Scan QR") })
            if (vm.canCreateDealer()) AssistChip(onClick = { showAddDealer = true }, label = { Text("+ Add Dealer") })
        }, recentActivity = {
            com.abm.erp.core.ModuleRecentActivity(setOf("Dealer", "Retailer", "PartyCollection", "Collection"))
        })
        } else {
            val taskTitle = when (startTab) { 0 -> "Dealer Directory"; 1 -> "Collections"; 2 -> "Retailer Outlets"; 3 -> "Location Alerts"; 4 -> "Security Events"; else -> "Location Master" }
            com.abm.erp.core.TaskHeader(taskTitle, 0xFFB45CFF, 0xFF7A2EE0, onBack = onBack, iconVector = Icons.Filled.Storefront)
        }
        Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                qrScanLauncher.launch(com.journeyapps.barcodescanner.ScanOptions().setPrompt("Dealer/Retailer QR স্ক্যান করুন").setBeepEnabled(true).setOrientationLocked(true))
            }) { Text("📷 Scan QR") }
            if (vm.canCreateDealer() && tab == 0) {
                Button(onClick = { showAddDealer = true }) { Text("+ Add Dealer") }
            }
            if (vm.canCreateDealer() && tab == 2) {
                Button(onClick = { showAddRetailer = true }) { Text("+ Add Outlet") }
            }
        }
        Spacer(Modifier.height(8.dp))
        if (startTab == null) {
        ScrollableTabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Directory") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Collections") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Outlets") })
            Tab(selected = tab == 3, onClick = { tab = 3 }, text = { Text("Location Alerts") })
            Tab(selected = tab == 4, onClick = { tab = 4 }, text = { Text("Security Events") })
            Tab(selected = tab == 5, onClick = { tab = 5 }, text = { Text("Location Master") })
        }
        }
        Spacer(Modifier.height(12.dp))

        when (tab) {
            0 -> DirectoryTab(vm, dealers, pending) { selectedDealerId = it }
            1 -> CollectionsTab(vm, dealers)
            2 -> OutletsTab(vm) { selectedRetailerId = it }
            3 -> LocationAlertsTab()
            4 -> SecurityEventsTab()
            else -> LocationMasterAdminTab()
        }
        }
    }

    selectedDealerId?.let { id ->
        val dealer = dealers.firstOrNull { it.id == id }
        if (dealer != null) {
            // v113-244 — the person's own direct follow-up to v113-236:
            // full parity for this dealer's two most consequential legacy
            // actions (pending Approve/Reject, PIN) now exists in Dealer's
            // own ModuleBrowseDetail config (the new "Account" extraTab),
            // so this can finally redirect there instead of the old,
            // narrower DealerDetailPanel — the same rich design already
            // used everywhere else a Dealer is opened (List, Scanner,
            // Search). A full-size Dialog rather than restructuring this
            // already-complex function's own Column/tab layout — the same
            // proven "look full-screen via Dialog" technique this
            // codebase already uses for UniversalSearchDialog, since
            // ModuleBrowseDetail expects to own the whole screen and a
            // plain (non-Dialog) call here wouldn't overlay the existing
            // tab content, it would just render after it.
            val zones = remember(dealers) { dealers.map { it.zone }.filter { it.isNotBlank() }.distinct().sorted() }
            Dialog(
                onDismissRequest = { selectedDealerId = null },
                properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
            ) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    com.abm.erp.core.ModuleBrowseDetail(
                        com.abm.erp.core.rememberDealerBrowseConfig(zones), dealer,
                        onBack = { selectedDealerId = null }, onNavigate = onNavigate,
                    )
                }
            }
        }
    }

    if (showAddDealer) {
        Dialog(onDismissRequest = { showAddDealer = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                AddDealerForm(vm, onDone = { showAddDealer = false })
            }
        }
    }

    selectedRetailerId?.let { id ->
        val retailer = vm.retailers.collectAsState().value.firstOrNull { it.id == id }
        if (retailer != null) {
            Dialog(onDismissRequest = { selectedRetailerId = null }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                    RetailerDetailPanel(vm, retailer, onClose = { selectedRetailerId = null })
                }
            }
        }
    }

    if (showAddRetailer) {
        Dialog(onDismissRequest = { showAddRetailer = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                AddRetailerForm(vm, dealers, onDone = { showAddRetailer = false })
            }
        }
    }
}

@Composable
internal fun DirectoryTab(vm: DealersScreenViewModel, dealers: List<com.abm.erp.data.Dealer>, pending: List<com.abm.erp.data.DealerOrderRecord>, onOpenDealer: (String) -> Unit) {
    val directoryScope = androidx.compose.runtime.rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            val context = androidx.compose.ui.platform.LocalContext.current
            val isChairmanForExport = MockRepository.currentUser.role == com.abm.erp.data.UserRole.CHAIRMAN
            com.abm.erp.core.ModuleActionBar(
                onExport = if (!isChairmanForExport) null else {
                    {
                        val header = "Name,Zone,Classification,Due,CreditLimit,Sales90d\n"
                        val rows = dealers.joinToString("\n") { d -> com.abm.erp.core.toCsvRow(d.name, d.zone, d.classification, d.dueBalance, d.creditLimit, d.salesLast90Days) }
                        val file = java.io.File(context.getExternalFilesDir(null), "dealer_directory_${System.currentTimeMillis()}.csv")
                        file.writeText(header + rows)
                        MockRepository.logAudit("Dealer", "(list)", "EXPORT", newValue = "${dealers.size} records exported by ${MockRepository.currentUser.name}")
                        android.widget.Toast.makeText(context, "Saved: ${file.name}", android.widget.Toast.LENGTH_LONG).show()
                    }
                },
                onShare = if (!isChairmanForExport) null else {
                    {
                        val summary = "Dealer Directory (${dealers.size})\n" + dealers.take(20).joinToString("\n") { "${it.name} — ${it.zone} · Due ৳${it.dueBalance}" }
                        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, summary) }
                        MockRepository.logAudit("Dealer", "(list)", "SHARE", newValue = "${dealers.size} records shared by ${MockRepository.currentUser.name}")
                        try { context.startActivity(android.content.Intent.createChooser(intent, "Dealer Directory")) } catch (e: Exception) { android.widget.Toast.makeText(context, "No app found to share this.", android.widget.Toast.LENGTH_LONG).show() }
                    }
                },
            )
            if (isChairmanForExport) {
                IconButton(onClick = {
                    val printText = "Dealer Directory (${dealers.size})\n\n" + dealers.joinToString("\n") { "${it.dealerCode}  ${it.name}  ${it.zone}  Due:৳${it.dueBalance}" }
                    val webView = android.webkit.WebView(context)
                    webView.loadDataWithBaseURL(null, "<pre>${android.text.Html.escapeHtml(printText)}</pre>", "text/html", "UTF-8", null)
                    val printManager = context.getSystemService(android.content.Context.PRINT_SERVICE) as android.print.PrintManager
                    val jobName = "Dealer Directory"
                    val adapter = webView.createPrintDocumentAdapter(jobName)
                    printManager.print(jobName, adapter, android.print.PrintAttributes.Builder().build())
                    MockRepository.logAudit("Dealer", "(list)", "PRINT", newValue = "${dealers.size} records printed by ${MockRepository.currentUser.name}")
                }) { Icon(Icons.Filled.Print, contentDescription = "Print") }
                IconButton(onClick = {
                    val fullText = "Dealer Directory (${dealers.size})\n" + dealers.joinToString("\n") { "${it.dealerCode}\t${it.name}\t${it.zone}\t${it.dueBalance}" }
                    val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Dealer Directory", fullText))
                    MockRepository.logAudit("Dealer", "(list)", "COPY", newValue = "${dealers.size} records copied by ${MockRepository.currentUser.name}")
                    android.widget.Toast.makeText(context, "Copied ${dealers.size} records", android.widget.Toast.LENGTH_SHORT).show()
                }) { Icon(Icons.Filled.ContentCopy, contentDescription = "Copy List") }
            }
        }
        var searchQuery by remember { mutableStateOf("") }
        var zoneFilter by remember { mutableStateOf<String?>(null) }
        var classFilter by remember { mutableStateOf<String?>(null) }
        var riskFilter by remember { mutableStateOf<com.abm.erp.data.RiskBand?>(null) }
        val zones = remember(dealers) { dealers.map { it.zone }.distinct().sorted() }
        OutlinedTextField(
            value = searchQuery, onValueChange = { searchQuery = it },
            placeholder = { Text("Search by name or phone…") },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            FilterChip(selected = zoneFilter == null, onClick = { zoneFilter = null }, label = { Text("All Areas") })
            zones.forEach { z -> FilterChip(selected = zoneFilter == z, onClick = { zoneFilter = z }, label = { Text(z) }) }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = classFilter == null, onClick = { classFilter = null }, label = { Text("All Tiers") })
            listOf("A", "B", "C").forEach { c -> FilterChip(selected = classFilter == c, onClick = { classFilter = c }, label = { Text("Tier $c") }) }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = riskFilter == null, onClick = { riskFilter = null }, label = { Text("All Risk") })
            FilterChip(selected = riskFilter == com.abm.erp.data.RiskBand.GREEN, onClick = { riskFilter = com.abm.erp.data.RiskBand.GREEN }, label = { Text("Healthy", color = SuccessGreen) })
            FilterChip(selected = riskFilter == com.abm.erp.data.RiskBand.YELLOW, onClick = { riskFilter = com.abm.erp.data.RiskBand.YELLOW }, label = { Text("Watch", color = WarningAmber) })
            FilterChip(selected = riskFilter == com.abm.erp.data.RiskBand.RED, onClick = { riskFilter = com.abm.erp.data.RiskBand.RED }, label = { Text("At Risk", color = DangerRed) })
        }
        val visitLogsForFilter by MockRepository.visitLogs.collectAsState()
        val routes = remember(dealers) { dealers.mapNotNull { it.territoryId }.distinct().sorted() }
        val officers = remember(visitLogsForFilter) { visitLogsForFilter.filter { it.partyType == PartyType.DEALER }.map { it.employeeName }.distinct().sorted() }
        var routeFilter by remember { mutableStateOf<String?>(null) }
        var officerFilter by remember { mutableStateOf<String?>(null) }
        if (routes.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                FilterChip(selected = routeFilter == null, onClick = { routeFilter = null }, label = { Text("All Routes") })
                routes.forEach { r -> FilterChip(selected = routeFilter == r, onClick = { routeFilter = r }, label = { Text(MockRepository.territoryName(r)) }) }
            }
        }
        if (officers.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text("Officer (যিনি visit করেছেন)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                FilterChip(selected = officerFilter == null, onClick = { officerFilter = null }, label = { Text("All Officers") })
                officers.forEach { o -> FilterChip(selected = officerFilter == o, onClick = { officerFilter = o }, label = { Text(o) }) }
            }
        }
        Spacer(Modifier.height(10.dp))
        val dealerIdsVisitedByOfficer = remember(visitLogsForFilter, officerFilter) {
            if (officerFilter == null) null else visitLogsForFilter.filter { it.partyType == PartyType.DEALER && it.employeeName == officerFilter }.map { it.partyId }.toSet()
        }
        val filteredDealers = remember(dealers, searchQuery, zoneFilter, classFilter, riskFilter, routeFilter, dealerIdsVisitedByOfficer) {
            dealers.filter { d ->
                (searchQuery.isBlank() || d.name.contains(searchQuery, ignoreCase = true) || d.phone.contains(searchQuery)) &&
                    (zoneFilter == null || d.zone == zoneFilter) &&
                    (classFilter == null || d.classification == classFilter) &&
                    (riskFilter == null || MockRepository.riskBand(d) == riskFilter) &&
                    (routeFilter == null || d.territoryId == routeFilter) &&
                    (dealerIdsVisitedByOfficer == null || d.id in dealerIdsVisitedByOfficer)
            }
        }
        val inactive = remember(dealers) { vm.inactiveDealers() }
        if (inactive.isNotEmpty()) {
            GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                Text("⚠ Inactive Dealers (${inactive.size}) — কোনো ৯০-দিনের sales নেই", color = WarningAmber, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelMedium)
                inactive.take(5).forEach { d -> Text("• ${d.name} (${d.zone})", style = MaterialTheme.typography.bodySmall, color = TextSecondary) }
            }
        }
        if (pending.isNotEmpty()) {
            Text("Pending dealer orders (${pending.size})", style = MaterialTheme.typography.titleMedium, color = WarningAmber)
            Spacer(Modifier.height(8.dp))
            pending.forEach { o ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Text(o.dealerName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Text("${o.product} × ${o.qty}", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.setDealerOrderStatus(o.id, "Approved") }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) {
                            Text("Approve")
                        }
                        OutlinedButton(onClick = { vm.setDealerOrderStatus(o.id, "Rejected") }) {
                            Text("Reject", color = DangerRed)
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        Text("Dealers in your territory", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filteredDealers, key = { it.id }) { d ->
                val dealerLedger by vm.ledgerFor(d.id).collectAsState(initial = emptyList())
                GlassCard(modifier = Modifier.fillMaxWidth().clickable { onOpenDealer(d.id) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(d.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(d.zone, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Spacer(Modifier.height(4.dp))
                            Text("Due: ৳${"%,.0f".format(d.dueBalance)} · 90-day sales: ৳${"%,.0f".format(d.salesLast90Days)}", style = MaterialTheme.typography.bodySmall)
                            if (d.creditLimit > 0) {
                                Text("Credit limit: ৳${"%,.0f".format(d.creditLimit)} · Utilization: ${(vm.creditUtilization(d) * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = if (d.dueBalance >= d.creditLimit) DangerRed else TextSecondary)
                            }
                            val failedSyncIds by MockRepository.failedSyncIds.collectAsState()
                            if (d.id in failedSyncIds) {
                                Text("⚠ Sync pending — will retry", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
                            }
                        }
                        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(6.dp), color = classificationColor(d.classification).copy(alpha = 0.15f)) {
                            Text(" ${d.classification} ", modifier = Modifier.padding(4.dp), color = classificationColor(d.classification), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Dealer", entityId = d.id, entityLabel = d.name,
                            shareText = "${d.name} — ${d.zone}\nDue: ৳${d.dueBalance}\n90-day sales: ৳${d.salesLast90Days}",
                            isDeleted = d.isDeleted,
                            onDuplicate = { onError -> directoryScope.launch { vm.duplicateDealerAction(d.id, onRejected = onError) } },
                            onArchive = { onError -> vm.deleteDealerAction(d.id, onRejected = onError) },
                            canArchive = vm.canDeleteDealer(),
                            archiveBlockedReasonOverride = if (d.dueBalance > 0) "এই ডিলারের বকেয়া ৳${"%,.0f".format(d.dueBalance)} আছে — বকেয়া ক্লিয়ার না হওয়া পর্যন্ত archive করা যাবে না।" else null,
                            onRestore = { directoryScope.launch { vm.restoreDealerAction(d.id) } },
                            csvHeader = "Name,Zone,Classification,Due,CreditLimit,Sales90d",
                            csvRow = com.abm.erp.core.toCsvRow(d.name, d.zone, d.classification, d.dueBalance, d.creditLimit, d.salesLast90Days),
                            historyLabel = "Dealer History",
                            historyItems = dealerLedger.map { "${it.reason}: ${it.type} ৳${"%,.0f".format(it.amount)} — ${it.createdAt.toLocalDate()}" },
                        )
                    }
                }
            }
        }
    }
}

private fun classificationColor(tier: String) = when (tier) {
    "A" -> SuccessGreen
    "C" -> DangerRed
    else -> WarningAmber
}

@Composable
internal fun CollectionsTab(vm: DealersScreenViewModel, dealers: List<com.abm.erp.data.Dealer>) {
    val collections by vm.collections.collectAsState()
    val dealerCollections = collections.filter { it.partyType == PartyType.DEALER }
    var showNewCollection by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current

    Column(Modifier.fillMaxSize()) {
        Button(onClick = { showNewCollection = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Record Collection") }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(dealerCollections, key = { it.id }) { c ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(c.partyName, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("৳${"%,.0f".format(c.amount)} · ${c.method} · by ${c.collectedBy}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            com.abm.erp.core.StatusPill(c.status)
                            com.abm.erp.core.RecordQrButton(
                                code = c.collectionNo.ifBlank { c.id },
                                entityType = "Collection", entityId = c.id,
                                title = "Collection — ${c.partyName}",
                                subtitle = "৳${"%,.0f".format(c.amount)} · ${c.method}",
                            )
                        }
                        if (c.status == "PENDING" && vm.canApproveCollection()) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(onClick = { MockRepository.verifyCollection(c.id, onRejected = { reason -> android.widget.Toast.makeText(context, reason, android.widget.Toast.LENGTH_LONG).show() }) }) { Text("Verify") }
                                TextButton(onClick = { vm.rejectCollection(c.id) }) { Text("Reject", color = DangerRed) }
                            }
                        }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Collection", entityId = c.id, entityLabel = c.partyName,
                            shareText = "Collection: ${c.partyName}\nAmount: ৳${c.amount}\nMethod: ${c.method}\nStatus: ${c.status}",
                            csvHeader = "Party,Amount,Method,Status,CollectedBy",
                            csvRow = com.abm.erp.core.toCsvRow(c.partyName, c.amount, c.method, c.status, c.collectedBy),
                        )
                    }
                }
            }
        }
    }

    if (showNewCollection) {
        Dialog(onDismissRequest = { showNewCollection = false }, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(modifier = Modifier.fillMaxSize(), color = com.abm.erp.theme.DashBg) {
                Column(Modifier.fillMaxSize()) {
                    com.abm.erp.core.ModuleGradientHeader("Record Collection", "💵", 0xFFF85606, 0xFFC23F00, iconVector = Icons.Filled.AccountBalanceWallet)
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showNewCollection = false }) { Text("✕ Close") }
                    }
                    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp).verticalScroll(rememberScrollState())) {
                        NewCollectionForm(dealers, onSubmit = { dealerId, dealerName, amount, method, allocations ->
                            if (allocations.isEmpty()) {
                                vm.createCollection(dealerId, dealerName, amount, method)
                            } else {
                                MockRepository.createCollectionWithMultipleAllocations(
                                    com.abm.erp.data.PartyType.DEALER, dealerId, dealerName, amount, method,
                                    allocations.map { (invId, amt) -> invId to amt },
                                )
                            }
                            showNewCollection = false
                        })
                        Spacer(Modifier.height(24.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun NewCollectionForm(dealers: List<com.abm.erp.data.Dealer>, onSubmit: (String, String, Double, String, Map<String, Double>) -> Unit) {
    var selectedDealer by remember { mutableStateOf<com.abm.erp.data.Dealer?>(null) }
    var amountText by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("CASH") }
    var expanded by remember { mutableStateOf(false) }
    val allocations = remember { mutableStateMapOf<String, String>() }
    var isSubmitting by remember { mutableStateOf(false) }
    val submitScope = androidx.compose.runtime.rememberCoroutineScope()

    val unpaidInvoices = remember(selectedDealer) {
        selectedDealer?.let { d -> MockRepository.salesInvoices.value.filter { !it.isDeleted && it.dealerId == d.id && it.status != "PAID" && it.status != "CANCELLED" } } ?: emptyList()
    }

    Column(Modifier.padding(16.dp).heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
        Text("Record Dealer Collection", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selectedDealer?.name ?: "Select dealer")
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                dealers.forEach { d ->
                    DropdownMenuItem(text = { Text(d.name) }, onClick = { selectedDealer = d; expanded = false; allocations.clear() })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = amountText, onValueChange = { amountText = it }, label = { Text("Amount (৳)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("CASH", "BANK", "MOBILE_BANKING", "CHEQUE").forEach { m ->
                FilterChip(selected = method == m, onClick = { method = m }, label = { Text(m) })
            }
        }
        if (unpaidInvoices.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Text("Allocate against invoice(s) — ঐচ্ছিক, না দিলে unallocated advance হিসেবে জমা হবে:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Spacer(Modifier.height(6.dp))
            unpaidInvoices.forEach { inv ->
                val remaining = inv.netAfterDiscount - inv.paidAmount
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${inv.invoiceNo} (due ৳${"%,.0f".format(remaining)})", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = allocations[inv.id] ?: "", onValueChange = { allocations[inv.id] = it },
                        modifier = Modifier.width(100.dp), singleLine = true, label = { Text("৳") },
                    )
                }
            }
            val allocatedSum = allocations.values.mapNotNull { it.toDoubleOrNull() }.sum()
            val totalAmount = amountText.toDoubleOrNull() ?: 0.0
            if (allocatedSum > 0) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "Allocated: ৳${"%,.0f".format(allocatedSum)} of ৳${"%,.0f".format(totalAmount)}" + if (allocatedSum > totalAmount) " — allocation total-এর চেয়ে বেশি!" else "",
                    style = MaterialTheme.typography.labelSmall, color = if (allocatedSum > totalAmount) DangerRed else TextSecondary,
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = {
                if (isSubmitting) return@Button
                val amt = amountText.toDoubleOrNull() ?: return@Button
                if (amt <= 0.0) return@Button
                val d = selectedDealer ?: return@Button
                val allocMap = allocations.mapNotNull { (invId, v) -> v.toDoubleOrNull()?.let { invId to it } }.toMap()
                if (allocMap.values.sum() > amt + 0.01) return@Button
                isSubmitting = true
                submitScope.launch { kotlinx.coroutines.delay(1200); isSubmitting = false }
                onSubmit(d.id, d.name, amt, method, allocMap)
            },
            enabled = !isSubmitting && selectedDealer != null && (amountText.toDoubleOrNull() ?: 0.0) > 0.0 && allocations.values.mapNotNull { it.toDoubleOrNull() }.sum() <= (amountText.toDoubleOrNull() ?: 0.0) + 0.01,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Submit for verification") }
    }
}

@Composable
internal fun AddDealerForm(vm: DealersScreenViewModel, onDone: () -> Unit) {
    val dealerFormScope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var zone by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var adminSelection by remember { mutableStateOf(com.abm.erp.ui.core.AdminSelection()) }
    // v113-147 — dealer photo slot, matching the retailer form which already has one.
    // Uses the same GetContent picker pattern already proven elsewhere in this app.
    var dealerPhotoUri by remember { mutableStateOf<android.net.Uri?>(null) }
    val dealerPhotoLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent(),
    ) { uri -> dealerPhotoUri = uri }
    // Phase 1 — full field set.
    var proprietorName by remember { mutableStateOf("") }
    var altPhone by remember { mutableStateOf("") }
    var nationalId by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var marketName by remember { mutableStateOf("") }
    var openingBalance by remember { mutableStateOf("") }
    var creditLimit by remember { mutableStateOf("") }
    var paymentTermsDays by remember { mutableStateOf("") }
    var classification by remember { mutableStateOf("B") }
    var tradeLicenseNumber by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var assignedEmployeeId by remember { mutableStateOf<String?>(null) }
    var assignedManagerId by remember { mutableStateOf<String?>(null) }
    var gps by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    // v113-268 — the person's own direct request: Dealer GPS capture
    // should match Retailer's exactly — accuracy included, not just the
    // raw coordinate pair.
    var gpsAccuracy by remember { mutableStateOf<Double?>(null) }
    var gpsError by remember { mutableStateOf<String?>(null) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val employees by MockRepository.employeeProfiles.collectAsState()

    fun tagLocationNow() {
        val hasPermission = androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!hasPermission) { gpsError = "Location permission needed."; return }
        val client = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(context)
        try {
            @Suppress("MissingPermission")
            client.lastLocation.addOnSuccessListener { loc ->
                if (loc != null) { gps = loc.latitude to loc.longitude; gpsAccuracy = loc.accuracy.toDouble(); gpsError = null } else gpsError = "No recent GPS fix — move to an open area and try again."
            }.addOnFailureListener { gpsError = it.message ?: "Couldn't fetch location." }
        } catch (e: SecurityException) { gpsError = "Location permission needed." }
    }

    Column(Modifier.padding(16.dp).heightIn(max = 620.dp).verticalScroll(rememberScrollState())) {
        Text("Dealer Registration", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        // v113-147 — dealer photo. Same tap-a-box picker the product form uses.
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(56.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                    .background(Color(0xFFF0F2F6)).clickable { dealerPhotoLauncher.launch("image/*") },
                contentAlignment = Alignment.Center,
            ) {
                if (dealerPhotoUri != null) {
                    androidx.compose.foundation.Image(
                        painter = coil.compose.rememberAsyncImagePainter(dealerPhotoUri),
                        contentDescription = "Dealer photo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    )
                } else {
                    Text("📷", fontSize = 20.sp)
                }
            }
            Spacer(Modifier.width(10.dp))
            Text(
                if (dealerPhotoUri != null) "ছবি নির্বাচিত — বদলাতে ট্যাপ করুন" else "দোকান/মালিকের ছবি (ঐচ্ছিক)",
                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
            )
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Dealer/business name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = proprietorName, onValueChange = { proprietorName = it }, label = { Text("Proprietor/contact person") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Mobile number") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = altPhone, onValueChange = { altPhone = it }, label = { Text("Alternate mobile (optional)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = nationalId, onValueChange = { nationalId = it }, label = { Text("National ID (optional)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email (optional)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Full address") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text("Division / District / Upazila / Union", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        com.abm.erp.ui.core.AdminLocationCascadeSelector(
            selection = adminSelection,
            onSelectionChange = { newSel ->
                adminSelection = newSel
                val locs = MockRepository.administrativeLocations.value.associateBy { it.id }
                val distName = locs[newSel.districtId]?.nameEn
                val upzName = locs[newSel.upazilaId]?.nameEn
                zone = listOfNotNull(upzName, distName).joinToString(", ").ifBlank { zone }
            },
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = marketName, onValueChange = { marketName = it }, label = { Text("Market/Bazar") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = zone, onValueChange = { zone = it }, label = { Text("Zone / district (editable)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { tagLocationNow() }) {
                Text(gps?.let { "📍 Captured: ${"%.5f".format(it.first)}, ${"%.5f".format(it.second)}" } ?: "📍 Capture GPS location")
            }
        }
        gpsError?.let { Text(it, color = WarningAmber, style = MaterialTheme.typography.labelSmall) }
        Spacer(Modifier.height(8.dp))
        Text("Assigned employee / SR", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            employees.filter { it.hasActiveAccess }.take(30).forEach { e ->
                FilterChip(selected = assignedEmployeeId == e.id, onClick = { assignedEmployeeId = e.id }, label = { Text(e.fullName, style = MaterialTheme.typography.labelSmall) })
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Assigned manager", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            employees.filter { it.hasActiveAccess && it.role != com.abm.erp.data.UserRole.SR }.take(30).forEach { e ->
                FilterChip(selected = assignedManagerId == e.id, onClick = { assignedManagerId = e.id }, label = { Text(e.fullName, style = MaterialTheme.typography.labelSmall) })
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = openingBalance, onValueChange = { openingBalance = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Opening balance (৳)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = creditLimit, onValueChange = { creditLimit = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Credit limit (৳)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = paymentTermsDays, onValueChange = { paymentTermsDays = it.filter(Char::isDigit) }, label = { Text("Payment terms (days)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text("Dealer category", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("A", "B", "C").forEach { c -> FilterChip(selected = classification == c, onClick = { classification = c }, label = { Text(c) }) }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = tradeLicenseNumber, onValueChange = { tradeLicenseNumber = it }, label = { Text("Trade licence number (optional)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
        error?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 6.dp)) }
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = {
                dealerFormScope.launch {
                    val created = MockRepository.createDealer(
                        name = name, zone = zone, phone = phone, address = address, territoryId = null,
                        proprietorName = proprietorName, altPhone = altPhone,
                        nationalId = nationalId.ifBlank { null }, email = email.ifBlank { null },
                        divisionId = adminSelection.divisionId, districtId = adminSelection.districtId,
                        upazilaId = adminSelection.upazilaId, unionId = adminSelection.unionId,
                        marketName = marketName.ifBlank { null }, lat = gps?.first, lng = gps?.second, gpsAccuracyMeters = gpsAccuracy,
                        assignedEmployeeId = assignedEmployeeId, assignedManagerId = assignedManagerId,
                        openingBalance = openingBalance.toDoubleOrNull() ?: 0.0, creditLimit = creditLimit.toDoubleOrNull() ?: 0.0,
                        paymentTermsDays = paymentTermsDays.toIntOrNull() ?: 0, classification = classification,
                        tradeLicenseNumber = tradeLicenseNumber.ifBlank { null }, notes = notes.ifBlank { null },
                        photoUri = dealerPhotoUri?.toString(),
                        onRejected = { reason -> error = reason },
                    )
                    if (created != null) onDone()
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Register Dealer (submits for approval)") }
    }
}

@Composable
internal fun DealerDetailPanel(vm: DealersScreenViewModel, dealer: com.abm.erp.data.Dealer, onClose: () -> Unit, onNavigate: (String) -> Unit = {}) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var subTab by remember { mutableStateOf(0) }
    var showSetPin by remember { mutableStateOf(false) }
    if (!dealer.isActive) {
        var showReject by remember { mutableStateOf(false) }
        Surface(color = WarningAmber.copy(alpha = 0.12f), shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp)) {
                Text("⏳ Application pending approval", fontWeight = FontWeight.Bold, color = WarningAmber, style = MaterialTheme.typography.labelMedium)
                var approveDlrError by remember { mutableStateOf<String?>(null) }
                approveDlrError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                    Button(onClick = { val ok = MockRepository.approveDealer(dealer.id, onRejected = { e -> approveDlrError = e }); if (ok) onClose() }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) { Text("Approve") }
                    OutlinedButton(onClick = { showReject = true }) { Text("Reject", color = DangerRed) }
                }
            }
        }
        if (showReject) {
            var rejectReason by remember { mutableStateOf("") }
            Dialog(onDismissRequest = { showReject = false }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Reject Application — ${dealer.name}", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = rejectReason, onValueChange = { rejectReason = it }, label = { Text("Reason") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(10.dp))
                        var rejectDealerError by remember { mutableStateOf<String?>(null) }
                        rejectDealerError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                        Button(onClick = { val ok = MockRepository.rejectDealer(dealer.id, rejectReason, onRejected = { e -> rejectDealerError = e }); if (ok) { showReject = false; onClose() } }, modifier = Modifier.fillMaxWidth()) { Text("Confirm Reject") }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(if (dealer.pinHash != null) "✓ Login PIN set" else "⚠ No login PIN set", style = MaterialTheme.typography.labelSmall, color = if (dealer.pinHash != null) SuccessGreen else WarningAmber)
        TextButton(onClick = { showSetPin = true }) { Text(if (dealer.pinHash != null) "Reset PIN" else "Set PIN") }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("Stock: ${dealer.stockUnits} units", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
        TextButton(onClick = { onClose(); onNavigate("dealer_stock/${dealer.id}") }) { Text("📦 View Product Breakdown") }
    }
    var showDealerQr by remember { mutableStateOf(false) }
    TextButton(onClick = {
        showDealerQr = !showDealerQr
        if (showDealerQr) MockRepository.logAudit("Dealer", dealer.id, "QR_VIEWED", reason = "by ${MockRepository.currentUser.name}")
    }) { Text(if (showDealerQr) "Hide QR Code" else "🔳 Dealer QR Code") }
    if (showDealerQr) {
        val dealerQrBitmap = remember(dealer.dealerCode) { com.abm.erp.util.QrCodeGenerator.generate(dealer.dealerCode.ifBlank { dealer.id }, 300) }
        Image(bitmap = dealerQrBitmap.asImageBitmap(), contentDescription = "QR code for ${dealer.name}", modifier = Modifier.size(140.dp))
        Text(dealer.dealerCode.ifBlank { dealer.id }, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    }
    if (showSetPin) {
        var newPin by remember { mutableStateOf("") }
        var pinError by remember { mutableStateOf<String?>(null) }
        Dialog(onDismissRequest = { showSetPin = false }) {
            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Set Login PIN — ${dealer.name}", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = newPin, onValueChange = { newPin = it.filter(Char::isDigit).take(5) }, label = { Text("New PIN (4-5 digits, not sequential/repeated)") }, modifier = Modifier.fillMaxWidth())
                    pinError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { if (!MockRepository.setDealerPin(dealer.id, newPin)) pinError = "খুব সহজ PIN — অন্যটা বেছে নিন।" else showSetPin = false },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Save") }
                }
            }
        }
    }
    val ledger by vm.ledgerFor(dealer.id).collectAsState(initial = emptyList())
    val visits by vm.visitsFor(dealer.id).collectAsState(initial = emptyList())
    val allInvoices by MockRepository.salesInvoices.collectAsState()
    val dealerInvoices = remember(allInvoices, dealer.id) { allInvoices.filter { !it.isDeleted && it.dealerId == dealer.id }.sortedBy { it.createdAt } }
    val lifetimeTotal = dealerInvoices.sumOf { it.total }
    val firstPurchaseDate = dealerInvoices.minByOrNull { it.createdAt }?.createdAt?.toLocalDate()
    val nextVisitSuggestion = remember(visits) {
        val last = visits.maxByOrNull { it.checkInAt }?.checkInAt
        last?.plusDays(30)?.toLocalDate()
    }

    Column(Modifier.padding(16.dp).heightIn(max = 560.dp).widthIn(max = 400.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(dealer.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${dealer.zone} · Tier ${dealer.classification}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            Row {
                val statementContext = androidx.compose.ui.platform.LocalContext.current
                IconButton(onClick = {
                    try {
                        val file = com.abm.erp.core.exportDealerStatementPdf(statementContext, dealer, ledger)
                        com.abm.erp.core.shareStructuredPdf(statementContext, file, "Statement — ${dealer.name}")
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(statementContext, "Statement PDF তৈরি ব্যর্থ হয়েছে: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                    }
                }) { Text("📄") }
                IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = "Close") }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text("Due: ৳${"%,.0f".format(dealer.dueBalance)}" + if (dealer.creditLimit > 0) " / limit ৳${"%,.0f".format(dealer.creditLimit)}" else "", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            val healthScore = remember(dealer.id) { MockRepository.dealerHealthScore(dealer) }
            Column {
                Text("Health Score", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text("$healthScore/100", fontWeight = FontWeight.Bold, color = when { healthScore >= 65 -> SuccessGreen; healthScore >= 40 -> WarningAmber; else -> DangerRed })
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text("Last Visit", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text(visits.maxByOrNull { it.checkInAt }?.checkInAt?.toLocalDate()?.toString() ?: "কখনো না", style = MaterialTheme.typography.bodySmall)
            }
            if (dealer.phone.isNotBlank()) {
                val callContext = androidx.compose.ui.platform.LocalContext.current
                IconButton(onClick = {
                    try {
                        callContext.startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:${dealer.phone}")))
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(callContext, "Call করা যায়নি।", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }) { Icon(Icons.Filled.Call, contentDescription = "Call ${dealer.name}") }
                // v113-135 — real SMS + WhatsApp handoff beside the existing real
                // Call action. Both are plain Intents to the device's own apps —
                // no backend/API key needed, so these are genuinely functional
                // rather than an "integration required" placeholder. Each carries
                // its own real failure path (no SMS app / WhatsApp not installed).
                IconButton(onClick = {
                    try {
                        callContext.startActivity(android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:${dealer.phone}")))
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(callContext, "SMS app পাওয়া যায়নি।", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }) { Icon(Icons.Filled.MarkunreadMailbox, contentDescription = "SMS ${dealer.name}") }
                IconButton(onClick = {
                    try {
                        val digits = dealer.phone.filter { it.isDigit() }
                        val intl = if (digits.startsWith("880")) digits else "88" + digits.removePrefix("0").let { d -> if (d.startsWith("1")) "0$d" else d }
                        callContext.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://wa.me/$intl")))
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(callContext, "WhatsApp খোলা যায়নি।", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }) { Icon(Icons.Filled.Send, contentDescription = "WhatsApp ${dealer.name}") }
            }
        }
        if (nextVisitSuggestion != null) {
            Spacer(Modifier.height(4.dp))
            Text("পরবর্তী visit সুপারিশ: $nextVisitSuggestion (শেষ visit-এর ৩০ দিন পর)", style = MaterialTheme.typography.labelSmall, color = Sky)
        }
        Spacer(Modifier.height(10.dp))
        ScrollableTabRow(selectedTabIndex = subTab) {
            Tab(selected = subTab == 0, onClick = { subTab = 0 }, text = { Text("Ledger") })
            Tab(selected = subTab == 1, onClick = { subTab = 1 }, text = { Text("Visits") })
            Tab(selected = subTab == 2, onClick = { subTab = 2 }, text = { Text("Notes") })
            Tab(selected = subTab == 3, onClick = { subTab = 3 }, text = { Text("Insights") })
            Tab(selected = subTab == 4, onClick = { subTab = 4 }, text = { Text("Timeline") })
        }
        Spacer(Modifier.height(10.dp))
        when (subTab) {
            0 -> LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(ledger, key = { it.id }) { e ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(e.reason, style = MaterialTheme.typography.bodySmall)
                            Text("balance after: ৳${"%,.0f".format(e.balanceAfter)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Text(
                            (if (e.type == "DEBIT") "+" else "−") + "৳${"%,.0f".format(e.amount)}",
                            color = if (e.type == "DEBIT") WarningAmber else SuccessGreen, fontWeight = FontWeight.Bold,
                        )
                    }
                }
                if (ledger.isEmpty()) item { Text("এখনো কোনো ledger entry নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
            }
            1 -> LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                val timeline = visits.sortedByDescending { it.checkInAt }
                items(timeline, key = { it.id }) { v ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${v.employeeName} — ${v.purpose}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            Text(
                                "In: ${v.checkInAt.toLocalDate()} ${v.checkInAt.toLocalTime()}" + (v.checkOutAt?.let { " · Out: ${it.toLocalTime()}" } ?: " · checkout নেই"),
                                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                            )
                        }
                        com.abm.erp.core.UniversalActionMenu(moduleReference = "Visit", entityId = v.id, entityLabel = v.employeeName, shareText = "Visit by ${v.employeeName} — ${v.purpose}\n${v.checkInAt}", csvHeader = "Employee,Purpose,CheckIn", csvRow = com.abm.erp.core.toCsvRow(v.employeeName, v.purpose, v.checkInAt))
                    }
                }
                if (visits.isEmpty()) item { Text("এখনো কোনো visit রেকর্ড নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
            }
            2 -> {
                var noteText by remember { mutableStateOf("") }
                val notesLog by MockRepository.activityLogFor("Dealer", dealer.id).collectAsState(initial = emptyList())
                val notes = remember(notesLog) { notesLog.filter { it.action == "NOTE" }.sortedByDescending { it.timestamp } }
                Column {
                    OutlinedTextField(
                        value = noteText, onValueChange = { noteText = it },
                        placeholder = { Text("একটা note লিখুন…") }, modifier = Modifier.fillMaxWidth(), minLines = 2,
                    )
                    Spacer(Modifier.height(6.dp))
                    Button(
                        onClick = {
                            if (noteText.isNotBlank()) {
                                MockRepository.logAudit("Dealer", dealer.id, "NOTE", newValue = noteText)
                                noteText = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Add Note") }
                    Spacer(Modifier.height(10.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(notes) { n ->
                            Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Text(n.newValueJson ?: "", style = MaterialTheme.typography.bodySmall)
                                Text("${n.performedBy} · ${n.timestamp}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                        if (notes.isEmpty()) item { Text("এখনো কোনো note নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
            3 -> {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    val eligibility = remember(dealer.id, dealer.weeklyPaidAmount, dealer.monthlyTarget) { MockRepository.checkWeeklyDueEligibility(dealer.id) }
                    Text("Weekly 50% Due Rule", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    var targetInput by remember(dealer.id) { mutableStateOf(if (dealer.monthlyTarget > 0) dealer.monthlyTarget.toInt().toString() else "") }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = targetInput, onValueChange = { targetInput = it }, label = { Text("Monthly Target (৳)") },
                            singleLine = true, modifier = Modifier.weight(1f),
                        )
                        Button(onClick = { targetInput.toDoubleOrNull()?.let { MockRepository.setDealerMonthlyTarget(dealer.id, it, onRejected = { e -> android.widget.Toast.makeText(context, e, android.widget.Toast.LENGTH_LONG).show() }) } }) { Text("Save") }
                    }
                    Spacer(Modifier.height(8.dp))
                    if (dealer.monthlyTarget <= 0.0) {
                        Text("এই dealer-এর জন্য monthly target সেট করা নেই — rule প্রযোজ্য না।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text("Weekly Target: ৳${"%,.0f".format(eligibility.weeklyTarget)}", style = MaterialTheme.typography.bodySmall)
                        Text("Expected so far: ৳${"%,.0f".format(eligibility.expectedSoFar)}", style = MaterialTheme.typography.bodySmall)
                        Text("Paid this week: ৳${"%,.0f".format(eligibility.weeklyPaid)}", style = MaterialTheme.typography.bodySmall, color = SuccessGreen)
                        if (eligibility.weeklyRemaining > 0) {
                            Text("Remaining: ৳${"%,.0f".format(eligibility.weeklyRemaining)}", style = MaterialTheme.typography.bodySmall, color = DangerRed)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("Status: ${dealer.creditStatus}", fontWeight = FontWeight.Bold, color = when (dealer.creditStatus) { "SUSPENDED" -> DangerRed; "WARNING" -> WarningAmber; "TEMPORARILY_APPROVED" -> Sky; else -> SuccessGreen })
                        Text(eligibility.reason, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    }
                    if (vm.canDeleteDealer()) { // reusing the existing manager-level permission gate for override
                        Spacer(Modifier.height(10.dp))
                        var showOverride by remember { mutableStateOf(false) }
                        TextButton(onClick = { showOverride = true }) { Text("Manual Credit Status Override") }
                        if (showOverride) {
                            var newStatus by remember { mutableStateOf("ACTIVE") }
                            var comment by remember { mutableStateOf("") }
                            Dialog(onDismissRequest = { showOverride = false }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text("Override Credit Status", style = MaterialTheme.typography.titleMedium)
                                        Spacer(Modifier.height(8.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            listOf("ACTIVE", "WARNING", "SUSPENDED", "TEMPORARILY_APPROVED").forEach { s ->
                                                FilterChip(selected = newStatus == s, onClick = { newStatus = s }, label = { Text(s, style = MaterialTheme.typography.labelSmall) })
                                            }
                                        }
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(value = comment, onValueChange = { comment = it }, label = { Text("Reason (required)") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(10.dp))
                                        Button(
                                            onClick = { if (MockRepository.setDealerCreditStatus(dealer.id, newStatus, comment, onRejected = { e -> android.widget.Toast.makeText(context, e, android.widget.Toast.LENGTH_LONG).show() })) showOverride = false },
                                            enabled = comment.isNotBlank(),
                                            modifier = Modifier.fillMaxWidth(),
                                        ) { Text("Save Override") }
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Lifetime Statistics", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Total Purchases: ৳${"%,.0f".format(lifetimeTotal)}", style = MaterialTheme.typography.bodySmall)
                    Text("Total Invoices: ${dealerInvoices.size}", style = MaterialTheme.typography.bodySmall)
                    Text("First Purchase: ${firstPurchaseDate ?: "Data unavailable"}", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(12.dp))
                    Text("Purchase Trend", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    if (dealerInvoices.size < 2) {
                        Text("Trend দেখানোর জন্য পর্যাপ্ত invoice data নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                    } else {
                        val recent = dealerInvoices.takeLast(7)
                        com.abm.erp.core.TrendLineChart(
                            labels = recent.map { it.createdAt.dayOfMonth.toString() },
                            values = recent.map { it.total },
                            lineColor = ElectricCyan,
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Visit Planner", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    val planContext = androidx.compose.ui.platform.LocalContext.current
                    Button(
                        onClick = {
                            val today = java.time.LocalDate.now()
                            android.app.DatePickerDialog(planContext, { _, y, m, d ->
                                val chosen = java.time.LocalDate.of(y, m + 1, d)
                                com.abm.erp.data.CrmRepository.createFollowUp(null, "Visit: ${dealer.name}", chosen.atTime(10, 0))
                                android.widget.Toast.makeText(planContext, "Visit planned for $chosen", android.widget.Toast.LENGTH_SHORT).show()
                            }, today.year, today.monthValue - 1, today.dayOfMonth).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("📅 Plan Next Visit") }
                    Spacer(Modifier.height(12.dp))
                    Text("Promise to Pay", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    if (MockRepository.isCommitmentBroken(dealer)) {
                        Text("⚠ Broken commitment: promised ৳${"%,.0f".format(dealer.promiseToPayAmount)} by ${dealer.promiseToPayDate?.toLocalDate()}, still due.", color = DangerRed, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                    } else if (dealer.promiseToPayDate != null) {
                        Text("Promised ৳${"%,.0f".format(dealer.promiseToPayAmount)} by ${dealer.promiseToPayDate?.toLocalDate()}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    var showPromise by remember { mutableStateOf(false) }
                    TextButton(onClick = { showPromise = true }) { Text("Record Promise to Pay") }
                    if (showPromise) {
                        var amountInput by remember { mutableStateOf("") }
                        var note by remember { mutableStateOf("") }
                        val promiseContext = androidx.compose.ui.platform.LocalContext.current
                        Dialog(onDismissRequest = { showPromise = false }) {
                            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("Promise to Pay — ${dealer.name}", style = MaterialTheme.typography.titleMedium)
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedTextField(value = amountInput, onValueChange = { amountInput = it }, label = { Text("Amount (৳)") }, modifier = Modifier.fillMaxWidth())
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Note") }, modifier = Modifier.fillMaxWidth())
                                    Spacer(Modifier.height(10.dp))
                                    Button(
                                        onClick = {
                                            val amt = amountInput.toDoubleOrNull()
                                            if (amt != null && amt > 0) {
                                                val today = java.time.LocalDate.now()
                                                android.app.DatePickerDialog(promiseContext, { _, y, m, d ->
                                                    MockRepository.recordPromiseToPay(dealer.id, java.time.LocalDate.of(y, m + 1, d).atStartOfDay(), amt, note)
                                                    showPromise = false
                                                }, today.year, today.monthValue - 1, today.dayOfMonth).show()
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                    ) { Text("Pick Date & Save") }
                                }
                            }
                        }
                    }
                }
            }
            4 -> {
                // v86, Module 2 — combined CRM timeline: visit, sale (invoice), collection, complaint and note events for this dealer, merged and sorted by date. Real data only, no placeholder events.
                val allComplaintsForTimeline by MockRepository.customerComplaints.collectAsState()
                val allCollectionsForTimeline by MockRepository.partyCollections.collectAsState()
                data class TimelineEvent(val date: java.time.LocalDateTime, val icon: String, val text: String)
                val events = remember(visits, dealerInvoices, allCollectionsForTimeline, allComplaintsForTimeline) {
                    val list = mutableListOf<TimelineEvent>()
                    visits.forEach { list += TimelineEvent(it.checkInAt, "📍", "Visit by ${it.employeeName} — ${it.purpose}") }
                    dealerInvoices.forEach { list += TimelineEvent(it.createdAt, "🧾", "Invoice ${it.invoiceNo} — ৳${"%,.0f".format(it.total)}") }
                    allCollectionsForTimeline.filter { it.partyId == dealer.id }.forEach { list += TimelineEvent(it.createdAt, "💰", "Collection ৳${"%,.0f".format(it.amount)} (${it.status})") }
                    allComplaintsForTimeline.filter { it.dealerId == dealer.id }.forEach { list += TimelineEvent(it.createdAt, "⚠️", "Complaint ${it.complaintNo} — ${it.status}") }
                    list.sortedByDescending { it.date }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (events.isEmpty()) {
                        item { Text("এখনো কোনো কার্যকলাপ নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
                    }
                    items(events) { e ->
                        Row(Modifier.fillMaxWidth()) {
                            Text(e.icon, modifier = Modifier.padding(end = 8.dp))
                            Column {
                                Text(e.text, style = MaterialTheme.typography.bodySmall)
                                Text(e.date.toLocalDate().toString(), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                    }
                }
            }
        }
        if (vm.canDeleteDealer()) {
            val deleteDealerBtnContext = androidx.compose.ui.platform.LocalContext.current
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = { val ok = MockRepository.deleteDealer(dealer.id, onRejected = { e -> android.widget.Toast.makeText(deleteDealerBtnContext, e, android.widget.Toast.LENGTH_LONG).show() }); if (ok) onClose() }, modifier = Modifier.fillMaxWidth()) {
                Text("Delete Dealer", color = DangerRed)
            }
        }
    }
}

@Composable
internal fun OutletsTab(vm: DealersScreenViewModel, onOpenRetailer: (String) -> Unit) {
    val outletsScope = androidx.compose.runtime.rememberCoroutineScope()
    val retailerListContext = androidx.compose.ui.platform.LocalContext.current
    // Section 13/19 — Permissions & real (not UI-only) visibility scope.
    // If a real EmployeeProfile exists for the logged-in user (Foundation 2's real
    // system), the proper hierarchy-derived visibleRetailerIds is used — this correctly
    // extends beyond SR/TSM to TERRITORY/AREA/REGION scopes as real EmployeeProfile
    // records get onboarded. It falls back to the original SR/TSM-only officerId check
    // when no EmployeeProfile exists yet for this user, since currentUser.id (the login
    // identity) and EmployeeProfile.id (the new real employee record) aren't the same
    // identity space until an employee is actually onboarded through the new system and
    // linked via userAccountId — an honest limitation of running two systems in parallel
    // during migration.
    //
    // Decision 4 (v113-73) — that rule now lives in exactly one place
    // (MockRepository.visibleRetailersFor / rememberVisibleRetailers) instead of being
    // written out here, in the scan block above, and nowhere at all on the two invoice
    // screens. Behaviour is unchanged; only the duplication is gone.
    val allRetailers = com.abm.erp.core.rememberVisibleRetailers()
    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf<String?>(null) }
    var classificationFilter by remember { mutableStateOf<String?>(null) }
    var routeFilter by remember { mutableStateOf<String?>(null) }
    var sortBy by remember { mutableStateOf("NAME") }
    var bulkMode by remember { mutableStateOf(false) }
    var selectedIds by remember { mutableStateOf<Set<String>>(emptySet()) }

    val retailers = remember(allRetailers, searchQuery, statusFilter, classificationFilter, routeFilter, sortBy) {
        val q = searchQuery.trim().lowercase()
        var list = allRetailers.filter { r ->
            !r.isDeleted &&
                (q.isBlank() || r.name.lowercase().contains(q) || r.ownerName.lowercase().contains(q) || r.phone.contains(q) ||
                    r.retailerCode.lowercase().contains(q) || r.market.lowercase().contains(q) || r.officerName.lowercase().contains(q)) &&
                (statusFilter == null || r.businessStatus == statusFilter) &&
                (classificationFilter == null || r.classification == classificationFilter) &&
                (routeFilter == null || r.routeId == routeFilter)
        }
        list = when (sortBy) {
            "NAME" -> list.sortedBy { it.name }
            "LAST_VISIT" -> list.sortedByDescending { it.lastVisitDate }
            "LAST_ORDER" -> list.sortedByDescending { it.lastOrderDate }
            "DUE" -> list.sortedByDescending { it.dueBalance }
            "CREATED" -> list.sortedByDescending { it.createdAt }
            else -> list
        }
        list
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Retailers / Outlets (${retailers.size}/${allRetailers.count { !it.isDeleted }})", style = MaterialTheme.typography.titleMedium)
            Row {
                var refreshing by remember { mutableStateOf(false) }
                IconButton(onClick = {
                    refreshing = true
                    MockRepository.refreshRetailers()
                    outletsScope.launch { kotlinx.coroutines.delay(600); refreshing = false }
                }) {
                    if (refreshing) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh")
                    }
                }
                if (MockRepository.currentUser.role == com.abm.erp.data.UserRole.CHAIRMAN) {
                    IconButton(onClick = {
                        val printText = "Retailer List (${retailers.size})\n\n" + retailers.joinToString("\n") { "${it.retailerCode}  ${it.name}  ${it.market}  Due:৳${it.dueBalance}" }
                        val webView = android.webkit.WebView(retailerListContext)
                        webView.loadDataWithBaseURL(null, "<pre>${android.text.Html.escapeHtml(printText)}</pre>", "text/html", "UTF-8", null)
                        val printManager = retailerListContext.getSystemService(android.content.Context.PRINT_SERVICE) as android.print.PrintManager
                        val adapter = webView.createPrintDocumentAdapter("Retailer List")
                        printManager.print("Retailer List", adapter, android.print.PrintAttributes.Builder().build())
                        MockRepository.logAudit("Retailer", "(list)", "PRINT", newValue = "${retailers.size} records printed by ${MockRepository.currentUser.name}")
                    }) { Icon(Icons.Filled.Print, contentDescription = "Print") }
                    IconButton(onClick = {
                        val fullText = "Retailer List (${retailers.size})\n" + retailers.joinToString("\n") { "${it.retailerCode}\t${it.name}\t${it.market}\t${it.dueBalance}" }
                        val clipboard = retailerListContext.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Retailer List", fullText))
                        MockRepository.logAudit("Retailer", "(list)", "COPY", newValue = "${retailers.size} records copied by ${MockRepository.currentUser.name}")
                        android.widget.Toast.makeText(retailerListContext, "Copied ${retailers.size} records", android.widget.Toast.LENGTH_SHORT).show()
                    }) { Icon(Icons.Filled.ContentCopy, contentDescription = "Copy List") }
                }
                TextButton(onClick = { bulkMode = !bulkMode; selectedIds = emptySet() }) { Text(if (bulkMode) "Cancel" else "Select") }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = searchQuery, onValueChange = { searchQuery = it }, placeholder = { Text("নাম/owner/মোবাইল/code/market/officer দিয়ে খুঁজুন") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            FilterChip(selected = statusFilter == null, onClick = { statusFilter = null }, label = { Text("All Status") })
            listOf("PROSPECT", "ACTIVE", "INACTIVE", "SUSPENDED", "CLOSED").forEach { s ->
                FilterChip(selected = statusFilter == s, onClick = { statusFilter = s }, label = { Text(s) })
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            FilterChip(selected = classificationFilter == null, onClick = { classificationFilter = null }, label = { Text("All Category") })
            listOf("A", "B", "C").forEach { c -> FilterChip(selected = classificationFilter == c, onClick = { classificationFilter = c }, label = { Text("Category $c") }) }
        }
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            listOf("NAME" to "Name", "LAST_VISIT" to "Last Visit", "LAST_ORDER" to "Last Order", "DUE" to "Due", "CREATED" to "Newest").forEach { (key, label) ->
                FilterChip(selected = sortBy == key, onClick = { sortBy = key }, label = { Text(label, style = MaterialTheme.typography.labelSmall) })
            }
        }
        if (bulkMode && selectedIds.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${selectedIds.size} selected", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                var showBulkAssign by remember { mutableStateOf(false) }
                TextButton(onClick = { showBulkAssign = true }) { Text("Bulk Reassign") }
                TextButton(onClick = { selectedIds = emptySet() }) { Text("Clear") }
                if (showBulkAssign) {
                    Dialog(onDismissRequest = { showBulkAssign = false }) {
                        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                            Column(Modifier.padding(16.dp).heightIn(max = 400.dp).verticalScroll(rememberScrollState())) {
                                Text("Bulk Reassign ${selectedIds.size} Retailer(s)", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                // v113-217 — same fake-employee-dropdown bug already
                                // fixed for "Apply Leave"/"Record Employee Event"
                                // earlier this session (PayrollScreen.kt): this
                                // bulk-reassign dropdown was picking from the
                                // orphaned synthetic EMPLOYEE_DIRECTORY, meaning
                                // bulk-reassigning retailers actually assigned them
                                // to a fake employee id that doesn't exist in the
                                // real system. Switched to real employeeProfiles.
                                val allProfilesForBulkAssign by MockRepository.employeeProfiles.collectAsState()
                                allProfilesForBulkAssign.forEach { emp ->
                                    // v87 fix — Section 18 accessibility: a Text with only 6dp
                                    // vertical padding gives a tap target well under the 48dp
                                    // minimum touch-target guideline. Row + heightIn fixes this
                                    // for every picker list in this screen.
                                    Row(
                                        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable {
                                            MockRepository.bulkAssignRetailerOfficer(selectedIds.toList(), emp.id, emp.fullName)
                                            selectedIds = emptySet(); bulkMode = false; showBulkAssign = false
                                        },
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) { Text("${emp.fullName} (${emp.role})", style = MaterialTheme.typography.bodySmall) }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (retailers.isEmpty()) {
            // v113-73 — after the scoping dedupe there is no local `rawRetailers`/`currentRole`
            // any more. Same meaning, read straight from the repository: "the company has
            // outlets, but none of them are mine" vs "there are no outlets at all".
            val isScopedEmpty = allRetailers.isEmpty() && MockRepository.retailers.value.any { !it.isDeleted }
            Text(
                if (isScopedEmpty) "আপনার নামে এখনো কোনো outlet assign করা হয়নি — Manager-এর সাথে যোগাযোগ করুন।"
                else "এখনো কোনো outlet registration নেই — Sales Chain-এ order দেওয়ার সময় শুধু নাম লেখা হয়, কিন্তু \"+ Add Outlet\" দিয়ে এখন সত্যিকারের Retailer রেকর্ড বানানো যাবে (dedup-check, ledger, visit history সহ)।",
                style = MaterialTheme.typography.bodySmall, color = TextSecondary,
            )
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(retailers, key = { it.id }) { r ->
                if (bulkMode) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = r.id in selectedIds, onCheckedChange = { checked -> selectedIds = if (checked) selectedIds + r.id else selectedIds - r.id })
                        Text(r.name, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    }
                    return@items
                }
                val retailerLedger by vm.retailerLedgerFor(r.id).collectAsState(initial = emptyList())
                GlassCard(modifier = Modifier.fillMaxWidth().clickable { onOpenRetailer(r.id) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(r.name, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text("${r.outletCategory} · ${r.outletType}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            if (r.onboardingStatus != "ACTIVE") {
                                Text(
                                    "Onboarding: ${r.onboardingStatus}" + (r.rejectReason?.let { " — $it" } ?: ""),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = when (r.onboardingStatus) { "REJECTED" -> DangerRed; "DRAFT" -> TextSecondary; else -> WarningAmber },
                                )
                            }
                            if (r.dueBalance > 0) Text("Due: ৳${"%,.0f".format(r.dueBalance)}", style = MaterialTheme.typography.bodySmall, color = WarningAmber)
                        }
                        if (r.routeId != null) {
                            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(6.dp), color = SuccessGreen.copy(alpha = 0.15f)) {
                                Text(" Routed ", modifier = Modifier.padding(4.dp), color = SuccessGreen, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        com.abm.erp.core.UniversalActionMenu(
                            moduleReference = "Retailer", entityId = r.id, entityLabel = r.name,
                            shareText = "${r.name} — ${r.outletCategory}/${r.outletType}\nDue: ৳${r.dueBalance}",
                            isDeleted = r.isDeleted,
                            onDuplicate = { onError -> outletsScope.launch { vm.duplicateRetailerAction(r.id, onRejected = onError) } },
                            onArchive = { onError -> outletsScope.launch { vm.archiveRetailerAction(r.id, onRejected = onError) } },
                            canArchive = vm.canDeleteDealer(), // Retailer/Outlet master data shares the "dealer" module permission scope — no separate canDeleteRetailer() exists, and this app's permission model doesn't distinguish them
                            archiveBlockedReasonOverride = if (r.dueBalance > 0) "এই আউটলেটের বকেয়া ৳${"%,.0f".format(r.dueBalance)} আছে — বকেয়া ক্লিয়ার না হওয়া পর্যন্ত archive করা যাবে না।" else null,
                            onRestore = { outletsScope.launch { vm.restoreRetailerAction(r.id) } },
                            csvHeader = "Name,Category,Type,Due,CreditLimit",
                            csvRow = com.abm.erp.core.toCsvRow(r.name, r.outletCategory, r.outletType, r.dueBalance, r.creditLimit),
                            historyLabel = "Retailer History",
                            historyItems = retailerLedger.map { "${it.reason}: ${it.type} ৳${"%,.0f".format(it.amount)} — ${it.createdAt.toLocalDate()}" },
                        )
                    }
                    if (r.onboardingStatus == "DRAFT" || r.onboardingStatus == "REJECTED") {
                        Spacer(Modifier.height(6.dp))
                        var showDupResult by remember { mutableStateOf<List<com.abm.erp.data.RetailerDuplicateMatch>?>(null) }
                        var showEdit by remember { mutableStateOf(false) }
                        var submitBlockedReason by remember { mutableStateOf<String?>(null) }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { showEdit = true }) { Text("Edit") }
                            TextButton(onClick = {
                                if (r.lat == null || r.lng == null) {
                                    submitBlockedReason = "⚠ GPS location capture করা হয়নি — Edit-এ গিয়ে location capture করুন, তারপর submit করুন।"
                                } else {
                                    submitBlockedReason = null
                                    showDupResult = MockRepository.submitRetailerForReview(r.id)
                                }
                            }) { Text("Submit for Approval") }
                        }
                        submitBlockedReason?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                        if (showEdit) {
                            var editName by remember { mutableStateOf(r.name) }
                            var editPhone by remember { mutableStateOf(r.phone) }
                            var editAddress by remember { mutableStateOf(r.address) }
                            var editDistrict by remember { mutableStateOf(r.district) }
                            var editUpazila by remember { mutableStateOf(r.upazila) }
                            var editGps by remember { mutableStateOf(r.lat?.let { lat -> r.lng?.let { lng -> lat to lng } }) }
                            var editGpsAccuracy by remember { mutableStateOf(r.gpsAccuracyMeters) }
                            var editGpsError by remember { mutableStateOf<String?>(null) }
                            val editContext = androidx.compose.ui.platform.LocalContext.current
                            fun captureGpsNow() {
                                val client = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(editContext)
                                try {
                                    @Suppress("MissingPermission")
                                    client.lastLocation.addOnSuccessListener { loc ->
                                        if (loc != null) { editGps = loc.latitude to loc.longitude; editGpsAccuracy = loc.accuracy.toDouble(); editGpsError = null }
                                        else editGpsError = "No recent GPS fix — খোলা জায়গায় গিয়ে আবার চেষ্টা করুন।"
                                    }.addOnFailureListener { editGpsError = it.message ?: "Location fetch করা যায়নি।" }
                                } catch (e: SecurityException) { editGpsError = "Location permission প্রয়োজন।" }
                            }
                            val editLocationPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                                androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
                            ) { granted -> if (granted) captureGpsNow() else editGpsError = "Location permission দেওয়া হয়নি।" }
                            Dialog(onDismissRequest = { showEdit = false }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp).heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
                                        Text("Edit ${r.retailerCode}", style = MaterialTheme.typography.titleMedium)
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(value = editName, onValueChange = { editName = it }, label = { Text("Outlet name") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(6.dp))
                                        OutlinedTextField(value = editPhone, onValueChange = { editPhone = it }, label = { Text("Phone") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(6.dp))
                                        OutlinedTextField(value = editAddress, onValueChange = { editAddress = it }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(6.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            OutlinedTextField(value = editDistrict, onValueChange = { editDistrict = it }, label = { Text("District") }, modifier = Modifier.weight(1f))
                                            OutlinedTextField(value = editUpazila, onValueChange = { editUpazila = it }, label = { Text("Upazila") }, modifier = Modifier.weight(1f))
                                        }
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedButton(
                                            onClick = {
                                                val granted = androidx.core.content.ContextCompat.checkSelfPermission(editContext, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                                if (granted) captureGpsNow() else editLocationPermissionLauncher.launch(android.Manifest.permission.ACCESS_FINE_LOCATION)
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                        ) { Text(editGps?.let { "📍 Captured: ${"%.5f".format(it.first)}, ${"%.5f".format(it.second)}" } ?: "📍 Capture GPS Location") }
                                        editGpsError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                        Spacer(Modifier.height(10.dp))
                                        Button(
                                            onClick = {
                                                MockRepository.updateRetailerDraft(r.id, name = editName, phone = editPhone, address = editAddress, district = editDistrict, upazila = editUpazila, lat = editGps?.first, lng = editGps?.second, gpsAccuracyMeters = editGpsAccuracy)
                                                showEdit = false
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                        ) { Text("Save Changes") }
                                    }
                                }
                            }
                        }
                        showDupResult?.let { matches ->
                            if (matches.isNotEmpty()) {
                                Text("সম্ভাব্য duplicate পাওয়া গেছে:", style = MaterialTheme.typography.labelSmall, color = WarningAmber, fontWeight = FontWeight.Bold)
                                matches.forEach { m -> Text("${m.confidence}: ${m.name} (${m.retailerCode}) — ${m.phone}", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                            }
                        }
                    }
                    if (r.onboardingStatus == "PENDING_APPROVAL" || r.onboardingStatus == "DUPLICATE_CHECK") {
                        Spacer(Modifier.height(6.dp))
                        var showReject by remember { mutableStateOf(false) }
                        var approveRtlError by remember { mutableStateOf<String?>(null) }
                        approveRtlError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { MockRepository.approveRetailer(r.id, onRejected = { e -> approveRtlError = e }) }) { Text("Approve") }
                            TextButton(onClick = { showReject = true }) { Text("Reject", color = DangerRed) }
                        }
                        if (showReject) {
                            var reason by remember { mutableStateOf("") }
                            Dialog(onDismissRequest = { showReject = false }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text("Reject ${r.name}", style = MaterialTheme.typography.titleMedium)
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason (required)") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(10.dp))
                                        var rejectRetailerError by remember { mutableStateOf<String?>(null) }
                                        rejectRetailerError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                        Button(onClick = { val ok = MockRepository.rejectRetailer(r.id, reason, onRejected = { e -> rejectRetailerError = e }); if (ok) showReject = false }, enabled = reason.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Confirm Reject") }
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    if (r.onboardingStatus == "ACTIVE") {
                        var checkedInVisit by remember { mutableStateOf<com.abm.erp.data.VisitLog?>(null) }
                        var showCheckIn by remember { mutableStateOf(false) }
                        var showCheckOut by remember { mutableStateOf(false) }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (checkedInVisit == null) {
                                TextButton(onClick = { showCheckIn = true }) { Text("📍 Check In") }
                            } else {
                                TextButton(onClick = { showCheckOut = true }) { Text("✅ Check Out", color = SuccessGreen) }
                            }
                        }
                        if (showCheckIn) {
                            VisitCheckInDialog(
                                retailer = r,
                                onDismiss = { showCheckIn = false },
                                onCheckedIn = { visit -> checkedInVisit = visit; showCheckIn = false },
                            )
                        }
                        if (showCheckOut && checkedInVisit != null) {
                            VisitCheckOutDialog(
                                retailer = r, visit = checkedInVisit!!,
                                onDismiss = { showCheckOut = false },
                                onCheckedOut = { checkedInVisit = null; showCheckOut = false },
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    var showAssign by remember { mutableStateOf(false) }
                    TextButton(onClick = { showAssign = true }) { Text(if (r.officerName.isBlank()) "Assign Officer" else "Reassign: ${r.officerName}") }
                    if (showAssign) {
                        var transferReason by remember { mutableStateOf("") }
                        Dialog(onDismissRequest = { showAssign = false }) {
                            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                Column(Modifier.padding(16.dp).heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                                    Text(if (r.officerName.isBlank()) "Assign Officer" else "Transfer to New Officer", style = MaterialTheme.typography.titleMedium)
                                    Spacer(Modifier.height(8.dp))
                                    if (r.officerName.isNotBlank()) {
                                        OutlinedTextField(value = transferReason, onValueChange = { transferReason = it }, label = { Text("Transfer reason (required)") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(8.dp))
                                    }
                                    val transferOfficerContext = androidx.compose.ui.platform.LocalContext.current
                                    // v113-217 — same fake-employee-dropdown bug as the
                                    // Bulk Reassign dialog above — assigning/transferring
                                    // a retailer's officer was picking from the orphaned
                                    // synthetic EMPLOYEE_DIRECTORY. Switched to real
                                    // employeeProfiles, same fix.
                                    val allProfilesForAssign by MockRepository.employeeProfiles.collectAsState()
                                    allProfilesForAssign.forEach { emp ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable {
                                                val ok = if (r.officerName.isBlank()) MockRepository.assignRetailerOfficer(r.id, emp.id, emp.fullName, onRejected = { e -> android.widget.Toast.makeText(transferOfficerContext, e, android.widget.Toast.LENGTH_LONG).show() })
                                                else MockRepository.transferRetailer(r.id, emp.id, emp.fullName, transferReason, onRejected = { e -> android.widget.Toast.makeText(transferOfficerContext, e, android.widget.Toast.LENGTH_LONG).show() })
                                                if (ok) showAssign = false
                                            },
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) { Text("${emp.fullName} (${emp.role})", style = MaterialTheme.typography.bodySmall) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun AddRetailerForm(vm: DealersScreenViewModel, dealers: List<com.abm.erp.data.Dealer>, onDone: () -> Unit) {
    val formScope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var ownerName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var altPhone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var district by remember { mutableStateOf("") }
    var upazila by remember { mutableStateOf("") }
    var adminSelection by remember { mutableStateOf(com.abm.erp.ui.core.AdminSelection()) }
    var classification by remember { mutableStateOf("B") }
    var selectedDealer by remember { mutableStateOf<com.abm.erp.data.Dealer?>(null) }
    var dealerMenuExpanded by remember { mutableStateOf(false) }
    var outletCategory by remember { mutableStateOf("General Store") }
    var outletType by remember { mutableStateOf("Retail") }
    var error by remember { mutableStateOf<String?>(null) }
    var gps by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var gpsAccuracy by remember { mutableStateOf<Double?>(null) }
    var gpsError by remember { mutableStateOf<String?>(null) }
    var shopPhotoUri by remember { mutableStateOf<android.net.Uri?>(null) }
    val categories = listOf("General Store", "Super Shop", "Pharmacy", "Tea Stall", "Grocery")
    val types = listOf("Retail", "Wholesale")
    val context = androidx.compose.ui.platform.LocalContext.current

    // v87 fix — real GPS capture (Section 1: latitude/longitude/GPS accuracy/geo-capture timestamp),
    // mirroring the exact pattern already used for Sales Chain outlet visits.
    fun hasLocationPermission() = androidx.core.content.ContextCompat.checkSelfPermission(
        context, android.Manifest.permission.ACCESS_FINE_LOCATION,
    ) == android.content.pm.PackageManager.PERMISSION_GRANTED

    fun tagLocationNow() {
        val client = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(context)
        try {
            @Suppress("MissingPermission")
            client.lastLocation.addOnSuccessListener { loc ->
                if (loc != null) {
                    gps = loc.latitude to loc.longitude; gpsAccuracy = loc.accuracy.toDouble(); gpsError = null
                    // Section 9 — offline district auto-suggestion from the captured point, only fills in if the user hasn't already picked a district.
                    if (adminSelection.districtId == null) {
                        MockRepository.resolveDistrictForPoint(loc.latitude, loc.longitude)?.let { district_ ->
                            adminSelection = adminSelection.copy(divisionId = district_.parentId, districtId = district_.id)
                        }
                    }
                }
                else gpsError = "No recent GPS fix — move to an open area and try again."
            }.addOnFailureListener { gpsError = it.message ?: "Couldn't fetch location." }
        } catch (e: SecurityException) {
            gpsError = "Location permission needed."
        }
    }
    val locationPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
    ) { granted -> if (granted) tagLocationNow() else gpsError = "Location permission was denied." }
    val photoLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent(),
    ) { uri -> shopPhotoUri = uri }

    Column(Modifier.padding(16.dp).heightIn(max = 640.dp).verticalScroll(rememberScrollState())) {
        Text("Outlet / Retailer Registration", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Outlet / shop name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = ownerName, onValueChange = { ownerName = it }, label = { Text("Owner name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Mobile") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = altPhone, onValueChange = { altPhone = it }, label = { Text("Alt. mobile") }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text("প্রশাসনিক এলাকা (Bangladesh Location Master, offline)", style = MaterialTheme.typography.labelMedium)
        com.abm.erp.ui.core.AdminLocationCascadeSelector(
            selection = adminSelection,
            onSelectionChange = { newSel ->
                adminSelection = newSel
                val locs = MockRepository.administrativeLocations.value.associateBy { it.id }
                district = locs[newSel.districtId]?.nameEn ?: district
                upazila = locs[newSel.upazilaId]?.nameEn ?: upazila
            },
        )
        Spacer(Modifier.height(8.dp))
        Text("Retailer category", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("A", "B", "C").forEach { c -> FilterChip(selected = classification == c, onClick = { classification = c }, label = { Text("Category $c") }) }
        }
        Spacer(Modifier.height(8.dp))
        Text("Outlet category", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            categories.forEach { c -> FilterChip(selected = outletCategory == c, onClick = { outletCategory = c }, label = { Text(c) }) }
        }
        Spacer(Modifier.height(8.dp))
        Text("Outlet type", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            types.forEach { t -> FilterChip(selected = outletType == t, onClick = { outletType = t }, label = { Text(t) }) }
        }
        Spacer(Modifier.height(8.dp))
        Box {
            OutlinedButton(onClick = { dealerMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selectedDealer?.name ?: "Link to a dealer (optional)")
            }
            DropdownMenu(expanded = dealerMenuExpanded, onDismissRequest = { dealerMenuExpanded = false }) {
                dealers.forEach { d -> DropdownMenuItem(text = { Text(d.name) }, onClick = { selectedDealer = d; dealerMenuExpanded = false }) }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Shop location & photo", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        OutlinedButton(
            onClick = { if (hasLocationPermission()) tagLocationNow() else locationPermissionLauncher.launch(android.Manifest.permission.ACCESS_FINE_LOCATION) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text(gps?.let { "📍 Captured: ${"%.5f".format(it.first)}, ${"%.5f".format(it.second)}" } ?: "📍 Capture GPS Location") }
        gpsError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
        Spacer(Modifier.height(6.dp))
        OutlinedButton(onClick = { photoLauncher.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
            Text(if (shopPhotoUri != null) "✓ Shop photo selected" else "📷 Add Shop Photo")
        }
        error?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 6.dp)) }
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = {
                formScope.launch {
                    error = null
                    val created = vm.createRetailer(
                        name = name, phone = phone, address = address, dealerId = selectedDealer?.id,
                        outletCategory = outletCategory, outletType = outletType, ownerName = ownerName,
                        altPhone = altPhone, district = district, upazila = upazila, classification = classification,
                        lat = gps?.first, lng = gps?.second, gpsAccuracyMeters = gpsAccuracy,
                        onRejected = { reason -> error = reason },
                    )
                    if (created == null) {
                        error = error ?: "তৈরি করা যায়নি — আবার চেষ্টা করুন।"
                    } else {
                        // v87 fix — the photo must actually upload to Storage
                        // (real bug fixed here), which needs the retailer's real
                        // id — so this happens as a second step after creation,
                        // not passed in as a raw local URI at creation time.
                        shopPhotoUri?.let { uri -> MockRepository.uploadRetailerPhoto(context, created.id, uri.toString(), isOwnerPhoto = false) {} }
                        onDone()
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Register Outlet") }
    }
}

@Composable
internal fun RetailerDetailPanel(vm: DealersScreenViewModel, retailer: com.abm.erp.data.Retailer, onClose: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val panelScope = rememberCoroutineScope()
    var subTab by remember { mutableStateOf(0) }
    val ledger by vm.retailerLedgerFor(retailer.id).collectAsState(initial = emptyList())
    val visits by vm.retailerVisitsFor(retailer.id).collectAsState(initial = emptyList())

    Column(Modifier.padding(16.dp).heightIn(max = 560.dp).widthIn(max = 400.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(retailer.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${retailer.outletCategory} · ${retailer.outletType}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = "Close") }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Due: ৳${"%,.0f".format(retailer.dueBalance)}" + if (retailer.creditLimit > 0) " / limit ৳${"%,.0f".format(retailer.creditLimit)}" else "",
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            val healthScore = remember(retailer.id) { MockRepository.retailerHealthScore(retailer) }
            Column {
                Text("Health Score", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text("$healthScore/100", fontWeight = FontWeight.Bold, color = when { healthScore >= 65 -> SuccessGreen; healthScore >= 40 -> WarningAmber; else -> DangerRed })
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text("Last Visit", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text(visits.maxByOrNull { it.checkInAt }?.checkInAt?.toLocalDate()?.toString() ?: "কখনো না", style = MaterialTheme.typography.bodySmall)
            }
            if (retailer.phone.isNotBlank()) {
                val callContext = androidx.compose.ui.platform.LocalContext.current
                IconButton(onClick = {
                    try {
                        callContext.startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:${retailer.phone}")))
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(callContext, "Call করা যায়নি।", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }) { Icon(Icons.Filled.Call, contentDescription = "Call ${retailer.name}") }
                // v113-135 — real SMS + WhatsApp handoff beside the existing real
                // Call action. Both are plain Intents to the device's own apps —
                // no backend/API key needed, so these are genuinely functional
                // rather than an "integration required" placeholder. Each carries
                // its own real failure path (no SMS app / WhatsApp not installed).
                IconButton(onClick = {
                    try {
                        callContext.startActivity(android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("smsto:${retailer.phone}")))
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(callContext, "SMS app পাওয়া যায়নি।", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }) { Icon(Icons.Filled.MarkunreadMailbox, contentDescription = "SMS ${retailer.name}") }
                IconButton(onClick = {
                    try {
                        val digits = retailer.phone.filter { it.isDigit() }
                        val intl = if (digits.startsWith("880")) digits else "88" + digits.removePrefix("0").let { d -> if (d.startsWith("1")) "0$d" else d }
                        callContext.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://wa.me/$intl")))
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(callContext, "WhatsApp খোলা যায়নি।", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }) { Icon(Icons.Filled.Send, contentDescription = "WhatsApp ${retailer.name}") }
            }
            if (retailer.lat != null && retailer.lng != null) {
                val navContext = androidx.compose.ui.platform.LocalContext.current
                IconButton(onClick = {
                    try {
                        val uri = android.net.Uri.parse("google.navigation:q=${retailer.lat},${retailer.lng}")
                        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, uri).apply { setPackage("com.google.android.apps.maps") }
                        navContext.startActivity(intent)
                    } catch (e: Exception) {
                        try {
                            navContext.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("geo:${retailer.lat},${retailer.lng}")))
                        } catch (e2: Exception) {
                            android.widget.Toast.makeText(navContext, "Maps app পাওয়া যায়নি।", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                }) { Icon(Icons.Filled.Place, contentDescription = "Navigate to ${retailer.name}") }
            }
        }
        Spacer(Modifier.height(10.dp))
        ScrollableTabRow(selectedTabIndex = subTab, edgePadding = 0.dp) {
            listOf("Overview", "Address", "Team", "Sales", "Collections", "Due/Credit", "Visits", "Complaints", "Notes", "History").forEachIndexed { i, label ->
                Tab(selected = subTab == i, onClick = { subTab = i }, text = { Text(label, style = MaterialTheme.typography.labelSmall) })
            }
        }
        Spacer(Modifier.height(10.dp))
        when (subTab) {
            0 -> { // Overview — real summary cards from linked records, not fabricated
                // v113-77 fix — before v113-75 there was no `retailerId` field on
                // CustomerComplaint at all, so this compared against `dealerId` as a
                // stand-in; nothing ever wrote a retailer's id into that field, so this
                // was silently always empty. Now filters on the real field.
                val complaintsOv = MockRepository.customerComplaints.collectAsState().value.filter { it.partyType == com.abm.erp.data.PartyType.RETAILER && it.retailerId == retailer.id }
                Column {
                    Text("Retailer Code: ${retailer.retailerCode}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    var showQr by remember { mutableStateOf(false) }
                    TextButton(onClick = {
                        if (retailer.qrCode == null) MockRepository.generateRetailerQrCode(retailer.id)
                        showQr = !showQr
                    }) { Text(if (showQr) "Hide QR Code" else "🔳 Shop QR Code") }
                    if (showQr) {
                        val qrContent = retailer.qrCode ?: retailer.retailerCode
                        val bitmap = remember(qrContent) { com.abm.erp.util.QrCodeGenerator.generate(qrContent, 300) }
                        Image(bitmap = bitmap.asImageBitmap(), contentDescription = "QR code for ${retailer.name}", modifier = Modifier.size(140.dp))
                    }
                    Text("Owner: ${retailer.ownerName.ifBlank { "—" }}", style = MaterialTheme.typography.bodySmall)
                    Text("Phone: ${retailer.phone}" + (retailer.altPhone.takeIf { it.isNotBlank() }?.let { " / $it" } ?: ""), style = MaterialTheme.typography.bodySmall)
                    Text("Status: ${retailer.businessStatus} · Category ${retailer.classification}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Lifetime sales: ৳${"%,.0f".format(ledger.filter { it.type == "DEBIT" }.sumOf { it.amount })}", style = MaterialTheme.typography.bodySmall)
                    Text("Current due: ৳${"%,.0f".format(retailer.dueBalance)}", style = MaterialTheme.typography.bodySmall, color = if (retailer.dueBalance > 0) WarningAmber else SuccessGreen)
                    Text("Last order: ${retailer.lastOrderDate?.toLocalDate() ?: "কখনো না"}", style = MaterialTheme.typography.bodySmall)
                    Text("Last collection: ${retailer.lastCollectionDate?.toLocalDate() ?: "কখনো না"}", style = MaterialTheme.typography.bodySmall)
                    Text("Last visit: ${visits.maxByOrNull { it.checkInAt }?.checkInAt?.toLocalDate() ?: "কখনো না"}", style = MaterialTheme.typography.bodySmall)
                    Text("Open complaints: ${complaintsOv.count { it.status != com.abm.erp.data.CustomerComplaintStatus.RESOLVED && it.status != com.abm.erp.data.CustomerComplaintStatus.CLOSED }}", style = MaterialTheme.typography.bodySmall)
                    Text("Assigned officer: ${retailer.officerName.ifBlank { "অনির্ধারিত" }}", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(10.dp))
                    val perf = remember(ledger, visits) { MockRepository.computeRetailerPerformance(retailer, ledger, visits) }
                    Text("Performance", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Text("30d: ৳${"%,.0f".format(perf.salesLast30Days)}  ·  60d: ৳${"%,.0f".format(perf.salesLast60Days)}  ·  90d: ৳${"%,.0f".format(perf.salesLast90Days)}", style = MaterialTheme.typography.bodySmall)
                    Text("Avg order: ৳${"%,.0f".format(perf.avgOrderValue)}  ·  Orders (30d): ${perf.orderCount30Days}", style = MaterialTheme.typography.bodySmall)
                    Text("Collection efficiency: ${"%.0f".format(perf.collectionEfficiencyPct)}%  ·  Credit used: ${"%.0f".format(perf.creditUtilizationPct)}%", style = MaterialTheme.typography.bodySmall)
                    Text("Trend: ${if (perf.isGrowing) "▲" else "▼"} ${"%.0f".format(perf.trendPct)}% vs previous month", color = if (perf.isGrowing) SuccessGreen else DangerRed, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    perf.outstandingAgeingDays?.let { Text("Outstanding ageing: $it days", style = MaterialTheme.typography.bodySmall, color = if (it > 30) DangerRed else WarningAmber) }
                    Spacer(Modifier.height(10.dp))
                    val flags = remember(retailer) { MockRepository.retailerActivityFlags(retailer) }
                    if (flags.isNotEmpty()) {
                        Text("Activity Alerts", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = WarningAmber)
                        flags.forEach { f -> Text("⚠ ${f.label}", style = MaterialTheme.typography.bodySmall, color = if (f.severity == "CRITICAL") DangerRed else WarningAmber) }
                    }
                }
            }
            1 -> { // Address and Location
                Column {
                    Text(retailer.address.ifBlank { "কোনো ঠিকানা নেই" }, style = MaterialTheme.typography.bodySmall)
                    Text("District: ${retailer.district.ifBlank { "—" }}  ·  Upazila: ${retailer.upazila.ifBlank { "—" }}", style = MaterialTheme.typography.bodySmall)
                    Text("Market: ${retailer.market.ifBlank { "—" }}  ·  Area: ${retailer.area.ifBlank { "—" }}", style = MaterialTheme.typography.bodySmall)
                    if (retailer.lat != null && retailer.lng != null) {
                        Text("GPS: ${retailer.lat}, ${retailer.lng}" + (retailer.gpsAccuracyMeters?.let { " (±${it.toInt()}m)" } ?: ""), style = MaterialTheme.typography.bodySmall)
                        Text("Captured: ${retailer.geoCapturedAt?.toLocalDate() ?: "অজানা"}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Text(
                            "Verification: ${retailer.locationVerificationStatus} (revision ${retailer.locationRevision})",
                            style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold,
                            color = when (retailer.locationVerificationStatus) { "VERIFIED" -> SuccessGreen; "REJECTED", "SUSPICIOUS" -> DangerRed; else -> WarningAmber },
                        )
                        if (retailer.locationVerificationStatus == "PENDING_VERIFICATION") {
                            var showVerifyDialog by remember { mutableStateOf<String?>(null) }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { showVerifyDialog = "VERIFIED" }) { Text("Verify") }
                                TextButton(onClick = { showVerifyDialog = "REJECTED" }) { Text("Reject", color = DangerRed) }
                                TextButton(onClick = { showVerifyDialog = "NEEDS_RECAPTURE" }) { Text("Request Recapture") }
                            }
                            showVerifyDialog?.let { decision ->
                                var comment by remember { mutableStateOf("") }
                                Dialog(onDismissRequest = { showVerifyDialog = null }) {
                                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                        Column(Modifier.padding(16.dp)) {
                                            Text("$decision — ${retailer.name}", style = MaterialTheme.typography.titleMedium)
                                            Spacer(Modifier.height(8.dp))
                                            OutlinedTextField(value = comment, onValueChange = { comment = it }, label = { Text("Comment") }, modifier = Modifier.fillMaxWidth())
                                            Spacer(Modifier.height(10.dp))
                                            Button(onClick = { val ok = MockRepository.verifyRetailerLocation(retailer.id, decision, comment.ifBlank { null }, onRejected = { e -> android.widget.Toast.makeText(context, e, android.widget.Toast.LENGTH_LONG).show() }); if (ok) showVerifyDialog = null }, modifier = Modifier.fillMaxWidth()) { Text("Confirm") }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Text("কোনো GPS location সংরক্ষিত নেই।", style = MaterialTheme.typography.bodySmall, color = DangerRed)
                    }
                    Spacer(Modifier.height(8.dp))
                    var showRecapture by remember { mutableStateOf(false) }
                    TextButton(onClick = { showRecapture = true }) { Text("📍 Recapture Location") }
                    if (showRecapture) {
                        RecaptureLocationDialog(retailer = retailer, onDismiss = { showRecapture = false })
                    }
                    Text(
                        "Visit radius: ${retailer.geofenceRadiusMeters?.toInt() ?: MockRepository.retailerGeofenceRadius(retailer).toInt()}m" +
                            (if (retailer.geofenceRadiusMeters == null) " (company default)" else " (custom)"),
                        style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                    )
                    var showRadiusDialog by remember { mutableStateOf(false) }
                    TextButton(onClick = { showRadiusDialog = true }) { Text("Set Visit Radius") }
                    if (showRadiusDialog) {
                        var radiusInput by remember { mutableStateOf(retailer.geofenceRadiusMeters?.toInt()?.toString() ?: "") }
                        var radiusReason by remember { mutableStateOf("") }
                        Dialog(onDismissRequest = { showRadiusDialog = false }) {
                            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("Visit Radius Override — ${retailer.name}", style = MaterialTheme.typography.titleMedium)
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedTextField(value = radiusInput, onValueChange = { radiusInput = it }, label = { Text("Radius in meters (blank = company default)") }, modifier = Modifier.fillMaxWidth())
                                    Spacer(Modifier.height(6.dp))
                                    OutlinedTextField(value = radiusReason, onValueChange = { radiusReason = it }, label = { Text("Reason (required)") }, modifier = Modifier.fillMaxWidth())
                                    Spacer(Modifier.height(10.dp))
                                    var radiusError by remember { mutableStateOf<String?>(null) }
                                    radiusError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                    Button(
                                        onClick = { val ok = MockRepository.setRetailerGeofenceRadius(retailer.id, radiusInput.toDoubleOrNull(), radiusReason, onRejected = { e -> radiusError = e }); if (ok) showRadiusDialog = false },
                                        enabled = radiusReason.isNotBlank(),
                                        modifier = Modifier.fillMaxWidth(),
                                    ) { Text("Save") }
                                }
                            }
                        }
                    }
                    val locHistory by MockRepository.retailerLocationHistoryFor(retailer.id).collectAsState(initial = emptyList())
                    if (locHistory.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("Location History", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        locHistory.forEach { h -> Text("Rev ${h.revisionNumber}: ${h.changeReason} — ${h.distanceFromPreviousMeters?.let { com.abm.erp.location.LocationVerification.formatDistance(it) } ?: "—"} moved", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                    }
                }
            }
            2 -> { // Assigned Team
                Column {
                    Text("Officer: ${retailer.officerName.ifBlank { "অনির্ধারিত" }}", style = MaterialTheme.typography.bodySmall)
                    Text("Route: ${retailer.routeId ?: "অনির্ধারিত"}", style = MaterialTheme.typography.bodySmall)
                    Text("Territory: ${retailer.territoryId ?: "অনির্ধারিত"}", style = MaterialTheme.typography.bodySmall)
                    Text("Dealer: ${retailer.dealerId?.let { id -> MockRepository.dealers.value.firstOrNull { it.id == id }?.name } ?: "অনির্ধারিত"}", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    Text("Assignment History", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    val assignHistory by MockRepository.retailerAssignmentHistory(retailer.id).collectAsState(initial = emptyList())
                    assignHistory.forEach { h -> Text("${h.action}: ${h.newValueJson ?: ""} — ${h.timestamp.toLocalDate()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary) }
                }
            }
            3 -> LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) { // Sales History (ledger DEBIT entries = sales)
                val sales = ledger.filter { it.type == "DEBIT" }
                item {
                    var showReturnDialog by remember { mutableStateOf(false) }
                    var showDamageDialog by remember { mutableStateOf(false) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { showReturnDialog = true }) { Text("↩ Report Return") }
                        TextButton(onClick = { showDamageDialog = true }) { Text("⚠ Report Damage", color = WarningAmber) }
                    }
                    if (showReturnDialog || showDamageDialog) {
                        var productName by remember { mutableStateOf("") }
                        var qty by remember { mutableStateOf("") }
                        var amount by remember { mutableStateOf("") }
                        var notes by remember { mutableStateOf("") }
                        val isDamage = showDamageDialog
                        Dialog(onDismissRequest = { showReturnDialog = false; showDamageDialog = false }) {
                            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                Column(Modifier.padding(16.dp).heightIn(max = 480.dp).verticalScroll(rememberScrollState())) {
                                    Text(if (isDamage) "Report Damage — ${retailer.name}" else "Report Return — ${retailer.name}", style = MaterialTheme.typography.titleMedium)
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedTextField(value = productName, onValueChange = { productName = it }, label = { Text("Product name") }, modifier = Modifier.fillMaxWidth())
                                    Spacer(Modifier.height(6.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        OutlinedTextField(value = qty, onValueChange = { qty = it }, label = { Text("Qty") }, modifier = Modifier.weight(1f))
                                        OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("Amount (৳)") }, modifier = Modifier.weight(1f))
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text(if (isDamage) "Damage details" else "Return reason") }, modifier = Modifier.fillMaxWidth())
                                    Spacer(Modifier.height(10.dp))
                                    Button(
                                        onClick = {
                                            val q = qty.toIntOrNull(); val amt = amount.toDoubleOrNull()
                                            if (productName.isNotBlank() && q != null && q > 0 && amt != null) {
                                                val line = com.abm.erp.data.SalesInvoiceLineItem(productId = "", name = productName, unit = "pcs", qty = q, unitPrice = amt / q)
                                                if (isDamage) panelScope.launch { MockRepository.reportRetailerDamage(retailer.id, retailer.name, listOf(line), notes) }
                                                else panelScope.launch { MockRepository.createSalesReturn(null, com.abm.erp.data.PartyType.RETAILER, retailer.id, retailer.name, listOf(line), notes) }
                                                showReturnDialog = false; showDamageDialog = false
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                    ) { Text(if (isDamage) "Submit Damage Report" else "Submit Return") }
                                }
                            }
                        }
                    }
                }
                items(sales, key = { it.id }) { e -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(e.reason, style = MaterialTheme.typography.bodySmall); Text("৳${"%,.0f".format(e.amount)}", color = WarningAmber, fontWeight = FontWeight.Bold) } }
                if (sales.isEmpty()) item { Text("কোনো sales history নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
            }
            4 -> LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) { // Collection History (ledger CREDIT entries = collections)
                val collections = ledger.filter { it.type == "CREDIT" }
                items(collections, key = { it.id }) { e -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(e.reason, style = MaterialTheme.typography.bodySmall); Text("৳${"%,.0f".format(e.amount)}", color = SuccessGreen, fontWeight = FontWeight.Bold) } }
                if (collections.isEmpty()) item { Text("কোনো collection history নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
            }
            5 -> { // Due and Credit
                Column {
                    Text("Current Due: ৳${"%,.0f".format(retailer.dueBalance)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = if (retailer.dueBalance > 0) WarningAmber else SuccessGreen)
                    Text("Credit Limit: ৳${"%,.0f".format(retailer.creditLimit)}", style = MaterialTheme.typography.bodySmall)
                    Text("Available Credit: ৳${"%,.0f".format(retailer.availableCredit)}", style = MaterialTheme.typography.bodySmall)
                    Text("Payment Terms: ${retailer.paymentTermsDays} days · Allowed Credit: ${retailer.allowedCreditDays} days", style = MaterialTheme.typography.bodySmall)
                    val applicableDiscount = remember(retailer.id) { MockRepository.applicableDiscountPct(retailer.id, 1.0) }
                    if (applicableDiscount > 0) {
                        Text("Applicable discount: ${"%.0f".format(applicableDiscount)}% (active scheme)", style = MaterialTheme.typography.bodySmall, color = SuccessGreen, fontWeight = FontWeight.Bold)
                    }
                    if (retailer.creditHold) {
                        Text("⚠ CREDIT HOLD: ${retailer.creditHoldReason ?: "কোনো কারণ উল্লেখ নেই"}", color = DangerRed, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(8.dp))
                    var showHold by remember { mutableStateOf(false) }
                    if (retailer.creditHold) {
                        Button(onClick = { MockRepository.setRetailerCreditHold(retailer.id, false, null, onRejected = { e -> android.widget.Toast.makeText(context, e, android.widget.Toast.LENGTH_LONG).show() }) }, colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)) { Text("Release Credit Hold") }
                    } else {
                        OutlinedButton(onClick = { showHold = true }) { Text("Put on Credit Hold") }
                    }
                    if (showHold) {
                        var holdReason by remember { mutableStateOf("") }
                        Dialog(onDismissRequest = { showHold = false }) {
                            Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("Credit Hold — ${retailer.name}", style = MaterialTheme.typography.titleMedium)
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedTextField(value = holdReason, onValueChange = { holdReason = it }, label = { Text("Reason (required)") }, modifier = Modifier.fillMaxWidth())
                                    Spacer(Modifier.height(10.dp))
                                    Button(onClick = { val ok = MockRepository.setRetailerCreditHold(retailer.id, true, holdReason, onRejected = { e -> android.widget.Toast.makeText(context, e, android.widget.Toast.LENGTH_LONG).show() }); if (ok) showHold = false }, enabled = holdReason.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Confirm Hold") }
                                }
                            }
                        }
                    }
                }
            }
            6 -> LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                val timeline = visits.sortedByDescending { it.checkInAt }
                items(timeline, key = { it.id }) { v ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("${v.employeeName} — ${v.purpose}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            Text(
                                "In: ${v.checkInAt.toLocalDate()} ${v.checkInAt.toLocalTime()}" + (v.checkOutAt?.let { " · Out: ${it.toLocalTime()}" } ?: " · checkout নেই"),
                                style = MaterialTheme.typography.labelSmall, color = TextSecondary,
                            )
                            if (v.checkOutAt != null) {
                                Text(
                                    "${v.verificationResult} (score ${v.verificationScore}) · ${MockRepository.visitLinkedActivitySummary(v)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = when (v.verificationResult) { "VERIFIED" -> SuccessGreen; "OUTSIDE_RADIUS", "WEAK_GPS", "STALE_LOCATION" -> WarningAmber; "MOCK_LOCATION_SUSPECTED" -> DangerRed; else -> TextSecondary },
                                )
                            }
                        }
                        com.abm.erp.core.UniversalActionMenu(moduleReference = "Visit", entityId = v.id, entityLabel = v.employeeName, shareText = "Visit by ${v.employeeName} — ${v.purpose}\n${v.checkInAt}", csvHeader = "Employee,Purpose,CheckIn", csvRow = com.abm.erp.core.toCsvRow(v.employeeName, v.purpose, v.checkInAt))
                    }
                }
                if (visits.isEmpty()) item { Text("এখনো কোনো visit রেকর্ড নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
            }
            7 -> { // Complaints — v113-77 fix, same reasoning as the Overview tab above:
                // now reads the real retailerId field (added v113-75) instead of the
                // dealerId field nothing ever populated for retailers.
                val complaints = MockRepository.customerComplaints.collectAsState().value.filter { it.partyType == com.abm.erp.data.PartyType.RETAILER && it.retailerId == retailer.id }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(complaints, key = { it.id }) { c ->
                        Column(Modifier.fillMaxWidth()) {
                            Text("${c.complaintNo} — ${c.category} (${c.priority})", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            Text(c.description, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            Text(c.status.name, style = MaterialTheme.typography.labelSmall, color = if (c.status == com.abm.erp.data.CustomerComplaintStatus.RESOLVED || c.status == com.abm.erp.data.CustomerComplaintStatus.CLOSED) SuccessGreen else WarningAmber)
                        }
                    }
                    if (complaints.isEmpty()) item { Text("কোনো complaint নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
                }
            }
            8 -> {
                var noteText by remember { mutableStateOf("") }
                val notesLog by MockRepository.activityLogFor("Retailer", retailer.id).collectAsState(initial = emptyList())
                val notes = remember(notesLog) { notesLog.filter { it.action == "NOTE" }.sortedByDescending { it.timestamp } }
                Column {
                    OutlinedTextField(
                        value = noteText, onValueChange = { noteText = it },
                        placeholder = { Text("একটা note লিখুন…") }, modifier = Modifier.fillMaxWidth(), minLines = 2,
                    )
                    Spacer(Modifier.height(6.dp))
                    Button(
                        onClick = {
                            if (noteText.isNotBlank()) {
                                MockRepository.logAudit("Retailer", retailer.id, "NOTE", newValue = noteText)
                                noteText = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Add Note") }
                    Spacer(Modifier.height(10.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(notes) { n ->
                            Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Text(n.newValueJson ?: "", style = MaterialTheme.typography.bodySmall)
                                Text("${n.performedBy} · ${n.timestamp}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            }
                        }
                        if (notes.isEmpty()) item { Text("এখনো কোনো note নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
            9 -> { // Audit History — full activity log, all actions (not filtered to NOTE)
                val fullLog by MockRepository.activityLogFor("Retailer", retailer.id).collectAsState(initial = emptyList())
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(fullLog.sortedByDescending { it.timestamp }, key = { it.id }) { h ->
                        Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Text("${h.action}" + (h.newValueJson?.let { " — $it" } ?: ""), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            Text("${h.performedBy} (${h.performedByRole}) · ${h.timestamp}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                    if (fullLog.isEmpty()) item { Text("কোনো history নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        var showDeleteConfirm by remember { mutableStateOf(false) }
        OutlinedButton(onClick = { showDeleteConfirm = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Delete Outlet", color = DangerRed)
        }
        if (showDeleteConfirm) {
            Dialog(onDismissRequest = { showDeleteConfirm = false }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Delete ${retailer.name}?", style = MaterialTheme.typography.titleMedium)
                        Text("এই outlet archive হয়ে যাবে (স্থায়ীভাবে মুছে যাবে না, প্রয়োজনে restore করা যাবে)।", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        val deleteRetailerContext = androidx.compose.ui.platform.LocalContext.current
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
                            Button(onClick = { panelScope.launch { val ok = MockRepository.deleteRetailer(retailer.id, onRejected = { e -> android.widget.Toast.makeText(deleteRetailerContext, e, android.widget.Toast.LENGTH_LONG).show() }); showDeleteConfirm = false; if (ok) onClose() } }, colors = ButtonDefaults.buttonColors(containerColor = DangerRed)) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Foundation 3 — real Visit Check-In. GPS capture (same fused-location
 * pattern as the retailer onboarding form), then real verification via
 * MockRepository.recordVisitCheckIn (accuracy/mock-suspicion/distance/
 * score), not just a raw coordinate save.
 */
@Composable
private fun VisitCheckInDialog(retailer: com.abm.erp.data.Retailer, onDismiss: () -> Unit, onCheckedIn: (com.abm.erp.data.VisitLog) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val checkInScope = rememberCoroutineScope()
    var gps by remember { mutableStateOf<Triple<Double, Double, Float?>?>(null) }
    var provider by remember { mutableStateOf<String?>(null) }
    var mockSuspected by remember { mutableStateOf(false) }
    var gpsError by remember { mutableStateOf<String?>(null) }
    var capturing by remember { mutableStateOf(false) }

    fun captureNow() {
        capturing = true
        val client = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(context)
        try {
            @Suppress("MissingPermission")
            client.lastLocation.addOnSuccessListener { loc ->
                capturing = false
                if (loc != null) {
                    gps = Triple(loc.latitude, loc.longitude, loc.accuracy)
                    provider = loc.provider
                    mockSuspected = loc.isFromMockProvider
                    gpsError = null
                } else gpsError = "No recent GPS fix — খোলা জায়গায় গিয়ে চেষ্টা করুন।"
            }.addOnFailureListener { capturing = false; gpsError = it.message ?: "Location fetch করা যায়নি।" }
        } catch (e: SecurityException) { capturing = false; gpsError = "Location permission প্রয়োজন।" }
    }
    val locationPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
    ) { granted -> if (granted) captureNow() else gpsError = "Location permission দেওয়া হয়নি।" }

    LaunchedEffect(Unit) {
        val granted = androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (granted) captureNow() else locationPermissionLauncher.launch(android.Manifest.permission.ACCESS_FINE_LOCATION)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 480.dp).verticalScroll(rememberScrollState())) {
                Text("Check In — ${retailer.name}", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                when {
                    capturing -> Text("📡 GPS location খোঁজা হচ্ছে...", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    gps != null -> {
                        val (lat, lng, acc) = gps!!
                        val quality = com.abm.erp.location.LocationVerification.classifyQuality(acc)
                        val distance = if (retailer.lat != null && retailer.lng != null) com.abm.erp.location.LocationVerification.distanceMeters(retailer.lat, retailer.lng, lat, lng) else null
                        Text("Accuracy: ${acc?.toInt() ?: "?"}m ($quality)", style = MaterialTheme.typography.bodySmall, color = when (quality) { com.abm.erp.location.LocationVerification.LocationQuality.EXCELLENT, com.abm.erp.location.LocationVerification.LocationQuality.GOOD -> SuccessGreen; com.abm.erp.location.LocationVerification.LocationQuality.ACCEPTABLE -> WarningAmber; else -> DangerRed })
                        distance?.let { Text("Distance from registered location: ${com.abm.erp.location.LocationVerification.formatDistance(it)}", style = MaterialTheme.typography.bodySmall) }
                        if (mockSuspected) Text("⚠ Mock location suspected!", color = DangerRed, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                        TextButton(onClick = { captureNow() }) { Text("↻ Retry Location") }
                    }
                    else -> {}
                }
                gpsError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        gps?.let { (lat, lng, acc) ->
                            val deviceId = android.provider.Settings.Secure.getString(context.contentResolver, android.provider.Settings.Secure.ANDROID_ID)
                            checkInScope.launch {
                                val visit = MockRepository.recordVisitCheckIn(
                                    com.abm.erp.data.PartyType.RETAILER, retailer.id, lat, lng,
                                    accuracyMeters = acc, provider = provider, mockSuspected = mockSuspected, deviceId = deviceId,
                                )
                                if (visit != null) {
                                    MockRepository.recordEmployeeLocationSnapshot(lat, lng, acc, provider, null, mockSuspected, deviceId, visitId = visit.id)
                                    onCheckedIn(visit)
                                }
                            }
                        }
                    },
                    enabled = gps != null && !capturing,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Confirm Check In") }
            }
        }
    }
}

@Composable
private fun VisitCheckOutDialog(retailer: com.abm.erp.data.Retailer, visit: com.abm.erp.data.VisitLog, onDismiss: () -> Unit, onCheckedOut: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var gps by remember { mutableStateOf<Triple<Double, Double, Float?>?>(null) }
    var mockSuspected by remember { mutableStateOf(false) }
    var notes by remember { mutableStateOf("") }

    fun captureNow() {
        val client = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(context)
        try {
            @Suppress("MissingPermission")
            client.lastLocation.addOnSuccessListener { loc -> if (loc != null) { gps = Triple(loc.latitude, loc.longitude, loc.accuracy); mockSuspected = loc.isFromMockProvider } }
        } catch (e: SecurityException) { /* permission already granted at check-in time in the normal flow */ }
    }
    LaunchedEffect(Unit) { captureNow() }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                Text("Check Out — ${retailer.name}", style = MaterialTheme.typography.titleMedium)
                Text("Visit duration so far: ${java.time.Duration.between(visit.checkInAt, java.time.LocalDateTime.now()).toMinutes()} min", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Visit notes") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        gps?.let { (lat, lng, acc) ->
                            if (MockRepository.recordVisitCheckOut(visit.id, lat, lng, acc, mockSuspected, notes)) onCheckedOut()
                        }
                    },
                    enabled = gps != null,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Confirm Check Out") }
            }
        }
    }
}

/** Foundation 3, Section 2 — real recapture flow: GPS capture, mandatory reason, real updateRetailerLocation (history-preserving, not silent overwrite). */
@Composable
private fun RecaptureLocationDialog(retailer: com.abm.erp.data.Retailer, onDismiss: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var gps by remember { mutableStateOf<Triple<Double, Double, Float?>?>(null) }
    var provider by remember { mutableStateOf<String?>(null) }
    var reason by remember { mutableStateOf("") }
    var gpsError by remember { mutableStateOf<String?>(null) }

    fun captureNow() {
        val client = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(context)
        try {
            @Suppress("MissingPermission")
            client.lastLocation.addOnSuccessListener { loc ->
                if (loc != null) { gps = Triple(loc.latitude, loc.longitude, loc.accuracy); provider = loc.provider; gpsError = null }
                else gpsError = "No recent GPS fix."
            }.addOnFailureListener { gpsError = it.message }
        } catch (e: SecurityException) { gpsError = "Location permission প্রয়োজন।" }
    }
    val locationPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
    ) { granted -> if (granted) captureNow() else gpsError = "Permission দেওয়া হয়নি।" }
    LaunchedEffect(Unit) {
        val granted = androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (granted) captureNow() else locationPermissionLauncher.launch(android.Manifest.permission.ACCESS_FINE_LOCATION)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp).heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                Text("Recapture Location — ${retailer.name}", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                gps?.let { (lat, lng, acc) ->
                    val quality = com.abm.erp.location.LocationVerification.classifyQuality(acc)
                    Text("New: $lat, $lng (±${acc?.toInt() ?: "?"}m, $quality)", style = MaterialTheme.typography.bodySmall)
                    if (retailer.lat != null && retailer.lng != null) {
                        val moved = com.abm.erp.location.LocationVerification.distanceMeters(retailer.lat, retailer.lng, lat, lng)
                        Text("Moved ${com.abm.erp.location.LocationVerification.formatDistance(moved)} from previous location", style = MaterialTheme.typography.labelSmall, color = if (moved > 500) DangerRed else TextSecondary)
                    }
                } ?: Text("📡 GPS capturing...", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                gpsError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason for update (required)") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { gps?.let { (lat, lng, acc) -> if (MockRepository.updateRetailerLocation(retailer.id, lat, lng, acc?.toDouble(), provider, null, "GPS", reason, onRejected = { e -> gpsError = e })) onDismiss() } },
                    enabled = gps != null && reason.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Submit for Verification") }
            }
        }
    }
}

/** Foundation 3, Section 20 — Manager Location Review. reviewLocationAlert existed with no UI; this is that UI. */
@Composable
internal fun LocationAlertsTab() {
    val alerts by MockRepository.locationAlerts.collectAsState()
    var showReviewed by remember { mutableStateOf(false) }
    val visible = alerts.filter { showReviewed || !it.isReviewed }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Location Alerts (${visible.size})", style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { showReviewed = !showReviewed }) { Text(if (showReviewed) "Unreviewed only" else "Show all") }
        }
        Spacer(Modifier.height(8.dp))
        if (visible.isEmpty()) {
            Text("কোনো unreviewed location alert নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(visible, key = { it.id }) { alert ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(alert.type, fontWeight = FontWeight.SemiBold, color = if (alert.severity == "CRITICAL") DangerRed else WarningAmber)
                            Text(alert.message, style = MaterialTheme.typography.bodySmall)
                            Text(java.time.Instant.ofEpochMilli(alert.createdAtEpochMillis).atZone(java.time.ZoneOffset.UTC).toLocalDateTime().toString(), style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            if (alert.isReviewed) {
                                Text("✓ Reviewed by ${alert.reviewedBy}: ${alert.reviewAction}" + (alert.reviewComment?.let { " — $it" } ?: ""), style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                            }
                        }
                    }
                    if (!alert.isReviewed) {
                        Spacer(Modifier.height(6.dp))
                        var showCommentFor by remember { mutableStateOf<String?>(null) }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            TextButton(onClick = { showCommentFor = "ACCEPTED" }) { Text("Accept") }
                            TextButton(onClick = { showCommentFor = "ESCALATED" }) { Text("Escalate", color = WarningAmber) }
                            TextButton(onClick = { showCommentFor = "REJECTED" }) { Text("Reject", color = DangerRed) }
                        }
                        showCommentFor?.let { action ->
                            var comment by remember { mutableStateOf("") }
                            Dialog(onDismissRequest = { showCommentFor = null }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text("$action — ${alert.type}", style = MaterialTheme.typography.titleMedium)
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(value = comment, onValueChange = { comment = it }, label = { Text("Comment") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(10.dp))
                                        val alertContext = androidx.compose.ui.platform.LocalContext.current
                                        Button(onClick = { MockRepository.reviewLocationAlert(alert.id, action, comment.ifBlank { null }, onRejected = { e -> android.widget.Toast.makeText(alertContext, e, android.widget.Toast.LENGTH_LONG).show() }); showCommentFor = null }, modifier = Modifier.fillMaxWidth()) { Text("Confirm") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Foundation 4, Section 12 — Manager Review of Security Events. */
@Composable
internal fun SecurityEventsTab() {
    val events by MockRepository.securityEvents.collectAsState()
    var showReviewed by remember { mutableStateOf(false) }
    val visible = events.filter { showReviewed || !it.isReviewed }
    val territoriesList by MockRepository.territories.collectAsState()

    Column(Modifier.fillMaxSize()) {
        var showTerritoryMgmt by remember { mutableStateOf(false) }
        TextButton(onClick = { showTerritoryMgmt = !showTerritoryMgmt }) { Text(if (showTerritoryMgmt) "Hide Territory Boundaries" else "🗺 Manage Territory Boundaries") }
        if (showTerritoryMgmt) {
            territoriesList.take(20).forEach { t ->
                var showEdit by remember(t.id) { mutableStateOf(false) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${t.division}/${t.district ?: "—"} · ${t.polygon.size} pts (v${t.polygonVersion})", style = MaterialTheme.typography.labelSmall)
                    TextButton(onClick = { showEdit = true }) { Text("Edit") }
                }
                if (showEdit) {
                    var pointsInput by remember { mutableStateOf(t.polygon.joinToString(";") { "${it.first},${it.second}" }) }
                    Dialog(onDismissRequest = { showEdit = false }) {
                        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                            Column(Modifier.padding(16.dp).heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                                Text("Boundary — ${t.division}", style = MaterialTheme.typography.titleMedium)
                                Text("Format: lat,lng;lat,lng;... (min 3 points)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = pointsInput, onValueChange = { pointsInput = it }, modifier = Modifier.fillMaxWidth())
                                var polygonError by remember { mutableStateOf<String?>(null) }
                                polygonError?.let { Text(it, color = DangerRed, style = MaterialTheme.typography.labelSmall) }
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        val parsed = pointsInput.split(";").filter { it.isNotBlank() }.mapNotNull {
                                            val p = it.split(","); if (p.size == 2) p[0].trim().toDoubleOrNull()?.let { la -> p[1].trim().toDoubleOrNull()?.let { lo -> la to lo } } else null
                                        }
                                        if (MockRepository.setTerritoryPolygon(t.id, parsed, onRejected = { r -> polygonError = r })) showEdit = false
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                ) { Text("Save Boundary") }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Security Events (${visible.size})", style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { showReviewed = !showReviewed }) { Text(if (showReviewed) "Unreviewed only" else "Show all") }
        }
        Spacer(Modifier.height(8.dp))
        if (visible.isEmpty()) Text("কোনো unreviewed security event নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(visible, key = { it.id }) { ev ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(ev.type, fontWeight = FontWeight.SemiBold, color = if (ev.severity == "CRITICAL") DangerRed else WarningAmber)
                    Text(ev.message, style = MaterialTheme.typography.bodySmall)
                    Text("${ev.employeeName} · ${ev.action}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    if (ev.isReviewed) {
                        Text("✓ ${ev.reviewedBy}: ${ev.reviewAction}", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
                    } else {
                        var showAction by remember { mutableStateOf<String?>(null) }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            TextButton(onClick = { showAction = "APPROVED" }) { Text("Approve") }
                            TextButton(onClick = { showAction = "WARNED" }) { Text("Warn") }
                            TextButton(onClick = { showAction = "SUSPENDED" }) { Text("Suspend", color = DangerRed) }
                            TextButton(onClick = { showAction = "ESCALATED" }) { Text("Escalate", color = WarningAmber) }
                        }
                        showAction?.let { action ->
                            var comment by remember { mutableStateOf("") }
                            Dialog(onDismissRequest = { showAction = null }) {
                                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text("$action — ${ev.type}", style = MaterialTheme.typography.titleMedium)
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(value = comment, onValueChange = { comment = it }, label = { Text("Comment") }, modifier = Modifier.fillMaxWidth())
                                        Spacer(Modifier.height(10.dp))
                                        val eventContext = androidx.compose.ui.platform.LocalContext.current
                                        Button(onClick = { MockRepository.reviewSecurityEvent(ev.id, action, comment.ifBlank { null }, onRejected = { e -> android.widget.Toast.makeText(eventContext, e, android.widget.Toast.LENGTH_LONG).show() }); showAction = null }, modifier = Modifier.fillMaxWidth()) { Text("Confirm") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Bangladesh Location Master — Section 11 admin screen. View hierarchy/search/import-status, add company markets, resolve legacy addresses. */
@Composable
private fun LocationMasterAdminTab() {
    val allLocations by MockRepository.administrativeLocations.collectAsState()
    var subTab by remember { mutableStateOf(0) }
    val marketScope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        Text("Bangladesh Location Master", style = MaterialTheme.typography.titleMedium)
        Text(
            "রেকর্ড: ${allLocations.size} (Division/District/Upazila/Union) · Source: nuhil/bangladesh-geocode",
            style = MaterialTheme.typography.labelSmall, color = TextSecondary,
        )
        val validation = remember(allLocations) { MockRepository.validateBangladeshLocationImport() }
        val importResult by MockRepository.lastBdImportResult.collectAsState()
        importResult?.let { r ->
            if (!r.validationPassed) {
                Text("⚠ সর্বশেষ import validation FAILED: ${r.validationErrors.joinToString("; ")}", style = MaterialTheme.typography.labelSmall, color = DangerRed)
            }
        }
        Text(
            "Division: ${validation.divisionCount}${if (validation.divisionsMatchExpected8) " ✓" else " ⚠"} · District: ${validation.districtCount}${if (validation.districtsMatchExpected64) " ✓" else " ⚠"} · Upazila: ${validation.upazilaCount} · Union: ${validation.unionCount}",
            style = MaterialTheme.typography.labelSmall,
            color = if (validation.divisionsMatchExpected8 && validation.districtsMatchExpected64 && validation.orphanDistricts == 0 && validation.orphanUpazilas == 0 && validation.orphanUnions == 0 && validation.duplicateSourceCodes == 0) SuccessGreen else WarningAmber,
        )
        if (validation.orphanDistricts + validation.orphanUpazilas + validation.orphanUnions + validation.duplicateSourceCodes + validation.blankNames > 0) {
            Text(
                "⚠ orphan: ${validation.orphanDistricts + validation.orphanUpazilas + validation.orphanUnions}, duplicate sourceCode: ${validation.duplicateSourceCodes}, blank name: ${validation.blankNames}",
                style = MaterialTheme.typography.labelSmall, color = DangerRed,
            )
        }
        Spacer(Modifier.height(8.dp))
        // v113-247 — the person's own sharp observation: a separate
        // "Search" tool here was genuinely redundant with Universal
        // Search once Universal Search's own Territory results were
        // extended to cover the full administrative-location database
        // (not just zones with an existing dealer) — the one real gap
        // that had made this second search feel necessary in the first
        // place. Removed rather than left as dead weight; the other
        // three sub-tabs are real, distinct admin data-integrity tools
        // (not searches), so they stay, renumbered down by one.
        ScrollableTabRow(selectedTabIndex = subTab) {
            Tab(selected = subTab == 0, onClick = { subTab = 0 }, text = { Text("Legacy Address", style = MaterialTheme.typography.labelSmall) })
            Tab(selected = subTab == 1, onClick = { subTab = 1 }, text = { Text("Company Markets", style = MaterialTheme.typography.labelSmall) })
            Tab(selected = subTab == 2, onClick = { subTab = 2 }, text = { Text("Territory Match", style = MaterialTheme.typography.labelSmall) })
        }
        Spacer(Modifier.height(8.dp))
        when (subTab) {
            0 -> {
                val resolutions = remember { MockRepository.resolveLegacyRetailerAddresses() }
                val unresolved = resolutions.filter { it.matchType == "UNRESOLVED" }
                Text("Unresolved legacy addresses: ${unresolved.size} / ${resolutions.size}", fontWeight = FontWeight.Bold, color = if (unresolved.isNotEmpty()) WarningAmber else SuccessGreen)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(unresolved) { res ->
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Text(res.retailerName, fontWeight = FontWeight.SemiBold)
                            Text("Free text: ${res.freeTextDistrict} / ${res.freeTextUpazila}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                            var showResolve by remember { mutableStateOf(false) }
                            TextButton(onClick = { showResolve = true }) { Text("Resolve manually") }
                            if (showResolve) {
                                var sel by remember { mutableStateOf(com.abm.erp.ui.core.AdminSelection()) }
                                Dialog(onDismissRequest = { showResolve = false }) {
                                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                                        Column(Modifier.padding(16.dp)) {
                                            Text("Resolve — ${res.retailerName}", style = MaterialTheme.typography.titleMedium)
                                            Spacer(Modifier.height(8.dp))
                                            com.abm.erp.ui.core.AdminLocationCascadeSelector(sel, { sel = it })
                                            Spacer(Modifier.height(10.dp))
                                            val legacyContext = androidx.compose.ui.platform.LocalContext.current
                                            Button(onClick = { MockRepository.confirmLegacyAddressMatch(res.retailerId, sel.districtId, sel.upazilaId, onRejected = { e -> android.widget.Toast.makeText(legacyContext, e, android.widget.Toast.LENGTH_LONG).show() }); showResolve = false }, modifier = Modifier.fillMaxWidth()) { Text("Confirm") }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (unresolved.isEmpty()) item { Text("সব retailer address resolve হয়ে গেছে।", color = SuccessGreen, style = MaterialTheme.typography.bodySmall) }
                }
            }
            1 -> {
                val markets by MockRepository.companyMarkets.collectAsState()
                var showAdd by remember { mutableStateOf(false) }
                TextButton(onClick = { showAdd = true }) { Text("+ Add Company Market") }
                if (showAdd) {
                    var name by remember { mutableStateOf("") }
                    var sel by remember { mutableStateOf(com.abm.erp.ui.core.AdminSelection()) }
                    Dialog(onDismissRequest = { showAdd = false }) {
                        Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
                            Column(Modifier.padding(16.dp).heightIn(max = 500.dp).verticalScroll(rememberScrollState())) {
                                Text("New Company Market/Bazaar", style = MaterialTheme.typography.titleMedium)
                                val marketContext = androidx.compose.ui.platform.LocalContext.current
                                Text("সরকারি administrative রেকর্ড থেকে আলাদাভাবে চিহ্নিত থাকবে।", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Market name") }, modifier = Modifier.fillMaxWidth())
                                Spacer(Modifier.height(8.dp))
                                com.abm.erp.ui.core.AdminLocationCascadeSelector(sel, { sel = it })
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        val parent = sel.unionId ?: sel.upazilaId
                                        if (name.isNotBlank() && parent != null) {
                                            marketScope.launch {
                                                if (MockRepository.createCompanyMarket(name, parent, null, null, onRejected = { e -> android.widget.Toast.makeText(marketContext, e, android.widget.Toast.LENGTH_LONG).show() })) showAdd = false
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                ) { Text("Save") }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(markets) { m -> Text("${m.name} (${m.verificationStatus})", style = MaterialTheme.typography.bodySmall) }
                    if (markets.isEmpty()) item { Text("কোনো company market নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
                }
            }
            else -> {
                // Section 8 — Employee Hierarchy/Territory integration with the Bangladesh Location Master.
                val territories by MockRepository.territories.collectAsState()
                val matches = remember(territories, allLocations) { territories.map { MockRepository.matchTerritoryToAdminHierarchy(it) } }
                Text("Territory ↔ Administrative Hierarchy Match", fontWeight = FontWeight.Bold)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(territories.zip(matches)) { (t, m) ->
                        Text(
                            "${t.division}/${t.district ?: "—"}: ${if (m.resolved) "matched" else "unresolved"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (m.resolved) SuccessGreen else WarningAmber,
                        )
                    }
                    if (territories.isEmpty()) item { Text("কোনো territory নেই।", color = TextSecondary, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
    }
}
