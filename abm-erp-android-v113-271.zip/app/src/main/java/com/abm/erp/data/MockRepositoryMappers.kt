package com.abm.erp.data
import android.content.Context
import com.abm.erp.location.GeoLock
import com.abm.erp.location.LocationVerification
import com.abm.erp.executive.ExecutiveIntelligence
import com.abm.erp.data.room.AppDatabase
import com.abm.erp.data.room.ApprovalRequestEntity
import com.abm.erp.data.room.AttendanceRecordEntity
import com.abm.erp.data.room.BoardroomQueryEntity
import com.abm.erp.data.room.Converters
import com.abm.erp.data.room.CourierPartnerEntity
import com.abm.erp.data.room.DealerEntity
import com.abm.erp.data.room.EngagementCampaignEntity
import com.abm.erp.data.room.FieldEmployeeRouteEntity
import com.abm.erp.data.room.AuditLogEntity
import com.abm.erp.data.room.LedgerEntryEntity
import com.abm.erp.data.room.PaymentProofEntity
import com.abm.erp.data.room.PayrollLineEntity
import com.abm.erp.data.room.ProductionBatchEntity
import com.abm.erp.data.room.RawMaterialLotEntity
import com.abm.erp.data.room.RetailOrderEntity
import com.abm.erp.data.room.InvoiceEntity
import com.abm.erp.data.room.ShipmentEntity
import com.abm.erp.data.room.TaskItemEntity
import com.abm.erp.data.room.QuotationEntity
import com.abm.erp.data.room.DeliveryChallanEntity
import com.abm.erp.data.room.SalesReturnEntity
import com.abm.erp.data.room.PartyLedgerEntryEntity
import com.abm.erp.data.room.PartyCollectionEntity
import com.abm.erp.data.room.DiscountRuleEntity
import com.abm.erp.data.room.SalesRouteEntity
import com.abm.erp.data.room.VisitLogEntity
import com.abm.erp.data.room.AttachmentEntity
import com.abm.erp.data.room.BillOfMaterialsEntity
import com.abm.erp.data.room.EmployeeLifecycleEventEntity
import com.abm.erp.data.room.LeaveRequestEntity
import com.abm.erp.data.room.MachineLogEntity
import com.abm.erp.data.room.NotificationEntryEntity
import com.abm.erp.data.room.ProductionLossEntity
import com.abm.erp.data.room.ProductionOrderEntity
import com.abm.erp.data.room.QualityCheckEntity
import com.abm.erp.data.room.RetailerEntity
import com.abm.erp.data.room.RoleDefinitionEntity
import com.abm.erp.data.room.TerritoryEntity
import com.abm.erp.data.room.VehicleEntity
import com.abm.erp.data.room.VehicleLocationPingEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import androidx.room.withTransaction
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.runBlocking
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneOffset

// ============================================================================
// v113-81 — SPLIT OUT OF MockRepository.kt, at the person's instruction ("mock
// repository file e sobkisu rakhle pore alada korte problem hote pare").
//
// These are the entity<->domain mapper extension functions that used to sit
// below the `object MockRepository { }` closing brace in the same file. They
// were file-`private`; moving them to their own file required `internal`
// (same module, no wider). NOTHING inside any mapper changed — this is a
// mechanical relocation, verified by diffing the moved text against the
// original. Same package, so no call site anywhere changed either.
//
// This is deliberately the FIRST split and not the whole split: the object's
// state (StateFlows, DAOs, sync listeners) is heavily interlocked and pulling
// business-logic groups out into separate repositories is real re-architecture
// that must not be rushed hours before a compile. Mappers were the one piece
// that was already cleanly separable.
// ============================================================================


// ================= Entity <-> domain mappers =================

internal fun RetailOrder.toEntity() = RetailOrderEntity(
    id = id, orderNo = orderNo, retailerName = retailerName, loggedBySoId = loggedBySoId, zone = zone, items = items,
    amount = amount, stage = stage.name, routedDealerId = routedDealerId,
    loggedAtEpochMillis = loggedAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    retailerPhotoUri = retailerPhotoUri, retailerLat = retailerLat, retailerLng = retailerLng, retailerQrCode = retailerQrCode,
    channel = channel, anonymous = anonymous, photoPurpose = photoPurpose, retailerId = retailerId,
    lineItemsRaw = Converters.packSalesInvoiceItems(lineItems),
)

internal fun RetailOrderEntity.toDomain() = RetailOrder(
    id = id, orderNo = orderNo, retailerName = retailerName, loggedBySoId = loggedBySoId, zone = zone, items = items,
    amount = amount, stage = OrderStage.valueOf(stage), routedDealerId = routedDealerId,
    loggedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(loggedAtEpochMillis), ZoneOffset.UTC),
    retailerPhotoUri = retailerPhotoUri, retailerLat = retailerLat, retailerLng = retailerLng, retailerQrCode = retailerQrCode,
    channel = channel, anonymous = anonymous, photoPurpose = photoPurpose, retailerId = retailerId,
    lineItems = if (lineItemsRaw.isBlank()) emptyList() else Converters.unpackSalesInvoiceItems(lineItemsRaw),
)

internal fun DealerEntity.toDomain() = Dealer(
    id = id, name = name, zone = zone, dueBalance = dueBalance, salesLast90Days = salesLast90Days, pin = pin,
    pinHash = pinHash, pinSalt = pinSalt, pinIterations = pinIterations, stockUnits = stockUnits,
    phone = phone, address = address, territoryId = territoryId,
    divisionId = divisionId, districtId = districtId, upazilaId = upazilaId, unionId = unionId, wardId = wardId, routeId = routeId, legacyAddressResolved = legacyAddressResolved,
    dedupKey = dedupKey, isActive = isActive, isDeleted = isDeleted,
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    deletedAt = deletedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) }, deletedBy = deletedBy,
    classification = classification, creditLimit = creditLimit,
    monthlyTarget = monthlyTarget, weeklyPaidAmount = weeklyPaidAmount, weekStartEpochDay = weekStartEpochDay,
    creditStatus = creditStatus, creditStatusReason = creditStatusReason, creditStatusChangedBy = creditStatusChangedBy,
    creditStatusChangedAt = creditStatusChangedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    promiseToPayDate = promiseToPayEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    promiseToPayAmount = promiseToPayAmount, promiseNote = promiseNote,
    dealerCode = dealerCode, proprietorName = proprietorName, altPhone = altPhone, nationalId = nationalId, email = email,
    marketName = marketName, lat = lat, lng = lng, gpsAccuracyMeters = gpsAccuracyMeters,
    geoCapturedAt = geoCapturedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    assignedEmployeeId = assignedEmployeeId, assignedManagerId = assignedManagerId,
    openingBalance = openingBalance, paymentTermsDays = paymentTermsDays, tradeLicenseNumber = tradeLicenseNumber, notes = notes,
    status = status, approvedBy = approvedBy, approvedByName = approvedByName, approvedAtEpochMillis = approvedAtEpochMillis,
    approvalComment = approvalComment, previousStatus = previousStatus, resolvedApprovalPath = resolvedApprovalPath,
    photoUri = photoUri,
)

internal fun Dealer.toEntity() = DealerEntity(
    id = id, name = name, zone = zone, dueBalance = dueBalance, salesLast90Days = salesLast90Days, pin = pin,
    pinHash = pinHash, pinSalt = pinSalt, pinIterations = pinIterations, stockUnits = stockUnits,
    phone = phone, address = address, territoryId = territoryId,
    divisionId = divisionId, districtId = districtId, upazilaId = upazilaId, unionId = unionId, wardId = wardId, routeId = routeId, legacyAddressResolved = legacyAddressResolved,
    dedupKey = dedupKey, isActive = isActive, isDeleted = isDeleted,
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    deletedAtEpochMillis = deletedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(), deletedBy = deletedBy,
    classification = classification, creditLimit = creditLimit,
    monthlyTarget = monthlyTarget, weeklyPaidAmount = weeklyPaidAmount, weekStartEpochDay = weekStartEpochDay,
    creditStatus = creditStatus, creditStatusReason = creditStatusReason, creditStatusChangedBy = creditStatusChangedBy,
    creditStatusChangedAtEpochMillis = creditStatusChangedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    promiseToPayEpochMillis = promiseToPayDate?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    promiseToPayAmount = promiseToPayAmount, promiseNote = promiseNote,
    dealerCode = dealerCode, proprietorName = proprietorName, altPhone = altPhone, nationalId = nationalId, email = email,
    marketName = marketName, lat = lat, lng = lng, gpsAccuracyMeters = gpsAccuracyMeters,
    geoCapturedAtEpochMillis = geoCapturedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    assignedEmployeeId = assignedEmployeeId, assignedManagerId = assignedManagerId,
    openingBalance = openingBalance, paymentTermsDays = paymentTermsDays, tradeLicenseNumber = tradeLicenseNumber, notes = notes,
    status = status, approvedBy = approvedBy, approvedByName = approvedByName, approvedAtEpochMillis = approvedAtEpochMillis,
    approvalComment = approvalComment, previousStatus = previousStatus, resolvedApprovalPath = resolvedApprovalPath,
    photoUri = photoUri,
)

internal fun Retailer.toEntity() = RetailerEntity(
    id = id, retailerCode = retailerCode, name = name, ownerName = ownerName, phone = phone, altPhone = altPhone, email = email,
    address = address, district = district, upazila = upazila, union_ = union_, market = market, area = area, postalCode = postalCode,
    territoryId = territoryId, dealerId = dealerId, lat = lat, lng = lng, gpsAccuracyMeters = gpsAccuracyMeters,
    geoCapturedAtEpochMillis = geoCapturedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    photoUri = photoUri, ownerPhotoUri = ownerPhotoUri, tradeLicenseNo = tradeLicenseNo, nidRef = nidRef, qrCode = qrCode, dedupKey = dedupKey,
    classification = classification, businessStatus = businessStatus, statusReason = statusReason,
    openingDateEpochDay = openingDate?.toEpochDay(), officerId = officerId, officerName = officerName,
    paymentTermsDays = paymentTermsDays, allowedCreditDays = allowedCreditDays,
    lastCollectionDateEpochMillis = lastCollectionDate?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    lastOrderDateEpochMillis = lastOrderDate?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    lastVisitDateEpochMillis = lastVisitDate?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    nextPlannedVisitEpochMillis = nextPlannedVisit?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    preferredProducts = preferredProducts, notes = notes, tags = tags, isActive = isActive, isDeleted = isDeleted,
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    updatedBy = updatedBy, updatedAtEpochMillis = updatedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    deletedAtEpochMillis = deletedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(), deletedBy = deletedBy,
    dueBalance = dueBalance, creditLimit = creditLimit, creditHold = creditHold, creditHoldReason = creditHoldReason,
    outletCategory = outletCategory, outletType = outletType, routeId = routeId,
    onboardingStatus = onboardingStatus, rejectReason = rejectReason, standardDiscountPct = standardDiscountPct, commissionPct = commissionPct,
    locationProvider = locationProvider, locationCapturedByEmployeeId = locationCapturedByEmployeeId, locationCapturedDeviceId = locationCapturedDeviceId,
    locationCaptureMethod = locationCaptureMethod, locationVerificationStatus = locationVerificationStatus, locationVerificationScore = locationVerificationScore,
    locationVerifiedBy = locationVerifiedBy, locationVerifiedAtEpochMillis = locationVerifiedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    locationVerificationComment = locationVerificationComment, geofenceRadiusMeters = geofenceRadiusMeters,
    lastLocationUpdateReason = lastLocationUpdateReason, locationRevision = locationRevision,
    pinHash = pinHash, pinSalt = pinSalt, pinIterations = pinIterations,
)

internal fun RetailerEntity.toDomain() = Retailer(
    id = id, retailerCode = retailerCode, name = name, ownerName = ownerName, phone = phone, altPhone = altPhone, email = email,
    address = address, district = district, upazila = upazila, union_ = union_, market = market, area = area, postalCode = postalCode,
    territoryId = territoryId, dealerId = dealerId, lat = lat, lng = lng, gpsAccuracyMeters = gpsAccuracyMeters,
    geoCapturedAt = geoCapturedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    photoUri = photoUri, ownerPhotoUri = ownerPhotoUri, tradeLicenseNo = tradeLicenseNo, nidRef = nidRef, qrCode = qrCode, dedupKey = dedupKey,
    classification = classification, businessStatus = businessStatus, statusReason = statusReason,
    openingDate = openingDateEpochDay?.let { LocalDate.ofEpochDay(it) }, officerId = officerId, officerName = officerName,
    paymentTermsDays = paymentTermsDays, allowedCreditDays = allowedCreditDays,
    lastCollectionDate = lastCollectionDateEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    lastOrderDate = lastOrderDateEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    lastVisitDate = lastVisitDateEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    nextPlannedVisit = nextPlannedVisitEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    preferredProducts = preferredProducts, notes = notes, tags = tags, isActive = isActive, isDeleted = isDeleted,
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    updatedBy = updatedBy, updatedAt = updatedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    deletedAt = deletedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) }, deletedBy = deletedBy,
    dueBalance = dueBalance, creditLimit = creditLimit, creditHold = creditHold, creditHoldReason = creditHoldReason,
    outletCategory = outletCategory, outletType = outletType, routeId = routeId,
    onboardingStatus = onboardingStatus, rejectReason = rejectReason, standardDiscountPct = standardDiscountPct, commissionPct = commissionPct,
    locationProvider = locationProvider, locationCapturedByEmployeeId = locationCapturedByEmployeeId, locationCapturedDeviceId = locationCapturedDeviceId,
    locationCaptureMethod = locationCaptureMethod, locationVerificationStatus = locationVerificationStatus, locationVerificationScore = locationVerificationScore,
    locationVerifiedBy = locationVerifiedBy, locationVerifiedAt = locationVerifiedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    locationVerificationComment = locationVerificationComment, geofenceRadiusMeters = geofenceRadiusMeters,
    lastLocationUpdateReason = lastLocationUpdateReason, locationRevision = locationRevision,
    pinHash = pinHash, pinSalt = pinSalt, pinIterations = pinIterations,
)

internal fun Territory.toEntity() = TerritoryEntity(
    id = id, division = division, district = district, market = market, parentTerritoryId = parentTerritoryId, zoneName = zoneName,
    country = country, upazila = upazila, area = area, beat = beat, code = code,
    polygonRaw = polygon.joinToString(";") { "${it.first},${it.second}" }, polygonVersion = polygonVersion,
    defaultVisitRadiusMeters = defaultVisitRadiusMeters, isActive = isActive,
    effectiveFromEpochDay = effectiveFrom?.toEpochDay(), effectiveToEpochDay = effectiveTo?.toEpochDay(),
    assignedManagerIdsRaw = assignedManagerIds.joinToString(","), assignedOfficerIdsRaw = assignedOfficerIds.joinToString(","),
)

internal fun TerritoryEntity.toDomain() = Territory(
    id = id, division = division, district = district, market = market, parentTerritoryId = parentTerritoryId, zoneName = zoneName,
    country = country, upazila = upazila, area = area, beat = beat, code = code,
    polygon = if (polygonRaw.isBlank()) emptyList() else polygonRaw.split(";").filter { it.isNotBlank() }.map { val p = it.split(","); p[0].toDouble() to p[1].toDouble() },
    polygonVersion = polygonVersion, defaultVisitRadiusMeters = defaultVisitRadiusMeters, isActive = isActive,
    effectiveFrom = effectiveFromEpochDay?.let { LocalDate.ofEpochDay(it) }, effectiveTo = effectiveToEpochDay?.let { LocalDate.ofEpochDay(it) },
    assignedManagerIds = if (assignedManagerIdsRaw.isBlank()) emptyList() else assignedManagerIdsRaw.split(","),
    assignedOfficerIds = if (assignedOfficerIdsRaw.isBlank()) emptyList() else assignedOfficerIdsRaw.split(","),
)

internal fun RoleDefinition.toEntity() = com.abm.erp.data.room.RoleDefinitionEntity(
    role = roleKey, label = label, modulePermissionsRaw = Converters.packModulePermissions(modulePermissions),
)

internal fun com.abm.erp.data.room.RoleDefinitionEntity.toDomain() = RoleDefinition(
    roleKey = role, label = label, modulePermissions = Converters.unpackModulePermissions(modulePermissionsRaw),
)

internal fun FieldEmployeeRouteEntity.toDomain() = FieldEmployeeRoute(
    employeeId = employeeId, employeeName = employeeName,
    date = LocalDate.ofEpochDay(dateEpochDay),
    breadcrumbs = Converters.unpackBreadcrumbs(breadcrumbsRaw),
)

internal fun EngagementCampaignEntity.toDomain() = EngagementCampaign(
    id = id, channel = CampaignChannel.valueOf(channel), message = message, targetZone = targetZone, sentCount = sentCount,
)

internal fun PayrollLineEntity.toDomain() = PayrollLine(
    employeeId = employeeId, employeeName = employeeName, basePay = basePay, targetAmount = targetAmount,
    achievedAmount = achievedAmount, commissionRate = commissionRate, unapprovedAbsenceDays = unapprovedAbsenceDays,
    dailyWage = dailyWage, overtimeMinutes = overtimeMinutes, overtimePay = overtimePay,
    attendanceDaysPresent = attendanceDaysPresent, attendanceDaysAbsent = attendanceDaysAbsent,
)

internal fun InvoiceEntity.toVoiceDomain() = VoiceInvoice(
    id = id, dealerId = dealerId, items = Converters.unpackInvoiceItems(lineItemsRaw), previousDue = previousDue,
)

internal fun PaymentProofEntity.toDomain() = PaymentProof(
    id = id, dealerId = dealerId, amount = amount, proofRef = proofRef,
    status = PaymentVerificationStatus.valueOf(status),
)

internal fun RawMaterialLotEntity.toDomain() = RawMaterialLot(
    id = id, materialName = materialName, qtyKg = qtyKg, costPerKg = costPerKg,
    purchasedOn = LocalDate.ofEpochDay(purchasedOnEpochDay),
)

// v113-221 — the reverse direction never existed (only Entity->Domain was
// built, since every prior creation path constructed the Entity directly
// rather than going through the domain class). The new Chairman-direct
// raw-material entry/edit functions construct the domain RawMaterialLot
// first (so their own validation/audit logic reads naturally), so this
// direction is now genuinely needed, not just for symmetry.
internal fun RawMaterialLot.toEntity() = RawMaterialLotEntity(
    id = id, materialName = materialName, qtyKg = qtyKg, costPerKg = costPerKg,
    purchasedOnEpochDay = purchasedOn.toEpochDay(),
)

internal fun ProductionBatchEntity.toDomain() = ProductionBatch(
    id = id, cycleType = cycleType, inputKg = inputKg, outputKg = outputKg, gatepassReceived = gatepassReceived,
)

internal fun BoardroomQueryEntity.toDomain() = BoardroomQuery(
    question = question, answer = answer, mode = mode,
    askedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(askedAtEpochMillis), ZoneOffset.UTC),
)

internal fun TaskItemEntity.toDomain() = TaskItem(
    id = id, title = title, assignee = assignee, done = done,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
    isDeleted = isDeleted,
    deletedAt = deletedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    deletedBy = deletedBy,
    status = runCatching { TaskStatus.valueOf(status) }.getOrDefault(TaskStatus.PENDING),
    parentTaskId = parentTaskId,
)

internal fun ApprovalRequestEntity.toDomain() = ApprovalRequest(
    id = id, type = ApprovalType.valueOf(type), fromEmployee = fromEmployee, detail = detail,
    status = ApprovalStatus.valueOf(status),
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
    entityType = entityType, entityId = entityId, level = level, approvedBy = approvedBy,
    approvedAt = approvedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    rejectReason = rejectReason, assignedToEmployeeId = assignedToEmployeeId, escalated = escalated,
)

internal fun CourierPartnerEntity.toDomain() = CourierPartner(
    id = id, name = name, hasApi = hasApi, apiBaseUrl = apiBaseUrl, apiKey = apiKey,
    courierType = courierType, apiSecretKey = apiSecretKey, apiUsername = apiUsername, apiPassword = apiPassword, apiStoreId = apiStoreId,
)

internal fun ShipmentEntity.toDomain() = Shipment(
    id = id, courierId = courierId, vehicleId = vehicleId, dealerOrRetailer = dealerOrRetailer, trackingId = trackingId,
    status = ShipmentStatus.valueOf(status), invoiceId = invoiceId, invoiceNo = invoiceNo,
    deliveryAddress = deliveryAddress, weightKg = weightKg, condition = condition,
)

internal fun LedgerEntryEntity.toDomain() = LedgerEntry(
    id = id, type = LedgerEntryType.valueOf(type), category = category, description = description,
    amount = amount, recordedBy = recordedBy, division = division,
    recordedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(recordedAtEpochMillis), ZoneOffset.UTC),
)

internal fun InvoiceEntity.toSalesDomain() = SalesInvoice(
    id = id, invoiceNo = invoiceNo, dealerId = dealerId, dealerName = dealerName, dealerZone = dealerZone,
    lineItems = Converters.unpackSalesInvoiceItems(lineItemsRaw), dealerDiscountPct = dealerDiscountPct,
    commissionPct = commissionPct, courier = courier, signedByRole = signedByRole, createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
    status = status, paidAmount = paidAmount, isDeleted = isDeleted,
    deletedAt = deletedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) }, deletedBy = deletedBy,
    warehouseId = warehouseId, stockReserved = stockReserved, giftNote = giftNote,
    previousDueSnapshot = previousDueSnapshot, closingDueSnapshot = closingDueSnapshot,
)

/**
 * Rejects easily-guessable 5-digit PINs — repeated digits (11111, 00000) and
 * straight ascending/descending runs (12345, 54321). Used wherever a PIN gets
 * SET (Forgot-PIN's new-PIN step, Admin's Reset PIN) — not on ordinary login,
 * since that's just checking whatever PIN already exists.
 */
fun isWeakPin(pin: String): Boolean {
    if (!pin.matches(Regex("^\\d{5}$"))) return true
    if (pin.toSet().size == 1) return true // 11111, 00000, ইত্যাদি
    val ascending = "0123456789"
    val descending = "9876543210"
    if (ascending.contains(pin) || descending.contains(pin)) return true // 12345, 54321, ইত্যাদি
    return false
}

// ================= Module 4/7/8 mappers =================

internal fun Quotation.toEntity() = QuotationEntity(
    id = id, quotationNo = quotationNo, partyType = partyType.name, partyId = partyId, partyName = partyName,
    lineItemsRaw = Converters.packSalesInvoiceItems(lineItems), validUntilEpochMillis = validUntil.toInstant(ZoneOffset.UTC).toEpochMilli(),
    status = status, convertedInvoiceId = convertedInvoiceId, createdBy = createdBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

internal fun QuotationEntity.toDomain() = Quotation(
    id = id, quotationNo = quotationNo, partyType = PartyType.valueOf(partyType), partyId = partyId, partyName = partyName,
    lineItems = Converters.unpackSalesInvoiceItems(lineItemsRaw),
    validUntil = LocalDateTime.ofInstant(Instant.ofEpochMilli(validUntilEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    status = status, convertedInvoiceId = convertedInvoiceId, createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC), isDeleted = isDeleted,
)

internal fun DeliveryChallan.toEntity() = DeliveryChallanEntity(
    id = id, challanNo = challanNo, invoiceId = invoiceId, partyType = partyType.name, partyId = partyId, partyName = partyName,
    lineItemsRaw = Converters.packSalesInvoiceItems(lineItems), vehicleNo = vehicleNo, driverName = driverName,
    deliveredBy = deliveredBy, status = status, createdBy = createdBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

internal fun DeliveryChallanEntity.toDomain() = DeliveryChallan(
    id = id, challanNo = challanNo, invoiceId = invoiceId, partyType = PartyType.valueOf(partyType), partyId = partyId, partyName = partyName,
    lineItems = Converters.unpackSalesInvoiceItems(lineItemsRaw), vehicleNo = vehicleNo, driverName = driverName,
    deliveredBy = deliveredBy, status = status, createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC), isDeleted = isDeleted,
)

internal fun SalesReturn.toEntity() = SalesReturnEntity(
    id = id, returnNo = returnNo, invoiceId = invoiceId, partyType = partyType.name, partyId = partyId, partyName = partyName,
    lineItemsRaw = Converters.packSalesInvoiceItems(lineItems), reason = reason, refundAmount = refundAmount,
    status = status, createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), isDeleted = isDeleted,
)

internal fun SalesReturnEntity.toDomain() = SalesReturn(
    id = id, returnNo = returnNo, invoiceId = invoiceId, partyType = PartyType.valueOf(partyType), partyId = partyId, partyName = partyName,
    lineItems = Converters.unpackSalesInvoiceItems(lineItemsRaw), reason = reason, refundAmount = refundAmount,
    status = status, createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC), isDeleted = isDeleted,
)

internal fun PartyLedgerEntryEntity.toDomain() = PartyLedgerEntry(
    id = id, partyType = PartyType.valueOf(partyType), partyId = partyId, type = type, amount = amount,
    reason = reason, referenceId = referenceId, balanceAfter = balanceAfter,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
)

internal fun com.abm.erp.data.room.CustomerComplaintEntity.toDomain() = CustomerComplaint(
    id = id, complaintNo = complaintNo, dealerId = dealerId, dealerName = dealerName,
    productId = productId, productName = productName, invoiceId = invoiceId, invoiceNo = invoiceNo,
    category = category, description = description, priority = priority,
    status = CustomerComplaintStatus.valueOf(status), assignedEmployeeId = assignedEmployeeId, assignedEmployeeName = assignedEmployeeName,
    resolutionNote = resolutionNote, createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    resolvedAt = resolvedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) }, isDeleted = isDeleted,
    partyType = runCatching { PartyType.valueOf(partyType) }.getOrDefault(PartyType.DEALER), retailerId = retailerId, retailerName = retailerName,
)

internal fun CustomerComplaint.toEntity() = com.abm.erp.data.room.CustomerComplaintEntity(
    id = id, complaintNo = complaintNo, dealerId = dealerId, dealerName = dealerName,
    productId = productId, productName = productName, invoiceId = invoiceId, invoiceNo = invoiceNo,
    category = category, description = description, priority = priority,
    status = status.name, assignedEmployeeId = assignedEmployeeId, assignedEmployeeName = assignedEmployeeName,
    resolutionNote = resolutionNote, createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    resolvedAtEpochMillis = resolvedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(), isDeleted = isDeleted,
    partyType = partyType.name, retailerId = retailerId, retailerName = retailerName,
)

internal fun PartyCollection.toEntity() = PartyCollectionEntity(
    id = id, collectionNo = collectionNo, partyType = partyType.name, partyId = partyId, partyName = partyName, amount = amount, method = method,
    proofUri = proofUri, status = status, collectedBy = collectedBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), verifiedBy = verifiedBy,
    verifiedAtEpochMillis = verifiedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(), allocatedInvoiceId = allocatedInvoiceId,
)

internal fun PartyCollectionEntity.toDomain() = PartyCollection(
    id = id, collectionNo = collectionNo, partyType = PartyType.valueOf(partyType), partyId = partyId, partyName = partyName, amount = amount, method = method,
    proofUri = proofUri, status = status, collectedBy = collectedBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC), verifiedBy = verifiedBy,
    verifiedAt = verifiedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) }, allocatedInvoiceId = allocatedInvoiceId,
)

internal fun DiscountRule.toEntity() = DiscountRuleEntity(
    id = id, label = label, scope = scope, minQty = minQty, discountPct = discountPct, isActive = isActive,
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun DiscountRuleEntity.toDomain() = DiscountRule(
    id = id, label = label, scope = scope, minQty = minQty, discountPct = discountPct, isActive = isActive,
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
)

internal fun SalesRoute.toEntity() = SalesRouteEntity(
    id = id, name = name, territoryId = territoryId, assignedToEmployeeId = assignedToEmployeeId,
    outletIdsRaw = outletIds.joinToString(","), isActive = isActive,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun SalesRouteEntity.toDomain() = SalesRoute(
    id = id, name = name, territoryId = territoryId, assignedToEmployeeId = assignedToEmployeeId,
    outletIds = outletIdsRaw.split(",").filter { it.isNotBlank() }, isActive = isActive,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun VisitLog.toEntity() = VisitLogEntity(
    id = id, partyType = partyType.name, partyId = partyId, employeeId = employeeId, employeeName = employeeName,
    lat = lat, lng = lng, photoUri = photoUri, purpose = purpose,
    checkInAtEpochMillis = checkInAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    checkOutAtEpochMillis = checkOutAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    routeId = routeId, checkInAccuracyMeters = checkInAccuracyMeters, checkInProvider = checkInProvider,
    checkInMockSuspected = checkInMockSuspected, checkInDistanceFromRetailerMeters = checkInDistanceFromRetailerMeters,
    checkOutLat = checkOutLat, checkOutLng = checkOutLng, checkOutAccuracyMeters = checkOutAccuracyMeters,
    checkOutMockSuspected = checkOutMockSuspected, checkOutDistanceFromRetailerMeters = checkOutDistanceFromRetailerMeters,
    deviceId = deviceId, verificationResult = verificationResult, verificationScore = verificationScore,
    overrideReason = overrideReason, overrideBy = overrideBy, orderCreatedId = orderCreatedId,
    collectionCreatedId = collectionCreatedId, complaintCreatedId = complaintCreatedId, notes = notes,
)

internal fun VisitLogEntity.toDomain() = VisitLog(
    id = id, partyType = PartyType.valueOf(partyType), partyId = partyId, employeeId = employeeId, employeeName = employeeName,
    lat = lat, lng = lng, photoUri = photoUri, purpose = purpose,
    checkInAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(checkInAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    checkOutAt = checkOutAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    routeId = routeId, checkInAccuracyMeters = checkInAccuracyMeters, checkInProvider = checkInProvider,
    checkInMockSuspected = checkInMockSuspected, checkInDistanceFromRetailerMeters = checkInDistanceFromRetailerMeters,
    checkOutLat = checkOutLat, checkOutLng = checkOutLng, checkOutAccuracyMeters = checkOutAccuracyMeters,
    checkOutMockSuspected = checkOutMockSuspected, checkOutDistanceFromRetailerMeters = checkOutDistanceFromRetailerMeters,
    deviceId = deviceId, verificationResult = verificationResult, verificationScore = verificationScore,
    overrideReason = overrideReason, overrideBy = overrideBy, orderCreatedId = orderCreatedId,
    collectionCreatedId = collectionCreatedId, complaintCreatedId = complaintCreatedId, notes = notes,
)

// ================= Module 2 Production mappers =================

internal fun packBomLines(lines: List<BomLine>): String = lines.joinToString(";") { "${it.rawMaterialName},${it.qtyPerUnit},${it.unit}" }
internal fun unpackBomLines(raw: String): List<BomLine> {
    if (raw.isBlank()) return emptyList()
    return raw.split(";").filter { it.isNotBlank() }.map { val p = it.split(","); BomLine(p[0], p[1].toDouble(), p[2]) }
}

internal fun BillOfMaterials.toEntity() = com.abm.erp.data.room.BillOfMaterialsEntity(
    id = id, finishedProductName = finishedProductName, linesRaw = packBomLines(lines),
    laborCostPerUnit = laborCostPerUnit, overheadCostPerUnit = overheadCostPerUnit, isActive = isActive,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.BillOfMaterialsEntity.toDomain() = BillOfMaterials(
    id = id, finishedProductName = finishedProductName, lines = unpackBomLines(linesRaw),
    laborCostPerUnit = laborCostPerUnit, overheadCostPerUnit = overheadCostPerUnit, isActive = isActive,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun ProductionOrder.toEntity() = com.abm.erp.data.room.ProductionOrderEntity(
    id = id, orderNo = orderNo, bomId = bomId, finishedProductName = finishedProductName, targetQty = targetQty,
    status = status, scheduledDateEpochMillis = scheduledDate.toInstant(ZoneOffset.UTC).toEpochMilli(),
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.ProductionOrderEntity.toDomain() = ProductionOrder(
    id = id, orderNo = orderNo, bomId = bomId, finishedProductName = finishedProductName, targetQty = targetQty,
    status = status, scheduledDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(scheduledDateEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
)

internal fun QualityCheck.toEntity() = com.abm.erp.data.room.QualityCheckEntity(
    id = id, batchId = batchId, result = result, notes = notes, checkedBy = checkedBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.QualityCheckEntity.toDomain() = QualityCheck(
    id = id, batchId = batchId, result = result, notes = notes, checkedBy = checkedBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
)

internal fun ProductionLoss.toEntity() = com.abm.erp.data.room.ProductionLossEntity(
    id = id, batchId = batchId, qtyLost = qtyLost, reason = reason,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.ProductionLossEntity.toDomain() = ProductionLoss(
    id = id, batchId = batchId, qtyLost = qtyLost, reason = reason,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.UTC),
)

internal fun MachineLog.toEntity() = com.abm.erp.data.room.MachineLogEntity(
    id = id, machineName = machineName, batchId = batchId, hoursUsed = hoursUsed, notes = notes,
    recordedAtEpochMillis = recordedAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.MachineLogEntity.toDomain() = MachineLog(
    id = id, machineName = machineName, batchId = batchId, hoursUsed = hoursUsed, notes = notes,
    recordedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(recordedAtEpochMillis), ZoneOffset.UTC),
)

// ================= Module 12 HR extras mappers =================

internal fun LeaveRequest.toEntity() = com.abm.erp.data.room.LeaveRequestEntity(
    id = id, employeeId = employeeId, employeeName = employeeName, type = type.name,
    fromDateEpochDay = fromDate.toEpochDay(), toDateEpochDay = toDate.toEpochDay(), reason = reason,
    status = status.name, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.LeaveRequestEntity.toDomain() = LeaveRequest(
    id = id, employeeId = employeeId, employeeName = employeeName, type = LeaveType.valueOf(type),
    fromDate = LocalDate.ofEpochDay(fromDateEpochDay), toDate = LocalDate.ofEpochDay(toDateEpochDay), reason = reason,
    status = LeaveStatus.valueOf(status), createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun EmployeeLifecycleEvent.toEntity() = com.abm.erp.data.room.EmployeeLifecycleEventEntity(
    id = id, employeeId = employeeId, employeeName = employeeName, type = type, oldValue = oldValue, newValue = newValue,
    effectiveDateEpochDay = effectiveDate.toEpochDay(), notes = notes, recordedBy = recordedBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.EmployeeLifecycleEventEntity.toDomain() = EmployeeLifecycleEvent(
    id = id, employeeId = employeeId, employeeName = employeeName, type = type, oldValue = oldValue, newValue = newValue,
    effectiveDate = LocalDate.ofEpochDay(effectiveDateEpochDay), notes = notes, recordedBy = recordedBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

// ================= Module 13 Vehicle Tracking mappers =================

internal fun Vehicle.toEntity() = com.abm.erp.data.room.VehicleEntity(
    id = id, registrationNo = registrationNo, vehicleType = vehicleType, driverName = driverName, driverPhone = driverPhone,
    isActive = isActive, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.VehicleEntity.toDomain() = Vehicle(
    id = id, registrationNo = registrationNo, vehicleType = vehicleType, driverName = driverName, driverPhone = driverPhone,
    isActive = isActive, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun VehicleLocationPing.toEntity() = com.abm.erp.data.room.VehicleLocationPingEntity(
    id = id, vehicleId = vehicleId, lat = lat, lng = lng, speedKmh = speedKmh,
    recordedAtEpochMillis = recordedAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.VehicleLocationPingEntity.toDomain() = VehicleLocationPing(
    id = id, vehicleId = vehicleId, lat = lat, lng = lng, speedKmh = speedKmh,
    recordedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(recordedAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

// ================= Universal Attachment mapper =================

internal fun Attachment.toEntity() = com.abm.erp.data.room.AttachmentEntity(
    id = id, moduleReference = moduleReference, entityId = entityId, type = type.name, uri = uri,
    lat = lat, lng = lng, uploadedBy = uploadedBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.AttachmentEntity.toDomain() = Attachment(
    id = id, moduleReference = moduleReference, entityId = entityId, type = AttachmentType.valueOf(type), uri = uri,
    lat = lat, lng = lng, uploadedBy = uploadedBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun com.abm.erp.data.room.AuditLogEntity.toDomain() = AuditLogEntry(
    id = id, entityType = entityType, entityId = entityId, action = action, performedBy = performedBy, performedByRole = performedByRole,
    oldValueJson = oldValueJson, newValueJson = newValueJson, reason = reason, relatedApprovalId = relatedApprovalId,
    deviceId = deviceId, gpsLat = gpsLat, gpsLng = gpsLng, syncStatus = syncStatus,
    timestamp = LocalDateTime.ofInstant(Instant.ofEpochMilli(timestampEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun com.abm.erp.data.room.NotificationEntryEntity.toDomain() = NotificationEntry(
    id = id, category = runCatching { NotificationCategory.valueOf(category) }.getOrDefault(NotificationCategory.APPROVAL),
    title = title, body = body, targetEmployeeId = targetEmployeeId, imageUri = imageUri, isRead = isRead,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun com.abm.erp.data.room.SalesOrderEntity.toDomain() = SalesOrder(
    id = id, orderNo = orderNo, dealerId = dealerId, dealerName = dealerName, dealerZone = dealerZone,
    lineItems = Converters.unpackSalesInvoiceItems(lineItemsRaw), dealerDiscountPct = dealerDiscountPct, status = status,
    convertedToInvoiceId = convertedToInvoiceId,
    deliveredQtyByProduct = if (deliveredQtyRaw.isBlank()) emptyMap() else deliveredQtyRaw.split(";").filter { it.isNotBlank() }.associate { val p = it.split(","); p[0] to p[1].toInt() },
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    approvedBy = approvedBy, approvedAt = approvedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) }, isDeleted = isDeleted,
)

internal fun SalesOrder.toEntity() = com.abm.erp.data.room.SalesOrderEntity(
    id = id, orderNo = orderNo, dealerId = dealerId, dealerName = dealerName, dealerZone = dealerZone,
    lineItemsRaw = Converters.packSalesInvoiceItems(lineItems), dealerDiscountPct = dealerDiscountPct, status = status,
    convertedToInvoiceId = convertedToInvoiceId,
    deliveredQtyRaw = deliveredQtyByProduct.entries.joinToString(";") { "${it.key},${it.value}" },
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    approvedBy = approvedBy, approvedAtEpochMillis = approvedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(), isDeleted = isDeleted,
)

internal fun com.abm.erp.data.room.EmployeeAreaAssignmentEntity.toDomain() = EmployeeAreaAssignment(
    id = id, employeeId = employeeId, companyId = companyId,
    divisionId = divisionId, divisionName = divisionName, districtId = districtId, districtName = districtName,
    upazilaId = upazilaId, upazilaName = upazilaName, unionId = unionId, unionName = unionName,
    marketName = marketName, routeId = routeId, assignmentType = AreaAssignmentType.valueOf(assignmentType),
    startDate = LocalDate.ofEpochDay(startDateEpochDay), endDate = endDateEpochDay?.let { LocalDate.ofEpochDay(it) },
    assignedBy = assignedBy, approvalStatus = approvalStatus, isActive = isActive,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun EmployeeAreaAssignment.toEntity() = com.abm.erp.data.room.EmployeeAreaAssignmentEntity(
    id = id, employeeId = employeeId, companyId = companyId,
    divisionId = divisionId, divisionName = divisionName, districtId = districtId, districtName = districtName,
    upazilaId = upazilaId, upazilaName = upazilaName, unionId = unionId, unionName = unionName,
    marketName = marketName, routeId = routeId, assignmentType = assignmentType.name,
    startDateEpochDay = startDate.toEpochDay(), endDateEpochDay = endDate?.toEpochDay(),
    assignedBy = assignedBy, approvalStatus = approvalStatus, isActive = isActive,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.EmployeeAppraisalEntity.toDomain() = EmployeeAppraisal(
    id = id, employeeId = employeeId, companyId = companyId,
    periodStart = LocalDate.ofEpochDay(periodStartEpochDay), periodEnd = LocalDate.ofEpochDay(periodEndEpochDay),
    salesTarget = salesTarget, salesAchievement = salesAchievement, collectionTarget = collectionTarget, collectionAchievement = collectionAchievement,
    attendancePresentDays = attendancePresentDays, attendanceTotalDays = attendanceTotalDays, punctualityLateDays = punctualityLateDays,
    dealerVisits = dealerVisits, retailerVisits = retailerVisits, newDealerAcquisition = newDealerAcquisition, newRetailerAcquisition = newRetailerAcquisition,
    returnRatePct = returnRatePct, complaintCount = complaintCount, supervisorScore = supervisorScore, hrScore = hrScore,
    managerComment = managerComment, employeeAcknowledged = employeeAcknowledged,
    employeeAcknowledgedAt = employeeAcknowledgedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    finalScore = finalScore, rating = rating,
    recognitions = recognitionsRaw.split(",").filter { it.isNotBlank() }.map { RecognitionType.valueOf(it) },
    generatedBy = generatedBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun EmployeeAppraisal.toEntity() = com.abm.erp.data.room.EmployeeAppraisalEntity(
    id = id, employeeId = employeeId, companyId = companyId,
    periodStartEpochDay = periodStart.toEpochDay(), periodEndEpochDay = periodEnd.toEpochDay(),
    salesTarget = salesTarget, salesAchievement = salesAchievement, collectionTarget = collectionTarget, collectionAchievement = collectionAchievement,
    attendancePresentDays = attendancePresentDays, attendanceTotalDays = attendanceTotalDays, punctualityLateDays = punctualityLateDays,
    dealerVisits = dealerVisits, retailerVisits = retailerVisits, newDealerAcquisition = newDealerAcquisition, newRetailerAcquisition = newRetailerAcquisition,
    returnRatePct = returnRatePct, complaintCount = complaintCount, supervisorScore = supervisorScore, hrScore = hrScore,
    managerComment = managerComment, employeeAcknowledged = employeeAcknowledged,
    employeeAcknowledgedAtEpochMillis = employeeAcknowledgedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    finalScore = finalScore, rating = rating, recognitionsRaw = recognitions.joinToString(",") { it.name },
    generatedBy = generatedBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.ManufacturingWorkerAssignmentEntity.toDomain() = ManufacturingWorkerAssignment(
    id = id, employeeId = employeeId, companyId = companyId, manufacturingUnitId = manufacturingUnitId,
    productionLine = productionLine, machine = machine, section = section, shiftType = ShiftType.valueOf(shiftType),
    supervisorEmployeeId = supervisorEmployeeId,
    skills = skillsRaw.split(",").filter { it.isNotBlank() }.map { ManufacturingSkill.valueOf(it) },
    startDate = LocalDate.ofEpochDay(startDateEpochDay), endDate = endDateEpochDay?.let { LocalDate.ofEpochDay(it) },
    isActive = isActive, assignedBy = assignedBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun ManufacturingWorkerAssignment.toEntity() = com.abm.erp.data.room.ManufacturingWorkerAssignmentEntity(
    id = id, employeeId = employeeId, companyId = companyId, manufacturingUnitId = manufacturingUnitId,
    productionLine = productionLine, machine = machine, section = section, shiftType = shiftType.name,
    supervisorEmployeeId = supervisorEmployeeId, skillsRaw = skills.joinToString(",") { it.name },
    startDateEpochDay = startDate.toEpochDay(), endDateEpochDay = endDate?.toEpochDay(),
    isActive = isActive, assignedBy = assignedBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.ProductionPlanEntity.toDomain() = ProductionPlan(
    id = id, planNumber = planNumber, companyId = companyId, productId = productId, variant = variant,
    plannedQuantity = plannedQuantity, unit = unit, batchNumber = batchNumber,
    productionDate = LocalDate.ofEpochDay(productionDateEpochDay), manufacturingUnitId = manufacturingUnitId,
    productionLine = productionLine, shiftType = ShiftType.valueOf(shiftType), supervisorEmployeeId = supervisorEmployeeId,
    status = ProductionPlanStatus.valueOf(status), createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun ProductionPlan.toEntity() = com.abm.erp.data.room.ProductionPlanEntity(
    id = id, planNumber = planNumber, companyId = companyId, productId = productId, variant = variant,
    plannedQuantity = plannedQuantity, unit = unit, batchNumber = batchNumber, productionDateEpochDay = productionDate.toEpochDay(),
    manufacturingUnitId = manufacturingUnitId, productionLine = productionLine, shiftType = shiftType.name,
    supervisorEmployeeId = supervisorEmployeeId, status = status.name, createdBy = createdBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.RawMaterialIssueEntity.toDomain() = RawMaterialIssue(
    id = id, productionPlanId = productionPlanId, companyId = companyId, materialProductId = materialProductId,
    warehouseId = warehouseId, binLocation = binLocation, batchCode = batchCode, issuedQuantity = issuedQuantity,
    consumedQuantity = consumedQuantity, returnedQuantity = returnedQuantity, wastedQuantity = wastedQuantity,
    issuedBy = issuedBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun RawMaterialIssue.toEntity() = com.abm.erp.data.room.RawMaterialIssueEntity(
    id = id, productionPlanId = productionPlanId, companyId = companyId, materialProductId = materialProductId,
    warehouseId = warehouseId, binLocation = binLocation, batchCode = batchCode, issuedQuantity = issuedQuantity,
    consumedQuantity = consumedQuantity, returnedQuantity = returnedQuantity, wastedQuantity = wastedQuantity,
    issuedBy = issuedBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.QualityInspectionEntity.toDomain() = QualityInspection(
    id = id, productionPlanId = productionPlanId, batchId = batchId, transferId = transferId, companyId = companyId,
    inspector = inspector, testParameters = testParameters, result = QcResult.valueOf(result),
    sampleQuantity = sampleQuantity, rejectedQuantity = rejectedQuantity, comment = comment, attachmentUri = attachmentUri,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun QualityInspection.toEntity() = com.abm.erp.data.room.QualityInspectionEntity(
    id = id, productionPlanId = productionPlanId, batchId = batchId, transferId = transferId, companyId = companyId,
    inspector = inspector, testParameters = testParameters, result = result.name,
    sampleQuantity = sampleQuantity, rejectedQuantity = rejectedQuantity, comment = comment, attachmentUri = attachmentUri,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.PackingRecordEntity.toDomain() = PackingRecord(
    id = id, productionPlanId = productionPlanId, companyId = companyId, bulkQuantityReceived = bulkQuantityReceived,
    packingSize = packingSize, numberOfPacks = numberOfPacks, numberOfCartons = numberOfCartons, looseQuantity = looseQuantity,
    damagedPacks = damagedPacks, wastageQuantity = wastageQuantity, finalAcceptedQuantity = finalAcceptedQuantity,
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun PackingRecord.toEntity() = com.abm.erp.data.room.PackingRecordEntity(
    id = id, productionPlanId = productionPlanId, companyId = companyId, bulkQuantityReceived = bulkQuantityReceived,
    packingSize = packingSize, numberOfPacks = numberOfPacks, numberOfCartons = numberOfCartons, looseQuantity = looseQuantity,
    damagedPacks = damagedPacks, wastageQuantity = wastageQuantity, finalAcceptedQuantity = finalAcceptedQuantity,
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun Carton.toEntity() = com.abm.erp.data.room.CartonEntity(
    id = id, cartonCode = cartonCode, companyId = companyId, productionPlanId = productionPlanId,
    productId = productId, productName = productName, batchCode = batchCode, quantityInside = quantityInside, unit = unit,
    status = status, packedBy = packedBy, packedAtEpochMillis = packedAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    warehouseId = warehouseId, warehouseReceivedBy = warehouseReceivedBy,
    warehouseReceivedAtEpochMillis = warehouseReceivedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    dispatchedTo = dispatchedTo, dispatchedBy = dispatchedBy,
    dispatchedAtEpochMillis = dispatchedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    deliveredBy = deliveredBy, deliveredAtEpochMillis = deliveredAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
)

internal fun com.abm.erp.data.room.CartonEntity.toDomain() = Carton(
    id = id, cartonCode = cartonCode, companyId = companyId, productionPlanId = productionPlanId,
    productId = productId, productName = productName, batchCode = batchCode, quantityInside = quantityInside, unit = unit,
    status = status, packedBy = packedBy,
    packedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(packedAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    warehouseId = warehouseId, warehouseReceivedBy = warehouseReceivedBy,
    warehouseReceivedAt = warehouseReceivedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    dispatchedTo = dispatchedTo, dispatchedBy = dispatchedBy,
    dispatchedAt = dispatchedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    deliveredBy = deliveredBy,
    deliveredAt = deliveredAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
)

internal fun com.abm.erp.data.room.FinishedGoodsReceiptEntity.toDomain() = FinishedGoodsReceipt(
    id = id, productionPlanId = productionPlanId, companyId = companyId, productId = productId, batchCode = batchCode,
    manufacturingDate = LocalDate.ofEpochDay(manufacturingDateEpochDay), expiryDate = expiryDateEpochDay?.let { LocalDate.ofEpochDay(it) },
    quantity = quantity, unit = unit, warehouseId = warehouseId, unitCost = unitCost, qcStatus = QcResult.valueOf(qcStatus),
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun FinishedGoodsReceipt.toEntity() = com.abm.erp.data.room.FinishedGoodsReceiptEntity(
    id = id, productionPlanId = productionPlanId, companyId = companyId, productId = productId, batchCode = batchCode,
    manufacturingDateEpochDay = manufacturingDate.toEpochDay(), expiryDateEpochDay = expiryDate?.toEpochDay(),
    quantity = quantity, unit = unit, warehouseId = warehouseId, unitCost = unitCost, qcStatus = qcStatus.name,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

// Phase 7 — WarehouseTransferLine pack/unpack, same pipe-delimited pattern as packPurchaseLineItems (no JSON library dependency added).
// Field 14 (transferId) was added after this format was first used in the field, so unpack must stay
// backward-compatible with older 13-field records that don't have it — see unpackTransferLines below.
internal fun packTransferLines(lines: List<WarehouseTransferLine>): String =
    lines.joinToString(";") { "${it.id}|${it.productId}|${it.batchCode ?: ""}|${it.quantity}|${it.unit}|${it.cartons}|${it.loosePacks}|${it.dispatchedQuantity}|${it.receivedQuantity}|${it.damagedQuantity}|${it.missingQuantity}|${it.excessQuantity}|${it.acceptedQuantity}|${it.transferId}" }

// parentTransferId is the owning WarehouseTransferEntity's id (its primary key). Older stored records were
// packed before field 14 existed, so p.getOrNull(13) is null for them — parentTransferId is the correct,
// real (non-fake) value in that case since every line always belongs to exactly the transfer it was read from.
internal fun unpackTransferLines(raw: String, parentTransferId: String): List<WarehouseTransferLine> {
    if (raw.isBlank()) return emptyList()
    return raw.split(";").filter { it.isNotBlank() }.map { record ->
        val p = record.split("|")
        WarehouseTransferLine(
            id = p[0], transferId = p.getOrNull(13)?.takeIf { it.isNotBlank() } ?: parentTransferId,
            productId = p[1], batchCode = p[2].ifBlank { null }, quantity = p[3].toDouble(), unit = p[4],
            cartons = p[5].toInt(), loosePacks = p[6].toDouble(), dispatchedQuantity = p[7].toDouble(),
            receivedQuantity = p[8].toDouble(), damagedQuantity = p[9].toDouble(), missingQuantity = p[10].toDouble(),
            excessQuantity = p[11].toDouble(), acceptedQuantity = p[12].toDouble(),
        )
    }
}

internal fun com.abm.erp.data.room.WarehouseTransferEntity.toDomain() = WarehouseTransfer(
    id = id, transferNumber = transferNumber, companyId = companyId, sourceWarehouseId = sourceWarehouseId,
    destinationWarehouseId = destinationWarehouseId, lines = unpackTransferLines(linesRaw, id), requestedBy = requestedBy,
    approvedBy = approvedBy, vehicle = vehicle, driver = driver,
    dispatchDate = dispatchDateEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    expectedDeliveryDate = expectedDeliveryDateEpochDay?.let { LocalDate.ofEpochDay(it) }, notes = notes,
    status = TransferStatus.valueOf(status), dispatchChallanNumber = dispatchChallanNumber, dispatchedBy = dispatchedBy,
    dispatchedAt = dispatchedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    attachmentUri = attachmentUri,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun WarehouseTransfer.toEntity() = com.abm.erp.data.room.WarehouseTransferEntity(
    id = id, transferNumber = transferNumber, companyId = companyId, sourceWarehouseId = sourceWarehouseId,
    destinationWarehouseId = destinationWarehouseId, linesRaw = packTransferLines(lines), requestedBy = requestedBy,
    approvedBy = approvedBy, vehicle = vehicle, driver = driver,
    dispatchDateEpochMillis = dispatchDate?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    expectedDeliveryDateEpochDay = expectedDeliveryDate?.toEpochDay(), notes = notes, status = status.name,
    dispatchChallanNumber = dispatchChallanNumber, dispatchedBy = dispatchedBy,
    dispatchedAtEpochMillis = dispatchedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(), attachmentUri = attachmentUri,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.WarehouseReceiptEntity.toDomain() = WarehouseReceipt(
    id = id, transferId = transferId, companyId = companyId, receivingWarehouseId = receivingWarehouseId,
    binLocation = binLocation, receiver = receiver, comment = comment, proofUri = proofUri,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun WarehouseReceipt.toEntity() = com.abm.erp.data.room.WarehouseReceiptEntity(
    id = id, transferId = transferId, companyId = companyId, receivingWarehouseId = receivingWarehouseId,
    binLocation = binLocation, receiver = receiver, comment = comment, proofUri = proofUri,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.EmployeePermissionOverrideEntity.toDomain() = EmployeePermissionOverride(
    id = id, employeeId = employeeId, companyId = companyId, moduleKey = moduleKey, accessLevel = AccessLevel.valueOf(accessLevel),
    setBy = setBy, setByName = setByName,
    setAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(setAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun EmployeePermissionOverride.toEntity() = com.abm.erp.data.room.EmployeePermissionOverrideEntity(
    id = id, employeeId = employeeId, companyId = companyId, moduleKey = moduleKey, accessLevel = accessLevel.name,
    setBy = setBy, setByName = setByName, setAtEpochMillis = setAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.EmployeeProfileEntity.toDomain() = EmployeeProfile(
    id = id, employeeCode = employeeCode, userAccountId = userAccountId, fullName = fullName, mobile = mobile, email = email,
    department = department, designation = designation, role = UserRole.valueOf(role), grade = grade, employmentType = employmentType,
    employeeType = runCatching { EmployeeType.valueOf(employeeType) }.getOrDefault(EmployeeType.OFFICE),
    joiningDate = joiningDateEpochDay?.let { LocalDate.ofEpochDay(it) }, status = EmployeeStatus.valueOf(status), statusReason = statusReason,
    companyId = companyId, branch = branch, region = region, area = area, territoryId = territoryId, routeId = routeId,
    branchId = branchId, departmentId = departmentId, divisionId = divisionId, districtId = districtId, upazilaId = upazilaId, unionId = unionId,
    directManagerId = directManagerId, secondaryManagerId = secondaryManagerId, functionalManagerId = functionalManagerId,
    reportingEffectiveFrom = reportingEffectiveFromEpochDay?.let { LocalDate.ofEpochDay(it) },
    reportingEffectiveTo = reportingEffectiveToEpochDay?.let { LocalDate.ofEpochDay(it) },
    tempManagerId = tempManagerId, tempAssignmentFrom = tempAssignmentFromEpochDay?.let { LocalDate.ofEpochDay(it) },
    tempAssignmentTo = tempAssignmentToEpochDay?.let { LocalDate.ofEpochDay(it) },
    approvalAuthorityLevel = approvalAuthorityLevel, financialApprovalLimit = financialApprovalLimit, creditOverrideLimit = creditOverrideLimit,
    discountApprovalLimitPct = discountApprovalLimitPct, stockAdjustmentApprovalLimit = stockAdjustmentApprovalLimit,
    purchaseApprovalLimit = purchaseApprovalLimit, leaveApprovalAuthority = leaveApprovalAuthority, attendanceCorrectionAuthority = attendanceCorrectionAuthority,
    dataAccessScope = dataAccessScope, onboardingStatus = EmployeeOnboardingStatus.valueOf(onboardingStatus), rejectReason = rejectReason,
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    updatedBy = updatedBy, updatedAt = updatedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    isDeleted = isDeleted, deletedAt = deletedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) }, deletedBy = deletedBy,
    nationalId = nationalId, dateOfBirth = dateOfBirthEpochDay?.let { LocalDate.ofEpochDay(it) }, workLocation = workLocation,
    emergencyContactName = emergencyContactName, emergencyContactPhone = emergencyContactPhone, profilePhotoUri = profilePhotoUri, basePayMonthly = basePayMonthly, assignedTemplateKey = assignedTemplateKey,
)

internal fun EmployeeProfile.toEntity() = com.abm.erp.data.room.EmployeeProfileEntity(
    id = id, employeeCode = employeeCode, userAccountId = userAccountId, fullName = fullName, mobile = mobile, email = email,
    department = department, designation = designation, role = role.name, grade = grade, employmentType = employmentType,
    employeeType = employeeType.name,
    joiningDateEpochDay = joiningDate?.toEpochDay(), status = status.name, statusReason = statusReason,
    companyId = companyId, branch = branch, region = region, area = area, territoryId = territoryId, routeId = routeId,
    branchId = branchId, departmentId = departmentId, divisionId = divisionId, districtId = districtId, upazilaId = upazilaId, unionId = unionId,
    directManagerId = directManagerId, secondaryManagerId = secondaryManagerId, functionalManagerId = functionalManagerId,
    reportingEffectiveFromEpochDay = reportingEffectiveFrom?.toEpochDay(), reportingEffectiveToEpochDay = reportingEffectiveTo?.toEpochDay(),
    tempManagerId = tempManagerId, tempAssignmentFromEpochDay = tempAssignmentFrom?.toEpochDay(), tempAssignmentToEpochDay = tempAssignmentTo?.toEpochDay(),
    approvalAuthorityLevel = approvalAuthorityLevel, financialApprovalLimit = financialApprovalLimit, creditOverrideLimit = creditOverrideLimit,
    discountApprovalLimitPct = discountApprovalLimitPct, stockAdjustmentApprovalLimit = stockAdjustmentApprovalLimit,
    purchaseApprovalLimit = purchaseApprovalLimit, leaveApprovalAuthority = leaveApprovalAuthority, attendanceCorrectionAuthority = attendanceCorrectionAuthority,
    dataAccessScope = dataAccessScope, onboardingStatus = onboardingStatus.name, rejectReason = rejectReason,
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    updatedBy = updatedBy, updatedAtEpochMillis = updatedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    isDeleted = isDeleted, deletedAtEpochMillis = deletedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(), deletedBy = deletedBy,
    nationalId = nationalId, dateOfBirthEpochDay = dateOfBirth?.toEpochDay(), workLocation = workLocation,
    emergencyContactName = emergencyContactName, emergencyContactPhone = emergencyContactPhone, profilePhotoUri = profilePhotoUri, basePayMonthly = basePayMonthly, assignedTemplateKey = assignedTemplateKey,
)

internal fun com.abm.erp.data.room.VacancyEntity.toDomain() = Vacancy(
    id = id, companyId = companyId, designation = designation, department = department, territoryId = territoryId,
    requestedBy = requestedBy, requestedByName = requestedByName, reason = reason, status = VacancyStatus.valueOf(status),
    approvedBy = approvedBy, filledByEmployeeId = filledByEmployeeId,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun Vacancy.toEntity() = com.abm.erp.data.room.VacancyEntity(
    id = id, companyId = companyId, designation = designation, department = department, territoryId = territoryId,
    requestedBy = requestedBy, requestedByName = requestedByName, reason = reason, status = status.name,
    approvedBy = approvedBy, filledByEmployeeId = filledByEmployeeId, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.TargetEntity.toDomain() = Target(
    id = id, companyId = companyId, scopeType = TargetScopeType.valueOf(scopeType), scopeId = scopeId, parentTargetId = parentTargetId,
    periodType = TargetPeriodType.valueOf(periodType), periodStart = LocalDate.ofEpochDay(periodStartEpochDay), periodEnd = LocalDate.ofEpochDay(periodEndEpochDay),
    targetType = TargetType.valueOf(targetType), targetValue = targetValue, achievedValue = achievedValue,
    isOverride = isOverride, overrideReason = overrideReason, status = status, createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun Target.toEntity() = com.abm.erp.data.room.TargetEntity(
    id = id, companyId = companyId, scopeType = scopeType.name, scopeId = scopeId, parentTargetId = parentTargetId,
    periodType = periodType.name, periodStartEpochDay = periodStart.toEpochDay(), periodEndEpochDay = periodEnd.toEpochDay(),
    targetType = targetType.name, targetValue = targetValue, achievedValue = achievedValue,
    isOverride = isOverride, overrideReason = overrideReason, status = status, createdBy = createdBy,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.TargetChangeLogEntity.toDomain() = TargetChangeLog(
    id = id, targetId = targetId, oldValue = oldValue, newValue = newValue, reason = reason,
    changedBy = changedBy, changedByName = changedByName,
    changedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(changedAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun TargetChangeLog.toEntity() = com.abm.erp.data.room.TargetChangeLogEntity(
    id = id, targetId = targetId, oldValue = oldValue, newValue = newValue, reason = reason,
    changedBy = changedBy, changedByName = changedByName, changedAtEpochMillis = changedAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.CorrectionRequestEntity.toDomain() = CorrectionRequest(
    id = id, companyId = companyId, module = module, recordId = recordId, correctionType = CorrectionType.valueOf(correctionType),
    reason = reason, proposedChangeJson = proposedChangeJson, originalValueJson = originalValueJson, requestedBy = requestedBy, requestedByName = requestedByName,
    managerReviewedBy = managerReviewedBy, managerComment = managerComment, chairmanApprovedBy = chairmanApprovedBy,
    chairmanComment = chairmanComment, status = CorrectionRequestStatus.valueOf(status), reversalEntryId = reversalEntryId,
    correctedEntryId = correctedEntryId,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun CorrectionRequest.toEntity() = com.abm.erp.data.room.CorrectionRequestEntity(
    id = id, companyId = companyId, module = module, recordId = recordId, correctionType = correctionType.name,
    reason = reason, proposedChangeJson = proposedChangeJson, originalValueJson = originalValueJson, requestedBy = requestedBy, requestedByName = requestedByName,
    managerReviewedBy = managerReviewedBy, managerComment = managerComment, chairmanApprovedBy = chairmanApprovedBy,
    chairmanComment = chairmanComment, status = status.name, reversalEntryId = reversalEntryId, correctedEntryId = correctedEntryId,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.AccountingPeriodLockEntity.toDomain() = AccountingPeriodLock(
    id = id, companyId = companyId, scope = PeriodLockScope.valueOf(scope), periodStart = LocalDate.ofEpochDay(periodStartEpochDay),
    periodEnd = LocalDate.ofEpochDay(periodEndEpochDay), lockedBy = lockedBy, lockedByName = lockedByName, isLocked = isLocked,
    lockedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(lockedAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    unlockedBy = unlockedBy, unlockedAt = unlockedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
)

internal fun AccountingPeriodLock.toEntity() = com.abm.erp.data.room.AccountingPeriodLockEntity(
    id = id, companyId = companyId, scope = scope.name, periodStartEpochDay = periodStart.toEpochDay(), periodEndEpochDay = periodEnd.toEpochDay(),
    lockedBy = lockedBy, lockedByName = lockedByName, isLocked = isLocked, lockedAtEpochMillis = lockedAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    unlockedBy = unlockedBy, unlockedAtEpochMillis = unlockedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
)

internal fun com.abm.erp.data.room.NumberSeriesConfigEntity.toDomain() = NumberSeriesConfig(
    id = id, companyId = companyId, companyPrefix = companyPrefix, branchPrefix = branchPrefix,
    useFinancialYear = useFinancialYear, fiscalYearStartMonth = fiscalYearStartMonth, currentRunningNumber = currentRunningNumber, padWidth = padWidth,
)

internal fun NumberSeriesConfig.toEntity() = com.abm.erp.data.room.NumberSeriesConfigEntity(
    id = id, companyId = companyId, companyPrefix = companyPrefix, branchPrefix = branchPrefix,
    useFinancialYear = useFinancialYear, fiscalYearStartMonth = fiscalYearStartMonth, currentRunningNumber = currentRunningNumber, padWidth = padWidth,
)

internal fun com.abm.erp.data.room.OwnershipTransferRecordEntity.toDomain() = OwnershipTransferRecord(
    id = id, companyId = companyId, scope = OwnershipTransferScope.valueOf(scope), entityId = entityId,
    fromEmployeeId = fromEmployeeId, toEmployeeId = toEmployeeId, reason = reason, transferredBy = transferredBy,
    transferredAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(transferredAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun OwnershipTransferRecord.toEntity() = com.abm.erp.data.room.OwnershipTransferRecordEntity(
    id = id, companyId = companyId, scope = scope.name, entityId = entityId, fromEmployeeId = fromEmployeeId,
    toEmployeeId = toEmployeeId, reason = reason, transferredBy = transferredBy,
    transferredAtEpochMillis = transferredAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.BusinessRuleEntity.toDomain() = BusinessRule(
    key = key, label = label, type = BusinessRuleType.valueOf(type), value = value, companyId = companyId,
    updatedBy = updatedBy, updatedByName = updatedByName,
    updatedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(updatedAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun BusinessRule.toEntity() = com.abm.erp.data.room.BusinessRuleEntity(
    key = key, label = label, type = type.name, value = value, companyId = companyId,
    updatedBy = updatedBy, updatedByName = updatedByName, updatedAtEpochMillis = updatedAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.CompanySettingsEntity.toDomain() = CompanySettings(
    id = id, companyName = companyName, companyAddress = companyAddress, companyPhone = companyPhone, companyEmail = companyEmail,
    companyLogoUri = companyLogoUri, fiscalYearStartMonth = fiscalYearStartMonth,
    taxVatNumber = taxVatNumber, vatPct = vatPct, currencyCode = currencyCode, currencySymbol = currencySymbol,
    numberFormatPattern = numberFormatPattern, workingDays = workingDaysRaw.split(",").filter { it.isNotBlank() },
    holidaysRaw = holidaysRaw, attendancePolicyNote = attendancePolicyNote, payrollPolicyNote = payrollPolicyNote,
    invoicePolicyNote = invoicePolicyNote, dealerPolicyNote = dealerPolicyNote, targetPolicyNote = targetPolicyNote,
    updatedBy = updatedBy, updatedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(updatedAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun CompanySettings.toEntity() = com.abm.erp.data.room.CompanySettingsEntity(
    id = id, companyName = companyName, companyAddress = companyAddress, companyPhone = companyPhone, companyEmail = companyEmail,
    companyLogoUri = companyLogoUri, fiscalYearStartMonth = fiscalYearStartMonth,
    taxVatNumber = taxVatNumber, vatPct = vatPct, currencyCode = currencyCode, currencySymbol = currencySymbol,
    numberFormatPattern = numberFormatPattern, workingDaysRaw = workingDays.joinToString(","), holidaysRaw = holidaysRaw,
    attendancePolicyNote = attendancePolicyNote, payrollPolicyNote = payrollPolicyNote, invoicePolicyNote = invoicePolicyNote,
    dealerPolicyNote = dealerPolicyNote, targetPolicyNote = targetPolicyNote, updatedBy = updatedBy,
    updatedAtEpochMillis = updatedAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.ExpenseEntity.toDomain() = Expense(
    id = id, expenseNo = expenseNo, companyId = companyId, category = category, amount = amount, description = description,
    paymentMethod = ExpensePaymentMethod.valueOf(paymentMethod), submittedBy = submittedBy, submittedByEmployeeId = submittedByEmployeeId,
    status = ExpenseStatus.valueOf(status), approvedBy = approvedBy, rejectReason = rejectReason, attachmentUri = attachmentUri,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    approvedAt = approvedAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
)

internal fun Expense.toEntity() = com.abm.erp.data.room.ExpenseEntity(
    id = id, expenseNo = expenseNo, companyId = companyId, category = category, amount = amount, description = description,
    paymentMethod = paymentMethod.name, submittedBy = submittedBy, submittedByEmployeeId = submittedByEmployeeId,
    status = status.name, approvedBy = approvedBy, rejectReason = rejectReason, attachmentUri = attachmentUri,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    approvedAtEpochMillis = approvedAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
)

internal fun com.abm.erp.data.room.TransferRequestEntity.toDomain() = TransferRequest(
    id = id, employeeId = employeeId, employeeName = employeeName, transferType = transferType, fromValue = fromValue, toValue = toValue,
    newManagerId = newManagerId, effectiveDate = LocalDate.ofEpochDay(effectiveDateEpochDay), reason = reason,
    retailerHandoverToEmployeeId = retailerHandoverToEmployeeId, stage = TransferStage.valueOf(stage), rejectReason = rejectReason,
    createdBy = createdBy, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun TransferRequest.toEntity() = com.abm.erp.data.room.TransferRequestEntity(
    id = id, employeeId = employeeId, employeeName = employeeName, transferType = transferType, fromValue = fromValue, toValue = toValue,
    newManagerId = newManagerId, effectiveDateEpochDay = effectiveDate.toEpochDay(), reason = reason,
    retailerHandoverToEmployeeId = retailerHandoverToEmployeeId, stage = stage.name, rejectReason = rejectReason,
    createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.DelegationEntity.toDomain() = Delegation(
    id = id, delegatorId = delegatorId, delegatorName = delegatorName, delegateId = delegateId, delegateName = delegateName,
    scope = scope, financialLimit = financialLimit, startDate = LocalDate.ofEpochDay(startDateEpochDay), endDate = LocalDate.ofEpochDay(endDateEpochDay),
    reason = reason, isActive = isActive, createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun Delegation.toEntity() = com.abm.erp.data.room.DelegationEntity(
    id = id, delegatorId = delegatorId, delegatorName = delegatorName, delegateId = delegateId, delegateName = delegateName,
    scope = scope, financialLimit = financialLimit, startDateEpochDay = startDate.toEpochDay(), endDateEpochDay = endDate.toEpochDay(),
    reason = reason, isActive = isActive, createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.ExecutiveExceptionEntity.toDomain() = ExecutiveException(
    id = id, type = type, severity = severity, source = source, companyId = companyId, branch = branch,
    territoryId = territoryId, responsiblePerson = responsiblePerson, message = message, impact = impact,
    recommendedAction = recommendedAction, status = status, assignedReviewer = assignedReviewer, resolutionNote = resolutionNote,
    dedupKey = dedupKey, createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    updatedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(updatedAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun ExecutiveException.toEntity() = com.abm.erp.data.room.ExecutiveExceptionEntity(
    id = id, type = type, severity = severity, source = source, companyId = companyId, branch = branch,
    territoryId = territoryId, responsiblePerson = responsiblePerson, message = message, impact = impact,
    recommendedAction = recommendedAction, status = status, assignedReviewer = assignedReviewer, resolutionNote = resolutionNote,
    dedupKey = dedupKey, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    updatedAtEpochMillis = updatedAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.ManagementActionEntity.toDomain() = ManagementAction(
    id = id, title = title, sourceExceptionId = sourceExceptionId, assignedTo = assignedTo, priority = priority,
    dueDate = dueDateEpochDay?.let { LocalDate.ofEpochDay(it) }, status = status, comment = comment, evidence = evidence,
    completionNote = completionNote, createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun ManagementAction.toEntity() = com.abm.erp.data.room.ManagementActionEntity(
    id = id, title = title, sourceExceptionId = sourceExceptionId, assignedTo = assignedTo, priority = priority,
    dueDateEpochDay = dueDate?.toEpochDay(), status = status, comment = comment, evidence = evidence,
    completionNote = completionNote, createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.DecisionQueryAuditEntity.toDomain() = DecisionQueryLog(
    id = id, question = question, matchedIntent = matchedIntent, askedBy = askedBy, resultSummary = resultSummary,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun DecisionQueryLog.toEntity() = com.abm.erp.data.room.DecisionQueryAuditEntity(
    id = id, question = question, matchedIntent = matchedIntent, askedBy = askedBy, resultSummary = resultSummary,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.AdministrativeLocationEntity.toDomain() = AdministrativeLocation(
    id = id, officialCode = officialCode, sourceCode = sourceCode, type = type, nameEn = nameEn, nameBn = nameBn,
    normalizedName = normalizedName, parentId = parentId, countryCode = countryCode, divisionId = divisionId, districtId = districtId,
    upazilaId = upazilaId, unionOrMunicipalityId = unionOrMunicipalityId, wardId = wardId, latitude = latitude, longitude = longitude,
    polygon = if (polygonRaw.isBlank()) emptyList() else polygonRaw.split(";").filter { it.isNotBlank() }.map { val p = it.split(","); p[0].toDouble() to p[1].toDouble() },
    sourceName = sourceName, sourceUrl = sourceUrl, sourceVersion = sourceVersion,
    effectiveFrom = effectiveFromEpochDay?.let { LocalDate.ofEpochDay(it) }, effectiveTo = effectiveToEpochDay?.let { LocalDate.ofEpochDay(it) },
    active = active, verified = verified,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    updatedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(updatedAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    syncStatus = syncStatus,
)

internal fun AdministrativeLocation.toEntity() = com.abm.erp.data.room.AdministrativeLocationEntity(
    id = id, officialCode = officialCode, sourceCode = sourceCode, type = type, nameEn = nameEn, nameBn = nameBn,
    normalizedName = normalizedName, parentId = parentId, countryCode = countryCode, divisionId = divisionId, districtId = districtId,
    upazilaId = upazilaId, unionOrMunicipalityId = unionOrMunicipalityId, wardId = wardId, latitude = latitude, longitude = longitude,
    polygonRaw = polygon.joinToString(";") { "${it.first},${it.second}" }, sourceName = sourceName, sourceUrl = sourceUrl, sourceVersion = sourceVersion,
    effectiveFromEpochDay = effectiveFrom?.toEpochDay(), effectiveToEpochDay = effectiveTo?.toEpochDay(), active = active, verified = verified,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), updatedAtEpochMillis = updatedAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    syncStatus = syncStatus,
)

internal fun com.abm.erp.data.room.CompanyMarketEntity.toDomain() = CompanyMarket(
    id = id, name = name, parentAdminId = parentAdminId, latitude = latitude, longitude = longitude, source = source,
    verificationStatus = verificationStatus, createdBy = createdBy,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun CompanyMarket.toEntity() = com.abm.erp.data.room.CompanyMarketEntity(
    id = id, name = name, parentAdminId = parentAdminId, latitude = latitude, longitude = longitude, source = source,
    verificationStatus = verificationStatus, createdBy = createdBy, createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

internal fun com.abm.erp.data.room.UserAccountEntity.toDomain() = UserAccount(
    id = id, employeeProfileId = employeeProfileId, companyId = companyId, pinHash = pinHash, pinSalt = pinSalt,
    pinIterations = pinIterations, pinSetAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(pinSetAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    pinExpiresAt = pinExpiresAtEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    failedAttempts = failedAttempts, lockedUntil = lockedUntilEpochMillis?.let { LocalDateTime.ofInstant(Instant.ofEpochMilli(it), ZoneOffset.UTC) },
    active = active, locked = locked, mustChangePinOnNextLogin = mustChangePinOnNextLogin,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
    updatedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(updatedAtEpochMillis.takeIf { it > 0 } ?: System.currentTimeMillis()), ZoneOffset.UTC),
)

internal fun UserAccount.toEntity() = com.abm.erp.data.room.UserAccountEntity(
    id = id, employeeProfileId = employeeProfileId, companyId = companyId, pinHash = pinHash, pinSalt = pinSalt,
    pinIterations = pinIterations, pinSetAtEpochMillis = pinSetAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
    pinExpiresAtEpochMillis = pinExpiresAt?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    failedAttempts = failedAttempts, lockedUntilEpochMillis = lockedUntil?.toInstant(ZoneOffset.UTC)?.toEpochMilli(),
    active = active, locked = locked, mustChangePinOnNextLogin = mustChangePinOnNextLogin,
    createdAtEpochMillis = createdAt.toInstant(ZoneOffset.UTC).toEpochMilli(), updatedAtEpochMillis = updatedAt.toInstant(ZoneOffset.UTC).toEpochMilli(),
)

